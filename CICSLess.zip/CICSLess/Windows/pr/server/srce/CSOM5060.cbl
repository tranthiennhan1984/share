       IDENTIFICATION DIVISION.
       PROGRAM-ID. CSOM5060.
       COPY XCWWCRHT.
      *****************************************************************
      **  MEMBER :  CSOM5060                                         **
      **  REMARKS:  MODC - PROCESS DRIVER MODIFICATION OF POLICIES   **
      **            AT A CLIENT LEVEL.                               **
      **            THIS PROCESS DRIVER WILL CONTROL CHANGES TO      **
      **            POLICIES FOR A SPECIFIED CLIENT. THE USER MAY    **
      **            CHANGE ALL OR SELECTED POLICIES ONLY FOR THE     **
      **            CLIENT. EDITING AND PROCESSING IS PERFORMED UNDER**
      **            THE CONTROL OF THREE  FUNCTION DRIVERS           **
      **            CORRESPONDING TO THE THREE DIFFERENT SCREEN      **
      **            VIEWS AVAILABLE, BILLING OWNER, LISTBILL PAYOR,  **
      **            AND MISCELLANEOUS OWNER CHANGES.                 **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       DATA ARCHITECTURE MODIFICATIONS                  **
557660**  5.5       CODE CLEAN UP; STANDARDIZATION                   **
557668**  5.5       SELECTION LIST                                   **
557698**  5.5       MIXED CASE SUPPORT                               **
557708**  5.5       ABEND HANDLING                                   **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
557788**  5.5       POLICY TABLE SPLIT                               **
010466**  5.5.2     CLEANUP WHILE FIXING #10466 (-502 ABEND)         **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010418**  5.6       GET NEW RL RECORD IF CURRENT RELATIONSHIP        **
010418**            DOESN'T APPLY                                    **
010904**  5.6       DISTINGUISH BETWEEN PRIMARY AND CONTINGENT       **
010904**            OWNERS.                                          **
012011**  5.6       ADD SUB-COMPANY CODE TO MODC-B, M, L             **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
016091**  6.0       CODE CLEANUP                                     **
014221**  6.2       LOGICAL LOCKING                                  **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016387**  6.2       REMOVE CLIENT CONSOLIDATION SUPPORT              **
016395**  6.2       CREDIT CARD RENAMING OF PAC FIELDS               **
016440**  6.2       R-REL-SYS-NBS.                                   **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017356**  6.2       DED. DATE CANNOT BE ZEROED OUT IN CLIENT BILLING **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019859**  6.3       CLIENT BILLING FIXES                             **
020462**  6.4       ISO DATE STANDARDIZATION                         **
018633**  6.4       TWRK CLEANUP                                     **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023118**  6.5       CODE CLEAN-UP AND STANDARDIZATION                **
023435**  6.5       OFF ANNIVERSARY PREMIUM                          **
023436**  6.5       UNDO/REDO OF ANNIVERSARY PROCESSING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
024244**  6.5       CODE FIXED FOR CICS -7 RETURN                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025001**  6.6       NEXT BILL MODE CHANGES                           **
025156**  6.6       PROBLEM WITH CLIENT BILLING CHANGES              **
026766**  6.6       PERFORMANCE MONITORING                           **
027868**  6.6       EFFECTIVE DATE EDIT FOR OFF ANNIVERSARY          **
027897**  6.6       BILLING CHANGES WHEN POLICY IS OFF-ANNIVERSARY   **
027177**  6.7       CHANGING BILL TYPE ON CLIENT BILLING CHANGE      **
030054**  7.0       PHST SEQUENCE NUMBER EXPANSION                   **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

       ENVIRONMENT DIVISION.
      **********************
      *
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5060'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

014221 COPY CCWWLOCK.

025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-TRANS-NAME-DEFAULT    VALUE 'MODC'.

       01  WS-WORKING-STORAGE.
025970*    05  WS-TRANS-NAME                PIC X(04)
025970*                                     VALUE 'MODC'.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-SUB2                      PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB2                      PIC S9(4)  VALUE ZERO
016548                                      BINARY.
014221     05  WS-SUB3                      PIC S9(4)  VALUE ZERO
014221                                      BINARY.
016548*    05  WS-CHNG-RELAS-ALLOWED        PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-CHNG-RELAS-ALLOWED        PIC S9(4)  VALUE ZERO
016548                                      BINARY.
           05  WS-BUS-FCN-ID                PIC X(04).
016091*        88  WS-BUS-FCN-VALID         VALUE '2120' ' 2121' '2122'.
016091         88  WS-BUS-FCN-VALID         VALUE '2120' '2121' '2122'.
               88  WS-BUS-FCN-BILLCHG              VALUE '2120'.
               88  WS-BUS-FCN-LBILCHG              VALUE '2121'.
               88  WS-BUS-FCN-MISCHG               VALUE '2122'.
           05  WS-CHNG-SET-CD               PIC X(01)  VALUE SPACES.
               88  WS-CHNG-SET-CD-VALID            VALUE 'S' 'B'.
               88  WS-CHNG-SET-SELCT               VALUE 'S'.
               88  WS-CHNG-SET-BROWSE              VALUE 'B'.
           05  WS-RL-INDICATOR              PIC X(01)  VALUE SPACES.
               88  WS-RL-FOUND                         VALUE 'Y'.
               88  WS-RL-NOT-FOUND                     VALUE 'N'.
           05  WS-RL-CHECK-SW               PIC X(01)  VALUE SPACES.
               88  WS-RL-POL-FOUND                     VALUE 'Y'.
               88  WS-RL-POL-NOT-FOUND                 VALUE 'N'.
           05  WS-CHNG-RELA-IND             PIC X(01)  VALUE SPACES.
               88  WS-CHNG-RELA-FOUND                  VALUE 'Y'.
               88  WS-CHNG-RELA-NOT-FOUND              VALUE 'N'.
           05  WS-SCREEN-TYP-CD             PIC X(01).
           05  WS-PIC-S99                   PIC +99.
           05  WS-PIC-9                     PIC 9.
           05  WS-PIC-99                    PIC 99.
           05  WS-TOTAL-MSG-CTR             PIC S9(05) COMP-3.
           05  WS-POL-ERROR-CTR             PIC S9(03) COMP-3.
016395*    05  WS-PAC-DRW-DY                PIC 99.
016395     05  WS-PMT-DRW-DY                PIC 99.
014221     05  WS-LOGICAL-LOCK-SW           PIC X(01).
014221         88  WS-LOGICAL-LOCK-ERROR    VALUE 'Y'.
014221         88  WS-NO-LOCK-ERROR         VALUE 'N'.
014221     05  WS-POL-ID.
014221         10  WS-POL-ID-BASE           PIC X(09).
014221         10  WS-POL-ID-SFX            PIC X(01).
023436     05  WS-PCHST-EFF-DT              PIC X(10).
023435     05  WS-BILL-CHNG-SW              PIC X(01).
023435         88  WS-BILL-CHNG             VALUE 'Y'.
023435         88  WS-BILL-CHNG-NO          VALUE 'N'.
023435     05  WS-DIV-CHNG-SW               PIC X(01).
023435         88  WS-DIV-CHNG              VALUE 'Y'.
023435         88  WS-DIV-CHNG-NO           VALUE 'N'.
023435     05  WS-POL-PMT-DRW-DY            PIC X(02).
023435     05  WS-POL-OFFANNV-PD-DT         PIC X(10).
023435     05  WS-MODE                      PIC 9(02).
023435     05  WS-LAST-ANNV-DT              PIC X(10).
023435     05  WS-ACTV-TYP-ID               PIC 9(04).
023435         88 WS-ACTV-TYP-BILL-CHNG     VALUES
023435                                           1003
023435                                           1004
023435                                           1005
020478*                                          1006
020478                                           1006.
020478*                                          1020
020478*                                          1021
020478*                                          1022
020478*                                          1023
020478*                                          1024
020478*                                          1026
020478*                                          1027.

018633*01  WS-TWRK-KEY                      PIC X(04)
018633*                                       VALUE '2120'.
018633*01  WS-TWRK-AREA.
018633*    05  WS-TWRK-CURR-KEY.
018633*        10  WS-TWRK-SYS-ID           PIC X(08).
018633*        10  WS-TWRK-POL-ID           PIC X(10).
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '2120'.
018633     15  LCOMM-SYS-ID             PIC X(08).
018633     15  LCOMM-POL-ID             PIC X(10).
      *
016108 COPY CCWL0985.
020478 COPY CCWL2626.
016108*
023436 COPY CCWL4780.
023436*
       COPY CCWL5600.
      *
       COPY CCWL2430.
      *
       COPY CCWL2435.
557668 COPY CCWL0620.
557788 COPY CCWL2480.
020478 COPY CCWL2625.
      *
557756*COPY CCWTYSNO.
      *
       COPY CCWWINDX.
030054 COPY XCWWCNST.
      *
       COPY XCWEBLCH.
      *
       COPY XCWL0280.
020874 COPY XCWL0290.
      *
       COPY XCWL1640.
023435 COPY XCWL1660.
023435 COPY XCWL1670.
023435 COPY XCWL1680.
      *
557756*COPY XCWL2510.
      *
013578 COPY XCWL8090.
      *
       COPY XCWLDTLK.
      *
       COPY CCWL5052.
      *
       COPY CCWL5061.
       COPY CCWL5063.
       COPY CCWL5065.
      *
       COPY XCWWWKDT.
      *
       COPY CCFWPOL.
      *
       COPY CCFWPOLC.
       COPY CCFRPOLC.
      *
023435 COPY CCFRPHST.
023435 COPY CCFWPHST.
023435*
       COPY CCFWRL.
       COPY CCFRRL.
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
       COPY CCFRPOL.
023436 COPY CCFWCVG.
023436 COPY CCFRCVG.
       COPY CCWWCVGS.
      *
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM5060.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM ABND-1000-HANDLE-ABEND
026070*       THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM INIT-1000-INITIALIZE
              THRU INIT-1000-INITIALIZE-X.

018633     PERFORM  COMM-1000-INITIALIZE
018633         THRU COMM-1000-INITIALIZE-X.
018633
           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X.

020478     PERFORM  FCCK-1000-CHECK-CLIENT
020478         THRU FCCK-1000-CHECK-CLIENT-X.
020478
           PERFORM EXIT-1000-FINALIZE
              THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      ***************************
       2000-PROCESS-REQUEST.
      ***************************
020874     PERFORM  0290-1000-BUILD-PARM-INFO
020874         THRU 0290-1000-BUILD-PARM-INFO-X.
           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

013578     IF MIR-DV-PRCES-STATE-CD = '2'
013578     OR MIR-DV-PRCES-STATE-CD = '3'
015904*        MOVE 'S'               TO MIR-DV-CHNG-SET-CD
015904         MOVE 'S'               TO WS-CHNG-SET-CD
013578     ELSE
015904*        MOVE 'B'               TO MIR-DV-CHNG-SET-CD
015904         MOVE 'B'               TO WS-CHNG-SET-CD
013578     END-IF.

           PERFORM  9000-SETUP-MSIN-REFERENCE
               THRU 9000-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           PERFORM  9200-CHECK-KEY-FIELDS
               THRU 9200-CHECK-KEY-FIELDS-X.
           IF WGLOB-MSG-ERROR-SW > ZERO
               MOVE SPACES            TO MIR-POL-ID-BASE-G
               MOVE SPACES            TO MIR-POL-ID-SFX-G
               PERFORM  9700-BLANK-DATA-FIELDS
                   THRU 9700-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF WS-BUS-FCN-BILLCHG
           OR WS-BUS-FCN-MISCHG
               MOVE 'O'               TO WS-SCREEN-TYP-CD
           END-IF.

           IF WS-BUS-FCN-LBILCHG
               MOVE 'L'               TO WS-SCREEN-TYP-CD
           END-IF.
      *
      *    PROCESS SCREEN FUNCTIONS
      *
015904*    MOVE MIR-DV-CHNG-SET-CD    TO WS-CHNG-SET-CD.

014221     MOVE ZEROS                 TO WLOCK-IDX.
014221     INITIALIZE                 WLOCK-MULT-TWRK-TS-TABLE.

           IF WS-CHNG-SET-CD-VALID
               PERFORM  3000-PROCESS-CHANGE-SCREENS
                   THRU 3000-PROCESS-CHANGE-SCREENS-X
           END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *****************************
       3000-PROCESS-CHANGE-SCREENS.
      *****************************

           EVALUATE TRUE
             WHEN WS-CHNG-SET-BROWSE
               PERFORM  4000-PROCESS-LIST
                   THRU 4000-PROCESS-LIST-X

             WHEN OTHER
014221             SET WS-NO-LOCK-ERROR        TO TRUE
                   PERFORM  6000-PROCESS-CHANGE
                       THRU 6000-PROCESS-CHANGE-X
           END-EVALUATE.

       3000-PROCESS-CHANGE-SCREENS-X.
           EXIT.
      *
      *********************
       4000-PROCESS-LIST.
      *********************

           MOVE SPACES                TO MIR-POL-ID-BASE-G
                                         MIR-POL-ID-SFX-G.

           MOVE LOW-VALUES            TO WRL-KEY.
           MOVE MIR-CLI-ID            TO WRL-CLI-ID.
016440     MOVE WGLOB-SYS-CTL-ID      TO WRL-REL-SYS-ID.

           MOVE HIGH-VALUES           TO WRL-ENDBR-KEY.
           MOVE MIR-CLI-ID            TO WRL-ENDBR-CLI-ID.
016440     MOVE WGLOB-SYS-CTL-ID      TO WRL-ENDBR-REL-SYS-ID.


018633*    PERFORM  9400-RETRIEVE-TWRK
018633*        THRU 9400-RETRIEVE-TWRK-X.
018633     PERFORM  COMM-1000-RETRIEVE-TWRK
018633         THRU COMM-1000-RETRIEVE-TWRK-X.
013578
018633*    IF  L8090-RETRN-OK
018633     IF  LCOMM-RETRN-OK
018633*        MOVE L8090-AREA-INFO-TEXT  TO WS-TWRK-AREA
018633*        PERFORM  9600-DELETE-TWRK
018633*            THRU 9600-DELETE-TWRK-X
018633         PERFORM  COMM-3000-DELETE-TWRK
018633             THRU COMM-3000-DELETE-TWRK-X
018633*        MOVE WS-TWRK-SYS-ID    TO WRL-REL-SYS-ID
018633*        MOVE WS-TWRK-POL-ID    TO WRL-REL-SYS-REF-POL-ID
018633         MOVE LCOMM-SYS-ID      TO WRL-REL-SYS-ID
018633         MOVE LCOMM-POL-ID      TO WRL-REL-SYS-REF-POL-ID
013578     ELSE
018633*        INITIALIZE WS-TWRK-AREA
018633         INITIALIZE LCOMM-WORK-AREA
013578     END-IF.

           PERFORM  4100-FORWARD-BROWSE
               THRU 4100-FORWARD-BROWSE-X.

       4000-PROCESS-LIST-X.
           EXIT.
      *
      *********************
       4100-FORWARD-BROWSE.
      *********************

           PERFORM  RL-1000-BROWSE
               THRU RL-1000-BROWSE-X.

           IF NOT WRL-IO-OK
      * MSG - NO RELATIONSHIPS FOUND FOR THIS CLIENT
               MOVE 'CS50600001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4100-FORWARD-BROWSE-X
               END-IF.

           PERFORM  RL-2000-READ-NEXT
               THRU RL-2000-READ-NEXT-X.

           IF NOT WRL-IO-OK
               PERFORM  RL-3000-END-BROWSE
                   THRU RL-3000-END-BROWSE-X
      * MSG - NO RELATIONSHIPS FOUND FOR THIS CLIENT
               MOVE 'CS50600001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4100-FORWARD-BROWSE-X
               END-IF.

           MOVE 1                     TO WS-SUB.
           SET WS-RL-NOT-FOUND TO TRUE.

           PERFORM  5000-POLICY-LOOP
               THRU 5000-POLICY-LOOP-X
               UNTIL WS-SUB > 100
                  OR WRL-IO-EOF.

           IF WRL-IO-EOF
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  4300-BROWSE-CHECK
                   THRU 4300-BROWSE-CHECK-X
           END-IF.

           IF WS-RL-NOT-FOUND
               IF WS-BUS-FCN-LBILCHG
      * MSG - NO LISTBILL RELATIONSHIPS FOUND FOR THIS CLIENT
                   MOVE 'CS50600002'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      * MSG - NO OWNER RELATIONSHIPS FOUND FOR THIS CLIENT
                   MOVE 'CS50600003'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           PERFORM  RL-3000-END-BROWSE
               THRU RL-3000-END-BROWSE-X.

014221     PERFORM  POL-2000-BUILD-MNTS-TWRK
014221         THRU POL-2000-BUILD-MNTS-TWRK-X.

       4100-FORWARD-BROWSE-X.
           EXIT.
      *
      *******************
       4300-BROWSE-CHECK.
      *******************

018633*    MOVE RRL-REL-SYS-ID          TO WS-TWRK-SYS-ID.
018633*    MOVE RRL-REL-SYS-REF-POL-ID  TO WS-TWRK-POL-ID.
018633     MOVE RRL-REL-SYS-ID          TO LCOMM-SYS-ID.
018633     MOVE RRL-REL-SYS-REF-POL-ID  TO LCOMM-POL-ID.

           MOVE 'N'                     TO WS-RL-CHECK-SW.

           PERFORM  4400-RL-CHECK-LOOP
               THRU 4400-RL-CHECK-LOOP-X
               UNTIL WRL-IO-EOF
                  OR WS-RL-POL-FOUND.

           IF WS-RL-POL-FOUND
018633*        PERFORM  9500-WRITE-TWRK
018633*            THRU 9500-WRITE-TWRK-X
018633         PERFORM  COMM-2000-WRITE-TWRK
018633             THRU COMM-2000-WRITE-TWRK-X
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4300-BROWSE-CHECK-X.
           EXIT.
      *
      ********************
       4400-RL-CHECK-LOOP.
      ********************

           IF WS-SCREEN-TYP-CD NOT = RRL-REL-TYP-CD
016440*    OR (RRL-REL-SYS-ID NOT = 'ADMIN'
016440*    AND RRL-REL-SYS-ID NOT = 'NEWBUS')
016440     OR NOT RRL-REL-SYS-ID  = WGLOB-SYS-CTL-ID
               PERFORM  5100-READ-RL-RECORD
                   THRU 5100-READ-RL-RECORD-X
               GO TO 4400-RL-CHECK-LOOP-X
           END-IF.

           MOVE RRL-REL-SYS-REF-POL-ID  TO WPOL-POL-ID.
           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF NOT WPOL-IO-OK
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
012011         PERFORM  5100-READ-RL-RECORD
012011             THRU 5100-READ-RL-RECORD-X
               GO TO 4400-RL-CHECK-LOOP-X
           END-IF.

020478     PERFORM  2625-0000-INIT-PARM-INFO
020478         THRU 2625-0000-INIT-PARM-INFO-X.
020478     PERFORM  2625-1000-BILL-CHNG-RETRIEVE
020478         THRU 2625-1000-BILL-CHNG-RETRIEVE-X.
           IF RPOL-POL-STAT-TERMINATED
           OR RPOL-POL-SUSPENDED
           OR RPOL-POL-STAT-REJECTED
               PERFORM  5100-READ-RL-RECORD
                   THRU 5100-READ-RL-RECORD-X
               GO TO 4400-RL-CHECK-LOOP-X
           END-IF.

           SET WS-RL-POL-FOUND           TO TRUE.

       4400-RL-CHECK-LOOP-X.
           EXIT.
      *
      ******************
       5000-POLICY-LOOP.
      ******************

           IF WS-SCREEN-TYP-CD NOT = RRL-REL-TYP-CD
016440*    OR (RRL-REL-SYS-ID NOT = 'ADMIN'
016440*    AND RRL-REL-SYS-ID NOT = 'NEWBUS')
016440     OR  NOT RRL-REL-SYS-ID = WGLOB-SYS-CTL-ID
               PERFORM  5100-READ-RL-RECORD
                   THRU 5100-READ-RL-RECORD-X
               GO TO 5000-POLICY-LOOP-X
           END-IF.

010904*    IF CURRENT RELATION TYPE IS "OWNER" CHECK CLI-REL-SUB-CODE.
010904*    IF CLI-REL-SUB-CODE IS = 'C-CONTINGENT" IGNORE THIS
010904*    RELATIONSHIP RECORD.
010904*
010904     IF  RRL-REL-TYP-OWNER
010904         MOVE RRL-CLI-ID        TO WPOLC-CLI-ID
010904         MOVE RRL-REL-SYS-REF-POL-ID
                                      TO WPOLC-POL-ID
010904         MOVE RRL-REL-TYP-CD    TO WPOLC-POL-CLI-REL-TYP-CD
010904
010904         PERFORM  POLC-1000-READ
010904             THRU POLC-1000-READ-X
010904
010904         IF  NOT WPOLC-IO-OK
010904             MOVE WPOLC-KEY     TO WGLOB-MSG-PARM(1)
010904             MOVE 'XS00000001'  TO WGLOB-MSG-REF-INFO
010904             PERFORM  0260-1000-GENERATE-MESSAGE
010904                 THRU 0260-1000-GENERATE-MESSAGE-X
010904             PERFORM  5100-READ-RL-RECORD
010904                 THRU 5100-READ-RL-RECORD-X
010904             GO TO 5000-POLICY-LOOP-X
010904         END-IF
010904
010904         IF  RPOLC-POL-CLI-REL-SUB-CD = 'C'
010904             PERFORM  5100-READ-RL-RECORD
010904                 THRU 5100-READ-RL-RECORD-X
010904             GO TO 5000-POLICY-LOOP-X
010904         END-IF
010904     END-IF.

           MOVE RRL-REL-SYS-REF-POL-ID  TO WPOL-POL-ID.
014221*    PERFORM  POL-1000-READ
014221*        THRU POL-1000-READ-X.

014221     PERFORM  POL-1000-READ-MNTS-TS
014221         THRU POL-1000-READ-MNTS-TS-X.

           IF NOT WPOL-IO-OK
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  5100-READ-RL-RECORD
                   THRU 5100-READ-RL-RECORD-X
               GO TO 5000-POLICY-LOOP-X
           END-IF.
020478     PERFORM  2625-0000-INIT-PARM-INFO
020478         THRU 2625-0000-INIT-PARM-INFO-X.
020478     PERFORM  2625-1000-BILL-CHNG-RETRIEVE
020478         THRU 2625-1000-BILL-CHNG-RETRIEVE-X.

           IF RPOL-POL-STAT-TERMINATED
           OR RPOL-POL-SUSPENDED
           OR RPOL-POL-STAT-REJECTED
               PERFORM  5100-READ-RL-RECORD
                   THRU 5100-READ-RL-RECORD-X
               GO TO 5000-POLICY-LOOP-X
           END-IF.

           SET  WS-RL-FOUND      TO TRUE.

           PERFORM  8000-LOAD-SCREEN
               THRU 8000-LOAD-SCREEN-X.

           PERFORM  5100-READ-RL-RECORD
               THRU 5100-READ-RL-RECORD-X.

       5000-POLICY-LOOP-X.
           EXIT.
      *
      *********************
       5100-READ-RL-RECORD.
      *********************

           PERFORM  RL-2000-READ-NEXT
               THRU RL-2000-READ-NEXT-X.

       5100-READ-RL-RECORD-X.
           EXIT.
      *
      *********************
       6000-PROCESS-CHANGE.
      *********************

018763*    IF MIR-DV-PRCES-STATE-CD ='3'
018763     IF MIR-DV-PRCES-STATE-CD = '3'
               PERFORM  6400-PROCESS-VERIFY-PASS
                   THRU 6400-PROCESS-VERIFY-PASS-X
           ELSE
018763*        IF MIR-DV-PRCES-STATE-CD ='2'
018763         IF MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM  6200-PROCESS-CHANGE-2ND-PASS
                       THRU 6200-PROCESS-CHANGE-2ND-PASS-X
               END-IF
           END-IF.

           MOVE 1                     TO WS-SUB.
014221     MOVE ZEROS                 TO WLOCK-IDX.
014221     INITIALIZE                 WLOCK-MULT-TWRK-TS-TABLE.

           PERFORM  6250-REDISPLAY-POLICY-INFO
               THRU 6250-REDISPLAY-POLICY-INFO-X
               UNTIL WS-SUB > 100
                  OR MIR-POL-ID-BASE-T (WS-SUB) = SPACES.

014221     PERFORM  POL-2000-BUILD-MNTS-TWRK
014221         THRU POL-2000-BUILD-MNTS-TWRK-X.

       6000-PROCESS-CHANGE-X.
           EXIT.
      *
      ******************************
       6200-PROCESS-CHANGE-2ND-PASS.
      ******************************

           PERFORM  6300-BASIC-EDIT-CHNG-FIELDS
               THRU 6300-BASIC-EDIT-CHNG-FIELDS-X.

           IF WGLOB-MSG-ERROR-SW > 0
           OR WGLOB-RETURN-CODE > 0
               GO TO 6200-PROCESS-CHANGE-2ND-PASS-X
           END-IF.


           IF WS-CHNG-SET-SELCT
      * MSG - ONLY POLICIES SELECTED WILL BE UPDATED, PLEASE VERIFY
               MOVE 'CS50600007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       6200-PROCESS-CHANGE-2ND-PASS-X.
           EXIT.
      *
      ****************************
       6250-REDISPLAY-POLICY-INFO.
      ****************************

           MOVE MIR-POL-ID-BASE-T(WS-SUB) TO WPOL-POL-ID(1:9).
           MOVE MIR-POL-ID-SFX-T (WS-SUB) TO WPOL-POL-ID(10:1).

014221*    PERFORM  POL-1000-READ
014221*        THRU POL-1000-READ-X.

014221     PERFORM  POL-1000-READ-MNTS-TS
014221         THRU POL-1000-READ-MNTS-TS-X.

           IF NOT WPOL-IO-OK
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6250-REDISPLAY-POLICY-INFO-X
           END-IF.

020478     PERFORM  2625-0000-INIT-PARM-INFO
020478         THRU 2625-0000-INIT-PARM-INFO-X.
020478     PERFORM  2625-1000-BILL-CHNG-RETRIEVE
020478         THRU 2625-1000-BILL-CHNG-RETRIEVE-X.
           PERFORM  8000-LOAD-SCREEN
               THRU 8000-LOAD-SCREEN-X.

       6250-REDISPLAY-POLICY-INFO-X.
           EXIT.
      *
      *******************************
       6300-BASIC-EDIT-CHNG-FIELDS.
      *******************************

023435     PERFORM  6320-CHK-BILL-CHNG-FIELDS
023435         THRU 6320-CHK-BILL-CHNG-FIELDS-X.
023435
023435     PERFORM  6330-CHK-DIV-CHNG-FIELDS
023435         THRU 6330-CHK-DIV-CHNG-FIELDS-X.
023435
013578     MOVE ZEROES                TO WS-SUB2
013578     PERFORM
013578       VARYING WS-SUB FROM 1 BY 1
024244       UNTIL WS-SUB > 100
013578*       UNTIL MIR-DV-SELCT-CD-T (WS-SUB) = SPACES
013578*       OR WS-SUB > 100
013578         IF MIR-DV-SELCT-CD-T (WS-SUB) = 'Y'
013578             ADD +1 TO WS-SUB2
023435             PERFORM  7400-EDIT-OFF-ANNV
023435                 THRU 7400-EDIT-OFF-ANNV-X
013578         END-IF
013578     END-PERFORM.

           IF  WS-SUB2 = ZEROES
      * MSG - POLICIES MUST BE SELECTED BY CODING ANY
      *       LETTER BESIDE POLICY
               MOVE 'CS50600008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
013578         GO TO 6300-BASIC-EDIT-CHNG-FIELDS-X
           END-IF.

           EVALUATE TRUE
              WHEN WS-BUS-FCN-BILLCHG
                   PERFORM 6310-EDIT-BILL-OWNER-FIELDS
                      THRU 6310-EDIT-BILL-OWNER-FIELDS-X

              WHEN WS-BUS-FCN-MISCHG
                   PERFORM 6340-EDIT-MISC-OWNER-FIELDS
                      THRU 6340-EDIT-MISC-OWNER-FIELDS-X

              WHEN WS-BUS-FCN-LBILCHG
                   PERFORM 6360-EDIT-LISTBILL-FIELDS
                      THRU 6360-EDIT-LISTBILL-FIELDS-X

           END-EVALUATE.

       6300-BASIC-EDIT-CHNG-FIELDS-X.
           EXIT.
      *
      *****************************
       6310-EDIT-BILL-OWNER-FIELDS.
      *****************************

           IF  MIR-POL-BILL-TYP-CD = SPACES
           AND MIR-POL-BILL-MODE-CD   = SPACES
017356*    AND MIR-POL-PAC-DRW-DY = ZEROES
019859     AND MIR-POL-PMT-DRW-DY = SPACES
           AND MIR-BILL-LEAD-TIME-DUR  = SPACES
           AND MIR-POL-CLI-REL-TYP-CD = SPACES
013578***  AND MIR-CLI-ID = SPACES
019859     AND MIR-DV-CLI-ID = SPACES
           AND MIR-POL-CLI-REL-SUB-CD = SPACES
           AND MIR-POL-RBILL-CD  = SPACES
           AND MIR-RBILL-DEPT-ID   = SPACES
           AND MIR-RBILL-MISC-1-CD  = SPACES
           AND MIR-RBILL-MISC-2-CD  = SPACES
           AND MIR-RBILL-EFF-DT = SPACES
           AND MIR-RBILL-END-DT = SPACES
      * MSG -  'NO DATA ENTERED ON CHANGE LINE'
              MOVE 'CS50600009'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF MIR-POL-BILL-MODE-CD > SPACES
027177     AND MIR-POL-BILL-MODE-CD NOT = EBLCH-BLANK-FIELD-CHAR
               SET L0280-SIGN-NOT-PERMITTED TO TRUE
               MOVE 0                 TO L0280-PRECISION
               MOVE 2                 TO L0280-LENGTH
               MOVE 2                 TO L0280-INPUT-SIZE
               MOVE MIR-POL-BILL-MODE-CD
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT  TO WS-PIC-99
                   MOVE WS-PIC-99     TO MIR-POL-BILL-MODE-CD
               ELSE
      * MSG -  'BILL MODE MUST BE VALID NUMERIC'
                   MOVE 'CS50600010'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

016395*    IF MIR-POL-PAC-DRW-DY > SPACES
016395     IF MIR-POL-PMT-DRW-DY > SPACES
               MOVE 'N'               TO L0280-SIGN-IND
               MOVE 0                 TO L0280-PRECISION
               MOVE 2                 TO L0280-LENGTH
               MOVE 2                 TO L0280-INPUT-SIZE
016395*        MOVE MIR-POL-PAC-DRW-DY               TO L0280-INPUT-DATA
016395         MOVE MIR-POL-PMT-DRW-DY               TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
027177         AND L0280-OUTPUT >= ZERO
027177         AND L0280-OUTPUT <= 31
020874*            MOVE L0280-OUTPUT  TO WS-PIC-99
016395*            MOVE WS-PIC-99     TO MIR-POL-PAC-DRW-DY
020874*            MOVE WS-PIC-99     TO MIR-POL-PMT-DRW-DY
020874             MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874             MOVE 0                     TO L0290-PRECISION
020874             MOVE LENGTH OF MIR-POL-PMT-DRW-DY
020874                                        TO L0290-MAX-OUT-LEN
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
020874             MOVE L0290-OUTPUT-DATA     TO MIR-POL-PMT-DRW-DY
               ELSE
      * MSG -  'PAC DRAW DAY MUST BE VALID NUMERIC'
                   MOVE 'CS50600011'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF MIR-BILL-LEAD-TIME-DUR > SPACES
               MOVE 'Y'               TO L0280-SIGN-IND
               MOVE 0                 TO L0280-PRECISION
               MOVE 2                 TO L0280-LENGTH
               MOVE 3                 TO L0280-INPUT-SIZE
               MOVE MIR-BILL-LEAD-TIME-DUR
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT  TO WS-PIC-S99
                   MOVE WS-PIC-S99    TO MIR-BILL-LEAD-TIME-DUR
               ELSE
      * MSG -  'BILLING LEAD TIME MUST BE VALID NUMERIC'
                   MOVE 'CS50600012'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF  MIR-RBILL-EFF-DT > SPACES
           AND MIR-RBILL-EFF-DT NOT = EBLCH-BLANK-FIELD-CHAR
               MOVE MIR-RBILL-EFF-DT  TO L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X
               IF L1640-NOT-VALID
      * MSG -  'RESTRICT BILL EFFECTIVE DATE INVALID'
                   MOVE 'CS50600015'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF  MIR-RBILL-END-DT > SPACES
           AND MIR-RBILL-END-DT NOT = EBLCH-BLANK-FIELD-CHAR
               MOVE MIR-RBILL-END-DT  TO L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X
               IF L1640-NOT-VALID
      * MSG -  'RESTRICT BILL END DATE INVALID'
                   MOVE 'CS50600016'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       6310-EDIT-BILL-OWNER-FIELDS-X.
           EXIT.
023435/
023435*--------------------------
023435 6320-CHK-BILL-CHNG-FIELDS.
023435*--------------------------
023435
023435     SET WS-BILL-CHNG-NO        TO TRUE.
023435
023435     IF  MIR-POL-BILL-TYP-CD    NOT = SPACES
023435     OR  MIR-POL-BILL-MODE-CD   NOT = SPACES
023435     OR  MIR-POL-PMT-DRW-DY     NOT = SPACES
023435
023435         EVALUATE TRUE
023435
023435             WHEN  WS-BUS-FCN-BILLCHG
023435
027177                   PERFORM  6321-CHK-BASIC-BILL-INFO
027177                       THRU 6321-CHK-BASIC-BILL-INFO-X
027177
023435                   IF (MIR-BILL-LEAD-TIME-DUR NOT = SPACES
023435                       AND MIR-BILL-LEAD-TIME-DUR
023435                                 NOT = EBLCH-BLANK-FIELD-CHAR)
023435                   OR (MIR-POL-CLI-REL-TYP-CD NOT = SPACES
023435                       AND MIR-POL-CLI-REL-TYP-CD
023435                                 NOT = EBLCH-BLANK-FIELD-CHAR)
023435                   OR (MIR-DV-CLI-ID          NOT = SPACES
023435                       AND MIR-DV-CLI-ID
023435                                 NOT = EBLCH-BLANK-FIELD-CHAR)
023435                   OR (MIR-POL-CLI-REL-SUB-CD NOT = SPACES
023435                       AND MIR-POL-CLI-REL-SUB-CD
023435                                 NOT = EBLCH-BLANK-FIELD-CHAR)
023435                   OR (MIR-POL-RBILL-CD       NOT = SPACES
023435                       AND MIR-POL-RBILL-CD
023435                                 NOT = EBLCH-BLANK-FIELD-CHAR)
023435                   OR (MIR-RBILL-DEPT-ID      NOT = SPACES
023435                       AND MIR-RBILL-DEPT-ID
023435                                 NOT = EBLCH-BLANK-FIELD-CHAR)
023435                   OR (MIR-RBILL-MISC-1-CD    NOT = SPACES
023435                       AND MIR-RBILL-MISC-1-CD
023435                                 NOT = EBLCH-BLANK-FIELD-CHAR)
023435                   OR (MIR-RBILL-MISC-2-CD    NOT = SPACES
023435                       AND MIR-RBILL-MISC-2-CD
023435                                 NOT = EBLCH-BLANK-FIELD-CHAR)
023435                   OR (MIR-RBILL-EFF-DT       NOT = SPACES
023435                       AND MIR-RBILL-EFF-DT
023435                                 NOT = EBLCH-BLANK-FIELD-CHAR)
023435                   OR (MIR-RBILL-END-DT       NOT = SPACES
023435                       AND MIR-RBILL-END-DT
023435                                 NOT = EBLCH-BLANK-FIELD-CHAR)
027177                       IF  NOT WS-BILL-CHNG
027177                           CONTINUE
027177                       ELSE
023435*MSG: ONLY BILLING INFO CAN BE MODIFIED ON THE PROCESS DATE
023435                           MOVE 'CS50600045'
023435                                            TO WGLOB-MSG-REF-INFO
023435                           PERFORM  0260-1000-GENERATE-MESSAGE
023435                               THRU 0260-1000-GENERATE-MESSAGE-X
023435                           MOVE '1'         TO WGLOB-RETURN-CODE
027177                       END-IF
023435                   ELSE
023435                       SET WS-BILL-CHNG TO TRUE
023435                   END-IF
023435
023435             WHEN  WS-BUS-FCN-LBILCHG
023435
023435                   IF (MIR-BILL-LEAD-TIME-DUR NOT = SPACES
023435                       AND MIR-BILL-LEAD-TIME-DUR
023435                                 NOT = EBLCH-BLANK-FIELD-CHAR)
023435*MSG: ONLY BILLING INFO CAN BE MODIFIED ON THE PROCESS DATE
023435                       MOVE 'CS50600045'
023435                                            TO WGLOB-MSG-REF-INFO
023435                       PERFORM  0260-1000-GENERATE-MESSAGE
023435                           THRU 0260-1000-GENERATE-MESSAGE-X
023435                       MOVE '1'             TO WGLOB-RETURN-CODE
023435                   ELSE
023435                       SET WS-BILL-CHNG TO TRUE
023435                   END-IF
023435
023435         END-EVALUATE
023435
023435     END-IF.
023435
023435 6320-CHK-BILL-CHNG-FIELDS-X.
023435     EXIT.
023435/
027177*-------------------------
027177 6321-CHK-BASIC-BILL-INFO.
027177*-------------------------
027177
027177     IF  MIR-POL-BILL-MODE-CD > SPACES
027177     AND MIR-POL-BILL-MODE-CD NOT = EBLCH-BLANK-FIELD-CHAR
027177         SET WS-BILL-CHNG TO TRUE
027177     END-IF.
027177
027177     IF  MIR-POL-PMT-DRW-DY > SPACES
027177     AND MIR-POL-PMT-DRW-DY NOT = EBLCH-BLANK-FIELD-CHAR
027177         SET WS-BILL-CHNG TO TRUE
027177     END-IF.
027177
027177     IF  MIR-POL-BILL-TYP-CD     = RPOL-POL-BILL-TYP-CD
027177     AND MIR-POL-BILL-TYP-CD NOT = EBLCH-BLANK-FIELD-CHAR
027177         SET WS-BILL-CHNG TO TRUE
027177     END-IF.
027177
027177 6321-CHK-BASIC-BILL-INFO-X.
027177     EXIT.

023435*-------------------------
023435 6330-CHK-DIV-CHNG-FIELDS.
023435*-------------------------
023435
023435     SET WS-DIV-CHNG-NO         TO TRUE.
023435
023435     IF  NOT WS-BUS-FCN-MISCHG
023435         GO TO 6330-CHK-DIV-CHNG-FIELDS-X
023435     END-IF.
023435
023435     IF (MIR-POL-DIV-OPT-CD     NOT = SPACES
023435     AND MIR-POL-DIV-OPT-CD     NOT = EBLCH-BLANK-FIELD-CHAR)
023435     OR (MIR-POL-CLI-REL-TYP-CD NOT = SPACES
023435     AND MIR-POL-CLI-REL-TYP-CD NOT = EBLCH-BLANK-FIELD-CHAR)
023435         SET WS-DIV-CHNG        TO TRUE
023435     END-IF.
023435
023435 6330-CHK-DIV-CHNG-FIELDS-X.
023435     EXIT.
      *
      *****************************
       6340-EDIT-MISC-OWNER-FIELDS.
      *****************************

           IF  MIR-SERV-AGT-ID  = SPACES
           AND MIR-POL-NFO-CD = SPACES
           AND MIR-POL-DIV-OPT-CD = SPACES
023436     AND MIR-POL-DIV-XCES-CD = SPACES
013578***  AND MIR-CLI-ID = SPACES
019859     AND MIR-DV-CLI-ID = SPACES
           AND MIR-CLI-ADDR-TYP-CD = SPACES
           AND MIR-POL-CLI-REL-SUB-CD = SPACES
      *MSG NO DATA ENTERED ON CHANGE LINE
               MOVE 'CS50600009'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF MIR-POL-NFO-CD > SPACES
               MOVE 'N'               TO L0280-SIGN-IND
               MOVE 0                 TO L0280-PRECISION
               MOVE 1                 TO L0280-LENGTH
               MOVE 1                 TO L0280-INPUT-SIZE
               MOVE MIR-POL-NFO-CD    TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT  TO WS-PIC-9
                   MOVE WS-PIC-9      TO MIR-POL-NFO-CD
               ELSE
      * MSG -  'NON FORFEITURE OPTION MUST BE VALID NUMERIC'
                   MOVE 'CS50600043'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       6340-EDIT-MISC-OWNER-FIELDS-X.
           EXIT.
      *
      ***************************
       6360-EDIT-LISTBILL-FIELDS.
      ***************************

           IF  MIR-POL-BILL-TYP-CD  = SPACES
           AND MIR-POL-BILL-MODE-CD    = SPACES
016395*    AND MIR-POL-PAC-DRW-DY  = SPACES
016395     AND MIR-POL-PMT-DRW-DY  = SPACES
           AND MIR-BILL-LEAD-TIME-DUR   = SPACES
      *MSG    NO DATA ENTERED ON CHANGE LINE
               MOVE 'CS50600009'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6360-EDIT-LISTBILL-FIELDS-X
           END-IF.

           IF MIR-POL-BILL-MODE-CD > SPACES
               MOVE 'N'               TO L0280-SIGN-IND
               MOVE 0                 TO L0280-PRECISION
               MOVE 2                 TO L0280-LENGTH
               MOVE 2                 TO L0280-INPUT-SIZE
               MOVE MIR-POL-BILL-MODE-CD
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT  TO WS-PIC-99
                   MOVE WS-PIC-99     TO MIR-POL-BILL-MODE-CD
               ELSE
      * MSG -  'BILL MODE MUST BE VALID NUMERIC'
                   MOVE 'CS50600010'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

016395*    IF MIR-POL-PAC-DRW-DY > SPACES
016395     IF MIR-POL-PMT-DRW-DY > SPACES
               SET L0280-SIGN-NOT-PERMITTED TO TRUE
               MOVE 0                 TO L0280-PRECISION
               MOVE 2                 TO L0280-LENGTH
               MOVE 2                 TO L0280-INPUT-SIZE
016395*        MOVE MIR-POL-PAC-DRW-DY               TO L0280-INPUT-DATA
016395         MOVE MIR-POL-PMT-DRW-DY               TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
027177         AND L0280-OUTPUT >= ZERO
027177         AND L0280-OUTPUT <= 31
020874*            MOVE L0280-OUTPUT  TO WS-PIC-99
016395*            MOVE WS-PIC-99     TO MIR-POL-PAC-DRW-DY
020874*            MOVE WS-PIC-99     TO MIR-POL-PMT-DRW-DY
020874             MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874             MOVE 0                     TO L0290-PRECISION
020874             MOVE LENGTH OF MIR-POL-PMT-DRW-DY
020874                                        TO L0290-MAX-OUT-LEN
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
020874             MOVE L0290-OUTPUT-DATA     TO MIR-POL-PMT-DRW-DY
               ELSE
      * MSG -  'PAC DRAW DAY MUST BE VALID NUMERIC'
                   MOVE 'CS50600011'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF MIR-BILL-LEAD-TIME-DUR > SPACES
               SET L0280-SIGN-PERMITTED    TO TRUE
               MOVE 0                 TO L0280-PRECISION
               MOVE 2                 TO L0280-LENGTH
               MOVE 3                 TO L0280-INPUT-SIZE
               MOVE MIR-BILL-LEAD-TIME-DUR
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT  TO WS-PIC-S99
                   MOVE WS-PIC-S99    TO MIR-BILL-LEAD-TIME-DUR
               ELSE
      * MSG -  'BILLING LEAD TIME MUST BE VALID NUMERIC'
                   MOVE 'CS50600012'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       6360-EDIT-LISTBILL-FIELDS-X.
           EXIT.
      *
      **************************
       6400-PROCESS-VERIFY-PASS.
      **************************

014221     PERFORM  POL-3000-SET-MNTS-TWRK-TS
014221         THRU POL-3000-SET-MNTS-TWRK-TS-X.

           EVALUATE TRUE

              WHEN WS-BUS-FCN-BILLCHG
                 PERFORM 7100-BILLING-OWNER-CHG
                    THRU 7100-BILLING-OWNER-CHG-X

              WHEN WS-BUS-FCN-MISCHG
                 PERFORM 7200-MISC-OWNER-SCREEN
                    THRU 7200-MISC-OWNER-SCREEN-X

              WHEN WS-BUS-FCN-LBILCHG
                 PERFORM 7300-LISTBILL-SCREEN
                    THRU 7300-LISTBILL-SCREEN-X

           END-EVALUATE.

014221     PERFORM  6480-UPDATE-POL-TWTS
014221         THRU 6480-UPDATE-POL-TWTS-X
014221         VARYING WS-SUB3 FROM +1 BY +1
014221         UNTIL  WS-SUB3 > WLOCK-MAX-MULT-TS.

014221     PERFORM  POL-2000-BUILD-MNTS-TWRK
014221         THRU POL-2000-BUILD-MNTS-TWRK-X.

       6400-PROCESS-VERIFY-PASS-X.
           EXIT.
      *
014221******************
014221 6450-CHECK-POL-TS.
014221******************

014221     MOVE MIR-POL-ID-BASE-T (WS-SUB) TO  WS-POL-ID-BASE.
014221     MOVE MIR-POL-ID-SFX-T (WS-SUB)  TO  WS-POL-ID-SFX.

014221     MOVE WS-POL-ID         TO WPOL-POL-ID.
014221     MOVE WPOL-KEY          TO WLOCK-PRCES-TWRK-TS-KEY.

014221     IF  WPOL-COMPANY-REQUIRED
014221         MOVE WGLOB-COMPANY-CODE
014221                       TO WLOCK-PRCES-TWRK-TS-CO-ID
014221     ELSE
014221         MOVE SPACES   TO WLOCK-PRCES-TWRK-TS-CO-ID
014221     END-IF.
014221     MOVE WLOCK-MULT-TWRK-TS-KEY (WS-SUB)
014221                            TO  WLOCK-PRCES-TWRK-TS-KEY.

014221     PERFORM  POL-4000-UPDATE-MNTS-TW-TS
014221         THRU POL-4000-UPDATE-MNTS-TW-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221         MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221         MOVE 'POL'             TO WGLOB-MSG-PARM (01)
014221         MOVE WPOL-KEY          TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         SET  WS-LOGICAL-LOCK-ERROR     TO TRUE
014221         GO TO 6450-CHECK-POL-TS-X
014221     END-IF

014221     IF  WPOL-IO-OK
014221         PERFORM  POL-3000-UNLOCK
014221             THRU POL-3000-UNLOCK-X
014221     ELSE
014221         GO TO 6450-CHECK-POL-TS-X
014221     END-IF.

014221 6450-CHECK-POL-TS-X.
014221     EXIT.
      *
014221**********************
014221 6480-UPDATE-POL-TWTS.
014221*********************

014221     IF WLOCK-MULT-TWRK-TS-KEY (WS-SUB3) = SPACES
014221     OR WLOCK-MULT-TWRK-TS-KEY (WS-SUB3) = LOW-VALUES
014221        GO TO 6480-UPDATE-POL-TWTS-X
014221     END-IF.

014221     MOVE WLOCK-MULT-TWRK-TS-KEY (WS-SUB3) TO
014221          WPOL-POL-ID.

014221     PERFORM  POL-1000-READ
014221         THRU POL-1000-READ-X.

014221     IF WPOL-IO-OK
014221        MOVE RPOL-PREV-UPDT-TS    TO WLOCK-MULT-TWRK-TS (WS-SUB3)
014221     END-IF.
020478     PERFORM  2625-0000-INIT-PARM-INFO
020478         THRU 2625-0000-INIT-PARM-INFO-X.
020478     PERFORM  2625-1000-BILL-CHNG-RETRIEVE
020478         THRU 2625-1000-BILL-CHNG-RETRIEVE-X.

014221 6480-UPDATE-POL-TWTS-X.
014221     EXIT.
      *
      ************************
       7100-BILLING-OWNER-CHG.
      ************************

           PERFORM 5061-1000-BUILD-PARM-INFO
              THRU 5061-1000-BUILD-PARM-INFO-X.
           INITIALIZE L5061-MAX-ERR-IND

           MOVE MIR-CLI-ID            TO L5061-CLI-ID.
           MOVE MIR-POL-BILL-TYP-CD   TO L5061-BILL-TYP-CD.
           MOVE MIR-POL-BILL-MODE-CD  TO L5061-BILL-MODE-CD.
016395*    MOVE MIR-POL-PAC-DRW-DY    TO L5061-PAC-DRAW-DY-CD.
016395     MOVE MIR-POL-PMT-DRW-DY    TO L5061-PMT-DRAW-DY.
           MOVE MIR-BILL-LEAD-TIME-DUR      TO L5061-BILL-LEAD-TIME-DUR.
           MOVE MIR-POL-CLI-REL-TYP-CD      TO L5061-POL-CLI-REL-TYP-CD.
019859*    MOVE MIR-CLI-ID            TO L5061-REL-CLI-ID.
019859     MOVE MIR-DV-CLI-ID         TO L5061-REL-CLI-ID.
           MOVE MIR-POL-CLI-REL-SUB-CD                 TO L5061-BNK-NUM.
           MOVE MIR-POL-RBILL-CD      TO L5061-RBILL-CD.
           MOVE MIR-RBILL-DEPT-ID     TO L5061-RBILL-DEPT-ID.
557659*    MOVE MIR-RBILL-MISC-1-CD   TO L5061-MISC-RESTR-1-IND.
557659*    MOVE MIR-RBILL-MISC-2-CD   TO L5061-MISC-RESTR-2-IND.
557659     MOVE MIR-RBILL-MISC-1-CD   TO L5061-MISC-RESTR-1-CD.
557659     MOVE MIR-RBILL-MISC-2-CD   TO L5061-MISC-RESTR-2-CD.
           MOVE MIR-RBILL-EFF-DT      TO L5061-RBILL-EFF-DT-X.
           MOVE MIR-RBILL-END-DT      TO L5061-RBILL-END-DT-X.

           IF WS-CHNG-SET-SELCT
              SET L5061-CHNG-TYP-SELECTED TO TRUE
              PERFORM 7150-SETUP-5061-POLS
                 THRU 7150-SETUP-5061-POLS-X
           END-IF.

023435     MOVE WS-BILL-CHNG-SW       TO L5061-BILL-CHNG-SW.
023435
014221     IF  WS-LOGICAL-LOCK-ERROR
014221         GO TO 7100-BILLING-OWNER-CHG-X
014221     END-IF.

           PERFORM 5061-1000-CHANGE-POLS
              THRU 5061-1000-CHANGE-POLS-X.

           IF L5061-RETRN-ERROR
              SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.
      *
      * CHECK TO SEE IF THERE MORE MESSAGES THAN CAN BE DISPLAYED ON
      * THE SCREEN.  IF SO, SEND 'SEE MSGI' MESSAGE.
      *
           MOVE L5061-MAX-ERR-IND     TO WS-POL-ERROR-CTR.

           IF  L5061-MAX-ERR-IND > ZERO
               SET L5061-ERR-INDX    TO L5061-MAX-ERR-IND
               INITIALIZE L5061-MAX-ERR-IND
               PERFORM 7110-OWNER-ERR-MSG
                  THRU 7110-OWNER-ERR-MSG-X
                 UNTIL L5061-ERR-INDX = ZERO
           ELSE
      *MSG - ALL POLICIES SUCCESSFULLY PROCESSED  (CS50600032)
               MOVE 'CS50600032'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


       7100-BILLING-OWNER-CHG-X.
           EXIT.
      *
      ********************
       7110-OWNER-ERR-MSG.
      ********************

           PERFORM
           VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > 4
                OR L5061-ERR-INDX = ZERO

              MOVE L5061-ERR-POL-ID (L5061-ERR-INDX)
                                      TO WGLOB-MSG-PARM (WS-SUB)
               SET L5061-ERR-INDX DOWN BY 1

           END-PERFORM.

      * MSG - POLICIES @1, @2, @3, @4 FAILED   (CS50600034)
           MOVE 'CS50600034'          TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

       7110-OWNER-ERR-MSG-X.
           EXIT.
      *
      **********************
       7150-SETUP-5061-POLS.
      **********************

023435     PERFORM  6320-CHK-BILL-CHNG-FIELDS
023435         THRU 6320-CHK-BILL-CHNG-FIELDS-X.
023435
           SET L5061-INDEX TO 1.
           PERFORM
           VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > 100
             OR MIR-POL-ID-BASE-T (WS-SUB) NOT > SPACES

              IF MIR-DV-SELCT-CD-T (WS-SUB) = 'Y'
023435           PERFORM  7400-EDIT-OFF-ANNV
023435               THRU 7400-EDIT-OFF-ANNV-X
014221           PERFORM  6450-CHECK-POL-TS
014221               THRU 6450-CHECK-POL-TS-X
014221           IF  WS-LOGICAL-LOCK-ERROR
014221               GO TO 7150-SETUP-5061-POLS-X
014221           END-IF
023435           MOVE WS-POL-OFFANNV-PD-DT
023435                TO L5061-POL-OFFANNV-PD-DT (L5061-INDEX)
                 MOVE MIR-POL-ID-BASE-T (WS-SUB)
                                  TO L5061-POL-ID(L5061-INDEX)(1:9)
                 MOVE MIR-POL-ID-SFX-T (WS-SUB)
                                  TO L5061-POL-ID(L5061-INDEX)(10:1)
019859*          IF L5061-REL-CLI-ID = SPACES
019859*             MOVE MIR-CLI-ID-T (WS-SUB)
019859*                           TO L5061-REL-CLI-ID
019859*          END-IF
019859*          IF L5061-BILL-TYP-CD = SPACES
019859*             MOVE MIR-POL-BILL-TYP-CD-T (WS-SUB)
019859*                           TO L5061-BILL-TYP-CD
019859*          END-IF
019859*          IF L5061-BILL-MODE-CD = SPACES
019859*             MOVE MIR-POL-BILL-MODE-CD-T (WS-SUB)
019859*                           TO L5061-BILL-MODE-CD
019859*          END-IF
019859*          IF L5061-BILL-LEAD-TIME-DUR = SPACES
019859*             MOVE MIR-BILL-LEAD-TIME-DUR-T (WS-SUB)
019859*                           TO L5061-BILL-LEAD-TIME-DUR
019859*          END-IF
019859*          IF L5061-POL-CLI-REL-TYP-CD = SPACES
019859*             MOVE MIR-POL-CLI-REL-TYP-CD-T (WS-SUB)
019859*                           TO L5061-POL-CLI-REL-TYP-CD
019859*          END-IF
019859*          IF L5061-BNK-NUM = SPACES
019859*             MOVE MIR-POL-CLI-REL-SUB-CD-T (WS-SUB)
019859*                           TO L5061-BNK-NUM
019859*          END-IF
019859*          IF L5061-RBILL-CD = SPACES
019859*             MOVE MIR-POL-RBILL-CD-T (WS-SUB)
019859*                           TO L5061-RBILL-CD
019859*          END-IF
019859*          IF L5061-RBILL-DEPT-ID = SPACES
019859*             MOVE MIR-RBILL-DEPT-ID-T (WS-SUB)
019859*                           TO L5061-RBILL-DEPT-ID
019859*          END-IF
019859*          IF L5061-MISC-RESTR-1-CD = SPACES
019859*             MOVE MIR-RBILL-MISC-1-CD-T (WS-SUB)
019859*                           TO L5061-MISC-RESTR-1-CD
019859*          END-IF
019859*          IF L5061-MISC-RESTR-2-CD = SPACES
019859*             MOVE MIR-RBILL-MISC-2-CD-T (WS-SUB)
019859*                           TO L5061-MISC-RESTR-2-CD
019859*          END-IF
019859*          IF L5061-RBILL-EFF-DT-X = SPACES
019859*             MOVE MIR-RBILL-EFF-DT-T (WS-SUB)
019859*                           TO L5061-RBILL-EFF-DT-X
019859*          END-IF
019859*          IF L5061-RBILL-END-DT-X = SPACES
019859*             MOVE MIR-RBILL-END-DT-T (WS-SUB)
019859*                           TO L5061-RBILL-END-DT-X
019859*          END-IF
016395*          IF L5061-PAC-DRAW-DY-CD = SPACES
019859*          IF L5061-PMT-DRAW-DY    = SPACES
017356*          OR L5061-PAC-DRAW-DY-CD = ZEROES
016395*             MOVE MIR-POL-PAC-DRW-DY-T (WS-SUB)
019859*             MOVE MIR-POL-PMT-DRW-DY-T (WS-SUB)
016395*                           TO L5061-PAC-DRAW-DY-CD
019859*                           TO L5061-PMT-DRAW-DY
019859*          END-IF
                 SET L5061-INDEX UP BY 1
              END-IF

           END-PERFORM.

       7150-SETUP-5061-POLS-X.
           EXIT.
      *
      ************************
       7200-MISC-OWNER-SCREEN.
      ************************

           PERFORM 5063-1000-BUILD-PARM-INFO
              THRU 5063-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID            TO L5063-CLI-ID.
           MOVE MIR-SERV-AGT-ID       TO L5063-SERV-AG-ID.
           MOVE MIR-POL-NFO-CD        TO L5063-NFO-CD.
           MOVE MIR-POL-DIV-OPT-CD    TO L5063-DIV-OPT-CD.
023436     MOVE MIR-POL-DIV-XCES-CD   TO L5063-DIV-XCES-CD.
023436     MOVE WS-BUS-FCN-ID         TO L5063-CHG-FCN-ID.
023436     MOVE WS-PCHST-EFF-DT       TO L5063-EFF-DT.
019859*    MOVE MIR-CLI-ID            TO L5063-REL-CLI-ID.
019859     MOVE MIR-DV-CLI-ID         TO L5063-REL-CLI-ID.
           MOVE MIR-CLI-ADDR-TYP-CD   TO L5063-CLI-ADR-TYP-CD.
           MOVE MIR-POL-CLI-REL-SUB-CD  TO L5063-ASIGN-TYP-CD.

           IF WS-CHNG-SET-SELCT
              SET L5063-CHNG-TYP-SELECTED  TO TRUE
              PERFORM 7250-SETUP-5063-POLS
                 THRU 7250-SETUP-5063-POLS-X
           END-IF.

           PERFORM 5063-1000-CHANGE-POLS
              THRU 5063-1000-CHANGE-POLS-X.

           IF L5063-RETRN-ERROR
              SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

      *
      * CHECK TO SEE IF THERE MORE MESSAGES THAN CAN BE DISPLAYED ON
      * THE SCREEN.  IF SO, SEND 'SEE MSGI' MESSAGE.
      *
           MOVE L5063-MAX-ERR-IND     TO WS-POL-ERROR-CTR.

           IF  L5063-MAX-ERR-IND > ZERO
               SET L5063-ERR-INDX   TO L5063-MAX-ERR-IND
               INITIALIZE L5063-MAX-ERR-IND
               PERFORM 7210-MISC-OWNER-ERR-MSG
                  THRU 7210-MISC-OWNER-ERR-MSG-X
                  UNTIL L5063-ERR-INDX = ZERO
           ELSE
      *MSG - ALL POLICIES SUCCESSFULLY PROCESSED  (CS50600032)
               MOVE 'CS50600032'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7200-MISC-OWNER-SCREEN-X.
           EXIT.
      *
      *************************
       7210-MISC-OWNER-ERR-MSG.
      *************************

           PERFORM
           VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > 4
                OR L5063-ERR-INDX = ZERO

              MOVE L5063-ERR-POL-ID (L5063-ERR-INDX)
                                      TO WGLOB-MSG-PARM (WS-SUB)
              SET L5063-ERR-INDX DOWN BY 1

           END-PERFORM.

      *MSG - POLICIES @1, @2, @3, @4 FAILED (CS50600034)
           MOVE 'CS50600034'          TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

       7210-MISC-OWNER-ERR-MSG-X.
           EXIT.
      *
      **********************
       7250-SETUP-5063-POLS.
      **********************

           SET L5063-INDEX TO 1.
           PERFORM
           VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > 100
             OR MIR-POL-ID-BASE-T (WS-SUB) NOT > SPACES

              IF MIR-DV-SELCT-CD-T (WS-SUB) = 'Y'
014221           PERFORM  6450-CHECK-POL-TS
014221               THRU 6450-CHECK-POL-TS-X
014221           IF  WS-LOGICAL-LOCK-ERROR
014221               GO TO 7250-SETUP-5063-POLS-X
014221           END-IF
                 MOVE MIR-POL-ID-BASE-T (WS-SUB)
                                   TO L5063-POL-ID(L5063-INDEX)(1:9)
013578           MOVE MIR-POL-ID-SFX-T (WS-SUB)
013578                             TO L5063-POL-ID(L5063-INDEX)(10:1)
019859*          IF L5063-CLI-ID = SPACES
019859*             MOVE MIR-CLI-ID-T (WS-SUB)
019859*                            TO L5063-CLI-ID
019859*          END-IF
019859*          IF L5063-SERV-AG-ID = SPACES
019859*             MOVE MIR-SERV-AGT-ID-T (WS-SUB)
019859*                            TO L5063-SERV-AG-ID
019859*          END-IF
019859*          IF L5063-NFO-CD = SPACES
019859*             MOVE MIR-POL-NFO-CD-T (WS-SUB)
019859*                            TO L5063-NFO-CD
019859*          END-IF
019859*          IF L5063-DIV-OPT-CD = SPACES
019859*             MOVE MIR-POL-DIV-OPT-CD-T (WS-SUB)
019859*                            TO L5063-DIV-OPT-CD
019859*          END-IF
019859*          IF L5063-REL-CLI-ID = SPACES
019859*             MOVE MIR-CLI-ID-T (WS-SUB)
019859*                            TO L5063-REL-CLI-ID
019859*          END-IF
019859*          IF L5063-CLI-ADR-TYP-CD = SPACES
019859*             MOVE MIR-CLI-ADDR-TYP-CD-T (WS-SUB)
019859*                            TO L5063-CLI-ADR-TYP-CD
019859*          END-IF
019859*          IF L5063-ASIGN-TYP-CD = SPACES
019859*             MOVE MIR-POL-CLI-REL-SUB-CD-T (WS-SUB)
019859*                            TO L5063-ASIGN-TYP-CD
019859*          END-IF
                 SET L5063-INDEX UP BY 1
              END-IF

           END-PERFORM.

       7250-SETUP-5063-POLS-X.
           EXIT.
      *
      **********************
       7300-LISTBILL-SCREEN.
      **********************

           PERFORM 5065-1000-BUILD-PARM-INFO
              THRU 5065-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID            TO L5065-LISTBILL-CLI-ID
           MOVE MIR-POL-BILL-TYP-CD   TO L5065-BILL-TYP-CD
           MOVE MIR-POL-BILL-MODE-CD  TO L5065-BILL-MODE-CD
016395*    MOVE MIR-POL-PAC-DRW-DY    TO L5065-PAC-DRW-DY-CD
016395     MOVE MIR-POL-PMT-DRW-DY    TO L5065-PMT-DRW-DY
           MOVE MIR-BILL-LEAD-TIME-DUR   TO L5065-BILL-LEAD-TIME-DUR
025001*    MOVE WS-BILL-CHNG-SW       TO L5065-BILL-CHNG-SW.

           IF WS-CHNG-SET-SELCT
              SET L5065-CHNG-TYP-SELECTED    TO TRUE
              PERFORM 7350-SETUP-5065-POLS
                 THRU 7350-SETUP-5065-POLS-X
           END-IF.

025001     MOVE WS-BILL-CHNG-SW       TO L5065-BILL-CHNG-SW.

           PERFORM 5065-1000-CHANGE-POLS
              THRU 5065-1000-CHANGE-POLS-X.

           IF L5065-RETRN-ERROR
              SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

      *
      * CHECK TO SEE IF THERE MORE MESSAGES THAN CAN BE DISPLAYED ON
      * THE SCREEN.  IF SO, SEND 'SEE MSGI' MESSAGE.
      *
557660*    MOVE L5063-MAX-ERR-IND       TO WS-POL-ERROR-CTR.
557660     MOVE L5065-MAX-ERR-IND     TO WS-POL-ERROR-CTR.

           IF  L5065-MAX-ERR-IND > ZERO
               SET L5065-ERR-INDX   TO L5065-MAX-ERR-IND
               INITIALIZE L5065-MAX-ERR-IND
               PERFORM 7310-LISTBILL-ERR-MSG
                  THRU 7310-LISTBILL-ERR-MSG-X
                 UNTIL L5065-ERR-INDX = ZERO
           ELSE
      *MSG - ALL POLICIES SUCCESSFULLY PROCESSED  (CS50600032)
               MOVE 'CS50600032'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7300-LISTBILL-SCREEN-X.
           EXIT.
      *
      ***********************
       7310-LISTBILL-ERR-MSG.
      ***********************

           PERFORM
           VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > 4
                OR L5065-ERR-INDX = ZERO

                MOVE L5065-ERR-POL-ID (L5065-ERR-INDX)
                                      TO WGLOB-MSG-PARM (WS-SUB)
                SET  L5065-ERR-INDX DOWN BY 1

           END-PERFORM.

      *MSG - POLICIES @1, @2, @3, @4 FAILED (CS50600034)
           MOVE 'CS50600034'          TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

       7310-LISTBILL-ERR-MSG-X.
           EXIT.
      *
      **********************
       7350-SETUP-5065-POLS.
      **********************

023435     PERFORM  6320-CHK-BILL-CHNG-FIELDS
023435         THRU 6320-CHK-BILL-CHNG-FIELDS-X.
023435
           SET L5065-INDEX TO 1.
           PERFORM
           VARYING WS-SUB FROM 1 BY 1
             UNTIL WS-SUB > 100
             OR MIR-POL-ID-BASE-T (WS-SUB) NOT > SPACES

              IF MIR-DV-SELCT-CD-T (WS-SUB) = 'Y'
023435           PERFORM  7400-EDIT-OFF-ANNV
023435               THRU 7400-EDIT-OFF-ANNV-X
014221           PERFORM  6450-CHECK-POL-TS
014221               THRU 6450-CHECK-POL-TS-X
014221           IF  WS-LOGICAL-LOCK-ERROR
014221               GO TO 7350-SETUP-5065-POLS-X
014221           END-IF
023435           MOVE WS-POL-OFFANNV-PD-DT
023435                TO L5065-POL-OFFANNV-PD-DT (L5065-INDEX)
                 MOVE MIR-POL-ID-BASE-T (WS-SUB)
                                 TO L5065-POL-ID (L5065-INDEX)(1:9)
013578           MOVE MIR-POL-ID-SFX-T (WS-SUB)
013578                           TO L5065-POL-ID (L5065-INDEX)(10:1)
019859*          IF L5065-LISTBILL-CLI-ID = SPACES
019859*             MOVE MIR-CLI-ID-T (WS-SUB)
019859*                          TO L5065-LISTBILL-CLI-ID
019859*          END-IF
019859*          IF L5065-BILL-TYP-CD = SPACES
019859*             MOVE MIR-POL-BILL-TYP-CD-T (WS-SUB)
019859*                          TO L5065-BILL-TYP-CD
019859*          END-IF
019859*          IF L5065-BILL-MODE-CD = SPACES
019859*             MOVE MIR-POL-BILL-MODE-CD-T (WS-SUB)
019859*                          TO L5065-BILL-MODE-CD
019859*          END-IF
016395*          IF L5065-PAC-DRW-DY-CD = SPACES
019859*          IF L5065-PMT-DRW-DY    = SPACES
017356*          OR L5065-PAC-DRW-DY-CD = ZEROES
016395*             MOVE MIR-POL-PAC-DRW-DY-T (WS-SUB)
019859*             MOVE MIR-POL-PMT-DRW-DY-T (WS-SUB)
016395*                          TO L5065-PAC-DRW-DY-CD
019859*                          TO L5065-PMT-DRW-DY
019859*          END-IF
019859*          IF L5065-BILL-LEAD-TIME-DUR = SPACES
019859*             MOVE MIR-BILL-LEAD-TIME-DUR-T (WS-SUB)
019859*                          TO L5065-BILL-LEAD-TIME-DUR
019859*          END-IF
                 SET L5065-INDEX UP BY 1
              END-IF

           END-PERFORM.

       7350-SETUP-5065-POLS-X.
           EXIT.
023435/
023435*--------------------
023435 7400-EDIT-OFF-ANNV.
023435*--------------------
023435
023435     INITIALIZE WS-POL-OFFANNV-PD-DT.
023435
023435     MOVE MIR-POL-ID-BASE-T (WS-SUB) TO WS-POL-ID-BASE.
023435     MOVE MIR-POL-ID-SFX-T  (WS-SUB) TO WS-POL-ID-SFX.
023435
023436     MOVE WS-POL-ID                  TO WPOL-POL-ID.
023436
023436     PERFORM  POL-1000-READ
023436         THRU POL-1000-READ-X.
023436
023436     IF NOT WPOL-IO-OK
023436         MOVE WPOL-KEY               TO WGLOB-MSG-PARM (1)
023436         MOVE 'XS00000001'           TO WGLOB-MSG-REF-INFO
023436         PERFORM  0260-1000-GENERATE-MESSAGE
023436             THRU 0260-1000-GENERATE-MESSAGE-X
023436         GO TO 7400-EDIT-OFF-ANNV-X
023436     END-IF.
020478     PERFORM  2625-0000-INIT-PARM-INFO
020478         THRU 2625-0000-INIT-PARM-INFO-X.
020478     PERFORM  2625-1000-BILL-CHNG-RETRIEVE
020478         THRU 2625-1000-BILL-CHNG-RETRIEVE-X.
023436
020478*    MOVE RPOL-POL-OFFANNV-PD-DT     TO WS-POL-OFFANNV-PD-DT.
020478     IF  L2625-OFFANNV-PD-DT = WWKDT-ZERO-DT
020478         MOVE RPOL-POL-OFFANNV-PD-DT TO WS-POL-OFFANNV-PD-DT
020478     ELSE
020478         MOVE L2625-OFFANNV-PD-DT TO WS-POL-OFFANNV-PD-DT
020478     END-IF.
023435
023436     PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
023436         THRU CVGS-1000-LOAD-CVGS-ARRAY-X.
023436
023436     IF  RPOL-POL-UL-PRCES-DT      NOT = WWKDT-ZERO-DT
023436         MOVE RPOL-POL-UL-PRCES-DT      TO WS-PCHST-EFF-DT
023436     ELSE
023436         IF  RPOL-POL-PD-TO-DT-NUM NOT = WWKDT-ZERO-DT
023436             MOVE RPOL-POL-PD-TO-DT-NUM TO WS-PCHST-EFF-DT
023436         ELSE
023436             MOVE RPOL-POL-ISS-EFF-DT   TO WS-PCHST-EFF-DT
023436         END-IF
023436     END-IF.
020478
020478     IF  WS-BUS-FCN-MISCHG
020478         MOVE MIR-PCHST-EFF-DT          TO L1640-EXTERNAL-DATE
020478         PERFORM  1640-7000-MIR-TO-INT
020478             THRU 1640-7000-MIR-TO-INT-X
020478         MOVE L1640-INTERNAL-DATE       TO WS-PCHST-EFF-DT
020478     END-IF.
023435
023435     PERFORM  7410-EDIT-EFF-DT
023435         THRU 7410-EDIT-EFF-DT-X.
023435
023435     IF  WS-BILL-CHNG-NO
023436         PERFORM  7500-CHECK-OS-ACTV
023436             THRU 7500-CHECK-OS-ACTV-X
023435         GO TO 7400-EDIT-OFF-ANNV-X
023435     END-IF.
023435
023435     IF  WGLOB-RETURN-CODE > ZERO
023435         GO TO 7400-EDIT-OFF-ANNV-X
023435     END-IF
023436
023435     PERFORM  7415-SET-PRCES-EFF-DT
023435         THRU 7415-SET-PRCES-EFF-DT-X.
023435
023436     MOVE WS-PCHST-EFF-DT               TO L1640-INTERNAL-DATE.
023436
023436     PERFORM  1640-8000-INTERNAL-TO-MIR
023436         THRU 1640-8000-INTERNAL-TO-MIR-X.
023436
023436     MOVE L1640-EXTERNAL-DATE           TO MIR-PCHST-EFF-DT.
023435
023436     PERFORM  7500-CHECK-OS-ACTV
023436         THRU 7500-CHECK-OS-ACTV-X.
023435
023435     IF  NOT RPOL-POL-PREM-CNTRCT
023435         GO TO 7400-EDIT-OFF-ANNV-X
023435     END-IF.
023435
023435     MOVE RPOL-POL-PMT-DRW-DY      TO L0290-INPUT-V00.
023435     MOVE ZERO                     TO L0290-PRECISION.
023435     MOVE LENGTH OF WS-POL-PMT-DRW-DY TO L0290-MAX-OUT-LEN.
023435     PERFORM  0290-2000-FORMAT-FOR-MIR
023435         THRU 0290-2000-FORMAT-FOR-MIR-X.
023435     MOVE L0290-OUTPUT-DATA        TO WS-POL-PMT-DRW-DY.
023435
023435     IF (MIR-POL-BILL-TYP-CD     = RPOL-POL-BILL-TYP-CD
023435     AND MIR-POL-BILL-MODE-CD    = RPOL-POL-BILL-MODE-CD
023435     AND MIR-POL-PMT-DRW-DY      = WS-POL-PMT-DRW-DY)
023435         GO TO 7400-EDIT-OFF-ANNV-X
023435     END-IF.
023435
023435     MOVE RPOL-POL-ISS-EFF-DT-R    TO L1680-INTERNAL-1.
023435     MOVE ZERO                     TO L1680-NUMBER-OF-DAYS.
023435     MOVE ZERO                     TO L1680-NUMBER-OF-MONTHS.
023435     MOVE RPOL-POL-PREV-ANNV-DUR   TO L1680-NUMBER-OF-YEARS.
023435
023435     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
023435         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
023435
023435     MOVE L1680-INTERNAL-2         TO WS-LAST-ANNV-DT.
023435
020478*    MOVE RPOL-POL-OFFANNV-PD-DT   TO L1680-INTERNAL-1.
020478     MOVE WS-POL-OFFANNV-PD-DT     TO L1680-INTERNAL-1.
023435     MOVE ZERO                     TO L1680-NUMBER-OF-DAYS.
023435     MOVE ZERO                     TO L1680-NUMBER-OF-MONTHS.
023435     MOVE RPOL-POL-PREV-ANNV-DUR   TO L1680-NUMBER-OF-YEARS.
023435     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
023435         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
023435
023435     MOVE L1680-INTERNAL-2         TO L1680-INTERNAL-1.
023435     MOVE +1                       TO L1680-NUMBER-OF-YEARS.
023435     MOVE ZEROS                    TO L1680-NUMBER-OF-DAYS.
023435     MOVE ZEROS                    TO L1680-NUMBER-OF-MONTHS.
023435     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
023435         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
023435
027868     MOVE ZERO                     TO WS-MODE.
027868     IF  MIR-POL-BILL-MODE-CD > SPACES
027868         SET L0280-SIGN-NOT-PERMITTED TO TRUE
027868         MOVE ZERO                 TO L0280-PRECISION
027868         MOVE LENGTH OF MIR-POL-BILL-MODE-CD
027868                                   TO L0280-LENGTH
027868         MOVE LENGTH OF MIR-POL-BILL-MODE-CD
027868                                   TO L0280-INPUT-SIZE
027868         MOVE MIR-POL-BILL-MODE-CD TO L0280-INPUT-DATA
027868         PERFORM  0280-1000-NUMERIC-EDIT
027868             THRU 0280-1000-NUMERIC-EDIT-X
027868         IF  L0280-OK
027868             MOVE L0280-OUTPUT     TO WS-MODE
027868         END-IF
027868     END-IF.
027868
023435     MOVE L1680-INTERNAL-2         TO L1680-INTERNAL-1.
023435     MOVE WS-MODE                  TO L1680-NUMBER-OF-MONTHS.
023435     PERFORM  1680-6000-SUB-M-FROM-DATE
023435         THRU 1680-6000-SUB-M-FROM-DATE-X.
023435     MOVE L1680-INTERNAL-2         TO L1680-INTERNAL-1.
023435
023435     PERFORM
023435       UNTIL L1680-INTERNAL-2 <= WS-LAST-ANNV-DT
027868       OR WS-MODE <= ZERO
023435             MOVE WS-MODE          TO L1680-NUMBER-OF-MONTHS
023435             PERFORM  1680-6000-SUB-M-FROM-DATE
023435                 THRU 1680-6000-SUB-M-FROM-DATE-X
023435             MOVE L1680-INTERNAL-2 TO L1680-INTERNAL-1
023435     END-PERFORM.
023435
023435     IF  L1680-INTERNAL-2            = WS-LAST-ANNV-DT
023435*MSG: THE COMBINATION OF THE OFF ANNIVERSARY DATE AND MODE WILL
023435*     MAKE THE POLICY ON-ANNIVERSARY
023435         MOVE 'CS50600046'           TO WGLOB-MSG-REF-INFO
023435         MOVE WS-POL-ID              TO WGLOB-MSG-PARM (1)
023435         PERFORM  0260-1000-GENERATE-MESSAGE
023435             THRU 0260-1000-GENERATE-MESSAGE-X
023435         MOVE EBLCH-BLANK-FIELD-CHAR TO WS-POL-OFFANNV-PD-DT
027897     ELSE
027897         IF  RPOL-POL-OFFANNV-PD-DT NOT = WWKDT-ZERO-DT
027897*MSG: POLICY IS OFF-ANNIVERSARY, USE OFF-ANNIVERSARY POLICY
027897*     UPDATE TO MAKE CHANGES
027897             MOVE 'CS50600052'        TO WGLOB-MSG-REF-INFO
027897             PERFORM  0260-1000-GENERATE-MESSAGE
027897                 THRU 0260-1000-GENERATE-MESSAGE-X
027897             GO TO 7400-EDIT-OFF-ANNV-X
027897         END-IF
023435     END-IF.
023435
020478*    IF  RPOL-POL-PD-TO-DT-NUM = RPOL-POL-BILL-CHNG-DT
020478     IF  L2625-PBRQST-EFF-DT NOT = WWKDT-ZERO-DT
023435*MSG  THERE IS AN ACTIVE BILL CHANGE ACTIVITY
023435         MOVE 'CS50600047'           TO WGLOB-MSG-REF-INFO
023435         MOVE WS-POL-ID              TO WGLOB-MSG-PARM (1)
023435         PERFORM  0260-1000-GENERATE-MESSAGE
023435             THRU 0260-1000-GENERATE-MESSAGE-X
023435         GO TO 7400-EDIT-OFF-ANNV-X
023435     END-IF.
023435
020478     IF  WGLOB-RETURN-ERROR
020478         GO TO 7400-EDIT-OFF-ANNV-X
020478     END-IF.
020478
023435     INITIALIZE                 RPHST-REC-INFO.
023435     MOVE RPOL-POL-ID           TO WPHST-POL-ID.
023435
023435     MOVE WS-PCHST-EFF-DT       TO L1660-INTERNAL-DATE.
023435
023435     PERFORM  1660-2000-CONVERT-INT-TO-INV
023435         THRU 1660-2000-CONVERT-INT-TO-INV-X.
023435
023435     MOVE L1660-INVERTED-DATE   TO WPHST-PCHST-EFF-IDT-NUM.
023435     MOVE ZEROS                 TO WPHST-PCHST-SEQ-NUM.
023435
023435     MOVE WPHST-KEY             TO WPHST-ENDBR-KEY.
030054*    MOVE 999                   TO WPHST-ENDBR-PCHST-SEQ-NUM.
030054     MOVE WCNST-MAX-PCHST-SEQ-NUM-N
030054                                TO WPHST-ENDBR-PCHST-SEQ-NUM.
023435
023435     PERFORM  PHST-1000-BROWSE
023435         THRU PHST-1000-BROWSE-X.
023435
023435     PERFORM  PHST-2000-READ-NEXT
023435         THRU PHST-2000-READ-NEXT-X.
023435
023435     IF  NOT WPHST-IO-OK
023435         PERFORM  PHST-3000-END-BROWSE
023435             THRU PHST-3000-END-BROWSE-X
023435         GO TO 7400-EDIT-OFF-ANNV-X
023435     END-IF.
023435*
023435*  FIND ANY ACTIVE/REVERSE PHST RECORD FOR BILL CHANGE
023435*
023435     MOVE RPHST-POL-ACTV-TYP-ID TO WS-ACTV-TYP-ID.
023435     PERFORM
023435        UNTIL WPHST-IO-EOF
023435           OR (WS-ACTV-TYP-BILL-CHNG
023435          AND (RPHST-PCHST-STAT-ACTIVE  OR
023435               RPHST-PCHST-STAT-REVERSED))
023435          PERFORM  PHST-2000-READ-NEXT
023435              THRU PHST-2000-READ-NEXT-X
023435          MOVE RPHST-POL-ACTV-TYP-ID TO WS-ACTV-TYP-ID
023435     END-PERFORM.
023435
023435     IF  WPHST-IO-OK
023435         MOVE WS-PCHST-EFF-DT        TO L1640-INTERNAL-DATE
023435         PERFORM  1640-2000-INTERNAL-TO-EXT
023435             THRU 1640-2000-INTERNAL-TO-EXT-X
023435         MOVE WS-POL-ID              TO WGLOB-MSG-PARM (1)
023435         MOVE L1640-EXTERNAL-DATE    TO WGLOB-MSG-PARM (2)
023435* MSG: EXISTING BILLING CHANGE ON SAME DAY, REVERSE AND ERROR OUT
023435*       THE PREVIOUS CHANGE BEFORE MAKING THIS CHANGE
023435         MOVE 'CS50600048'           TO WGLOB-MSG-REF-INFO
023435         PERFORM  0260-1000-GENERATE-MESSAGE
023435             THRU 0260-1000-GENERATE-MESSAGE-X
023435         SET WGLOB-RETURN-ERROR      TO TRUE
023435     END-IF.
023435
023435     PERFORM  PHST-3000-END-BROWSE
023435         THRU PHST-3000-END-BROWSE-X.
023435
023435 7400-EDIT-OFF-ANNV-X.
023435     EXIT.
023435/
023435*-----------------
023435 7410-EDIT-EFF-DT.
023435*-----------------
023435
023435     IF  NOT WS-BUS-FCN-MISCHG
023435         GO TO 7410-EDIT-EFF-DT-X
023435     END-IF.
023435
023435     IF  WS-DIV-CHNG-NO
023435         GO TO 7410-EDIT-EFF-DT-X
023435     END-IF.
023435
023435* EFFECTIVE DATE CANNOT BE GREATER THAN THE PAID TO DATE.
023435
023435      MOVE MIR-PCHST-EFF-DT  TO L1640-EXTERNAL-DATE.
023435      PERFORM  1640-7000-MIR-TO-INT
023435          THRU 1640-7000-MIR-TO-INT-X.
023435
023435     IF  L1640-INTERNAL-DATE > RPOL-POL-PD-TO-DT-NUM
023435         PERFORM  1640-2000-INTERNAL-TO-EXT
023435             THRU 1640-2000-INTERNAL-TO-EXT-X
023435         MOVE L1640-EXTERNAL-DATE    TO WGLOB-MSG-PARM (1)
023435         MOVE RPOL-POL-PD-TO-DT-NUM  TO L1640-INTERNAL-DATE
023435         PERFORM  1640-2000-INTERNAL-TO-EXT
023435             THRU 1640-2000-INTERNAL-TO-EXT-X
023435         MOVE L1640-EXTERNAL-DATE    TO WGLOB-MSG-PARM (2)
023435         MOVE WS-POL-ID              TO WGLOB-MSG-PARM (3)
023435* MSG: EFFECTIVE DATE @1 IS GREATER THAN THE PAID TO DATE @2 FOR
023435*      POLICY @3
023435         MOVE 'CS50600049'           TO WGLOB-MSG-REF-INFO
023435         PERFORM  0260-1000-GENERATE-MESSAGE
023435             THRU 0260-1000-GENERATE-MESSAGE-X
023435         SET WGLOB-RETURN-ERROR      TO TRUE
023435     END-IF.
023435
023435* EFFECTIVE DATE CANNOT BE LESS THAN THE ISSUE DATE.
023435
023435      MOVE MIR-PCHST-EFF-DT  TO L1640-EXTERNAL-DATE.
023435      PERFORM  1640-7000-MIR-TO-INT
023435          THRU 1640-7000-MIR-TO-INT-X.
023435
023435     IF  L1640-INTERNAL-DATE < RPOL-POL-ISS-EFF-DT
023435         PERFORM  1640-2000-INTERNAL-TO-EXT
023435             THRU 1640-2000-INTERNAL-TO-EXT-X
023435         MOVE L1640-EXTERNAL-DATE    TO WGLOB-MSG-PARM (1)
023435         MOVE RPOL-POL-ISS-EFF-DT    TO L1640-INTERNAL-DATE
023435         PERFORM  1640-2000-INTERNAL-TO-EXT
023435             THRU 1640-2000-INTERNAL-TO-EXT-X
023435         MOVE L1640-EXTERNAL-DATE    TO WGLOB-MSG-PARM (2)
023435         MOVE WS-POL-ID              TO WGLOB-MSG-PARM (3)
023435* MSG: EFFECTIVE DATE @1 IS LESS THAN THE ISSUE DATE @2 FOR
023435*      POLICY @3
023435         MOVE 'CS50600050'           TO WGLOB-MSG-REF-INFO
023435         PERFORM  0260-1000-GENERATE-MESSAGE
023435             THRU 0260-1000-GENERATE-MESSAGE-X
023435         SET WGLOB-RETURN-ERROR      TO TRUE
023435     END-IF.
023435
023435 7410-EDIT-EFF-DT-X.
023435     EXIT.
023435/
023435*---------------------
023435 7415-SET-PRCES-EFF-DT.
023435*---------------------
023435
023435     IF  NOT WS-BILL-CHNG
023435         GO TO 7415-SET-PRCES-EFF-DT-X
023435     END-IF.
023435
023435     MOVE WGLOB-PROCESS-DATE         TO WS-PCHST-EFF-DT
023435
020478     IF  NOT RPOL-POL-PREM-CNTRCT
020478         GO TO 7415-SET-PRCES-EFF-DT-X
020478     END-IF.
020478
020478     IF  RPOL-POL-PD-TO-DT-NUM > WGLOB-PROCESS-DATE
020478* MSG: PAID-TO-DATE IS IN THE FUTURE FOR POLICY (@1). USE BILLING
020478*      METHOD AND MODE UPDATE TO PROCESS BILLING CHANGE
020478         MOVE 'CS50600051'           TO WGLOB-MSG-REF-INFO
020478         MOVE RPOL-POL-ID            TO WGLOB-MSG-PARM (1)
020478         PERFORM  0260-1000-GENERATE-MESSAGE
020478             THRU 0260-1000-GENERATE-MESSAGE-X
020478         SET WGLOB-RETURN-ERROR      TO TRUE
020478         GO TO 7415-SET-PRCES-EFF-DT-X
020478     END-IF.
020478
023435     IF  RPOL-POL-PD-TO-DT-NUM    <= WGLOB-PROCESS-DATE
023435         MOVE RPOL-POL-PD-TO-DT-NUM  TO WS-PCHST-EFF-DT
023435     END-IF.
023435
023435 7415-SET-PRCES-EFF-DT-X.
023435     EXIT.
023435/
023436*
023436*-------------------
023436 7500-CHECK-OS-ACTV.
023436*-------------------
023436
023436     IF  NOT RPOL-POL-STAT-IN-FORCE
023436         GO TO 7500-CHECK-OS-ACTV-X
023436     END-IF.
023436
023436     PERFORM  4780-1000-BUILD-PARM-INFO
023436         THRU 4780-1000-BUILD-PARM-INFO-X.
023436     MOVE WS-PCHST-EFF-DT             TO L4780-EFF-DT.
025156*    SET L4780-REDO-WARNING           TO TRUE.
023436     MOVE RPOL-PREV-BTCH-PRCES-DT     TO L4780-LAST-PROCESS-DATE.
023436     SET L4780-PRCES-INCLUSIVE        TO TRUE.
023436
023436     PERFORM  4780-1000-GET-NEXT-ACT-DT
023436         THRU 4780-1000-GET-NEXT-ACT-DT-X.
023436
023436 7500-CHECK-OS-ACTV-X.
023436     EXIT.
023436/
      *
      ******************
       8000-LOAD-SCREEN.
      ******************

           MOVE RPOL-POL-ID(1:9)      TO MIR-POL-ID-BASE-T(WS-SUB).
           MOVE RPOL-POL-ID(10:1)     TO MIR-POL-ID-SFX-T (WS-SUB).

           IF WS-BUS-FCN-BILLCHG
               PERFORM  8100-LOAD-BILL-OWNER-SCREEN
                   THRU 8100-LOAD-BILL-OWNER-SCREEN-X
           END-IF.

           IF WS-BUS-FCN-MISCHG
               PERFORM  8200-LOAD-MISC-OWNER-SCREEN
                   THRU 8200-LOAD-MISC-OWNER-SCREEN-X
           END-IF.

           IF WS-BUS-FCN-LBILCHG
               PERFORM  8300-LOAD-LISTBILL-SCREEN
                   THRU 8300-LOAD-LISTBILL-SCREEN-X
           END-IF.

       8000-LOAD-SCREEN-X.
           EXIT.
      *
      *****************************
       8100-LOAD-BILL-OWNER-SCREEN.
      *****************************

           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD-T (WS-SUB).
           MOVE RPOL-POL-BILL-TYP-CD  TO MIR-POL-BILL-TYP-CD-T (WS-SUB).
           MOVE RPOL-POL-BILL-MODE-CD
                                   TO MIR-POL-BILL-MODE-CD-T   (WS-SUB).
557659*    MOVE RPOL-POL-PAC-DRW-DY-CD TO MIR-POL-PAC-DRW-DY-T (WS-SUB).
023118*    MOVE RPOL-POL-PMT-DRW-DY    TO MIR-POL-PMT-DRW-DY-T (WS-SUB).
016395*    INITIALIZE WS-PAC-DRW-DY
016395     INITIALIZE WS-PMT-DRW-DY
016395*    ADD  RPOL-POL-PAC-DRW-DY        TO WS-PAC-DRW-DY.
020874*    ADD  RPOL-POL-PMT-DRW-DY        TO WS-PMT-DRW-DY.
023118     ADD  RPOL-POL-PMT-DRW-DY   TO WS-PMT-DRW-DY.
016395*    MOVE WS-PAC-DRW-DY        TO MIR-POL-PAC-DRW-DY-T   (WS-SUB).
020874*    MOVE WS-PMT-DRW-DY        TO MIR-POL-PMT-DRW-DY-T   (WS-SUB).
020874     ADD  RPOL-POL-PMT-DRW-DY   TO L0290-INPUT-V00.
023118     MOVE WS-PMT-DRW-DY         TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-POL-PMT-DRW-DY-T   (WS-SUB)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA    TO MIR-POL-PMT-DRW-DY-T   (WS-SUB).

020478*    MOVE RPOL-POL-NXT-BILL-CD TO MIR-POL-NXT-BILL-CD-T  (WS-SUB).
020478     MOVE L2625-PBRQST-BILL-TYP-CD TO MIR-PBRQST-BILL-TYP-CD-T
020478                                      (WS-SUB).
020478*    MOVE RPOL-POL-NXT-MODE-CD TO MIR-POL-NXT-MODE-CD-T  (WS-SUB).
020478     MOVE L2625-BILL-MODE-CD TO MIR-BILL-MODE-CD-T    (WS-SUB).
023435
020478*    MOVE RPOL-POL-NXT-PMT-DRW-DY TO L0290-INPUT-V00.
020478     MOVE L2625-PBRQST-PMT-DRW-DY TO L0290-INPUT-V00.
023435     MOVE ZERO                    TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-POL-NXT-PMT-DRW-DY
020478     MOVE LENGTH OF MIR-PBRQST-PMT-DRW-DY
023435                                  TO L0290-MAX-OUT-LEN.
023435     PERFORM 0290-2000-FORMAT-FOR-MIR
023435        THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA    TO MIR-POL-NXT-MODE-CD-T  (WS-SUB).
020478     MOVE L0290-OUTPUT-DATA    TO MIR-BILL-MODE-CD-T  (WS-SUB).
023435
020874*    MOVE RPOL-BILL-LEAD-TIME-DUR
020874*                               TO WS-PIC-S99.
020874*    MOVE WS-PIC-S99       TO MIR-BILL-LEAD-TIME-DUR-T   (WS-SUB).
020874     MOVE RPOL-BILL-LEAD-TIME-DUR  TO L0290-INPUT-V00.
020874     MOVE 0                        TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-BILL-LEAD-TIME-DUR-T   (WS-SUB)
020874                                   TO L0290-MAX-OUT-LEN.
020874     SET L0290-SIGN-DISPLAY     TO TRUE.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA
020874              TO MIR-BILL-LEAD-TIME-DUR-T   (WS-SUB).

           MOVE   ZEROS               TO I.
           PERFORM 2430-1000-BUILD-PARM-INFO
              THRU 2430-1000-BUILD-PARM-INFO-X.
           PERFORM 2430-2100-GET-OWNER
              THRU 2430-2100-GET-OWNER-X.
           IF L2430-RELATIONSHIP-FOUND
               MOVE L2430-CLI-REL-TYP-CD
                                   TO MIR-POL-CLI-REL-TYP-CD-T  (WS-SUB)
               MOVE L2430-CLI-ID      TO MIR-CLI-ID-T  (WS-SUB)
           ELSE
               PERFORM 2430-2300-GET-LISTBILL
                  THRU 2430-2300-GET-LISTBILL-X
               IF L2430-RELATIONSHIP-FOUND
                   MOVE L2430-CLI-REL-TYP-CD
                                    TO MIR-POL-CLI-REL-TYP-CD-T (WS-SUB)
                   MOVE L2430-CLI-ID  TO MIR-CLI-ID-T  (WS-SUB)
               ELSE
                   MOVE SPACES     TO MIR-POL-CLI-REL-TYP-CD-T  (WS-SUB)
                   MOVE SPACES        TO MIR-CLI-ID-T  (WS-SUB)
               END-IF
           END-IF.

           IF L2430-RELATIONSHIP-FOUND
               MOVE RPOL-POL-ID       TO WPOLC-POL-ID
               MOVE L2430-CLI-REL-TYP-CD
                                      TO WPOLC-POL-CLI-REL-TYP-CD
               MOVE L2430-CLI-ID      TO WPOLC-CLI-ID
               PERFORM  POLC-1000-READ
                   THRU POLC-1000-READ-X
               IF NOT WPOLC-IO-OK
                   MOVE WPOLC-KEY     TO WGLOB-MSG-PARM (1)
                   MOVE 'XS00000001'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE RPOLC-POL-CLI-REL-SUB-CD
                                    TO MIR-POL-CLI-REL-SUB-CD-T (WS-SUB)
               END-IF
           ELSE
               MOVE SPACES          TO MIR-POL-CLI-REL-SUB-CD-T (WS-SUB)
           END-IF.
557788
557788
557788     PERFORM 2480-1000-BUILD-PARM-INFO
557788         THRU 2480-1000-BUILD-PARM-INFO-X.
557788
557788     PERFORM 2480-1000-READ-RBILL
557788         THRU 2480-1000-READ-RBILL-X.
557788
557788
010418     MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID-T (WS-SUB).
557788     MOVE L2480-RBILL-DEPT-ID   TO MIR-RBILL-DEPT-ID-T (WS-SUB).
557788     MOVE L2480-RBILL-MISC-1-CD
                                    TO MIR-RBILL-MISC-1-CD-T   (WS-SUB).
557788     MOVE L2480-RBILL-MISC-2-CD
                                    TO MIR-RBILL-MISC-2-CD-T   (WS-SUB).
557788     MOVE L2480-RBILL-EFF-DT    TO L1640-INTERNAL-DATE.
           MOVE RPOL-POL-RBILL-CD     TO MIR-POL-RBILL-CD-T (WS-SUB).
557788*    MOVE RPOL-POL-RBILL-DEPT-ID TO MIR-RBILL-DEPT-ID-T (WS-SUB).
557788*    MOVE RPOL-MISC-RESTR-1-IND TO MIR-RBILL-MISC-1-CD-T (WS-SUB).
557788*    MOVE RPOL-MISC-RESTR-2-IND TO MIR-RBILL-MISC-2-CD-T (WS-SUB).
557788*    MOVE RPOL-POL-RBILL-EFF-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-RBILL-EFF-DT-T (WS-SUB).
557788*    MOVE RPOL-POL-RBILL-END-DT      TO L1640-INTERNAL-DATE.
557788     MOVE L2480-RBILL-END-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-RBILL-END-DT-T (WS-SUB).

           ADD 1                           TO WS-SUB.

       8100-LOAD-BILL-OWNER-SCREEN-X.
           EXIT.
      *
      *****************************
       8200-LOAD-MISC-OWNER-SCREEN.
      *****************************

           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD-T (WS-SUB).
           MOVE RPOL-SERV-AGT-ID      TO MIR-SERV-AGT-ID-T (WS-SUB).
           MOVE RPOL-POL-NFO-CD       TO MIR-POL-NFO-CD-T (WS-SUB).
           MOVE RPOL-POL-DIV-OPT-CD   TO MIR-POL-DIV-OPT-CD-T (WS-SUB).
023436     MOVE RPOL-POL-DIV-XCES-CD
023436                          TO MIR-POL-DIV-XCES-CD-T (WS-SUB).
010418     MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID-T (WS-SUB).

           MOVE ZEROS                 TO I.
           PERFORM 2430-1000-BUILD-PARM-INFO
              THRU 2430-1000-BUILD-PARM-INFO-X.
           PERFORM 2430-2600-GET-ASSIGNEE
              THRU 2430-2600-GET-ASSIGNEE-X.
           IF L2430-RELATIONSHIP-FOUND
               MOVE L2430-CLI-ID      TO MIR-CLI-ID-T (WS-SUB)
               MOVE RPOL-POL-ID       TO WPOLC-POL-ID
               MOVE L2430-CLI-REL-TYP-CD
                                      TO WPOLC-POL-CLI-REL-TYP-CD
               MOVE L2430-CLI-ID      TO WPOLC-CLI-ID
               PERFORM  POLC-1000-READ
                   THRU POLC-1000-READ-X
               IF NOT WPOLC-IO-OK
                   MOVE SPACES        TO MIR-CLI-ADDR-TYP-CD-T (WS-SUB)
                   MOVE SPACES      TO MIR-POL-CLI-REL-SUB-CD-T (WS-SUB)
                   MOVE WPOLC-KEY     TO WGLOB-MSG-PARM (1)
                   MOVE 'XS00000001'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE RPOLC-CLI-ADDR-TYP-CD
                                      TO MIR-CLI-ADDR-TYP-CD-T (WS-SUB)
                   MOVE RPOLC-POL-CLI-REL-SUB-CD
                                    TO MIR-POL-CLI-REL-SUB-CD-T (WS-SUB)
               END-IF
           ELSE
               MOVE SPACES            TO MIR-CLI-ID-T (WS-SUB)
               MOVE SPACES            TO MIR-CLI-ADDR-TYP-CD-T (WS-SUB)
               MOVE SPACES          TO MIR-POL-CLI-REL-SUB-CD-T (WS-SUB)
           END-IF.

           ADD 1                           TO WS-SUB.

       8200-LOAD-MISC-OWNER-SCREEN-X.
           EXIT.
      *
      ***************************
       8300-LOAD-LISTBILL-SCREEN.
      ***************************

           MOVE ZEROS                 TO I.
           PERFORM 2430-1000-BUILD-PARM-INFO
              THRU 2430-1000-BUILD-PARM-INFO-X.
           PERFORM 2430-2300-GET-LISTBILL
              THRU 2430-2300-GET-LISTBILL-X.
           IF L2430-RELATIONSHIP-FOUND
557698*        MOVE L2430-CLI-SUR-NM  TO MIR-DV-OWN-CLI-NM-T (WS-SUB)
557698         MOVE L2430-CLI-ENTR-SUR-NM
                                      TO MIR-DV-OWN-CLI-NM-T (WS-SUB)
           ELSE
               MOVE SPACES            TO MIR-DV-OWN-CLI-NM-T (WS-SUB)
           END-IF.

010418     MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID-T (WS-SUB).
           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD-T (WS-SUB).

           MOVE RPOL-POL-PD-TO-DT-NUM TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE  TO MIR-POL-PD-TO-DT-NUM-T (WS-SUB).

           MOVE RPOL-POL-BILL-TYP-CD
                                    TO MIR-POL-BILL-TYP-CD-T   (WS-SUB).
           MOVE RPOL-POL-BILL-MODE-CD
                                   TO MIR-POL-BILL-MODE-CD-T   (WS-SUB).
557659*    MOVE RPOL-POL-PAC-DRW-DY-CD TO MIR-POL-PAC-DRW-DY-T (WS-SUB).
023118*    MOVE RPOL-POL-PMT-DRW-DY    TO MIR-POL-PMT-DRW-DY-T (WS-SUB).
016395*    INITIALIZE WS-PAC-DRW-DY
016395     INITIALIZE WS-PMT-DRW-DY
016395*    ADD  RPOL-POL-PAC-DRW-DY        TO WS-PAC-DRW-DY.
020874*    ADD  RPOL-POL-PMT-DRW-DY        TO WS-PMT-DRW-DY.
016395*    MOVE WS-PAC-DRW-DY        TO MIR-POL-PAC-DRW-DY-T   (WS-SUB).
020874*    MOVE WS-PMT-DRW-DY        TO MIR-POL-PMT-DRW-DY-T   (WS-SUB).
023118*    ADD  RPOL-POL-PMT-DRW-DY   TO L0290-INPUT-V00.
023118     ADD  RPOL-POL-PMT-DRW-DY   TO WS-PMT-DRW-DY.
023118     MOVE WS-PMT-DRW-DY         TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-POL-PMT-DRW-DY-T   (WS-SUB)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA   TO MIR-POL-PMT-DRW-DY-T   (WS-SUB).

020478*    MOVE RPOL-POL-NXT-BILL-CD TO MIR-POL-NXT-BILL-CD-T (WS-SUB).
020478     MOVE L2625-PBRQST-BILL-TYP-CD TO MIR-PBRQST-BILL-TYP-CD-T
020478                                      (WS-SUB).
020478*    MOVE RPOL-POL-NXT-MODE-CD TO MIR-POL-NXT-MODE-CD-T (WS-SUB).
020478     MOVE L2625-BILL-MODE-CD TO MIR-BILL-MODE-CD-T (WS-SUB).
023435
020478*    MOVE RPOL-POL-NXT-PMT-DRW-DY TO L0290-INPUT-V00.
020478     MOVE L2625-PBRQST-PMT-DRW-DY TO L0290-INPUT-V00.
023435     MOVE ZERO                 TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-POL-NXT-PMT-DRW-DY
020478     MOVE LENGTH OF MIR-PBRQST-PMT-DRW-DY
023435                               TO L0290-MAX-OUT-LEN.
023435     PERFORM 0290-2000-FORMAT-FOR-MIR
023435        THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA    TO MIR-POL-NXT-MODE-CD-T (WS-SUB).
020478     MOVE L0290-OUTPUT-DATA    TO MIR-BILL-MODE-CD-T (WS-SUB).
023435
020874*    MOVE RPOL-BILL-LEAD-TIME-DUR
020874*                               TO WS-PIC-S99.
020874*    MOVE WS-PIC-S99       TO MIR-BILL-LEAD-TIME-DUR-T   (WS-SUB).
020874     MOVE RPOL-BILL-LEAD-TIME-DUR  TO L0290-INPUT-V00.
020874     MOVE 0                        TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-BILL-LEAD-TIME-DUR-T   (WS-SUB)
020874                                   TO L0290-MAX-OUT-LEN.
020874     SET L0290-SIGN-DISPLAY     TO TRUE.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA
020874              TO MIR-BILL-LEAD-TIME-DUR-T   (WS-SUB).

           ADD 1                           TO WS-SUB.

       8300-LOAD-LISTBILL-SCREEN-X.
           EXIT.
      *
      ***************************
       9000-SETUP-MSIN-REFERENCE.
      ***************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET WGLOB-REF-CLIENT            TO TRUE.
           MOVE MIR-CLI-ID            TO WGLOB-REF-CLIENT-NUMBER.

       9000-SETUP-MSIN-REFERENCE-X.
           EXIT.
      *
      ***********************
       9200-CHECK-KEY-FIELDS.
      ***********************

           PERFORM 2435-1000-BUILD-PARM-INFO
              THRU 2435-1000-BUILD-PARM-INFO-X.
           MOVE MIR-CLI-ID            TO L2435-CLI-ID.
           PERFORM 2435-1000-OBTAIN-CLI-INFO
              THRU 2435-1000-OBTAIN-CLI-INFO-X.

           IF  NOT L2435-RETRN-OK
               MOVE L2435-CLI-ID      TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000076'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  L2435-RETRN-OK
557668*        MOVE L2435-CLI-NM-COMPRESSED TO MIR-DV-OWN-CLI-NM

557668         INITIALIZE L0620-INPUT-PARM-INFO
557668         IF L2435-CLI-SEX-CD = 'C'
557668             MOVE L2435-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
557668         ELSE
557668             MOVE L2435-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
557668             MOVE L2435-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
                   MOVE L2435-CLI-MID-INIT-NM
                                      TO L0620-CLI-MID-INIT-NM
                   MOVE L2435-CLI-SFX-NM
                                      TO L0620-CLI-SFX-NM
557668         END-IF
557668         MOVE L2435-CLI-SEX-CD  TO L0620-CLI-SEX-CD

557668         PERFORM  0620-1000-FORMAT-SCREEN-NAME
557668             THRU 0620-1000-FORMAT-SCREEN-NAME-X

557668         MOVE L0620-SCREEN-NAME TO MIR-DV-LBILL-CLI-NM
557668         MOVE L0620-SCREEN-NAME TO MIR-DV-OWN-CLI-NM

           END-IF.

           IF  L2435-RETRN-OK
           AND WS-BUS-FCN-BILLCHG
               MOVE ZERO              TO L5052-LBILL-REC-TYP-CD
               MOVE MIR-CLI-ID        TO L5052-LBILL-CLI-ID
               MOVE WWKDT-HIGH-DT     TO L5052-LBILL-EFF-DT
               PERFORM 5052-1000-LISTBILL-INFO
                  THRU 5052-1000-LISTBILL-INFO-X
               IF L5052-RETRN-OK
                  MOVE L5052-LBILL-STAT-CD
                                      TO MIR-LBILL-STAT-CD
               END-IF
           END-IF.

016108     IF  L2435-RETRN-OK
016108         PERFORM  0985-1000-BUILD-PARM-INFO
016108             THRU 0985-1000-BUILD-PARM-INFO-X
016108
016108         MOVE MIR-CLI-ID         TO L0985-CLI-ID
016108         MOVE WGLOB-PROCESS-DATE TO L0985-EFF-DT
016108
016108         PERFORM  0985-3000-VAL-CLI-DT-OF-DTH
016108             THRU 0985-3000-VAL-CLI-DT-OF-DTH-X
016108
016108         IF  NOT L0985-RETRN-OK
016108             MOVE 1              TO WGLOB-MSG-ERROR-SW
016108         END-IF
016108     END-IF.

           PERFORM 5600-1000-BUILD-PARM-INFO
              THRU 5600-1000-BUILD-PARM-INFO-X.
016387*    SET  L5600-GEN-CNSLDT-MSG-WARN   TO TRUE.
           MOVE MIR-CLI-ID            TO L5600-CLI-ID.
           PERFORM 5600-1000-CLI-CHK
              THRU 5600-1000-CLI-CHK-X.

023436     IF  MIR-PCHST-EFF-DT > SPACES
023436     AND MIR-PCHST-EFF-DT NOT = EBLCH-BLANK-FIELD-CHAR
023436         MOVE MIR-PCHST-EFF-DT  TO L1640-EXTERNAL-DATE
023436         PERFORM  1640-7000-MIR-TO-INT
023436             THRU 1640-7000-MIR-TO-INT-X
023436         IF L1640-NOT-VALID
023436* MSG -  'POLICY HISTORY CHANGE DATE INVALID'
023436             MOVE 'CS50600044'  TO WGLOB-MSG-REF-INFO
023436             PERFORM  0260-1000-GENERATE-MESSAGE
023436                 THRU 0260-1000-GENERATE-MESSAGE-X
023436             MOVE WWKDT-ZERO-DT TO WS-PCHST-EFF-DT
023436         ELSE
023436             MOVE L1640-INTERNAL-DATE
023436                                TO WS-PCHST-EFF-DT
023436         END-IF
023436     ELSE
023436         MOVE WWKDT-ZERO-DT     TO WS-PCHST-EFF-DT
023436     END-IF.

       9200-CHECK-KEY-FIELDS-X.
           EXIT.
      /
018633*--------------------
018633*9300-BUILD-TWRK-KEY.
018633*--------------------
018633*
018633*    MOVE WS-TWRK-KEY               TO  L8090-BUS-FCN-ID.
018633*    MOVE ZEROS                     TO  L8090-TEMP-WRK-SEQ-NUM.
018633*    SET  L8090-USAGE-COMM          TO  TRUE.
018633*
018633*9300-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9400-RETRIEVE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9300-BUILD-TWRK-KEY
018633*        THRU 9300-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-2000-RETRIEVE-TWRK
018633*        THRU 8090-2000-RETRIEVE-TWRK-X.
018633*
018633*
018633*9400-RETRIEVE-TWRK-X.
018633*    EXIT.
018633*
018633*----------------
018633*9500-WRITE-TWRK.
018633*----------------
018633*
018633*    PERFORM  9300-BUILD-TWRK-KEY
018633*        THRU 9300-BUILD-TWRK-KEY-X.
018633*
018633*    MOVE LENGTH OF WS-TWRK-AREA TO L8090-AREA-LEN.
018633*    MOVE WS-TWRK-AREA           TO L8090-AREA-INFO-TEXT.
018633*
018633*    PERFORM  8090-1000-WRITE-TWRK
018633*        THRU 8090-1000-WRITE-TWRK-X.
018633*
018633*9500-WRITE-TWRK-X.
018633*    EXIT.
018633*
018633*-----------------
018633*9600-DELETE-TWRK.
018633*-----------------
018633*
018633*    PERFORM  9300-BUILD-TWRK-KEY
018633*        THRU 9300-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-3000-DELETE-TWRK
018633*        THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*
018633*9600-DELETE-TWRK-X.
018633*    EXIT.
018633*
      ************************
       9700-BLANK-DATA-FIELDS.
      ************************

           MOVE SPACES                TO MIR-DV-SELCT-CD-G.

           IF WS-BUS-FCN-BILLCHG
               MOVE SPACES            TO MIR-POL-BILL-TYP-CD
               MOVE SPACES            TO MIR-POL-BILL-MODE-CD
016395*        MOVE SPACES            TO MIR-POL-PAC-DRW-DY
016395         MOVE SPACES            TO MIR-POL-PMT-DRW-DY
               MOVE SPACES            TO MIR-BILL-LEAD-TIME-DUR
               MOVE SPACES            TO MIR-POL-CLI-REL-TYP-CD
019859*        MOVE SPACES            TO MIR-CLI-ID
               MOVE SPACES            TO MIR-DV-CLI-ID
               MOVE SPACES            TO MIR-POL-CLI-REL-SUB-CD
               MOVE SPACES            TO MIR-POL-RBILL-CD
               MOVE SPACES            TO MIR-RBILL-DEPT-ID
               MOVE SPACES            TO MIR-RBILL-MISC-1-CD
               MOVE SPACES            TO MIR-RBILL-MISC-2-CD
               MOVE SPACES            TO MIR-RBILL-EFF-DT
               MOVE SPACES            TO MIR-RBILL-END-DT
010418         MOVE SPACES            TO MIR-SBSDRY-CO-ID-G
               MOVE SPACES            TO MIR-POL-BILL-TYP-CD-G
               MOVE SPACES            TO MIR-POL-BILL-MODE-CD-G
016395*        MOVE SPACES            TO MIR-POL-PAC-DRW-DY-G
016395         MOVE SPACES            TO MIR-POL-PMT-DRW-DY-G
               MOVE SPACES            TO MIR-BILL-LEAD-TIME-DUR-G
               MOVE SPACES            TO MIR-POL-CLI-REL-TYP-CD-G
               MOVE SPACES            TO MIR-CLI-ID-G
               MOVE SPACES            TO MIR-POL-CLI-REL-SUB-CD-G
               MOVE SPACES            TO MIR-POL-RBILL-CD-G
               MOVE SPACES            TO MIR-RBILL-DEPT-ID-G
               MOVE SPACES            TO MIR-RBILL-MISC-1-CD-G
               MOVE SPACES            TO MIR-RBILL-MISC-2-CD-G
               MOVE SPACES            TO MIR-RBILL-EFF-DT-G
               MOVE SPACES            TO MIR-RBILL-END-DT-G
               MOVE SPACES            TO MIR-POL-CSTAT-CD-G
           END-IF.

           IF WS-BUS-FCN-MISCHG
               MOVE SPACES            TO MIR-SERV-AGT-ID
               MOVE SPACES            TO MIR-POL-NFO-CD
               MOVE SPACES            TO MIR-POL-DIV-OPT-CD
023436         MOVE SPACES            TO MIR-POL-DIV-XCES-CD
019859*        MOVE SPACES            TO MIR-CLI-ID
019859         MOVE SPACES            TO MIR-DV-CLI-ID
               MOVE SPACES            TO MIR-CLI-ADDR-TYP-CD
               MOVE SPACES            TO MIR-POL-CLI-REL-SUB-CD
010418         MOVE SPACES            TO MIR-SBSDRY-CO-ID-G
               MOVE SPACES            TO MIR-POL-CSTAT-CD-G
               MOVE SPACES            TO MIR-SERV-AGT-ID-G
               MOVE SPACES            TO MIR-POL-NFO-CD-G
               MOVE SPACES            TO MIR-POL-DIV-OPT-CD-G
023436         MOVE SPACES            TO MIR-POL-DIV-XCES-CD-G
               MOVE SPACES            TO MIR-CLI-ID-G
               MOVE SPACES            TO MIR-CLI-ADDR-TYP-CD-G
               MOVE SPACES            TO MIR-POL-CLI-REL-SUB-CD-G
           END-IF.

           IF WS-BUS-FCN-LBILCHG
               MOVE SPACES            TO MIR-POL-BILL-TYP-CD
               MOVE SPACES            TO MIR-POL-BILL-MODE-CD
016395*        MOVE SPACES            TO MIR-POL-PAC-DRW-DY
016395         MOVE SPACES            TO MIR-POL-PMT-DRW-DY
               MOVE SPACES            TO MIR-BILL-LEAD-TIME-DUR
010418         MOVE SPACES            TO MIR-SBSDRY-CO-ID-G
               MOVE SPACES            TO MIR-DV-OWN-CLI-NM-G
               MOVE SPACES            TO MIR-POL-CSTAT-CD-G
               MOVE SPACES            TO MIR-POL-PD-TO-DT-NUM-G
               MOVE SPACES            TO MIR-POL-BILL-TYP-CD-G
               MOVE SPACES            TO MIR-POL-BILL-MODE-CD-G
016395*        MOVE SPACES            TO MIR-POL-PAC-DRW-DY-G
016395         MOVE SPACES            TO MIR-POL-PMT-DRW-DY-G
               MOVE SPACES            TO MIR-BILL-LEAD-TIME-DUR-G
           END-IF.

       9700-BLANK-DATA-FIELDS-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2480-0000-INIT-PARM-INFO
025970         THRU 2480-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2625-0000-INIT-PARM-INFO
025970         THRU 2625-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4780-0000-INIT-PARM-INFO
025970         THRU 4780-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5052-0000-INIT-PARM-INFO
025970         THRU 5052-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5061-0000-INIT-PARM-INFO
025970         THRU 5061-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5063-0000-INIT-PARM-INFO
025970         THRU 5063-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5065-0000-INIT-PARM-INFO
025970         THRU 5065-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     MOVE SPACES                TO WWKDT-WORK-FIELDS.
025970     SET WS-TRANS-NAME-DEFAULT  TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
018764*COPY CCCL0985.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

020478 COPY CCPPFCCK.
025970 COPY XCPS1670.
025970 COPY CCPS5052.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
018764 COPY CCPL0985.
016108 COPY CCPS0985.
016108*
018764*COPY CCCL2430.
018764 COPY CCPL2430.
       COPY CCPS2430.
      *
018764*COPY CCCL2435.
018764 COPY CCPL2435.
       COPY CCPS2435.
020478 COPY CCPL2625.
020478 COPY CCPS2625.
023436/
023436 COPY CCPL4780.
023436 COPY CCPS4780.
023436/
018764*COPY CCCL5600.
018764 COPY CCPL5600.
       COPY CCPS5600.
      *
       COPY CCPSPGA.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
025970 COPY XCPS0280.
       COPY XCPL0280.
020874 COPY XCPL0290.
020874 COPY XCPS0290.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
023435 COPY XCPL1660.
025970 COPY XCPS1680.
023435 COPY XCPL1680.
      *
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
018633 COPY XCPSCOMM.
018633 COPY XCPPCOMM.
018633
014221 COPY CCPPMNTS REPLACING ==:VAR1:== BY POL
014221                             '$VAR2' BY 'POL'.
      *
018764*COPY CCCL5052.
018764 COPY CCPL5052.
      *
018764*COPY CCCL5061.
018764 COPY CCPL5061.
       COPY CCPS5061.

018764*COPY CCCL5063.
018764 COPY CCPL5063.
       COPY CCPS5063.

018764*COPY CCCL5065.
018764 COPY CCPL5065.
       COPY CCPS5065.
      *
557756*COPY XCCL2510.
557756*COPY XCPS2510.
      *
018764*COPY XCCL8090.
018633 COPY XCPS8090.
018764 COPY XCPL8090.
016537*COPY XCPS8090.
      *
557788 COPY CCPS2480.
018764*COPY CCCL2480.
018764 COPY CCPL2480.
      *
025970 COPY CCPS0620.
557668 COPY CCPL0620.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNPOL.
014221 COPY CCPUPOL.
023436*
023436 COPY CCPNCVG.
023436 COPY NCPPCVGS.
      *
       COPY CCPNPOLC.
      *
023435 COPY CCPBPHST.
023435*
       COPY CCPBRL.
016537*COPY CCPVRL.
      *
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM5060                     **
      *****************************************************************
