      *************************
       IDENTIFICATION DIVISION.
      *************************
      *
       PROGRAM-ID. CSOM0152.
      *
       COPY XCWWCRHT.
      *
      *****************************************************************
      **  MEMBER :  CSOM0152                                         **
      **  REMARKS:  PCOV - PROTECTED COVERAGE MAINTENANCE.           **
      **            THIS PROCESS DRIVER IS USED TO UPDATE FINANCIAL  **
      **            BALANCES AND SYSTEM CONTROL FIELDS ON THE CVG    **
      **            TABLE. ANOTHER MODULE IS CALLED TO UPDATE        **
      **            AGENT-RELATED INFORMATION STORED ON THE CVGA     **
      **            TABLE.                                           **
      **                                                             **
      **  DOMAIN :  CV                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
555744**  5.5       DO NOT ALLOW COVERAGE 00                         **
557659**  5.5       DATA ARCHITECTURE CHANGE                         **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557668**  5.5       NEW NAME FORMATTING                              **
557699**  5.5       NEW DATA AUDIT                                   **
557708**  5.5       ABEND HANDLING                                   **
557973**  5.5       AMOUNT FIELD SIZING FOR INTL SUPPORT             **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010302**  5.6       DATA ARCHITECTURE CHANGE                         **
010311**  5.6       CODE CLEAN UP                                    **
010314**  5.6       EQUITY INDEXED ANNUITIES                         **
010418**  5.6       ADD SUB-COMPANY-CODE FIELD                       **
012138**  5.6V      SEC GUIDLINE ANNUAL PRIMIUMS PROCESSING          **
012145**  5.6V      ADD LOAN COLLATERAL FUND INDICATOR               **
012146**  5.6V      ADD UNIT-TYPE                                    **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014591**  6.0       COMBINE TWO PART FIELDS                          **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
014221**  6.2       LOGICAL LOCKING                                  **
016440**  6.2       NB/AD CONSOLIDATION                              **
016503**  6.2       SCHEDULING ENHANCEMENT                           **
016306**  6.3       MORTGAGE BACKED DECREASING TERM (6.1.1E)         **
018412**  6.3       FIXED ALLOWING TO ENTER PERCENT > 100            **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018770**  6.3       PCR - ALLOWABLE VALUE EDIT                       **
018846**  6.3       TAXABLE OVERFLOW (SHUTTLE) ACCOUNT SUPPORT       **
019297**  6.3       GENERATE CURRENCY MSG                            **
020180**  6.3       CHANGE TO ALLOW RETRIEVE IF CURRENCY NOT MATCH   **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020074**  6.4       ALLOWED VALUE FOR POL STATUS                     **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021239**  6.4       FUND UNIT VALUE                                  **
020475**  6.4       DEATH BENEFIT GUARANTEES AND RIDERS              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
031037**  7.0       TAMRA OFF ANNIVERSARY PROCESSING                 **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
035393**  7.1       CITS TRANSMITTAL                                 **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0152'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      *

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

007766 COPY XCWWCVGM.

       01  WS-PGM-WORK-AREA.
013578     05  WS-BUS-FCN-ID                PIC X(04).
013578         88  WS-BUS-FCN-RETRIEVE      VALUE '1970'.
013578         88  WS-BUS-FCN-UPDATE        VALUE '1972'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '1970'.
           05  HOLD-RIDER                   PIC X(02).
           05  PART-ADV-TYPE                PIC X(01).
557973*    05  PART-ADV-NUM                 PIC 9(05)V99.
557973     05  PART-ADV-NUM                 PIC 9(11)V99.
           05  POLICY-HOLD.
               10  POLICY-FIRST             PIC X(01).
               10  POLICY-MID               PIC X(8).
               10  POLICY-LAST              PIC X(01).
035393     05  WS-INDEX                     PIC S9(5) COMP-3.
      *
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '1970'.
025970     05  CV-DATE                      PIC X(10).
025970         88 CV-DATE-DEFAULT           VALUE '0000-00-00'.
025970
       01  VALID-INPUT-SWITCH               PIC X(01).
           88  INPUT-VALID                              VALUE 'Y'.
           88  INPUT-NOT-VALID                          VALUE 'N'.
      *
       01  VALID-POLICY-SWITCH              PIC X(01).
           88  POLICY-VALID                             VALUE 'Y'.
           88  POLICY-NOT-VALID                         VALUE 'N'.
      *
       01  VALID-RIDER-SWITCH               PIC X(01).
           88  RIDER-VALID                              VALUE 'Y'.
           88  RIDER-NOT-VALID                          VALUE 'N'.
      *
018763*01  WS-CVG-INT-CMPND-CD              PIC X(03).
018763*    88  WS-CVG-INT-CMPND-VALID                   VALUE
018763 01  WS-INT-CMPND-FREQ-CD             PIC X(01).
018763     88  WS-INT-CMPND-FREQ-VALID                  VALUE
018763*             '365' '052' '012' '004' '002' '001' '   '.
018763              'A' 'D' 'M' 'N' 'Q' 'S' 'W'.
016306 01  WS-MTG-REPAY-FREQ-CD             PIC X(01).
016306     88  WS-MTG-REPAY-FREQ-VALID                  VALUE
018763*                           'W' 'B' 'M' 'Q' 'S' 'A' ' '.
018763                            'W' 'B' 'M' 'Q' 'S' 'A' 'N'.
      *
       01  UPDATE-NEEDED-SWITCH             PIC X(01).
           88  UPDATE-NEEDED                            VALUE 'Y'.
           88  UPDATE-NOT-NEEDED                        VALUE 'N'.
      *
       01  UPDATE-AGENT-SWITCH              PIC X(01).
           88  UPDATE-AGENT                             VALUE 'Y'.
           88  UPDATE-AGENT-NO                          VALUE 'N'.
      *
       01  UPDATE-CVG-AGENTS-SWITCH         PIC X(01).
           88  UPDATE-CVG-AGENTS                        VALUE 'Y'.
           88  UPDATE-CVG-AGENTS-NO                     VALUE 'N'.
      *
       COPY CCWWINDX.
       COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      *
      *
025970*01  CV-DATE                 PIC X(10) VALUE '0000-00-00'.
      *
028298 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWL1640.
020074*COPY CCWTSTCD.
       COPY XCWEBLCH.
      *

      *-----------------------------------------------------------------
      * DISPLAY FIELDS FOR NUMERICS ON PCOV
      *-----------------------------------------------------------------

       01  WS-DISPLAY-FIELD-DEFINITIONS.
013578*    03  WS-DISP-1-0.
013578*        05  WS-HOLD-1-0          PIC 9(1).
013578*    03  WS-DISP-2-0.
013578*        05  WS-HOLD-2-0          PIC 9(2).
013578*    03  WS-DISP-2-7.
013578*        05  WS-HOLD-2-7          PIC 9(2).9(7).
           03  WS-DISP-3-0.
               05  WS-HOLD-3-0          PIC 9(3).
008455*    03  WS-DISP-3-2.
008455*        05  WS-HOLD-3-2          PIC 9(3).99.
008455*    03  WS-DISP-4-0.
008455*        05  WS-HOLD-4-0          PIC 9(4).
008455*    03  WS-DISP-5-2.
008455*        05  WS-HOLD-5-2          PIC 9(5).9(2).
008455*    03  WS-DISP-5-2-S.
008455*        05  WS-HOLD-5-2-S        PIC 9(5).9(2)-.
008455*    03  WS-DISP-7-0.
008455*        05  WS-HOLD-7-0          PIC 9(7).
008455*    03  WS-DISP-7-2.
008455*        05  WS-HOLD-7-2          PIC 9(7).9(2).
008455*    03  WS-DISP-7-2-S.
008455*        05  WS-HOLD-7-2-S        PIC 9(7).9(2)-.
008455*    03  WS-DISP-S7-2.
008455*        05  WS-HOLD-S7-2         PIC +9(7).9(2).
008455*    03  WS-DISP-S9.
008455*        05  WS-HOLD-S9           PIC +9(9).
008455*    03  WS-DISP-9-2.
008455*        05  WS-HOLD-9-2          PIC 9(9).9(2).
008455*    03  WS-DISP-S9-2.
008455*        05  WS-HOLD-S9-2         PIC +9(9).9(2).
008455*    03  WS-DISP-11-2.
008455*        05  WS-HOLD-11-2         PIC 9(11).9(2).
008455*    03  WS-DISP-S11-2.
008455*        05  WS-HOLD-S11-2        PIC +9(11).9(2).

      *---- WORKING STORAGE LAYOUTS FOR THE FILES
      *
016503 COPY CCWL0289.
557668 COPY CCWL0620.
       COPY CCWL2430.
       COPY CCWL2450.
       COPY CCWL5400.
035393 COPY CCWLCITC.
      *
       COPY CCFWCVG.
       COPY CCFRCVG.
      *
021239 COPY CCFWEDIT.
021239 COPY CCFREDIT.
021239
018770*COPY XCFWDMAD.
018770*COPY XCFRDMAD.
018770*
       COPY CCFWPOL.
      *
       COPY XCWL0280.
008455*
008455 COPY XCWL0290.
      *
035393 COPY XCWL0319.
035393*
014221 COPY XCWL8090.
      *
018770 COPY XCWL8960.
018770
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      *
016503 COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      *
       LINKAGE SECTION.

CVMQ71 COPY XCWWDFH.
      *
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0152.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *
      *****************
       0000-MAINLINE.
      *****************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      ****************************
       2000-PROCESS-REQUEST.
      ****************************

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.
008455
           PERFORM  9400-SETUP-MSIN-REFERENCE
               THRU 9400-SETUP-MSIN-REFERENCE-X.

013578     MOVE MIR-CVG-NUM           TO L0280-INPUT-DATA.
013578     MOVE ZERO                  TO L0280-PRECISION.
013578     MOVE LENGTH OF MIR-CVG-NUM TO L0280-INPUT-SIZE.
013578     MOVE L0280-INPUT-SIZE      TO L0280-LENGTH.
013578     PERFORM  0280-1000-NUMERIC-EDIT
013578         THRU 0280-1000-NUMERIC-EDIT-X.
013578*
013578     IF L0280-OK
020874*        IF L0280-OUTPUT = ZERO
020874*            MOVE 1             TO L0290-INPUT-NUMBER
020874*        ELSE
020874*            MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
020874*        END-IF
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
013578         MOVE ZERO              TO L0290-PRECISION
013578         MOVE LENGTH OF MIR-CVG-NUM TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
013578         MOVE L0290-OUTPUT-DATA TO MIR-CVG-NUM
013578     END-IF.
013578*
           IF  MIR-CVG-NUM NUMERIC
           AND MIR-CVG-NUM > ZERO
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE '01'              TO MIR-CVG-NUM
555744* MSG: COVERAGE NUMBER MUST BE NUMERIC IN THE RANGE 01-20
007766* MSG: COVERAGE NUMBER MUST BE NUMERIC IN THE RANGE 01-@1
555744         MOVE 'CS01520001'      TO WGLOB-MSG-REF-INFO
555744*        MOVE 'CS00000055'            TO WGLOB-MSG-REF-INFO
007766         MOVE WCVGM-MAX-WCVGS-NUM
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           MOVE MIR-POL-ID-BASE       TO POLICY-HOLD.
           MOVE MIR-POL-ID-SFX        TO POLICY-LAST.
           MOVE MIR-CVG-NUM           TO HOLD-RIDER.
           MOVE MIR-CVG-NUM           TO I.
           MOVE MIR-CVG-NUM           TO WCVG-CVG-NUM-N.

           MOVE POLICY-HOLD           TO WPOL-POL-ID.
           MOVE WPOL-POL-ID           TO WCVG-POL-ID.

           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           EVALUATE TRUE
               WHEN WS-BUS-FCN-RETRIEVE
                   PERFORM  3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X
               WHEN WS-BUS-FCN-UPDATE
                   PERFORM  4000-PROCESS-UPDATE
                       THRU 4000-PROCESS-UPDATE-X
               WHEN OTHER
                   SET MIR-RETRN-INVALD-RQST TO TRUE
           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      **********************
       3000-PROCESS-RETRIEVE.
      **********************

           PERFORM  8000-GET-POLICY-MASTER
               THRU 8000-GET-POLICY-MASTER-X.

           IF  POLICY-VALID
               PERFORM  8100-GET-RIDER
                   THRU 8100-GET-RIDER-X
               IF RIDER-VALID
                   PERFORM  8200-MOVE-RIDER-INFO
                       THRU 8200-MOVE-RIDER-INFO-X
                   PERFORM  CVG-3000-UNLOCK
                       THRU CVG-3000-UNLOCK-X
557660         END-IF
557660     END-IF.

           IF  RIDER-VALID
           AND POLICY-VALID
013578         CONTINUE
           ELSE
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
557660     END-IF.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      *
      **********************
       4000-PROCESS-UPDATE.
      **********************

           PERFORM  8000-GET-POLICY-MASTER
               THRU 8000-GET-POLICY-MASTER-X.

016440     IF  POLICY-VALID
016440         CONTINUE
016440     ELSE
016440         PERFORM  9100-BLANK-DATA-FIELDS
016440             THRU 9100-BLANK-DATA-FIELDS-X
014221         IF  NOT MIR-RETRN-TS-MISMATCH
016440             PERFORM  POL-3000-UNLOCK
016440                 THRU POL-3000-UNLOCK-X
014221         END-IF
016440         GO TO 4000-PROCESS-UPDATE-X
016440     END-IF.

           PERFORM  8100-GET-RIDER
               THRU 8100-GET-RIDER-X.

           PERFORM  5000-EDIT-INPUT
               THRU 5000-EDIT-INPUT-X.

           PERFORM  6000-PROCESS-INPUT
               THRU 6000-PROCESS-INPUT-X.

           PERFORM  4100-CROSS-CHECKS
               THRU 4100-CROSS-CHECKS-X.

013578     PERFORM  2430-1000-BUILD-PARM-INFO
013578         THRU 2430-1000-BUILD-PARM-INFO-X.
013578     PERFORM  2430-2100-GET-OWNER
013578         THRU 2430-2100-GET-OWNER-X.
013578
013578     INITIALIZE L0620-INPUT-PARM-INFO.
013578
013578     IF L2430-CLI-SEX-COMPANY
013578         MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
013578     ELSE
013578         MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
013578         MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
013578         MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
013578         MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
013578     END-IF.
013578
013578     MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD.
013578
013578     PERFORM  0620-1000-FORMAT-SCREEN-NAME
013578         THRU 0620-1000-FORMAT-SCREEN-NAME-X.
013578
013578     MOVE L0620-SCREEN-NAME     TO MIR-DV-INSRD-CLI-NM.

       4000-PROCESS-UPDATE-X.
           EXIT.
      *
      *******************
       4100-CROSS-CHECKS.
      *******************

557659*    IF WCVGS-CVG-XHBT-ISS-IND-N (I) > 1
557659     IF  WCVGS-CVG-XHBT-ISS-IND (I) NOT = 'Y'
557659     AND WCVGS-CVG-XHBT-ISS-IND (I) NOT = 'N'
              MOVE 'CS01520035'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           IF WCVGS-CVG-XHBT-TRMN-QTY-N (I)
              < WCVGS-XHBT-REINST-QTY-N (I)
              MOVE 'CS01520036'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           COMPUTE J = WCVGS-CVG-XHBT-TRMN-QTY-N (I)
                     - WCVGS-XHBT-REINST-QTY-N (I)
           IF J > 1
              MOVE 'CS01520037'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4100-CROSS-CHECKS-X.
           EXIT.
      *
      ******************
       5000-EDIT-INPUT.
      ******************

           SET INPUT-VALID                  TO TRUE.
           SET UPDATE-NOT-NEEDED            TO TRUE.

           PERFORM  5100-EDIT-SCREEN-01
               THRU 5100-EDIT-SCREEN-01-X
           PERFORM  5200-EDIT-SCREEN-02
               THRU 5200-EDIT-SCREEN-02-X.

       5000-EDIT-INPUT-X.
           EXIT.

      *
      *********************
       5100-EDIT-SCREEN-01.
      *********************

           PERFORM  5101-EDIT-CSTAT
               THRU 5101-EDIT-CSTAT-X.

           PERFORM  5102-EDIT-OLDSTAT
               THRU 5102-EDIT-OLDSTAT-X.

           PERFORM  5103-EDIT-STAT-CHG-DATE
               THRU 5103-EDIT-STAT-CHG-DATE-X.

010302*    PERFORM  5104-EDIT-ADJ-DATE
010302*        THRU 5104-EDIT-ADJ-DATE-X.

           PERFORM  5105-EDIT-TYPE-OF-INSURANCE
               THRU 5105-EDIT-TYPE-OF-INSURANCE-X.

           PERFORM  5106-EDIT-ACCT-TYPE
               THRU 5106-EDIT-ACCT-TYPE-X.

           PERFORM  5107-EDIT-CONV
               THRU 5107-EDIT-CONV-X.

           PERFORM  5108-EDIT-NET-CHANGE
               THRU 5108-EDIT-NET-CHANGE-X.

           PERFORM  5128-EDIT-URATE
               THRU 5128-EDIT-URATE-X.

           PERFORM  5109-EDIT-OPLAN
               THRU 5109-EDIT-OPLAN-X.

           PERFORM  5110-EDIT-REPMDRT
               THRU 5110-EDIT-REPMDRT-X.

           PERFORM  5111-EDIT-REPFYC
               THRU 5111-EDIT-REPFYC-X.

           PERFORM  5112-EDIT-FACE-AMOUNT
               THRU 5112-EDIT-FACE-AMOUNT-X.

           PERFORM  5113-EDIT-FACE
               THRU 5113-EDIT-FACE-X.

           PERFORM  5114-EDIT-LAST-PREMIUM
               THRU 5114-EDIT-LAST-PREMIUM-X.

           PERFORM  5115-EDIT-NEXT-PREMIUM
               THRU 5115-EDIT-NEXT-PREMIUM-X.

010302*    PERFORM  5116-EDIT-LWPRATE
010302*        THRU 5116-EDIT-LWPRATE-X.

           PERFORM  5129-EDIT-WCUR
               THRU 5129-EDIT-WCUR-X.

           PERFORM  5130-EDIT-WTOT
               THRU 5130-EDIT-WTOT-X.

           PERFORM  5117-EDIT-CLCUR
               THRU 5117-EDIT-CLCUR-X.

           PERFORM  5118-EDIT-CLTOT
               THRU 5118-EDIT-CLTOT-X.

           SET UPDATE-CVG-AGENTS-NO TO TRUE.

           PERFORM  2450-1000-BUILD-PARM-INFO
               THRU 2450-1000-BUILD-PARM-INFO-X
           PERFORM  2450-2000-READ-CVG-AGENTS
               THRU 2450-2000-READ-CVG-AGENTS-X.

018763*    PERFORM  5119-EDIT-AGENT-INFO
018763*        THRU 5119-EDIT-AGENT-INFO-X
018763     PERFORM  5136-EDIT-AGENT-INFO
018763         THRU 5136-EDIT-AGENT-INFO-X
               VARYING J FROM 1 BY 1
               UNTIL J > 3.

           IF  UPDATE-CVG-AGENTS
               PERFORM  2450-4000-UPDT-CVG-AGENTS
                   THRU 2450-4000-UPDT-CVG-AGENTS-X
557660     END-IF.

           PERFORM  5131-EDIT-ORGFACE
               THRU 5131-EDIT-ORGFACE-X.

           PERFORM  5132-EDIT-SMINSRD
               THRU 5132-EDIT-SMINSRD-X.

           PERFORM  5120-EDIT-CVG-XHBT-ISS-IND
               THRU 5120-EDIT-CVG-XHBT-ISS-IND-X.

           PERFORM  5121-EDIT-CVG-XHBT-ISS-DT
               THRU 5121-EDIT-CVG-XHBT-ISS-DT-X.

           PERFORM  5122-EDIT-CVG-XHBT-TRMN-QTY
               THRU 5122-EDIT-CVG-XHBT-TRMN-QTY-X.

           PERFORM  5123-EDIT-CVG-XHBT-TRMN-DT
               THRU 5123-EDIT-CVG-XHBT-TRMN-DT-X.

           PERFORM  5124-EDIT-XHBT-REINST-QTY
               THRU 5124-EDIT-XHBT-REINST-QTY-X.

           PERFORM  5125-EDIT-CVG-XHBT-REINST-DT
               THRU 5125-EDIT-CVG-XHBT-REINST-DT-X.

           PERFORM  5126-EDIT-APP-COM-DT
               THRU 5126-EDIT-APP-COM-DT-X.

           PERFORM  5127-EDIT-EARLY-DATE
               THRU 5127-EDIT-EARLY-DATE-X.

012145     PERFORM  5133-EDIT-LCF
012145         THRU 5133-EDIT-LCF-X.

012146     PERFORM  5135-EDIT-UNTTYP
012146         THRU 5135-EDIT-UNTTYP-X.

020475     PERFORM  5140-EDIT-DBG-INCL
020475         THRU 5140-EDIT-DBG-INCL-X.

       5100-EDIT-SCREEN-01-X.
           EXIT.
      *
      *----------------
       5101-EDIT-CSTAT.
      *----------------

           IF  MIR-CVG-CSTAT-CD =  SPACES
               MOVE WCVGS-CVG-CSTAT-CD (I)
                                      TO MIR-CVG-CSTAT-CD
               GO TO 5101-EDIT-CSTAT-X
557660     END-IF.

           IF  MIR-CVG-CSTAT-CD =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CVG-CSTAT-CD
557660     END-IF.

020074*    MOVE MIR-CVG-CSTAT-CD      TO STATUS-FIND-CODE.
020074*
020074*    PERFORM  STCD-1000-FIND
020074*        THRU STCD-1000-FIND-X.
020074*
020074*    IF  NOT STATUS-DATA-VALID
020074*        SET INPUT-NOT-VALID          TO TRUE
020074*        MOVE 'CS01520002'      TO WGLOB-MSG-REF-INFO
020074*        PERFORM  0260-1000-GENERATE-MESSAGE
020074*            THRU 0260-1000-GENERATE-MESSAGE-X
020074*    ELSE
020074*        SET UPDATE-NEEDED            TO TRUE
020074*        MOVE MIR-CVG-CSTAT-CD  TO WCVGS-CVG-CSTAT-CD (I)
020074*    END-IF.
020074
020074     PERFORM  8960-1000-BUILD-PARM-INFO
020074         THRU 8960-1000-BUILD-PARM-INFO-X.
020074
020074     MOVE 'CVG-CSTAT-CD'              TO L8960-AV-TBL-CD.
020074     MOVE MIR-CVG-CSTAT-CD            TO L8960-AV-CD.
020074
020074     PERFORM  8960-1000-VALIDATE-CODE
020074         THRU 8960-1000-VALIDATE-CODE-X.
020074
020074     IF  L8960-RETRN-OK
020074         SET UPDATE-NEEDED            TO TRUE
035393         IF  MIR-CVG-CSTAT-CD NOT = WCVGS-CVG-CSTAT-CD (I)
035393         AND NOT RPOL-POL-STAT-IN-FORCE
035393             PERFORM  6100-CCHG-EVENT
035393                 THRU 6100-CCHG-EVENT-X
035393         END-IF
020074         MOVE MIR-CVG-CSTAT-CD        TO WCVGS-CVG-CSTAT-CD (I)
020074     ELSE
020074         SET INPUT-NOT-VALID          TO TRUE
020074         MOVE 'CS01520002'            TO WGLOB-MSG-REF-INFO
020074         PERFORM  0260-1000-GENERATE-MESSAGE
020074             THRU 0260-1000-GENERATE-MESSAGE-X
020074     END-IF.

       5101-EDIT-CSTAT-X.
           EXIT.
      *
      *------------------
       5102-EDIT-OLDSTAT.
      *------------------

           IF  MIR-CVG-PREV-CSTAT-CD = SPACES
               MOVE WCVGS-CVG-PREV-CSTAT-CD (I)
                                      TO MIR-CVG-PREV-CSTAT-CD
               GO TO 5102-EDIT-OLDSTAT-X
557660     END-IF.

           IF  MIR-CVG-PREV-CSTAT-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CVG-PREV-CSTAT-CD
557660     END-IF.

020074*    MOVE MIR-CVG-PREV-CSTAT-CD TO STATUS-FIND-CODE.
020074*
020074*    PERFORM  STCD-1000-FIND
020074*        THRU STCD-1000-FIND-X.
020074*
020074*    IF  NOT STATUS-DATA-VALID
020074*        SET INPUT-NOT-VALID     TO TRUE
020074*        MOVE 'CS01520003'      TO WGLOB-MSG-REF-INFO
020074*        PERFORM  0260-1000-GENERATE-MESSAGE
020074*            THRU 0260-1000-GENERATE-MESSAGE-X
020074*    ELSE
020074*        SET UPDATE-NEEDED       TO TRUE
020074*        MOVE MIR-CVG-PREV-CSTAT-CD
020074*                               TO WCVGS-CVG-PREV-CSTAT-CD (I)
020074*    END-IF.
020074
020074     PERFORM  8960-1000-BUILD-PARM-INFO
020074         THRU 8960-1000-BUILD-PARM-INFO-X.
020074
020074     MOVE 'CVG-CSTAT-CD'         TO L8960-AV-TBL-CD.
020074     MOVE MIR-CVG-PREV-CSTAT-CD  TO L8960-AV-CD.
020074
020074     PERFORM  8960-1000-VALIDATE-CODE
020074         THRU 8960-1000-VALIDATE-CODE-X.
020074
020074     IF  L8960-RETRN-OK
020074         SET UPDATE-NEEDED       TO TRUE
020074         MOVE MIR-CVG-PREV-CSTAT-CD
020074                                 TO WCVGS-CVG-PREV-CSTAT-CD (I)
020074     ELSE
020074         SET INPUT-NOT-VALID     TO TRUE
020074         MOVE 'CS01520003'       TO WGLOB-MSG-REF-INFO
020074         PERFORM  0260-1000-GENERATE-MESSAGE
020074             THRU 0260-1000-GENERATE-MESSAGE-X
020074     END-IF.

       5102-EDIT-OLDSTAT-X.
           EXIT.
      *

      *------------------------
       5103-EDIT-STAT-CHG-DATE.
      *------------------------
           IF MIR-CVG-STAT-PRCES-DT = SPACES
               MOVE WCVGS-CVG-STAT-PRCES-DT (I)
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CVG-STAT-PRCES-DT
               GO TO 5103-EDIT-STAT-CHG-DATE-X
557660     END-IF.

           IF MIR-CVG-STAT-PRCES-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CVG-STAT-PRCES-DT
               MOVE WWKDT-ZERO-DT     TO WCVGS-CVG-STAT-PRCES-DT (I)
               SET UPDATE-NEEDED        TO TRUE
           ELSE
               MOVE MIR-CVG-STAT-PRCES-DT
                                      TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X
               IF L1640-NOT-VALID
                   SET INPUT-NOT-VALID      TO TRUE
                   MOVE 'CS01520004'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   SET UPDATE-NEEDED        TO TRUE
                   MOVE L1640-INTERNAL-DATE
                                      TO
                                            WCVGS-CVG-STAT-PRCES-DT (I)
557660         END-IF
557660     END-IF.

       5103-EDIT-STAT-CHG-DATE-X.
           EXIT.
      *

010302*-------------------
010302*5104-EDIT-ADJ-DATE.
010302*-------------------
010302*    IF MIR-ADJDATE = SPACES
010302*        MOVE WCVGS-CVG-ADJ-DT         (I)
010302*                                     TO L1640-INTERNAL-DATE
010302*        PERFORM 1640-2000-INTERNAL-TO-EXT
010302*           THRU 1640-2000-INTERNAL-TO-EXT-X
010302*        MOVE L1640-EXTERNAL-DATE     TO MIR-ADJDATE
010302*        GO TO 5104-EDIT-ADJ-DATE-X
010302*557660     END-IF.
010302*
010302*    IF MIR-ADJDATE = EBLCH-BLANK-FIELD-CHAR
010302*
010302*        MOVE SPACES                  TO MIR-ADJDATE
010302*        MOVE WWKDT-ZERO-DT           TO
010302*                                   WCVGS-CVG-ADJ-DT         (I)
010302*54-001         SET UPDATE-NEEDED            TO TRUE
010302*    ELSE
010302*        MOVE MIR-ADJDATE             TO L1640-EXTERNAL-DATE
010302*        PERFORM 1640-3000-EXTERNAL-TO-INT
010302*           THRU 1640-3000-EXTERNAL-TO-INT-X
010302*        IF L1640-NOT-VALID
010302*54-001             SET INPUT-NOT-VALID      TO TRUE
010302*            MOVE 'CS01520005'        TO WGLOB-MSG-REF-INFO
010302*           PERFORM  0260-1000-GENERATE-MESSAGE
010302*                THRU 0260-1000-GENERATE-MESSAGE-X
010302*        ELSE
010302*54-001             SET UPDATE-NEEDED        TO TRUE
010302*            MOVE L1640-INTERNAL-DATE TO
010302*                                   WCVGS-CVG-ADJ-DT         (I)
010302*557660         END-IF
010302*557660     END-IF.
010302*
010302*5104-EDIT-ADJ-DATE-X.
010302*    EXIT.
      *

      *----------------------------
       5105-EDIT-TYPE-OF-INSURANCE.
      *---------------------------
           IF MIR-CVG-INS-TYP-CD = SPACES
               MOVE WCVGS-CVG-INS-TYP-CD (I)
                                      TO MIR-CVG-INS-TYP-CD
           ELSE
               SET UPDATE-NEEDED            TO TRUE
               MOVE MIR-CVG-INS-TYP-CD       TO WCVGS-CVG-INS-TYP-CD (I)
557660     END-IF.

       5105-EDIT-TYPE-OF-INSURANCE-X.
           EXIT.
      *

      *--------------------
       5106-EDIT-ACCT-TYPE.
      *--------------------
           IF MIR-CVG-ACCT-TYP-CD = SPACES
               MOVE WCVGS-CVG-ACCT-TYP-CD (I)
                                      TO MIR-CVG-ACCT-TYP-CD
           ELSE
               SET UPDATE-NEEDED           TO TRUE
               MOVE MIR-CVG-ACCT-TYP-CD
                                      TO WCVGS-CVG-ACCT-TYP-CD (I)
557660     END-IF.

       5106-EDIT-ACCT-TYPE-X.
           EXIT.
      *
      *---------------
       5107-EDIT-CONV.
      *---------------
           IF MIR-CVG-CNVR-IND = SPACES
               MOVE WCVGS-CVG-CNVR-IND (I)
                                      TO MIR-CVG-CNVR-IND
               GO TO 5107-EDIT-CONV-X
557660     END-IF.

           IF MIR-CVG-CNVR-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CVG-CNVR-IND
557660     END-IF.

           IF  MIR-CVG-CNVR-IND = 'Y'
557659*    OR  MIR-CVG-CNVR-IND = ' '
557659     OR  MIR-CVG-CNVR-IND = 'N'
               SET UPDATE-NEEDED            TO TRUE
               MOVE MIR-CVG-CNVR-IND  TO WCVGS-CVG-CNVR-IND (I)
           ELSE
               SET INPUT-NOT-VALID          TO TRUE
               MOVE 'CS01520006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5107-EDIT-CONV-X.
           EXIT.
      *
      *---------------------
       5108-EDIT-NET-CHANGE.
      *---------------------
           IF MIR-CVG-NET-REISS-AMT = SPACES
008455*        MOVE WCVGS-CVG-NET-REISS-AMT (I) TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-CVG-NET-REISS-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-CVG-NET-REISS-AMT (I) * 100
020874         MOVE WCVGS-CVG-NET-REISS-AMT (I)   TO L0290-INPUT-V02
008455         MOVE 2                             TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-NET-REISS-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY            TO TRUE
008455         SET  L0290-SIGN-POS-DISPLAY        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-NET-REISS-AMT
               GO TO 5108-EDIT-NET-CHANGE-X
557660     END-IF.

           IF MIR-CVG-NET-REISS-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '000000000.00+'         TO MIR-CVG-NET-REISS-AMT
008455         MOVE  ZEROS            TO MIR-CVG-NET-REISS-AMT
557660     END-IF.

           MOVE MIR-CVG-NET-REISS-AMT TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 13                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-NET-REISS-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WCVGS-CVG-NET-REISS-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR   TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2          TO MIR-CVG-NET-REISS-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-NET-REISS-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET L0290-SIGN-DISPLAY     TO TRUE
008455         SET L0290-SIGN-POS-DISPLAY TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-NET-REISS-AMT
               SET UPDATE-NEEDED          TO TRUE
           ELSE
               SET INPUT-NOT-VALID        TO TRUE
               MOVE 'CS01520007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.


       5108-EDIT-NET-CHANGE-X.
           EXIT.
      *
      *----------------
       5109-EDIT-OPLAN.
      *----------------
014591***   IF MIR-ORIG-PLAN-BASE-ID = SPACES
014591***       MOVE WCVGS-ORIG-PLAN-BASE-ID (I)
014591***                              TO MIR-ORIG-PLAN-BASE-ID
014591***   ELSE
014591***      SET UPDATE-NEEDED         TO TRUE
014591***       MOVE MIR-ORIG-PLAN-BASE-ID
014591***                              TO WCVGS-ORIG-PLAN-BASE-ID (I)
014591      IF MIR-ORIG-PLAN-ID = SPACES
014591          MOVE WCVGS-ORIG-PLAN-ID (I) TO MIR-ORIG-PLAN-ID
014591      ELSE
014591          SET UPDATE-NEEDED           TO TRUE
014591          MOVE MIR-ORIG-PLAN-ID       TO WCVGS-ORIG-PLAN-ID (I)
557660     END-IF.
       5109-EDIT-OPLAN-X.
           EXIT.
      *
      *------------------
       5110-EDIT-REPMDRT.
      *------------------
           IF MIR-CVG-MDRT-AMT = SPACES
008455*        MOVE WCVGS-CVG-MDRT-AMT (I)  TO WS-HOLD-S9
008455*        MOVE WS-HOLD-S9               TO MIR-CVG-MDRT-AMT
020874*        MOVE WCVGS-CVG-MDRT-AMT (I)
020874*                               TO L0290-INPUT-NUMBER
020874         MOVE WCVGS-CVG-MDRT-AMT (I) TO L0290-INPUT-V00
008455         MOVE 0                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-MDRT-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY     TO TRUE
008455         SET  L0290-SIGN-POS-DISPLAY TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-MDRT-AMT
               GO TO 5110-EDIT-REPMDRT-X
557660     END-IF.

           IF MIR-CVG-MDRT-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '000000000+'            TO MIR-CVG-MDRT-AMT
008455         MOVE  ZEROS            TO MIR-CVG-MDRT-AMT
557660     END-IF.

           MOVE MIR-CVG-MDRT-AMT      TO L0280-INPUT-DATA.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           MOVE 0                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-MDRT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 1.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WCVGS-CVG-MDRT-AMT (I)
008455*        MOVE L0280-OUTPUT            TO WS-HOLD-S9
008455*        MOVE WS-DISP-S9              TO MIR-CVG-MDRT-AMT
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
008455         MOVE 0                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-MDRT-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
008455         SET  L0290-SIGN-POS-DISPLAY  TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-MDRT-AMT
               SET UPDATE-NEEDED            TO TRUE
           ELSE
               SET INPUT-NOT-VALID          TO TRUE
               MOVE 'CS01520008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       5110-EDIT-REPMDRT-X.
           EXIT.
      *

      *-----------------
       5111-EDIT-REPFYC.
      *-----------------
           IF MIR-CVG-FYR-COMM-AMT = SPACES
008455*        MOVE WCVGS-CVG-FYR-COMM-AMT (I) TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-CVG-FYR-COMM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-CVG-FYR-COMM-AMT (I) * 100
020874         MOVE WCVGS-CVG-FYR-COMM-AMT (I)      TO L0290-INPUT-V02
008455         MOVE 2                               TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-FYR-COMM-AMT
                                            TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-FYR-COMM-AMT
               GO TO 5111-EDIT-REPFYC-X
557660     END-IF.

           IF MIR-CVG-FYR-COMM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000'               TO MIR-CVG-FYR-COMM-AMT
008455         MOVE  ZEROS            TO MIR-CVG-FYR-COMM-AMT
557660     END-IF.

           MOVE MIR-CVG-FYR-COMM-AMT  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-FYR-COMM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WCVGS-CVG-FYR-COMM-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR    TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2            TO MIR-CVG-FYR-COMM-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-FYR-COMM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-FYR-COMM-AMT
               SET UPDATE-NEEDED           TO TRUE
           ELSE
               SET INPUT-NOT-VALID         TO TRUE
               MOVE 'CS01520009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       5111-EDIT-REPFYC-X.
           EXIT.
      *

      *----------------------
       5112-EDIT-FACE-AMOUNT.
      *----------------------
           IF MIR-CVG-FACE-AMT = SPACES
008455*        MOVE WCVGS-CVG-FACE-AMT (I)  TO WS-HOLD-9-2
008455*        MOVE WS-DISP-9-2             TO MIR-CVG-FACE-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-CVG-FACE-AMT (I) * 100
020874         MOVE WCVGS-CVG-FACE-AMT (I)     TO L0290-INPUT-V02
008455         MOVE 2                          TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-FACE-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-FACE-AMT
               GO TO 5112-EDIT-FACE-AMOUNT-X
557660     END-IF.

           IF MIR-CVG-FACE-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '000000000.00'          TO MIR-CVG-FACE-AMT
008455         MOVE  ZEROS            TO MIR-CVG-FACE-AMT
557660     END-IF.

           MOVE MIR-CVG-FACE-AMT      TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 12                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-FACE-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WCVGS-CVG-FACE-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-9-2
008455*        MOVE WS-DISP-9-2             TO MIR-CVG-FACE-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-FACE-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-FACE-AMT
               SET UPDATE-NEEDED            TO TRUE
           ELSE
               SET INPUT-NOT-VALID          TO TRUE
               MOVE 'CS01520028'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       5112-EDIT-FACE-AMOUNT-X.
           EXIT.
      *

      *---------------
       5113-EDIT-FACE.
      *---------------
           IF MIR-CVG-PREV-FACE-AMT = SPACES
008455*        MOVE WCVGS-CVG-PREV-FACE-AMT (I) TO WS-HOLD-9-2
008455*        MOVE WS-DISP-9-2             TO MIR-CVG-PREV-FACE-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-CVG-PREV-FACE-AMT (I) * 100
020874         MOVE WCVGS-CVG-PREV-FACE-AMT (I)     TO L0290-INPUT-V02
008455         MOVE 2                               TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-PREV-FACE-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-PREV-FACE-AMT
               GO TO 5113-EDIT-FACE-X
557660     END-IF.

           IF MIR-CVG-PREV-FACE-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '000000000.00'          TO MIR-CVG-PREV-FACE-AMT
008455         MOVE  ZEROS            TO MIR-CVG-PREV-FACE-AMT
557660     END-IF.

           MOVE MIR-CVG-PREV-FACE-AMT TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 12                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-PREV-FACE-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WCVGS-CVG-PREV-FACE-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR   TO WS-HOLD-9-2
008455*        MOVE WS-DISP-9-2           TO MIR-CVG-PREV-FACE-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-PREV-FACE-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-PREV-FACE-AMT
               SET UPDATE-NEEDED          TO TRUE
           ELSE
               SET INPUT-NOT-VALID        TO TRUE
               MOVE 'CS01520029'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       5113-EDIT-FACE-X.
           EXIT.
      *

      *-----------------------
       5114-EDIT-LAST-PREMIUM.
      *-----------------------
           IF MIR-CVG-PREV-UPREM-AMT = SPACES
008455*        MOVE WCVGS-CVG-PREV-UPREM-AMT (I) TO WS-HOLD-3-2
008455*        MOVE WS-DISP-3-2             TO MIR-CVG-PREV-UPREM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-CVG-PREV-UPREM-AMT (I) * 100
020874         MOVE WCVGS-CVG-PREV-UPREM-AMT (I)      TO L0290-INPUT-V02
008455         MOVE 2                                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-PREV-UPREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-PREV-UPREM-AMT
               GO TO 5114-EDIT-LAST-PREMIUM-X
557660     END-IF.

           IF MIR-CVG-PREV-UPREM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '000.00'                TO MIR-CVG-PREV-UPREM-AMT
008455         MOVE  ZEROS            TO MIR-CVG-PREV-UPREM-AMT
557660     END-IF.

           MOVE MIR-CVG-PREV-UPREM-AMT              TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 3                           TO L0280-LENGTH.
008455*    MOVE 6                           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-PREV-UPREM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WCVGS-CVG-PREV-UPREM-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR  TO WS-HOLD-3-2
008455*        MOVE WS-DISP-3-2          TO MIR-CVG-PREV-UPREM-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-PREV-UPREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-PREV-UPREM-AMT
               SET UPDATE-NEEDED         TO TRUE
           ELSE
               SET INPUT-NOT-VALID       TO TRUE
               MOVE 'CS01520030'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       5114-EDIT-LAST-PREMIUM-X.
           EXIT.
      *

      *-----------------------
       5115-EDIT-NEXT-PREMIUM.
      *-----------------------
           IF MIR-CVG-NXT-UPREM-AMT = SPACES
008455*        MOVE WCVGS-CVG-NXT-UPREM-AMT (I) TO WS-HOLD-3-2
008455*        MOVE WS-DISP-3-2             TO MIR-CVG-NXT-UPREM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-CVG-NXT-UPREM-AMT (I) * 100
020874         MOVE WCVGS-CVG-NXT-UPREM-AMT (I)     TO L0290-INPUT-V02
008455         MOVE 2                               TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-NXT-UPREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-NXT-UPREM-AMT
               GO TO 5115-EDIT-NEXT-PREMIUM-X
557660     END-IF.

           IF MIR-CVG-NXT-UPREM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '000.00'                TO MIR-CVG-NXT-UPREM-AMT
008455         MOVE  ZEROS            TO MIR-CVG-NXT-UPREM-AMT
557660     END-IF.

           MOVE MIR-CVG-NXT-UPREM-AMT TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 3                           TO L0280-LENGTH.
008455*    MOVE 6                           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-NXT-UPREM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WCVGS-CVG-NXT-UPREM-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR   TO WS-HOLD-3-2
008455*        MOVE WS-DISP-3-2           TO MIR-CVG-NXT-UPREM-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-NXT-UPREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-NXT-UPREM-AMT
               SET UPDATE-NEEDED          TO TRUE
           ELSE
               SET INPUT-NOT-VALID        TO TRUE
               MOVE 'CS01520031'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       5115-EDIT-NEXT-PREMIUM-X.
           EXIT.
      *

      *------------------
010302*5116-EDIT-LWPRATE-X.
010302*------------------
010302*           IF MIR-LWPRATE = SPACES
010302*008455*        MOVE WCVGS-PREV-WP-UPREM-AMT (I) TO WS-HOLD-3-2
010302*008455*        MOVE WS-DISP-3-2             TO MIR-LWPRATE
010302*008455         COMPUTE L0290-INPUT-NUMBER
010302*008455               = WCVGS-PREV-WP-UPREM-AMT (I) * 100
010302*008455         MOVE 2                       TO L0290-PRECISION
010302*008455         MOVE LENGTH OF MIR-LWPRATE   TO L0290-MAX-OUT-LEN
010302*008455         PERFORM 0290-1000-NUMERIC-FORMAT
010302*008455            THRU 0290-1000-NUMERIC-FORMAT-X
010302*008455         MOVE L0290-OUTPUT-DATA       TO MIR-LWPRATE
010302*           GO TO 5116-EDIT-LWPRATE-X
010302*557660     END-IF.
010302
010302*           IF MIR-LWPRATE = EBLCH-BLANK-FIELD-CHAR
010302*008455*        MOVE '000.00'                TO MIR-LWPRATE
010302*008455         MOVE  ZEROS                  TO MIR-LWPRATE
010302*557660     END-IF.
010302
010302*           MOVE MIR-LWPRATE                 TO L0280-INPUT-DATA.
010302*54-001     SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
010302*           MOVE 2                           TO L0280-PRECISION.
010302*008455*    MOVE 3                           TO L0280-LENGTH.
010302*008455*    MOVE 6                           TO L0280-INPUT-SIZE.
010302*008455     MOVE LENGTH OF MIR-LWPRATE       TO L0280-INPUT-SIZE.
010302*008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
010302*           PERFORM  0280-1000-NUMERIC-EDIT
010302*               THRU 0280-1000-NUMERIC-EDIT-X.
010302
010302*        IF L0280-OK
010302*         MOVE L0280-OUTPUT-DOLLAR  TO WCVGS-PREV-WP-UPREM-AMT (I)
010302*008455*  MOVE L0280-OUTPUT-DOLLAR  TO WS-HOLD-3-2
010302*008455*  MOVE WS-DISP-3-2          TO MIR-LWPRATE
010302*008455   MOVE L0280-OUTPUT         TO L0290-INPUT-NUMBER
010302*008455   MOVE 2                    TO L0290-PRECISION
010302*008455   MOVE LENGTH OF MIR-LWPRATE TO L0290-MAX-OUT-LEN
010302*008455   PERFORM 0290-1000-NUMERIC-FORMAT
010302*008455      THRU 0290-1000-NUMERIC-FORMAT-X
010302*008455   MOVE L0290-OUTPUT-DATA    TO MIR-LWPRATE
010302*54-001   SET UPDATE-NEEDED         TO TRUE
010302*        ELSE
010302*54-001   SET INPUT-NOT-VALID       TO TRUE
010302*         MOVE 'CS01520032'         TO WGLOB-MSG-REF-INFO
010302*         PERFORM  0260-1000-GENERATE-MESSAGE
010302*             THRU 0260-1000-GENERATE-MESSAGE-X
010302*557660  END-IF.
010302*      *
010302*       5116-EDIT-LWPRATE-X.
010302*           EXIT.
      *

      *----------------
       5117-EDIT-CLCUR.
      *----------------
           IF MIR-CVG-CLM-YTD-AMT = SPACES
008455*        MOVE WCVGS-CVG-CLM-YTD-AMT (I) TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-CVG-CLM-YTD-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-CVG-CLM-YTD-AMT (I) * 100
020874         MOVE WCVGS-CVG-CLM-YTD-AMT (I)     TO L0290-INPUT-V02
008455         MOVE 2                             TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-CLM-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-CLM-YTD-AMT
               GO TO 5117-EDIT-CLCUR-X
557660     END-IF.

           IF MIR-CVG-CLM-YTD-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-CVG-CLM-YTD-AMT
008455         MOVE  ZEROS            TO MIR-CVG-CLM-YTD-AMT
557660     END-IF.

           MOVE MIR-CVG-CLM-YTD-AMT   TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-CLM-YTD-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WCVGS-CVG-CLM-YTD-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-CVG-CLM-YTD-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-CLM-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-CLM-YTD-AMT
               SET UPDATE-NEEDED            TO TRUE
           ELSE
               SET INPUT-NOT-VALID          TO TRUE
               MOVE 'CS01520033'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       5117-EDIT-CLCUR-X.
           EXIT.
      *

      *----------------
       5118-EDIT-CLTOT.
      *----------------
           IF MIR-CVG-CLM-LTD-AMT = SPACES
008455*        MOVE WCVGS-CVG-CLM-LTD-AMT (I) TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-CVG-CLM-LTD-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-CVG-CLM-LTD-AMT (I) * 100
020874         MOVE WCVGS-CVG-CLM-LTD-AMT (I)      TO L0290-INPUT-V02
008455         MOVE 2                              TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-CLM-LTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-CLM-LTD-AMT
               GO TO 5118-EDIT-CLTOT-X
557660     END-IF.

           IF MIR-CVG-CLM-LTD-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-CVG-CLM-LTD-AMT
008455         MOVE  ZEROS            TO MIR-CVG-CLM-LTD-AMT
557660     END-IF.

           MOVE MIR-CVG-CLM-LTD-AMT   TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-CLM-LTD-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WCVGS-CVG-CLM-LTD-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-CVG-CLM-LTD-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-CLM-LTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-CLM-LTD-AMT
               SET UPDATE-NEEDED            TO TRUE
           ELSE
               SET INPUT-NOT-VALID          TO TRUE
               MOVE 'CS01520034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       5118-EDIT-CLTOT-X.
           EXIT.
      *
      *
      *--------------------
       5120-EDIT-CVG-XHBT-ISS-IND.
      *--------------------
           IF MIR-CVG-XHBT-ISS-IND = SPACES
557659*        MOVE WCVGS-CVG-XHBT-ISS-IND-N (I) TO MIR-CVG-XHBT-ISS-IND
557659         MOVE WCVGS-CVG-XHBT-ISS-IND (I)
                                      TO MIR-CVG-XHBT-ISS-IND
               GO TO 5120-EDIT-CVG-XHBT-ISS-IND-X
557660     END-IF.

           IF MIR-CVG-XHBT-ISS-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE '0'               TO MIR-CVG-XHBT-ISS-IND
557660     END-IF.

557659*    IF (MIR-CVG-XHBT-ISS-IND NOT = '0'
557659*    AND MIR-CVG-XHBT-ISS-IND NOT = '1')
557659     IF (MIR-CVG-XHBT-ISS-IND NOT = 'N'
557659     AND MIR-CVG-XHBT-ISS-IND NOT = 'Y')
               SET INPUT-NOT-VALID     TO TRUE
               MOVE 'CS01520015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-NEEDED       TO TRUE
557659*        MOVE MIR-CVG-XHBT-ISS-IND TO WCVGS-CVG-XHBT-ISS-IND-N (I)
557659         MOVE MIR-CVG-XHBT-ISS-IND
                                      TO WCVGS-CVG-XHBT-ISS-IND (I)
557660     END-IF.
      *
       5120-EDIT-CVG-XHBT-ISS-IND-X.
           EXIT.
      *

      *----------------------
       5121-EDIT-CVG-XHBT-ISS-DT.
      *----------------------
           IF MIR-CVG-XHBT-ISS-DT = SPACES
               MOVE WCVGS-CVG-XHBT-ISS-DT (I)
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CVG-XHBT-ISS-DT
               GO TO 5121-EDIT-CVG-XHBT-ISS-DT-X
557660     END-IF.

           IF MIR-CVG-XHBT-ISS-DT = EBLCH-BLANK-FIELD-CHAR
               SET UPDATE-NEEDED            TO TRUE
               MOVE SPACES            TO MIR-CVG-XHBT-ISS-DT
               MOVE WWKDT-ZERO-DT     TO WCVGS-CVG-XHBT-ISS-DT (I)
               GO TO 5121-EDIT-CVG-XHBT-ISS-DT-X
557660     END-IF.

           MOVE MIR-CVG-XHBT-ISS-DT   TO L1640-EXTERNAL-DATE.

020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF L1640-NOT-VALID
               SET INPUT-NOT-VALID        TO TRUE
               MOVE 'CS01520016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-NEEDED          TO TRUE
               MOVE L1640-INTERNAL-DATE
                                      TO WCVGS-CVG-XHBT-ISS-DT (I)
557660     END-IF.
      *
       5121-EDIT-CVG-XHBT-ISS-DT-X.
           EXIT.
      *

      *--------------------
       5122-EDIT-CVG-XHBT-TRMN-QTY.
      *--------------------

           IF MIR-CVG-XHBT-TRMN-QTY = SPACES
               MOVE WCVGS-CVG-XHBT-TRMN-QTY-N (I)
                                      TO MIR-CVG-XHBT-TRMN-QTY
               GO TO 5122-EDIT-CVG-XHBT-TRMN-QTY-X
557660     END-IF.

           IF MIR-CVG-XHBT-TRMN-QTY = EBLCH-BLANK-FIELD-CHAR
               MOVE '0'               TO MIR-CVG-XHBT-TRMN-QTY
557660     END-IF.

           IF MIR-CVG-XHBT-TRMN-QTY NOT NUMERIC
               SET INPUT-NOT-VALID       TO TRUE
               MOVE 'CS01520017'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-NEEDED TO TRUE
               MOVE MIR-CVG-XHBT-TRMN-QTY
                                      TO WCVGS-CVG-XHBT-TRMN-QTY-N (I)
557660     END-IF.
      *
       5122-EDIT-CVG-XHBT-TRMN-QTY-X.
           EXIT.
      *

      *----------------------
       5123-EDIT-CVG-XHBT-TRMN-DT.
      *----------------------
           IF MIR-CVG-XHBT-TRMN-DT = SPACES
               MOVE WCVGS-CVG-XHBT-TRMN-DT (I)
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CVG-XHBT-TRMN-DT
               GO TO 5123-EDIT-CVG-XHBT-TRMN-DT-X
557660     END-IF.

           IF MIR-CVG-XHBT-TRMN-DT = EBLCH-BLANK-FIELD-CHAR
               SET UPDATE-NEEDED          TO TRUE
               MOVE SPACES            TO MIR-CVG-XHBT-TRMN-DT
               MOVE WWKDT-ZERO-DT     TO WCVGS-CVG-XHBT-TRMN-DT (I)
               GO TO 5123-EDIT-CVG-XHBT-TRMN-DT-X
557660     END-IF.

           MOVE MIR-CVG-XHBT-TRMN-DT  TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-NOT-VALID
               SET INPUT-NOT-VALID        TO TRUE
               MOVE 'CS01520018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-NEEDED          TO TRUE
               MOVE L1640-INTERNAL-DATE
                                      TO WCVGS-CVG-XHBT-TRMN-DT (I)
557660     END-IF.
      *
       5123-EDIT-CVG-XHBT-TRMN-DT-X.
           EXIT.
      *

      *--------------------
       5124-EDIT-XHBT-REINST-QTY.
      *--------------------
           IF MIR-XHBT-REINST-QTY = SPACES
               MOVE WCVGS-XHBT-REINST-QTY-N (I)
                                      TO MIR-XHBT-REINST-QTY
               GO TO 5124-EDIT-XHBT-REINST-QTY-X
557660     END-IF.

           IF MIR-XHBT-REINST-QTY = EBLCH-BLANK-FIELD-CHAR
               MOVE '0'               TO MIR-XHBT-REINST-QTY
557660     END-IF.

           IF MIR-XHBT-REINST-QTY NOT NUMERIC
               SET INPUT-NOT-VALID      TO TRUE
               MOVE 'CS01520019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-NEEDED        TO TRUE
               MOVE MIR-XHBT-REINST-QTY
                                      TO WCVGS-XHBT-REINST-QTY-N (I)
557660     END-IF.
      *
       5124-EDIT-XHBT-REINST-QTY-X.
           EXIT.
      *

      *----------------------
       5125-EDIT-CVG-XHBT-REINST-DT.
      *----------------------
           IF MIR-CVG-XHBT-REINST-DT = SPACES
               MOVE WCVGS-CVG-XHBT-REINST-DT (I)
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CVG-XHBT-REINST-DT
               GO TO 5125-EDIT-CVG-XHBT-REINST-DT-X
557660     END-IF.

           IF MIR-CVG-XHBT-REINST-DT = EBLCH-BLANK-FIELD-CHAR
               SET UPDATE-NEEDED         TO TRUE
               MOVE SPACES            TO MIR-CVG-XHBT-REINST-DT
               MOVE WWKDT-ZERO-DT     TO WCVGS-CVG-XHBT-REINST-DT (I)
               GO TO 5125-EDIT-CVG-XHBT-REINST-DT-X
557660     END-IF.

           MOVE MIR-CVG-XHBT-REINST-DT           TO L1640-EXTERNAL-DATE.

020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF L1640-NOT-VALID
               SET INPUT-NOT-VALID      TO TRUE
               MOVE 'CS01520020'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-NEEDED        TO TRUE
               MOVE L1640-INTERNAL-DATE
                                      TO WCVGS-CVG-XHBT-REINST-DT (I)
557660     END-IF.
      *
       5125-EDIT-CVG-XHBT-REINST-DT-X.
           EXIT.
      *

      *---------------------
       5126-EDIT-APP-COM-DT.
      *---------------------
           IF MIR-CVG-APP-CMPLT-DT = SPACES
               MOVE WCVGS-CVG-APP-CMPLT-DT (I)
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CVG-APP-CMPLT-DT
               GO TO 5126-EDIT-APP-COM-DT-X
557660     END-IF.

           IF MIR-CVG-APP-CMPLT-DT = EBLCH-BLANK-FIELD-CHAR
               SET UPDATE-NEEDED          TO TRUE
               MOVE WWKDT-ZERO-DT     TO WCVGS-CVG-APP-CMPLT-DT (I)
               MOVE SPACES            TO MIR-CVG-APP-CMPLT-DT
               GO TO 5126-EDIT-APP-COM-DT-X
557660     END-IF.

           MOVE MIR-CVG-APP-CMPLT-DT  TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-NOT-VALID
               SET INPUT-NOT-VALID       TO TRUE
               MOVE 'CS01520021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-NEEDED         TO TRUE
               MOVE L1640-INTERNAL-DATE
                                      TO WCVGS-CVG-APP-CMPLT-DT (I)
557660     END-IF.
      *
       5126-EDIT-APP-COM-DT-X.
           EXIT.
      *

      *---------------------
       5127-EDIT-EARLY-DATE.
      *---------------------
           IF MIR-CVG-MTHV-STRT-DT = SPACES
               MOVE WCVGS-CVG-MTHV-STRT-DT (I)
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CVG-MTHV-STRT-DT
               GO TO 5127-EDIT-EARLY-DATE-X
557660     END-IF.

           IF MIR-CVG-MTHV-STRT-DT = EBLCH-BLANK-FIELD-CHAR
               SET UPDATE-NEEDED          TO TRUE
               MOVE SPACES            TO MIR-CVG-MTHV-STRT-DT
               MOVE WWKDT-ZERO-DT     TO WCVGS-CVG-MTHV-STRT-DT (I)
               GO TO 5127-EDIT-EARLY-DATE-X
557660     END-IF.

           MOVE MIR-CVG-MTHV-STRT-DT  TO L1640-EXTERNAL-DATE.

020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF L1640-NOT-VALID
               SET INPUT-NOT-VALID        TO TRUE
               MOVE 'CS01520041'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-NEEDED          TO TRUE
               MOVE L1640-INTERNAL-DATE
                                      TO WCVGS-CVG-MTHV-STRT-DT(I)
557660     END-IF.

       5127-EDIT-EARLY-DATE-X.
           EXIT.
      *
      *----------------
       5128-EDIT-URATE.
      *----------------
           IF MIR-ULT-PREM-RT-CD = SPACES
               MOVE WCVGS-ULT-PREM-RT-CD (I)
                                      TO MIR-ULT-PREM-RT-CD
               GO TO 5128-EDIT-URATE-X
557660     END-IF.

           IF MIR-ULT-PREM-RT-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-ULT-PREM-RT-CD
557660     END-IF.

           IF  MIR-ULT-PREM-RT-CD = 'Y'
           OR  MIR-ULT-PREM-RT-CD = 'S'
           OR  MIR-ULT-PREM-RT-CD = 'N'
           OR  MIR-ULT-PREM-RT-CD = ' '
               SET UPDATE-NEEDED            TO TRUE
               MOVE MIR-ULT-PREM-RT-CD       TO WCVGS-ULT-PREM-RT-CD (I)
           ELSE
               SET INPUT-NOT-VALID          TO TRUE
               MOVE 'CS01520065'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: ULT RATE INDICATOR MUST BE Y, S, N OR *. RE-ENTER
      *
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5128-EDIT-URATE-X.
           EXIT.
      *
      *---------------
       5129-EDIT-WCUR.
      *---------------
           IF MIR-CVG-WP-YTD-AMT = SPACES
008455*        MOVE WCVGS-CVG-WP-YTD-AMT (I) TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-CVG-WP-YTD-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-CVG-WP-YTD-AMT(I) * 100
020874         MOVE WCVGS-CVG-WP-YTD-AMT(I)      TO L0290-INPUT-V02
008455         MOVE 2                            TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-WP-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-WP-YTD-AMT
               GO TO 5129-EDIT-WCUR-X
557660     END-IF.

           IF MIR-CVG-WP-YTD-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-CVG-WP-YTD-AMT
008455         MOVE  ZEROS            TO MIR-CVG-WP-YTD-AMT
557660     END-IF.

           MOVE MIR-CVG-WP-YTD-AMT    TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-WP-YTD-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WCVGS-CVG-WP-YTD-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-CVG-WP-YTD-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-WP-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-WP-YTD-AMT
               SET UPDATE-NEEDED            TO TRUE
           ELSE
               SET INPUT-NOT-VALID          TO TRUE
               MOVE 'CS01520066'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: WAIVER-CURRENT MUST BE A VALID NUMERIC. RE-ENTER
      *
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5129-EDIT-WCUR-X.
           EXIT.
      *
      *---------------
       5130-EDIT-WTOT.
      *---------------
           IF MIR-CVG-WP-LTD-AMT = SPACES
008455*        MOVE WCVGS-CVG-WP-LTD-AMT (I) TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-CVG-WP-LTD-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-CVG-WP-LTD-AMT (I) * 100
020874         MOVE WCVGS-CVG-WP-LTD-AMT (I)     TO L0290-INPUT-V02
008455         MOVE 2                            TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-WP-LTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-WP-LTD-AMT
               GO TO 5130-EDIT-WTOT-X
557660     END-IF.

           IF MIR-CVG-WP-LTD-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-CVG-WP-LTD-AMT
008455         MOVE  ZEROS            TO MIR-CVG-WP-LTD-AMT
557660     END-IF.

           MOVE MIR-CVG-WP-LTD-AMT    TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-WP-LTD-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WCVGS-CVG-WP-LTD-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-CVG-WP-LTD-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-WP-LTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-WP-LTD-AMT
               SET UPDATE-NEEDED            TO TRUE
           ELSE
               SET INPUT-NOT-VALID          TO TRUE
               MOVE 'CS01520067'      TO WGLOB-MSG-REF-INFO
      *
      *        MSG: WAIVER-TOTAL MUST BE A VALID NUMERIC. RE-ENTER
      *
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5130-EDIT-WTOT-X.
           EXIT.
      *
      *------------------
       5131-EDIT-ORGFACE.
      *------------------

           IF  MIR-CVG-ORIG-FACE-AMT                  =  SPACES
008455*        MOVE WCVGS-CVG-ORIG-FACE-AMT (I)
008455*                                     TO WS-HOLD-9-2
008455*        MOVE WS-DISP-9-2             TO MIR-CVG-ORIG-FACE-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-CVG-ORIG-FACE-AMT (I) * 100
020874         MOVE WCVGS-CVG-ORIG-FACE-AMT (I)      TO L0290-INPUT-V02
008455         MOVE 2                                TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-ORIG-FACE-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-ORIG-FACE-AMT
               GO TO 5131-EDIT-ORGFACE-X
557660     END-IF.

           IF  MIR-CVG-ORIG-FACE-AMT =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '000000000.00'          TO MIR-CVG-ORIG-FACE-AMT
008455         MOVE  ZEROS            TO MIR-CVG-ORIG-FACE-AMT
557660     END-IF.

           MOVE MIR-CVG-ORIG-FACE-AMT TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 12                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-ORIG-FACE-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO
                    WCVGS-CVG-ORIG-FACE-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-9-2
008455*        MOVE WS-DISP-9-2             TO MIR-CVG-ORIG-FACE-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-ORIG-FACE-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-ORIG-FACE-AMT
               SET UPDATE-NEEDED            TO TRUE
           ELSE
               SET INPUT-NOT-VALID          TO TRUE
               MOVE 'CS01520010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5131-EDIT-ORGFACE-X.
           EXIT.
      *
      *------------------
       5132-EDIT-SMINSRD.
      *------------------

           IF  MIR-CVG-SUM-INS-AMT                  =  SPACES
008455*        MOVE WCVGS-CVG-SUM-INS-AMT (I)
008455*                                     TO WS-HOLD-9-2
008455*        MOVE WS-DISP-9-2             TO MIR-CVG-SUM-INS-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-CVG-SUM-INS-AMT (I) * 100
020874         MOVE WCVGS-CVG-SUM-INS-AMT (I)      TO L0290-INPUT-V02
008455         MOVE 2                              TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-SUM-INS-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-SUM-INS-AMT
               GO TO 5132-EDIT-SMINSRD-X
557660     END-IF.

           IF  MIR-CVG-SUM-INS-AMT =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '000000000.00'          TO MIR-CVG-SUM-INS-AMT
008455         MOVE  ZEROS            TO MIR-CVG-SUM-INS-AMT
           END-IF.

           MOVE MIR-CVG-SUM-INS-AMT   TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 12                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-SUM-INS-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO
                    WCVGS-CVG-SUM-INS-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-9-2
008455*        MOVE WS-DISP-9-2             TO MIR-CVG-SUM-INS-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-SUM-INS-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-SUM-INS-AMT
               SET UPDATE-NEEDED            TO TRUE
           ELSE
               SET INPUT-NOT-VALID          TO TRUE
               MOVE 'CS01520011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5132-EDIT-SMINSRD-X.
           EXIT.
      *
012145*---------------
012145 5133-EDIT-LCF.
012145*---------------

012145     IF  MIR-CVG-COLFND-IND = SPACES
012145         MOVE WCVGS-CVG-COLFND-IND (I)
                                      TO  MIR-CVG-COLFND-IND
012145         GO TO 5133-EDIT-LCF-X
012145     END-IF.

012145     IF        MIR-CVG-COLFND-IND NOT = 'Y'
012145         AND   MIR-CVG-COLFND-IND NOT = 'N'
012145         SET   INPUT-NOT-VALID        TO TRUE
012145***MSG: LOAN COLLATERAL FUND INDICATOR INVALID. MUST BE 'Y' OR 'N'
012145         MOVE  'CS01520069'     TO WGLOB-MSG-REF-INFO
012145         PERFORM  0260-1000-GENERATE-MESSAGE
012145             THRU 0260-1000-GENERATE-MESSAGE-X
012145     ELSE
012145         MOVE MIR-CVG-COLFND-IND       TO WCVGS-CVG-COLFND-IND (I)
012145         SET UPDATE-NEEDED            TO TRUE
012145     END-IF.

012145 5133-EDIT-LCF-X.
012145     EXIT.
012145*
012146*---------------
012146 5135-EDIT-UNTTYP.
012146*---------------

021239     EVALUATE TRUE
021239
021239         WHEN MIR-CVG-UNIT-TYP-CD = EBLCH-BLANK-FIELD-CHAR
021239              MOVE SPACE         TO WCVGS-CVG-UNIT-TYP-CD (I)
021239              MOVE SPACE         TO MIR-CVG-UNIT-TYP-CD
021239
021239         WHEN MIR-CVG-UNIT-TYP-CD = SPACES
021239              MOVE WCVGS-CVG-UNIT-TYP-CD (I)
021239                                 TO  MIR-CVG-UNIT-TYP-CD
021239              GO TO 5135-EDIT-UNTTYP-X
021239
021239     END-EVALUATE.
021239*
021239*    IF        MIR-CVG-UNIT-TYP-CD NOT = 'A'
021239*        AND   MIR-CVG-UNIT-TYP-CD NOT = 'I'
021239*        AND   MIR-CVG-UNIT-TYP-CD NOT = 'N'
021239*        SET   INPUT-NOT-VALID        TO TRUE
021239***MSG: UNIT TYPE IS INVALID. IT CAN BE 'I'OR 'A' OR 'N'
021239*        MOVE  'CS01520070'     TO WGLOB-MSG-REF-INFO
021239*        PERFORM  0260-1000-GENERATE-MESSAGE
021239*            THRU 0260-1000-GENERATE-MESSAGE-X
021239*    ELSE
021239*        MOVE MIR-CVG-UNIT-TYP-CD
021239*                               TO WCVGS-CVG-UNIT-TYP-CD (I)
021239*        SET UPDATE-NEEDED            TO TRUE
021239*    END-IF.
021239*
021239     MOVE MIR-CVG-UNIT-TYP-CD        TO WEDIT-ETBL-VALU-ID.
021239
021239     PERFORM  UVTP-1000-EDIT
021239         THRU UVTP-1000-EDIT-X.
021239
021239     IF  NOT WEDIT-IO-OK
021239         SET INPUT-NOT-VALID           TO TRUE
021239*MSG: UNIT TYPE (@1) NOT ON EDIT (@2)
021239         MOVE 'CS01520070'             TO WGLOB-MSG-REF-INFO
014221         MOVE MIR-CVG-UNIT-TYP-CD      TO WGLOB-MSG-PARM (1)
014221         MOVE 'UVTYP'                  TO WGLOB-MSG-PARM (2)
021239         PERFORM  0260-1000-GENERATE-MESSAGE
021239             THRU 0260-1000-GENERATE-MESSAGE-X
021239         GO TO 5135-EDIT-UNTTYP-X
021239     END-IF.
021239
021239     MOVE MIR-CVG-UNIT-TYP-CD      TO WCVGS-CVG-UNIT-TYP-CD (I).
021239     SET UPDATE-NEEDED             TO TRUE.
021239
012146 5135-EDIT-UNTTYP-X.
012146     EXIT.
012146*
      *---------------------
018763*5119-EDIT-AGENT-INFO.
018763 5136-EDIT-AGENT-INFO.
      *---------------------

           SET UPDATE-AGENT-NO     TO TRUE.
           MOVE SPACES                TO PART-ADV-TYPE.
           MOVE +0                    TO PART-ADV-NUM.

018763*    PERFORM  5119-A-EDIT-ADV-TYPE
018763*        THRU 5119-A-EDIT-ADV-TYPE-X.

018763     PERFORM  5137-EDIT-ADV-TYPE
018763         THRU 5137-EDIT-ADV-TYPE-X.

018763*    PERFORM  5119-B-EDIT-PART-ADV
018763*        THRU 5119-B-EDIT-PART-ADV-X.

018763     PERFORM  5138-EDIT-PART-ADV
018763         THRU 5138-EDIT-PART-ADV-X.

           IF  UPDATE-AGENT
               SET UPDATE-CVG-AGENTS TO TRUE
018763*        PERFORM  5119-C-VALIDATE-PARTIAL-ADV
018763*            THRU 5119-C-VALIDATE-PARTIAL-ADV-X
018763         PERFORM  5139-VALIDATE-PARTIAL-ADV
018763             THRU 5139-VALIDATE-PARTIAL-ADV-X
557660     END-IF.

018763*5119-EDIT-AGENT-INFO-X.
018763 5136-EDIT-AGENT-INFO-X.
           EXIT.
      *
      *---------------------
018763*5119-A-EDIT-ADV-TYPE.
018763 5137-EDIT-ADV-TYPE.
      *---------------------

           IF  L2450-AGT-ID (I, J) = SPACES
               MOVE SPACES            TO MIR-PARTL-ADV-TYP-CD-T (J)
018763*        GO TO 5119-A-EDIT-ADV-TYPE-X
018763         GO TO 5137-EDIT-ADV-TYPE-X
557660     END-IF.

           IF  MIR-PARTL-ADV-TYP-CD-T (J) = SPACES
               MOVE L2450-PARTL-ADV-TYP-CD (I, J)
                                      TO MIR-PARTL-ADV-TYP-CD-T (J)
               MOVE L2450-PARTL-ADV-TYP-CD (I, J)
                                      TO PART-ADV-TYPE
018763*        GO TO 5119-A-EDIT-ADV-TYPE-X
018763         GO TO 5137-EDIT-ADV-TYPE-X
557660     END-IF.

           IF  MIR-PARTL-ADV-TYP-CD-T (J) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO PART-ADV-TYPE
557660     END-IF.

           IF  MIR-PARTL-ADV-TYP-CD-T (J) NOT = 'N'
           AND MIR-PARTL-ADV-TYP-CD-T (J) NOT = 'P'
           AND MIR-PARTL-ADV-TYP-CD-T (J) NOT = 'F'
           AND MIR-PARTL-ADV-TYP-CD-T (J) NOT = ' '
               SET INPUT-NOT-VALID          TO TRUE
               MOVE 'CS01520063'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-AGENT             TO TRUE
               MOVE MIR-PARTL-ADV-TYP-CD-T (J)
                                      TO PART-ADV-TYPE
557660     END-IF.

018763*5119-A-EDIT-ADV-TYPE-X.
018763 5137-EDIT-ADV-TYPE-X.
           EXIT.
      *
      *---------------------
018763*5119-B-EDIT-PART-ADV.
018763 5138-EDIT-PART-ADV.
      *---------------------

           IF  L2450-AGT-ID (I, J) = SPACES
               MOVE SPACES            TO MIR-PARTL-ADV-AMT-T (J)
018763*        GO TO 5119-B-EDIT-PART-ADV-X
018763         GO TO 5138-EDIT-PART-ADV-X
557660     END-IF.

           IF  MIR-PARTL-ADV-AMT-T (J) = SPACES
               MOVE L2450-PARTL-ADV-AMT (I, J)
                                      TO PART-ADV-NUM
008455*        MOVE L2450-PARTL-ADV-AMT (I, J)     TO WS-HOLD-5-2
008455*        MOVE WS-DISP-5-2               TO MIR-PARTL-ADV-AMT-T (J)
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = L2450-PARTL-ADV-AMT (I, J) * 100
020874         MOVE L2450-PARTL-ADV-AMT (I, J)      TO L0290-INPUT-V02
008455         MOVE 2                               TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PARTL-ADV-AMT-T (J)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PARTL-ADV-AMT-T (J)
018763*        GO TO 5119-B-EDIT-PART-ADV-X
018763         GO TO 5138-EDIT-PART-ADV-X
557660     END-IF.

           IF  MIR-PARTL-ADV-AMT-T (J) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-PARTL-ADV-AMT-T (J)
               MOVE +0                TO PART-ADV-NUM
               SET UPDATE-AGENT             TO TRUE
018763*        GO TO 5119-B-EDIT-PART-ADV-X
018763         GO TO 5138-EDIT-PART-ADV-X
557660     END-IF.

           MOVE MIR-PARTL-ADV-AMT-T (J)
                                      TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 5                           TO L0280-LENGTH.
008455*    MOVE 8                           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-PARTL-ADV-AMT-T (J)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO PART-ADV-NUM
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-5-2
008455*        MOVE WS-DISP-5-2             TO MIR-PARTL-ADV-AMT-T (J)
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PARTL-ADV-AMT-T (J)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PARTL-ADV-AMT-T (J)
               SET UPDATE-AGENT             TO TRUE
           ELSE
               SET INPUT-NOT-VALID          TO TRUE
               MOVE 'CS01520052'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

018763*5119-B-EDIT-PART-ADV-X.
018763 5138-EDIT-PART-ADV-X.
           EXIT.
      *
      *----------------------------
018763*5119-C-VALIDATE-PARTIAL-ADV.
018763 5139-VALIDATE-PARTIAL-ADV.
      *----------------------------

           IF  L2450-AGT-ID (I, J) = SPACES
018763*        GO TO 5119-C-VALIDATE-PARTIAL-ADV-X
018763         GO TO 5139-VALIDATE-PARTIAL-ADV-X
557660     END-IF.

           IF  (PART-ADV-TYPE = 'N'
557660     AND  PART-ADV-NUM = +0)
           OR  (PART-ADV-TYPE = 'F' AND PART-ADV-NUM > +0)
           OR  (PART-ADV-TYPE = 'P' AND (PART-ADV-NUM > +0
018412*                             AND  PART-ADV-NUM < +101))
018412                              AND  PART-ADV-NUM NOT > +100))
               SET UPDATE-NEEDED     TO TRUE
               MOVE PART-ADV-TYPE     TO L2450-PARTL-ADV-TYP-CD (I, J)
               MOVE PART-ADV-NUM      TO L2450-PARTL-ADV-AMT (I, J)
           ELSE
               SET INPUT-NOT-VALID   TO TRUE
               MOVE 'CS01520064'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

018763*5119-C-VALIDATE-PARTIAL-ADV-X.
018763 5139-VALIDATE-PARTIAL-ADV-X.
           EXIT.


020475*------------------
020475 5140-EDIT-DBG-INCL.
020475*------------------
020475
020475     EVALUATE TRUE
020475
020475         WHEN MIR-CVG-DBG-INCL-IND = EBLCH-BLANK-FIELD-CHAR
020475              MOVE SPACE         TO WCVGS-CVG-DBG-INCL-IND (I)
020475              MOVE SPACE         TO MIR-CVG-DBG-INCL-IND
020475              GO TO 5140-EDIT-DBG-INCL-X
020475
020475         WHEN MIR-CVG-DBG-INCL-IND = SPACES
020475              MOVE WCVGS-CVG-DBG-INCL-IND (I)
020475                                 TO  MIR-CVG-DBG-INCL-IND
020475              GO TO 5140-EDIT-DBG-INCL-X
020475
020475     END-EVALUATE.
020475
020475     PERFORM  8960-1000-BUILD-PARM-INFO
020475         THRU 8960-1000-BUILD-PARM-INFO-X.
020475
020475     MOVE 'PLAN-INCL-DBG-IND'      TO L8960-AV-TBL-CD.
020475     MOVE MIR-CVG-DBG-INCL-IND     TO L8960-AV-CD.
020475
020475     PERFORM  8960-1000-VALIDATE-CODE
020475         THRU 8960-1000-VALIDATE-CODE-X.
020475
020475     IF  NOT L8960-RETRN-OK
020475         SET INPUT-NOT-VALID           TO TRUE
020475*MSG: DEATH BENEFIT GURARANTEE INCLUDE INDICATOR INVALID
020475         MOVE 'CS01520082'             TO WGLOB-MSG-REF-INFO
020475         PERFORM  0260-1000-GENERATE-MESSAGE
020475             THRU 0260-1000-GENERATE-MESSAGE-X
020475         GO TO 5140-EDIT-DBG-INCL-X
020475     END-IF.
020475
020475     MOVE MIR-CVG-DBG-INCL-IND     TO WCVGS-CVG-DBG-INCL-IND (I).
020475     SET UPDATE-NEEDED             TO TRUE.
020475
020475*MSG: DEATH BENEFIT GURARANTEE INCLUDE INDICATOR HAS BEEN CHANGDED
020475*     CHECK COVERAGE UNIT TYPE
020475     MOVE 'CS01520083'             TO WGLOB-MSG-REF-INFO.
020475     PERFORM  0260-1000-GENERATE-MESSAGE
020475         THRU 0260-1000-GENERATE-MESSAGE-X.
020475
020475 5140-EDIT-DBG-INCL-X.
020475     EXIT.

      *--------------------
       5200-EDIT-SCREEN-02.
      *--------------------

           PERFORM  5201-EDIT-SUR-TRGT
               THRU 5201-EDIT-SUR-TRGT-X.

           PERFORM  5202-EDIT-SUR-LLTD
               THRU 5202-EDIT-SUR-LLTD-X.

           PERFORM  5203-EDIT-CUM-SUR-LTD
               THRU 5203-EDIT-CUM-SUR-LTD-X.

           PERFORM  5204-EDIT-PMT-LLTD
               THRU 5204-EDIT-PMT-LLTD-X.

           PERFORM  5205-EDIT-CUM-PMT-LTD
               THRU 5205-EDIT-CUM-PMT-LTD-X.

           PERFORM  5206-EDIT-GUIDE-ANN-PREM
               THRU 5206-EDIT-GUIDE-ANN-PREM-X.

           PERFORM  5207-EDIT-GUIDE-SNGL-PREM
               THRU 5207-EDIT-GUIDE-SNGL-PREM-X.

           PERFORM  5208-EDIT-CF-TYPE
               THRU 5208-EDIT-CF-TYPE-X.

           PERFORM  5209-EDIT-CF-LDEP
               THRU 5209-EDIT-CF-LDEP-X.

           PERFORM  5210-EDIT-COMM-DUR
               THRU 5210-EDIT-COMM-DUR-X.

031037*    PERFORM  5211-EDIT-CVG-SEC-GAP
031037*        THRU 5211-EDIT-CVG-SEC-GAP-X.

016306     PERFORM  5212-MTG-CALC-EDITS
016306         THRU 5212-MTG-CALC-EDITS-X.

018846     PERFORM  5213-EDIT-PLAN-FND-TYP-CD
018846         THRU 5213-EDIT-PLAN-FND-TYP-CD-X.
018846
       5200-EDIT-SCREEN-02-X.
           EXIT.
      *
      *-------------------
       5201-EDIT-SUR-TRGT.
      *-------------------
           IF MIR-CVG-SURR-TRG-AMT = SPACES
008455*        MOVE WCVGS-CVG-SURR-TRG-AMT (I) TO WS-HOLD-7-0
008455*        MOVE WS-DISP-7-0             TO MIR-CVG-SURR-TRG-AMT
020874*        MOVE WCVGS-CVG-SURR-TRG-AMT (I)
020874*                               TO L0290-INPUT-NUMBER
020874         MOVE WCVGS-CVG-SURR-TRG-AMT (I)      TO L0290-INPUT-V00
008455         MOVE 0                               TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-SURR-TRG-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-SURR-TRG-AMT
               GO TO 5201-EDIT-SUR-TRGT-X
557660     END-IF.

           IF MIR-CVG-SURR-TRG-AMT = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-CVG-SURR-TRG-AMT
557660     END-IF.

           MOVE MIR-CVG-SURR-TRG-AMT  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 0                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 7                           TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-SURR-TRG-AMT
                                      TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-SURR-TRG-AMT
                                      TO L0280-LENGTH.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WCVGS-CVG-SURR-TRG-AMT (I)
008455*        MOVE L0280-OUTPUT           TO WS-HOLD-7-0
008455*        MOVE WS-DISP-7-0            TO MIR-CVG-SURR-TRG-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 0                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-SURR-TRG-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-SURR-TRG-AMT
               SET UPDATE-NEEDED           TO TRUE
           ELSE
               SET INPUT-NOT-VALID         TO TRUE
               MOVE 'CS01520053'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       5201-EDIT-SUR-TRGT-X.
           EXIT.
      *
      *-------------------
       5202-EDIT-SUR-LLTD.
      *-------------------
           IF MIR-SURR-LOAD-LTD-AMT = SPACES
008455*        MOVE WCVGS-SURR-LOAD-LTD-AMT (I) TO WS-HOLD-9-2
008455*        MOVE WS-DISP-9-2             TO MIR-SURR-LOAD-LTD-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-SURR-LOAD-LTD-AMT (I) * 100
020874         MOVE WCVGS-SURR-LOAD-LTD-AMT (I)    TO L0290-INPUT-V02
008455         MOVE 2                              TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-SURR-LOAD-LTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-SURR-LOAD-LTD-AMT
               GO TO 5202-EDIT-SUR-LLTD-X
557660     END-IF.

           IF MIR-SURR-LOAD-LTD-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '000000000.00'          TO MIR-SURR-LOAD-LTD-AMT
008455         MOVE  ZEROS            TO MIR-SURR-LOAD-LTD-AMT
557660     END-IF.

           MOVE MIR-SURR-LOAD-LTD-AMT TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 12                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-SURR-LOAD-LTD-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO
                                            WCVGS-SURR-LOAD-LTD-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-9-2
008455*        MOVE WS-DISP-9-2             TO MIR-SURR-LOAD-LTD-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-SURR-LOAD-LTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-SURR-LOAD-LTD-AMT
               SET UPDATE-NEEDED            TO TRUE
           ELSE
               SET INPUT-NOT-VALID          TO TRUE
               MOVE 'CS01520054'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       5202-EDIT-SUR-LLTD-X.
           EXIT.
      *
      *----------------------
       5203-EDIT-CUM-SUR-LTD.
      *----------------------

           IF  MIR-CVG-SURR-LTD-AMT = SPACES
008455*        MOVE WCVGS-CVG-SURR-LTD-AMT (I) TO WS-HOLD-11-2
008455*        MOVE WS-DISP-11-2               TO MIR-CVG-SURR-LTD-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-CVG-SURR-LTD-AMT (I) * 100
020874         MOVE WCVGS-CVG-SURR-LTD-AMT (I)     TO L0290-INPUT-V02
008455         MOVE 2                              TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-SURR-LTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-SURR-LTD-AMT
               GO TO 5203-EDIT-CUM-SUR-LTD-X
557660     END-IF.

           IF  MIR-CVG-SURR-LTD-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '00000000000.00'        TO MIR-CVG-SURR-LTD-AMT
008455         MOVE  ZEROS            TO MIR-CVG-SURR-LTD-AMT
557660     END-IF.

           MOVE MIR-CVG-SURR-LTD-AMT  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 11                          TO L0280-LENGTH.
008455*    MOVE 14                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-SURR-LTD-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WCVGS-CVG-SURR-LTD-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR    TO WS-HOLD-11-2
008455*        MOVE WS-DISP-11-2           TO MIR-CVG-SURR-LTD-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-SURR-LTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-SURR-LTD-AMT
               SET UPDATE-NEEDED           TO TRUE
           ELSE
               SET INPUT-NOT-VALID         TO TRUE
               MOVE 'CS01520055'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5203-EDIT-CUM-SUR-LTD-X.
           EXIT.
      *
      *-------------------
       5204-EDIT-PMT-LLTD.
      *-------------------
           IF MIR-PMT-LOAD-LTD-AMT = SPACES
008455*        MOVE WCVGS-PMT-LOAD-LTD-AMT (I) TO WS-HOLD-9-2
008455*        MOVE WS-DISP-9-2             TO MIR-PMT-LOAD-LTD-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-PMT-LOAD-LTD-AMT (I) * 100
020874         MOVE WCVGS-PMT-LOAD-LTD-AMT (I)     TO L0290-INPUT-V02
008455         MOVE 2                              TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PMT-LOAD-LTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PMT-LOAD-LTD-AMT
               GO TO 5204-EDIT-PMT-LLTD-X
557660     END-IF.

           IF MIR-PMT-LOAD-LTD-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '000000000.00'          TO MIR-PMT-LOAD-LTD-AMT
008455         MOVE  ZEROS            TO MIR-PMT-LOAD-LTD-AMT
557660     END-IF.

           MOVE MIR-PMT-LOAD-LTD-AMT  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 12                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-PMT-LOAD-LTD-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WCVGS-PMT-LOAD-LTD-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR    TO WS-HOLD-9-2
008455*        MOVE WS-DISP-9-2            TO MIR-PMT-LOAD-LTD-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PMT-LOAD-LTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PMT-LOAD-LTD-AMT
               SET UPDATE-NEEDED           TO TRUE
           ELSE
               SET INPUT-NOT-VALID         TO TRUE
               MOVE 'CS01520056'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       5204-EDIT-PMT-LLTD-X.
           EXIT.
      *
      *----------------------
       5205-EDIT-CUM-PMT-LTD.
      *----------------------
           IF MIR-CVG-PMT-LTD-AMT = SPACES
008455*        MOVE WCVGS-CVG-PMT-LTD-AMT (I) TO WS-HOLD-9-2
008455*        MOVE WS-DISP-9-2             TO MIR-CVG-PMT-LTD-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-CVG-PMT-LTD-AMT (I) * 100
020874         MOVE WCVGS-CVG-PMT-LTD-AMT (I)      TO L0290-INPUT-V02
008455         MOVE 2                              TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-PMT-LTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-PMT-LTD-AMT
               GO TO 5205-EDIT-CUM-PMT-LTD-X
557660     END-IF.

           IF MIR-CVG-PMT-LTD-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '000000000.00'          TO MIR-CVG-PMT-LTD-AMT
008455         MOVE  ZEROS            TO MIR-CVG-PMT-LTD-AMT
557660     END-IF.

           MOVE MIR-CVG-PMT-LTD-AMT   TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 12                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-PMT-LTD-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WCVGS-CVG-PMT-LTD-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-9-2
008455*        MOVE WS-DISP-9-2             TO MIR-CVG-PMT-LTD-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-PMT-LTD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-PMT-LTD-AMT
               SET UPDATE-NEEDED            TO TRUE
           ELSE
               SET INPUT-NOT-VALID          TO TRUE
               MOVE 'CS01520057'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       5205-EDIT-CUM-PMT-LTD-X.
           EXIT.
      *
      *-------------------------
       5206-EDIT-GUIDE-ANN-PREM.
      *-------------------------
           IF MIR-CVG-GDLN-APREM-AMT = SPACES
008455*        MOVE WCVGS-CVG-GDLN-APREM-AMT (I) TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-CVG-GDLN-APREM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-CVG-GDLN-APREM-AMT (I) * 100
020874         MOVE WCVGS-CVG-GDLN-APREM-AMT (I)     TO L0290-INPUT-V02
008455         MOVE 2                                TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-GDLN-APREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-GDLN-APREM-AMT
               GO TO 5206-EDIT-GUIDE-ANN-PREM-X
557660     END-IF.

           IF MIR-CVG-GDLN-APREM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-CVG-GDLN-APREM-AMT
008455         MOVE  ZEROS            TO MIR-CVG-GDLN-APREM-AMT
557660     END-IF.

           MOVE MIR-CVG-GDLN-APREM-AMT              TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-GDLN-APREM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
013578     IF L0280-OUTPUT-DOLLAR = WCVGS-CVG-GDLN-APREM-AMT (I)
013578         GO TO 5206-EDIT-GUIDE-ANN-PREM-X
013578     END-IF

           IF L0280-OK
013578         IF L0280-OUTPUT-DOLLAR = WCVGS-CVG-GDLN-APREM-AMT (I)
013578             GO TO 5206-EDIT-GUIDE-ANN-PREM-X
013578         END-IF
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WCVGS-CVG-GDLN-APREM-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR  TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-CVG-GDLN-APREM-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-GDLN-APREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-GDLN-APREM-AMT
               SET UPDATE-NEEDED         TO TRUE
               MOVE 'CS01520049'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET INPUT-NOT-VALID       TO TRUE
               MOVE 'CS01520045'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       5206-EDIT-GUIDE-ANN-PREM-X.
           EXIT.
      *
      *--------------------------
       5207-EDIT-GUIDE-SNGL-PREM.
      *--------------------------
           IF MIR-CVG-GDLN-SPREM-AMT = SPACES
008455*        MOVE WCVGS-CVG-GDLN-SPREM-AMT (I) TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-CVG-GDLN-SPREM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = WCVGS-CVG-GDLN-SPREM-AMT (I) * 100
020874         MOVE WCVGS-CVG-GDLN-SPREM-AMT (I)      TO L0290-INPUT-V02
008455         MOVE 2                                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-GDLN-SPREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-GDLN-SPREM-AMT
               GO TO 5207-EDIT-GUIDE-SNGL-PREM-X
557660     END-IF.

           IF MIR-CVG-GDLN-SPREM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-CVG-GDLN-SPREM-AMT
008455         MOVE  ZEROS            TO MIR-CVG-GDLN-SPREM-AMT
557660     END-IF.

           MOVE MIR-CVG-GDLN-SPREM-AMT              TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVG-GDLN-SPREM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WCVGS-CVG-GDLN-SPREM-AMT (I)
008455*        MOVE L0280-OUTPUT-DOLLAR  TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-CVG-GDLN-SPREM-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-GDLN-SPREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-GDLN-SPREM-AMT
               SET UPDATE-NEEDED         TO TRUE
           ELSE
               SET INPUT-NOT-VALID       TO TRUE
               MOVE 'CS01520046'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       5207-EDIT-GUIDE-SNGL-PREM-X.
           EXIT.
      *
      *------------------
       5208-EDIT-CF-TYPE.
      *------------------
           IF MIR-CVG-CF-TYP-CD = SPACES
               MOVE WCVGS-CVG-CF-TYP-CD (I)
                                      TO MIR-CVG-CF-TYP-CD
               GO TO 5208-EDIT-CF-TYPE-X
557660     END-IF.

           IF MIR-CVG-CF-TYP-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CVG-CF-TYP-CD
557660     END-IF.

           IF  MIR-CVG-CF-TYP-CD NOT = 'A'
           AND MIR-CVG-CF-TYP-CD NOT = 'N'
           AND MIR-CVG-CF-TYP-CD NOT = 'P'
           AND MIR-CVG-CF-TYP-CD NOT = 'D'
           AND MIR-CVG-CF-TYP-CD NOT = 'E'
           AND MIR-CVG-CF-TYP-CD NOT = 'M'
010314     AND MIR-CVG-CF-TYP-CD NOT = 'I'
               SET INPUT-NOT-VALID          TO TRUE
               MOVE 'CS01520013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-NEEDED            TO TRUE
               MOVE MIR-CVG-CF-TYP-CD TO WCVGS-CVG-CF-TYP-CD (I)
557660     END-IF.
      *
       5208-EDIT-CF-TYPE-X.
           EXIT.
      *
      *------------------
       5209-EDIT-CF-LDEP.
      *------------------
           IF MIR-LATST-CF-DT = SPACES
               MOVE WCVGS-LATST-CF-DT (I)
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-LATST-CF-DT
               GO TO 5209-EDIT-CF-LDEP-X
557660     END-IF.

           IF MIR-LATST-CF-DT = EBLCH-BLANK-FIELD-CHAR
               SET UPDATE-NEEDED            TO TRUE
               MOVE WWKDT-ZERO-DT     TO WCVGS-LATST-CF-DT (I)
               MOVE SPACES            TO MIR-LATST-CF-DT
               GO TO 5209-EDIT-CF-LDEP-X
557660     END-IF.

           MOVE MIR-LATST-CF-DT       TO L1640-EXTERNAL-DATE.

020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF L1640-NOT-VALID
               SET INPUT-NOT-VALID          TO TRUE
               MOVE 'CS01520014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET UPDATE-NEEDED            TO TRUE
               MOVE L1640-INTERNAL-DATE
                                      TO WCVGS-LATST-CF-DT (I)
557660     END-IF.
      *
       5209-EDIT-CF-LDEP-X.
           EXIT.
      *
      *-------------------
       5210-EDIT-COMM-DUR.
      *-------------------
           IF MIR-PREV-ANNV-CVGD-DUR = SPACES
               MOVE WCVGS-PREV-ANNV-CVGD-DUR-N (I)
                                      TO WS-HOLD-3-0
               MOVE WS-DISP-3-0       TO MIR-PREV-ANNV-CVGD-DUR
               GO TO 5210-EDIT-COMM-DUR-X
557660     END-IF.

           IF MIR-PREV-ANNV-CVGD-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS             TO MIR-PREV-ANNV-CVGD-DUR
557660     END-IF.

           MOVE MIR-PREV-ANNV-CVGD-DUR              TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WCVGS-PREV-ANNV-CVGD-DUR-N (I)
               MOVE L0280-OUTPUT      TO WS-HOLD-3-0
               MOVE WS-DISP-3-0       TO MIR-PREV-ANNV-CVGD-DUR
               SET UPDATE-NEEDED       TO TRUE
           ELSE
               SET INPUT-NOT-VALID     TO TRUE
               MOVE 'CS01520012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       5210-EDIT-COMM-DUR-X.
           EXIT.
      *
012138*-----------------------
031037*5211-EDIT-CVG-SEC-GAP.
012138*-----------------------
031037*    IF MIR-CVG-SE-GDLN-AMT = SPACES
020874*        COMPUTE  L0290-INPUT-NUMBER
020874*              =  WCVGS-CVG-SE-GDLN-AMT(I) * 100
031037*        MOVE WCVGS-CVG-SE-GDLN-AMT(I)     TO L0290-INPUT-V02
031037*        MOVE 2                            TO L0290-PRECISION
031037*        MOVE LENGTH OF MIR-CVG-SE-GDLN-AMT
031037*                               TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
031037*        PERFORM 0290-2000-FORMAT-FOR-MIR
031037*           THRU 0290-2000-FORMAT-FOR-MIR-X
031037*        MOVE  L0290-OUTPUT-DATA            TO MIR-CVG-SE-GDLN-AMT
031037*        GO TO 5211-EDIT-CVG-SEC-GAP-X
031037*    END-IF.
012138
031037*    IF MIR-CVG-SE-GDLN-AMT = EBLCH-BLANK-FIELD-CHAR
031037*        MOVE ZEROS             TO MIR-CVG-SE-GDLN-AMT
031037*    END-IF.
031037*
031037*    MOVE MIR-CVG-SE-GDLN-AMT   TO L0280-INPUT-DATA.
031037*    SET  L0280-SIGN-NOT-PERMITTED   TO TRUE.
031037*    MOVE 2                     TO L0280-PRECISION.
031037*    MOVE LENGTH OF MIR-CVG-SE-GDLN-AMT
031037*                               TO L0280-INPUT-SIZE.
031037*    COMPUTE  L0280-LENGTH = L0280-INPUT-SIZE - 3.
031037*    PERFORM  0280-1000-NUMERIC-EDIT
031037*        THRU 0280-1000-NUMERIC-EDIT-X.
031037*
031037*    IF L0280-OK
031037*        MOVE L0280-OUTPUT-DOLLAR
031037*                               TO WCVGS-CVG-SE-GDLN-AMT (I)
031037*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
031037*        MOVE 2                 TO L0290-PRECISION
031037*        MOVE LENGTH OF MIR-CVG-SE-GDLN-AMT
031037*                               TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
031037*        PERFORM 0290-2000-FORMAT-FOR-MIR
031037*           THRU 0290-2000-FORMAT-FOR-MIR-X
031037*        MOVE L0290-OUTPUT-DATA TO MIR-CVG-SE-GDLN-AMT
031037*        SET  UPDATE-NEEDED          TO TRUE
031037*    ELSE
031037*        SET INPUT-NOT-VALID         TO TRUE
012138***MSG: SEC GUIDELINE AMOUNT MUST BE VALID NUMERIC
031037*        MOVE 'CS01520068'      TO WGLOB-MSG-REF-INFO
031037*        PERFORM  0260-1000-GENERATE-MESSAGE
031037*            THRU 0260-1000-GENERATE-MESSAGE-X
031037*    END-IF.
031037*5211-EDIT-CVG-SEC-GAP-X.
031037*    EXIT.
012138*
016306*----------------------------
016306 5212-MTG-CALC-EDITS.
016306*----------------------------
016306*  NUMERIC EDIT: INTEREST RATE
016306*
016306     MOVE 'N'                      TO L0280-SIGN-IND.
016306     MOVE 4                        TO L0280-PRECISION.
016306     MOVE 6                        TO L0280-LENGTH.
016306     MOVE MIR-ANN-MTG-INT-PCT      TO L0280-INPUT-DATA.
016306
016306     PERFORM  0280-1000-NUMERIC-EDIT
016306         THRU 0280-1000-NUMERIC-EDIT-X.
016306
016306     IF  L0280-OK
016306         MOVE L0280-OUTPUT-V04     TO
016306                         WCVGS-ANN-MTG-INT-PCT (I)
016306     ELSE
016306*MSG: ANNUAL MORTGAGE INTEREST RATE MUST BE NUMERIC
016306         MOVE 'CS01520076'        TO WGLOB-MSG-REF-INFO
016306         PERFORM  0260-1000-GENERATE-MESSAGE
016306             THRU 0260-1000-GENERATE-MESSAGE-X
016306     END-IF.
016306
016306*  VALIDITY EDIT: INTEREST COMPOUNDS
016306*
018763*    IF  MIR-CVG-INT-CMPND-CD = EBLCH-BLANK-FIELD-CHAR
018763*        MOVE SPACES TO MIR-CVG-INT-CMPND-CD
018763     IF  MIR-INT-CMPND-FREQ-CD = EBLCH-BLANK-FIELD-CHAR
018763         MOVE SPACES TO MIR-INT-CMPND-FREQ-CD
016306     END-IF.
016306
018763*    MOVE MIR-CVG-INT-CMPND-CD TO WS-CVG-INT-CMPND-CD
018763*    IF  WS-CVG-INT-CMPND-VALID
018763*        MOVE MIR-CVG-INT-CMPND-CD  TO
018763*                           WCVGS-CVG-INT-CMPND-CD (I)
018763     MOVE MIR-INT-CMPND-FREQ-CD TO WS-INT-CMPND-FREQ-CD
018763     IF  WS-INT-CMPND-FREQ-VALID
018763         MOVE MIR-INT-CMPND-FREQ-CD TO
018763                            WCVGS-INT-CMPND-FREQ-CD (I)
016306     ELSE
016306*MSG: INTEREST COMPOUNDINGS PER YEAR MUST BE VALID
016306         MOVE 'CS01520077'        TO WGLOB-MSG-REF-INFO
016306         PERFORM  0260-1000-GENERATE-MESSAGE
016306             THRU 0260-1000-GENERATE-MESSAGE-X
016306     END-IF.
016306
016306*  NUMERIC EDIT: REPAYMENT AMOUNT
016306*
016306     MOVE 'N'                      TO L0280-SIGN-IND.
016306     MOVE 2                        TO L0280-PRECISION.
016306     MOVE 15                       TO L0280-LENGTH.
016306     MOVE MIR-CVG-MTG-REPAY-AMT  TO L0280-INPUT-DATA.
016306
016306     PERFORM  0280-1000-NUMERIC-EDIT
016306         THRU 0280-1000-NUMERIC-EDIT-X.
016306
016306     IF  L0280-OK
016306         MOVE L0280-OUTPUT-DOLLAR     TO
016306                            WCVGS-CVG-MTG-REPAY-AMT (I)
016306     ELSE
016306*MSG: MORTGAGE REPAYMENT AMOUNT MUST BE NUMERIC
016306         MOVE 'CS01520078'        TO WGLOB-MSG-REF-INFO
016306         PERFORM  0260-1000-GENERATE-MESSAGE
016306             THRU 0260-1000-GENERATE-MESSAGE-X
016306     END-IF.
016306
016306*  VALIDITY EDIT: REPAYMENT FREQUENCY
016306*
016306     IF  MIR-MTG-REPAY-FREQ-CD = EBLCH-BLANK-FIELD-CHAR
016306         MOVE SPACES TO MIR-MTG-REPAY-FREQ-CD
016306     END-IF.
016306
016306     MOVE MIR-MTG-REPAY-FREQ-CD TO WS-MTG-REPAY-FREQ-CD
016306     IF  WS-MTG-REPAY-FREQ-VALID
016306         MOVE MIR-MTG-REPAY-FREQ-CD  TO
016306                             WCVGS-MTG-REPAY-FREQ-CD (I)
016306     ELSE
016306*MSG: MORTGAGE AMOUNT REPAYMENT FREQUENCY MUST BE VALID
016306         MOVE 'CS01520079'        TO WGLOB-MSG-REF-INFO
016306         PERFORM  0260-1000-GENERATE-MESSAGE
016306             THRU 0260-1000-GENERATE-MESSAGE-X
016306     END-IF.
016306
016306*  NUMERIC EDIT: PREVIOUS SUM INSURED AMOUNT
016306*
016306     MOVE 'N'                      TO L0280-SIGN-IND.
016306     MOVE 2                        TO L0280-PRECISION.
016306     MOVE 15                       TO L0280-LENGTH.
016306     MOVE MIR-PREV-SUM-INS-AMT  TO L0280-INPUT-DATA.
016306
016306     PERFORM  0280-1000-NUMERIC-EDIT
016306         THRU 0280-1000-NUMERIC-EDIT-X.
016306
016306     IF  L0280-OK
016306         MOVE L0280-OUTPUT-DOLLAR     TO
016306                            WCVGS-PREV-SUM-INS-AMT (I)
016306     ELSE
016306*MSG: PREVIOUS SUM INSURED AMOUNT MUST BE NUMERIC
016306         MOVE 'CS01520080'        TO WGLOB-MSG-REF-INFO
016306         PERFORM  0260-1000-GENERATE-MESSAGE
016306             THRU 0260-1000-GENERATE-MESSAGE-X
016306     END-IF.
016306
016306 5212-MTG-CALC-EDITS-X.
016306     EXIT.
018846*---------------------------
018846 5213-EDIT-PLAN-FND-TYP-CD.
018846*---------------------------
018846
018846     IF  MIR-PLAN-FND-TYP-CD = SPACES
018846         MOVE WCVGS-PLAN-FND-TYP-CD (I)
018846                                TO MIR-PLAN-FND-TYP-CD
018846         GO TO 5213-EDIT-PLAN-FND-TYP-CD-X
018846     END-IF.
018846
018846     IF  MIR-PLAN-FND-TYP-CD = EBLCH-BLANK-FIELD-CHAR
018846         MOVE SPACE             TO MIR-PLAN-FND-TYP-CD
018846     END-IF.
018846
018770*    MOVE 'PLAN-FND-TYP-CD'         TO WDMAD-DM-AV-TBL-CD.
018770*    MOVE MIR-PLAN-FND-TYP-CD       TO WDMAD-DM-AV-CD.
018770*    MOVE WGLOB-USER-LANG           TO WDMAD-DM-AV-DESC-LANG-CD.
018770*
018770*    PERFORM  DMAD-2000-READ-INDEX
018770*        THRU DMAD-2000-READ-INDEX-X.
018770*
018770*    IF  WDMAD-IO-OK
018770     PERFORM  8960-1000-BUILD-PARM-INFO
018770         THRU 8960-1000-BUILD-PARM-INFO-X.
018770     MOVE 'PLAN-FND-TYP-CD'         TO L8960-AV-TBL-CD.
018770     MOVE MIR-PLAN-FND-TYP-CD       TO L8960-AV-CD.
018770
018770     PERFORM  8960-1000-VALIDATE-CODE
018770         THRU 8960-1000-VALIDATE-CODE-X.
018770
018770     IF  L8960-RETRN-OK
018846         SET UPDATE-NEEDED       TO TRUE
018846         MOVE MIR-PLAN-FND-TYP-CD
018846                                 TO WCVGS-PLAN-FND-TYP-CD (I)
018846     ELSE
018846         SET INPUT-NOT-VALID     TO TRUE
018846*MSG: INVALID PLAN FUND TYPE CODE
018846         MOVE 'CS01520081'       TO WGLOB-MSG-REF-INFO
018846         PERFORM  0260-1000-GENERATE-MESSAGE
018846             THRU 0260-1000-GENERATE-MESSAGE-X
018846     END-IF.
018846
018846 5213-EDIT-PLAN-FND-TYP-CD-X.
018846     EXIT.
018846
      *
      *-------------------*
       6000-PROCESS-INPUT.
      *-------------------*

           IF UPDATE-NEEDED
               PERFORM  6010-PRCES-UPDATE
                   THRU 6010-PRCES-UPDATE-X
           ELSE
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               PERFORM  CVG-3000-UNLOCK
                   THRU CVG-3000-UNLOCK-X
           END-IF.

       6000-PROCESS-INPUT-X.
           EXIT.
      *
      *------------------
       6010-PRCES-UPDATE.
      *------------------

           MOVE WCVG-KEY              TO RCVG-KEY
           MOVE WCVGS-CVG-INFO (I)    TO RCVG-CVG-INFO
           PERFORM  CVG-2000-REWRITE
               THRU CVG-2000-REWRITE-X
557699     IF WGLOB-AUDIT-REQUESTED
557699         PERFORM  CVG-1000-CALL-AUDIT
557699             THRU CVG-1000-CALL-AUDIT-X
557699     END-IF.
016503*    IF  WCVGS-CVG-STAT-IN-FORCE (I)
016503*        MOVE WWKDT-ZERO-DT     TO RPOL-POL-NXT-ACTV-DT
016503*        IF  RPOL-NXT-ACTV-TYP-CD = 'SCH'
016503*            PERFORM  POL-2000-REWRITE
016503*                THRU POL-2000-REWRITE-X
016503*        ELSE
016503*            MOVE 'RSH'         TO RPOL-NXT-ACTV-TYP-CD
016503*            PERFORM  POL-2000-REWRITE
016503*                THRU POL-2000-REWRITE-X
016503*            IF WGLOB-AUDIT-REQUESTED
016503*                PERFORM  POL-1000-CALL-AUDIT
016503*                    THRU POL-1000-CALL-AUDIT-X
016503*            END-IF
016503*        END-IF
016503*    ELSE
016503*        PERFORM  POL-3000-UNLOCK
016503*            THRU POL-3000-UNLOCK-X
016503*    END-IF.
016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.
016503     PERFORM  POL-2000-REWRITE
016503          THRU POL-2000-REWRITE-X.

016503     IF WGLOB-AUDIT-REQUESTED
016503        PERFORM  POL-1000-CALL-AUDIT
016503            THRU POL-1000-CALL-AUDIT-X
016503     END-IF.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

       6010-PRCES-UPDATE-X.
           EXIT.
035393
035393*-----------------
035393 6100-CCHG-EVENT.
035393*-----------------
035393
035393     PERFORM  0319-0000-INIT-PARM-INFO
035393         THRU 0319-0000-INIT-PARM-INFO-X.
035393     SET L0319-XTRNL-EVNT-CITS-CVGSTAT
035393                                     TO TRUE.
035393     MOVE WGLOB-SYS-CTL-ID           TO L0319-SYS-CTL-ID
035393     PERFORM  0319-1000-GET-EVNT-EXIT-PGM
035393         THRU 0319-1000-GET-EVNT-EXIT-PGM-X.
035393
035393     PERFORM
035393         VARYING WS-INDEX FROM 1 BY 1
035393         UNTIL   WS-INDEX > L0319-XTRNL-EVNT-CNT
035393
035393         IF  L0319-XTRNL-EVNT-PUBLISH (WS-INDEX)
035393
035393             PERFORM  CITC-0000-INIT-PARM-INFO
035393                 THRU CITC-0000-INIT-PARM-INFO-X
035393             MOVE RPOL-POL-ID        TO LCITC-POL-ID
035393             MOVE RPOL-SERV-BR-ID    TO LCITC-SERV-BR-ID
035393             MOVE RPOL-SERV-AGT-ID   TO LCITC-AGT-ID
035393             MOVE L0319-XTRNL-EVNT-PGM-ID (WS-INDEX)
035393                                     TO LCITC-CALL-PGM-ID
035393             MOVE L0319-XTRNL-DOC-ID (WS-INDEX)
035393                                     TO LCITC-DOC-ID
035393             MOVE L0319-XTRNL-SYS-ID (WS-INDEX)
035393                                     TO LCITC-XTRNL-SYS-ID
035393             MOVE L0319-XTRNL-EVNT-ID
035393                                     TO LCITC-XTRNL-EVNT-ID
035393             PERFORM  CITC-1000-PEND-POL-CHANGE
035393                 THRU CITC-1000-PEND-POL-CHANGE-X
035393
035393         END-IF
035393     END-PERFORM.
035393
035393 6100-CCHG-EVENT-X.
035393     EXIT.
      *
      ************************
       8000-GET-POLICY-MASTER.
      ************************

           SET POLICY-VALID                 TO TRUE.

013578     IF  WS-BUS-FCN-RETRIEVE
014221*        PERFORM  POL-1000-READ
014221*            THRU POL-1000-READ-X
014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X
           ELSE
014221*        PERFORM  POL-1000-READ-FOR-UPDATE
014221*            THRU POL-1000-READ-FOR-UPDATE-X
014221         PERFORM  POL-2000-UPDATE-TWRK-TS
014221             THRU POL-2000-UPDATE-TWRK-TS-X
014221         IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221            MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221            MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221            MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221            PERFORM  0260-1000-GENERATE-MESSAGE
014221                THRU 0260-1000-GENERATE-MESSAGE-X
014221            SET POLICY-NOT-VALID       TO TRUE
014221            GO TO 8000-GET-POLICY-MASTER-X
014221        END-IF
557660     END-IF.

557699*    IF NOT WPOL-IO-OK
557699     IF  WPOL-IO-OK
557699         IF WGLOB-AUDIT-REQUESTED
557699             PERFORM POL-1000-CALL-AUDIT
557699                THRU POL-1000-CALL-AUDIT-X
557699         END-IF
016503         PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
016503             THRU CVGS-1000-LOAD-CVGS-ARRAY-X
016503         MOVE MIR-CVG-NUM             TO I
016503         MOVE MIR-CVG-NUM             TO WCVG-CVG-NUM-N
557699     ELSE
               SET POLICY-NOT-VALID         TO TRUE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           IF  WPOL-IO-OK
               PERFORM  5400-1000-BUILD-PARM-INFO
                   THRU 5400-1000-BUILD-PARM-INFO-X
016440         IF  WS-BUS-FCN-UPDATE
016440             SET L5400-POL-XFER-UPDATE    TO TRUE
019297             SET L5400-CRCY-MSG-REQD      TO TRUE
016440         END-IF
               PERFORM  5400-1000-POL-CHK
                   THRU 5400-1000-POL-CHK-X
               PERFORM  8050-CHECK-ACCESS
                   THRU 8050-CHECK-ACCESS-X
           END-IF.

016440* SIMILAR TO THE POLICY TRANSFER EDIT, WE ALSO NEED TO PERFORM
016440* AN EDIT ON THE COVERAGE STATUS - ISSUE A WARNING WHEN THE
016440* BUSINESS FUNCTION IS RETRIEVE AND ONLY ALLOW THE CVG-STATUS
016440* TO BE UPDATED WHEN THE BUSINESS FUNCTION IS AN UPDATE

016440     IF   WCVGS-CVG-STAT-XFER-XTRNL (I)
016440     AND  WS-BUS-FCN-RETRIEVE
016440          MOVE 'CS01520042'           TO WGLOB-MSG-REF-INFO
016440          PERFORM  0260-1000-GENERATE-MESSAGE
016440              THRU 0260-1000-GENERATE-MESSAGE-X
016440     END-IF.

016440     IF  WCVGS-CVG-STAT-XFER-XTRNL (I)
016440     AND MIR-CVG-CSTAT-CD NOT = WCVGS-CVG-CSTAT-CD (I)
016440         CONTINUE
016440     ELSE
016440         IF WS-BUS-FCN-UPDATE
016440         AND MIR-CVG-CSTAT-CD = WCVGS-CVG-CSTAT-CD (I)
016440         AND WCVGS-CVG-STAT-XFER-XTRNL (I)
016440            MOVE 'CS01520043'            TO WGLOB-MSG-REF-INFO
016440            PERFORM 0260-1000-GENERATE-MESSAGE
016440               THRU 0260-1000-GENERATE-MESSAGE-X
016440            SET POLICY-NOT-VALID         TO TRUE
016440         END-IF
016440     END-IF.

           IF  POLICY-VALID
           AND RPOL-POL-CVG-REC-CTR-N = 0
               SET POLICY-NOT-VALID         TO TRUE
               MOVE 'CS01520038'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
010311*    IF POLICY-VALID AND HOLD-RIDER > RPOL-POL-CVG-REC-CTR-N
010311     IF POLICY-VALID
010311     AND HOLD-RIDER > RPOL-POL-CVG-REC-CTR-N
              SET POLICY-NOT-VALID         TO TRUE
              MOVE 'CS01520039'       TO WGLOB-MSG-REF-INFO
              MOVE RPOL-POL-CVG-REC-CTR-N
                                      TO WGLOB-MSG-PARM (1)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       8000-GET-POLICY-MASTER-X.
           EXIT.
      *
      *------------------
       8050-CHECK-ACCESS.
      *------------------

           IF  L5400-CNFD-ACCS-RESTRICTED
020180*    OR  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
016440     OR  L5400-XFER-ACCS-RESTRICTED
               SET POLICY-NOT-VALID     TO TRUE
           END-IF.

020180     IF  L5400-CRCY-ACCS-RESTRICTED
020180     AND WS-BUS-FCN-UPDATE
020180         SET POLICY-NOT-VALID     TO TRUE
020180     END-IF.

       8050-CHECK-ACCESS-X.
           EXIT.
      *

       8100-GET-RIDER.
      ******************************************************
      *  ARRANGES TO READ THE RIDER  RECORD.               *
      ******************************************************

           SET RIDER-VALID                  TO TRUE.
           PERFORM  CVG-1000-READ-FOR-UPDATE
               THRU CVG-1000-READ-FOR-UPDATE-X.
           IF NOT WCVG-IO-OK
               SET RIDER-NOT-VALID          TO TRUE
               MOVE 'CS00000021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  CVG-3000-UNLOCK
                   THRU CVG-3000-UNLOCK-X
           ELSE
557699         IF WGLOB-AUDIT-REQUESTED
557699             PERFORM CVG-1000-CALL-AUDIT
557699                THRU CVG-1000-CALL-AUDIT-X
557699         END-IF
               MOVE RCVG-CVG-INFO     TO WCVGS-CVG-INFO (I)
               MOVE RCVG-CVG-NUM      TO WCVGS-CVG-SEQ-NUM (I)
           END-IF.

       8100-GET-RIDER-X.
           EXIT.
      *
      *---------------------*
       8200-MOVE-RIDER-INFO.
      *---------------------*

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.
           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           PERFORM  8300-MOVE-INFO-TO-SCREEN1
               THRU 8300-MOVE-INFO-TO-SCREEN1-X
           PERFORM  8400-MOVE-INFO-TO-SCREEN2
               THRU 8400-MOVE-INFO-TO-SCREEN2-X.

       8200-MOVE-RIDER-INFO-X.
           EXIT.
      *
      *-------------------------*
       8300-MOVE-INFO-TO-SCREEN1.
      *-------------------------*

557668*    MOVE L2430-CLI-NM-COMPRESSED     TO MIR-DV-CLI-NM.

557668     INITIALIZE L0620-INPUT-PARM-INFO.
557668     IF L2430-CLI-SEX-COMPANY
557668         MOVE L2430-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
557668     ELSE
557668         MOVE L2430-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
557668         MOVE L2430-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
013578         MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
013578         MOVE L2430-CLI-SFX-NM  TO L0620-CLI-SFX-NM
557668     END-IF.
557668     MOVE L2430-CLI-SEX-CD      TO L0620-CLI-SEX-CD.

557668     PERFORM  0620-1000-FORMAT-SCREEN-NAME
557668         THRU 0620-1000-FORMAT-SCREEN-NAME-X.

557668     MOVE L0620-SCREEN-NAME     TO MIR-DV-INSRD-CLI-NM.

           MOVE WCVGS-PLAN-ID (I)     TO MIR-PLAN-ID.

           MOVE WCVGS-CVG-CSTAT-CD (I)              TO MIR-CVG-CSTAT-CD.
           MOVE WCVGS-CVG-PREV-CSTAT-CD (I)
                                      TO MIR-CVG-PREV-CSTAT-CD.
           MOVE WCVGS-CVG-STAT-PRCES-DT (I)
                                      TO L1640-INTERNAL-DATE.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           IF  L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CVG-STAT-PRCES-DT
           ELSE
               MOVE SPACES            TO MIR-CVG-STAT-PRCES-DT
557660     END-IF.

010302*    MOVE WCVGS-CVG-ADJ-DT        (I) TO L1640-INTERNAL-DATE.
010302*
010302*    PERFORM 1640-2000-INTERNAL-TO-EXT
010302*       THRU 1640-2000-INTERNAL-TO-EXT-X.
010302*
010302*    IF  L1640-VALID
010302*        MOVE L1640-EXTERNAL-DATE     TO MIR-ADJDATE
010302*    ELSE
010302*        MOVE SPACES                  TO MIR-ADJDATE
010302*557660     END-IF.

           MOVE WCVGS-CVG-INS-TYP-CD (I)
                                      TO MIR-CVG-INS-TYP-CD.
           MOVE WCVGS-CVG-ACCT-TYP-CD (I)
                                      TO MIR-CVG-ACCT-TYP-CD.
           MOVE WCVGS-CVG-CNVR-IND (I)              TO MIR-CVG-CNVR-IND.
008455*    MOVE WCVGS-CVG-NET-REISS-AMT (I) TO WS-HOLD-S9-2.
008455*    MOVE WS-DISP-S9-2                TO MIR-CVG-NET-REISS-AMT.
008455     MOVE WCVGS-CVG-NET-REISS-AMT (I)
                                      TO L0290-INPUT-NUMBER.
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-CVG-NET-REISS-AMT (I) * 100.
020874     MOVE WCVGS-CVG-NET-REISS-AMT (I)     TO L0290-INPUT-V02.
008455     MOVE 2                               TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-NET-REISS-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY          TO TRUE.
008455     SET  L0290-SIGN-POS-DISPLAY      TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-NET-REISS-AMT.
           MOVE WCVGS-ULT-PREM-RT-CD (I)
                                      TO MIR-ULT-PREM-RT-CD.
014591***  MOVE WCVGS-ORIG-PLAN-BASE-ID (I)
014591***                             TO MIR-ORIG-PLAN-BASE-ID.
014591     MOVE WCVGS-ORIG-PLAN-ID (I) TO MIR-ORIG-PLAN-ID.

008455*    MOVE WCVGS-CVG-MDRT-AMT (I)      TO WS-HOLD-S9.
008455*    MOVE WS-DISP-S9                  TO MIR-CVG-MDRT-AMT.
020874*    MOVE WCVGS-CVG-MDRT-AMT (I)            TO L0290-INPUT-NUMBER.
020874     MOVE WCVGS-CVG-MDRT-AMT (I)            TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-MDRT-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY          TO TRUE.
008455     SET  L0290-SIGN-POS-DISPLAY      TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-MDRT-AMT.
008455*    MOVE WCVGS-CVG-FYR-COMM-AMT (I)  TO WS-HOLD-7-2.
008455*    MOVE WS-DISP-7-2                 TO MIR-CVG-FYR-COMM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-CVG-FYR-COMM-AMT (I) * 100.
020874     MOVE WCVGS-CVG-FYR-COMM-AMT (I)     TO L0290-INPUT-V02.
008455     MOVE 2                              TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-FYR-COMM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-FYR-COMM-AMT.
008455*    MOVE WCVGS-CVG-FACE-AMT (I)      TO WS-HOLD-9-2.
008455*    MOVE WS-DISP-9-2                 TO MIR-CVG-FACE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-CVG-FACE-AMT (I) * 100.
020874     MOVE WCVGS-CVG-FACE-AMT (I)  TO L0290-INPUT-V02.
008455     MOVE 2                       TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-FACE-AMT
                                        TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-FACE-AMT.
008455*    MOVE WCVGS-CVG-PREV-FACE-AMT (I) TO WS-HOLD-9-2.
008455*    MOVE WS-DISP-9-2                 TO MIR-CVG-PREV-FACE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-CVG-PREV-FACE-AMT (I) * 100.
020874     MOVE WCVGS-CVG-PREV-FACE-AMT (I)  TO L0290-INPUT-V02.
008455     MOVE 2                            TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-PREV-FACE-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-PREV-FACE-AMT.
008455*    MOVE WCVGS-CVG-PREV-UPREM-AMT (I) TO WS-HOLD-3-2.
008455*    MOVE WS-DISP-3-2                 TO MIR-CVG-PREV-UPREM-AMT
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-CVG-PREV-UPREM-AMT (I) * 100.
020874     MOVE WCVGS-CVG-PREV-UPREM-AMT (I)  TO L0290-INPUT-V02.
008455     MOVE 2                             TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-PREV-UPREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-PREV-UPREM-AMT.
008455*    MOVE WCVGS-CVG-NXT-UPREM-AMT (I) TO WS-HOLD-3-2.
008455*    MOVE WS-DISP-3-2                 TO MIR-CVG-NXT-UPREM-AMT
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-CVG-NXT-UPREM-AMT (I) * 100.
020874     MOVE WCVGS-CVG-NXT-UPREM-AMT (I)  TO L0290-INPUT-V02.
008455     MOVE 2                            TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-NXT-UPREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-NXT-UPREM-AMT.
008455*    MOVE WCVGS-PREV-WP-UPREM-AMT (I) TO WS-HOLD-3-2.
008455*    MOVE WS-DISP-3-2                 TO MIR-LWPRATE.
010302*    COMPUTE L0290-INPUT-NUMBER
010302*          = WCVGS-PREV-WP-UPREM-AMT (I) * 100.
010302*    MOVE 2                           TO L0290-PRECISION.
010302*    MOVE LENGTH OF MIR-LWPRATE       TO L0290-MAX-OUT-LEN.
010302*    PERFORM 0290-1000-NUMERIC-FORMAT
010302*       THRU 0290-1000-NUMERIC-FORMAT-X.
010302*    MOVE L0290-OUTPUT-DATA           TO MIR-LWPRATE.

008455*    MOVE WCVGS-CVG-WP-YTD-AMT (I)    TO WS-HOLD-7-2.
008455*    MOVE WS-DISP-7-2                 TO MIR-CVG-WP-YTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-CVG-WP-YTD-AMT (I) * 100.
020874     MOVE WCVGS-CVG-WP-YTD-AMT (I)  TO L0290-INPUT-V02.
008455     MOVE 2                         TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-WP-YTD-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-WP-YTD-AMT.
008455*    MOVE WCVGS-CVG-WP-LTD-AMT (I)    TO WS-HOLD-7-2.
008455*    MOVE WS-DISP-7-2                 TO MIR-CVG-WP-LTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-CVG-WP-LTD-AMT (I) * 100.
020874     MOVE WCVGS-CVG-WP-LTD-AMT (I)  TO L0290-INPUT-V02.
008455     MOVE 2                         TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-WP-LTD-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-WP-LTD-AMT.
008455*    MOVE WCVGS-CVG-CLM-YTD-AMT (I)   TO WS-HOLD-7-2.
008455*    MOVE WS-DISP-7-2                 TO MIR-CVG-CLM-YTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-CVG-CLM-YTD-AMT (I) * 100.
020874     MOVE WCVGS-CVG-CLM-YTD-AMT (I)  TO L0290-INPUT-V02.
008455     MOVE 2                          TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-CLM-YTD-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-CLM-YTD-AMT.
008455*    MOVE WCVGS-CVG-CLM-LTD-AMT (I)   TO WS-HOLD-7-2.
008455*    MOVE WS-DISP-7-2                 TO MIR-CVG-CLM-LTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-CVG-CLM-LTD-AMT (I) * 100.
020874     MOVE WCVGS-CVG-CLM-LTD-AMT (I)  TO L0290-INPUT-V02.
008455     MOVE 2                          TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-CLM-LTD-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-CLM-LTD-AMT.

           PERFORM  2450-1000-BUILD-PARM-INFO
               THRU 2450-1000-BUILD-PARM-INFO-X.
           PERFORM  2450-2000-READ-CVG-AGENTS
               THRU 2450-2000-READ-CVG-AGENTS-X.

           PERFORM  8310-MOVE-AGENT-INFO
               THRU 8310-MOVE-AGENT-INFO-X
               VARYING J FROM 1 BY 1
               UNTIL J > 3

008455*    MOVE WCVGS-CVG-ORIG-FACE-AMT (I) TO WS-HOLD-9-2.
008455*    MOVE WS-DISP-9-2                 TO MIR-CVG-ORIG-FACE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-CVG-ORIG-FACE-AMT (I) * 100.
020874     MOVE WCVGS-CVG-ORIG-FACE-AMT (I)  TO L0290-INPUT-V02.
008455     MOVE 2                            TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-ORIG-FACE-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-ORIG-FACE-AMT.

008455*    MOVE WCVGS-CVG-SUM-INS-AMT (I)   TO WS-HOLD-9-2.
008455*    MOVE WS-DISP-9-2                 TO MIR-CVG-SUM-INS-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-CVG-SUM-INS-AMT (I) * 100.
020874     MOVE WCVGS-CVG-SUM-INS-AMT (I)  TO L0290-INPUT-V02.
008455     MOVE 2                          TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-SUM-INS-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-SUM-INS-AMT.

557659*    MOVE WCVGS-CVG-XHBT-ISS-IND-N (I) TO MIR-CVG-XHBT-ISS-IND.
557659     MOVE WCVGS-CVG-XHBT-ISS-IND (I)
                                      TO MIR-CVG-XHBT-ISS-IND.
           MOVE WCVGS-CVG-XHBT-ISS-DT (I)
                                      TO L1640-INTERNAL-DATE.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           IF  L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CVG-XHBT-ISS-DT
           ELSE
               MOVE SPACES            TO MIR-CVG-XHBT-ISS-DT
557660     END-IF.

           MOVE WCVGS-CVG-XHBT-TRMN-QTY-N (I)
                                      TO MIR-CVG-XHBT-TRMN-QTY.
           MOVE WCVGS-CVG-XHBT-TRMN-DT (I)
                                      TO L1640-INTERNAL-DATE.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           IF  L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CVG-XHBT-TRMN-DT
           ELSE
               MOVE SPACES            TO MIR-CVG-XHBT-TRMN-DT
557660     END-IF.

           MOVE WCVGS-XHBT-REINST-QTY-N (I)
                                      TO MIR-XHBT-REINST-QTY.
           MOVE WCVGS-CVG-XHBT-REINST-DT (I)
                                      TO L1640-INTERNAL-DATE.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           IF  L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CVG-XHBT-REINST-DT
           ELSE
               MOVE SPACES            TO MIR-CVG-XHBT-REINST-DT
557660     END-IF.

           MOVE WCVGS-CVG-APP-CMPLT-DT (I)
                                      TO L1640-INTERNAL-DATE.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           IF  L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CVG-APP-CMPLT-DT
           ELSE
               MOVE SPACES            TO MIR-CVG-APP-CMPLT-DT
557660     END-IF.

           MOVE WCVGS-CVG-MTHV-STRT-DT (I)
                                      TO L1640-INTERNAL-DATE.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           IF  L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CVG-MTHV-STRT-DT
           ELSE
               MOVE SPACES            TO MIR-CVG-MTHV-STRT-DT
557660     END-IF.

010418     MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.
012145     MOVE WCVGS-CVG-COLFND-IND (I)
                                      TO MIR-CVG-COLFND-IND.

021239*    IF  NOT   WCVGS-CVG-INS-TYP-SEG-FUND (I)
021239*        MOVE 'N'               TO MIR-CVG-UNIT-TYP-CD
021239*        GO TO 8300-MOVE-INFO-TO-SCREEN1-X
021239*    ELSE
021239*        MOVE WCVGS-CVG-UNIT-TYP-CD (I)
021239*                               TO  MIR-CVG-UNIT-TYP-CD
021239*    END-IF.
021239*
021239     MOVE WCVGS-CVG-UNIT-TYP-CD (I)
021239                                TO  MIR-CVG-UNIT-TYP-CD.
021239
020475     MOVE WCVGS-CVG-DBG-INCL-IND (I)
020475                                TO  MIR-CVG-DBG-INCL-IND.

       8300-MOVE-INFO-TO-SCREEN1-X.
           EXIT.
      *
      *
      *---------------------
       8310-MOVE-AGENT-INFO.
      *---------------------

           MOVE L2450-AGT-ID (I, J)   TO MIR-AGT-ID-T (J).

           IF  MIR-AGT-ID-T (J) NOT = SPACES
013578*        MOVE J                 TO WS-HOLD-1-0
013578*        MOVE WS-DISP-1-0       TO MIR-AGNUM-T (J)
               MOVE L2450-PARTL-ADV-TYP-CD (I, J)
                                      TO MIR-PARTL-ADV-TYP-CD-T (J)
008455*        MOVE L2450-PARTL-ADV-AMT (I, J)     TO WS-HOLD-5-2
008455*        MOVE WS-DISP-5-2               TO MIR-PARTL-ADV-AMT-T (J)
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = L2450-PARTL-ADV-AMT (I, J) * 100
020874         MOVE L2450-PARTL-ADV-AMT (I, J)  TO L0290-INPUT-V02
008455         MOVE 2                           TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PARTL-ADV-AMT-T (J)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PARTL-ADV-AMT-T (J)
557660     END-IF.

       8310-MOVE-AGENT-INFO-X.
           EXIT.
      *
       8400-MOVE-INFO-TO-SCREEN2.

557668*    MOVE L2430-CLI-NM-COMPRESSED        TO MIR-DV-CLI-NM.
           MOVE WCVGS-PLAN-ID (I)     TO MIR-PLAN-ID.
      *
008455*    MOVE WCVGS-CVG-SURR-TRG-AMT (I)     TO WS-HOLD-7-0.
008455*    MOVE WS-DISP-7-0                    TO MIR-CVG-SURR-TRG-AMT.
020874*    MOVE WCVGS-CVG-SURR-TRG-AMT (I)
020874*                               TO L0290-INPUT-NUMBER.
020874     MOVE WCVGS-CVG-SURR-TRG-AMT (I)  TO L0290-INPUT-V00.
008455     MOVE 0                           TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-SURR-TRG-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-SURR-TRG-AMT.
008455*    MOVE WCVGS-SURR-LOAD-LTD-AMT (I)    TO WS-HOLD-9-2.
008455*    MOVE WS-DISP-9-2                    TO MIR-SURR-LOAD-LTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-SURR-LOAD-LTD-AMT (I) * 100.
020874     MOVE WCVGS-SURR-LOAD-LTD-AMT (I)  TO L0290-INPUT-V02.
008455     MOVE 2                            TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-SURR-LOAD-LTD-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-SURR-LOAD-LTD-AMT.
008455*    MOVE WCVGS-CVG-SURR-LTD-AMT (I)     TO WS-HOLD-11-2.
008455*    MOVE WS-DISP-11-2                   TO MIR-CVG-SURR-LTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-CVG-SURR-LTD-AMT (I) * 100.
020874     MOVE WCVGS-CVG-SURR-LTD-AMT (I)  TO L0290-INPUT-V02.
008455     MOVE 2                           TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-SURR-LTD-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-SURR-LTD-AMT.
008455*    MOVE WCVGS-PMT-LOAD-LTD-AMT (I)     TO WS-HOLD-9-2.
008455*    MOVE WS-DISP-9-2                    TO MIR-PMT-LOAD-LTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-PMT-LOAD-LTD-AMT (I) * 100.
020874     MOVE WCVGS-PMT-LOAD-LTD-AMT (I)  TO L0290-INPUT-V02.
008455     MOVE 2                           TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PMT-LOAD-LTD-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PMT-LOAD-LTD-AMT.
008455*    MOVE WCVGS-CVG-PMT-LTD-AMT (I)      TO WS-HOLD-9-2.
008455*    MOVE WS-DISP-9-2                    TO MIR-CVG-PMT-LTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-CVG-PMT-LTD-AMT (I) * 100.
020874     MOVE WCVGS-CVG-PMT-LTD-AMT (I)  TO L0290-INPUT-V02.
008455     MOVE 2                          TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-PMT-LTD-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-PMT-LTD-AMT.
      *
008455*    MOVE WCVGS-CVG-GDLN-APREM-AMT (I)   TO WS-HOLD-7-2.
008455*    MOVE WS-DISP-7-2                   TO MIR-CVG-GDLN-APREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-CVG-GDLN-APREM-AMT (I) * 100.
020874     MOVE WCVGS-CVG-GDLN-APREM-AMT (I)  TO L0290-INPUT-V02.
008455     MOVE 2                             TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-GDLN-APREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-GDLN-APREM-AMT.
008455*    MOVE WCVGS-CVG-GDLN-SPREM-AMT (I)   TO WS-HOLD-7-2.
008455*    MOVE WS-DISP-7-2                   TO MIR-CVG-GDLN-SPREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-CVG-GDLN-SPREM-AMT (I) * 100.
020874     MOVE WCVGS-CVG-GDLN-SPREM-AMT (I)  TO L0290-INPUT-V02.
008455     MOVE 2                             TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-GDLN-SPREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-GDLN-SPREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = WCVGS-CVG-SE-GDLN-AMT (I) * 100.
031037*    MOVE WCVGS-CVG-SE-GDLN-AMT (I)  TO L0290-INPUT-V02.
031037*    MOVE 2                          TO L0290-PRECISION
031037*    MOVE LENGTH OF MIR-CVG-SE-GDLN-AMT
031037*                               TO L0290-MAX-OUT-LEN
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
031037*    PERFORM 0290-2000-FORMAT-FOR-MIR
031037*       THRU 0290-2000-FORMAT-FOR-MIR-X.
031037*    MOVE L0290-OUTPUT-DATA     TO MIR-CVG-SE-GDLN-AMT
      *
           MOVE WCVGS-CVG-CF-TYP-CD (I)
                                      TO MIR-CVG-CF-TYP-CD.
           MOVE WCVGS-LATST-CF-DT (I) TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-LATST-CF-DT
           ELSE
               MOVE SPACES            TO MIR-LATST-CF-DT
557660     END-IF.
           MOVE WCVGS-PREV-ANNV-CVGD-DUR-N (I)
                                      TO WS-HOLD-3-0.
           MOVE WS-DISP-3-0           TO MIR-PREV-ANNV-CVGD-DUR.
      *
010418     MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.
      *
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                          WCVGS-ANN-MTG-INT-PCT (I) * 10000.
020874     MOVE WCVGS-ANN-MTG-INT-PCT (I)       TO L0290-INPUT-V04.
016306     MOVE 4                               TO L0290-PRECISION.
016306     MOVE LENGTH OF MIR-ANN-MTG-INT-PCT
016306                                          TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016306     MOVE L0290-OUTPUT-DATA     TO MIR-ANN-MTG-INT-PCT.
016306
018763*    MOVE WCVGS-CVG-INT-CMPND-CD (I)
018763*                               TO MIR-CVG-INT-CMPND-CD.
018763     MOVE WCVGS-INT-CMPND-FREQ-CD (I)
018763                                TO MIR-INT-CMPND-FREQ-CD.
016306
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                          WCVGS-CVG-MTG-REPAY-AMT (I) * 100.
020874     MOVE WCVGS-CVG-MTG-REPAY-AMT (I)     TO L0290-INPUT-V02.
016306     MOVE 2                               TO L0290-PRECISION.
016306     MOVE LENGTH OF MIR-CVG-MTG-REPAY-AMT TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016306     MOVE L0290-OUTPUT-DATA         TO MIR-CVG-MTG-REPAY-AMT.
016306
016306     MOVE WCVGS-MTG-REPAY-FREQ-CD (I)
016306                                    TO MIR-MTG-REPAY-FREQ-CD.
016306
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*                          WCVGS-PREV-SUM-INS-AMT (I) * 100.
020874     MOVE WCVGS-PREV-SUM-INS-AMT (I)      TO L0290-INPUT-V02.
016306     MOVE 2                               TO L0290-PRECISION.
016306     MOVE LENGTH OF MIR-PREV-SUM-INS-AMT  TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016306     MOVE L0290-OUTPUT-DATA               TO MIR-PREV-SUM-INS-AMT.
      *
018846     MOVE WCVGS-PLAN-FND-TYP-CD (I) TO MIR-PLAN-FND-TYP-CD.
018846
       8400-MOVE-INFO-TO-SCREEN2-X.
           EXIT.
      *
      ************************
       9100-BLANK-DATA-FIELDS.
      ************************

           MOVE SPACES                TO MIR-DV-INSRD-CLI-NM.
           MOVE SPACES                TO MIR-PLAN-ID.
           MOVE SPACES                TO MIR-CVG-CSTAT-CD.
           MOVE SPACES                TO MIR-CVG-PREV-CSTAT-CD.
           MOVE SPACES                TO MIR-CVG-STAT-PRCES-DT.
010302*    MOVE SPACES            TO MIR-ADJDATE.
           MOVE SPACES                TO MIR-CVG-INS-TYP-CD.
           MOVE SPACES                TO MIR-CVG-ACCT-TYP-CD.
           MOVE SPACES                TO MIR-CVG-CNVR-IND.
           MOVE SPACES                TO MIR-CVG-NET-REISS-AMT.
           MOVE SPACES                TO MIR-ULT-PREM-RT-CD.
014591***  MOVE SPACES                TO MIR-ORIG-PLAN-BASE-ID.
014591     MOVE SPACES                TO MIR-ORIG-PLAN-ID.
           MOVE SPACES                TO MIR-CVG-MDRT-AMT.
           MOVE SPACES                TO MIR-CVG-FYR-COMM-AMT.
           MOVE SPACES                TO MIR-CVG-FACE-AMT.
           MOVE SPACES                TO MIR-CVG-PREV-FACE-AMT.
           MOVE SPACES                TO MIR-CVG-PREV-UPREM-AMT.
           MOVE SPACES                TO MIR-CVG-NXT-UPREM-AMT.
010302*    MOVE SPACES            TO MIR-LWPRATE.
           MOVE SPACES                TO MIR-CVG-WP-YTD-AMT.
           MOVE SPACES                TO MIR-CVG-WP-LTD-AMT.
           MOVE SPACES                TO MIR-CVG-CLM-YTD-AMT.
           MOVE SPACES                TO MIR-CVG-CLM-LTD-AMT.
013578*    MOVE SPACES                TO MIR-AGNUM-T (1).
013578*    MOVE SPACES                TO MIR-AGNUM-T (2).
013578*    MOVE SPACES                TO MIR-AGNUM-T (3).
           MOVE SPACES                TO MIR-AGT-ID-T (1).
           MOVE SPACES                TO MIR-AGT-ID-T (2).
           MOVE SPACES                TO MIR-AGT-ID-T (3).
           MOVE SPACES                TO MIR-PARTL-ADV-TYP-CD-T (1).
           MOVE SPACES                TO MIR-PARTL-ADV-TYP-CD-T (2).
           MOVE SPACES                TO MIR-PARTL-ADV-TYP-CD-T (3).
           MOVE SPACES                TO MIR-PARTL-ADV-AMT-T (1).
           MOVE SPACES                TO MIR-PARTL-ADV-AMT-T (2).
           MOVE SPACES                TO MIR-PARTL-ADV-AMT-T (3).
           MOVE SPACES                TO MIR-CVG-ORIG-FACE-AMT.
           MOVE SPACES                TO MIR-CVG-SUM-INS-AMT.
           MOVE SPACES                TO MIR-CVG-XHBT-ISS-IND.
           MOVE SPACES                TO MIR-CVG-XHBT-ISS-DT.
           MOVE SPACES                TO MIR-CVG-XHBT-TRMN-QTY.
           MOVE SPACES                TO MIR-CVG-XHBT-TRMN-DT.
           MOVE SPACES                TO MIR-XHBT-REINST-QTY.
           MOVE SPACES                TO MIR-CVG-XHBT-REINST-DT.
           MOVE SPACES                TO MIR-CVG-APP-CMPLT-DT.
           MOVE SPACES                TO MIR-CVG-MTHV-STRT-DT.
           MOVE SPACES                TO MIR-CVG-SURR-TRG-AMT.
           MOVE SPACES                TO MIR-SURR-LOAD-LTD-AMT.
           MOVE SPACES                TO MIR-CVG-SURR-LTD-AMT.
           MOVE SPACES                TO MIR-PMT-LOAD-LTD-AMT.
           MOVE SPACES                TO MIR-CVG-PMT-LTD-AMT.
           MOVE SPACES                TO MIR-CVG-GDLN-APREM-AMT.
           MOVE SPACES                TO MIR-CVG-GDLN-SPREM-AMT.
031037*    MOVE SPACES                TO MIR-CVG-SE-GDLN-AMT.
           MOVE SPACES                TO MIR-CVG-CF-TYP-CD.
           MOVE SPACES                TO MIR-LATST-CF-DT.
           MOVE SPACES                TO MIR-PREV-ANNV-CVGD-DUR.
016306     MOVE ZEROES                TO MIR-ANN-MTG-INT-PCT.
018763*    MOVE SPACES                TO MIR-CVG-INT-CMPND-CD.
018763     MOVE SPACES                TO MIR-INT-CMPND-FREQ-CD.
016306     MOVE ZEROES                TO MIR-CVG-MTG-REPAY-AMT.
016306     MOVE SPACES                TO MIR-MTG-REPAY-FREQ-CD.
016306     MOVE ZEROES                TO MIR-PREV-SUM-INS-AMT.
018846     MOVE SPACES                TO MIR-PLAN-FND-TYP-CD.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.

      *
      ***********************
      *
      *--------------------------
       9400-SETUP-MSIN-REFERENCE.
      *--------------------------
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY      TO TRUE.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.
           MOVE MIR-CVG-NUM           TO WGLOB-REF-COVERAGE-NUMBER.
      *
       9400-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

035393     PERFORM  CITC-0000-INIT-PARM-INFO
035393         THRU CITC-0000-INIT-PARM-INFO-X.
035393
026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
035393     PERFORM  0319-0000-INIT-PARM-INFO
035393         THRU 0319-0000-INIT-PARM-INFO-X.
035393
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2450-0000-INIT-PARM-INFO
025970         THRU 2450-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WS-DISPLAY-FIELD-DEFINITIONS.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     MOVE SPACES             TO VALID-INPUT-SWITCH.
025970     MOVE SPACES             TO VALID-POLICY-SWITCH.
025970     MOVE SPACES             TO VALID-RIDER-SWITCH.
025970     MOVE SPACES             TO UPDATE-NEEDED-SWITCH.
025970     MOVE SPACES             TO UPDATE-AGENT-SWITCH.
025970     MOVE SPACES             TO UPDATE-CVG-AGENTS-SWITCH.
025970     MOVE SPACES             TO WS-INT-CMPND-FREQ-CD.
025970     MOVE SPACES             TO WS-MTG-REPAY-FREQ-CD.
025970     MOVE SPACES             TO WWKDT-WORK-FIELDS.
025970
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
025970     SET CV-DATE-DEFAULT     TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      ***********************
      *
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

021239 COPY CCPEUVTP.
021239
035393 COPY CCPSCITC.
035393 COPY CCPLCITC.
035393
025970 COPY XCPS8090.
016503 COPY CCPS0289.
018764*COPY CCCL0289.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL0289.
      *
       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      *
       COPY CCPS2450.
018764*COPY CCCL2450.
018764 COPY CCPL2450.
      *
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      *
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
018770 COPY XCPS8960.
018770 COPY XCPL8960.
018770
025970 COPY XCPS1640.
       COPY XCPL1640.
      *
018764*COPY CCCLPOL.
018764 COPY CCPLPOL.
018764*COPY CCCLCVG.
018764 COPY CCPLCVG.
      *
020074*COPY CCPESTCD.
      *
       COPY CCPUCVG.
016503 COPY CCPNCVG.
      *
021239 COPY CCPNEDIT.
021239
018770*COPY XCPNDMAD.
018770*
       COPY CCPNPOL.
       COPY CCPUPOL.
      *
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
016503 COPY NCPPCVGS.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
025970 COPY CCPS0620.
557668 COPY CCPL0620.
025970 COPY XCPS0280.
       COPY XCPL0280.
008455*
008455 COPY XCPS0290.
008455 COPY XCPL0290.
008455*
035393 COPY XCPS0319.
035393 COPY XCPL0319.
035393
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0152                     **
      *****************************************************************


