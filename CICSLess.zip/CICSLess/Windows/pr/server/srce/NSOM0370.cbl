      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM0370.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM0370                                         **
      **  REMARKS:  PROCESS DRIVER FOR DEFINED FIELD TRANS. (DFLD)   **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP/STANDARDIZATION                     **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
008453**  5.5.2     MULTIPLE EXTERNAL DATE FORMATS                   **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      /
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0370'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

016537*COPY XCWWWKDT.

       01  WS-EDIT-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-ID-VALID      VALUE
                   '0370' '0371' '0372' '0373' '0374'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '0370'.
               88  WS-BUS-FCN-CREATE        VALUE '0371'.
               88  WS-BUS-FCN-UPDATE        VALUE '0372'.
               88  WS-BUS-FCN-DELETE        VALUE '0373'.
               88  WS-BUS-FCN-LIST          VALUE '0374'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '0370'.

           05  WS-EDIT-FIELD-NAME           PIC X(10).
           05  WS-EDIT-FIELD-NAME-R REDEFINES WS-EDIT-FIELD-NAME.
               10  WS-EDIT-FIELD-CHAR       OCCURS 10 TIMES
                                            INDEXED BY WS-CHAR
                                            PIC X(01).

           05  WS-EDIT-FIELD-TYPE           PIC X(01).
               88  VALID-FIELD-TYPE         VALUE 'C' 'D' 'N' 'S' 'Y'.
               88  CHAR-TYPE                VALUE 'C'.
               88  DATE-TYPE                VALUE 'D'.
               88  NUMERIC-TYPE             VALUE 'N'.
               88  SIGNED-NUMERIC-TYPE      VALUE 'S'.
               88  YESNO-TYPE               VALUE 'Y'.

       01  WS-WORK-FIELDS.
           05  WS-FIELD-LENGTH              PIC S9(3) COMP-3.
           05  WS-FIELD-PLACES              PIC S9(3) COMP-3.
           05  WS-FIELD-SUM                 PIC S9(3) COMP-3.
           05  WS-FIELD-STORAGE             PIC S9(3) COMP-3.
           05  WS-ODD-EVEN-FIELD            PIC 9(03).
           05  WS-ODD-EVEN-FIELD-R  REDEFINES WS-ODD-EVEN-FIELD.
               10  FILLER                   PIC X(02).
               10  WS-ODD-EVEN              PIC X(01).
                   88  WS-ODD               VALUE '1' '3' '5' '7' '9'.
           05  WS-NUM-99                    PIC 9(02).
           05  WS-NUM-999                   PIC 9(03).
           05  WS-NUM-9999                  PIC 9(04).
      /
       01  WS-SWITCHES.
           05  WS-VALIDATE-FAIL-SW          PIC X(01).
               88  VALIDATE-FAILED          VALUE 'Y'.
025970*    05  WS-EDITS-OK-SW               PIC X(01)  VALUE 'Y'.
025970     05  WS-EDITS-OK-SW               PIC X(01).
025970         88  WS-DEFAULT-EDITS-OK      VALUE 'Y'.
               88  WS-EDIT-OK               VALUE 'Y'.
               88  WS-EDIT-FAILED           VALUE 'N'.
           05  WS-FIRST-SPACE-SW            PIC X(01).
               88  WS-FIRST-SPACE           VALUE 'Y'.

016548*    05  WS-LINE                      PIC S9(04) COMP.
016548     05  WS-LINE                      PIC S9(04) BINARY.
016548*    05  WS-MAX-LINES                 PIC S9(04) COMP VALUE +12.
025970*    05  WS-MAX-LINES                 PIC S9(04) BINARY VALUE +12.
025970/
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                VALUE '0370'.
025970     05  WS-MAX-LINES                 PIC S9(04) BINARY.
025970         88  WS-DEFAULT-MAX-LINES                VALUE +12.

       COPY XCWEBLCH.

       COPY NCFWDFLD.
       COPY NCFRDFLD.
      /
       COPY XCWL0280.
014221 COPY XCWL8090.
      /
014221 COPY CCWWLOCK.

007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY NCWL5880.
      /
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

      /
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0370.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      **********************
       2000-PROCESS-REQUEST.
      **********************

025970*    SET  MIR-RETRN-OK          TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.
      *
      *    PROCESS SCREEN FUNCTIONS
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  3500-PROCESS-LIST
                        THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  4000-PROCESS-CREATE
                        THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  6000-PROCESS-DELETE
                        THRU 6000-PROCESS-DELETE-X

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  7000-PROCESS-RETRIEVE
                        THRU 7000-PROCESS-RETRIEVE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID  TO WGLOB-MSG-PARM (1)
                    MOVE 'NSOM0370'      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      ****************************************************************
      * INQUIRY PROCESSING:  SETUP BROWSE KEYS, BEGIN BROWSE, AND    *
      * LOAD DATA ARRAY UNTIL END-OF-FILE OR SCREEN IS FULL.         *
      ****************************************************************
       3500-PROCESS-LIST.

           MOVE LOW-VALUES            TO WDFLD-KEY.
           MOVE HIGH-VALUES           TO WDFLD-ENDBR-KEY.
           PERFORM  8000-BUILD-DFLD-KEY
               THRU 8000-BUILD-DFLD-KEY-X.

           PERFORM DFLD-1000-BROWSE
              THRU DFLD-1000-BROWSE-X.

           IF WDFLD-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
557660     END-IF.

           PERFORM  DFLD-2000-READ-NEXT
               THRU DFLD-2000-READ-NEXT-X.

           IF WDFLD-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
           ELSE
557660         PERFORM  3550-DISPLAY-RECORD
557660             THRU 3550-DISPLAY-RECORD-X
                        VARYING WS-LINE FROM 1 BY 1
                        UNTIL WDFLD-IO-EOF
                        OR (WS-LINE > WS-MAX-LINES)
               IF WDFLD-IO-EOF
                   MOVE 'XS00000025'  TO WGLOB-MSG-REF-INFO
               ELSE
                   MOVE RDFLD-FLD-ID  TO MIR-FLD-ID
                   SET WGLOB-MORE-DATA-EXISTS  TO TRUE
                   MOVE 'XS00000014'  TO WGLOB-MSG-REF-INFO
557660         END-IF
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  DFLD-3000-END-BROWSE
               THRU DFLD-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
557660 3550-DISPLAY-RECORD.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  DFLD-2000-READ-NEXT
               THRU DFLD-2000-READ-NEXT-X.

557660 3550-DISPLAY-RECORD-X.
           EXIT.

      /
      ****************************************************************
      * CREATE PROCESSING:  CHECK IF RECORD DOES NOT EXIST, INIT    *
      * NEW RECORD AND ALLOW USER TO MODIFY.                        *
      ****************************************************************
       4000-PROCESS-CREATE.

           PERFORM  4100-VALIDATE-KEY-FIELDS
               THRU 4100-VALIDATE-KEY-FIELDS-X.

           IF VALIDATE-FAILED
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

           PERFORM  8000-BUILD-DFLD-KEY
               THRU 8000-BUILD-DFLD-KEY-X.

           PERFORM DFLD-1000-READ
              THRU DFLD-1000-READ-X.

           IF WDFLD-IO-OK
               MOVE WDFLD-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
                   VARYING WS-LINE FROM 1 BY 1
                   UNTIL   (WS-LINE > WS-MAX-LINES)
           ELSE
               PERFORM  DFLD-1000-CREATE
                   THRU DFLD-1000-CREATE-X
               PERFORM  DFLD-1000-WRITE
                   THRU DFLD-1000-WRITE-X

014221         PERFORM  DFLD-1000-READ-TWRK-TS
014221             THRU DFLD-1000-READ-TWRK-TS-X

               MOVE 'XS00000004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE +1                TO WS-LINE
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
557660     END-IF.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
       4100-VALIDATE-KEY-FIELDS.

           MOVE 'N'                   TO WS-VALIDATE-FAIL-SW.

           IF MIR-FLD-ID = SPACES
               MOVE 'Y'               TO WS-VALIDATE-FAIL-SW
           ELSE
               MOVE 'N'               TO WS-FIRST-SPACE-SW
               MOVE MIR-FLD-ID        TO WS-EDIT-FIELD-NAME
               PERFORM  4150-CHECK-IMBEDDED-SPACE
                   THRU 4150-CHECK-IMBEDDED-SPACE-X
                        VARYING WS-CHAR FROM 1 BY 1
                        UNTIL (WS-CHAR > 10)
                           OR VALIDATE-FAILED
557660     END-IF.

           IF VALIDATE-FAILED
               MOVE MIR-FLD-ID        TO WGLOB-MSG-PARM (1)
               MOVE 'NS03700014'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4100-VALIDATE-KEY-FIELDS-X.
           EXIT.


       4150-CHECK-IMBEDDED-SPACE.

           IF (WS-EDIT-FIELD-CHAR (WS-CHAR) = SPACES)
               IF WS-FIRST-SPACE
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   MOVE 'Y'           TO WS-FIRST-SPACE-SW
557660         END-IF
           ELSE
               IF WS-FIRST-SPACE
                   MOVE 'Y'           TO WS-VALIDATE-FAIL-SW
557660         END-IF
557660     END-IF.

       4150-CHECK-IMBEDDED-SPACE-X.
           EXIT.
      /
      *********************
       5000-PROCESS-UPDATE.
      *********************

           PERFORM  8000-BUILD-DFLD-KEY
               THRU 8000-BUILD-DFLD-KEY-X.

014221*    PERFORM DFLD-1000-READ-FOR-UPDATE
014221*       THRU DFLD-1000-READ-FOR-UPDATE-X.

014221     PERFORM DFLD-2000-UPDATE-TWRK-TS
014221        THRU DFLD-2000-UPDATE-TWRK-TS-X.

           IF WDFLD-IO-NOT-FOUND
               MOVE WDFLD-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'DFLD'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WDFLD-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  5300-EDIT-DATA-FIELDS
               THRU 5300-EDIT-DATA-FIELDS-X.

      *
      *    RECORD IS NOT REWRITTEN IF ANY FIELD IS INVALID.
      *
           IF WS-EDIT-FAILED
               PERFORM  DFLD-3000-UNLOCK
                   THRU DFLD-3000-UNLOCK-X
               MOVE 'XS00000032'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  DFLD-2000-REWRITE
               THRU DFLD-2000-REWRITE-X.

014221     PERFORM  DFLD-1000-READ-TWRK-TS
014221         THRU DFLD-1000-READ-TWRK-TS-X.

           MOVE 'XS00000007'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      ****************************************************************
      * FIELD TYPE EDIT:  CHECK VALIDITY OF FIELD TYPE, SINCE        *
      * NO UPDATES WILL BE PERFORMED IF THE FIELD TYPE IS INVALID.   *
      ****************************************************************
       5300-EDIT-DATA-FIELDS.

           MOVE 'Y'                   TO WS-EDITS-OK-SW.

           IF MIR-FLD-TYP-CD-T (1) = SPACES
               MOVE RDFLD-FLD-TYP-CD  TO MIR-FLD-TYP-CD-T (1)
           ELSE
               IF MIR-FLD-TYP-CD-T (1) = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-FLD-TYP-CD-T (1)
557660         END-IF
557660     END-IF.

           MOVE MIR-FLD-TYP-CD-T (1)  TO WS-EDIT-FIELD-TYPE.
           IF VALID-FIELD-TYPE
               MOVE MIR-FLD-TYP-CD-T (1)
                                      TO RDFLD-FLD-TYP-CD
               PERFORM  5310-NUMERIC-EDIT
                   THRU 5310-NUMERIC-EDIT-X
           ELSE
               MOVE MIR-FLD-TYP-CD-T (1)
                                      TO WGLOB-MSG-PARM (1)
               MOVE 'NS03700001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
557660     END-IF.

           PERFORM  5400-EDIT-FILE
               THRU 5400-EDIT-FILE-X.
           IF WS-EDIT-OK
               MOVE MIR-FLD-FILE-CD-T (1)
                                      TO RDFLD-FLD-FILE-CD
           ELSE
               GO TO 5300-EDIT-DATA-FIELDS-X
557660     END-IF.

           PERFORM  5500-OTHER-EDITS
               THRU 5500-OTHER-EDITS-X.

       5300-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      ****************************************************************
      * NUMERIC-EDIT:  EDIT NUMERIC FIELDS USING NSDS0280            *
      ****************************************************************
       5310-NUMERIC-EDIT.

           PERFORM  5320-NUM-EDIT-OFFSET
               THRU 5320-NUM-EDIT-OFFSET-X.
           PERFORM  5330-NUM-EDIT-LENGTH
               THRU 5330-NUM-EDIT-LENGTH-X.
           PERFORM  5340-NUM-EDIT-PLACES
               THRU 5340-NUM-EDIT-PLACES-X.
           IF WS-EDIT-OK
               PERFORM  5350-OTHER-CROSS-EDITS
                   THRU 5350-OTHER-CROSS-EDITS-X
557660     END-IF.

       5310-NUMERIC-EDIT-X.
           EXIT.
      /
       5320-NUM-EDIT-OFFSET.

           IF MIR-FLD-OFFST-LEN-T (1) = SPACES
               MOVE RDFLD-FLD-OFFST-LEN-N
                                      TO MIR-FLD-OFFST-LEN-T (1)
           ELSE
               IF MIR-FLD-OFFST-LEN-T (1) = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROES        TO MIR-FLD-OFFST-LEN-T (1)
557660         END-IF
557660     END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 4                     TO L0280-LENGTH.
           MOVE +4                    TO L0280-INPUT-SIZE.
           MOVE MIR-FLD-OFFST-LEN-T (1)
                                      TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO RDFLD-FLD-OFFST-LEN-N
               MOVE RDFLD-FLD-OFFST-LEN-N
                                      TO WS-NUM-9999
               MOVE WS-NUM-9999       TO MIR-FLD-OFFST-LEN-T (1)
           ELSE
               MOVE 'NS03700002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
557660     END-IF.

       5320-NUM-EDIT-OFFSET-X.
           EXIT.
      /
       5330-NUM-EDIT-LENGTH.
           IF MIR-FLD-LEN-T (1) = SPACES
               MOVE RDFLD-FLD-LEN-N   TO MIR-FLD-LEN-T (1)
           ELSE
               IF MIR-FLD-LEN-T (1) = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROES        TO MIR-FLD-LEN-T (1)
557660         END-IF
557660     END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE +3                    TO L0280-INPUT-SIZE.
           MOVE MIR-FLD-LEN-T (1)     TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-FIELD-LENGTH
               MOVE L0280-OUTPUT      TO WS-NUM-999
               MOVE WS-NUM-999        TO MIR-FLD-LEN-T (1)
           ELSE
               MOVE ZEROES            TO WS-FIELD-LENGTH
               IF YESNO-TYPE
557660         OR DATE-TYPE
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   MOVE 'NS03700003'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-EDITS-OK-SW
                   GO TO 5330-NUM-EDIT-LENGTH-X
557660         END-IF
557660     END-IF.

           PERFORM  5335-TYPE-LENGTH-CROSS-EDIT
               THRU 5335-TYPE-LENGTH-CROSS-EDIT-X.

       5330-NUM-EDIT-LENGTH-X.
           EXIT.
      /
       5335-TYPE-LENGTH-CROSS-EDIT.

           IF YESNO-TYPE
               IF WS-FIELD-LENGTH = 1
                   MOVE 1             TO RDFLD-FLD-LEN-N
                   GO TO 5335-TYPE-LENGTH-CROSS-EDIT-X
               ELSE
                   MOVE 1             TO RDFLD-FLD-LEN-N
                   MOVE '001'         TO MIR-FLD-LEN-T (1)
                   MOVE 'NS03700004'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 5335-TYPE-LENGTH-CROSS-EDIT-X
557660         END-IF
557660     END-IF.

           IF DATE-TYPE
008453*        IF WS-FIELD-LENGTH = 9
008453*            MOVE 9       TO RDFLD-FLD-LEN-N
008453         IF WS-FIELD-LENGTH = 10
008453             MOVE 10            TO RDFLD-FLD-LEN-N
                   GO TO 5335-TYPE-LENGTH-CROSS-EDIT-X
               ELSE
008453*            MOVE 9       TO RDFLD-FLD-LEN-N
008453*            MOVE '009'   TO MIR-FLD-LEN-T (1)
008453             MOVE 10            TO RDFLD-FLD-LEN-N
008453             MOVE '010'         TO MIR-FLD-LEN-T (1)
                   MOVE 'NS03700005'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 5335-TYPE-LENGTH-CROSS-EDIT-X
557660         END-IF
557660     END-IF.

           IF CHAR-TYPE
               IF WS-FIELD-LENGTH > ZEROES
                   MOVE WS-FIELD-LENGTH
                                      TO RDFLD-FLD-LEN-N
               ELSE
                   MOVE 'NS03700006'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-EDITS-OK-SW
557660         END-IF
557660     END-IF.

       5335-TYPE-LENGTH-CROSS-EDIT-X.
           EXIT.
      /
       5340-NUM-EDIT-PLACES.

           IF MIR-FLD-DCML-LEN-T (1) = SPACES
               MOVE RDFLD-FLD-DCML-LEN-N
                                      TO MIR-FLD-DCML-LEN-T (1)
           ELSE
               IF MIR-FLD-DCML-LEN-T (1) = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROES        TO MIR-FLD-DCML-LEN-T (1)
557660         END-IF
557660     END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE +2                    TO L0280-INPUT-SIZE.
           MOVE MIR-FLD-DCML-LEN-T (1)              TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-99
               MOVE L0280-OUTPUT      TO WS-FIELD-PLACES
               MOVE WS-NUM-99         TO MIR-FLD-DCML-LEN-T (1)
           ELSE
               MOVE 'N'               TO WS-EDITS-OK-SW
               MOVE 'NS03700010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5340-NUM-EDIT-PLACES-X.
           EXIT.
      /
       5350-OTHER-CROSS-EDITS.

           IF NUMERIC-TYPE
557660     OR SIGNED-NUMERIC-TYPE
               IF (WS-FIELD-LENGTH = ZEROES)  AND
                  (WS-FIELD-PLACES NOT > ZEROES)
                   MOVE 'NS03700008'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-EDITS-OK-SW
               ELSE
                   ADD WS-FIELD-LENGTH
                       WS-FIELD-PLACES GIVING WS-FIELD-SUM
016537             PERFORM  5351-CHECK-FIELD-LENGTH
016537                 THRU 5351-CHECK-FIELD-LENGTH-X
016537*            IF WS-FIELD-SUM > 18
016537*                MOVE 'NS03700009'
016537*                               TO WGLOB-MSG-REF-INFO
016537*                PERFORM  0260-1000-GENERATE-MESSAGE
016537*                    THRU 0260-1000-GENERATE-MESSAGE-X
016537*                MOVE 'N'       TO WS-EDITS-OK-SW
016537*            ELSE
016537*                MOVE WS-FIELD-PLACES
016537*                               TO RDFLD-FLD-DCML-LEN-N
016537*                MOVE WS-FIELD-SUM
016537*                               TO WS-ODD-EVEN-FIELD
016537*                IF WS-ODD
016537*                OR (WS-FIELD-SUM = 18)
016537*                    MOVE WS-FIELD-LENGTH
016537*                               TO RDFLD-FLD-LEN-N
016537*                ELSE
016537*                    ADD +1    TO WS-FIELD-LENGTH
016537*                    MOVE WS-FIELD-LENGTH
016537*                               TO RDFLD-FLD-LEN-N
016537*                END-IF
016537*            END-IF
557660         END-IF
           ELSE
               IF WS-FIELD-PLACES = ZEROES
                   MOVE WS-FIELD-PLACES
                                      TO RDFLD-FLD-DCML-LEN-N
               ELSE
                   MOVE ZEROES        TO RDFLD-FLD-DCML-LEN-N
                   MOVE ZEROES        TO WS-NUM-99
                   MOVE WS-NUM-99     TO MIR-FLD-DCML-LEN-T (1)
                   MOVE 'NS03700011'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

       5350-OTHER-CROSS-EDITS-X.
           EXIT.

016537*----------------------------
016537 5351-CHECK-FIELD-LENGTH.
016537*----------------------------
016537
016537     IF WS-FIELD-SUM > 18
016537         MOVE 'NS03700009'
016537                        TO WGLOB-MSG-REF-INFO
016537         PERFORM  0260-1000-GENERATE-MESSAGE
016537             THRU 0260-1000-GENERATE-MESSAGE-X
016537         MOVE 'N'       TO WS-EDITS-OK-SW
016537     ELSE
016537         MOVE WS-FIELD-PLACES
016537                        TO RDFLD-FLD-DCML-LEN-N
016537         MOVE WS-FIELD-SUM
016537                        TO WS-ODD-EVEN-FIELD
016537         IF WS-ODD
016537         OR (WS-FIELD-SUM = 18)
016537             MOVE WS-FIELD-LENGTH
016537                        TO RDFLD-FLD-LEN-N
016537         ELSE
016537             ADD +1    TO WS-FIELD-LENGTH
016537             MOVE WS-FIELD-LENGTH
016537                        TO RDFLD-FLD-LEN-N
016537         END-IF
016537     END-IF.
016537
016537 5351-CHECK-FIELD-LENGTH-X.
016537     EXIT.
      /
      ****************************************************************
      * EDIT FILE:  EDIT FILE CODE USING NSLC5880                    *
      ****************************************************************
       5400-EDIT-FILE.

           IF MIR-FLD-FILE-CD-T (1) = SPACES
               MOVE RDFLD-FLD-FILE-CD TO MIR-FLD-FILE-CD-T (1)
           ELSE
               IF MIR-FLD-FILE-CD-T (1) = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-FLD-FILE-CD-T (1)
557660         END-IF
557660     END-IF.

           MOVE 'Y'                   TO L5880-MESSAGE-IND.
           MOVE +1                    TO L5880-COUNT.
           MOVE MIR-FLD-FILE-CD-T (1) TO L5880-DEFN-FLD-FILE (1).
           MOVE MIR-FLD-ID-T (1)      TO L5880-DEFN-FLD-NAME (1).

           PERFORM  5880-6000-VALIDATE-FILE
               THRU 5880-6000-VALIDATE-FILE-X.

           IF L5880-RETRN-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *
      ***      NOTE:  ERROR MESSAGES ARE GENERATED BY NSLC5880.
      *
               MOVE 'N'               TO WS-EDITS-OK-SW
557660     END-IF.

       5400-EDIT-FILE-X.
           EXIT.
      /
      ****************************************************************
      * FIELD EDITS:  CHECK VALIDITY OF ALL DATA FIELDS              *
      *               (EXCEPT FIELD TYPE)                            *
      ****************************************************************

       5500-OTHER-EDITS.

           PERFORM  5600-EDIT-POSITION
               THRU 5600-EDIT-POSITION-X.

           IF MIR-FLD-DESC-TXT-T (1) = SPACES
               MOVE RDFLD-FLD-DESC-TXT         TO MIR-FLD-DESC-TXT-T (1)
               GO TO 5500-OTHER-EDITS-X
557660     END-IF.

           IF MIR-FLD-DESC-TXT-T (1) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-FLD-DESC-TXT-T (1)
557660     END-IF.

           MOVE MIR-FLD-DESC-TXT-T (1)            TO RDFLD-FLD-DESC-TXT.

       5500-OTHER-EDITS-X.
           EXIT.
      /
       5600-EDIT-POSITION.

           PERFORM  5610-DERIVE-STORAGE
               THRU 5610-DERIVE-STORAGE-X.

           IF MIR-FLD-FILE-CD-T (1) = SPACES
               MOVE RDFLD-FLD-FILE-CD TO MIR-FLD-FILE-CD-T (1)
           ELSE
               IF MIR-FLD-FILE-CD-T (1) = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-FLD-FILE-CD-T (1)
557660         END-IF
557660     END-IF.

           MOVE 'Y'                   TO L5880-MESSAGE-IND.
           MOVE +1                    TO L5880-COUNT.
           MOVE RDFLD-FLD-ID          TO L5880-DEFN-FLD-NAME (1).
           MOVE RDFLD-FLD-FILE-CD     TO L5880-DEFN-FLD-FILE (1).
           MOVE RDFLD-FLD-OFFST-LEN-N TO L5880-DEFN-FLD-OFFSET (1).
           MOVE RDFLD-FLD-STRG-LEN-N
                                      TO L5880-DEFN-FLD-STORAGE (1).

           PERFORM  5880-7000-VALIDATE-POSITION
               THRU 5880-7000-VALIDATE-POSITION-X.

      *
      ***      NOTE:  ERROR MESSAGES ARE GENERATED BY NSLC5880.
      *
           IF L5880-OFFSET-IN-KEY (1)
               MOVE 'N'               TO WS-EDITS-OK-SW
           ELSE
               IF L5880-RECLEN-EXCEEDED (1)
                   MOVE 'N'           TO WS-EDITS-OK-SW
557660         END-IF
557660     END-IF.

       5600-EDIT-POSITION-X.
           EXIT.
      /
       5610-DERIVE-STORAGE.

           IF YESNO-TYPE
               MOVE 1                 TO RDFLD-FLD-STRG-LEN-N
           ELSE
               IF DATE-TYPE
                   MOVE 10            TO RDFLD-FLD-STRG-LEN-N
               ELSE
                   IF CHAR-TYPE
                       MOVE RDFLD-FLD-LEN-N
                                      TO RDFLD-FLD-STRG-LEN-N
                   ELSE
                       COMPUTE WS-FIELD-STORAGE =
                       ((WS-FIELD-LENGTH + WS-FIELD-PLACES) / 2) + 1
                       MOVE WS-FIELD-STORAGE
                                      TO RDFLD-FLD-STRG-LEN-N
557660             END-IF
557660         END-IF
557660     END-IF.

       5610-DERIVE-STORAGE-X.
           EXIT.
      /
      *********************
       6000-PROCESS-DELETE.
      *********************

           PERFORM  8000-BUILD-DFLD-KEY
               THRU 8000-BUILD-DFLD-KEY-X.

014221*    PERFORM DFLD-1000-READ-FOR-UPDATE
014221*       THRU DFLD-1000-READ-FOR-UPDATE-X.

014221     PERFORM DFLD-2000-UPDATE-TWRK-TS
014221        THRU DFLD-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'DFLD'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WDFLD-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF WDFLD-IO-OK
               PERFORM  DFLD-1000-DELETE
                   THRU DFLD-1000-DELETE-X
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE WDFLD-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      ***********************
       7000-PROCESS-RETRIEVE.
      ***********************

           PERFORM  8000-BUILD-DFLD-KEY
               THRU 8000-BUILD-DFLD-KEY-X.

014221*    PERFORM DFLD-1000-READ
014221*       THRU DFLD-1000-READ-X.

014221     PERFORM DFLD-1000-READ-TWRK-TS
014221        THRU DFLD-1000-READ-TWRK-TS-X.

           IF WDFLD-IO-NOT-FOUND
               MOVE WDFLD-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
                   VARYING WS-LINE FROM 1 BY 1
                   UNTIL   (WS-LINE > WS-MAX-LINES)
           ELSE
               MOVE +1                TO WS-LINE
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

       7000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *********************
       8000-BUILD-DFLD-KEY.
      *********************

           MOVE MIR-FLD-ID            TO WDFLD-FLD-ID.

       8000-BUILD-DFLD-KEY-X.
           EXIT.


      /
       9100-BLANK-DATA-FIELDS.

           MOVE SPACES                TO  MIR-FLD-ID-T (WS-LINE).
           MOVE SPACES                TO  MIR-FLD-FILE-CD-T (WS-LINE).
           MOVE SPACES                TO  MIR-FLD-OFFST-LEN-T (WS-LINE).
           MOVE SPACES                TO  MIR-FLD-TYP-CD-T (WS-LINE).
           MOVE SPACES                TO  MIR-FLD-LEN-T (WS-LINE).
           MOVE SPACES                TO  MIR-FLD-DCML-LEN-T (WS-LINE).
           MOVE SPACES                TO  MIR-FLD-DESC-TXT-T (WS-LINE).

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
       9200-MOVE-RECORD-TO-SCREEN.

           MOVE RDFLD-FLD-ID          TO MIR-FLD-ID-T (WS-LINE).
           MOVE RDFLD-FLD-FILE-CD     TO MIR-FLD-FILE-CD-T (WS-LINE).
           MOVE RDFLD-FLD-TYP-CD      TO MIR-FLD-TYP-CD-T (WS-LINE).
           MOVE RDFLD-FLD-OFFST-LEN-N TO WS-NUM-9999.
           MOVE WS-NUM-9999           TO MIR-FLD-OFFST-LEN-T (WS-LINE).
           MOVE RDFLD-FLD-LEN-N       TO WS-NUM-999.
           MOVE WS-NUM-999            TO MIR-FLD-LEN-T (WS-LINE).
           MOVE RDFLD-FLD-DCML-LEN-N  TO WS-NUM-99.
           MOVE WS-NUM-99             TO MIR-FLD-DCML-LEN-T (WS-LINE).
           MOVE RDFLD-FLD-DESC-TXT    TO MIR-FLD-DESC-TXT-T (WS-LINE).


       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
       9300-SETUP-MSIN-REFERENCE.

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5880-0000-INIT-PARM-INFO
025970         THRU 5880-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-EDIT-WORK-AREA.
025970     INITIALIZE                         WS-WORK-FIELDS.
025970     INITIALIZE                         WS-SWITCHES.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-EDITS-OK            TO TRUE.
025970     SET WS-DEFAULT-MAX-LINES           TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
018764*COPY NCCL5880.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
025970 COPY XCPS8090.
025970 COPY NCPS5880.
018764 COPY NCPL5880.
025970 COPY XCPS0280.
       COPY XCPL0280.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY DFLD
014221                         '$VAR2' BY 'DFLD'.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      ****************************************************************
      * GENERAL & MESSAGE PROCESSING COPYBOOKS                       *
      ****************************************************************
       COPY XCPPINIT.
       COPY XCPPEXIT.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
      /
       COPY NCPADFLD.
       COPY NCPBDFLD.
       COPY NCPNDFLD.
       COPY NCPUDFLD.
       COPY NCPXDFLD.
       COPY NCPCDFLD.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM0370                     **
      *****************************************************************
