      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7814.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7814                                         **
      **  REMARKS:  THIS MODULE PERFORMS                             **
      **            FINANCIAL ACTIVITY - TOTAL PERIODIC DEDUCTIONS   **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
018839**  6.3       FINANCIAL BALANCES FLOW                          **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
021657**  6.6       CORRECT FIELD NAMES IN MIR COPYBOOKS             **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
025999**  6.6       MESSAGE CORRECTION                               **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
030054**  7.0       PHST SEQUENCE NUMBER EXPANSION                   **
033899**  7.0       M&E TRANSFER MISSING FROM POLICY ACTIVITY LIST   **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7814'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-MAX-LINE                      PIC 999 VALUE 50.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-RETRIEVE          VALUE '7814'.
           05  WS-CVG                           PIC 99.
           05  WS-SEQ                           PIC X(20).
           05  FILLER                REDEFINES  WS-SEQ.
               10  WS-SEQ-NUM                   PIC 999.
               10  FILLER                       PIC X(17).
           05  WS-FA-SEQ-NUM                    PIC 999.
           05  WS-SUB                           PIC 999.
           05  WS-WEALTH-ACCUM-IND              PIC X.
               88  WS-WEALTH-ACCUM-YES          VALUE 'Y'.
               88  WS-WEALTH-ACCUM-NO           VALUE 'N'.
           05  WS-SAVE-EFF-IDT-NUM              PIC X(007).
           05  WS-SAVE-EFF-DT                   PIC X(010).
030054*    05  WS-SAVE-SEQ-NUM                  PIC 9(003).
030054     05  WS-SAVE-SEQ-NUM                  PIC 9(005).
           05  WS-SAVE-UH-EFF-DT                PIC X(010).
           05  WS-SAVE-UH-EFF-DT-R REDEFINES WS-SAVE-UH-EFF-DT.
               10  WS-SAVE-UH-EFF-DT-YR         PIC 9(004).
               10  FILLER                       PIC X(001).
               10  WS-SAVE-UH-EFF-DT-MT         PIC 9(002).
               10  FILLER                       PIC X(001).
               10  WS-SAVE-UH-EFF-DT-DY         PIC 9(002).
030054*    05  WS-SAVE-PCHST-EFF-DT             PIC X(010).
030054*    05  WS-SAVE-PCHST-SEQ-NUM            PIC 9(003).
           05  WS-SAVE-TRXN-AMT                 PIC S9(13)V9(2).
           05  WS-TRXN-TYP-ID                   PIC X(003).
               88  WS-TRXN-TYP-ADM              VALUE 'ADM'.
               88  WS-TRXN-TYP-CDM              VALUE 'CDM'.
               88  WS-TRXN-TYP-AMF              VALUE 'AMF'.
               88  WS-TRXN-TYP-AFO              VALUE 'AFO'.
               88  WS-TRXN-TYP-TAF              VALUE 'TAF'.
               88  WS-TRXN-TYP-MTH              VALUE 'MTH'.
               88  WS-TRXN-TYP-PUP              VALUE 'PUP'.
           05  WS-TRXN-STAT-CD                  PIC X(001).
               88  WS-TRXN-STAT-ACTIVE          VALUE 'A'.
               88  WS-TRXN-STAT-REVERSED        VALUE 'R'.
           05  WS-ADM-PHST-REC-IND              PIC X(001).
               88  WS-ADM-PHST-FOUND-NO         VALUE 'N'.
               88  WS-ADM-PHST-FOUND-YES        VALUE 'Y'.
           05  WS-UH-REC-IND                    PIC X(001).
               88  WS-UH-REC-FOUND-NO           VALUE 'N'.
               88  WS-UH-REC-FOUND-YES          VALUE 'Y'.
               88  WS-UH-REC-NO-MORE            VALUE 'E'.
           05  WS-PROCESS-END-IND               PIC X(001).
               88  WS-PROCESS-END-NO            VALUE 'N'.
               88  WS-PROCESS-END-YES           VALUE 'Y'.
           05  WS-ACTIVITY-TYPE-ID              PIC X(4).
               88  WS-ACTIVITY-TYPE-ADMIN-FEES  VALUE '4007' '4008'
                                                '5002' '5003' '5004'
                                                '4014' '5100'.
               88  WS-ACTIVITY-TYPE-REVRS VALUE '4001' '4002' '4003'
                                                '4006' '4007' '4008'
                                                '4011' '4012' '4013'
                                                '4014' '4015' '4017'
                                                '4018' '5002' '5003'
                                                '5004' '5005' '5006'
033899*                                         '5007' '5010' '5100'
033899                                          '5007' '5011' '5100'
                                                '5022'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
021930*COPY XCWWWKDT.
026057 COPY CCWWIHSD.
       COPY CCWWINDX.
       COPY CCWWLOCK.
026057 COPY XCWWWKDT.
030054 COPY XCWWCNST.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
       COPY CCWWCVGS.
       COPY CCFWPOL.
       COPY CCFRPOL.
       COPY SCFWFA.
       COPY SCFRFA.
       COPY CCFWCFLW.
       COPY CCFRCFLW.
       COPY CCFWPHST.
       COPY CCFRPHST.
030054 COPY CCFHPHST.
       COPY CCFWUH.
       COPY CCFRUH.
       COPY CCFWUHCO.
       COPY CCFRUHCO.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7814.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    INITIALIZE                   WS-WORK-AREA.
025970*    MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.
025970*    SET  MIR-RETRN-OK         TO TRUE.
025970*    MOVE SPACES               TO MIR-OUTPUT-AREA.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7814'     TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'   TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *--------------
       2000-RETRIEVE.
      *--------------

           MOVE MIR-POL-ID             TO WPOL-POL-ID.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: (@2) RECORD (@1) NOT FOUND
               MOVE WPOL-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'POL'            TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000344'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           SET WS-WEALTH-ACCUM-NO TO TRUE.

           PERFORM  2010-INS-TYPE-CHECK
               THRU 2010-INS-TYPE-CHECK-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > RPOL-POL-CVG-REC-CTR-N
                  OR WS-WEALTH-ACCUM-YES.

           IF WS-WEALTH-ACCUM-NO
      * MSG: FINANCIAL ACTIVITY IS NOT AVAILABLE FOR THIS TYPE OF POLICY
               MOVE 'CS78140002'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-RETRIEVE-X
           END-IF.

021657*    MOVE MIR-DV-START-DT           TO L1640-EXTERNAL-DATE.
021657     MOVE MIR-DV-STRT-DT            TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
026057     IF  L1640-NOT-VALID
026057*MSG:    'DATE @1 INVALID'
026057         MOVE 'CS78140003'      TO WGLOB-MSG-REF-INFO
026057         MOVE MIR-DV-STRT-DT    TO WGLOB-MSG-PARM (1)
026057         PERFORM  0260-1000-GENERATE-MESSAGE
026057             THRU 0260-1000-GENERATE-MESSAGE-X
026057         SET MIR-RETRN-RQST-FAILED  TO TRUE
026057         GO TO 2000-RETRIEVE-X
026057     END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE L1640-INTERNAL-DATE   TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF  WIHSD-CHK-EFF-DT-NOT-OK
026057         SET MIR-RETRN-RQST-FAILED  TO TRUE
026057         GO TO 2000-RETRIEVE-X
026057     END-IF.

           MOVE L1640-INTERNAL-DATE       TO L1660-INTERNAL-DATE.
           MOVE L1640-INTERNAL-DATE       TO WS-SAVE-EFF-DT.

           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE       TO WS-SAVE-EFF-IDT-NUM.

021657*    MOVE MIR-DV-START-SEQ-NUM      TO L0280-INPUT-DATA.
021657     MOVE MIR-DV-STRT-SEQ-NUM       TO L0280-INPUT-DATA.
021657*    MOVE LENGTH OF MIR-DV-START-SEQ-NUM TO L0280-INPUT-SIZE.
021657     MOVE LENGTH OF MIR-DV-STRT-SEQ-NUM  TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE          TO L0280-LENGTH.
           MOVE ZERO                      TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           MOVE L0280-OUTPUT              TO WS-SAVE-SEQ-NUM.


           PERFORM  3000-POL-ACTIVITY-LIST
               THRU 3000-POL-ACTIVITY-LIST-X.

       2000-RETRIEVE-X.
           EXIT.


      *--------------------
       2010-INS-TYPE-CHECK.
      *--------------------

           IF WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-SUB)
           OR WCVGS-CVG-INS-TYP-SEG-FUND    (WS-SUB)
           OR WCVGS-CVG-INS-TYP-FPA         (WS-SUB)
               SET WS-WEALTH-ACCUM-YES TO TRUE
           END-IF.

       2010-INS-TYPE-CHECK-X.
           EXIT.

      /
      *-----------------------
       3000-POL-ACTIVITY-LIST.
      *-----------------------
      *
      * GET FIRST UH
      *
           MOVE WS-SAVE-EFF-DT          TO WS-SAVE-UH-EFF-DT.
           MOVE RPOL-POL-ISS-EFF-DT-DY  TO WS-SAVE-UH-EFF-DT-DY.

           IF  WS-SAVE-UH-EFF-DT > WS-SAVE-EFF-DT
               PERFORM  3110-SET-NEXT-UH-DATE
                   THRU 3110-SET-NEXT-UH-DATE-X
           END-IF.

           SET  WS-UH-REC-FOUND-NO      TO TRUE.
           PERFORM  3100-GET-NEXT-UH-REC
               THRU 3100-GET-NEXT-UH-REC-X
               UNTIL WS-UH-REC-FOUND-YES
               OR   WS-UH-REC-NO-MORE.

      *
      * GET FIRST ADM PHST
      *
           MOVE RPOL-POL-ID         TO WPHST-POL-ID.
           MOVE WPHST-KEY           TO WPHST-ENDBR-KEY.
           MOVE WS-SAVE-EFF-IDT-NUM TO WPHST-PCHST-EFF-IDT-NUM.
           MOVE WS-SAVE-SEQ-NUM     TO WPHST-PCHST-SEQ-NUM.
           MOVE HIGH-VALUES         TO WPHST-ENDBR-PCHST-EFF-IDT-NUM.
030054*    MOVE +999                TO WPHST-ENDBR-PCHST-SEQ-NUM.
030054     MOVE WCNST-MAX-PCHST-SEQ-NUM-N
030054                              TO WPHST-ENDBR-PCHST-SEQ-NUM.

           PERFORM  PHST-1000-BROWSE
               THRU PHST-1000-BROWSE-X.

           SET WS-ADM-PHST-FOUND-NO TO TRUE.
           PERFORM  3200-READ-ADM-PHST
               THRU 3200-READ-ADM-PHST-X
               UNTIL WS-ADM-PHST-FOUND-YES
                  OR WPHST-IO-EOF.


           IF  WS-ADM-PHST-FOUND-NO
           AND WS-UH-REC-NO-MORE
      *MSG: NO PERIODIC DEDUCTION ACTIVITY TO DISPLAY
               MOVE 'CS78140001'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  PHST-3000-END-BROWSE
                   THRU PHST-3000-END-BROWSE-X
               GO TO 3000-POL-ACTIVITY-LIST-X
           END-IF.


           MOVE 1                  TO WS-SUB.
           SET WS-PROCESS-END-NO   TO TRUE.
           PERFORM  3300-ADM-DED-LOOP
               THRU 3300-ADM-DED-LOOP-X
               UNTIL  WS-SUB > WS-MAX-LINE
               OR     WS-PROCESS-END-YES.


           IF WS-PROCESS-END-YES
      * MSG: ** END OF LIST **
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
           ELSE
      * MSG: INQUIRE COMPLETE - CONTINUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE

               PERFORM  3010-SET-MORE-KEY
                   THRU 3010-SET-MORE-KEY-X
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  PHST-3000-END-BROWSE
               THRU PHST-3000-END-BROWSE-X.

       3000-POL-ACTIVITY-LIST-X.
           EXIT.


      *-----------------
       3010-SET-MORE-KEY.
      *-----------------


030054*    IF  WS-SAVE-UH-EFF-DT NOT < WS-SAVE-PCHST-EFF-DT
030054     IF  WS-SAVE-UH-EFF-DT NOT < HPHST-PCHST-EFF-DT
               MOVE WS-SAVE-UH-EFF-DT     TO WS-SAVE-EFF-DT
               MOVE ZERO                  TO WS-SAVE-SEQ-NUM
           ELSE
030054*        MOVE WS-SAVE-PCHST-EFF-DT  TO WS-SAVE-EFF-DT
030054*        MOVE WS-SAVE-PCHST-SEQ-NUM TO WS-SAVE-SEQ-NUM
030054         MOVE HPHST-PCHST-EFF-DT    TO WS-SAVE-EFF-DT
030054         MOVE HPHST-PCHST-SEQ-NUM   TO WS-SAVE-SEQ-NUM
           END-IF.

           MOVE WS-SAVE-EFF-DT            TO  L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
021657*    MOVE L1640-EXTERNAL-DATE       TO  MIR-DV-START-DT.
021657     MOVE L1640-EXTERNAL-DATE       TO  MIR-DV-STRT-DT.

020874*    MOVE WS-SAVE-SEQ-NUM           TO L0290-INPUT-NUMBER.
020874     MOVE WS-SAVE-SEQ-NUM           TO L0290-INPUT-V00.
           MOVE 0                         TO L0290-PRECISION
021657*    MOVE LENGTH OF MIR-DV-START-SEQ-NUM
021657     MOVE LENGTH OF MIR-DV-STRT-SEQ-NUM
                                          TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS  TO TRUE.
           SET L0290-SIGN-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
021657*    MOVE L0290-OUTPUT-DATA         TO  MIR-DV-START-SEQ-NUM.
021657     MOVE L0290-OUTPUT-DATA         TO  MIR-DV-STRT-SEQ-NUM.

       3010-SET-MORE-KEY-X.
           EXIT.


      *---------------------
       3100-GET-NEXT-UH-REC.
      *---------------------

           IF  WS-SAVE-UH-EFF-DT < RPOL-POL-ISS-EFF-DT
               SET WS-UH-REC-NO-MORE    TO TRUE
               MOVE SPACES              TO WS-SAVE-UH-EFF-DT
               GO TO 3100-GET-NEXT-UH-REC-X
           END-IF.

           MOVE RPOL-POL-ID             TO WUH-POL-ID.
           MOVE WS-SAVE-UH-EFF-DT       TO WUH-MTHV-EFF-DT-NUM.
           MOVE ZERO                    TO WUH-MTHV-EFF-DT-NUM-DY.

           PERFORM  UH-1000-READ
               THRU UH-1000-READ-X.

           IF NOT WUH-IO-OK
              PERFORM  3110-SET-NEXT-UH-DATE
                  THRU 3110-SET-NEXT-UH-DATE-X
              GO TO 3100-GET-NEXT-UH-REC-X
           END-IF.

           IF  RUH-POL-TOT-DED-AMT < ZERO
               PERFORM  3110-SET-NEXT-UH-DATE
                   THRU 3110-SET-NEXT-UH-DATE-X
               GO TO 3100-GET-NEXT-UH-REC-X
           END-IF.

           SET WS-UH-REC-FOUND-YES      TO TRUE.

       3100-GET-NEXT-UH-REC-X.
           EXIT.


      *---------------------
       3110-SET-NEXT-UH-DATE.
      *---------------------

           SUBTRACT 1            FROM WS-SAVE-UH-EFF-DT-MT.

           IF  WS-SAVE-UH-EFF-DT-MT = 0
               MOVE 12             TO WS-SAVE-UH-EFF-DT-MT
               SUBTRACT 1        FROM WS-SAVE-UH-EFF-DT-YR
           END-IF.

       3110-SET-NEXT-UH-DATE-X.
           EXIT.


      *-------------------
       3200-READ-ADM-PHST.
      *-------------------

           PERFORM  PHST-2000-READ-NEXT
               THRU PHST-2000-READ-NEXT-X.

           IF WPHST-IO-EOF
030054*       MOVE SPACES              TO WS-SAVE-PCHST-EFF-DT
030054        MOVE SPACES              TO HPHST-PCHST-EFF-DT
              GO TO 3200-READ-ADM-PHST-X
           END-IF.

           IF RPHST-PCHST-STAT-ACTIVE
           OR RPHST-PCHST-STAT-REVERSED
               CONTINUE
           ELSE
               GO TO 3200-READ-ADM-PHST-X
           END-IF.

           MOVE RPHST-POL-ACTV-TYP-ID TO WS-ACTIVITY-TYPE-ID.
           IF NOT WS-ACTIVITY-TYPE-ADMIN-FEES
               GO TO 3200-READ-ADM-PHST-X
           END-IF.

           SET WS-ADM-PHST-FOUND-YES    TO TRUE.
030054*    MOVE RPHST-PCHST-EFF-DT      TO WS-SAVE-PCHST-EFF-DT.
030054*    MOVE RPHST-PCHST-SEQ-NUM     TO WS-SAVE-PCHST-SEQ-NUM.
030054     MOVE RPHST-PCHST-EFF-DT      TO HPHST-PCHST-EFF-DT.
030054     MOVE RPHST-PCHST-SEQ-NUM     TO HPHST-PCHST-SEQ-NUM.

       3200-READ-ADM-PHST-X.
           EXIT.


      *-----------------
       3300-ADM-DED-LOOP.
      *-----------------

           EVALUATE TRUE

030054*        WHEN WS-SAVE-UH-EFF-DT NOT < WS-SAVE-PCHST-EFF-DT
030054         WHEN WS-SAVE-UH-EFF-DT NOT < HPHST-PCHST-EFF-DT
                    PERFORM  3800-PROCESS-UH
                        THRU 3800-PROCESS-UH-X

030054*        WHEN WS-SAVE-PCHST-EFF-DT > SPACE
030054         WHEN HPHST-PCHST-EFF-DT > SPACE
                    PERFORM  3400-PROCESS-PHST
                        THRU 3400-PROCESS-PHST-X

           END-EVALUATE.

           IF  WS-SAVE-UH-EFF-DT = SPACES
030054*    AND WS-SAVE-PCHST-EFF-DT = SPACES
030054     AND HPHST-PCHST-EFF-DT = SPACES
               SET WS-PROCESS-END-YES   TO TRUE
           END-IF.

       3300-ADM-DED-LOOP-X.
           EXIT.


      *------------------
       3400-PROCESS-PHST.
      *------------------

           MOVE RPHST-CVG-NUM             TO WS-CVG.

           EVALUATE TRUE

               WHEN WCVGS-CVG-INS-TYP-SEG-FUND (WS-CVG)
                    PERFORM  3500-ADM-FA
                        THRU 3500-ADM-FA-X

               WHEN WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-CVG)
               WHEN WCVGS-CVG-INS-TYP-FPA         (WS-CVG)
                    PERFORM  3600-ADM-CFLW
                        THRU 3600-ADM-CFLW-X

           END-EVALUATE.

           SET WS-ADM-PHST-FOUND-NO TO TRUE.
           PERFORM  3200-READ-ADM-PHST
               THRU 3200-READ-ADM-PHST-X
               UNTIL WS-ADM-PHST-FOUND-YES
                  OR WPHST-IO-EOF.

       3400-PROCESS-PHST-X.
           EXIT.

      *
      *------------
       3500-ADM-FA.
      *------------

           MOVE RPHST-POL-ID             TO WFA-POL-ID.
           MOVE RPHST-CVG-NUM            TO WFA-CVG-NUM.
           MOVE RPHST-PCHST-EFF-IDT-NUM  TO WFA-CIA-IDT-NUM.

           IF  RPHST-PCHST-STAT-REVERSED
           AND WS-ACTIVITY-TYPE-REVRS
               MOVE RPHST-PCHST-OLD-VALU-TXT
                                         TO WS-SEQ
           ELSE
               MOVE RPHST-PCHST-NEW-VALU-TXT
                                         TO WS-SEQ
           END-IF.

           COMPUTE WS-FA-SEQ-NUM = 1000 - WS-SEQ-NUM.
           MOVE WS-FA-SEQ-NUM            TO WFA-CIA-SEQ-NUM.

           PERFORM  FA-1000-READ
               THRU FA-1000-READ-X.

           IF NOT WFA-IO-OK
               GO TO 3500-ADM-FA-X
           END-IF.

           IF  RFA-CIA-TYP-ADMIN
           AND NOT RFA-CIA-REASN-MORT-CHRG
               CONTINUE
           ELSE
               GO TO 3500-ADM-FA-X
           END-IF.

           MOVE RFA-CIA-CLI-TRXN-AMT        TO WS-SAVE-TRXN-AMT.
           PERFORM  3700-MOVE-PHST-TO-MIR
               THRU 3700-MOVE-PHST-TO-MIR-X.


       3500-ADM-FA-X.
           EXIT.
      *
      *--------------
       3600-ADM-CFLW.
      *--------------

           MOVE RPHST-POL-ID                 TO WCFLW-POL-ID.
           MOVE RPHST-CVG-NUM                TO WCFLW-CVG-NUM.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG) TO WCFLW-CF-TYP-CD.
           MOVE RPHST-PCHST-EFF-DT           TO WCFLW-CF-EFF-DT.

           IF  RPHST-PCHST-STAT-REVERSED
           AND WS-ACTIVITY-TYPE-REVRS
               MOVE RPHST-PCHST-OLD-VALU-TXT TO WS-SEQ
           ELSE
               MOVE RPHST-PCHST-NEW-VALU-TXT TO WS-SEQ
           END-IF.

           MOVE WS-SEQ-NUM                   TO WCFLW-CF-SEQ-NUM-N.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

           IF NOT WCFLW-IO-OK
               GO TO 3600-ADM-CFLW-X
           END-IF.

           IF (RCFLW-CF-TRXN-ADMIN-FEE
           OR  RCFLW-CF-TRXN-ADMIN-FEE-REVRS)
           AND NOT RCFLW-CF-REASN-MORTALITY
               CONTINUE
           ELSE
               GO TO 3600-ADM-CFLW-X
           END-IF.

           MOVE RCFLW-CF-CLI-TRXN-AMT        TO WS-SAVE-TRXN-AMT.
           PERFORM  3700-MOVE-PHST-TO-MIR
               THRU 3700-MOVE-PHST-TO-MIR-X.

       3600-ADM-CFLW-X.
           EXIT.

      *---------------------
       3700-MOVE-PHST-TO-MIR.
      *---------------------

           MOVE RPHST-PCHST-EFF-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
                                 TO MIR-DV-FIN-TRXN-EFF-DT-T (WS-SUB).


           EVALUATE TRUE

               WHEN RPHST-POL-ACTV-TYP-ID = '4007'
                    SET WS-TRXN-TYP-ADM    TO TRUE

               WHEN RPHST-POL-ACTV-TYP-ID = '4008'
               WHEN RPHST-POL-ACTV-TYP-ID = '5004'
                    SET WS-TRXN-TYP-CDM    TO TRUE

               WHEN RPHST-POL-ACTV-TYP-ID = '5002'
                    SET WS-TRXN-TYP-AMF    TO TRUE

               WHEN RPHST-POL-ACTV-TYP-ID = '5003'
                    SET WS-TRXN-TYP-AFO   TO TRUE

               WHEN RPHST-POL-ACTV-TYP-ID = '4014'
                    SET WS-TRXN-TYP-TAF   TO TRUE

               WHEN RPHST-POL-ACTV-TYP-ID = '5100'
                    SET WS-TRXN-TYP-PUP   TO TRUE

           END-EVALUATE.

           MOVE WS-TRXN-TYP-ID  TO MIR-DV-FIN-TRXN-TYP-CD-T (WS-SUB).


020874*    COMPUTE L0290-INPUT-NUMBER = WS-SAVE-TRXN-AMT * 100.
020874     MOVE WS-SAVE-TRXN-AMT     TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-FIN-TRXN-GRS-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
                                TO MIR-DV-FIN-TRXN-GRS-AMT-T (WS-SUB).


           MOVE RPHST-PCHST-STAT-CD
                                TO MIR-DV-FIN-TRXN-STAT-CD-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RPHST-PCHST-SEQ-NUM.
020874     MOVE RPHST-PCHST-SEQ-NUM      TO L0290-INPUT-V00.
           MOVE 0                        TO L0290-PRECISION.
021657*    MOVE LENGTH OF MIR-DV-FIRST-SEQ-NUM-T (WS-SUB)
021657     MOVE LENGTH OF MIR-DV-FIN-TRXN-SEQ-NUM-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
021657*    MOVE L0290-OUTPUT-DATA  TO MIR-DV-FIRST-SEQ-NUM-T (WS-SUB).
021657     MOVE L0290-OUTPUT-DATA TO MIR-DV-FIN-TRXN-SEQ-NUM-T (WS-SUB).

           ADD +1                       TO WS-SUB.

       3700-MOVE-PHST-TO-MIR-X.
           EXIT.


      *----------------
       3800-PROCESS-UH.
      *----------------

           SET WS-TRXN-STAT-ACTIVE   TO TRUE.

           PERFORM  3810-CHECK-UH-STATUS
               THRU 3810-CHECK-UH-STATUS-X.

           MOVE WS-TRXN-STAT-CD  TO MIR-DV-FIN-TRXN-STAT-CD-T (WS-SUB).

           MOVE WS-SAVE-UH-EFF-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
                                 TO MIR-DV-FIN-TRXN-EFF-DT-T (WS-SUB).

           SET WS-TRXN-TYP-MTH  TO TRUE.
           MOVE WS-TRXN-TYP-ID  TO MIR-DV-FIN-TRXN-TYP-CD-T (WS-SUB).


020874*    COMPUTE L0290-INPUT-NUMBER = RUH-POL-TOT-DED-AMT * 100.
020874     MOVE RUH-POL-TOT-DED-AMT            TO L0290-INPUT-V02.
           MOVE 2                              TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-FIN-TRXN-GRS-AMT-T (WS-SUB)
                                               TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS       TO TRUE.
           SET L0290-SIGN-SUPPRESS             TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
                                 TO MIR-DV-FIN-TRXN-GRS-AMT-T (WS-SUB).

020874*    MOVE ZERO                     TO L0290-INPUT-NUMBER.
020874     MOVE ZERO                     TO L0290-INPUT-V00.
           MOVE 0                        TO L0290-PRECISION.
021657*    MOVE LENGTH OF MIR-DV-FIRST-SEQ-NUM-T (WS-SUB)
021657     MOVE LENGTH OF MIR-DV-FIN-TRXN-SEQ-NUM-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
021657*    MOVE L0290-OUTPUT-DATA    TO MIR-DV-FIRST-SEQ-NUM-T (WS-SUB).
021657     MOVE L0290-OUTPUT-DATA TO MIR-DV-FIN-TRXN-SEQ-NUM-T (WS-SUB).

           ADD +1                    TO WS-SUB.

           PERFORM  3110-SET-NEXT-UH-DATE
               THRU 3110-SET-NEXT-UH-DATE-X.

           IF  WS-SAVE-UH-EFF-DT < RPOL-POL-ISS-EFF-DT
               SET WS-UH-REC-NO-MORE    TO TRUE
               MOVE SPACES              TO WS-SAVE-UH-EFF-DT
               GO TO 3800-PROCESS-UH-X
           END-IF.

           SET  WS-UH-REC-FOUND-NO      TO TRUE.
           PERFORM  3100-GET-NEXT-UH-REC
               THRU 3100-GET-NEXT-UH-REC-X
               UNTIL WS-UH-REC-FOUND-YES
               OR   WS-UH-REC-NO-MORE.

       3800-PROCESS-UH-X.
           EXIT.


      *---------------------
       3810-CHECK-UH-STATUS.
      *---------------------

           MOVE RUH-KEY                 TO WUHCO-KEY.
           MOVE WUHCO-KEY               TO WUHCO-ENDBR-KEY.
           MOVE LOW-VALUE               TO WUHCO-CVG-NUM.
           MOVE HIGH-VALUE              TO WUHCO-ENDBR-CVG-NUM.

           PERFORM  UHCO-1000-BROWSE
               THRU UHCO-1000-BROWSE-X.

           PERFORM  UHCO-2000-READ-NEXT
               THRU UHCO-2000-READ-NEXT-X.

           IF WUHCO-IO-EOF
              SET WS-TRXN-STAT-REVERSED  TO TRUE
           END-IF.

           PERFORM  UHCO-3000-END-BROWSE
               THRU UHCO-3000-END-BROWSE-X.

       3810-CHECK-UH-STATUS-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY   TO TRUE.
           MOVE MIR-POL-ID         TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORK-AREA.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

025970     MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.
025970     MOVE SPACES               TO MIR-OUTPUT-AREA.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

026057 COPY CCPPIHSD.
       COPY NCPPCVGS.
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0260.
025970 COPY XCPS1670.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL0290.
       COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.
       COPY CCPNCVG.
       COPY CCPNCFLW.
       COPY SCPNFA.
       COPY CCPBPHST.
       COPY CCPNUH.
       COPY CCPBUHCO.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **              END OF PROGRAM CSOM7814                        **
      *****************************************************************
