      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4913.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4913                                         **
      **  REMARKS:  THIS MODULE RETRIEVE CLIENT NAME AND ADDRESS     **
      **            FROM SYSTEM AND RETURN FORMATTED CLIENT NAME/    **
      **            ADDRESS INFO. FOR APPLICATION ENTRY              **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016051**  6.1       NEW FOR RELEASE 6.1                              **
016387**  6.2       REMOVE CLIENT CONSOLIDATION SUPPORT              **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
023434**  6.5       EXPAND ADDRESS LINE                              **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4913'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

      *
      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************

021930*COPY XCWWWKDT.
       COPY XCWEBLCH.

      *
       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID             VALUE '4913'.
               88  WS-BUS-FCN-RETRIEVE          VALUE '4913'.

           05  WS-VALIDATE-FAIL-SW          PIC X(01) VALUE 'N'.
               88  WS-VALIDATE-FAILED       VALUE 'Y'.
025970         88  WS-VALIDATE-FAILED-NO    VALUE 'N'.

           05  WS-PIC-999                   PIC 9(03).
           05  WS-HOLD-SEQNO                PIC X(03).
           05  WS-HOLD-SEQNO-N REDEFINES
               WS-HOLD-SEQNO                PIC 9(03).

           05  WS-SWITCHES.
               10  WS-ADDR-SW               PIC X(01).
                   88  WS-ADDR-FOUND        VALUE 'Y'.
                   88  WS-NO-ADDR-FOUND     VALUE 'N'.
020478     05  WS-EFF-DT                    PIC X(10).
      *
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWEDIT.
       COPY CCFREDIT.
      *
020478 COPY CCFWCLEA.
020478 COPY CCFRCLEA.
020478*
       COPY CCFWCLI.
       COPY CCFRCLI.
      *
       COPY CCFWCLIA.
       COPY CCFRCLIA.
      *
020478*COPY CCFWCLNM.
020478*COPY CCFRCLNM.
      *
       COPY CCFWCLNC.
       COPY CCFRCLNC.
      *
      ****************************************************************
      *  CALLED MODULE PARAMTER INFORMATION                          *
      ****************************************************************
021930*COPY XCWLDTLK.
020478 COPY XCWLDTLK.

       COPY CCWL0620.
020478 COPY CCWL2435.
020478 COPY CCWL2626.

       COPY XCWL0280.
020874 COPY XCWL0290.
020478*
020478 COPY XCWL1640.
      *
       COPY CCWL0951.
      *
       COPY CCWL5600.
      *
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      *
       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM4913.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X.

020478     PERFORM  FCCK-1000-CHECK-CLIENT
020478         THRU FCCK-1000-CHECK-CLIENT-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      **********************
       2000-PROCESS-REQUEST.
      **********************
      *
020874     PERFORM  0290-1000-BUILD-PARM-INFO
020874         THRU 0290-1000-BUILD-PARM-INFO-X.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      *    PROCESS SCREEN FUNCTIONS
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                   PERFORM  3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                   MOVE 'XS00000237'      TO  WGLOB-MSG-REF-INFO
                   MOVE MIR-BUS-FCN-ID    TO  WGLOB-MSG-PARM (1)
                   MOVE 'CSOM4913'        TO  WGLOB-MSG-PARM (2)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-INVALD-RQST  TO  TRUE

           END-EVALUATE.
      *
       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      ****************************************************************
      * INQUIRY PROCESSING:  SETUP KEY AND READ RECORD               *
      ****************************************************************
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      * CHECK CLIENT ACCESS

           PERFORM  5600-0000-INIT-PARM-INFO
               THRU 5600-0000-INIT-PARM-INFO-X.
           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.
           MOVE MIR-CLI-ID                TO L5600-CLI-ID.
016387*    SET L5600-GEN-CNSLDT-MSG-WARN TO TRUE.
           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.

      *
      * CHECK THE RETURN FROM CLIENT ACCESS
      *

           IF  L5600-RETRN-CLI-NOT-FOUND
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           IF  L5600-CNFD-ACCS-RESTRICTED
016387*    OR  L5600-CNSLDT-ACCS-RESTRICTED
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  5000-EDIT-KEY-FIELDS
               THRU 5000-EDIT-KEY-FIELDS-X.

           IF WS-VALIDATE-FAILED
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.
      *
           PERFORM  3200-GET-CLI-NAME
               THRU 3200-GET-CLI-NAME-X.

           PERFORM  3400-GET-ADDR-INFO
               THRU 3400-GET-ADDR-INFO-X.

           IF WGLOB-RETURN-ERROR
              GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

      *
       3000-PROCESS-RETRIEVE-X.
           EXIT.
      *
      *-----------------
       3200-GET-CLI-NAME.
      *----------------

           PERFORM  8000-BUILD-NAL-KEY
               THRU 8000-BUILD-NAL-KEY-X.

           PERFORM  CLI-1000-READ
               THRU CLI-1000-READ-X.

020478*    SET WCLNC-IO-OK                      TO  TRUE.
020478*    SET WCLNM-IO-OK                      TO  TRUE.

           IF  RCLI-CLI-SEX-COMPANY
               PERFORM  CLNC-1000-READ
                   THRU CLNC-1000-READ-X
020478         IF  WCLNC-IO-OK
020478             PERFORM  3220-FORMAT-CLI-NM
020478                 THRU 3220-FORMAT-CLI-NM-X
020478         END-IF
           ELSE
020478*        PERFORM  CLNM-1000-READ
020478*            THRU CLNM-1000-READ-X
020478         PERFORM  2435-1000-BUILD-PARM-INFO
020478             THRU 2435-1000-BUILD-PARM-INFO-X
020478         MOVE MIR-CLI-ID                  TO L2435-CLI-ID
020478         IF  NOT WGLOB-COUNTRY-JAPAN
020478             SET L2435-CLI-GR-ALPHA   TO TRUE
020478         ELSE
020478             SET L2435-CLI-GR-KANJI   TO TRUE
020478         END-IF

020478         PERFORM  2435-2000-CRNT-CLI-NAME
020478             THRU 2435-2000-CRNT-CLI-NAME-X
020478         IF  L2435-RETRN-OK
020478             PERFORM  3220-FORMAT-CLI-NM
020478                 THRU 3220-FORMAT-CLI-NM-X
020478         END-IF
           END-IF.

020478*    IF  WCLNC-IO-OK
020478*    AND WCLNM-IO-OK
020478*        PERFORM  3220-FORMAT-CLI-NM
020478*            THRU 3220-FORMAT-CLI-NM-X
020478*    END-IF.

       3200-GET-CLI-NAME-X.
           EXIT.

      *
      *-------------------
       3220-FORMAT-CLI-NM.
      *-------------------

           MOVE RCLI-CLI-SEX-CD      TO L0620-CLI-SEX-CD.

           IF  RCLI-CLI-SEX-COMPANY
               MOVE SPACES                TO L0620-CLI-GIV-NM
               MOVE SPACES                TO L0620-CLI-SUR-NM
               MOVE SPACES                TO L0620-CLI-SFX-NM
               MOVE SPACES                TO L0620-CLI-MID-INIT-NM
               MOVE RCLNC-CLI-CO-ENTR-NM  TO L0620-CLI-CO-NM
           ELSE
020478*        MOVE RCLNM-ENTR-GIV-NM     TO L0620-CLI-GIV-NM
020478*        MOVE RCLNM-ENTR-SUR-NM     TO L0620-CLI-SUR-NM
020478*        MOVE RCLNM-CLI-INDV-SFX-NM TO L0620-CLI-SFX-NM
020478*        MOVE RCLNM-CLI-INDV-MID-NM TO L0620-CLI-MID-INIT-NM
               MOVE SPACES                TO L0620-CLI-CO-NM
020478         IF  NOT WGLOB-COUNTRY-JAPAN
020478             MOVE L2435-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
020478             MOVE L2435-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
020478             MOVE L2435-CLI-SFX-NM      TO L0620-CLI-SFX-NM
020478             MOVE L2435-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
020478         ELSE
020478             MOVE L2435-CLI-KJ-ENTR-GIV-NM
020478                                        TO L0620-CLI-GIV-NM
020478             MOVE L2435-CLI-KJ-ENTR-SUR-NM
020478                                        TO L0620-CLI-SUR-NM
020478             MOVE L2435-CLI-KJ-SFX-NM   TO L0620-CLI-SFX-NM
020478             MOVE L2435-CLI-KJ-MID-INIT-NM
020478                                        TO L0620-CLI-MID-INIT-NM
020478         END-IF
           END-IF.

           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.

           MOVE L0620-SCREEN-NAME  TO MIR-DV-CLI-NM.

       3220-FORMAT-CLI-NM-X.
           EXIT.
      *
      *------------------
       3400-GET-ADDR-INFO.
      *------------------

           PERFORM  8100-BUILD-CLIA-KEY
               THRU 8100-BUILD-CLIA-KEY-X.

020478*    IF WS-NO-ADDR-FOUND
020478*       GO TO 3400-GET-ADDR-INFO-X
020478*    END-IF.
020478*
020478*    PERFORM CLIA-1000-READ
020478*       THRU CLIA-1000-READ-X.

020478     PERFORM  CLEA-1000-BROWSE
020478         THRU CLEA-1000-BROWSE-X
020478     PERFORM  CLEA-2000-READ-NEXT
020478         THRU CLEA-2000-READ-NEXT-X

020478*    IF WCLIA-IO-OK
020478     IF WCLEA-IO-OK
               CONTINUE
           ELSE
020478         PERFORM  CLEA-3000-END-BROWSE
020478             THRU CLEA-3000-END-BROWSE-X
020478*        MOVE WCLIA-KEY         TO WGLOB-MSG-PARM (1)
020478         MOVE WCLEA-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3400-GET-ADDR-INFO-X
           END-IF.
020478     MOVE RCLEA-REC-INFO        TO RCLIA-REC-INFO.
020478     PERFORM  CLEA-3000-END-BROWSE
020478         THRU CLEA-3000-END-BROWSE-X.
020478     SET WS-ADDR-FOUND          TO TRUE
020478     IF  WGLOB-COUNTRY-JAPAN
020478         IF  NOT RCLIA-CLI-ADDR-GR-KANJI
020478             MOVE RCLIA-KEY     TO WCLIA-KEY
020478             SET  WCLIA-CLI-ADDR-GR-KANJI
020478                                TO TRUE
020478             PERFORM  CLIA-1000-READ
020478                 THRU CLIA-1000-READ-X
020478             IF  NOT WCLIA-IO-OK
020478                 SET WS-NO-ADDR-FOUND
020478                                TO TRUE
020478             END-IF
020478         END-IF
020478     ELSE
020478         IF  NOT RCLIA-CLI-ADDR-GR-ALPHA
020478             SET  WS-NO-ADDR-FOUND
020478                                TO TRUE
020478         END-IF
020478     END-IF.
020478
020478     IF  WS-NO-ADDR-FOUND
020478         MOVE WCLIA-KEY         TO WGLOB-MSG-PARM (1)
020478         MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
020478         PERFORM  0260-1000-GENERATE-MESSAGE
020478             THRU 0260-1000-GENERATE-MESSAGE-X
020478         GO TO 3400-GET-ADDR-INFO-X
020478     END-IF.

           PERFORM  3420-FORMAT-ADDRESS
               THRU 3420-FORMAT-ADDRESS-X.


       3400-GET-ADDR-INFO-X.
           EXIT.
      *
      *-------------------
       3420-FORMAT-ADDRESS.
      *-------------------

           INITIALIZE                   L0951-INPUT-PARM-INFO.

           MOVE RCLIA-CLI-ADDR-LN-1-TXT TO  L0951-CLI-ADDR-LN-1-TXT.
           MOVE RCLIA-CLI-ADDR-LN-2-TXT TO  L0951-CLI-ADDR-LN-2-TXT.
           MOVE RCLIA-CLI-ADDR-LN-3-TXT TO  L0951-CLI-ADDR-LN-3-TXT.
           MOVE RCLIA-CLI-ADDR-MUN-CD   TO  L0951-CLI-MUN-CD.
           MOVE RCLIA-CLI-ADDR-CNTY-CD  TO  L0951-CLI-CNTY-CD.
           MOVE RCLIA-CLI-CITY-NM-TXT   TO  L0951-CLI-CITY-NM-TXT.
           MOVE RCLIA-CLI-CRNT-LOC-CD   TO  L0951-CLI-CRNT-LOC-CD.
           MOVE RCLIA-CLI-CTRY-CD       TO  L0951-CLI-CTRY-CD.
           MOVE RCLIA-CLI-PSTL-CD       TO  L0951-CLI-PSTL-CD.
018763*    MOVE RCLIA-CLI-JP-ADDR-CD    TO  L0951-CLI-JP-ADDR-CD.
018763     MOVE RCLIA-CLI-ALT-ADDR-CD   TO  L0951-CLI-ALT-ADDR-CD.
           MOVE RCLIA-CLI-RES-NUM       TO  L0951-CLI-RES-NUM.
           MOVE RCLIA-CLI-RES-TYP-CD    TO  L0951-CLI-RES-TYP-CD.
023434     MOVE RCLIA-CLI-CTRY-CD        TO L0951-FORMAT-CTRY.

           PERFORM  0951-1000-FORMAT-ADDRESS
               THRU 0951-1000-FORMAT-ADDRESS-X.

           IF NOT L0951-RETRN-OK
              GO TO 3420-FORMAT-ADDRESS-X
           END-IF.

           MOVE L0951-CLIENT-ADDRESS-LINE (01)
                                      TO  MIR-CLI-ADDR-LN-1-TXT-T (01).
           MOVE L0951-CLIENT-ADDRESS-LINE (02)
                                      TO  MIR-CLI-ADDR-LN-1-TXT-T (02).
           MOVE L0951-CLIENT-ADDRESS-LINE (03)
                                      TO  MIR-CLI-ADDR-LN-1-TXT-T (03).
           MOVE L0951-CLIENT-ADDRESS-LINE (04)
                                      TO  MIR-CLI-ADDR-LN-1-TXT-T (04).
           MOVE L0951-CLIENT-ADDRESS-LINE (05)
                                      TO  MIR-CLI-ADDR-LN-1-TXT-T (05).
           MOVE L0951-CLIENT-ADDRESS-LINE (06)
                                      TO  MIR-CLI-ADDR-LN-1-TXT-T (06).

       3420-FORMAT-ADDRESS-X.
           EXIT.
      *
      *--------------------
       5000-EDIT-KEY-FIELDS.
      *--------------------

      ****CLIENT ID CANNOT BE BLANK

           IF  MIR-CLI-ID = SPACES
               SET  WS-VALIDATE-FAILED TO  TRUE
      *MSG: CLIENT ID CANNOT BE BLANK
               MOVE 'CS49130001'       TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
      ****ADDRESS TYPE: CANNOT BE BLANK
      ****              MUST BE DEFINED ON EDIT
      ****              PRIMARY ADDRESS CANNOT BE CREATED/MAINTAINED
      *
           IF MIR-CLI-ADDR-TYP-CD = SPACES
               SET WS-VALIDATE-FAILED TO TRUE
      *MSG: CLEINT ADDRESS TYPE CODE CANNOT BE BLANK
               MOVE 'CS49130002'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
           MOVE MIR-CLI-ADDR-TYP-CD   TO WEDIT-ETBL-VALU-ID.
           PERFORM  ADDR-1000-EDIT
               THRU ADDR-1000-EDIT-X.
           IF WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               SET WS-VALIDATE-FAILED TO TRUE
      *MSG CLIENT ADDRESS TYPE (ADTYP) MUST BE FOUND IN EDIT TABLE
               MOVE 'CS49130003'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-CLI-ADDR-TYP-CD
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      **** EDIT SEQUENCE NUMBER, SEQUENCE MUST BE NUMERIC OR SPACES
020478*    IF  MIR-CLI-ADDR-SEQ-NUM = EBLCH-BLANK-FIELD-CHAR
020478*        MOVE SPACES          TO MIR-CLI-ADDR-SEQ-NUM
020478*    END-IF.
020478*
020478*    IF  MIR-CLI-ADDR-SEQ-NUM NOT = SPACES
020478*        MOVE 'N'               TO  L0280-SPACE-PERMITTED-IND
020478*        MOVE 'N'               TO  L0280-SIGN-IND
020478*        MOVE 0                 TO  L0280-PRECISION
020478*        MOVE 3                 TO  L0280-LENGTH
020478*        MOVE 3                 TO  L0280-INPUT-SIZE
020478*        MOVE MIR-CLI-ADDR-SEQ-NUM
020478*                               TO  L0280-INPUT-DATA
020478*        PERFORM  0280-1000-NUMERIC-EDIT
020478*            THRU 0280-1000-NUMERIC-EDIT-X
020478*        IF  L0280-OK
020874*            MOVE L0280-OUTPUT  TO  WS-HOLD-SEQNO-N
020874*            MOVE WS-HOLD-SEQNO TO  MIR-CLI-ADDR-SEQ-NUM
020478*            MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020478*            MOVE 0                     TO L0290-PRECISION
020478*            MOVE LENGTH OF MIR-CLI-ADDR-SEQ-NUM
020478*                               TO L0290-MAX-OUT-LEN
020478*            PERFORM 0290-2000-FORMAT-FOR-MIR
020478*              THRU 0290-2000-FORMAT-FOR-MIR-X
020478*            MOVE L0290-OUTPUT-DATA   TO MIR-CLI-ADDR-SEQ-NUM
020478*        ELSE
020478*            SET WS-VALIDATE-FAILED    TO  TRUE
020478*MSG: SEQUENCE NUMBER MUST BE SPACES OR NUMERIC
020478*            MOVE 'CS49130004'         TO WGLOB-MSG-REF-INFO
020478*            PERFORM  0260-1000-GENERATE-MESSAGE
020478*                THRU 0260-1000-GENERATE-MESSAGE-X
020478*        END-IF
020478*    END-IF.
020478     IF  MIR-CLI-ADDR-EFF-DT = SPACES
020478         MOVE WGLOB-PROCESS-DATE       TO WS-EFF-DT
020478     ELSE
020478         MOVE MIR-CLI-ADDR-EFF-DT      TO L1640-EXTERNAL-DATE
020478         PERFORM  1640-7000-MIR-TO-INT
020478             THRU 1640-7000-MIR-TO-INT-X
020478
020478         IF  L1640-NOT-VALID
020478*MSG : INVALID ADDRESS EFFECTIVE DATE
020478             MOVE 'CS49130005'         TO WGLOB-MSG-REF-INFO
020478             PERFORM  0260-1000-GENERATE-MESSAGE
020478                 THRU 0260-1000-GENERATE-MESSAGE-X
020478             SET WS-VALIDATE-FAILED    TO  TRUE
020478             GO TO 5000-EDIT-KEY-FIELDS-X
020478         ELSE
020478             MOVE L1640-INTERNAL-DATE  TO WS-EFF-DT
020478         END-IF
020478     END-IF.

       5000-EDIT-KEY-FIELDS-X.
           EXIT.
      *
      *-----------------
       8000-BUILD-NAL-KEY.
      *-----------------

           MOVE MIR-CLI-ID                   TO WCLI-CLI-ID.
           MOVE MIR-CLI-ID                   TO WCLNC-CLI-ID.
020478*    MOVE MIR-CLI-ID                   TO WCLNM-CLI-ID.
020478*    MOVE +1                           TO WCLNM-CLI-INDV-SEQ-NUM.
           MOVE MIR-CLI-ID                   TO WCLNC-CLI-ID.

           SET  WCLNC-CLI-CO-NM-TYP-CLI      TO TRUE.
020478*    SET  WCLNM-CLI-INDV-NM-TYP-CRNT   TO TRUE.

018763*    SET  WCLNM-CLI-INDV-GR-ALPHA      TO TRUE.
018763*    SET  WCLNC-CLI-CO-GR-ALPHA        TO TRUE.
018763
018763     IF  NOT WGLOB-COUNTRY-JAPAN
018763         SET WCLNC-CLI-CO-GR-ALPHA     TO TRUE
020478*        SET WCLNM-CLI-INDV-GR-ALPHA   TO TRUE
018763     ELSE
018763         SET WCLNC-CLI-CO-GR-KANJI     TO TRUE
020478*        SET WCLNM-CLI-INDV-GR-KANJI   TO TRUE
018763     END-IF.

       8000-BUILD-NAL-KEY-X.
           EXIT.
      *
      *--------------------
       8100-BUILD-CLIA-KEY.
      *--------------------

020478*    MOVE MIR-CLI-ID                         TO WCLIA-CLI-ID.

020478*    SET WS-ADDR-FOUND                       TO TRUE.

018763*    SET  WCLIA-CLI-ADDR-GR-ALPHA            TO TRUE.
020478*    IF  WGLOB-COUNTRY-JAPAN
020478*        SET  WCLIA-CLI-ADDR-GR-KANJI    TO TRUE
020478*    ELSE
020478*        SET  WCLIA-CLI-ADDR-GR-ALPHA    TO TRUE
020478*    END-IF.
020478*
020478*    MOVE MIR-CLI-ADDR-TYP-CD    TO  WCLIA-CLI-ADDR-TYP-CD.
020478*    MOVE LOW-VALUES             TO  WCLIA-CLI-ADDR-SEQ-NUM.
020478*    MOVE WCLIA-KEY              TO  WCLIA-ENDBR-KEY.
020478*    MOVE HIGH-VALUES        TO  WCLIA-ENDBR-CLI-ADDR-SEQ-NUM.
020478*    MOVE ZERO                   TO WS-PIC-999.
020478*
020478*    IF  MIR-CLI-ADDR-SEQ-NUM = ZEROS
020478*    OR  MIR-CLI-ADDR-SEQ-NUM = SPACES
020478*        PERFORM  CLIA-2000-READ-MAX
020478*            THRU CLIA-2000-READ-MAX-X
020478*        IF WCLIA-IO-OK
020478*           MOVE WCLIA-MAX-CLI-ADDR-SEQ-NUM
020478*                                TO  WS-PIC-999
020478*        ELSE
020478*           SET WS-NO-ADDR-FOUND TO  TRUE
020478*        END-IF
020478*        MOVE WS-PIC-999         TO  WCLIA-CLI-ADDR-SEQ-NUM-N
020478*        GO TO 8100-BUILD-CLIA-KEY-X
020478*    END-IF.
020478*
020478*    IF MIR-CLI-ADDR-SEQ-NUM NUMERIC
020478*       MOVE  MIR-CLI-ADDR-SEQ-NUM TO WS-PIC-999
020478*    END-IF.
020478*
020478*    MOVE WS-PIC-999             TO  WCLIA-CLI-ADDR-SEQ-NUM-N.
020478     MOVE MIR-CLI-ID             TO WCLEA-CLI-ID.
020478     MOVE MIR-CLI-ADDR-TYP-CD    TO WCLEA-CLI-ADDR-TYP-CD.
020478     MOVE WS-EFF-DT              TO WCLEA-CLI-ADDR-EFF-DT.

       8100-BUILD-CLIA-KEY-X.
           EXIT.

      *
      *--------------------
       9100-BLANK-DATA-FIELDS.
      *--------------------
      *
           MOVE SPACES        TO  MIR-CLI-ADDR-LN-1-TXT-G.
      *
       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *-----------------------
       9300-SETUP-MSIN-REFERENCE.
      *-----------------------
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

      *
       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0951-0000-INIT-PARM-INFO
025970         THRU 0951-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970
025970     SET  WS-VALIDATE-FAILED-NO       TO TRUE.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      *
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
      *
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY CCPEADDR.
      *
025970 COPY CCPS0951.
025970 COPY CCPS0620.
       COPY CCPL0620.
020478 COPY CCPS2435.
020478 COPY CCPL2435.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY XCPS0280.
       COPY XCPL0280.
020874 COPY XCPL0290.
020874 COPY XCPS0290.
       COPY CCPS5600.
      *
      ****************************************************************
      * GENERAL COPYBOOKS                                            *
      ****************************************************************
020478 COPY CCPPFCCK.
       COPY XCPPINIT.
       COPY XCPPEXIT.
      *
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
018764*COPY CCCL0951.
018764 COPY CCPL0951.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS1640.
020478 COPY XCPL1640.
018764*COPY CCCL5600.
018764 COPY CCPL5600.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
      *
       COPY CCPNEDIT.
      *
020478 COPY CCPBCLEA.
       COPY CCPNCLI.
021930*COPY CCPUCLI.
      *
021930*COPY CCPBCLIA.
020478*COPY CCPFCLIA.
       COPY CCPNCLIA.
      *
       COPY CCPNCLNC.
020478*COPY CCPNCLNM.
      *
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM4913                     **
      *****************************************************************
