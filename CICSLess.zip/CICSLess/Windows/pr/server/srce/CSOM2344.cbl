      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2344.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2344                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE BROWSE FUNCTION OF      **
      **            DAIRY/CLIENT FOR A CLIENT BY AN AUTHORIZED       **
      **            USER.                                            **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       ORIGINAL - NEW FOR RELEASE 6.0                   **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016387**  6.2       REMOVE FUSE SUPPORT                              **
016440**  6.2       NB/AD SUPPORT                                    **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
015703**  6.4       REMOVE CCWLPGA                                   **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2344'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.
       COPY XCWWTIME.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID               PIC X(04).
               88  WS-BUS-CLI-LIST         VALUE '2344'.

       01  WS-FCN-WORK-AREA.
           05  WS-SWITCHES.
               10  WS-KEY-FIELDS-OK-SW      PIC X(01).
                   88  WS-KEY-FIELDS-OK         VALUE 'Y'.
                   88  WS-KEY-FIELDS-NOT-OK     VALUE 'N'.
           05  WS-SUBSCRIPT.
016548*        10  WS-SUB                   PIC S9(04) COMP.
016548         10  WS-SUB                   PIC S9(04) BINARY.
016548*        10  WS-CLI-POL-SUB           PIC S9(04) COMP.
016548         10  WS-CLI-POL-SUB           PIC S9(04) BINARY.
           05  WS-LINE                      PIC 9(02).
025970*    05  WS-MAX-LINES                 PIC 9(02) VALUE 25.
025970*    05  WS-MAX-POL                   PIC 9(02) VALUE 10.
           05  WS-RDALG-KEY.
               10  WS-RDALG-ID              PIC X(06).
               10  WS-RDALG-NUM             PIC X(04).
           05  WS-POL-ID.
               10  WS-POL-ID-BASE           PIC X(09).
               10  WS-POL-ID-SFX            PIC X(01).
           05  WS-SEQ-NO                    PIC X(03).
           05  WS-PIC-99                    PIC 9(02).
           05  WS-PIC-999                   PIC 9(03).
           05  WS-CLIENT-BROWSE-KEY         PIC X(50).
           05  WS-FORMAT-TIME.
               10  WS-FORMAT-HH             PIC X(02).
               10  WS-FORMAT-MM             PIC X(02).
               10  WS-FORMAT-SS             PIC X(02).
           05  WS-REL-SYS-REF-TABLE.
               15  WS-REL-SYS-REF-INFO      OCCURS 10 TIMES.
                   20  WS-REL-SYS-REF-POL-ID   PIC X(10).
                  20  WS-REL-SYS-REF-CVG-NUM   PIC X(02).
                  
025970 01  WS-CONSTANT-FIELDS.
025970     05  WS-MAX-LINES                  PIC 9(02).  
025970         88  WS-MAX-LINES-DEFAULT      VALUE 25. 
025970     05  WS-MAX-POL                    PIC 9(02).  
025970         88  WS-MAX-POL-DEFAULT        VALUE 10. 

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
016537*COPY CCWWFRMT.
016537*COPY XCWEBLCH.
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
021930*COPY CCFWPOL.
021930*COPY CCFRPOL.
021930*
021930*COPY CCFWCVG.
021930*COPY CCFRCVG.
021930*
       COPY CCFWRL.
       COPY CCFRRL.
      /
       COPY NCFWDALG.
       COPY NCFRDALG.
      /
016537*COPY CCFWEDIT.
016537*COPY CCFREDIT.
      /
015703*COPY CCWLPGA.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
       COPY CCWL5600.
       COPY XCWL0280.
020874 COPY XCWL0290.       
       COPY XCWL1640.
      /
       COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2344.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           SET MIR-RETRN-OK                  TO  TRUE.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           IF  MIR-CPEVNT-TRXN-DT NOT > SPACES
               PERFORM  1200-DEFAULT-DATE
                   THRU 1200-DEFAULT-DATE-X
           END-IF.

           MOVE SPACES                  TO  WS-FORMAT-TIME.
           MOVE MIR-CPEVNT-TRXN-TIME    TO  WS-FORMAT-TIME.

           IF  WS-FORMAT-TIME NOT > SPACES
               PERFORM  1400-DEFAULT-TIME
                   THRU 1400-DEFAULT-TIME-X
           END-IF.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           MOVE MIR-BUS-FCN-ID    TO  WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-CLI-LIST
                    PERFORM  2000-PROCESS-LIST
                        THRU 2000-PROCESS-LIST-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID           TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2344'               TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST     TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------------
       1200-DEFAULT-DATE.
      *------------------

           MOVE WGLOB-SYSTEM-DATE-INT TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CPEVNT-TRXN-DT.

       1200-DEFAULT-DATE-X.
           EXIT.
      *------------------
       1400-DEFAULT-TIME.
      *------------------

           MOVE WGLOB-SYSTEM-TIME     TO WTIME-EDIT-TIME.
           MOVE WTIME-EDIT-HH         TO WS-FORMAT-HH.
           MOVE WTIME-EDIT-MM         TO WS-FORMAT-MM.
           MOVE WTIME-EDIT-SS         TO WS-FORMAT-SS.
           MOVE WS-FORMAT-TIME        TO MIR-CPEVNT-TRXN-TIME.

       1400-DEFAULT-TIME-X.
           EXIT.
      /
      *-----------------
       2000-PROCESS-LIST.
      *-----------------

           PERFORM  2200-VALIDATE-KEY-FIELDS
               THRU 2200-VALIDATE-KEY-FIELDS-X.

           IF  NOT WS-KEY-FIELDS-OK
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-LIST-X
           END-IF.

           PERFORM  4000-BUILD-RELA-DISPLAY
               THRU 4000-BUILD-RELA-DISPLAY-X.

           MOVE ZEROS                      TO  WS-LINE.
           MOVE HIGH-VALUES                TO  WDALG-KEY.
           PERFORM  7000-BUILD-DALG-BROWSE-KEY
               THRU 7000-BUILD-DALG-BROWSE-KEY-X.

           PERFORM  4200-CLIENT-LIST
               THRU 4200-CLIENT-LIST-X.

       2000-PROCESS-LIST-X.
           EXIT.
      /
      *------------------------
       2200-VALIDATE-KEY-FIELDS.
      *-----------------------

           SET WS-KEY-FIELDS-OK             TO  TRUE.

           IF MIR-CPEVNT-SEQ-NUM = SPACES
              MOVE '999'                   TO  MIR-CPEVNT-SEQ-NUM
           END-IF.
           PERFORM  3000-EDIT-CLIENT-NUM
               THRU 3000-EDIT-CLIENT-NUM-X.

           PERFORM  3100-EDIT-FORMAT-DATE
               THRU 3100-EDIT-FORMAT-DATE-X.

           PERFORM  3200-EDIT-FORMAT-TIME
               THRU 3200-EDIT-FORMAT-TIME-X.

           PERFORM  3300-EDIT-SEQUENCE-NUM
               THRU 3300-EDIT-SEQUENCE-NUM-X.

       2200-VALIDATE-KEY-FIELDS-X.
           EXIT.
      /
      *---------------------
       3000-EDIT-CLIENT-NUM.
      *---------------------

           IF MIR-CPEVNT-POL-CLI-ID = SPACES
               MOVE 'CS23440001'               TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-EDIT-CLIENT-NUM-X
           END-IF.

      *    CALL THE CLIENT ACCESS VERIFICATION MODULE


           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.

016387*    SET  L5600-GEN-CNSLDT-MSG-WARN   TO TRUE.
           MOVE MIR-CPEVNT-POL-CLI-ID TO L5600-CLI-ID.

           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.

           IF  L5600-RETRN-OK
               CONTINUE
           ELSE
               SET WS-KEY-FIELDS-NOT-OK     TO   TRUE
               GO TO 3000-EDIT-CLIENT-NUM-X
           END-IF.

           IF  L5600-CNFD-ACCS-RESTRICTED
               SET WS-KEY-FIELDS-NOT-OK     TO  TRUE
           END-IF.

       3000-EDIT-CLIENT-NUM-X.
           EXIT.
      /
      *----------------------
       3100-EDIT-FORMAT-DATE.
      *----------------------

           MOVE MIR-CPEVNT-TRXN-DT       TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-NOT-VALID
               MOVE MIR-CPEVNT-TRXN-DT   TO WGLOB-MSG-PARM (1)
               MOVE 'CS23440002'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-KEY-FIELDS-NOT-OK  TO TRUE
               GO TO 3100-EDIT-FORMAT-DATE-X
           END-IF.

           IF L1640-INTERNAL-DATE > WGLOB-SYSTEM-DATE-INT
               MOVE 'CS23440003'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-KEY-FIELDS-NOT-OK   TO TRUE
           END-IF.

       3100-EDIT-FORMAT-DATE-X.
           EXIT.
      /
      *----------------------
       3200-EDIT-FORMAT-TIME.
      *----------------------

           MOVE MIR-CPEVNT-TRXN-TIME  TO WS-FORMAT-TIME.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 6                     TO L0280-LENGTH.
           MOVE 6                     TO L0280-INPUT-SIZE.
           MOVE WS-FORMAT-TIME        TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF NOT L0280-OK
               MOVE 'CS23440004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-KEY-FIELDS-NOT-OK TO TRUE
           END-IF.

       3200-EDIT-FORMAT-TIME-X.
           EXIT.
      /
      *-----------------------
       3300-EDIT-SEQUENCE-NUM.
      *-----------------------

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE MIR-CPEVNT-SEQ-NUM    TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-SEQ-NO
           ELSE
               MOVE 'CS23440005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-KEY-FIELDS-NOT-OK TO TRUE
               GO TO 3300-EDIT-SEQUENCE-NUM-X
           END-IF.

       3300-EDIT-SEQUENCE-NUM-X.
           EXIT.
      /
      *------------------------
       4000-BUILD-RELA-DISPLAY.
      *------------------------

           MOVE SPACES                TO WS-REL-SYS-REF-TABLE.
           MOVE ZERO                  TO WS-CLI-POL-SUB.
015904*    MOVE SPACES                TO MIR-DV-ADDL-POL-IND.

           PERFORM  4100-FIND-POLICIES
               THRU 4100-FIND-POLICIES-X.

           PERFORM
               VARYING WS-SUB FROM +1 BY +1
               UNTIL  WS-SUB > WS-MAX-POL
               MOVE WS-REL-SYS-REF-POL-ID (WS-SUB)
015904*                     TO  MIR-REL-SYS-REF-POL-ID-T (WS-SUB)
015904                      TO  MIR-DV-REL-SYS-REF-POL-ID-T (WS-SUB)
               MOVE WS-REL-SYS-REF-CVG-NUM (WS-SUB)
015904*                     TO  MIR-REL-SYS-REF-CVG-NUM-T (WS-SUB)
015904                      TO  MIR-DV-REL-SYS-REF-CVG-NUM-T (WS-SUB)
           END-PERFORM.

       4000-BUILD-RELA-DISPLAY-X.
           EXIT.
      /
      *------------------
       4100-FIND-POLICIES.
      *-------------------

           MOVE LOW-VALUES            TO WRL-KEY.
           MOVE MIR-CPEVNT-POL-CLI-ID TO WRL-CLI-ID.

           MOVE HIGH-VALUES           TO WRL-ENDBR-KEY.
           MOVE MIR-CPEVNT-POL-CLI-ID TO WRL-ENDBR-CLI-ID.

           PERFORM  RL-1000-BROWSE
               THRU RL-1000-BROWSE-X.

           IF WRL-IO-EOF
               GO TO 4100-FIND-POLICIES-X
           END-IF.

           PERFORM RL-2000-READ-NEXT
              THRU RL-2000-READ-NEXT-X.
           IF NOT WRL-IO-OK
               PERFORM RL-3000-END-BROWSE
                  THRU RL-3000-END-BROWSE-X
               GO TO 4100-FIND-POLICIES-X
           END-IF.

               PERFORM  4120-LOOP-THRU-RELA
                   THRU 4120-LOOP-THRU-RELA-X
                  UNTIL (NOT WRL-IO-OK)
                     OR (WS-CLI-POL-SUB > WS-MAX-POL)

           PERFORM RL-3000-END-BROWSE
              THRU RL-3000-END-BROWSE-X.

       4100-FIND-POLICIES-X.
           EXIT.
      /
      *-------------------
       4120-LOOP-THRU-RELA.
      *-------------------

      *    READ THE NEXT RECORD AND EXIT IF THIS IS NOT AN INSURED
      *    RELATIONSHIP

           IF RRL-REL-TYP-CD  NOT = 'I'
               PERFORM RL-2000-READ-NEXT
                  THRU RL-2000-READ-NEXT-X
               GO TO 4120-LOOP-THRU-RELA-X
           END-IF.

      *    READ THE NEXT RECORD AND EXIT IF THIS IS NOT A
      *    RELATIONSHIP GENERATED FROM THE ADMIN OR NEWBUS SYSTEMS

016387*    IF RRL-REL-SYS-ID = 'ADMIN'
016387*    OR RRL-REL-SYS-ID = 'NEWBUS'
016387     IF RRL-REL-SYS-ID = WGLOB-SYS-CTL-ID
              CONTINUE
           ELSE
               PERFORM  RL-2000-READ-NEXT
                   THRU RL-2000-READ-NEXT-X
               GO TO 4120-LOOP-THRU-RELA-X
           END-IF.

           ADD 1       TO WS-CLI-POL-SUB.

           IF WS-CLI-POL-SUB > WS-MAX-POL
015904*       MOVE '*'                 TO  MIR-DV-ADDL-POL-IND
              GO TO 4120-LOOP-THRU-RELA-X
           END-IF.

           MOVE RRL-REL-SYS-REF-POL-ID
                       TO WS-REL-SYS-REF-POL-ID (WS-CLI-POL-SUB).
           MOVE RRL-REL-SYS-REF-CVG-NUM
                       TO WS-REL-SYS-REF-CVG-NUM (WS-CLI-POL-SUB).

           PERFORM RL-2000-READ-NEXT
              THRU RL-2000-READ-NEXT-X.

       4120-LOOP-THRU-RELA-X.
           EXIT.
      /
      *----------------
       4200-CLIENT-LIST.
      *----------------

           MOVE ZEROS                 TO WS-LINE.
           MOVE WS-CLIENT-BROWSE-KEY  TO WDALG-KEY.
           MOVE WS-CLIENT-BROWSE-KEY  TO RDALG-KEY.
           MOVE LOW-VALUES            TO WDALG-ENDBR-KEY.
           MOVE WWKDT-LOW-DT          TO WDALG-ENDBR-CPEVNT-TRXN-DT.
           MOVE WDALG-CPEVNT-POL-CLI-CD
                                      TO WDALG-ENDBR-CPEVNT-POL-CLI-CD.
           MOVE WDALG-CPEVNT-POL-CLI-ID
                                      TO WDALG-ENDBR-CPEVNT-POL-CLI-ID.

      ***  BEGIN BROWSE PREVIOUS
           PERFORM  DALG-1000-BROWSE-PREV
               THRU DALG-1000-BROWSE-PREV-X.

           IF WDALG-IO-OK
           PERFORM  DALG-2000-READ-PREV
               THRU DALG-2000-READ-PREV-X
           END-IF.

           IF NOT WDALG-IO-OK
           OR WDALG-IO-EOF
      *MSG:        'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  DALG-3000-END-BROWSE-PREV
                   THRU DALG-3000-END-BROWSE-PREV-X
               GO TO 4200-CLIENT-LIST-X
           END-IF.

      ***      LOAD SCREEN DATA

           PERFORM  4220-DISPLAY-RECORD
               THRU 4220-DISPLAY-RECORD-X
               UNTIL (WDALG-IO-EOF)
                  OR (WS-LINE > WS-MAX-LINES).

           IF WDALG-IO-EOF
               MOVE 'XS00000015'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE RDALG-CPEVNT-TRXN-DT  TO  L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE  TO  MIR-CPEVNT-TRXN-DT
               MOVE RDALG-CPEVNT-TRXN-TIME   TO  WS-FORMAT-TIME
               MOVE WS-FORMAT-TIME           TO  MIR-CPEVNT-TRXN-TIME
               MOVE RDALG-CPEVNT-SEQ-NUM     TO  MIR-CPEVNT-SEQ-NUM
               MOVE RDALG-CPEVNT-GR-CD       TO  MIR-CPEVNT-GR-CD
               MOVE RDALG-EVNT-ACTV-CD       TO  MIR-EVNT-ACTV-CD
               SET WGLOB-MORE-DATA-EXISTS    TO  TRUE
               MOVE 'XS00000014'             TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      ***  FINISH BROWSE PREV
           PERFORM  DALG-3000-END-BROWSE-PREV
               THRU DALG-3000-END-BROWSE-PREV-X.

       4200-CLIENT-LIST-X.
           EXIT.
      /
      *-------------------
       4220-DISPLAY-RECORD.
      *-------------------

      ***  IF DALG SECURITY NOT PASSED, READ ANOTHER RECORD AND EXIT.
           IF RDALG-CPEVNT-SECUR-CD  > WGLOB-SECUR-LVL-CD
                PERFORM  DALG-2000-READ-PREV
                    THRU DALG-2000-READ-PREV-X
                GO TO 4220-DISPLAY-RECORD-X
           ELSE
               ADD  1  TO  WS-LINE
               IF WS-LINE > WS-MAX-LINES
                  GO TO 4220-DISPLAY-RECORD-X
               ELSE
                  PERFORM  4222-MOVE-REC-TO-SCREEN
                      THRU 4222-MOVE-REC-TO-SCREEN-X
               END-IF
           END-IF.

           PERFORM  DALG-2000-READ-PREV
               THRU DALG-2000-READ-PREV-X.

       4220-DISPLAY-RECORD-X.
           EXIT.
      /
      *-----------------------
       4222-MOVE-REC-TO-SCREEN.
      *------------------------

           MOVE RDALG-CPEVNT-POL-CLI-ID
                                 TO MIR-CPEVNT-POL-CLI-ID-T (WS-LINE).
           MOVE RDALG-CPEVNT-TRXN-DT
                                 TO  L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
                                 TO  MIR-CPEVNT-TRXN-DT-T (WS-LINE).
           MOVE RDALG-CPEVNT-TRXN-TIME
                                 TO  WS-FORMAT-TIME.
           MOVE WS-FORMAT-TIME   TO  MIR-CPEVNT-TRXN-TIME-T (WS-LINE).
020874*    MOVE RDALG-CPEVNT-SEQ-NUM
020874*                          TO  WS-PIC-999.
020874*    MOVE WS-PIC-999           TO  MIR-CPEVNT-SEQ-NUM-T (WS-LINE).
020874     MOVE RDALG-CPEVNT-SEQ-NUM  TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CPEVNT-SEQ-NUM-T (WS-LINE)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CPEVNT-SEQ-NUM-T (WS-LINE).
           MOVE RDALG-CPEVNT-GR-CD   TO  MIR-CPEVNT-GR-CD-T (WS-LINE).
           MOVE RDALG-EVNT-ACTV-CD   TO  MIR-EVNT-ACTV-CD-T (WS-LINE).
           MOVE RDALG-EVNT-ACT-CD    TO  MIR-EVNT-ACT-CD-T (WS-LINE).
           MOVE RDALG-CVG-NUM        TO  MIR-CVG-NUM-T (WS-LINE).
           MOVE RDALG-CPEVNT-SRC-CD  TO  MIR-CPEVNT-SRC-CD-T (WS-LINE).
           MOVE RDALG-BUS-FCN-ID     TO  MIR-BUS-FCN-ID-T (WS-LINE).
           MOVE RDALG-USER-ID        TO  MIR-USER-ID-T (WS-LINE).
           MOVE RDALG-MSG-REF-ID     TO  WS-RDALG-ID.
           MOVE RDALG-MSG-REF-NUM    TO  WS-RDALG-NUM.
           MOVE WS-RDALG-KEY         TO  WGLOB-MSG-REF-INFO.
           MOVE RDALG-CPEVNT-PARM-1-TXT
                                     TO  WGLOB-MSG-PARM (1).
           MOVE RDALG-CPEVNT-PARM-2-TXT
                                     TO  WGLOB-MSG-PARM (2).
           MOVE RDALG-CPEVNT-PARM-3-TXT
                                     TO  WGLOB-MSG-PARM (3).
           MOVE RDALG-CPEVNT-PARM-4-TXT
                                     TO  WGLOB-MSG-PARM (4).
           PERFORM  0260-2000-GET-MESSAGE
               THRU 0260-2000-GET-MESSAGE-X.
015904*    MOVE WGLOB-MSG-TXT      TO MIR-DV-MSG-TXT-T (WS-LINE).
015904     MOVE WGLOB-MSG-TXT      TO MIR-MSG-TXT-T (WS-LINE).

       4222-MOVE-REC-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       7000-BUILD-DALG-BROWSE-KEY.
      *--------------------------
      *
      *  BUILD THE RECORD KEY FROM THE MIR FIELDS
      *

           MOVE SPACES                TO WS-CLIENT-BROWSE-KEY.

           MOVE 'C'                   TO WDALG-CPEVNT-POL-CLI-CD.
           MOVE MIR-CPEVNT-POL-CLI-ID TO WDALG-CPEVNT-POL-CLI-ID.
           MOVE MIR-CPEVNT-TRXN-DT    TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE   TO  WDALG-CPEVNT-TRXN-DT.
           MOVE MIR-CPEVNT-TRXN-TIME  TO  WS-FORMAT-TIME.
           MOVE WS-FORMAT-TIME        TO  WDALG-CPEVNT-TRXN-TIME.
           MOVE MIR-CPEVNT-SEQ-NUM    TO  WDALG-CPEVNT-SEQ-NUM.
           MOVE MIR-EVNT-ACTV-CD      TO  WDALG-EVNT-ACTV-CD.
           MOVE MIR-CPEVNT-GR-CD      TO  WDALG-CPEVNT-GR-CD.
           MOVE WDALG-KEY             TO  WS-CLIENT-BROWSE-KEY.

       7000-BUILD-DALG-BROWSE-KEY-X.
           EXIT.
      /
      *----------------------
       9100-BLANK-DATA-FIELDS.
      *----------------------

015904*    MOVE SPACES             TO  MIR-REL-SYS-REF-POL-ID-G.
015904     MOVE SPACES             TO  MIR-DV-REL-SYS-REF-POL-ID-G.
015904*    MOVE SPACES             TO  MIR-REL-SYS-REF-CVG-NUM-G.
015904     MOVE SPACES             TO  MIR-DV-REL-SYS-REF-CVG-NUM-G.
015904*    MOVE SPACES             TO  MIR-DV-ADDL-POL-IND.
           MOVE SPACES             TO  MIR-CPEVNT-POL-CLI-ID-G.
           MOVE SPACES             TO  MIR-CPEVNT-TRXN-DT.
           MOVE SPACES             TO  MIR-CPEVNT-TRXN-TIME-G.
           MOVE SPACES             TO  MIR-CPEVNT-SEQ-NUM-G.
           MOVE SPACES             TO  MIR-CPEVNT-GR-CD-G.
           MOVE SPACES             TO  MIR-EVNT-ACTV-CD-G.
           MOVE SPACES             TO  MIR-EVNT-ACT-CD-G.
           MOVE SPACES             TO  MIR-CVG-NUM-G.
           MOVE SPACES             TO  MIR-CPEVNT-SRC-CD-G.
           MOVE SPACES             TO  MIR-BUS-FCN-ID-G.
           MOVE SPACES             TO  MIR-USER-ID-G.
015904*    MOVE SPACES             TO  MIR-DV-MSG-TXT-G.
015904     MOVE SPACES             TO  MIR-MSG-TXT-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE       WS-WORKING-STORAGE.
025970     INITIALIZE       WS-FCN-WORK-AREA.
025970     MOVE SPACES TO   WWKDT-WORK-FIELDS.
025970     SET WS-MAX-LINES-DEFAULT        TO TRUE. 
025970     SET WS-MAX-POL-DEFAULT          TO TRUE. 
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.

023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
      /
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
      /
016537*COPY NCPEACTN.
016537*COPY NCPEACTV.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
020874 COPY XCPL0290.       
020874 COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
       COPY CCPS5600.
018764*COPY CCCL5600.
018764 COPY CCPL5600.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
      /
016537*COPY CCPNPOL.
      /
016537*COPY CCPNCVG.
      /
016537*COPY CCPNEDIT.
      /
       COPY CCPBRL.
      /
016537*COPY NCPADALG.
016537*COPY NCPBDALG.
016537*COPY NCPCDALG.
016537*COPY NCPNDALG.
016537*COPY NCPUDALG.
       COPY NCPVDALG.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2344                     **
      *****************************************************************
