      *************************
       IDENTIFICATION DIVISION.
      *************************
      *
       PROGRAM-ID. CSOM0091.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0091                                         **
      **  REMARKS:  ACCT - MAINTAIN ACCOUNTING (AC) TABLE.           **
      **            THIS MODULE PERFORMS TABLE MAINTENANCE FUNCTIONS **
      **            FOR THE ACCOUNT (AC) TABLE. NOTE THAT READS OF   **
      **            PH AND BRCH ARE DONE AS PART OF THE AC KEY FIELD **
      **            EDITS.                                           **
      **  DOMAIN :  AC                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557658**  5.5       YEAR 2000 REPORT MODIFICATIONS                   **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557708**  5.5       CICS ABEND HANDLING                              **
557973**  5.5       AMOUNT FIELD SIZING FOR INTL SUPPORT             **
558021**  5.5       RETRIEVE ACCT DESC FROM NEW ACTC TABLE           **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
010357**  5.5.2     CORRECT MESSAGE XS00000001 ON INQUIRE & DEL      **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010418**  5.6       ADD FIELD TO SCREEN TO MAINTAIN ACCOUNTING       **
010418**            TABLE WITH MULTI-COMPANY PROCESSING              **
006002**  6.0       NEW COUNTRY LOCATION TABLE                       **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014591**  6.0       COMBINE TWO PARTS FIELD                          **
015648**  6.0       HANDLING BLANK FIELD CHARACTER                   **
016203**  6.1       UNDO 006002 CHANGES                              **
016255**  6.1       DISPLAY ACCOUNT FIELDS ON UPDATE/OUTPUT          **
011970**  6.2       REMOVE FIELD FROM AC TABLE                       **
014221**  6.2       LOGICAL LOCKING                                  **
014591**  6.2       COMBINE PLAN-ID & RS                             **
016395**  6.2       CREDIT CARD BILLING                              **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
019708**  6.3       SETUP PROPER KEY FOR MESSAGES                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
       ENVIRONMENT DIVISION.
      **********************
      *
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0091'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.

558021 COPY CCWL0093.

       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-SUB1                      PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB1                      PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12  COMP.
025970*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12
025970*                                     BINARY.
016548*    05  WS-MAX-MONTH                 PIC S9(4)  VALUE +12  COMP.
025970*    05  WS-MAX-MONTH                 PIC S9(4)  VALUE +12
025970*                                     BINARY.
           05  WS-IF-BALANCE-PRESENT        PIC X.
               88  WS-BALANCE-PRESENT           VALUE 'Y'.
557973*    05  WS-CURRENT-BALANCE           PIC S9(9)V99 COMP-3.
557973     05  WS-CURRENT-BALANCE           PIC S9(15)V99 COMP-3.
008455*    05  EDIT-1                       PIC ---------9.99.
557658     05  EDIT-4-DIGITS                PIC 9999.
008455*    05  EDIT-2                       PIC ---------9.99.
           05  WS-FAIL-EDIT                 PIC X(01)  VALUE SPACE.
               88  FAIL-EDIT                           VALUES 'Y'.
               88  EDIT-OK                             VALUES 'N'.
008455         88  FAIL-EDIT-BTOT                      VALUES 'T'.
           05  WS-ACTYP-VALID               PIC X(02)  VALUE SPACES.
               88  ACTYP-VALID                         VALUES ARE
                   'A', 'B', 'C', 'E', 'I', 'L', 'M',
                   'P', 'T', 'X', 'S', 'W', ' '.
           05  WS-BCCLR-VALID               PIC X(01)  VALUE SPACES.
               88  BCCLR-VALID                         VALUES ARE
020467             'B', 'C', 'D', 'N', 'P', 'R'.               
016395*                                     'B', 'C', 'N', 'P'.
020467*                                     'B', 'C', 'N', 'P', 'R'.
           05  WS-PAUPDT-VALID              PIC X(02)  VALUE SPACES.
               88  PAUPDT-VALID                        VALUES ARE
                          'A', 'AB', 'OD', 'PS', 'MS', 'SC', 'PC', 'NN'.
           05  WS-BUS-FCN-ID                PIC X(04)  VALUE SPACES.
               88  WS-BUS-FCN-VALID         VALUE '1430' '1431'
                                                  '1432' '1433'
                                                  '1434'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '1430'.
               88  WS-BUS-FCN-CREATE        VALUE '1431'.
               88  WS-BUS-FCN-UPDATE        VALUE '1432'.
               88  WS-BUS-FCN-DELETE        VALUE '1433'.
               88  WS-BUS-FCN-LIST          VALUE '1434'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '1430'.
           05  WS-DISPLAY-NUM               PIC 9(05).
557658*    05  WS-CURR-YR-WORK1             PIC 99     VALUE ZEROES.
557658*    05  WS-CURR-YR-WORK2             PIC 99     VALUE ZEROES.
           05  CURRENT-BALANCE              PIC S9(09)V99 VALUE ZEROES.
557973*    05  WS-BUDGET-TOTAL              PIC S9(9)V99 COMP-3.
557973     05  WS-BUDGET-TOTAL              PIC S9(15)V99 COMP-3.
014591*    05  WS-PLAN-ID.
014591*        10  WS-PLAN                  PIC X(05)  VALUE SPACES.
014591*        10  WS-PLAN-RS               PIC X(01)  VALUE SPACES.
014591     05  WS-PLAN-ID                   PIC X(06)  VALUE SPACES.
           05  WS-ACNT.
               10  WS-ACNT-12               PIC X(02)  VALUE SPACES.
               10  FILLER                   PIC X(04)  VALUE SPACES.
           05  J                            PIC 999.
557658     05  WS-WAC-ACCT-YR               PIC X(04).
557658     05  WS-WAC-ACCT-YR-N             REDEFINES
557658         WS-WAC-ACCT-YR               PIC 9(04).
557658
557658     05  WS-WAC-KEY.
557658         10  WS-WAC-CO-ID                    PIC X(02).
557658         10  WS-WAC-ACCT-ID-INFO.
557658             15  WS-WAC-ACCT-BASE-ID         PIC X(06).
557658             15  WS-WAC-ACCT-YEAR            PIC 9(04).
557658             15  WS-WAC-ACCT-YEAR-C          REDEFINES
557658                 WS-WAC-ACCT-YEAR            PIC X(04).
010418             15  WS-WAC-SBSDRY-CO-ID         PIC X(02).
                   15  WS-WAC-ACCT-CRCY-CD         PIC X(02).
557658             15  WS-WAC-PLAN-ID              PIC X(06).
557658             15  WS-WAC-BR-OR-DEPT-ID        PIC X(05).
557658             15  WS-WAC-ACCT-ISS-LOC-CD      PIC X(02).
557658             15  WS-WAC-ACCT-CRNT-LOC-CD     PIC X(02).
010418*            15  WS-WAC-ACCT-LOB-DIVSN-CD    PIC X(01).

025970 01  WS-CONSTANTS.
025970     05  WS-MAX-BROWSE-LINES                 PIC S9(4) BINARY.
025970         88  WS-MAX-BROWSE-LINES-DEFAULT     VALUE +12.
025970     05  WS-MAX-MONTH                        PIC S9(4) BINARY.
025970         88  WS-MAX-MONTH-DEFAULT            VALUE +12.
025970     05  WS-TWRK-KEY                         PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT             VALUE '1430'.
      /
       COPY XCWEBLCH.
       COPY CCFWEDIT.
       COPY CCFREDIT.
016537*COPY CCWZEDIT.
558021*COPY CCWTADES.
558021*COPY CCWWADES.
016537*COPY CCWW0093.
014221 COPY CCWWLOCK.
558021 COPY CCWTACTC.
       COPY CCWTAKEY.
      /
021930*COPY CCFWBRCH.
021930*COPY CCFRBRCH.
016537*COPY CCFWACTD.
016537*COPY CCFRACTD.

010418 COPY CCFWSCOM.
010418 COPY CCFRSCOM.
      /
014221 COPY XCWL8090.
      /
       COPY XCWL0280.
008455 COPY XCWL0290.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
       COPY CCFWAC.
       COPY CCFRAC.
      /
016537*COPY XCFWXTAB.
016537*COPY XCFRXTAB.
008455/
008455 COPY XCFWCRCY.
008455 COPY XCFRCRCY.
      /
016203*COPY XCFWCTLC.
016203*COPY XCFRCTLC.
016203*
025970 COPY XCWWWKDT.
021930*
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      *
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0091.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

015648     INSPECT MIR-PARM-AREA REPLACING ALL '*' BY ' '.

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

025970*    MOVE MIR-BUS-FCN-ID        TO  WS-BUS-FCN-ID.
025970*    SET  MIR-RETRN-OK          TO  TRUE.

           IF  NOT WS-BUS-FCN-VALID
               SET MIR-RETRN-INVALD-RQST  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

008455
008455     PERFORM 0290-1000-BUILD-PARM-INFO
008455        THRU 0290-1000-BUILD-PARM-INFO-X.
008455
           MOVE 'N'                   TO WS-FAIL-EDIT.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *    PROCESS SCREEN FUNCTIONS
      *
557658     IF NOT WS-BUS-FCN-LIST
557658        PERFORM  2200-MIR-ACCT-YR-EDIT
557658            THRU 2200-MIR-ACCT-YR-EDIT-X
557658        IF L0280-OK
557658           CONTINUE
557658        ELSE
557658           GO TO 2000-PROCESS-REQUEST-X
557658        END-IF
557658     END-IF.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                   PERFORM  3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                   PERFORM  3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                   PERFORM  4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                   PERFORM  5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                   PERFORM  6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------
557658 2200-MIR-ACCT-YR-EDIT.
      *----------------------

557658     MOVE MIR-ACCT-YR           TO  L0280-INPUT-DATA.
557658     MOVE 4                     TO  L0280-INPUT-SIZE.
557658     MOVE 4                     TO  L0280-LENGTH.
557658     MOVE 0                     TO  L0280-PRECISION.
557658     MOVE 'N'                   TO  L0280-SIGN-IND.
557658     MOVE 'N'                   TO  L0280-SPACE-PERMITTED-IND.

557658     PERFORM  0280-1000-NUMERIC-EDIT
557658        THRU  0280-1000-NUMERIC-EDIT-X.

557658     IF L0280-OK
557658        CONTINUE
557658     ELSE
557658**   YEAR MUST BE VALID NUMERIC
557658        MOVE 'CS00919001'       TO  WGLOB-MSG-REF-INFO
557658        PERFORM  0260-1000-GENERATE-MESSAGE
557658           THRU  0260-1000-GENERATE-MESSAGE-X
557658     END-IF.

557658 2200-MIR-ACCT-YR-EDIT-X.
557658     EXIT.
      /
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------

           MOVE MIR-ACCT-BASE-ID      TO WAC-ACCT-BASE-ID.
557658*    MOVE MIR-ACCT-YR                  TO WAC-ACCT-YR-CD.
557658     IF MIR-ACCT-YR = SPACES
557658        MOVE '0000'             TO WS-WAC-ACCT-YR
557658     ELSE
557658        MOVE MIR-ACCT-YR        TO WS-WAC-ACCT-YR
557658     END-IF.
557658     MOVE WS-WAC-ACCT-YR-N      TO WAC-ACCT-YR.
010418     MOVE MIR-SBSDRY-CO-ID      TO WAC-SBSDRY-CO-ID.
           MOVE MIR-ACCT-CRCY-CD      TO WAC-ACCT-CRCY-CD.
014591     MOVE MIR-PLAN-ID           TO WS-PLAN-ID.
014591*    MOVE MIR-RS                TO WS-PLAN-RS.
           MOVE WS-PLAN-ID            TO WAC-PLAN-ID.
           MOVE MIR-BR-OR-DEPT-ID     TO WAC-BR-OR-DEPT-ID.
           MOVE MIR-ACCT-ISS-LOC-CD   TO WAC-ACCT-ISS-LOC-CD.
           MOVE MIR-ACCT-CRNT-LOC-CD  TO WAC-ACCT-CRNT-LOC-CD.
010418*    MOVE MIR-LOB                   TO WAC-ACCT-LOB-DIVSN-CD.

014221*    PERFORM  AC-1000-READ
014221*        THRU AC-1000-READ-X.

014221     PERFORM  AC-1000-READ-TWRK-TS
014221         THRU AC-1000-READ-TWRK-TS-X.

           IF WAC-IO-OK
558021        PERFORM  0093-0000-INIT-PARM-INFO
558021            THRU 0093-0000-INIT-PARM-INFO-X
558021        MOVE MIR-ACCT-BASE-ID   TO  L0093-ACCT-DESC-ID
558021        MOVE SPACES             TO  L0093-ACCT-DESC-REASN-CD
558021        PERFORM  0093-1000-RETRIEVE-ACCT-INFO
558021            THRU 0093-1000-RETRIEVE-ACCT-INFO-X
              PERFORM  9200-MOVE-RECORD-TO-SCREEN
                  THRU 9200-MOVE-RECORD-TO-SCREEN-X
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
           ELSE
               PERFORM 9100-BLANK-DATA-FIELDS
                  THRU 9100-BLANK-DATA-FIELDS-X
557658         MOVE WAC-CO-ID         TO WS-WAC-CO-ID
557658         MOVE WAC-ACCT-BASE-ID  TO WS-WAC-ACCT-BASE-ID
557658         MOVE WS-WAC-ACCT-YR    TO WS-WAC-ACCT-YEAR
010418         MOVE WAC-SBSDRY-CO-ID  TO WS-WAC-SBSDRY-CO-ID
               MOVE WAC-ACCT-CRCY-CD  TO WS-WAC-ACCT-CRCY-CD
557658         MOVE WAC-PLAN-ID       TO WS-WAC-PLAN-ID
557658         MOVE WAC-BR-OR-DEPT-ID TO WS-WAC-BR-OR-DEPT-ID
557658         MOVE WAC-ACCT-ISS-LOC-CD
                                      TO WS-WAC-ACCT-ISS-LOC-CD
557658         MOVE WAC-ACCT-CRNT-LOC-CD
                                      TO WS-WAC-ACCT-CRNT-LOC-CD
010418*        MOVE WAC-ACCT-LOB-DIVSN-CD TO WS-WAC-ACCT-LOB-DIVSN-CD
557658         MOVE WS-WAC-KEY        TO WGLOB-MSG-PARM (1)
557658*        MOVE WAC-KEY               TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *------------------
       3500-PROCESS-LIST.
      *------------------

           MOVE SPACES                TO MIR-ACCT-BASE-ID-G.
           MOVE SPACES                TO MIR-ACCT-YR-G.
010418     MOVE SPACES                TO MIR-SBSDRY-CO-ID-G.
           MOVE SPACES                TO MIR-ACCT-CRCY-CD-G.
           MOVE SPACES                TO MIR-PLAN-ID-G.
014591*    MOVE SPACES                TO MIR-RS-TABLE.
           MOVE SPACES                TO MIR-BR-OR-DEPT-ID-G.
           MOVE SPACES                TO MIR-ACCT-ISS-LOC-CD-G.
           MOVE SPACES                TO MIR-ACCT-CRNT-LOC-CD-G.
010418*    MOVE SPACES                TO MIR-LOB-TABLE.
           MOVE SPACES                TO MIR-DV-ACCT-YTD-AMT-G.
           MOVE SPACES                TO MIR-ACCT-DESC-TXT-G.

           MOVE LOW-VALUES            TO WAC-KEY.
           MOVE HIGH-VALUES           TO WAC-ENDBR-KEY.
557658     MOVE +9999                 TO WAC-ENDBR-ACCT-YR.

           MOVE MIR-ACCT-BASE-ID      TO WAC-ACCT-BASE-ID.
557658*    MOVE MIR-ACCT-YR           TO WAC-ACCT-YR-CD.
557658     IF MIR-ACCT-YR = SPACES
557658        MOVE '0000'             TO WS-WAC-ACCT-YR
557658     ELSE
557658        MOVE MIR-ACCT-YR        TO WS-WAC-ACCT-YR
557658     END-IF.
557658     MOVE WS-WAC-ACCT-YR-N      TO WAC-ACCT-YR.
010418     MOVE MIR-SBSDRY-CO-ID      TO WAC-SBSDRY-CO-ID.
           MOVE MIR-ACCT-CRCY-CD      TO WAC-ACCT-CRCY-CD.
014591     MOVE MIR-PLAN-ID           TO WS-PLAN-ID.
014591*    MOVE MIR-RS                TO WS-PLAN-RS.
           MOVE WS-PLAN-ID            TO WAC-PLAN-ID.
           MOVE MIR-BR-OR-DEPT-ID     TO WAC-BR-OR-DEPT-ID.
           MOVE MIR-ACCT-ISS-LOC-CD   TO WAC-ACCT-ISS-LOC-CD.
           MOVE MIR-ACCT-CRNT-LOC-CD  TO WAC-ACCT-CRNT-LOC-CD.
010418*    MOVE MIR-LOB                    TO WAC-ACCT-LOB-DIVSN-CD.

           PERFORM  AC-1000-BROWSE
               THRU AC-1000-BROWSE-X.

           IF WAC-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM  AC-2000-READ-NEXT
               THRU AC-2000-READ-NEXT-X.

           IF WAC-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM  3510-PROCESS-BROWSE-READ
               THRU 3510-PROCESS-BROWSE-READ-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-BROWSE-LINES
               OR    WAC-IO-EOF.

           IF WAC-IO-EOF
               MOVE MIR-ACCT-BASE-ID-T   (01)
                                      TO MIR-ACCT-BASE-ID
               MOVE MIR-ACCT-YR-T   (01)
                                      TO MIR-ACCT-YR
010418         MOVE MIR-SBSDRY-CO-ID-T  (01)
                                      TO MIR-SBSDRY-CO-ID
               MOVE MIR-ACCT-CRCY-CD-T   (01)
                                      TO MIR-ACCT-CRCY-CD
               MOVE MIR-PLAN-ID-T   (01)
                                      TO MIR-PLAN-ID
014591*        MOVE MIR-RS-T     (01) TO MIR-RS
               MOVE MIR-BR-OR-DEPT-ID-T   (01)
                                      TO MIR-BR-OR-DEPT-ID
               MOVE MIR-ACCT-ISS-LOC-CD-T  (01)
                                      TO MIR-ACCT-ISS-LOC-CD
               MOVE MIR-ACCT-CRNT-LOC-CD-T  (01)
                                      TO MIR-ACCT-CRNT-LOC-CD
010418*        MOVE MIR-LOB-T    (01)      TO MIR-LOB
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE RAC-ACCT-BASE-ID  TO MIR-ACCT-BASE-ID
557658*        MOVE RAC-ACCT-YR-CD         TO MIR-ACCT-YR
020874*        MOVE RAC-ACCT-YR       TO EDIT-4-DIGITS
020874*        MOVE EDIT-4-DIGITS     TO MIR-ACCT-YR
020874         MOVE RAC-ACCT-YR           TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-ACCT-YR
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-ACCT-YR
010418         MOVE RAC-SBSDRY-CO-ID  TO MIR-SBSDRY-CO-ID
               MOVE RAC-ACCT-CRCY-CD  TO MIR-ACCT-CRCY-CD
               MOVE RAC-PLAN-ID       TO WS-PLAN-ID
014591         MOVE WS-PLAN-ID        TO MIR-PLAN-ID
014591*        MOVE WS-PLAN-RS        TO MIR-RS
               MOVE RAC-BR-OR-DEPT-ID TO MIR-BR-OR-DEPT-ID
               MOVE RAC-ACCT-ISS-LOC-CD
                                      TO MIR-ACCT-ISS-LOC-CD
               MOVE RAC-ACCT-CRNT-LOC-CD
                                      TO MIR-ACCT-CRNT-LOC-CD
010418*        MOVE RAC-ACCT-LOB-DIVSN-CD  TO MIR-LOB
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  AC-3000-END-BROWSE
               THRU AC-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *-------------------------
       3510-PROCESS-BROWSE-READ.
      *-------------------------

558021     PERFORM  0093-0000-INIT-PARM-INFO
558021         THRU 0093-0000-INIT-PARM-INFO-X.
558021     MOVE RAC-ACCT-BASE-ID      TO  L0093-ACCT-DESC-ID.
558021     MOVE SPACES                TO  L0093-ACCT-DESC-REASN-CD.
558021     PERFORM  0093-1000-RETRIEVE-ACCT-INFO
558021         THRU 0093-1000-RETRIEVE-ACCT-INFO-X.

      *-- MOVE FIELDS TO SCREEN
           MOVE RAC-ACCT-BASE-ID      TO MIR-ACCT-BASE-ID-T  (WS-SUB).
557658*    MOVE RAC-ACCT-YR-CD             TO MIR-ACCT-YR-T  (WS-SUB).
020874*    MOVE RAC-ACCT-YR           TO EDIT-4-DIGITS.
020874*    MOVE EDIT-4-DIGITS         TO MIR-ACCT-YR-T  (WS-SUB).
020874     MOVE RAC-ACCT-YR           TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-ACCT-YR-T  (WS-SUB)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-ACCT-YR-T  (WS-SUB).
010418     MOVE RAC-SBSDRY-CO-ID      TO MIR-SBSDRY-CO-ID-T (WS-SUB).
           MOVE RAC-ACCT-CRCY-CD      TO MIR-ACCT-CRCY-CD-T  (WS-SUB).
           MOVE RAC-PLAN-ID           TO WS-PLAN-ID.
014591     MOVE WS-PLAN-ID            TO MIR-PLAN-ID-T  (WS-SUB).
014591*    MOVE WS-PLAN-RS            TO MIR-RS-T    (WS-SUB).
           MOVE RAC-BR-OR-DEPT-ID     TO MIR-BR-OR-DEPT-ID-T  (WS-SUB).
           MOVE RAC-ACCT-ISS-LOC-CD   TO MIR-ACCT-ISS-LOC-CD-T (WS-SUB).
           MOVE RAC-ACCT-CRNT-LOC-CD TO MIR-ACCT-CRNT-LOC-CD-T (WS-SUB).
010418*    MOVE RAC-ACCT-LOB-DIVSN-CD      TO MIR-LOB-T   (WS-SUB).
           PERFORM  7000-COMPUTE-CURRENT-BALANCE
               THRU 7000-COMPUTE-CURRENT-BALANCE-X.
008455*    MOVE WS-CURRENT-BALANCE         TO EDIT-1.
008455*    MOVE EDIT-1            TO MIR-DV-ACCT-YTD-AMT-T  (WS-SUB).
020874*    COMPUTE L0290-INPUT-NUMBER = WS-CURRENT-BALANCE * 100.
020874     MOVE WS-CURRENT-BALANCE    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-ACCT-YTD-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY         TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA  TO MIR-DV-ACCT-YTD-AMT-T    (WS-SUB).
558021     MOVE L0093-ACCT-DESC-TXT  TO MIR-ACCT-DESC-TXT-T    (WS-SUB).

           PERFORM  AC-2000-READ-NEXT
               THRU AC-2000-READ-NEXT-X.

       3510-PROCESS-BROWSE-READ-X.
           EXIT.
      /
      *--------------------
       4000-PROCESS-CREATE.
      *--------------------

558021     MOVE SPACES                TO L0093-ACCT-DESC-TXT.

           MOVE MIR-ACCT-BASE-ID      TO WAC-ACCT-BASE-ID.
557658*    MOVE MIR-ACCT-YR                   TO WAC-ACCT-YR-CD.
557658     IF MIR-ACCT-YR = SPACES
557658        MOVE '0000'             TO WS-WAC-ACCT-YR
557658     ELSE
557658        MOVE MIR-ACCT-YR        TO WS-WAC-ACCT-YR
557658     END-IF.
557658     MOVE WS-WAC-ACCT-YR-N      TO WAC-ACCT-YR.
010418     MOVE MIR-SBSDRY-CO-ID      TO WAC-SBSDRY-CO-ID.
           MOVE MIR-ACCT-CRCY-CD      TO WAC-ACCT-CRCY-CD.
           MOVE MIR-BR-OR-DEPT-ID     TO WAC-BR-OR-DEPT-ID.
014591     MOVE MIR-PLAN-ID           TO WS-PLAN-ID.
014591*    MOVE MIR-RS                TO WS-PLAN-RS.
           MOVE WS-PLAN-ID            TO WAC-PLAN-ID.
           MOVE MIR-ACCT-ISS-LOC-CD   TO WAC-ACCT-ISS-LOC-CD.
           MOVE MIR-ACCT-CRNT-LOC-CD  TO WAC-ACCT-CRNT-LOC-CD.
010418*    MOVE MIR-LOB                    TO WAC-ACCT-LOB-DIVSN-CD.

           PERFORM  AC-1000-READ
               THRU AC-1000-READ-X.

           IF WAC-IO-OK
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
557658*        MOVE WAC-KEY                TO WGLOB-MSG-PARM (1)
557658         MOVE WAC-CO-ID         TO WS-WAC-CO-ID
557658         MOVE WAC-ACCT-BASE-ID  TO WS-WAC-ACCT-BASE-ID
557658         MOVE WS-WAC-ACCT-YR    TO WS-WAC-ACCT-YEAR
010418         MOVE WAC-SBSDRY-CO-ID  TO WS-WAC-SBSDRY-CO-ID
               MOVE WAC-ACCT-CRCY-CD  TO WS-WAC-ACCT-CRCY-CD
557658         MOVE WAC-PLAN-ID       TO WS-WAC-PLAN-ID
557658         MOVE WAC-BR-OR-DEPT-ID TO WS-WAC-BR-OR-DEPT-ID
557658         MOVE WAC-ACCT-ISS-LOC-CD
                                      TO WS-WAC-ACCT-ISS-LOC-CD
557658         MOVE WAC-ACCT-CRNT-LOC-CD
                                      TO WS-WAC-ACCT-CRNT-LOC-CD
010418*        MOVE WAC-ACCT-LOB-DIVSN-CD TO WS-WAC-ACCT-LOB-DIVSN-CD
557658         MOVE WS-WAC-KEY        TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.
           PERFORM  4200-CREATE-EDITS
               THRU 4200-CREATE-EDITS-X.

           IF FAIL-EDIT
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           MOVE MIR-ACCT-BASE-ID      TO WAC-ACCT-BASE-ID.
557658*    MOVE MIR-ACCT-YR                   TO WAC-ACCT-YR-CD.
557658     IF MIR-ACCT-YR = SPACES
557658        MOVE '0000'             TO WS-WAC-ACCT-YR
557658     ELSE
557658        MOVE MIR-ACCT-YR        TO WS-WAC-ACCT-YR
557658     END-IF.
557658     MOVE WS-WAC-ACCT-YR-N      TO WAC-ACCT-YR.
010418     MOVE MIR-SBSDRY-CO-ID      TO WAC-SBSDRY-CO-ID.
           MOVE MIR-ACCT-CRCY-CD      TO WAC-ACCT-CRCY-CD.
           MOVE MIR-BR-OR-DEPT-ID     TO WAC-BR-OR-DEPT-ID.
014591     MOVE MIR-PLAN-ID           TO WS-PLAN-ID.
014591*    MOVE MIR-RS                TO WS-PLAN-RS.
           MOVE WS-PLAN-ID            TO WAC-PLAN-ID.
           MOVE MIR-ACCT-ISS-LOC-CD   TO WAC-ACCT-ISS-LOC-CD.
           MOVE MIR-ACCT-CRNT-LOC-CD  TO WAC-ACCT-CRNT-LOC-CD.
010418*    MOVE MIR-LOB                    TO WAC-ACCT-LOB-DIVSN-CD.

           PERFORM  AC-1000-CREATE
               THRU AC-1000-CREATE-X.

558021*    PERFORM  ADES-1000-INIT-ACNT-DESCRIPT
558021*        THRU ADES-1000-INIT-ACNT-DESCRIPT-X.
558021     PERFORM  ACTC-1000-INIT-ACCT-TYP-CD
558021         THRU ACTC-1000-INIT-ACCT-TYP-CD-X.

           PERFORM  AC-1000-WRITE
               THRU AC-1000-WRITE-X.

014221     PERFORM  AC-1000-READ-TWRK-TS
014221         THRU AC-1000-READ-TWRK-TS-X.

558021     PERFORM  0093-0000-INIT-PARM-INFO
558021         THRU 0093-0000-INIT-PARM-INFO-X.
558021     MOVE WAC-ACCT-BASE-ID      TO  L0093-ACCT-DESC-ID.
558021     MOVE SPACES                TO  L0093-ACCT-DESC-REASN-CD.
558021     PERFORM  0093-1000-RETRIEVE-ACCT-INFO
558021         THRU 0093-1000-RETRIEVE-ACCT-INFO-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *------------------
       4200-CREATE-EDITS.
      *------------------
      *
      * VALIDATE ACNT KEY
      *

           PERFORM  AKEY-1000-CHECK-ACNT-KEY
               THRU AKEY-1000-CHECK-ACNT-KEY-X.
           IF  TAKEY-RTRN-ERROR
               MOVE 'Y'               TO WS-FAIL-EDIT
           END-IF.

      ***PLAN AND RATE SCALE HAVE BEEN ADDED
      ***FOLLOWING EDITS ARE NEW
           MOVE MIR-ACCT-BASE-ID      TO WS-ACNT.
014591     MOVE MIR-PLAN-ID           TO WS-PLAN-ID.
014591*    MOVE MIR-RS                TO WS-PLAN-RS.
           IF  WS-ACNT-12 = 'FX'
           AND WS-PLAN-ID = SPACES
               MOVE 'CS00910014'      TO WGLOB-MSG-REF-INFO
               MOVE 'Y'               TO WS-FAIL-EDIT
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4200-CREATE-EDITS-X
           END-IF.

           IF  WS-ACNT-12 = 'FX'
           AND WS-PLAN-ID > SPACES
014591*        MOVE MIR-PLAN-ID       TO WPH-PLAN-ID-BASE
014591         MOVE MIR-PLAN-ID       TO WPH-PLAN-ID
014591*        MOVE MIR-RS            TO WPH-PLAN-ID-RS
               PERFORM  PH-1000-READ
                   THRU PH-1000-READ-X
               IF WPH-IO-OK
                   CONTINUE
               ELSE
                   MOVE 'CS00910015'  TO WGLOB-MSG-REF-INFO
                   MOVE 'Y'           TO WS-FAIL-EDIT
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO  TO  4200-CREATE-EDITS-X
               END-IF
           END-IF.

           IF  WS-ACNT-12 NOT = 'FX'
           AND WS-PLAN-ID > SPACES
               MOVE 'CS00910016'      TO WGLOB-MSG-REF-INFO
               MOVE 'Y'               TO WS-FAIL-EDIT
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4200-CREATE-EDITS-X
           END-IF.

       4200-CREATE-EDITS-X.
           EXIT.
      /
      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------

           MOVE MIR-ACCT-BASE-ID      TO WAC-ACCT-BASE-ID.
557658*    MOVE MIR-ACCT-YR           TO WAC-ACCT-YR-CD.
557658     IF MIR-ACCT-YR = SPACES
557658        MOVE '0000'             TO WS-WAC-ACCT-YR
557658     ELSE
557658        MOVE MIR-ACCT-YR        TO WS-WAC-ACCT-YR
557658     END-IF.
557658     MOVE WS-WAC-ACCT-YR-N      TO WAC-ACCT-YR.
010418     MOVE MIR-SBSDRY-CO-ID      TO WAC-SBSDRY-CO-ID.
           MOVE MIR-ACCT-CRCY-CD      TO WAC-ACCT-CRCY-CD.
014591     MOVE MIR-PLAN-ID           TO WS-PLAN-ID.
014591*    MOVE MIR-RS                TO WS-PLAN-RS.
           MOVE WS-PLAN-ID            TO WAC-PLAN-ID.
           MOVE MIR-BR-OR-DEPT-ID     TO WAC-BR-OR-DEPT-ID.
           MOVE MIR-ACCT-ISS-LOC-CD   TO WAC-ACCT-ISS-LOC-CD.
           MOVE MIR-ACCT-CRNT-LOC-CD  TO WAC-ACCT-CRNT-LOC-CD.
010418*    MOVE MIR-LOB               TO WAC-ACCT-LOB-DIVSN-CD.

014221*    PERFORM  AC-1000-READ-FOR-UPDATE
014221*        THRU AC-1000-READ-FOR-UPDATE-X.

014221     PERFORM  AC-2000-UPDATE-TWRK-TS
014221         THRU AC-2000-UPDATE-TWRK-TS-X.

           IF WAC-IO-NOT-FOUND
               PERFORM  AC-3000-UNLOCK
                   THRU AC-3000-UNLOCK-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               MOVE WAC-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'AC'                         TO WGLOB-MSG-PARM (01)
019708*        MOVE WAC-KEY                      TO WGLOB-MSG-PARM (02)
019708         MOVE WAC-CO-ID         TO WS-WAC-CO-ID
019708         MOVE WAC-ACCT-BASE-ID  TO WS-WAC-ACCT-BASE-ID
019708         MOVE WAC-ACCT-YR       TO WS-WAC-ACCT-YEAR
019708         MOVE WAC-SBSDRY-CO-ID  TO WS-WAC-SBSDRY-CO-ID
019708         MOVE WAC-ACCT-CRCY-CD  TO WS-WAC-ACCT-CRCY-CD
019708         MOVE WAC-PLAN-ID       TO WS-WAC-PLAN-ID
019708         MOVE WAC-BR-OR-DEPT-ID TO WS-WAC-BR-OR-DEPT-ID
019708         MOVE WAC-ACCT-ISS-LOC-CD
019708                                TO WS-WAC-ACCT-ISS-LOC-CD
019708         MOVE WAC-ACCT-CRNT-LOC-CD
019708                                TO WS-WAC-ACCT-CRNT-LOC-CD
019708         MOVE WS-WAC-KEY        TO WGLOB-MSG-PARM (02)

014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  5230-MAINTAIN-EDITS
               THRU 5230-MAINTAIN-EDITS-X.

           IF FAIL-EDIT
               CONTINUE
           ELSE
               PERFORM  5240-CROSS-EDITS
                   THRU 5240-CROSS-EDITS-X
           END-IF.

           PERFORM  AC-2000-REWRITE
              THRU  AC-2000-REWRITE-X.

014221     PERFORM  AC-1000-READ-TWRK-TS
014221         THRU AC-1000-READ-TWRK-TS-X.

           IF FAIL-EDIT
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *--------------------
       5230-MAINTAIN-EDITS.
      *--------------------
      *
      * SINCE ALL FIELDS ARE GOING TO BE EDITED FOR THE GUI ENVIRONMENT
      * THE SCREEN FIELDS IN BLANK SHOULD BE FILED WITH WHAT WAS IN THE
      * FILE.
      *
           IF MIR-ACCT-DESC-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-ACCT-DESC-TXT
           ELSE
               IF MIR-ACCT-DESC-TXT  = SPACES
558021*          MOVE RAC-ACCT-DESC-TXT  TO MIR-ACCT-DESC-TXT
558021           PERFORM  0093-0000-INIT-PARM-INFO
558021               THRU 0093-0000-INIT-PARM-INFO-X
558021           MOVE MIR-ACCT-BASE-ID   TO  L0093-ACCT-DESC-ID
558021           MOVE SPACES          TO  L0093-ACCT-DESC-REASN-CD
558021           PERFORM  0093-1000-RETRIEVE-ACCT-INFO
558021               THRU 0093-1000-RETRIEVE-ACCT-INFO-X
558021           MOVE L0093-ACCT-DESC-TXT
558021                                TO MIR-ACCT-DESC-TXT
               END-IF
           END-IF.

011970*    IF MIR-ACCT-MTHLY-RPT-IND = SPACES
011970*       MOVE RAC-ACCT-MTHLY-RPT-IND
011970*                               TO MIR-ACCT-MTHLY-RPT-IND
011970*    END-IF.

           IF MIR-ACCT-TYP-CD     = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-ACCT-TYP-CD
           ELSE
               IF MIR-ACCT-TYP-CD = SPACES
                   MOVE RAC-ACCT-TYP-CD
                                      TO MIR-ACCT-TYP-CD
               END-IF
           END-IF.

           IF MIR-ACCT-SUB-TYP-CD = SPACES
              MOVE RAC-ACCT-SUB-TYP-CD            TO MIR-ACCT-SUB-TYP-CD
           END-IF.

           IF MIR-MEMO-BDGT-RPT-AMT      = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE ZEROS                  TO EDIT-2
008455*        MOVE EDIT-2                 TO MIR-MEMO-BDGT-RPT-AMT
020874*        MOVE ZEROS             TO L0290-INPUT-NUMBER
020874         MOVE ZEROS             TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-MEMO-BDGT-RPT-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-MEMO-BDGT-RPT-AMT
           ELSE
               IF MIR-MEMO-BDGT-RPT-AMT  = SPACES
008455*            MOVE RAC-MEMO-BDGT-RPT-AMT TO EDIT-2
008455*            MOVE EDIT-2                TO MIR-MEMO-BDGT-RPT-AMT
020874*            COMPUTE L0290-INPUT-NUMBER
020874*                  = RAC-MEMO-BDGT-RPT-AMT * 100
020874             MOVE RAC-MEMO-BDGT-RPT-AMT TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-MEMO-BDGT-RPT-AMT
                                      TO L0290-MAX-OUT-LEN
008455             SET  L0290-SIGN-DISPLAY    TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-MEMO-BDGT-RPT-AMT
               END-IF
           END-IF.

           IF MIR-ACCT-CTL-IND = SPACES
              MOVE RAC-ACCT-CTL-IND   TO MIR-ACCT-CTL-IND
           END-IF.

           IF MIR-ENTR-IMPCT-CD = SPACES
              MOVE RAC-ENTR-IMPCT-CD  TO MIR-ENTR-IMPCT-CD
           END-IF.

           IF MIR-DV-ACCT-YTD-AMT      = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE ZEROS                  TO EDIT-1
008455*        MOVE EDIT-1                 TO MIR-DV-ACCT-YTD-AMT
020874*        MOVE ZEROS             TO L0290-INPUT-NUMBER
020874         MOVE ZEROS             TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-ACCT-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-DV-ACCT-YTD-AMT
           ELSE
               IF MIR-DV-ACCT-YTD-AMT  = SPACES
                   PERFORM  7000-COMPUTE-CURRENT-BALANCE
                       THRU 7000-COMPUTE-CURRENT-BALANCE-X
008455*            MOVE WS-CURRENT-BALANCE   TO EDIT-1
008455*            MOVE EDIT-1               TO MIR-DV-ACCT-YTD-AMT
020874*            COMPUTE L0290-INPUT-NUMBER = WS-CURRENT-BALANCE * 100
020874             MOVE WS-CURRENT-BALANCE   TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-DV-ACCT-YTD-AMT
                                      TO L0290-MAX-OUT-LEN
008455             SET  L0290-SIGN-DISPLAY   TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-DV-ACCT-YTD-AMT
               END-IF
           END-IF.

           IF MIR-ACCT-BDGT-TYP-CD = SPACES
              MOVE RAC-ACCT-BDGT-TYP-CD
                                      TO MIR-ACCT-BDGT-TYP-CD
           END-IF.

           IF MIR-ACCT-TOT-BDGT-AMT      = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE ZEROS                  TO EDIT-2
008455*        MOVE EDIT-2                 TO MIR-ACCT-TOT-BDGT-AMT
020874*        MOVE ZEROS             TO L0290-INPUT-NUMBER
020874         MOVE ZEROS             TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-ACCT-TOT-BDGT-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-ACCT-TOT-BDGT-AMT
           END-IF.

           PERFORM
               VARYING WS-SUB
               FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-MONTH
               IF MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
                                        = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS      TO EDIT-2
008455*            MOVE EDIT-2     TO MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455             SET  L0290-SIGN-DISPLAY TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                  TO MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
               ELSE
                   IF MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB) = SPACES
008455*                MOVE RAC-MO-BDGT-AMT-PCT (WS-SUB) TO EDIT-2
008455*                MOVE EDIT-2 TO MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
020874*                COMPUTE L0290-INPUT-NUMBER
020874*                      = RAC-MO-BDGT-AMT-PCT (WS-SUB) * 100
020874                 MOVE RAC-MO-BDGT-AMT-PCT (WS-SUB) 
020874                                TO L0290-INPUT-V02
008455                 MOVE 2         TO L0290-PRECISION
008455                 MOVE LENGTH OF MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455                 SET  L0290-SIGN-DISPLAY TO TRUE
020874*                PERFORM 0290-1000-NUMERIC-FORMAT
020874*                   THRU 0290-1000-NUMERIC-FORMAT-X
020874                 PERFORM 0290-2000-FORMAT-FOR-MIR
020874                    THRU 0290-2000-FORMAT-FOR-MIR-X
008455                 MOVE L0290-OUTPUT-DATA
                                  TO MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
                   END-IF
               END-IF
           END-PERFORM.

016255     PERFORM
016255         VARYING WS-SUB
016255         FROM 1 BY 1
016255         UNTIL WS-SUB > WS-MAX-MONTH
016255         IF MIR-DV-ACCT-MO-BAL-AMT-T (WS-SUB)
016255                                  = EBLCH-BLANK-FIELD-CHAR
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
016255             MOVE 2             TO L0290-PRECISION
016255             MOVE LENGTH OF MIR-DV-ACCT-MO-BAL-AMT-T (WS-SUB)
016255                                TO L0290-MAX-OUT-LEN
016255             SET  L0290-SIGN-DISPLAY TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
016255             MOVE L0290-OUTPUT-DATA
016255                            TO MIR-DV-ACCT-MO-BAL-AMT-T (WS-SUB)
016255         ELSE
016255             IF MIR-DV-ACCT-MO-BAL-AMT-T (WS-SUB) = SPACES
020874*                COMPUTE L0290-INPUT-NUMBER
020874*                      = RAC-ACCT-MO-BAL-AMT (WS-SUB) * 100
020874                 MOVE RAC-ACCT-MO-BAL-AMT (WS-SUB) 
020874                                TO L0290-INPUT-V02
016255                 MOVE 2         TO L0290-PRECISION
016255                 MOVE LENGTH OF MIR-DV-ACCT-MO-BAL-AMT-T (WS-SUB)
016255                                TO L0290-MAX-OUT-LEN
016255                 SET  L0290-SIGN-DISPLAY TO TRUE
020874*                PERFORM 0290-1000-NUMERIC-FORMAT
020874*                   THRU 0290-1000-NUMERIC-FORMAT-X
020874                 PERFORM 0290-2000-FORMAT-FOR-MIR
020874                    THRU 0290-2000-FORMAT-FOR-MIR-X
016255                 MOVE L0290-OUTPUT-DATA
016255                            TO MIR-DV-ACCT-MO-BAL-AMT-T (WS-SUB)
016255             END-IF
016255         END-IF
016255     END-PERFORM.

558021*    MOVE MIR-ACCT-DESC-TXT    TO RAC-ACCT-DESC-TXT.
011970*    IF MIR-ACCT-MTHLY-RPT-IND = 'Y'
011970*    OR MIR-ACCT-MTHLY-RPT-IND = 'N'
011970*        MOVE MIR-ACCT-MTHLY-RPT-IND
011970*                               TO RAC-ACCT-MTHLY-RPT-IND
011970*    ELSE
011970*        MOVE 'CS00910001'      TO WGLOB-MSG-REF-INFO
011970*        MOVE 'Y'               TO WS-FAIL-EDIT
011970*        PERFORM  0260-1000-GENERATE-MESSAGE
011970*            THRU 0260-1000-GENERATE-MESSAGE-X
011970*    END-IF.

           MOVE MIR-ACCT-TYP-CD       TO WS-ACTYP-VALID.
           IF ACTYP-VALID
               MOVE MIR-ACCT-TYP-CD   TO RAC-ACCT-TYP-CD
           ELSE
               MOVE 'Y'               TO WS-FAIL-EDIT
               MOVE 'CS00910002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-ACCT-SUB-TYP-CD   TO WS-BCCLR-VALID.
           IF BCCLR-VALID
               MOVE MIR-ACCT-SUB-TYP-CD
                                      TO RAC-ACCT-SUB-TYP-CD
           ELSE
               MOVE 'Y'               TO WS-FAIL-EDIT
               MOVE 'CS00910005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-MEMO-BDGT-RPT-AMT TO L0280-INPUT-DATA.
           MOVE 'Y'                   TO L0280-SIGN-IND.
008455*    MOVE  09                        TO L0280-LENGTH.
           MOVE  2                    TO L0280-PRECISION.
           MOVE 'Y'                   TO L0280-SPACE-PERMITTED-IND.
008455*    MOVE  13                        TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-MEMO-BDGT-RPT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               COMPUTE RAC-MEMO-BDGT-RPT-AMT = L0280-OUTPUT-DOLLAR
008455*        MOVE RAC-MEMO-BDGT-RPT-AMT  TO EDIT-2
008455*        MOVE EDIT-2                 TO MIR-MEMO-BDGT-RPT-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-MEMO-BDGT-RPT-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-MEMO-BDGT-RPT-AMT
           ELSE
               MOVE 'Y'               TO WS-FAIL-EDIT
               MOVE 'CS00910017'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

557660     IF MIR-ACCT-CTL-IND = 'Y'
           OR MIR-ACCT-CTL-IND = 'N'
               MOVE MIR-ACCT-CTL-IND  TO RAC-ACCT-CTL-IND
           ELSE
               MOVE 'CS00910006'      TO WGLOB-MSG-REF-INFO
               MOVE 'Y'               TO WS-FAIL-EDIT
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-ENTR-IMPCT-CD     TO WS-PAUPDT-VALID.
           IF PAUPDT-VALID
               MOVE MIR-ENTR-IMPCT-CD TO RAC-ENTR-IMPCT-CD
           ELSE
               MOVE 'CS00910009'      TO WGLOB-MSG-REF-INFO
               MOVE 'Y'               TO WS-FAIL-EDIT
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

557660     IF MIR-ACCT-BDGT-TYP-CD = 'A'
           OR MIR-ACCT-BDGT-TYP-CD = 'P'
           OR MIR-ACCT-BDGT-TYP-CD = 'E'
               MOVE MIR-ACCT-BDGT-TYP-CD
                                      TO RAC-ACCT-BDGT-TYP-CD
           ELSE
               MOVE 'CS00910011'      TO WGLOB-MSG-REF-INFO
               MOVE 'Y'               TO WS-FAIL-EDIT
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF MIR-ACCT-TOT-BDGT-AMT > SPACES
008455     AND MIR-ACCT-BDGT-TYP-CD NOT = 'A'
               MOVE MIR-ACCT-TOT-BDGT-AMT
                                      TO L0280-INPUT-DATA
               MOVE 'Y'               TO L0280-SIGN-IND
008455*        MOVE  09                    TO L0280-LENGTH
               MOVE  2                TO L0280-PRECISION
               MOVE 'Y'               TO L0280-SPACE-PERMITTED-IND
008455*        MOVE  13                    TO L0280-INPUT-SIZE
008455         MOVE LENGTH OF MIR-ACCT-TOT-BDGT-AMT
                                      TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   COMPUTE RAC-ACCT-TOT-BDGT-AMT = L0280-OUTPUT-DOLLAR
008455*            MOVE RAC-ACCT-TOT-BDGT-AMT TO EDIT-2
008455*            MOVE EDIT-2                TO MIR-ACCT-TOT-BDGT-AMT
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-ACCT-TOT-BDGT-AMT
                                      TO L0290-MAX-OUT-LEN
008455             SET  L0290-SIGN-DISPLAY TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-ACCT-TOT-BDGT-AMT
               ELSE
008455*            MOVE 'Y'                TO WS-FAIL-EDIT
008455             MOVE 'T'           TO WS-FAIL-EDIT
                   MOVE 'CS00910018'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           ELSE
008455*        MOVE RAC-ACCT-TOT-BDGT-AMT  TO EDIT-2
008455*        MOVE EDIT-2                 TO MIR-ACCT-TOT-BDGT-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RAC-ACCT-TOT-BDGT-AMT * 100
020874         MOVE RAC-ACCT-TOT-BDGT-AMT  TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-ACCT-TOT-BDGT-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-ACCT-TOT-BDGT-AMT
           END-IF.

           IF MIR-ACCT-BDGT-TYP-CD = 'E'
               DIVIDE RAC-ACCT-TOT-BDGT-AMT BY 12
                      GIVING RAC-MO-BDGT-AMT-PCT (01)
008455*        MOVE RAC-MO-BDGT-AMT-PCT (01) TO EDIT-2
008455*        MOVE EDIT-2            TO MIR-DV-MO-BDGT-AMT-PCT-T (01)
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = RAC-MO-BDGT-AMT-PCT (01) * 100
020874         MOVE RAC-MO-BDGT-AMT-PCT (01)  TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-MO-BDGT-AMT-PCT-T (01)
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-DV-MO-BDGT-AMT-PCT-T (01)
               PERFORM
                   VARYING WS-SUB FROM 2 BY 1
                   UNTIL WS-SUB > 11
                   MOVE RAC-MO-BDGT-AMT-PCT (01)
                                      TO RAC-MO-BDGT-AMT-PCT(WS-SUB)
008455*            MOVE RAC-MO-BDGT-AMT-PCT (01) TO EDIT-2
008455*            MOVE EDIT-2    TO MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
008455             MOVE L0290-OUTPUT-DATA
                                 TO MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
               END-PERFORM
               COMPUTE RAC-MO-BDGT-AMT-PCT (12) = RAC-ACCT-TOT-BDGT-AMT
                    - (RAC-MO-BDGT-AMT-PCT (01) * 11)
008455*        MOVE RAC-MO-BDGT-AMT-PCT (12) TO EDIT-2
008455*        MOVE EDIT-2           TO MIR-DV-MO-BDGT-AMT-PCT-T (12)
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = RAC-MO-BDGT-AMT-PCT (12) * 100
020874         MOVE RAC-MO-BDGT-AMT-PCT (12)  TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-MO-BDGT-AMT-PCT-T (12)
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY        TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-DV-MO-BDGT-AMT-PCT-T (12)
               GO  TO  5230-MAINTAIN-EDITS-X
           END-IF.

           PERFORM
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-MONTH
               MOVE MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
                                      TO L0280-INPUT-DATA
               MOVE 'Y'               TO L0280-SIGN-IND
008455*        MOVE  09                    TO L0280-LENGTH
               MOVE  2                TO L0280-PRECISION
               MOVE 'Y'               TO L0280-SPACE-PERMITTED-IND
008455*        MOVE  13                    TO L0280-INPUT-SIZE
008455         MOVE LENGTH OF MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
008455                                TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   COMPUTE RAC-MO-BDGT-AMT-PCT (WS-SUB)
                                          = L0280-OUTPUT-DOLLAR
008455*            MOVE RAC-MO-BDGT-AMT-PCT (WS-SUB) TO EDIT-2
008455*            MOVE EDIT-2    TO MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455             SET  L0290-SIGN-DISPLAY TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                  TO MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
               ELSE
                   MOVE 'Y'           TO WS-FAIL-EDIT
                   MOVE 'CS00910019'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-PERFORM.

       5230-MAINTAIN-EDITS-X.
           EXIT.
      /
       5240-CROSS-EDITS.

           MOVE ZEROES                TO WS-BUDGET-TOTAL.

           PERFORM
               VARYING WS-SUB FROM  1 BY 1
               UNTIL WS-SUB > WS-MAX-MONTH

               COMPUTE WS-BUDGET-TOTAL = WS-BUDGET-TOTAL
                                       + RAC-MO-BDGT-AMT-PCT (WS-SUB)
           END-PERFORM.

           IF RAC-ACCT-BDGT-TYP-CD = 'A'
020874*        COMPUTE L0290-INPUT-NUMBER = WS-BUDGET-TOTAL * 100
020874         MOVE WS-BUDGET-TOTAL   TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-ACCT-TOT-BDGT-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-ACCT-TOT-BDGT-AMT
               IF RAC-ACCT-TOT-BDGT-AMT NOT = WS-BUDGET-TOTAL
                   MOVE WS-BUDGET-TOTAL
                                      TO RAC-ACCT-TOT-BDGT-AMT
008455*            MOVE WS-BUDGET-TOTAL    TO EDIT-2
008455*            MOVE EDIT-2             TO MIR-ACCT-TOT-BDGT-AMT
                   MOVE 'CS00910007'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
008455*        ELSE
008455*            MOVE WS-BUDGET-TOTAL    TO RAC-ACCT-TOT-BDGT-AMT
008455*            MOVE WS-BUDGET-TOTAL    TO EDIT-2
008455*            MOVE EDIT-2             TO MIR-ACCT-TOT-BDGT-AMT
               END-IF
           END-IF.

           IF RAC-ACCT-BDGT-TYP-CD = 'P'
              IF WS-BUDGET-TOTAL NOT = 100.00
                 MOVE 'Y'             TO WS-FAIL-EDIT
                 MOVE 'CS00910008'    TO WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU  0260-1000-GENERATE-MESSAGE-X
              END-IF
           END-IF.

008455     IF FAIL-EDIT-BTOT
008455         MOVE 'Y'               TO WS-FAIL-EDIT
008455     END-IF.
008455

       5240-CROSS-EDITS-X.
           EXIT.
      /
      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

           MOVE MIR-ACCT-BASE-ID      TO WAC-ACCT-BASE-ID.
557658*    MOVE MIR-ACCT-YR                   TO WAC-ACCT-YR-CD.
557658     IF MIR-ACCT-YR = SPACES
557658        MOVE '0000'             TO WS-WAC-ACCT-YR
557658     ELSE
557658        MOVE MIR-ACCT-YR        TO WS-WAC-ACCT-YR
557658     END-IF.
557658     MOVE WS-WAC-ACCT-YR-N      TO WAC-ACCT-YR.
010418     MOVE MIR-SBSDRY-CO-ID      TO WAC-SBSDRY-CO-ID.
           MOVE MIR-ACCT-CRCY-CD      TO WAC-ACCT-CRCY-CD.
014591     MOVE MIR-PLAN-ID           TO WS-PLAN-ID.
014591*    MOVE MIR-RS                TO WS-PLAN-RS.
           MOVE WS-PLAN-ID            TO WAC-PLAN-ID.
           MOVE MIR-BR-OR-DEPT-ID     TO WAC-BR-OR-DEPT-ID.
           MOVE MIR-ACCT-ISS-LOC-CD   TO WAC-ACCT-ISS-LOC-CD.
           MOVE MIR-ACCT-CRNT-LOC-CD  TO WAC-ACCT-CRNT-LOC-CD.
010418*    MOVE MIR-LOB                    TO WAC-ACCT-LOB-DIVSN-CD.

           PERFORM  AC-1000-READ
               THRU AC-1000-READ-X.

           IF WAC-IO-NOT-FOUND
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
010357         MOVE WAC-CO-ID         TO WS-WAC-CO-ID
010357         MOVE WAC-ACCT-BASE-ID  TO WS-WAC-ACCT-BASE-ID
010357         MOVE WS-WAC-ACCT-YR    TO WS-WAC-ACCT-YEAR
010418         MOVE WAC-SBSDRY-CO-ID  TO WS-WAC-SBSDRY-CO-ID
010357         MOVE WAC-ACCT-CRCY-CD  TO WS-WAC-ACCT-CRCY-CD
010357         MOVE WAC-PLAN-ID       TO WS-WAC-PLAN-ID
010357         MOVE WAC-BR-OR-DEPT-ID TO WS-WAC-BR-OR-DEPT-ID
010357         MOVE WAC-ACCT-ISS-LOC-CD
                                      TO WS-WAC-ACCT-ISS-LOC-CD
010357         MOVE WAC-ACCT-CRNT-LOC-CD
                                      TO WS-WAC-ACCT-CRNT-LOC-CD
010418*        MOVE WAC-ACCT-LOB-DIVSN-CD TO WS-WAC-ACCT-LOB-DIVSN-CD
010357         MOVE WS-WAC-KEY        TO WGLOB-MSG-PARM (1)
010357*         MOVE WAC-KEY                TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

           MOVE 'N'                   TO WS-IF-BALANCE-PRESENT.
558021     PERFORM  0093-0000-INIT-PARM-INFO
558021         THRU 0093-0000-INIT-PARM-INFO-X.
558021     MOVE MIR-ACCT-BASE-ID      TO  L0093-ACCT-DESC-ID.
558021     MOVE SPACES                TO  L0093-ACCT-DESC-REASN-CD.
558021     PERFORM  0093-1000-RETRIEVE-ACCT-INFO
558021         THRU 0093-1000-RETRIEVE-ACCT-INFO-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           IF WS-BALANCE-PRESENT
           OR RAC-ACCT-BEG-BAL-AMT  NOT EQUAL ZEROS
               MOVE 'CS00910004'      TO WGLOB-MSG-REF-INFO
               MOVE 'Y'               TO WS-FAIL-EDIT
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

           MOVE MIR-ACCT-BASE-ID      TO WAC-ACCT-BASE-ID.
557658*    MOVE MIR-ACCT-YR                   TO WAC-ACCT-YR-CD.
557658     IF MIR-ACCT-YR = SPACES
557658        MOVE '0000'             TO WS-WAC-ACCT-YR
557658     ELSE
557658        MOVE MIR-ACCT-YR        TO WS-WAC-ACCT-YR
557658     END-IF.
557658     MOVE WS-WAC-ACCT-YR-N      TO WAC-ACCT-YR.
010418     MOVE MIR-SBSDRY-CO-ID      TO WAC-SBSDRY-CO-ID
           MOVE MIR-ACCT-CRCY-CD      TO WAC-ACCT-CRCY-CD.
014591     MOVE MIR-PLAN-ID           TO WS-PLAN-ID.
014591*    MOVE MIR-RS                TO WS-PLAN-RS.
           MOVE WS-PLAN-ID            TO WAC-PLAN-ID.
           MOVE MIR-BR-OR-DEPT-ID     TO WAC-BR-OR-DEPT-ID.
           MOVE MIR-ACCT-ISS-LOC-CD   TO WAC-ACCT-ISS-LOC-CD.
           MOVE MIR-ACCT-CRNT-LOC-CD  TO WAC-ACCT-CRNT-LOC-CD.
010418*    MOVE MIR-LOB                    TO WAC-ACCT-LOB-DIVSN-CD.

014221*    PERFORM  AC-1000-READ-FOR-UPDATE
014221*        THRU AC-1000-READ-FOR-UPDATE-X.

014221     PERFORM  AC-2000-UPDATE-TWRK-TS
014221         THRU AC-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'AC'                         TO WGLOB-MSG-PARM (01)
019708*        MOVE WAC-KEY                      TO WGLOB-MSG-PARM (02)
019708         MOVE WAC-CO-ID         TO WS-WAC-CO-ID
019708         MOVE WAC-ACCT-BASE-ID  TO WS-WAC-ACCT-BASE-ID
019708         MOVE WAC-ACCT-YR       TO WS-WAC-ACCT-YEAR
019708         MOVE WAC-SBSDRY-CO-ID  TO WS-WAC-SBSDRY-CO-ID
019708         MOVE WAC-ACCT-CRCY-CD  TO WS-WAC-ACCT-CRCY-CD
019708         MOVE WAC-PLAN-ID       TO WS-WAC-PLAN-ID
019708         MOVE WAC-BR-OR-DEPT-ID TO WS-WAC-BR-OR-DEPT-ID
019708         MOVE WAC-ACCT-ISS-LOC-CD
019708                                TO WS-WAC-ACCT-ISS-LOC-CD
019708         MOVE WAC-ACCT-CRNT-LOC-CD
019708                                TO WS-WAC-ACCT-CRNT-LOC-CD
019708         MOVE WS-WAC-KEY        TO WGLOB-MSG-PARM (02)

014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF WAC-IO-OK
               PERFORM  AC-1000-DELETE
                   THRU AC-1000-DELETE-X
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE WAC-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *-----------------------------
       7000-COMPUTE-CURRENT-BALANCE.
      *-----------------------------

           MOVE RAC-ACCT-BEG-BAL-AMT  TO WS-CURRENT-BALANCE.

           PERFORM
               VARYING WS-SUB1 FROM 1 BY 1
               UNTIL   WS-SUB1 > WS-MAX-MONTH

               ADD RAC-ACCT-MO-BAL-AMT (WS-SUB1) TO WS-CURRENT-BALANCE

           END-PERFORM.

       7000-COMPUTE-CURRENT-BALANCE-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-ACCT-DESC-TXT.
011970*    MOVE SPACES                TO MIR-ACCT-MTHLY-RPT-IND.
           MOVE SPACES                TO MIR-ACCT-TYP-CD.
           MOVE SPACES                TO MIR-ACCT-SUB-TYP-CD.
           MOVE SPACES                TO MIR-MEMO-BDGT-RPT-AMT.
           MOVE SPACES                TO MIR-ACCT-CTL-IND.
           MOVE SPACES                TO MIR-ENTR-IMPCT-CD.
           MOVE SPACES                TO MIR-DV-ACCT-YTD-AMT.
           MOVE SPACES                TO MIR-ACCT-BDGT-TYP-CD.
008455*    MOVE ZEROS                      TO EDIT-1.
008455*    MOVE ZEROS                      TO EDIT-2.
008455*    MOVE EDIT-1                     TO MIR-ACCT-BEG-BAL-AMT.
008455*    MOVE EDIT-2                     TO MIR-ACCT-TOT-BDGT-AMT.
008455
020874*    MOVE ZEROS                 TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                 TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-ACCT-BEG-BAL-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY         TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-ACCT-BEG-BAL-AMT.
008455
020874*    MOVE ZEROS                 TO L0290-INPUT-NUMBER.
020874     MOVE ZEROS                 TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-ACCT-TOT-BDGT-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY         TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-ACCT-TOT-BDGT-AMT.
008455
           PERFORM
               VARYING WS-SUB
               FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-MONTH
008455*        MOVE EDIT-2         TO MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
008455*        MOVE EDIT-1         TO MIR-DV-ACCT-MO-BAL-AMT-T (WS-SUB)
008455         MOVE MIR-ACCT-TOT-BDGT-AMT
                                 TO MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
008455         MOVE MIR-ACCT-BEG-BAL-AMT
                                 TO MIR-DV-ACCT-MO-BAL-AMT-T (WS-SUB)
           END-PERFORM.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

558021*    MOVE RAC-ACCT-DESC-TXT          TO MIR-ACCT-DESC-TXT.
558021     MOVE L0093-ACCT-DESC-TXT   TO MIR-ACCT-DESC-TXT.
011970*    MOVE RAC-ACCT-MTHLY-RPT-IND        TO MIR-ACCT-MTHLY-RPT-IND.
           MOVE RAC-ACCT-TYP-CD       TO MIR-ACCT-TYP-CD.
           MOVE RAC-ACCT-SUB-TYP-CD   TO MIR-ACCT-SUB-TYP-CD.
008455*    MOVE RAC-MEMO-BDGT-RPT-AMT      TO EDIT-2.
008455*    MOVE EDIT-2                     TO MIR-MEMO-BDGT-RPT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAC-MEMO-BDGT-RPT-AMT * 100.
020874     MOVE RAC-MEMO-BDGT-RPT-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-MEMO-BDGT-RPT-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY         TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-MEMO-BDGT-RPT-AMT.
           MOVE RAC-ACCT-CTL-IND      TO MIR-ACCT-CTL-IND.
           MOVE RAC-ENTR-IMPCT-CD     TO MIR-ENTR-IMPCT-CD.
           PERFORM  7000-COMPUTE-CURRENT-BALANCE
               THRU 7000-COMPUTE-CURRENT-BALANCE-X.
008455*    MOVE WS-CURRENT-BALANCE         TO EDIT-1.
008455*    MOVE EDIT-1                     TO MIR-DV-ACCT-YTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WS-CURRENT-BALANCE * 100.
020874     MOVE WS-CURRENT-BALANCE    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-ACCT-YTD-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY         TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-ACCT-YTD-AMT.

           MOVE RAC-ACCT-BDGT-TYP-CD  TO MIR-ACCT-BDGT-TYP-CD.
008455*    MOVE RAC-ACCT-TOT-BDGT-AMT      TO EDIT-2.
008455*    MOVE EDIT-2                     TO MIR-ACCT-TOT-BDGT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAC-ACCT-TOT-BDGT-AMT * 100.
020874     MOVE RAC-ACCT-TOT-BDGT-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-ACCT-TOT-BDGT-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY         TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-ACCT-TOT-BDGT-AMT.
           PERFORM
               VARYING WS-SUB
               FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-MONTH
008455*        MOVE RAC-MO-BDGT-AMT-PCT (WS-SUB) TO EDIT-2
008455*        MOVE EDIT-2 TO MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = RAC-MO-BDGT-AMT-PCT (WS-SUB) * 100
020874         MOVE RAC-MO-BDGT-AMT-PCT (WS-SUB) TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
                                 TO MIR-DV-MO-BDGT-AMT-PCT-T (WS-SUB)
           END-PERFORM.

008455*    MOVE RAC-ACCT-BEG-BAL-AMT       TO EDIT-1.
008455*    MOVE EDIT-1                     TO MIR-ACCT-BEG-BAL-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAC-ACCT-BEG-BAL-AMT * 100.
020874     MOVE RAC-ACCT-BEG-BAL-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-ACCT-BEG-BAL-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY         TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-ACCT-BEG-BAL-AMT.
           PERFORM
               VARYING WS-SUB
               FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-MONTH
               IF RAC-ACCT-MO-BAL-AMT (WS-SUB) NOT = ZERO
                   MOVE 'Y'           TO WS-IF-BALANCE-PRESENT
               END-IF
008455*        MOVE RAC-ACCT-MO-BAL-AMT (WS-SUB) TO EDIT-1
008455*        MOVE EDIT-1   TO MIR-DV-ACCT-MO-BAL-AMT-T (WS-SUB)
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = RAC-ACCT-MO-BAL-AMT (WS-SUB) * 100
020874         MOVE RAC-ACCT-MO-BAL-AMT (WS-SUB) TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-ACCT-MO-BAL-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY     TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA
                                 TO MIR-DV-ACCT-MO-BAL-AMT-T (WS-SUB)
           END-PERFORM.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0093-0000-INIT-PARM-INFO
025970         THRU 0093-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE TACTC-FUND-ACCOUNT.
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970     MOVE SPACES            TO WWKDT-WORK-FIELDS.
025970     MOVE WWKDT-ZERO-DT     TO TAKEY-ACNT-PROCESS-DATE. 
025970     SET  MIR-RETRN-OK                  TO TRUE.
025970     SET WS-MAX-BROWSE-LINES-DEFAULT    TO TRUE.
025970     SET WS-MAX-MONTH-DEFAULT           TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT            TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ***PROCESSING COPYBOOKS
      /
558021*COPY CCPPADES.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
558021 COPY CCPPACTC.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY AC
014221                         '$VAR2' BY 'AC'.
      /
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
008455
008455 COPY XCPL0290.
008455 COPY XCPS0290.

558021 COPY CCPS0093.

      ***EDIT COPYBOOKS
      /
       COPY CCPEAKEY.
008455*COPY CCPECURR.
021930*COPY CCPNBRCH.
006002*COPY CCPECLOC.
006002*COPY CCPEILOC.
016203 COPY CCPECLOC.
016203 COPY CCPEILOC.
016537*COPY CCPEDVN.
008455/
008455 COPY XCPNCRCY.
      /
010418 COPY CCPNSCOM.
      /
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      /
018764*COPY CCCL0093.
018764 COPY CCPL0093.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPBAC.
      /
       COPY CCPNAC.
      /
       COPY CCPUAC.
      /
       COPY CCPAAC.
      /
       COPY CCPCAC.
      /
       COPY CCPXAC.
      /
       COPY CCPNEDIT.
      /
016537*COPY CCPZEDIT.
      /
       COPY CCPNPH.
016203*
016203*COPY XCPNCTLC.

      *****************************************************************
      **                 END OF PROGRAM CSOM0091                     **
      *****************************************************************
