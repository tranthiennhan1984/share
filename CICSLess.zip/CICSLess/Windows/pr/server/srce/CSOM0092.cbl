      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0092.


       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0092                                         **
      **  REMARKS:  PROCESS DRIVER FOR ACTD                          **
      **                                                             **
      **  DOMAIN :  AC                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      **  5.5       CREATED FOR ACCT DESC PROCESSING.                **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
012147**  5.6V      NEW REASON CODES FOR RETAINED COMM               **
014035**  5.6V      CLEAN-UP                                         **
013930**  5.6A      TERMINAL BONUS                                   **
013994**  5.6A      BONUS/DIVIDEDN VESTING                           **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0092'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.


       01  WS-PGM-WORK-AREA.
           05  WS-EDIT-CHECKS.
               10  WS-BUS-FCN-ID            PIC X(04).
                   88  WS-BUS-FCN-VALID     VALUE '1520' '1521'
                                                  '1522' '1523'
                                                  '1524'.
                   88  WS-BUS-FCN-RETRIEVE  VALUE '1520'.
                   88  WS-BUS-FCN-CREATE    VALUE '1521'.
                   88  WS-BUS-FCN-UPDATE    VALUE '1522'.
                   88  WS-BUS-FCN-DELETE    VALUE '1523'.
                   88  WS-BUS-FCN-LIST      VALUE '1524'.
025970*        10  WS-TWRK-KEY              PIC X(04) VALUE '1520'.
               10  WS-TOKENS                PIC X(01).
                   88  VALID-TOKENS         VALUE '1' '2' '3' '4'.
               10  WS-MESSAGE-SW            PIC X(01).
                   88  WS-VALID-MESSAGE     VALUE 'Y'.
                   88  WS-INVALID-MESSAGE   VALUE 'N'.
               10  WS-REASON-CODE           PIC X(08).
                   88  WS-VALID-REASON-CD   VALUE
012147                                           'AB RCOMM'
                                                 'ADM INC '
                                                 'AGT BAL '
                                                 'AGT ME  '
                                                 'ALLOC   '
                                                 'APL     '
                                                 'APL CAP '
                                                 'APL INT '
                                                 'AUTO    '
                                                 'BASIC   '
013994                                           'BON VST '
013994                                           'BONUS   '
                                                 'CASH    '
                                                 'CPAY    '
                                                 'CHGB    '
                                                 'CLM     '
                                                 'COMM EXP'
                                                 'COV     '
                                                 'COV CONV'
                                                 'COV REF '
                                                 'DEP     '
                                                 'DIV     '
                                                 'DIV CAP '
013994                                           'DIV VST '
                                                 'DOD     '
                                                 'DTH     '
                                                 'DTH GUAR'
                                                 'EQT     '
                                                 'EQT DUE '
                                                 'EQT REV '
                                                 'EQT SURR'
                                                 'ETI     '
                                                 'FEE     '
                                                 'FPA     '
                                                 'FPA REV '
                                                 'FPA SURR'
                                                 'FYC     '
                                                 'FYC COM '
                                                 'GL EXP  '
                                                 'IA      '
                                                 'INP     '
                                                 'INT     '
                                                 'INT EXP '
                                                 'LOAN    '
                                                 'LOAN CAP'
                                                 'LOAN INT'
                                                 'LOAN RED'
                                                 'LPV     '
                                                 'MAT     '
                                                 'ME CHQ  '
                                                 'NTU     '
                                                 'OVR     '
                                                 'OYT     '
                                                 'OYT CLM '
                                                 'PAYO    '
                                                 'PDF CAP '
                                                 'PEND    '
                                                 'POL     '
                                                 'POL AUTO'
                                                 'POL CONV'
                                                 'POL REPL'
                                                 'PREM    '
                                                 'PREM ADJ'
                                                 'PREM DSC'
                                                 'PREM DUE'
                                                 'PREM RED'
                                                 'PSUR    '
                                                 'PUA     '
                                                 'PUA SURR'
                                                 'RECAP   '
                                                 'REIN ADV'
                                                 'REIN CB '
                                                 'RPU     '
                                                 'RRIF    '
                                                 'SEG     '
                                                 'SEG UL  '
                                                 'SFF     '
                                                 'SM GUAR '
                                                 'SUR     '
                                                 'SURR    '
                                                 'SUS     '
013930                                           'TBDTH   '
013930                                           'TBMAT   '
013930                                           'TBSURR  '
                                                 'TRAN INC'
                                                 'TRI     '
                                                 'TRO     '
                                                 'UL COMM '
                                                 'WTHDRWL '
                                                 'WVR     '
                                                 '        '.

016548*    05  WS-SUB                       PIC S9(04) COMP.
016548     05  WS-SUB                       PIC S9(04) BINARY.
016548*    05  WS-MAX-LINES                 PIC S9(04) COMP
025970*    05  WS-MAX-LINES                 PIC S9(04) BINARY
025970*                                                VALUE +13.
           05  WS-PARAMETERS-USED           PIC X(01).
016548*    05  WS-MAX-MESSAGE-LENGTH        PIC S9(04) COMP
025970*    05  WS-MAX-MESSAGE-LENGTH        PIC S9(04) BINARY
025970*                                                VALUE +20.
           05  WS-DESC-ARRAY                PIC X(20).
           05  WS-DESC-ARRAY-R              REDEFINES WS-DESC-ARRAY.
               10  WS-SINGLE-CHAR           OCCURS 20 TIMES
                                            INDEXED BY CHAR-ARRAY
                                            PIC X(01).
                                            
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '1520'.
025970     05  WS-MAX-LINES                 PIC S9(04) BINARY.
025970         88  WS-MAX-LINES-DEFAULT     VALUE +13.
025970     05  WS-MAX-MESSAGE-LENGTH        PIC S9(04) BINARY.
025970         88  WS-MAX-MESSAGE-LENGTH-DEFAULT    VALUE +20.

      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
016537*COPY XCWL0280.
014221 COPY XCWL8090.
      /
       COPY XCWEBLCH.
      /
       COPY XCFWXTAB.
       COPY XCFRXTAB.
      /
       COPY CCFWACTD.
       COPY CCFRACTD.
      /
014035*COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0092.

      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM ABND-1000-HANDLE-ABEND
026070*       THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.



026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /

      *----------------------
       2000-PROCESS-REQUEST.
      *----------------------

025970*    MOVE MIR-BUS-FCN-ID        TO  WS-BUS-FCN-ID.
025970*    SET  MIR-RETRN-OK          TO  TRUE.

           IF  NOT WS-BUS-FCN-VALID
               SET MIR-RETRN-INVALD-RQST  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF WS-BUS-FCN-RETRIEVE
              PERFORM  3000-PROCESS-RETRIEVE
                  THRU 3000-PROCESS-RETRIEVE-X
              GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF WS-BUS-FCN-LIST
              PERFORM  3500-PROCESS-LIST
                  THRU 3500-PROCESS-LIST-X
              GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF WS-BUS-FCN-CREATE
              PERFORM  4000-PROCESS-CREATE
                  THRU 4000-PROCESS-CREATE-X
              GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF WS-BUS-FCN-UPDATE
              PERFORM  5000-PROCESS-UPDATE
                  THRU 5000-PROCESS-UPDATE-X
              GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF WS-BUS-FCN-DELETE
              PERFORM  6000-PROCESS-DELETE
                  THRU 6000-PROCESS-DELETE-X
              GO TO 2000-PROCESS-REQUEST-X
           END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /

      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------
      ****************************************************************
      * READ ACCT DESC FILE FOR SPECIFIC DESC AND DISPLAY            *
      ****************************************************************

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  7100-BUILD-ACTD-KEY
               THRU 7100-BUILD-ACTD-KEY-X.

014221*    PERFORM  ACTD-1000-READ
014221*        THRU ACTD-1000-READ-X.

014221     PERFORM  ACTD-1000-READ-TWRK-TS
014221         THRU ACTD-1000-READ-TWRK-TS-X.

           IF WACTD-IO-NOT-FOUND
               MOVE WACTD-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /

      *------------------
       3500-PROCESS-LIST.
      *------------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           IF  (MIR-ACCT-DESC-ID = SPACES)
           AND (MIR-ACCT-DESC-REASN-CD NOT = SPACES)
               MOVE 'CS00920001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           MOVE LOW-VALUES            TO WACTD-KEY.
           MOVE HIGH-VALUES           TO WACTD-ENDBR-KEY.

           MOVE MIR-ACCT-DESC-ID      TO WACTD-ACCT-DESC-ID.
           MOVE MIR-ACCT-DESC-REASN-CD   TO WACTD-ACCT-DESC-REASN-CD.
           MOVE MIR-ACCT-DESC-LANG-CD TO WACTD-ACCT-DESC-LANG-CD.

           PERFORM  ACTD-1000-BROWSE
               THRU ACTD-1000-BROWSE-X.

           IF WACTD-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           ELSE
               PERFORM  ACTD-2000-READ-NEXT
                   THRU ACTD-2000-READ-NEXT-X

               IF WACTD-IO-EOF
                   MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3500-PROCESS-LIST-X
               END-IF
           END-IF.

           MOVE +1                    TO WS-SUB.
           PERFORM  3600-ACTD-INQ-READ
               THRU 3600-ACTD-INQ-READ-X
               UNTIL (WS-SUB  > WS-MAX-LINES)
               OR   WACTD-IO-EOF.

           IF WS-SUB > WS-MAX-LINES
               MOVE MIR-ACCT-DESC-ID-T (WS-MAX-LINES)
                                      TO MIR-ACCT-DESC-ID
               MOVE MIR-ACCT-DESC-REASN-CD-T (WS-MAX-LINES)
                                      TO MIR-ACCT-DESC-REASN-CD
           END-IF

           IF WACTD-IO-EOF
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  ACTD-2000-READ-NEXT
                   THRU ACTD-2000-READ-NEXT-X

               IF WACTD-IO-EOF
                   MOVE 'XS00000015'  TO WGLOB-MSG-REF-INFO
               ELSE
                   MOVE 'XS00000014'  TO WGLOB-MSG-REF-INFO
                   SET WGLOB-MORE-DATA-EXISTS TO TRUE
               END-IF
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  ACTD-3000-END-BROWSE
               THRU ACTD-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /

      *-------------------
       3600-ACTD-INQ-READ.
      *-------------------

           IF  (MIR-ACCT-DESC-LANG-CD = SPACES)
           OR  (MIR-ACCT-DESC-LANG-CD = RACTD-ACCT-DESC-LANG-CD)
               MOVE RACTD-ACCT-DESC-ID
                                  TO MIR-ACCT-DESC-ID-T (WS-SUB)
               MOVE RACTD-ACCT-DESC-REASN-CD
                            TO MIR-ACCT-DESC-REASN-CD-T (WS-SUB)
               MOVE RACTD-ACCT-DESC-LANG-CD
                             TO MIR-ACCT-DESC-LANG-CD-T (WS-SUB)
               MOVE RACTD-ACCT-DESC-TXT
                                 TO MIR-ACCT-DESC-TXT-T (WS-SUB)
               ADD  +1                        TO WS-SUB
           END-IF.

           PERFORM  ACTD-2000-READ-NEXT
               THRU ACTD-2000-READ-NEXT-X.

       3600-ACTD-INQ-READ-X.
           EXIT.
      /

      *--------------------
       4000-PROCESS-CREATE.
      *--------------------
      ****************************************************************
      * CREATE NEW ACCT DESC RECORD.  THE RECORD IS CREATED WITH THE
      * KEY FIELDS ENTERED.  THE REMAINING DATA WILL BE UPDATED VIA
      * THE MAINTAIN SCREEN.
      ****************************************************************

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  7100-BUILD-ACTD-KEY
               THRU 7100-BUILD-ACTD-KEY-X.
           PERFORM  ACTD-1000-READ
               THRU ACTD-1000-READ-X.
           IF WACTD-IO-OK
               MOVE WACTD-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  4100-CREATE-EDITS
               THRU 4100-CREATE-EDITS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  7100-BUILD-ACTD-KEY
               THRU 7100-BUILD-ACTD-KEY-X.

           PERFORM  ACTD-1000-CREATE
               THRU ACTD-1000-CREATE-X.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  ACTD-1000-WRITE
               THRU ACTD-1000-WRITE-X.

014221     PERFORM  ACTD-1000-READ-TWRK-TS
014221         THRU ACTD-1000-READ-TWRK-TS-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /

      *------------------
       4100-CREATE-EDITS.
      *------------------
      ****************************************************************
      * EDIT INPUT FIELDS.
      ****************************************************************

           MOVE MIR-ACCT-DESC-REASN-CD   TO WS-REASON-CODE.
           IF NOT WS-VALID-REASON-CD
              MOVE 'CS00920004'       TO WGLOB-MSG-REF-INFO
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
            END-IF.

           MOVE MIR-ACCT-DESC-LANG-CD TO WXTAB-ETBL-VALU-ID.
           PERFORM  LANG-1000-EDIT-USER-LANGUAGE
               THRU LANG-1000-EDIT-USER-LANGUAGE-X.

           IF WXTAB-IO-OK
               CONTINUE
           ELSE
               MOVE 'CS00920002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4100-CREATE-EDITS-X.
           EXIT.
      /


      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------

           PERFORM  7100-BUILD-ACTD-KEY
               THRU 7100-BUILD-ACTD-KEY-X.

014221*    PERFORM  ACTD-1000-READ-FOR-UPDATE
014221*        THRU ACTD-1000-READ-FOR-UPDATE-X.

014221     PERFORM  ACTD-2000-UPDATE-TWRK-TS
014221         THRU ACTD-2000-UPDATE-TWRK-TS-X.

           IF WACTD-IO-NOT-FOUND
               MOVE WACTD-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
014221          MOVE 'XS00000303'     TO WGLOB-MSG-REF-INFO
014221          MOVE 'ACTD'           TO WGLOB-MSG-PARM (01)
014221          MOVE WACTD-KEY        TO WGLOB-MSG-PARM (02)
014221          PERFORM  0260-1000-GENERATE-MESSAGE
014221              THRU 0260-1000-GENERATE-MESSAGE-X
014221          PERFORM  9100-BLANK-DATA-FIELDS
014221              THRU 9100-BLANK-DATA-FIELDS-X
014221          GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  5220-MAINTAIN-EDITS
               THRU 5220-MAINTAIN-EDITS-X.

           PERFORM  ACTD-2000-REWRITE
               THRU ACTD-2000-REWRITE-X.

014221     PERFORM  ACTD-1000-READ-TWRK-TS
014221         THRU ACTD-1000-READ-TWRK-TS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /

      *--------------------
       5220-MAINTAIN-EDITS.
      *--------------------

      ****************************************************************
      * EDIT INPUT FIELDS.                                          *
      ****************************************************************

           MOVE 'N'                   TO WS-PARAMETERS-USED.

           IF MIR-ACCT-DESC-TXT = SPACES
               MOVE RACTD-ACCT-DESC-TXT
                                      TO MIR-ACCT-DESC-TXT
           ELSE
               IF MIR-ACCT-DESC-TXT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-ACCT-DESC-TXT
               END-IF
           END-IF.

           MOVE MIR-ACCT-DESC-TXT
                                      TO WS-DESC-ARRAY.
           SET  WS-VALID-MESSAGE           TO TRUE.
           PERFORM  5226-CHECK-FOR-TOKENS
               THRU 5226-CHECK-FOR-TOKENS-X
               VARYING CHAR-ARRAY FROM 1 BY 1
               UNTIL CHAR-ARRAY > WS-MAX-MESSAGE-LENGTH.

           IF WS-VALID-MESSAGE
               MOVE MIR-ACCT-DESC-TXT
                                      TO RACTD-ACCT-DESC-TXT
           END-IF.

       5220-MAINTAIN-EDITS-X.
           EXIT.
      /
      *----------------------
       5226-CHECK-FOR-TOKENS.
      *----------------------

           IF WS-SINGLE-CHAR (CHAR-ARRAY) = '@'
               SET CHAR-ARRAY UP BY 1
               MOVE WS-SINGLE-CHAR (CHAR-ARRAY)
                                      TO WS-TOKENS
               IF VALID-TOKENS
                   MOVE 'Y'           TO WS-PARAMETERS-USED
               ELSE
                   SET  WS-INVALID-MESSAGE TO TRUE
                   MOVE 'CS00920003'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       5226-CHECK-FOR-TOKENS-X.
           EXIT.
      /

      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

           PERFORM  7100-BUILD-ACTD-KEY
               THRU 7100-BUILD-ACTD-KEY-X.

014221*    PERFORM  ACTD-1000-READ-FOR-UPDATE
014221*        THRU ACTD-1000-READ-FOR-UPDATE-X.

014221     PERFORM  ACTD-2000-UPDATE-TWRK-TS
014221         THRU ACTD-2000-UPDATE-TWRK-TS-X.

           IF WACTD-IO-OK
               PERFORM  ACTD-1000-DELETE
                   THRU ACTD-1000-DELETE-X
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE SPACES            TO MIR-ACCT-DESC-TXT
           ELSE
014221         EVALUATE  TRUE
014221            WHEN MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
014221                MOVE 'XS00000303'     TO WGLOB-MSG-REF-INFO
014221                MOVE 'ACTD'           TO WGLOB-MSG-PARM (01)
014221                MOVE WACTD-KEY        TO WGLOB-MSG-PARM (02)
014221                PERFORM  0260-1000-GENERATE-MESSAGE
014221                    THRU 0260-1000-GENERATE-MESSAGE-X
014221            WHEN OTHER
                     MOVE WACTD-KEY         TO WGLOB-MSG-PARM (1)
                     MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
                     PERFORM  0260-1000-GENERATE-MESSAGE
                         THRU 0260-1000-GENERATE-MESSAGE-X
014221         END-EVALUATE
           END-IF.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *--------------------
       7100-BUILD-ACTD-KEY.
      *--------------------

      ****************************************************************
      * BUILD THE KEY.                                               *
      ****************************************************************

           MOVE MIR-ACCT-DESC-ID      TO WACTD-ACCT-DESC-ID.
           MOVE MIR-ACCT-DESC-REASN-CD   TO WACTD-ACCT-DESC-REASN-CD.
           MOVE MIR-ACCT-DESC-LANG-CD TO WACTD-ACCT-DESC-LANG-CD.

       7100-BUILD-ACTD-KEY-X.
           EXIT.
      /

      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES       TO MIR-ACCT-DESC-ID-G.
           MOVE SPACES       TO MIR-ACCT-DESC-REASN-CD-G.
           MOVE SPACES       TO MIR-ACCT-DESC-LANG-CD-G.
           MOVE SPACES       TO MIR-ACCT-DESC-TXT-G.
           MOVE SPACES       TO MIR-ACCT-DESC-TXT.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /

      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RACTD-ACCT-DESC-TXT   TO MIR-ACCT-DESC-TXT.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     SET WS-TWRK-KEY-DEFAULT           TO TRUE.
025970     SET WS-MAX-LINES-DEFAULT          TO TRUE.
025970     SET WS-MAX-MESSAGE-LENGTH-DEFAULT TO TRUE.
025970     MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK                 TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /


      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPELANG.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY ACTD
014221                         '$VAR2' BY 'ACTD'.
      /
      ****************************************************************
      * LINKING COPYBOOKS                                            *
      ****************************************************************

      *
      * LINK TO PROGRAM 0280 FOR NUMERIC EDITS
      *
014035*COPY XCPL0280.
      /
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS
      ****************************************************************

      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY XCPNXTAB.
      /
       COPY CCPAACTD.
       COPY CCPBACTD.
       COPY CCPCACTD.
       COPY CCPNACTD.
       COPY CCPUACTD.
       COPY CCPXACTD.

      *****************************************************************
      **                 END OF PROGRAM CSOM0092                     **
      *****************************************************************
