      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. XSOM2294.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  XSOM2294                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE DOCS TABLE                               **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025244**  6.6       ADD INFORMATIONAL MESSAGE                        **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSOM2294'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                         PIC X(04).
               88  WS-BUS-FCN-LIST                   VALUE '2294'.
           05  WS-INDX                               PIC S9(04) BINARY.
           05  WS-SUB                                PIC S9(04) BINARY.
025970*           05  WS-MAX-LIST-LINES              PIC S9(04) BINARY
025970*                                                  VALUE 50.
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LIST-LINES                     PIC S9(4) BINARY.
025970         88  WS-MAX-LIST-LINES-DEFAULT         VALUE +50.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
       COPY XCWEBLCH.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY CCWL0620.
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL1640.
       COPY XCWL2566.       
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY XCWM2294.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'XSOM2294'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'     TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-LIST.
      *------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

      * CALL THE DOCUMENT STRUCTURE UTILITY TO LOAD THE DOCUMENT 
      * STRUCTURE INTO ITS WORKING-STORAGE TABLE
      
           PERFORM  2566-0000-INIT-PARM-INFO
               THRU 2566-0000-INIT-PARM-INFO-X.
               
           MOVE MIR-DOCSTC-ID          TO L2566-DOCSTC-ID.
           
           PERFORM  2566-1000-STRT-DOCM
               THRU 2566-1000-STRT-DOCM-X.
      
      *MSG: THE DOCUMENT STRUCTURE LOAD FAILED     
           IF L2566-RETRN-ERROR
               MOVE 'XS22940001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 2000-LIST-X
           END-IF.
           
      * LOOP THROUGH DOCUMENT STRUCTURE POPULATING MIR OUTPUT FIELDS
      * NOTE:- ALWAYS IGNORE THE FIRST ENTRY IN THE STRUCTURE TABLE; 
      * THIS IS A DUMMY ENTRY THAT ENABLES US TO SUPPORT MULTIPLE
      * 'ROOT' RELATIONSHIPS
                  
           MOVE +1 TO WS-INDX.

           PERFORM  3000-LIST-DOCS
               THRU 3000-LIST-DOCS-X
               VARYING WS-SUB FROM 1 BY +1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      L2566-GET-DOCS-BY-INDX-EOF
               OR      MIR-RETRN-EDIT-ERROR.
               
           IF  L2566-GET-DOCS-BY-INDX-EOF
           OR  MIR-RETRN-EDIT-ERROR
025244         MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
025244         PERFORM  0260-1000-GENERATE-MESSAGE
025244             THRU 0260-1000-GENERATE-MESSAGE-X
025244*        CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
025244         MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
025244* TO VIEW MORE DATA - SELECT MORE
025244         PERFORM  0260-1000-GENERATE-MESSAGE
025244             THRU 0260-1000-GENERATE-MESSAGE-X

               MOVE L2566-DOCSTC-ID        TO MIR-DOCSTC-ID
               MOVE L2566-DBSRL-ID         TO MIR-DBSRL-ID
           END-IF.

       2000-LIST-X.
           EXIT.


      *-----------------
       3000-LIST-DOCS.
      *-----------------
      
           PERFORM  2566-0000-INIT-PARM-INFO
               THRU 2566-0000-INIT-PARM-INFO-X.

      *FOR THE FIRST RECORD USE THE GET DOCS BY KEY
           IF  WS-SUB = 1
           AND MIR-DBSRL-ID > SPACES
               IF  MIR-DBSRL-ID = EBLCH-BLANK-FIELD-CHAR
                   CONTINUE
               ELSE
                   PERFORM  3100-GET-FIRST-RECORD
                       THRU 3100-GET-FIRST-RECORD-X
                   GO TO 3000-LIST-DOCS-X
               END-IF
           END-IF.

           MOVE MIR-DOCSTC-ID          TO L2566-DOCSTC-ID.
           COMPUTE L2566-INDX = WS-INDX + 1.
           
           PERFORM  2566-5500-GET-DOCS-BY-INDX
               THRU 2566-5500-GET-DOCS-BY-INDX-X.
           
      *MSG: THE DOCUMENT STRUCTURE INDEX READ FAILED           
           IF L2566-RETRN-ERROR
               MOVE 'XS22940002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 3000-LIST-DOCS-X
           END-IF.
           
           IF  L2566-GET-DOCS-BY-INDX-EOF
               GO TO 3000-LIST-DOCS-X
           END-IF.
           
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       3000-LIST-DOCS-X.
           EXIT.
      /
      *----------------------
       3100-GET-FIRST-RECORD.
      *----------------------
      
      * START THE LIST FROM THE SELECTED RELATIONSHIP ID IF POPULATED
           PERFORM  2566-0000-INIT-PARM-INFO
               THRU 2566-0000-INIT-PARM-INFO-X.
           
           MOVE MIR-DOCSTC-ID          TO L2566-DOCSTC-ID.
           MOVE MIR-DBSRL-ID           TO L2566-DBSRL-ID.
           
           PERFORM  2566-5000-GET-DOCS-BY-KEY
               THRU 2566-5000-GET-DOCS-BY-KEY-X.
           
      *MSG: THE DOCUMENT STRUCTURE KEY READ FAILED           
           IF L2566-RETRN-ERROR
               MOVE 'XS22940003'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 3100-GET-FIRST-RECORD-X
           END-IF.
           
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       3100-GET-FIRST-RECORD-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                 TO MIR-DBSRL-ID-G.
           MOVE SPACES                 TO MIR-PARNT-DBSRL-ID-G.
           MOVE SPACES                 TO MIR-DBSRL-PARNT-TBL-ID-G.
           MOVE SPACES                 TO MIR-DBSRL-CHILD-TBL-ID-G.
           MOVE SPACES                 TO MIR-DV-DOCSTC-LVL-NUM-G.
           
       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE L2566-INDX TO WS-INDX.

           MOVE L2566-DBSRL-ID         
                            TO MIR-DBSRL-ID-T (WS-SUB).
           MOVE L2566-DBSRL-PARNT-TBL-ID   
                            TO MIR-DBSRL-PARNT-TBL-ID-T (WS-SUB).
           MOVE L2566-DBSRL-CHILD-TBL-ID
                            TO MIR-DBSRL-CHILD-TBL-ID-T (WS-SUB).
           MOVE L2566-DV-DOCSTC-LVL-NUM
                            TO MIR-DV-DOCSTC-LVL-NUM-T (WS-SUB).

      * NEED TO GET THE PARENT RELATIONSHIP ID
           PERFORM  2566-2500-GET-PARNT-DOCS
               THRU 2566-2500-GET-PARNT-DOCS-X.
           
           MOVE L2566-DBSRL-ID
                            TO MIR-PARNT-DBSRL-ID-T (WS-SUB).
       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
      
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2566-0000-INIT-PARM-INFO
025970         THRU 2566-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE. 

           MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.
025970     SET  WS-MAX-LIST-LINES-DEFAULT TO TRUE.
           
       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
025970 COPY CCPS0620.
       COPY CCPL0620.
       COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
025970 COPY XCPS1640.
       COPY XCPL1640.
       
       COPY XCPS2566.
       COPY XCPL2566.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM XSOM2294
      *****************************************************************
