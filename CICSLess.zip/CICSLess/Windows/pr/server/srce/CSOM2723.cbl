      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2723.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2723                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE DELETE RECORD FUNCTION  **
      **            FOR THE INVESTOR PROFILE (IPRO) TABLE            **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020463**  6.4       INVESTOR PROFILES                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2723'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
      /

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-DELETE         VALUE '2723'.

       01  WS-CONSTANT-AREA.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '2723'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
       COPY XCWL8090.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWIPRO.
       COPY CCFRIPRO.
       COPY CCFWIPRD.
       COPY CCFRIPRD.
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2723.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  2000-DELETE
                        THRU 2000-DELETE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2723'     TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'   TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *--------------
       2000-DELETE.
      *--------------
      *
      *  THE RECORD MUST EXIST, AND HAVE A CURRENT TIMESTAMP
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  IPRO-2000-UPDATE-TWRK-TS
               THRU IPRO-2000-UPDATE-TWRK-TS-X.

           IF  WIPRO-IO-NOT-FOUND
      *MSG: 'RECORD (@1) ON TABLE (@2) NOT FOUND. DELETE FAILED'
               MOVE WIPRO-KEY      TO WGLOB-MSG-PARM (1)
               MOVE 'TIPRO'        TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000010'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-DELETE-X
           END-IF.

           IF MIR-RETRN-TS-MISMATCH
      *MSG: 'PROCESS FAILED - RE-ENTER DATA AS ANOTHER PROCESS HAS 
      *      UPDATED - TABLE (@1), KEY @2'
              MOVE 'XS00000303'    TO WGLOB-MSG-REF-INFO
              MOVE 'IPRO'          TO WGLOB-MSG-PARM (1)
              MOVE WIPRO-KEY       TO WGLOB-MSG-PARM (2)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 2000-DELETE-X
           END-IF.
      *
      *  EDIT THE DATA ENTERED FOR THE RECORD
      *
           PERFORM  8000-EDIT-DATA
               THRU 8000-EDIT-DATA-X.

           IF  WGLOB-RETURN-ERROR
               PERFORM  IPRO-3000-UNLOCK
                   THRU IPRO-3000-UNLOCK-X
               GO TO 2000-DELETE-X
           END-IF.

      *
      *  DELETE THE RECORD AND AUDIT THE CHANGE
      *
           PERFORM  IPRO-1000-DELETE
               THRU IPRO-1000-DELETE-X.


           IF  WIPRO-IO-OK
      *MSG:    DELETE COMPLETED MESSAGE
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  IPRO-3000-UNLOCK
                   THRU IPRO-3000-UNLOCK-X
      *MSG:    RECORD (@1) LOST IN DELETE
               MOVE WIPRO-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM 9000-BLANK-DATA-FIELDS
              THRU 9000-BLANK-DATA-FIELDS-X.

       2000-DELETE-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WIPRO-KEY.
           MOVE MIR-PRFL-ID            TO WIPRO-PRFL-ID.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *----------------
       8000-EDIT-DATA.
      *----------------

           MOVE LOW-VALUES             TO WIPRD-KEY.
           MOVE MIR-PRFL-ID            TO WIPRD-PRFL-ID.
           MOVE WWKDT-LOW-DT           TO WIPRD-PRFLD-EFF-DT.
           MOVE ZERO                   TO WIPRD-PRFLD-SEQ-NUM.

           MOVE WIPRD-KEY              TO WIPRD-ENDBR-KEY.
           MOVE WWKDT-HIGH-DT          TO WIPRD-ENDBR-PRFLD-EFF-DT.
           MOVE +999                   TO WIPRD-ENDBR-PRFLD-SEQ-NUM.

           PERFORM  IPRD-4000-BROWSE-INDEX
               THRU IPRD-4000-BROWSE-INDEX-X.

           PERFORM  IPRD-5000-READ-NEXT-INDEX
               THRU IPRD-5000-READ-NEXT-INDEX-X.

           IF  WIPRD-IO-OK
      *MSG: INVESTOR PROFILE DETAIL RECORD (@1) EXISTS
      *     : CANNOT DELETE PROFILE
               MOVE 'CS27230001'        TO WGLOB-MSG-REF-INFO
               MOVE WIPRD-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           PERFORM  IPRD-6000-END-BROWSE-INDEX
               THRU IPRD-6000-END-BROWSE-INDEX-X.

       8000-EDIT-DATA-X.
           EXIT.

      *-----------------
       9000-BLANK-DATA-FIELDS.
      *-----------------

           MOVE SPACES                  TO MIR-PRFL-ID.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE          WS-WORKING-STORAGE.
025970     SET  WS-TWRK-KEY-DEFAULT            TO TRUE.
025970     MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.


       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  IPRO
                                '$VAR2'   BY 'IPRO'.
       COPY XCPL8090.
025970 COPY XCPS8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNIPRO.
       COPY CCPUIPRO.
       COPY CCPXIPRO.
       COPY CCPBIPRD.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2723                     **
      *****************************************************************


