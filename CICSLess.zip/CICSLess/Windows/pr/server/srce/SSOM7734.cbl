      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM7734.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM7734                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE UTRA TABLE                               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
021239**  6.4       FUND UNIT VALUE                                  **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM7734'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************

      ****************************************************************
      *  WORKING AREA                                                *
      ****************************************************************
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                         PIC X(04).
               88  WS-BUS-FCN-LIST                   VALUE '7734'.
           05  WS-SUB                                PIC S9(04) BINARY.
           05  WS-FCT-SUB                            PIC S9(04) BINARY.
           05  WS-MAX-LIST-LINES                     PIC S9(04) BINARY.
           05  WS-ASIGN-EFF-DT                       PIC X(10).
           05  WS-DEFN-RULE-ID                       PIC S9(04).

       01  WS-CONSTANT-AREA.
025970*    05  WS-MAX-FCT-QTY                        PIC S9(04) BINARY
025970*                                              VALUE +5.
025970     05  WS-MAX-FCT-QTY                        PIC S9(04) BINARY.
025970         88  WS-MAX-FCT-QTY-DEFAULT            VALUE +5.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY SCFWUTRB.
       COPY SCFRUTRB.
      /
       COPY SCFWUTRD.
       COPY SCFRUTRD.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM7734.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE WPGWS-CRNT-PGM-ID
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'     TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-LIST.
      *------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2100-VALIDATE-DATA
               THRU 2100-VALIDATE-DATA-X.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  UTRB-1000-BROWSE
               THRU UTRB-1000-BROWSE-X.

           PERFORM  UTRB-2000-READ-NEXT
               THRU UTRB-2000-READ-NEXT-X.

           IF  WUTRB-IO-EOF
               PERFORM  UTRB-3000-END-BROWSE
                   THRU UTRB-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  2200-POPULATE-KEY-FIELDS
               THRU 2200-POPULATE-KEY-FIELDS-X.

           PERFORM  2010-BROWSE-UTRB
               THRU 2010-BROWSE-UTRB-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WUTRB-IO-EOF.

           IF  WUTRB-IO-EOF
      *MSG: *** END OF LIST ***
               MOVE 'CS00000023'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS
                 TO TRUE

               PERFORM  2200-POPULATE-KEY-FIELDS
                   THRU 2200-POPULATE-KEY-FIELDS-X
           END-IF.

           PERFORM  UTRB-3000-END-BROWSE
               THRU UTRB-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.

      *-----------------
       2010-BROWSE-UTRB.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  UTRB-2000-READ-NEXT
               THRU UTRB-2000-READ-NEXT-X.

       2010-BROWSE-UTRB-X.
           EXIT.
      /
      *----------------------------
       2100-VALIDATE-DATA.
      *----------------------------

           PERFORM  2110-EDIT-UTR-ASIGN-TYP-CD
               THRU 2110-EDIT-UTR-ASIGN-TYP-CD-X.

           PERFORM  2120-EDIT-UTR-ASIGN-EFF-DT
               THRU 2120-EDIT-UTR-ASIGN-EFF-DT-X.

           PERFORM  2130-EDIT-UTR-DEFN-RULE-ID
               THRU 2130-EDIT-UTR-DEFN-RULE-ID-X.

       2100-VALIDATE-DATA-X.
           EXIT.

      *----------------------------
       2110-EDIT-UTR-ASIGN-TYP-CD.
      *----------------------------

           MOVE MIR-UTR-ASIGN-TYP-CD   TO WEDIT-ETBL-VALU-ID.

           PERFORM  UVTP-1000-EDIT
               THRU UVTP-1000-EDIT-X.

           IF  NOT WEDIT-IO-OK
      *MSG: UNIT TYPE CODE (@1) NOT ON EDIT (@2)
               MOVE 'SS77340001'            TO WGLOB-MSG-REF-INFO
               MOVE WEDIT-ETBL-VALU-ID      TO WGLOB-MSG-PARM (1)
               MOVE 'UVTYP'                 TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2110-EDIT-UTR-ASIGN-TYP-CD-X.
           EXIT.

      *----------------------------
       2120-EDIT-UTR-ASIGN-EFF-DT.
      *----------------------------

           IF  MIR-UTR-ASIGN-EFF-DT = SPACE
               MOVE WWKDT-HIGH-DT      TO WS-ASIGN-EFF-DT
               GO TO 2120-EDIT-UTR-ASIGN-EFF-DT-X
           END-IF.

           MOVE MIR-UTR-ASIGN-EFF-DT   TO L1640-EXTERNAL-DATE

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      *MSG: INVALID ASSIGNMENT EFFECTIVE DATE
               MOVE 'SS77340002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L1640-INTERNAL-DATE
                                       TO WS-ASIGN-EFF-DT
           END-IF.

       2120-EDIT-UTR-ASIGN-EFF-DT-X.
           EXIT.

      *----------------------------
       2130-EDIT-UTR-DEFN-RULE-ID.
      *----------------------------

           IF  MIR-DV-REFRESH-SCROLL
               MOVE ZERO               TO MIR-UTR-DEFN-RULE-ID
               MOVE ZERO               TO WS-DEFN-RULE-ID
               GO TO 2130-EDIT-UTR-DEFN-RULE-ID-X
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE LENGTH OF MIR-UTR-DEFN-RULE-ID
             TO L0280-LENGTH.
           MOVE ZERO                    TO L0280-PRECISION.
           MOVE MIR-UTR-DEFN-RULE-ID    TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF  L0280-OK
               MOVE L0280-OUTPUT        TO WS-DEFN-RULE-ID
           ELSE
               MOVE ZERO                TO WS-DEFN-RULE-ID
           END-IF.

       2130-EDIT-UTR-DEFN-RULE-ID-X.
           EXIT.

      *----------------------------
       2200-POPULATE-KEY-FIELDS.
      *----------------------------

            MOVE RUTRB-UTR-ASIGN-TYP-CD  TO MIR-UTR-ASIGN-TYP-CD.

            MOVE RUTRB-UTR-ASIGN-EFF-DT  TO L1640-INTERNAL-DATE
            PERFORM  1640-8000-INTERNAL-TO-MIR
                THRU 1640-8000-INTERNAL-TO-MIR-X
            MOVE L1640-EXTERNAL-DATE     TO MIR-UTR-ASIGN-EFF-DT.

            MOVE RUTRB-UTR-DEFN-RULE-ID  TO L0290-INPUT-V00.
            MOVE ZERO                    TO L0290-PRECISION.
            MOVE LENGTH OF MIR-UTR-DEFN-RULE-ID
                                         TO L0290-MAX-OUT-LEN.
            PERFORM  0290-2000-FORMAT-FOR-MIR
                THRU 0290-2000-FORMAT-FOR-MIR-X.
            MOVE L0290-OUTPUT-DATA       TO MIR-UTR-DEFN-RULE-ID.

       2200-POPULATE-KEY-FIELDS-X.
           EXIT.

      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WUTRB-KEY.
           MOVE MIR-UTR-ASIGN-TYP-CD   TO WUTRB-UTR-ASIGN-TYP-CD.
           MOVE WS-ASIGN-EFF-DT        TO WUTRB-UTR-ASIGN-EFF-DT.
           MOVE WS-DEFN-RULE-ID        TO WUTRB-UTR-DEFN-RULE-ID.

       7000-BUILD-KEYS-X.
           EXIT.

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           INITIALIZE MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RUTRB-UTR-DEFN-RULE-ID
             TO L0290-INPUT-V00.
           MOVE ZERO           TO L0290-PRECISION.
           MOVE LENGTH OF MIR-UTR-DEFN-RULE-ID
                               TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-UTR-DEFN-RULE-ID-T (WS-SUB).

           MOVE RUTRB-UTR-ASIGN-EFF-DT
             TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
             TO MIR-UTR-ASIGN-EFF-DT-T (WS-SUB).

           PERFORM  9210-GET-RULE-DEFN
               THRU 9210-GET-RULE-DEFN-X.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *----------------------------
       9210-GET-RULE-DEFN.
      *----------------------------

           MOVE LOW-VALUES             TO WUTRD-KEY.

           MOVE RUTRB-UTR-DEFN-RULE-ID TO WUTRD-UTR-DEFN-RULE-ID.

           MOVE WUTRD-KEY              TO WUTRD-ENDBR-KEY.
           MOVE HIGH-VALUES            TO WUTRD-ENDBR-UTR-DEFN-FCT-CD.

           PERFORM  UTRD-1000-BROWSE
               THRU UTRD-1000-BROWSE-X.

           PERFORM  UTRD-2000-READ-NEXT
               THRU UTRD-2000-READ-NEXT-X.

           MOVE ZERO                   TO WS-FCT-SUB.

           PERFORM
               UNTIL WS-FCT-SUB > WS-MAX-FCT-QTY
               OR NOT WUTRD-IO-OK

               ADD +1                  TO WS-FCT-SUB

               EVALUATE WS-FCT-SUB

                   WHEN +1
                        MOVE RUTRD-UTR-DEFN-FCT-CD
                          TO MIR-UTR-DEFN-FCT-CD-1-T (WS-SUB)

                        MOVE RUTRD-UTR-DEFN-FCT-QTY
                          TO L0290-INPUT-V00
                        MOVE ZERO           TO L0290-PRECISION
                        MOVE LENGTH OF MIR-UTR-DEFN-FCT-QTY-1-T (WS-SUB)
                                            TO L0290-MAX-OUT-LEN
                        PERFORM  0290-2000-FORMAT-FOR-MIR
                            THRU 0290-2000-FORMAT-FOR-MIR-X
                        MOVE L0290-OUTPUT-DATA
                          TO MIR-UTR-DEFN-FCT-QTY-1-T (WS-SUB)

                   WHEN +2
                        MOVE RUTRD-UTR-DEFN-FCT-CD
                          TO MIR-UTR-DEFN-FCT-CD-2-T (WS-SUB)

                        MOVE RUTRD-UTR-DEFN-FCT-QTY
                          TO L0290-INPUT-V00
                        MOVE ZERO           TO L0290-PRECISION
                        MOVE LENGTH OF MIR-UTR-DEFN-FCT-QTY-2-T (WS-SUB)
                                            TO L0290-MAX-OUT-LEN
                        PERFORM  0290-2000-FORMAT-FOR-MIR
                            THRU 0290-2000-FORMAT-FOR-MIR-X
                        MOVE L0290-OUTPUT-DATA
                          TO MIR-UTR-DEFN-FCT-QTY-2-T (WS-SUB)

                   WHEN +3
                        MOVE RUTRD-UTR-DEFN-FCT-CD
                          TO MIR-UTR-DEFN-FCT-CD-3-T (WS-SUB)

                        MOVE RUTRD-UTR-DEFN-FCT-QTY
                          TO L0290-INPUT-V00
                        MOVE ZERO           TO L0290-PRECISION
                        MOVE LENGTH OF MIR-UTR-DEFN-FCT-QTY-3-T (WS-SUB)
                                            TO L0290-MAX-OUT-LEN
                        PERFORM  0290-2000-FORMAT-FOR-MIR
                            THRU 0290-2000-FORMAT-FOR-MIR-X
                        MOVE L0290-OUTPUT-DATA
                          TO MIR-UTR-DEFN-FCT-QTY-3-T (WS-SUB)

                   WHEN +4
                        MOVE RUTRD-UTR-DEFN-FCT-CD
                          TO MIR-UTR-DEFN-FCT-CD-4-T (WS-SUB)

                        MOVE RUTRD-UTR-DEFN-FCT-QTY
                          TO L0290-INPUT-V00
                        MOVE ZERO           TO L0290-PRECISION
                        MOVE LENGTH OF MIR-UTR-DEFN-FCT-QTY-4-T (WS-SUB)
                                            TO L0290-MAX-OUT-LEN
                        PERFORM  0290-2000-FORMAT-FOR-MIR
                            THRU 0290-2000-FORMAT-FOR-MIR-X
                        MOVE L0290-OUTPUT-DATA
                          TO MIR-UTR-DEFN-FCT-QTY-4-T (WS-SUB)

                   WHEN +5
                        MOVE RUTRD-UTR-DEFN-FCT-CD
                          TO MIR-UTR-DEFN-FCT-CD-5-T (WS-SUB)

                        MOVE RUTRD-UTR-DEFN-FCT-QTY
                          TO L0290-INPUT-V00
                        MOVE ZERO           TO L0290-PRECISION
                        MOVE LENGTH OF MIR-UTR-DEFN-FCT-QTY-5-T (WS-SUB)
                                            TO L0290-MAX-OUT-LEN
                        PERFORM  0290-2000-FORMAT-FOR-MIR
                            THRU 0290-2000-FORMAT-FOR-MIR-X
                        MOVE L0290-OUTPUT-DATA
                          TO MIR-UTR-DEFN-FCT-QTY-5-T (WS-SUB)

               END-EVALUATE

               PERFORM  UTRD-2000-READ-NEXT
                   THRU UTRD-2000-READ-NEXT-X

           END-PERFORM.

           PERFORM  UTRD-3000-END-BROWSE
               THRU UTRD-3000-END-BROWSE-X.

       9210-GET-RULE-DEFN-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
025970     MOVE SPACE                       TO WWKDT-WORK-FIELDS.

           COMPUTE WS-MAX-LIST-LINES = LENGTH OF MIR-UTR-DEFN-RULE-ID-G
                / LENGTH OF MIR-UTR-DEFN-RULE-ID-T (1).

           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

025970     SET WS-MAX-FCT-QTY-DEFAULT  TO TRUE.
025970
       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY CCPEUVTP.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.

025970 COPY XCPS0280.
       COPY XCPL0280.

       COPY XCPS0290.
       COPY XCPL0290.

025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY SCPBUTRB.

       COPY SCPBUTRD.

       COPY CCPNEDIT.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM SSOM7734
      *****************************************************************
