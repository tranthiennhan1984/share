      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7702.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7702                                         **
      **  REMARKS:  THIS MODULE PERFORMS CNTX RECORD UPDATE          **
      **                                                             **
      **  DOMAIN :  TX                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
013697**  6.3       ROTH IRA / EDUCATIONAL IRA                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
022455**  6.4       CORRECT POLICY ACTIVITY DATE                     **
023271**  6.5       REMOVAL OF CSINPGAO AND CSINPGAR                 **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
035626**  7.0       CORRECT COMMENT FIELD OUTPUT                     **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7702'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                       PIC X(04).
               88  WS-BUS-FCN-UPDATE               VALUE '7702'.
           05  WS-MIR-FIELDS.
               10  WS-MIR-CNTRXN-SEQ-NUM           PIC 9(01).
               10  WS-MIR-POL-PAYO-NUM             PIC S9(05).
               10  WS-MIR-CDA-SEQ-NUM              PIC S9(04).
               10  WS-MIR-CNTRXN-RPT-SEQ-NUM       PIC S9(04).
           05  WS-EFF-DT                           PIC X(10).
           05  WS-CDA-EFF-IDT-NUM                  PIC X(10).
           05  WS-NEW-ALLOC-TYP-CD                 PIC X(01).
           05  WS-OLD-ALLOC-TYP-CD                 PIC X(01).
           05  WS-PGAL-SEQ-NUM                     PIC S9(03) COMP-3.
           05  WS-PGAL-UPDATE-IND                  PIC X.
               88  WS-PGAL-UPDATE-YES              VALUE 'Y'.
               88  WS-PGAL-UPDATE-NO               VALUE 'N'.
           05  WS-CNTRXN-AMT-CHNG-IND              PIC X.
               88  WS-CNTRXN-AMT-CHNG-YES          VALUE 'Y'.
               88  WS-CNTRXN-AMT-CHNG-NO           VALUE 'N'.
           05  WS-PGAL-REC-FOUND-IND               PIC 9.
               88  WS-PGAL-REC-FOUND-NONE          VALUE 0.
               88  WS-PGAL-REC-FOUND-ONE           VALUE 1.
               88  WS-PGAL-REC-FOUND-TWO           VALUE 2.
           05  WS-SAVE-PGAL-EFF-DT                 PIC X(10).
           05  WS-SAVE-PGAL-SEQ-NUM                PIC S9(03) COMP-3.
           05  WS-DPOS-DFLT-SW                     PIC X(01).
               88  WS-DPOS-DFLT-FOUND              VALUE 'Y'.
               88  WS-DPOS-DFLT-NOT-FOUND          VALUE 'N'.
           05  WS-TAX-YEAR-CHNG-SW                 PIC X(01).
               88  WS-TAX-YEAR-CHNG                VALUE 'Y'.
           05  WS-CNTRXN-RPT-CD                    PIC X(01).
               88  WS-CNTRXN-RPT-ACTV              VALUE 'A'.
               88  WS-CNTRXN-RPT-ACTV-RPT          VALUE 'T'.
               88  WS-CNTRXN-RPT-CNCL              VALUE 'C'.
               88  WS-CNTRXN-RPT-RPT-LATE          VALUE 'X'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWWWKDT.
       COPY CCWLPGA.
       COPY CCWWLOCK.
       COPY CCWWCVGS.
       COPY CCWWINDX.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFWCDSA.
       COPY CCFRCDSA.
      /
       COPY CCFWUSRP.
       COPY CCFRUSRP.

       COPY CCFWCNTX.
       COPY CCFHCNTX.
       COPY CCFRCNTX.
      /
       COPY CCFWPGAO.
       COPY CCFWPGAM.
       COPY CCFRPGAL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY CCWL0620.
       COPY CCWL2435.
       COPY CCWL7280.
       COPY CCWL7800.
       COPY CCWLPGAL.
       COPY XCWL1640.
       COPY XCWL1646.
       COPY XCWL1660.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL8090.
       COPY XCWL8960.

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7702.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    INITIALIZE WS-WORKING-STORAGE.

025970*    MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  3000-PROCESS-REQUEST
                        THRU 3000-PROCESS-REQUEST-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
025999*             MOVE 'XS00000000'         TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE WPGWS-CRNT-PGM-ID    TO WGLOB-MSG-PARM (2)
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *----------------------------
       3000-PROCESS-REQUEST.
      *----------------------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  8100-EDIT-KEY-FIELDS
               THRU 8100-EDIT-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  7000-LOCK-CNTX-RECORD
               THRU 7000-LOCK-CNTX-RECORD-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  8200-EDIT-DATA-FIELDS
               THRU 8200-EDIT-DATA-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW = ZERO
               PERFORM  9200-MOVE-RECORD-TO-MIR
                   THRU 9200-MOVE-RECORD-TO-MIR-X
           ELSE
               PERFORM  CNTX-3000-UNLOCK
                   THRU CNTX-3000-UNLOCK-X
               GO TO 3000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  3100-UPDATE-CNTX
               THRU 3100-UPDATE-CNTX-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  3200-PGAL-ROLL-FRWD-UPDT
               THRU 3200-PGAL-ROLL-FRWD-UPDT-X.

       3000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------------
       3100-UPDATE-CNTX.
      *----------------------------

           PERFORM  CNTX-2000-REWRITE
               THRU CNTX-2000-REWRITE-X.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           PERFORM  9350-SETUP-AUDIT-INFO
               THRU 9350-SETUP-AUDIT-INFO-X.

       3100-UPDATE-CNTX-X.
           EXIT.


      *----------------------------
       3200-PGAL-ROLL-FRWD-UPDT.
      *----------------------------

           IF  WS-NEW-ALLOC-TYP-CD = WS-OLD-ALLOC-TYP-CD
           OR  WS-PGAL-UPDATE-NO
           OR  WS-CNTRXN-AMT-CHNG-YES
               GO TO 3200-PGAL-ROLL-FRWD-UPDT-X
           END-IF.

           PERFORM  7280-1000-BUILD-PARM-INFO
               THRU 7280-1000-BUILD-PARM-INFO-X.

           SET L7280-PRCES-TYP-ALL          TO TRUE.

           PERFORM  3210-PGAL-ROLL-FRWD
               THRU 3210-PGAL-ROLL-FRWD-X.

       3200-PGAL-ROLL-FRWD-UPDT-X.
           EXIT.

      *----------------------------
       3210-PGAL-ROLL-FRWD.
      *----------------------------

           SET L7280-FCN-DRVR-PRIMARY       TO TRUE.
           MOVE WS-EFF-DT                   TO L7280-EFF-DT.
           MOVE WS-OLD-ALLOC-TYP-CD         TO L7280-FROM-ALLOC-TYP-CD.
           MOVE WS-NEW-ALLOC-TYP-CD         TO L7280-TO-ALLOC-TYP-CD.
           MOVE WS-PGAL-SEQ-NUM             TO L7280-PGAL-SEQ-NUM.
           MOVE RCNTX-CNTRXN-AMT            TO L7280-REALLOC-PRIN-AMT.
           MOVE RCNTX-CDA-TYP-CD            TO L7280-CDA-TYP-CD.
           MOVE RCNTX-POL-PAYO-NUM          TO L7280-POL-PAYO-NUM.
           MOVE RCNTX-CDA-EFF-IDT-NUM       TO L7280-CDA-EFF-IDT-NUM.
           MOVE RCNTX-CDA-SEQ-NUM           TO L7280-CDA-SEQ-NUM.

           PERFORM  7280-2000-PROCESS-REQST
               THRU 7280-2000-PROCESS-REQST-X.

           IF  NOT L7280-RETRN-OK
      *MSG: 7280 CALL FAILED
               MOVE 'CS77020001'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
           END-IF.

       3210-PGAL-ROLL-FRWD-X.
           EXIT.

      *----------------------------
       3360-PGAL-ROLL-FRWD-EDIT.
      *----------------------------

           IF  WS-NEW-ALLOC-TYP-CD = WS-OLD-ALLOC-TYP-CD
           OR  WS-PGAL-UPDATE-NO
           OR  WS-CNTRXN-AMT-CHNG-YES
               GO TO 3360-PGAL-ROLL-FRWD-EDIT-X
           END-IF.

           PERFORM  7280-1000-BUILD-PARM-INFO
               THRU 7280-1000-BUILD-PARM-INFO-X.

           SET L7280-PRCES-TYP-EDIT-ONLY    TO TRUE.

           PERFORM  3210-PGAL-ROLL-FRWD
               THRU 3210-PGAL-ROLL-FRWD-X.

       3360-PGAL-ROLL-FRWD-EDIT-X.
           EXIT.

      *----------------------------
       7000-LOCK-CNTX-RECORD.
      *----------------------------

           MOVE MIR-POL-ID                  TO WPOL-POL-ID.

           PERFORM  POL-2000-UPDATE-TWRK-TS
               THRU POL-2000-UPDATE-TWRK-TS-X.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG: PROCESS FAILED - RE-ENTER DATA AS ANOTHER PROCESS HAS
      *      UPDATED - TABLE (@1), KEY @2
               MOVE 'XS00000303'            TO WGLOB-MSG-REF-INFO
               MOVE 'POL'                   TO WGLOB-MSG-PARM (1)
               MOVE WPOL-KEY                TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 7000-LOCK-CNTX-RECORD-X
           END-IF.

           IF  NOT WPOL-IO-OK
      *MSG: RECORD NOT FOUND
               MOVE 'XS00000001'            TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY                TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 7000-LOCK-CNTX-RECORD-X
           END-IF.

           MOVE RPOL-POL-ID                 TO WCNTX-POL-ID.
           MOVE MIR-CNTRXN-TS               TO WCNTX-CNTRXN-TS.
           MOVE WS-MIR-CNTRXN-SEQ-NUM       TO WCNTX-CNTRXN-SEQ-NUM.

           PERFORM  CNTX-1000-READ-FOR-UPDATE
               THRU CNTX-1000-READ-FOR-UPDATE-X.

           IF  NOT WCNTX-IO-OK
      *MSG: CNTX (@1) NOT FOUND
               MOVE 'CS77020002'            TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY                TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 7000-LOCK-CNTX-RECORD-X
           END-IF.

           MOVE RCNTX-CDA-EFF-IDT-NUM       TO L1660-INVERTED-DATE.
           PERFORM  1660-3000-CONVERT-INV-TO-INT
               THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE         TO WS-EFF-DT.

           MOVE RCNTX-REC-INFO              TO HCNTX-REC-INFO.

           PERFORM  9350-SETUP-AUDIT-INFO
               THRU 9350-SETUP-AUDIT-INFO-X.

       7000-LOCK-CNTX-RECORD-X.
           EXIT.

      *----------------------------
       8100-EDIT-KEY-FIELDS.
      *----------------------------

           PERFORM  8110-EDIT-POL-ID
               THRU 8110-EDIT-POL-ID-X.

           PERFORM  8120-EDIT-CNTRXN-TS
               THRU 8120-EDIT-CNTRXN-TS-X.

           PERFORM  8130-EDIT-CNTRXN-SEQ-NUM
               THRU 8130-EDIT-CNTRXN-SEQ-NUM-X.

       8100-EDIT-KEY-FIELDS-X.
           EXIT.

      *----------------------------
       8110-EDIT-POL-ID.
      *----------------------------

           MOVE MIR-POL-ID                  TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
      *MSG: RECORD NOT FOUND
               MOVE 'CS77020003'            TO WGLOB-MSG-REF-INFO
               MOVE  MIR-POL-ID             TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 8110-EDIT-POL-ID-X
           END-IF.

       8110-EDIT-POL-ID-X.
           EXIT.

      *----------------------------
       8120-EDIT-CNTRXN-TS.
      *----------------------------

           PERFORM  1646-1000-BUILD-PARM-INFO
               THRU 1646-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CNTRXN-TS               TO L1646-TIMESTAMP.

           PERFORM  1646-1000-EDIT-TIMESTAMP
               THRU 1646-1000-EDIT-TIMESTAMP-X.

           IF  NOT L1646-EDIT-OK
      *MSG: INVALID TIMESTAMP
               MOVE 'CS77020004'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
           END-IF.

       8120-EDIT-CNTRXN-TS-X.
           EXIT.

      *----------------------------
       8130-EDIT-CNTRXN-SEQ-NUM.
      *----------------------------

           MOVE MIR-CNTRXN-SEQ-NUM          TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-CNTRXN-SEQ-NUM
                                            TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
           MOVE ZERO                        TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00        TO WS-MIR-CNTRXN-SEQ-NUM
           ELSE
      *MSG: INVALID CONTRIBUTION SEQUENCE NUMBER
               MOVE 'CS77020005'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               MOVE ZERO                    TO WS-MIR-CNTRXN-SEQ-NUM
           END-IF.

       8130-EDIT-CNTRXN-SEQ-NUM-X.
           EXIT.

      *----------------------------
       8200-EDIT-DATA-FIELDS.
      *----------------------------

           PERFORM  8210-EDIT-CLI-ID
               THRU 8210-EDIT-CLI-ID-X.

           PERFORM  8230-EDIT-CNTRXN-RPT-CD
               THRU 8230-EDIT-CNTRXN-RPT-CD-X.

           PERFORM  8270-EDIT-CNTRXN-COMNT-TXT
               THRU 8270-EDIT-CNTRXN-COMNT-TXT-X.

           IF  HCNTX-CNTRXN-RPT-ACTV-RPT
           OR  HCNTX-CNTRXN-RPT-RPT-LATE
      *MSG: REPORTING STATUS IS 'REPORTED'
               MOVE 'CS77020008' TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8200-EDIT-DATA-FIELDS-X
           END-IF.

           PERFORM  8220-EDIT-CNTRXN-STAT-CD
               THRU 8220-EDIT-CNTRXN-STAT-CD-X.

           PERFORM  8240-EDIT-CNTRXN-AMT
               THRU 8240-EDIT-CNTRXN-AMT-X.

           PERFORM  8250-EDIT-CNTRXN-TYP-CD
               THRU 8250-EDIT-CNTRXN-TYP-CD-X.

           PERFORM  8260-EDIT-CNTRXN-TAX-YR
               THRU 8260-EDIT-CNTRXN-TAX-YR-X.

           PERFORM  8280-EDIT-CDSA-RECORD
               THRU 8280-EDIT-CDSA-RECORD-X.

           PERFORM  8290-EDIT-CNTRXN-REVRS-CD
               THRU 8290-EDIT-CNTRXN-REVRS-CD-X.

           PERFORM  8300-EDIT-CNTRXN-RPT-SEQ-NUM
               THRU 8300-EDIT-CNTRXN-RPT-SEQ-NUM-X.

           MOVE MIR-CNTRXN-CLI-TAX-ID       TO RCNTX-CNTRXN-CLI-TAX-ID.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           PERFORM  8310-GET-NEW-ALLOC-INSTR
               THRU 8310-GET-NEW-ALLOC-INSTR-X.

           PERFORM  8320-GET-ORIG-ALLOC-INSTR
               THRU 8320-GET-ORIG-ALLOC-INSTR-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8200-EDIT-DATA-FIELDS-X
           END-IF.

           PERFORM  3360-PGAL-ROLL-FRWD-EDIT
               THRU 3360-PGAL-ROLL-FRWD-EDIT-X.

       8200-EDIT-DATA-FIELDS-X.
           EXIT.


      *----------------------------
       8210-EDIT-CLI-ID.
      *----------------------------

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE SPACE                       TO L0620-SCREEN-NAME.
           MOVE MIR-CLI-ID                  TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X

           IF  NOT L2435-RETRN-OK
      *MSG: CLIENT (@1) NOT FOUND
               MOVE 'CS77020006'            TO WGLOB-MSG-REF-INFO
               MOVE MIR-CLI-ID              TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8210-EDIT-CLI-ID-X
           END-IF.

           MOVE MIR-CLI-ID                  TO RCNTX-CLI-ID.

           IF  L2435-CLI-SEX-CD = 'C'
               MOVE L2435-CLI-FULL-NAME     TO L0620-CLI-CO-NM
           ELSE
               MOVE L2435-CLI-GIV-NM        TO L0620-CLI-GIV-NM
               MOVE L2435-CLI-SUR-NM        TO L0620-CLI-SUR-NM
               MOVE L2435-CLI-MID-INIT-NM   TO L0620-CLI-MID-INIT-NM
               MOVE L2435-CLI-SFX-NM        TO L0620-CLI-SFX-NM
           END-IF.

           MOVE L2435-CLI-SEX-CD            TO L0620-CLI-SEX-CD.

           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.

           IF  L0620-RETRN-OK
               MOVE L0620-SCREEN-NAME       TO MIR-DV-OWN-CLI-NM
           END-IF.


       8210-EDIT-CLI-ID-X.
           EXIT.

      *----------------------------
       8220-EDIT-CNTRXN-STAT-CD.
      *----------------------------

           IF  HCNTX-CNTRXN-STAT-ERROR
      *MSG: RECORD STATUS IS 'ERROR'
               MOVE 'CS77020007'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 8220-EDIT-CNTRXN-STAT-CD-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'CNTRXN-STAT-CD'             TO L8960-AV-TBL-CD.
           MOVE MIR-CNTRXN-STAT-CD           TO L8960-AV-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.

           IF  L8960-RETRN-OK
               CONTINUE
           ELSE
      *MSG: INVALID CONTRIBUTION STATUS CODE
               MOVE 'CS77020025'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 8220-EDIT-CNTRXN-STAT-CD-X
           END-IF.

           MOVE MIR-CNTRXN-STAT-CD          TO RCNTX-CNTRXN-STAT-CD.

       8220-EDIT-CNTRXN-STAT-CD-X.
           EXIT.

      *----------------------------
       8230-EDIT-CNTRXN-RPT-CD.
      *----------------------------

           MOVE MIR-CNTRXN-RPT-CD TO WS-CNTRXN-RPT-CD.

           EVALUATE TRUE

               WHEN HCNTX-CNTRXN-RPT-ACTV-RPT

                 IF NOT (WS-CNTRXN-RPT-RPT-LATE
                 OR      WS-CNTRXN-RPT-ACTV-RPT)
      *MSG:INVALID REPORTING STATUS @1
                    MOVE 'CS77020029'      TO WGLOB-MSG-REF-INFO
                    MOVE MIR-CNTRXN-RPT-CD TO WGLOB-MSG-PARM (1)
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    MOVE 1            TO WGLOB-MSG-ERROR-SW
                    GO TO 8230-EDIT-CNTRXN-RPT-CD-X
                 END-IF

               WHEN HCNTX-CNTRXN-RPT-RPT-LATE

                 IF NOT (WS-CNTRXN-RPT-ACTV-RPT
                 OR      WS-CNTRXN-RPT-RPT-LATE)
      *MSG:INVALID REPORTING STATUS @1
                    MOVE 'CS77020029'      TO WGLOB-MSG-REF-INFO
                    MOVE MIR-CNTRXN-RPT-CD TO WGLOB-MSG-PARM (1)
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    MOVE 1            TO WGLOB-MSG-ERROR-SW
                    GO TO 8230-EDIT-CNTRXN-RPT-CD-X
                 END-IF

               WHEN HCNTX-CNTRXN-RPT-CNCL

                 IF NOT (WS-CNTRXN-RPT-ACTV
                 OR      WS-CNTRXN-RPT-CNCL)
      *MSG:INVALID REPORTING STATUS @1
                    MOVE 'CS77020029'      TO WGLOB-MSG-REF-INFO
                    MOVE MIR-CNTRXN-RPT-CD TO WGLOB-MSG-PARM (1)
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    MOVE 1            TO WGLOB-MSG-ERROR-SW
                    GO TO 8230-EDIT-CNTRXN-RPT-CD-X
                 END-IF

           END-EVALUATE.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'CNTRXN-RPT-CD'              TO L8960-AV-TBL-CD.
           MOVE MIR-CNTRXN-RPT-CD            TO L8960-AV-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.

           IF  L8960-RETRN-OK
               CONTINUE
           ELSE
      *MSG: INVALID CONTRIBUTION REPORT CODE
               MOVE 'CS77020026'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 8230-EDIT-CNTRXN-RPT-CD-X
           END-IF.

           MOVE MIR-CNTRXN-RPT-CD           TO RCNTX-CNTRXN-RPT-CD.

       8230-EDIT-CNTRXN-RPT-CD-X.
           EXIT.

      *----------------------------
       8240-EDIT-CNTRXN-AMT .
      *----------------------------

           SET WS-CNTRXN-AMT-CHNG-NO        TO TRUE.

           MOVE MIR-CNTRXN-AMT              TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-CNTRXN-AMT    TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
           MOVE +2                          TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V02        TO RCNTX-CNTRXN-AMT
           ELSE
      *MSG: INVALID CONTRIBUTION AMOUNT
               MOVE 'CS77020024'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 8240-EDIT-CNTRXN-AMT-X
           END-IF.

           IF RCNTX-CNTRXN-AMT NOT = HCNTX-CNTRXN-AMT
               SET WS-CNTRXN-AMT-CHNG-YES   TO TRUE
      *MSG: CONTRIBUTION AMOUNT CHANGED, REQUIRED MANUAL UPDATE ON PGAL
               MOVE 'CS77020027'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8240-EDIT-CNTRXN-AMT-X
           END-IF.


       8240-EDIT-CNTRXN-AMT-X.
           EXIT.

      *----------------------------
       8250-EDIT-CNTRXN-TYP-CD .
      *----------------------------

           IF  MIR-CNTRXN-TYP-CD = RCNTX-CNTRXN-TYP-CD
               GO TO 8250-EDIT-CNTRXN-TYP-CD-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'CNTRXN-TYP-CD'              TO L8960-AV-TBL-CD.
           MOVE MIR-CNTRXN-TYP-CD            TO L8960-AV-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.

           IF  L8960-RETRN-OK
               CONTINUE
           ELSE
      *MSG: INVALID CONTRIBUTION TYPE CODE
               MOVE 'CS77020010'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 8250-EDIT-CNTRXN-TYP-CD-X
           END-IF.

           MOVE MIR-CNTRXN-TYP-CD           TO RCNTX-CNTRXN-TYP-CD.

       8250-EDIT-CNTRXN-TYP-CD-X.
           EXIT.

      *----------------------------
       8260-EDIT-CNTRXN-TAX-YR .
      *----------------------------

           MOVE SPACES                      TO WS-TAX-YEAR-CHNG-SW.
           MOVE MIR-CNTRXN-TAX-YR           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-CNTRXN-TAX-YR TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
           MOVE ZERO                        TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00        TO RCNTX-CNTRXN-TAX-YR
           ELSE
      *MSG: INVALID TAX YEAR
               MOVE 'CS77020011'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 8260-EDIT-CNTRXN-TAX-YR-X
           END-IF.

           IF  RCNTX-CNTRXN-TAX-YR = HCNTX-CNTRXN-TAX-YR
               CONTINUE
           ELSE
               SET WS-TAX-YEAR-CHNG     TO TRUE
      *MSG: TAX YEAR CHANGED TO @1
               MOVE 'CS77020030'        TO WGLOB-MSG-REF-INFO
               MOVE RCNTX-CNTRXN-TAX-YR TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


       8260-EDIT-CNTRXN-TAX-YR-X.
           EXIT.

      *----------------------------
       8270-EDIT-CNTRXN-COMNT-TXT .
      *----------------------------

           IF  MIR-CNTRXN-COMNT-TXT = SPACE
      *MSG: AUDIT HISTORY USER COMMENT IS EMPTY
               MOVE 'CS77020012'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-CNTRXN-COMNT-TXT     TO RCNTX-CNTRXN-COMNT-TXT-TXT.

           MOVE LENGTH OF RCNTX-CNTRXN-COMNT-TXT-TXT
             TO I.

           PERFORM
               VARYING I
               FROM LENGTH OF RCNTX-CNTRXN-COMNT-TXT-TXT BY -1
               UNTIL RCNTX-CNTRXN-COMNT-TXT-TXT (I:1) NOT = SPACE
               OR I = 1

               CONTINUE

           END-PERFORM.

           MOVE I                        TO RCNTX-CNTRXN-COMNT-TXT-LEN.

       8270-EDIT-CNTRXN-COMNT-TXT-X.
           EXIT.

      *----------------------------
       8280-EDIT-CDSA-RECORD .
      *----------------------------

           PERFORM  8281-EDIT-POL-PAYO-NUM
               THRU 8281-EDIT-POL-PAYO-NUM-X.

           PERFORM  8282-EDIT-CDA-SEQ-NUM
               THRU 8282-EDIT-CDA-SEQ-NUM-X.

           PERFORM  8283-EDIT-CDA-EFF-IDT-NUM
               THRU 8283-EDIT-CDA-EFF-IDT-NUM-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8280-EDIT-CDSA-RECORD-X
           END-IF.

           IF  MIR-POL-ID          = RCNTX-POL-ID
           AND MIR-CDA-TYP-CD      = RCNTX-CDA-TYP-CD
           AND WS-MIR-POL-PAYO-NUM = RCNTX-POL-PAYO-NUM
           AND WS-CDA-EFF-IDT-NUM  = RCNTX-CDA-EFF-IDT-NUM
           AND WS-MIR-CDA-SEQ-NUM  = RCNTX-CDA-SEQ-NUM
               GO TO 8280-EDIT-CDSA-RECORD-X
           END-IF.

           IF  RCNTX-CDA-TYP-CD = SPACE
               MOVE MIR-CDA-TYP-CD          TO RCNTX-CDA-TYP-CD
               MOVE WS-MIR-POL-PAYO-NUM     TO RCNTX-POL-PAYO-NUM
               MOVE WS-CDA-EFF-IDT-NUM      TO RCNTX-CDA-EFF-IDT-NUM
               MOVE WS-MIR-CDA-SEQ-NUM      TO RCNTX-CDA-SEQ-NUM
               GO TO 8280-EDIT-CDSA-RECORD-X
           END-IF.

           MOVE MIR-POL-ID                  TO WCDSA-POL-ID
           MOVE MIR-CDA-TYP-CD              TO WCDSA-CDA-TYP-CD.
           MOVE WS-MIR-POL-PAYO-NUM         TO WCDSA-POL-PAYO-NUM.
           MOVE WS-CDA-EFF-IDT-NUM          TO WCDSA-CDA-EFF-IDT-NUM.
           MOVE WS-MIR-CDA-SEQ-NUM          TO WCDSA-CDA-SEQ-NUM.

           PERFORM  CDSA-1000-READ
               THRU CDSA-1000-READ-X.

           IF  NOT WCDSA-IO-OK
      *MSG: CDSA (@1) NOT FOUND
               MOVE 'CS77020013'            TO WGLOB-MSG-REF-INFO
               MOVE WCDSA-KEY               TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 8280-EDIT-CDSA-RECORD-X
           END-IF.

      *MSG: CDSA KEY FIELDS CHANGED ON CNTX
           MOVE 'CS77020014'                TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           IF  WGLOB-MSG-SEVRTY-FATAL
               GO TO 8280-EDIT-CDSA-RECORD-X
           END-IF.

           MOVE MIR-CDA-TYP-CD              TO RCNTX-CDA-TYP-CD.
           MOVE WS-MIR-POL-PAYO-NUM         TO RCNTX-POL-PAYO-NUM.
           MOVE WS-CDA-EFF-IDT-NUM          TO RCNTX-CDA-EFF-IDT-NUM.
           MOVE WS-MIR-CDA-SEQ-NUM          TO RCNTX-CDA-SEQ-NUM.

       8280-EDIT-CDSA-RECORD-X.
           EXIT.

      *----------------------------
       8281-EDIT-POL-PAYO-NUM.
      *----------------------------

           MOVE MIR-POL-PAYO-NUM            TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-POL-PAYO-NUM  TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
           MOVE ZERO                        TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00        TO WS-MIR-POL-PAYO-NUM
           ELSE
      *MSG: INVALID CDA PAYOUT NUMBER
               MOVE 'CS77020015'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
           END-IF.

       8281-EDIT-POL-PAYO-NUM-X.
           EXIT.

      *----------------------------
       8282-EDIT-CDA-SEQ-NUM.
      *----------------------------

           MOVE MIR-CDA-SEQ-NUM             TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-CDA-SEQ-NUM   TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
           MOVE ZERO                        TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               COMPUTE WS-MIR-CDA-SEQ-NUM = 1000
                                          - L0280-OUTPUT-V00
           ELSE
      *MSG: INVALID CDA SEQUENCE NUMBER
               MOVE 'CS77020016'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
           END-IF.

       8282-EDIT-CDA-SEQ-NUM-X.
           EXIT.

      *----------------------------
       8283-EDIT-CDA-EFF-IDT-NUM.
      *----------------------------

022455*    MOVE MIR-CDA-EFF-IDT-NUM         TO L1640-EXTERNAL-DATE.
022455     MOVE MIR-DV-EFF-DT               TO L1640-EXTERNAL-DATE.

020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  NOT L1640-RETRN-OK
      *MSG: INVALID CDA EFFECTIVE DATE
               MOVE 'CS77020023'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 8283-EDIT-CDA-EFF-IDT-NUM-X
           END-IF.

022455     MOVE  L1640-INTERNAL-DATE        TO L1660-INTERNAL-DATE.

           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.

           MOVE L1660-INVERTED-DATE         TO WS-CDA-EFF-IDT-NUM.

       8283-EDIT-CDA-EFF-IDT-NUM-X.
           EXIT.

      *----------------------------
       8290-EDIT-CNTRXN-REVRS-CD .
      *----------------------------

           IF  MIR-CNTRXN-REVRS-CD = RCNTX-CNTRXN-REVRS-CD
               GO TO 8290-EDIT-CNTRXN-REVRS-CD-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'CNTRXN-REVRS-CD'           TO L8960-AV-TBL-CD.
           MOVE MIR-CNTRXN-REVRS-CD         TO L8960-AV-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.

           IF  L8960-RETRN-OK
               MOVE MIR-CNTRXN-REVRS-CD     TO RCNTX-CNTRXN-REVRS-CD
           ELSE
      *MSG: INVALID REVERSAL CODE
               MOVE 'CS77020017'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
           END-IF.

       8290-EDIT-CNTRXN-REVRS-CD-X.
           EXIT.

      *----------------------------
       8300-EDIT-CNTRXN-RPT-SEQ-NUM .
      *----------------------------

           MOVE MIR-CNTRXN-RPT-SEQ-NUM      TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-CNTRXN-RPT-SEQ-NUM
                                            TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
           MOVE ZERO                        TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00        TO WS-MIR-CNTRXN-RPT-SEQ-NUM
           ELSE
      *MSG: INVALID REPORT SEQUENCE NUMBER
               MOVE 'CS77020018'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 8300-EDIT-CNTRXN-RPT-SEQ-NUM-X
           END-IF.

           IF  NOT RPOL-POL-CTRY-US
           OR  WS-MIR-CNTRXN-RPT-SEQ-NUM = ZERO
               GO TO 8300-EDIT-CNTRXN-RPT-SEQ-NUM-X
           END-IF.

           MOVE MIR-POL-ID                  TO WUSRP-POL-ID.
           MOVE MIR-CNTRXN-TAX-YR           TO WUSRP-USRP-TAX-YR.
           MOVE WS-MIR-CNTRXN-RPT-SEQ-NUM   TO WUSRP-USRP-SEQ-NUM.

           PERFORM  USRP-1000-READ
               THRU USRP-1000-READ-X.

           IF  WUSRP-IO-OK
               MOVE WS-MIR-CNTRXN-RPT-SEQ-NUM
                                            TO RCNTX-CNTRXN-RPT-SEQ-NUM
               GO TO 8300-EDIT-CNTRXN-RPT-SEQ-NUM-X
           END-IF.

      *MSG: USRP RECORD NOT FOUND
           MOVE 'CS77020019'                TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           IF  WGLOB-MSG-SEVRTY-FATAL
               GO TO 8300-EDIT-CNTRXN-RPT-SEQ-NUM-X
           END-IF.

           MOVE WS-MIR-CNTRXN-RPT-SEQ-NUM   TO RCNTX-CNTRXN-RPT-SEQ-NUM.

       8300-EDIT-CNTRXN-RPT-SEQ-NUM-X.
           EXIT.

      *----------------------------
       8310-GET-NEW-ALLOC-INSTR.
      *----------------------------

           MOVE SPACES                      TO WS-NEW-ALLOC-TYP-CD.

           PERFORM  7800-0000-INIT-PARM-INFO
               THRU 7800-0000-INIT-PARM-INFO-X.

           MOVE RPOL-POL-ID                 TO L7800-POL-ID.

           IF  HCNTX-CDA-TYP-CD = SPACE
               MOVE RPOL-POL-MISC-SUSP-DT   TO L7800-EFF-DT
           ELSE
               MOVE WS-EFF-DT               TO L7800-EFF-DT
           END-IF.

           MOVE MIR-CNTRXN-TYP-CD           TO L7800-CNTRXN-TYP-CD.
           MOVE RCNTX-CNTRXN-TAX-YR         TO L7800-TAX-YR.
           SET L7800-TRXN-DPOS              TO TRUE.
           SET L7800-GET-PLAR-REQ           TO TRUE.
           SET L7800-PRCES-NORMAL           TO TRUE.
           SET L7800-PGAL-ALLOC-REQ         TO TRUE.

           PERFORM  7800-1000-GET-PLAR-INFO
               THRU 7800-1000-GET-PLAR-INFO-X.

           IF  NOT L7800-RETRN-OK
      *MSG: 7800 CALL FAILED
               MOVE 'CS77020020'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 8310-GET-NEW-ALLOC-INSTR-X
           END-IF.


           PERFORM
               VARYING LPGAL-SUB FROM 1 BY 1
               UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
               OR WS-NEW-ALLOC-TYP-CD NOT = SPACE

               IF  L7800-PGAL-DPOS-DFLT (LPGAL-SUB)
                   MOVE L7800-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
                     TO WS-NEW-ALLOC-TYP-CD
               END-IF

           END-PERFORM.

           IF  WS-NEW-ALLOC-TYP-CD = SPACE
      *MSG: NEW ALLOCATION NOT FOUND
               MOVE 'CS77020021'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
           END-IF.

       8310-GET-NEW-ALLOC-INSTR-X.
           EXIT.

      *----------------------------
       8320-GET-ORIG-ALLOC-INSTR.
      *----------------------------

           SET WS-PGAL-UPDATE-YES      TO TRUE.
           SET WS-DPOS-DFLT-NOT-FOUND  TO TRUE.
           MOVE SPACES                 TO WS-OLD-ALLOC-TYP-CD.

           PERFORM  7800-0000-INIT-PARM-INFO
               THRU 7800-0000-INIT-PARM-INFO-X.

           MOVE RPOL-POL-ID                 TO L7800-POL-ID.

           IF  HCNTX-CDA-TYP-CD = SPACE
               MOVE RPOL-POL-MISC-SUSP-DT   TO L7800-EFF-DT
           ELSE
               MOVE HCNTX-CDA-EFF-IDT-NUM   TO L1660-INVERTED-DATE
               PERFORM  1660-3000-CONVERT-INV-TO-INT
                   THRU 1660-3000-CONVERT-INV-TO-INT-X
               MOVE L1660-INTERNAL-DATE     TO L7800-EFF-DT
           END-IF.

           MOVE HCNTX-CNTRXN-TYP-CD         TO L7800-CNTRXN-TYP-CD.
           MOVE HCNTX-CNTRXN-TAX-YR         TO L7800-TAX-YR.
           SET L7800-TRXN-DPOS              TO TRUE.
           SET L7800-GET-PLAR-REQ           TO TRUE.
           SET L7800-PRCES-NORMAL           TO TRUE.
           SET L7800-PGAL-ALLOC-REQ         TO TRUE.

           PERFORM  7800-1000-GET-PLAR-INFO
               THRU 7800-1000-GET-PLAR-INFO-X.

           IF  NOT L7800-RETRN-OK
      *MSG: 7800 CALL FAILED
               MOVE 'CS77020020'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 8320-GET-ORIG-ALLOC-INSTR-X
           END-IF.

           PERFORM

               VARYING LPGAL-SUB FROM 1 BY 1
               UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
               OR WS-OLD-ALLOC-TYP-CD NOT = SPACE

               IF  L7800-PGAL-DPOS-DFLT (LPGAL-SUB)
                   MOVE L7800-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
                     TO WS-OLD-ALLOC-TYP-CD
                     SET WS-DPOS-DFLT-FOUND TO TRUE
               END-IF

           END-PERFORM.

           IF  HCNTX-CDA-TYP-CD = SPACE
               PERFORM  8340-GET-PENDING-PGAL
                   THRU 8340-GET-PENDING-PGAL-X
               GO TO 8320-GET-ORIG-ALLOC-INSTR-X
           ELSE
               IF  WS-OLD-ALLOC-TYP-CD NOT = SPACES
                   MOVE LOW-VALUES           TO WPGAO-KEY
                   MOVE HCNTX-POL-ID         TO WPGAO-POL-ID
                   MOVE HCNTX-CDA-TYP-CD     TO WPGAO-CDA-TYP-CD
                   MOVE HCNTX-POL-PAYO-NUM   TO WPGAO-POL-PAYO-NUM
                   MOVE HCNTX-CDA-EFF-IDT-NUM  TO WPGAO-CDA-EFF-IDT-NUM
                   MOVE HCNTX-CDA-SEQ-NUM    TO WPGAO-CDA-SEQ-NUM
                   MOVE WS-OLD-ALLOC-TYP-CD  TO WPGAO-PGAL-ALLOC-TYP-CD

023271             MOVE WPGAO-KEY            TO WPGAO-ENDBR-KEY
023271*            PERFORM  PGAO-1000-READ
023271*                THRU PGAO-1000-READ-X
023271
023271             PERFORM  PGAO-1000-BROWSE
023271                 THRU PGAO-1000-BROWSE-X
023271
023271             PERFORM  PGAO-2000-READ-NEXT
023271                 THRU PGAO-2000-READ-NEXT-X

                   IF  WPGAO-IO-OK
                       MOVE RPGAL-PGAL-SEQ-NUM  TO WS-PGAL-SEQ-NUM
023271             END-IF
023271
023271             PERFORM  PGAO-3000-END-BROWSE
023271                 THRU PGAO-3000-END-BROWSE-X
023271
023271*            ELSE
023271             IF  NOT WPGAO-IO-OK
      *MSG: ORIGINAL ALLOCATION NOT FOUND
                       MOVE 'CS77020022'     TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                       MOVE 1                TO WGLOB-MSG-ERROR-SW
                   END-IF
               ELSE
      *MSG: ORIGINAL ALLOCATION NOT FOUND
                   MOVE 'CS77020022'         TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 1                    TO WGLOB-MSG-ERROR-SW
                   GO TO 8320-GET-ORIG-ALLOC-INSTR-X
               END-IF
           END-IF.

       8320-GET-ORIG-ALLOC-INSTR-X.
           EXIT.


      *----------------------
       8340-GET-PENDING-PGAL.
      *----------------------

           SET  WS-PGAL-REC-FOUND-NONE   TO TRUE.
           MOVE SPACE              TO WS-SAVE-PGAL-EFF-DT.
           MOVE ZERO               TO WS-SAVE-PGAL-SEQ-NUM.

           MOVE RPOL-POL-ID        TO WPGAM-POL-ID.
           MOVE WWKDT-LOW-DT       TO WPGAM-PGAL-EFF-DT.
           MOVE ZERO               TO WPGAM-PGAL-SEQ-NUM.
           MOVE LOW-VALUE          TO WPGAM-PGAL-ALLOC-TYP-CD.
           MOVE WPGAM-KEY          TO WPGAM-ENDBR-KEY.
           MOVE WWKDT-HIGH-DT      TO WPGAM-ENDBR-PGAL-EFF-DT.
           MOVE 999                TO WPGAM-ENDBR-PGAL-SEQ-NUM.
           MOVE HIGH-VALUE         TO WPGAM-ENDBR-PGAL-ALLOC-TYP-CD.

           PERFORM  PGAM-1000-BROWSE
               THRU PGAM-1000-BROWSE-X.

           PERFORM  PGAM-2000-READ-NEXT
               THRU PGAM-2000-READ-NEXT-X.

           IF  WPGAM-IO-EOF
               PERFORM  PGAM-3000-END-BROWSE
                   THRU PGAM-3000-END-BROWSE-X
               PERFORM  8342-GEN-MANUAL-MSG
                   THRU 8342-GEN-MANUAL-MSG-X
               GO TO 8340-GET-PENDING-PGAL-X
           END-IF.

           MOVE RPGAL-PGAL-SEQ-NUM      TO WS-SAVE-PGAL-SEQ-NUM.
           MOVE RPGAL-PGAL-EFF-DT       TO WS-SAVE-PGAL-EFF-DT.

           IF  WS-DPOS-DFLT-NOT-FOUND
              MOVE RPGAL-PGAL-ALLOC-TYP-CD TO WS-OLD-ALLOC-TYP-CD
           END-IF.

           SET  WS-PGAL-REC-FOUND-ONE   TO TRUE.

           PERFORM  8341-READ-NEXT-PGAL
               THRU 8341-READ-NEXT-PGAL-X
               UNTIL WPGAM-IO-EOF
               OR    WS-PGAL-REC-FOUND-TWO.

           PERFORM  PGAM-3000-END-BROWSE
               THRU PGAM-3000-END-BROWSE-X.

           IF WS-PGAL-REC-FOUND-TWO
               PERFORM  8342-GEN-MANUAL-MSG
                   THRU 8342-GEN-MANUAL-MSG-X
               GO TO 8340-GET-PENDING-PGAL-X
           END-IF.

           IF  WS-OLD-ALLOC-TYP-CD = SPACE
      *MSG: ORIGINAL ALLOCATION NOT FOUND
               MOVE 'CS77020022'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
           END-IF.

           MOVE WS-SAVE-PGAL-EFF-DT         TO WS-EFF-DT.
           MOVE WS-SAVE-PGAL-SEQ-NUM        TO WS-PGAL-SEQ-NUM.

       8340-GET-PENDING-PGAL-X.
           EXIT.

      *-------------------
       8341-READ-NEXT-PGAL.
      *-------------------

           IF RPGAL-PGAL-EFF-DT   NOT = WS-SAVE-PGAL-EFF-DT
           OR RPGAL-PGAL-SEQ-NUM  NOT = WS-SAVE-PGAL-SEQ-NUM
              SET WS-PGAL-REC-FOUND-TWO   TO TRUE
              GO TO 8341-READ-NEXT-PGAL-X
           END-IF.

           IF  RPGAL-PGAL-ALLOC-TYP-CD = WS-OLD-ALLOC-TYP-CD
               MOVE RPGAL-PGAL-EFF-DT        TO WS-SAVE-PGAL-EFF-DT
               MOVE RPGAL-PGAL-SEQ-NUM       TO WS-SAVE-PGAL-SEQ-NUM
           END-IF.

           IF  WS-DPOS-DFLT-NOT-FOUND
           AND WS-OLD-ALLOC-TYP-CD NOT = WS-NEW-ALLOC-TYP-CD
               MOVE RPGAL-PGAL-ALLOC-TYP-CD  TO WS-OLD-ALLOC-TYP-CD
           END-IF.

           PERFORM  PGAM-2000-READ-NEXT
               THRU PGAM-2000-READ-NEXT-X.

       8341-READ-NEXT-PGAL-X.
           EXIT.


      *--------------------
       8342-GEN-MANUAL-MSG.
      *--------------------

           SET WS-PGAL-UPDATE-NO   TO TRUE
           MOVE SPACE              TO WS-OLD-ALLOC-TYP-CD
      *MSG: MANUAL UPDATE ON PGAL AND POLT INFORMATION MAY BE REQUIRED
           MOVE 'CS77020028'                  TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       8342-GEN-MANUAL-MSG-X.
           EXIT.


      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      *----------------------------
       9200-MOVE-RECORD-TO-MIR.
      *----------------------------

           MOVE RCNTX-CNTRXN-TYP-CD
             TO MIR-CNTRXN-TYP-CD.

           MOVE RCNTX-CLI-ID
             TO MIR-CLI-ID.

           MOVE RCNTX-CNTRXN-CLI-TAX-ID
             TO MIR-CNTRXN-CLI-TAX-ID.

020874*    COMPUTE L0290-INPUT-NUMBER = RCNTX-CNTRXN-TAX-YR.
020874     MOVE RCNTX-CNTRXN-TAX-YR         TO L0290-INPUT-V00.
           MOVE ZERO                        TO L0290-PRECISION
           MOVE LENGTH OF MIR-CNTRXN-TAX-YR TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA           TO MIR-CNTRXN-TAX-YR.

020874*    COMPUTE L0290-INPUT-NUMBER = RCNTX-CNTRXN-AMT
020874*                               * 100.
020874     MOVE RCNTX-CNTRXN-AMT            TO L0290-INPUT-V02.
           MOVE +2                          TO L0290-PRECISION
           SET L0290-SIGN-SUPPRESS          TO TRUE.
           MOVE LENGTH OF MIR-CNTRXN-AMT    TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA           TO MIR-CNTRXN-AMT.

           MOVE RCNTX-CDA-TYP-CD
             TO MIR-CDA-TYP-CD.

020874*    COMPUTE L0290-INPUT-NUMBER = RCNTX-POL-PAYO-NUM.
020874     MOVE RCNTX-POL-PAYO-NUM          TO L0290-INPUT-V00.
           MOVE ZERO                        TO L0290-PRECISION
           MOVE LENGTH OF MIR-POL-PAYO-NUM  TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA           TO MIR-POL-PAYO-NUM.

           MOVE RCNTX-CDA-EFF-IDT-NUM       TO L1660-INVERTED-DATE.
           PERFORM  1660-3000-CONVERT-INV-TO-INT
               THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE         TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
022455*    MOVE L1640-EXTERNAL-DATE         TO MIR-CDA-EFF-IDT-NUM.
022455     MOVE L1640-EXTERNAL-DATE         TO MIR-DV-EFF-DT.

           IF  RCNTX-CDA-SEQ-NUM = ZERO
020874*        COMPUTE L0290-INPUT-NUMBER = ZERO
020874         MOVE ZERO                    TO L0290-INPUT-V00
           ELSE
020874*        COMPUTE L0290-INPUT-NUMBER = 1000 - RCNTX-CDA-SEQ-NUM
020874         COMPUTE L0290-INPUT-V00 = 1000 - RCNTX-CDA-SEQ-NUM
           END-IF.

           MOVE ZERO                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CDA-SEQ-NUM   TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA           TO MIR-CDA-SEQ-NUM.

           MOVE RCNTX-CNTRXN-REVRS-CD
             TO MIR-CNTRXN-REVRS-CD.

020874*    COMPUTE L0290-INPUT-NUMBER = RCNTX-CNTRXN-RPT-SEQ-NUM.
020874     MOVE RCNTX-CNTRXN-RPT-SEQ-NUM    TO L0290-INPUT-V00.
           MOVE ZERO                        TO L0290-PRECISION
           MOVE LENGTH OF MIR-CNTRXN-RPT-SEQ-NUM TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA           TO MIR-CNTRXN-RPT-SEQ-NUM.

           MOVE RCNTX-CNTRXN-RPT-CD
             TO MIR-CNTRXN-RPT-CD.

           MOVE RCNTX-CNTRXN-STAT-CD
             TO MIR-CNTRXN-STAT-CD.

035626*    MOVE RCNTX-CNTRXN-COMNT-TXT
035626     MOVE RCNTX-CNTRXN-COMNT-TXT-TXT
             TO MIR-CNTRXN-COMNT-TXT.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *----------------------
       9350-SETUP-AUDIT-INFO.
      *----------------------

           IF  WGLOB-AUDIT-REQUESTED
      *        PERFORM  CNTX-1000-CALL-AUDIT
      *            THRU CNTX-1000-CALL-AUDIT-X
               CONTINUE
           END-IF.

       9350-SETUP-AUDIT-INFO-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1646-0000-INIT-PARM-INFO
025970         THRU 1646-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  7280-0000-INIT-PARM-INFO
025970         THRU 7280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7800-0000-INIT-PARM-INFO
025970         THRU 7800-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.
025970
025970     MOVE MIR-BUS-FCN-ID
025970       TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY NCPPCVGS.
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  POL
                                '$VAR2'   BY 'POL'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
025970 COPY XCPS8090.
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0620.
      /
       COPY CCPS2435.
       COPY CCPL2435.
      /
       COPY CCPS7800.
       COPY CCPL7800.
      /
       COPY CCPS7280.
       COPY CCPL7280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
       COPY XCPS1646.
       COPY XCPL1646.
      /
025970 COPY XCPS1660.
       COPY XCPL1660.
      /
021930*COPY XCPS8090.
       COPY XCPL8090.

       COPY XCPS8960.
       COPY XCPL8960.

      *COPY CCPLCNTX.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.

       COPY CCPUPOL.

       COPY CCPNCVG.

       COPY CCPNCDSA.

       COPY CCPNUSRP.

021930*COPY CCPFCNTX.
021930*COPY CCPNCNTX.
       COPY CCPUCNTX.
021930*COPY CCPACNTX.
      /
023271 COPY CCPBPGAO.
023271*COPY CCPNPGAO.
       COPY CCPBPGAM.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM7702
      *****************************************************************
