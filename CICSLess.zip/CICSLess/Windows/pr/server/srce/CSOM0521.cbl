      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0521.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0521                                         **
      **  REMARKS:  MAINTAIN THE PACKAGING MATRIX (PACK) TABLE.      **
      **                                                             **
      **            THIS PROGRAM PERFORMS TABLE MAINTENANCE          **
      **            FUNCTIONS FOR THE PACKAGING MATRIX (PACK) TABLE. **
      **            THE MATRIX DEFINES THE PLANS THAT ARE ALLOWED TO **
      **            BE SOLD TOGETHER.  ALL BASIC OR ADDITIONAL PLANS **
      **            ENTERED FOR PACKAGING MUST ALREADY EXIST ON THE  **
      **            PLAN HEADER (PH) TABLE.                          **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       DATA ARCHITECTURE MODIFICATIONS                  **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010302**  5.6       ADD PROCESSING FOR NEW PACKING KEY FIELD         **
010302**            LOCATION GROUP                                   **
010311**  5.6       CLEAN-UP                                         **
010418**  5.6       ADD PACK ABILITY TO KLON RECORDS AND             **
010418**            ABILITY TO FUNCTION AT MULTI-CO-LEVEL            **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       MESSAGE SUPPORT - REMOVAL OF XCPPMEXT            **
014221**  6.2       LOGICAL RECORD LOCKING                           **
014591**  6.2       COMBINE PLAN-ID & RS                             **
016483**  6.2       MESSAGE CLEANUP                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018629**  6.4       CLEANUP FCN ID                                   **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0521'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
014221 COPY XCWL8090.

       COPY XCWEBLCH.
014221 COPY CCWWLOCK.
016537*COPY XCWWMATC.
021930*COPY XCWWWKDT.

       01  WS-PGM-WORK-AREA.
016548*    05  WS-LINE                      PIC S9(4)  COMP SYNC.
016548     05  WS-LINE                      PIC S9(4)  BINARY SYNC.
016548*    05  WS-NUMBER-OF-DISPLAY-LINES   PIC S9(4)  COMP VALUE +100.
025970*    05  WS-NUMBER-OF-DISPLAY-LINES   PIC S9(4)
025970*                                     BINARY VALUE +100.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '2030' '2031'
                                                  '2032' '2033'
018629*                                           '2034' '2045'
018629                                            '2034' '2035'
                                                  '2036'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '2030'.
               88  WS-BUS-FCN-CREATE        VALUE '2031'.
               88  WS-BUS-FCN-UPDATE        VALUE '2032'.
               88  WS-BUS-FCN-DELETE        VALUE '2033'.
               88  WS-BUS-FCN-LIST          VALUE '2034'.
               88  WS-BUS-FCN-SUMMARY       VALUE '2035'.
               88  WS-BUS-FCN-KLON          VALUE '2036'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '2030'.
           05  WS-KEY-EDIT-VALIDITY-SW      PIC X(01)  VALUE 'Y'.
               88  WS-KEY-EDIT-VALID        VALUE 'Y'.
               88  WS-KEY-EDIT-INVALID      VALUE 'N'.
           05  WS-DATA-EDIT-VALIDITY-SW     PIC X(01)  VALUE 'Y'.
               88  WS-DATA-EDIT-VALID       VALUE 'Y'.
               88  WS-DATA-EDIT-INVALID     VALUE 'N'.
014591*    05  WS-HOLD-PLAN-ID.
014591*        10  WS-HOLD-PLAN-CODE        PIC X(05).
014591*        10  WS-HOLD-RATE-SCALE       PIC X(01).
014591     05  WS-HOLD-PLAN-ID              PIC X(06).
           05  WS-HOLD-ADDL-LIST-TYPE       PIC X(01).
           05  WS-SAVE-ADDL-LIST-TYPE       PIC X(01).
           05  WS-ADDL-PLN-TYP-CHG-SW       PIC X(01).
               88  WS-ADDL-PLN-TYP-CHGED    VALUE 'Y'.
557660     05  WS-ADDTNL-PLANS-FOUND-SW     PIC X(01).
557660         88  WS-ADDTNL-PLANS-FOUND    VALUE 'Y'.
557660         88  WS-NO-ADDTNL-PLANS-FOUND VALUE 'N'.
010418     05  COUNT-KLON-RECS              PIC 9(4).
010418     05  HOLD-LAST-PACK-KEY           PIC X(17).

025970 01  WS-CONSTANTS.
025970     05  WS-NUMBER-OF-DISPLAY-LINES     PIC S9(4) BINARY.
025970         88  WS-NUMBER-OF-LINES-DEFAULT VALUE +100.
025970     05  WS-TWRK-KEY                    PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT        VALUE '2030'.
      /
       COPY CCFWPACK.
       COPY CCFRPACK.
      /
010418 COPY CCFRSCOM.
010418 COPY CCFWSCOM.
      /
010302 COPY CCFREDIT.
010302 COPY CCFWEDIT.
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

      /
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0521.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708

           SET MIR-RETRN-OK          TO  TRUE.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *********************
       2000-PROCESS-REQUEST.
      *********************

      *    1) BACK OUT FROM DELETE FUNCTION IF DELETE NOT VERIFIED
      *    2) VALIDATE FUNCTION CODE (I.E. I, M, C, D, ETC.)
      *    3) CHECK SECURITY LEVEL FOR FUNCTION REQUESTED
      *    4) PROCESS SCREEN FUNCTIONS
      *       - PERFORM INITIAL EDITS
      *       - PROCESS EACH FUNCTION INDIVIDUALLY
      *       - ALWAYS EXIT THRU 2000-PROCESS-TRANSACTIONS-X
      *         NO OTHER BRANCHES ALLOWED

      *    MOVE ENTER CODE TO WORKER MODULE.

025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  MIR-ADDL-PLAN-ID  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES             TO  MIR-ADDL-PLAN-ID
           END-IF.

           IF  MIR-ADDL-PLAN-MAND-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES             TO  MIR-ADDL-PLAN-MAND-IND
           END-IF.

           IF  MIR-LOC-GR-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES             TO  MIR-LOC-GR-ID
           END-IF.

           EVALUATE TRUE
              WHEN WS-BUS-FCN-RETRIEVE
                  PERFORM  3000-PROCESS-RETRIEVE
                      THRU 3000-PROCESS-RETRIEVE-X

              WHEN WS-BUS-FCN-LIST
              WHEN WS-BUS-FCN-SUMMARY
                  PERFORM  3500-PROCESS-LIST
                      THRU 3500-PROCESS-LIST-X

              WHEN WS-BUS-FCN-CREATE
                  PERFORM  4000-PROCESS-CREATE
                      THRU 4000-PROCESS-CREATE-X

              WHEN WS-BUS-FCN-UPDATE
                  PERFORM  5000-PROCESS-UPDATE
                      THRU 5000-PROCESS-UPDATE-X

              WHEN WS-BUS-FCN-DELETE
                  PERFORM  6000-PROCESS-DELETE
                      THRU 6000-PROCESS-DELETE-X

              WHEN WS-BUS-FCN-KLON
                  PERFORM  7000-PROCESS-KLON
                      THRU 7000-PROCESS-KLON-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                   MOVE 'XS00000237'         TO  WGLOB-MSG-REF-INFO
                   MOVE MIR-BUS-FCN-ID       TO  WGLOB-MSG-PARM (1)
                   MOVE 'CSOM0521'           TO  WGLOB-MSG-PARM (2)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-INVALD-RQST     TO  TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      **********************
       3000-PROCESS-RETRIEVE.
      **********************

      * SET UP BROWSE KEYS:

           PERFORM  8000-BUILD-PACK-KEY
               THRU 8000-BUILD-PACK-KEY-X.

           MOVE WPACK-BASIC-PLAN-ID   TO WPACK-ENDBR-BASIC-PLAN-ID.

      * SET UP FIELD ATTRIBUTES:

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

014221     MOVE MIR-BASIC-PLAN-ID     TO WPH-PLAN-ID.

014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.

           PERFORM  PACK-1000-READ
               THRU PACK-1000-READ-X.

           IF WPACK-IO-OK
               MOVE +1                TO WS-LINE
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WPACK-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      ******************
       3500-PROCESS-LIST.
      ******************

      * SET UP BROWSE KEYS:
           MOVE LOW-VALUES              TO WPACK-KEY.
           PERFORM  8000-BUILD-PACK-KEY
               THRU 8000-BUILD-PACK-KEY-X.

           MOVE HIGH-VALUES             TO WPACK-ENDBR-KEY.
           IF  WS-BUS-FCN-LIST
               MOVE WPACK-BASIC-PLAN-ID
                                        TO WPACK-ENDBR-BASIC-PLAN-ID
010418         MOVE WPACK-SBSDRY-CO-ID  TO WPACK-ENDBR-SBSDRY-CO-ID
557660     END-IF.

      * SET UP FIELD ATTRIBUTES:

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      * BEGIN BROWSE:

           PERFORM  PACK-1000-BROWSE
               THRU PACK-1000-BROWSE-X.

           IF NOT WPACK-IO-OK
      *        MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
557660     END-IF.

      * READ FIRST RECORD:

           PERFORM  PACK-2000-READ-NEXT
               THRU PACK-2000-READ-NEXT-X.

      * FOR AN INQUIRE THE REQUESTED KEY MUST BE FOUND

           IF NOT WPACK-IO-OK
      *MSG:    'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  PACK-3000-END-BROWSE
                   THRU PACK-3000-END-BROWSE-X
               GO TO 3500-PROCESS-LIST-X
557660     END-IF.

      * RESET SCREEN KEY FIELDS:

           MOVE RPACK-BASIC-PLAN-ID   TO MIR-BASIC-PLAN-ID.
010302     MOVE RPACK-LOC-GR-ID       TO MIR-LOC-GR-ID.
010418     MOVE RPACK-SBSDRY-CO-ID    TO MIR-SBSDRY-CO-ID.
           MOVE RPACK-ADDL-PLAN-ID    TO  MIR-ADDL-PLAN-ID.
557659*    MOVE RPACK-ADDL-PLAN-MAND-CD TO MIR-ADDL-PLAN-MAND-IND.
557659     MOVE RPACK-ADDL-PLAN-MAND-IND
557659                                TO MIR-ADDL-PLAN-MAND-IND.

      * LOAD SCREEN DATA ARRAY:

           MOVE ZERO                  TO WS-LINE.

           IF WPACK-IO-OK
557660         PERFORM  3600-DISPLAY-RECORD
557660             THRU 3600-DISPLAY-RECORD-X
                     VARYING WS-LINE FROM 1 BY 1
                      UNTIL (NOT WPACK-IO-OK)
                         OR (WS-LINE > WS-NUMBER-OF-DISPLAY-LINES)
557660     END-IF.

      * COMPLETION MESSAGE:

           IF WPACK-IO-OK
      *        MSG: 'TO VIEW MORE DATA PRESS ENTER'
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9250-UPDATE-SCREEN-KEYS
                   THRU 9250-UPDATE-SCREEN-KEYS-X
           ELSE
               IF WS-LINE > ZERO
557660             EVALUATE TRUE
                       WHEN WS-BUS-FCN-LIST
      *                    MSG: 'END OF FILE'
                           MOVE 'XS00000015'
                                      TO WGLOB-MSG-REF-INFO
                           PERFORM  0260-1000-GENERATE-MESSAGE
                               THRU 0260-1000-GENERATE-MESSAGE-X
                       WHEN WS-BUS-FCN-SUMMARY
      *                    MSG: 'END OF FILE REACHED'
                           MOVE 'XS00000025'
                                      TO WGLOB-MSG-REF-INFO
                           PERFORM  0260-1000-GENERATE-MESSAGE
                               THRU 0260-1000-GENERATE-MESSAGE-X
557660                 WHEN OTHER
      *                    MSG: 'NO RECORDS FOUND TO DISPLAY'
                           MOVE 'XS00000034'
                                      TO WGLOB-MSG-REF-INFO
                           PERFORM  0260-1000-GENERATE-MESSAGE
                               THRU 0260-1000-GENERATE-MESSAGE-X
557660             END-EVALUATE
557660         END-IF
557660     END-IF.

      * FINISH BROWSE:

           PERFORM  PACK-3000-END-BROWSE
               THRU PACK-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *********************
557660 3600-DISPLAY-RECORD.
      *********************

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  PACK-2000-READ-NEXT
               THRU PACK-2000-READ-NEXT-X.

           IF WS-BUS-FCN-SUMMARY
               PERFORM  PACK-2000-READ-NEXT
                   THRU PACK-2000-READ-NEXT-X
                   UNTIL RPACK-ADDL-PLAN-ID = SPACES
                   OR NOT WPACK-IO-OK
557660     END-IF.

557660 3600-DISPLAY-RECORD-X.
           EXIT.
      /
      ********************
       4000-PROCESS-CREATE.
      ********************

      * CHECK CONTROL FIELDS:

           PERFORM  9110-BLANK-DISPLAY-LINE
               THRU 9110-BLANK-DISPLAY-LINE-X
                 VARYING WS-LINE FROM 1 BY 1
                   UNTIL WS-LINE > WS-NUMBER-OF-DISPLAY-LINES.

           PERFORM  4100-EDIT-KEY-FIELDS
               THRU 4100-EDIT-KEY-FIELDS-X.

           IF WS-KEY-EDIT-INVALID
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

      * CHECK RECORD EXISTENCE:

           PERFORM  8000-BUILD-PACK-KEY
               THRU 8000-BUILD-PACK-KEY-X.

           PERFORM  PACK-1000-READ
               THRU PACK-1000-READ-X.

           IF WPACK-IO-OK
      *        MSG: 'RECORD ALREADY EXISTS (@1)'
               MOVE WPACK-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

           PERFORM  PACK-1000-CREATE
               THRU PACK-1000-CREATE-X.

           PERFORM  4200-PACK-OVERRIDE-DEFAULTS
               THRU 4200-PACK-OVERRIDE-DEFAULTS-X.

           PERFORM  PACK-1000-WRITE
               THRU PACK-1000-WRITE-X.

014221     MOVE MIR-BASIC-PLAN-ID     TO WPH-PLAN-ID.

014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.

           MOVE 1                     TO WS-LINE.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

      *    MSG: 'RECORD CREATED - CONTINUE'
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

      *    MSG: 'MAINTAIN DETAILS'
           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      **********************
       4100-EDIT-KEY-FIELDS.
      **********************

           MOVE 'Y'                   TO WS-KEY-EDIT-VALIDITY-SW.

      * EDIT BASIC PLAN CODE AND RATE SCALE:

           MOVE MIR-BASIC-PLAN-ID     TO WS-HOLD-PLAN-ID.

           PERFORM  4110-GET-FIRST-PLAN
               THRU 4110-GET-FIRST-PLAN-X.

           IF NOT WPH-IO-OK
010418*    OR RPH-PLAN-ID-BASE NOT = MIR-BASIC-PLAN-ID
      *        MSG: 'BASIC PLAN INVALID - @1'
014591*        MOVE WS-HOLD-PLAN-CODE    TO WGLOB-MSG-PARM (1)
014591*        MOVE WS-HOLD-RATE-SCALE   TO WGLOB-MSG-PARM (2)
014591         MOVE WS-HOLD-PLAN-ID      TO WGLOB-MSG-PARM (1)
               MOVE 'CS05210001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-KEY-EDIT-VALIDITY-SW
557660     END-IF.

010418     MOVE MIR-SBSDRY-CO-ID      TO WSCOM-SBSDRY-CO-ID.
010418     PERFORM  SCOM-1000-READ
010418         THRU SCOM-1000-READ-X.
010418
010418     IF NOT WSCOM-IO-OK
010418* MSG: 'INVALID SUB-COMPANY @1'
010418         MOVE MIR-SBSDRY-CO-ID  TO WGLOB-MSG-PARM (1)
010418         MOVE 'CS05210002'      TO WGLOB-MSG-REF-INFO
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418         MOVE 'N'               TO WS-KEY-EDIT-VALIDITY-SW
010418     END-IF.

010302     IF  MIR-LOC-GR-ID  = SPACES
010302* MSG: 'LOCATION GROUP MUST NOT BE BLANK'
               MOVE 'CS05210025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-KEY-EDIT-VALIDITY-SW
010302     ELSE
010302         MOVE SPACES            TO WEDIT-KEY
010302         MOVE MIR-LOC-GR-ID     TO WEDIT-ETBL-VALU-ID
010302         PERFORM  LGAS-1000-EDIT-LGAS-LOCATION
010302             THRU LGAS-1000-EDIT-LGAS-LOCATION-X
010302         IF NOT WEDIT-IO-OK
010302* MSG  'INVALID LOCATION GROUP'
010302            MOVE 'CS05210031'   TO WGLOB-MSG-REF-INFO
010302            PERFORM  0260-1000-GENERATE-MESSAGE
010302                THRU 0260-1000-GENERATE-MESSAGE-X
010302            MOVE 'N'            TO WS-KEY-EDIT-VALIDITY-SW
010302         END-IF
010302     END-IF.
010302
           MOVE SPACES                TO WS-HOLD-ADDL-LIST-TYPE.

           IF MIR-ADDL-PLAN-ID NOT = SPACES
               PERFORM 4120-EDIT-ADDL-PLAN
                   THRU 4120-EDIT-ADDL-PLAN-X
           ELSE
      *** FOR BASIC PLAN ENTRIES, MANDATORY INDICATOR MUST BE BLANK
               IF MIR-ADDL-PLAN-MAND-IND = SPACES
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
      *            MSG: 'MANDATORY IND MUST BE BLANK ON BASIC PLAN'
                   MOVE 'CS05210006'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-KEY-EDIT-VALIDITY-SW
557660         END-IF
557660     END-IF.

       4100-EDIT-KEY-FIELDS-X.
           EXIT.
      *
      *----------------------------------------------------------
      *   READ PLAN FILE, TAKING THE UNIVERSAL RATE SCALE INTO ACCOUNT
      *----------------------------------------------------------
      *--------------------
       4110-GET-FIRST-PLAN.
      *--------------------

010418*    IF WS-HOLD-RATE-SCALE NOT = WMATC-MATCH-ANY-CHAR
010418*        MOVE WS-HOLD-PLAN-CODE   TO WPH-PLAN-ID-BASE
010418*        MOVE WS-HOLD-RATE-SCALE  TO WPH-PLAN-ID-RS
010418*        PERFORM  PH-1000-READ
010418*            THRU PH-1000-READ-X
010418*        GO TO 4110-GET-FIRST-PLAN-X
010418*     END-IF.

014591*    MOVE WS-HOLD-PLAN-CODE     TO WPH-PLAN-ID-BASE.
014591*    MOVE WS-HOLD-RATE-SCALE    TO WPH-PLAN-ID-RS.
014591     MOVE WS-HOLD-PLAN-ID       TO WPH-PLAN-ID.

010418     PERFORM  PH-1000-READ
010418         THRU PH-1000-READ-X.

010418*    MOVE WS-HOLD-PLAN-CODE       TO WPH-PLAN-ID-BASE.
010418*    MOVE HIGH-VALUES             TO WPH-PLAN-ID-RS.
010418*    MOVE WPH-PLAN-ID             TO WPH-ENDBR-PLAN-ID.
010418*    MOVE LOW-VALUES              TO WPH-PLAN-ID-RS.

010418*    PERFORM  PH-1000-BROWSE
010418*        THRU PH-1000-BROWSE-X.

010418*    IF NOT WPH-IO-OK
010418*        GO TO 4110-GET-FIRST-PLAN-X
010418*    END-IF.

010418*    PERFORM  PH-2000-READ-NEXT
010418*        THRU PH-2000-READ-NEXT-X.

010418*    PERFORM  PH-3000-END-BROWSE
010418*        THRU PH-3000-END-BROWSE-X.

       4110-GET-FIRST-PLAN-X.
           EXIT.
      /
      *****************************************************************
      **   EDIT ADDL PLAN
      **      PACK ENTRY MUST EXIST FOR BASIC PLAN
      **      BASIC PACK ENTRY MUST HAVE PACKAGING TURNED ON
      **      ADDL PLAN/RS MUST EXIT ON PLAN
      **      ADDL PLAN MUST BE EITHER MANDATORY OR NOT MANDATORY
      *****************************************************************

      *--------------------
       4120-EDIT-ADDL-PLAN.
      *--------------------

      * ADDITIONAL PLANS MUST HAVE BASIC PLAN PACKAGING ENTRY ALREADY

           MOVE MIR-BASIC-PLAN-ID     TO WPACK-BASIC-PLAN-ID.
010302     MOVE MIR-LOC-GR-ID         TO WPACK-LOC-GR-ID.
010418     MOVE MIR-SBSDRY-CO-ID      TO WPACK-SBSDRY-CO-ID.
557659*    MOVE SPACES                TO WPACK-ADDL-PLAN-MAND-CD.
557659     MOVE SPACES                TO WPACK-ADDL-PLAN-MAND-IND.
           MOVE SPACES                TO WPACK-ADDL-PLAN-ID.
           PERFORM  PACK-1000-READ
               THRU PACK-1000-READ-X.
           IF NOT WPACK-IO-OK
      *        MSG: 'NO BASIC PLAN ENTRY IN PACKAGING MATRIX YET'
               MOVE 'CS05210004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-KEY-EDIT-VALIDITY-SW
               GO TO 4120-EDIT-ADDL-PLAN-X
557660     END-IF.

557659*    MOVE RPACK-ADDL-PLAN-TYP-IND TO WS-HOLD-ADDL-LIST-TYPE.
557659     MOVE RPACK-PLAN-PKG-TYP-CD TO WS-HOLD-ADDL-LIST-TYPE.

      * IF PACKAGING HAS BEEN TURNED OFF FOR BASIC PLAN, CANNOT CREATE A
      * ADDITIONAL PLAN

           IF WS-HOLD-ADDL-LIST-TYPE = SPACES
               MOVE 'CS05210005'      TO WGLOB-MSG-REF-INFO
      *** MSG: 'PACKAGING TURNED OFF FOR THIS PLAN'
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-KEY-EDIT-VALIDITY-SW
               GO TO 4120-EDIT-ADDL-PLAN-X
557660     END-IF.

      * EDIT ADDITIONAL PLAN CODE AND RATE SCALE:

           MOVE MIR-ADDL-PLAN-ID      TO WS-HOLD-PLAN-ID.
           PERFORM  4110-GET-FIRST-PLAN
               THRU 4110-GET-FIRST-PLAN-X.
           IF NOT WPH-IO-OK
014591*    OR RPH-PLAN-ID-BASE NOT = WS-HOLD-PLAN-CODE
014591     OR RPH-PLAN-ID NOT = WS-HOLD-PLAN-ID
      *        MSG: 'ADDITIONAL PLAN INVALID - @1'
014591*        MOVE WS-HOLD-PLAN-CODE    TO WGLOB-MSG-PARM (1)
014591*        MOVE WS-HOLD-RATE-SCALE   TO WGLOB-MSG-PARM (2)
014591         MOVE WS-HOLD-PLAN-ID      TO WGLOB-MSG-PARM (1)
               MOVE 'CS05210003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-KEY-EDIT-VALIDITY-SW
557660     END-IF.

      * EDIT ADDITIONAL PLAN REQUIRED INDICATOR

           IF MIR-ADDL-PLAN-MAND-IND = 'N'
557659*    OR MIR-ADDL-PLAN-MAND-IND = 'M'
557659     OR MIR-ADDL-PLAN-MAND-IND = 'Y'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
557659*        MSG: 'MANDATORY IND MUST BE N OR Y ON ADDL PLAN'
               MOVE 'CS05210007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-KEY-EDIT-VALIDITY-SW
557660     END-IF.

      * AN ADDITIONAL PLAN CAN ONLY BE ONE OF MANDATORY OR NON MANDATORY

           PERFORM  4122-CHECK-ADDL-UNIQUE
               THRU 4122-CHECK-ADDL-UNIQUE-X.

       4120-EDIT-ADDL-PLAN-X.
           EXIT.
      /
      *----------------------------------------------------------
      *   MAKE SURE AN ADDITIONAL PLAN ENTRY OCCURS AS MANDATORY
      *   OR OTHER BUT NOT BOTH
      *----------------------------------------------------------
      *-----------------------
       4122-CHECK-ADDL-UNIQUE.
      *-----------------------

           PERFORM  8000-BUILD-PACK-KEY
               THRU 8000-BUILD-PACK-KEY-X.

557659*    IF WPACK-ADDL-PLAN-MAND-CD = 'M'
557659*        MOVE 'N'         TO WPACK-ADDL-PLAN-MAND-CD
557659*    ELSE
557659*        MOVE 'M'         TO WPACK-ADDL-PLAN-MAND-CD
557659     IF WPACK-ADDL-PLAN-MAND-IND = 'Y'
557659         MOVE 'N'               TO WPACK-ADDL-PLAN-MAND-IND
557659     ELSE
557659         MOVE 'Y'               TO WPACK-ADDL-PLAN-MAND-IND
557660     END-IF.

           PERFORM  PACK-1000-READ
               THRU PACK-1000-READ-X.

           IF NOT WPACK-IO-OK
               GO TO 4122-CHECK-ADDL-UNIQUE-X
557660     END-IF.

557660     EVALUATE TRUE
557659*    IF WPACK-ADDL-PLAN-MAND-CD = 'M'
557659         WHEN WPACK-ADDL-PLAN-MAND-IND = 'Y'
      *        MSG: 'ADDITIONAL PLAN ALREADY A MANDATORY PLAN'
                   MOVE 'CS05210008'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         WHEN WS-HOLD-ADDL-LIST-TYPE = 'O'
      *        MSG: 'ADDITIONAL PLAN ALREADY AN OPTIONAL PLAN'
                   MOVE 'CS05210009'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         WHEN WS-HOLD-ADDL-LIST-TYPE = 'N'
      *        MSG: 'ADDITIONAL PLAN ALREADY NOT ALLOWED'
                   MOVE 'CS05210010'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         WHEN OTHER
      *        MSG: 'ADDITIONAL PLAN ALREADY ON FILE'
                   MOVE 'CS05210011'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-EVALUATE.

           MOVE 'N'                   TO WS-KEY-EDIT-VALIDITY-SW.

       4122-CHECK-ADDL-UNIQUE-X.
           EXIT.
      /
      *----------------------------------------------------------
      *   OVERRIDE PACK CREATE DEFAULTS IN CERTAIN SITUATIONS
      *----------------------------------------------------------
      *----------------------------
       4200-PACK-OVERRIDE-DEFAULTS.
      *----------------------------

      * BASIC PLAN ENTRY:
           IF  MIR-ADDL-PLAN-ID = SPACES
557659*        MOVE SPACES            TO RPACK-ADDL-PLAN-TYP-IND
557659         MOVE SPACES            TO RPACK-PLAN-PKG-TYP-CD
               GO TO 4200-PACK-OVERRIDE-DEFAULTS-X
557660     END-IF.

      * 'NOT ALLOWED' ADDITIONAL PLAN ENTRY:
            IF  MIR-ADDL-PLAN-MAND-IND = 'N'
            AND WS-HOLD-ADDL-LIST-TYPE = 'N'
557659*         MOVE SPACES     TO RPACK-WP-ALLOW-IND
557659*         MOVE SPACES     TO RPACK-AD-ALLOW-IND
557659          MOVE SPACES           TO RPACK-PLAN-PKG-WP-CD
557659          MOVE SPACES           TO RPACK-PLAN-PKG-ADB-CD
557660      END-IF.

       4200-PACK-OVERRIDE-DEFAULTS-X.
           EXIT.
      /
      *----------------------------------------------------------
      *   MAINTAIN PROCESSING:
      *       FORCE = 1: USER HAS ENTERED KEY DETAILS.
      *       FORCE = 2: USER HAS MODIFIED DATA FIELDS.
      *----------------------------------------------------------
      *-------------------
       5000-PROCESS-UPDATE.
      *-------------------

014221     MOVE MIR-BASIC-PLAN-ID    TO WPH-PLAN-ID.

014221     PERFORM  PH-2000-UPDATE-TWRK-TS
014221         THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF WPH-IO-NOT-FOUND
014221*MSG: 'PLAN (@1) NOT FOUND'
014221         SET WS-KEY-EDIT-INVALID TO TRUE
014221         MOVE 'XS00000049'      TO WGLOB-MSG-REF-INFO
014221         MOVE WPH-PLAN-ID       TO WGLOB-MSG-PARM (01)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.
014221
014221     IF MIR-RETRN-TS-MISMATCH
014221*MSG: 'TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*      PROCESS NOT COMPLETE'
014221         SET WS-KEY-EDIT-INVALID TO TRUE
014221         MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'              TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID       TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

      * IF ADDITIONAL PLAN ENTRY, GET BASIC PLAN ENTRY

           IF MIR-ADDL-PLAN-ID NOT = SPACES
               MOVE SPACES            TO WPACK-KEY
               MOVE MIR-BASIC-PLAN-ID TO WPACK-BASIC-PLAN-ID
010302         MOVE MIR-LOC-GR-ID     TO WPACK-LOC-GR-ID
010418         MOVE MIR-SBSDRY-CO-ID  TO WPACK-SBSDRY-CO-ID
               PERFORM  PACK-1000-READ
                   THRU PACK-1000-READ-X
               IF NOT WPACK-IO-OK
      *            MSG: 'MISSING BASIC PLAN ENTRY FOR THIS ADDL PLAN'
                   MOVE 'CS05210013'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 5000-PROCESS-UPDATE-X
               ELSE
557659*            MOVE RPACK-ADDL-PLAN-TYP-IND
557659             MOVE RPACK-PLAN-PKG-TYP-CD
                                      TO WS-HOLD-ADDL-LIST-TYPE
557660         END-IF
557660     END-IF.

           PERFORM  8000-BUILD-PACK-KEY
               THRU 8000-BUILD-PACK-KEY-X.

           PERFORM  PACK-1000-READ-FOR-UPDATE
               THRU PACK-1000-READ-FOR-UPDATE-X.

           IF WPACK-IO-NOT-FOUND
      *        'MESSAGE LOST RECORD IN MAINTAIN (@1) - CONTACT SYSTEMS'
               MOVE WPACK-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  PH-3000-UNLOCK
014221             THRU PH-3000-UNLOCK-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  5300-EDIT-DATA-FIELDS
               THRU 5300-EDIT-DATA-FIELDS-X.

           PERFORM  PACK-2000-REWRITE
               THRU PACK-2000-REWRITE-X.
014221     PERFORM  PH-2000-REWRITE
014221         THRU PH-2000-REWRITE-X.
014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.

           IF  MIR-ADDL-PLAN-ID = SPACES
               PERFORM  5250-CROSS-EDIT
                   THRU 5250-CROSS-EDIT-X
557660     END-IF.

           IF WS-DATA-EDIT-VALID
      *        MSG: 'MAINTENANCE COMPLETED - CONTINUE'
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *        MSG: 'RECORD UPDATED'
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *----------------
       5250-CROSS-EDIT.
      *----------------
      *
      *   IF THE LIST TYPE IS BLANK ON THE BASIC PACKAGING ENTRY
      *      NO ADDITIONAL PLAN PACKAGING ENTRIES ALLOWED

      *   THE LIST TYPE ON THE BASIC PACKAGING ENTRY CANNOT BE
      *      CHANGED IF THERE ARE ADDITIONAL PLAN ENTRIES

           MOVE SPACES                TO WPACK-KEY.
           MOVE MIR-BASIC-PLAN-ID     TO WPACK-BASIC-PLAN-ID.
010302     MOVE MIR-LOC-GR-ID         TO WPACK-LOC-GR-ID.

010418     MOVE MIR-SBSDRY-CO-ID      TO WPACK-SBSDRY-CO-ID.
           MOVE HIGH-VALUES           TO WPACK-ENDBR-KEY.
           MOVE WPACK-BASIC-PLAN-ID   TO WPACK-ENDBR-BASIC-PLAN-ID.
010302     MOVE MIR-LOC-GR-ID         TO WPACK-ENDBR-LOC-GR-ID.
010418     MOVE WPACK-SBSDRY-CO-ID    TO WPACK-ENDBR-SBSDRY-CO-ID.

           PERFORM  PACK-1000-BROWSE
               THRU PACK-1000-BROWSE-X.

           IF NOT WPACK-IO-OK
               GO TO 5250-CROSS-EDIT-X
557660     END-IF.


           PERFORM  PACK-2000-READ-NEXT
               THRU PACK-2000-READ-NEXT-X.

           IF NOT WPACK-IO-OK
               PERFORM  PACK-3000-END-BROWSE
                   THRU PACK-3000-END-BROWSE-X
               GO TO 5250-CROSS-EDIT-X
557660     END-IF.

557659*    MOVE RPACK-ADDL-PLAN-TYP-IND TO WS-SAVE-ADDL-LIST-TYPE.
557659     MOVE RPACK-PLAN-PKG-TYP-CD TO WS-SAVE-ADDL-LIST-TYPE.

           PERFORM  PACK-2000-READ-NEXT
               THRU PACK-2000-READ-NEXT-X.

           IF NOT WPACK-IO-OK
               PERFORM  PACK-3000-END-BROWSE
                   THRU PACK-3000-END-BROWSE-X
               GO TO 5250-CROSS-EDIT-X
557660     END-IF.

           IF WS-SAVE-ADDL-LIST-TYPE = SPACES
      *        'LIST TYPE BLANK BUT ADDITIONAL PACKAGING ENTRIES EXIST
               MOVE 'CS05210023'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF WS-ADDL-PLN-TYP-CHGED
      *            'LIST TYPE CHANGED BUT ADDITIONAL ENTRIES EXIST'
                   MOVE 'CS05210024'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           PERFORM PACK-3000-END-BROWSE
              THRU PACK-3000-END-BROWSE-X.

       5250-CROSS-EDIT-X.
           EXIT.
      /
      *----------------------------------------------------------
      *   FIELD EDITS: CHECK VALIDITY OF ALL DATA FIELDS.
      *----------------------------------------------------------
      ***********************
       5300-EDIT-DATA-FIELDS.
      ***********************

           IF MIR-PLAN-PKG-TYP-CD-T (1) NOT = SPACES
               MOVE 'Y'               TO WS-ADDL-PLN-TYP-CHG-SW
               PERFORM  5400-EDIT-PLAN-TYPE
                   THRU 5400-EDIT-PLAN-TYPE-X
           ELSE
               MOVE 'Y'               TO WS-ADDL-PLN-TYP-CHG-SW
557659*        MOVE RPACK-ADDL-PLAN-TYP-IND TO MIR-PLAN-PKG-TYP-CD-T (1)
557659         MOVE RPACK-PLAN-PKG-TYP-CD
                                      TO MIR-PLAN-PKG-TYP-CD-T (1)
557660     END-IF.

           IF MIR-PLAN-PKG-WP-CD-T (1) = SPACES
557659*        MOVE RPACK-WP-ALLOW-IND   TO MIR-PLAN-PKG-WP-CD-T (1)
557659         MOVE RPACK-PLAN-PKG-WP-CD
                                      TO MIR-PLAN-PKG-WP-CD-T (1)
557660     END-IF.
      *    EDIT MUST BE PERFORMED EVERY TIME BECAUSE SOME OF THE EDIT
      *    VALUES DEPEND ON OTHER FIELDS.
           PERFORM  5500-EDIT-WP-REQUIRED
               THRU 5500-EDIT-WP-REQUIRED-X.

           IF MIR-PLAN-PKG-ADB-CD-T (1) = SPACES
557659*        MOVE RPACK-AD-ALLOW-IND    TO MIR-PLAN-PKG-ADB-CD-T (1)
557659         MOVE RPACK-PLAN-PKG-ADB-CD
                                      TO MIR-PLAN-PKG-ADB-CD-T (1)
557660     END-IF.
      *    EDIT MUST BE PERFORMED EVERY TIME BECAUSE SOME OF THE EDIT
      *    VALUES DEPEND ON OTHER FIELDS.
           PERFORM  5600-EDIT-ADB-REQUIRED
               THRU 5600-EDIT-ADB-REQUIRED-X.

       5300-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      *********************
       5400-EDIT-PLAN-TYPE.
      *********************

           IF MIR-PLAN-PKG-TYP-CD-T (1) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-PLAN-PKG-TYP-CD-T (1)
557660     END-IF.

           IF  MIR-ADDL-PLAN-ID-T (1) = SPACES
557660         IF  MIR-PLAN-PKG-TYP-CD-T (1) NOT = ' '
               AND MIR-PLAN-PKG-TYP-CD-T (1) NOT = 'O'
               AND MIR-PLAN-PKG-TYP-CD-T (1) NOT = 'N'
      *** LIST TYPE FOR BASIC PLAN ENTRY MUST BE BLANK, O OR N
                   MOVE 'CS05210014'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDIT-VALIDITY-SW
                   GO TO 5400-EDIT-PLAN-TYPE-X
034802*        ELSE
034802*            NEXT SENTENCE
               END-IF
           ELSE
               IF MIR-PLAN-PKG-TYP-CD-T (1) NOT = ' '
      *** LIST TYPE MUST BE BLANK FOR ADDITIONAL PLAN ENTRY
                   MOVE 'CS05210015'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDIT-VALIDITY-SW
                   GO TO 5400-EDIT-PLAN-TYPE-X
557660         END-IF
557660     END-IF.

557659*    MOVE MIR-PLAN-PKG-TYP-CD-T (1) TO RPACK-ADDL-PLAN-TYP-IND.
557659     MOVE MIR-PLAN-PKG-TYP-CD-T (1)
                                      TO RPACK-PLAN-PKG-TYP-CD.

       5400-EDIT-PLAN-TYPE-X.
           EXIT.
      /
      ***********************
       5500-EDIT-WP-REQUIRED.
      ***********************

           IF MIR-PLAN-PKG-WP-CD-T (1) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-PLAN-PKG-WP-CD-T (1)
557660     END-IF.

           IF  MIR-ADDL-PLAN-ID = SPACES
      *        THIS IS A BASIC PLAN ENTRY
               PERFORM  5510-EDIT-WP-BASIC
                   THRU 5510-EDIT-WP-BASIC-X
           ELSE
      *        THIS IS AN ADDITIONAL PLAN ENTRY
               PERFORM  5520-EDIT-WP-ADDL
                   THRU 5520-EDIT-WP-ADDL-X
557660     END-IF.

       5500-EDIT-WP-REQUIRED-X.
           EXIT.

      /
      ********************
       5510-EDIT-WP-BASIC.
      ********************

           IF  MIR-PLAN-PKG-TYP-CD-T (1) = SPACES
               IF MIR-PLAN-PKG-WP-CD-T (1) = SPACES
557659*            MOVE MIR-PLAN-PKG-WP-CD-T (1) TO RPACK-WP-ALLOW-IND
557659             MOVE MIR-PLAN-PKG-WP-CD-T (1)
                                      TO RPACK-PLAN-PKG-WP-CD
               ELSE
      *            'WP-IND MUST BE BLANK FOR ADDL-PLAN-TYPE = " "'
                   MOVE 'CS05210017'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDIT-VALIDITY-SW
               END-IF
           ELSE
557660         IF MIR-PLAN-PKG-WP-CD-T (1) = 'M'
               OR MIR-PLAN-PKG-WP-CD-T (1) = 'N'
               OR MIR-PLAN-PKG-WP-CD-T (1) = 'O'
557659*            MOVE MIR-PLAN-PKG-WP-CD-T (1) TO RPACK-WP-ALLOW-IND
557659             MOVE MIR-PLAN-PKG-WP-CD-T (1)
                                      TO RPACK-PLAN-PKG-WP-CD
               ELSE
      *            MSG: 'INVALID VALUE FOR WP-REQUIRED INDICATOR'
                   MOVE 'CS05210018'  TO WGLOB-MSG-REF-INFO
                   MOVE 'M, N, O'     TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDIT-VALIDITY-SW
557660         END-IF
557660     END-IF.

       5510-EDIT-WP-BASIC-X.
           EXIT.

      /
      *******************
       5520-EDIT-WP-ADDL.
      *******************

557659*    IF MIR-ADDL-PLAN-MAND-IND-T (1) = 'M'
557659     IF MIR-ADDL-PLAN-MAND-IND-T (1) = 'Y'
           OR WS-HOLD-ADDL-LIST-TYPE = 'O'
               IF MIR-PLAN-PKG-WP-CD-T (1) = 'M'
               OR MIR-PLAN-PKG-WP-CD-T (1) = 'N'
               OR MIR-PLAN-PKG-WP-CD-T (1) = 'O'
557659*            MOVE MIR-PLAN-PKG-WP-CD-T (1) TO RPACK-WP-ALLOW-IND
557659             MOVE MIR-PLAN-PKG-WP-CD-T (1)
                                      TO RPACK-PLAN-PKG-WP-CD
               ELSE
      *            MSG: 'INVALID VALUE FOR WP-REQUIRED INDICATOR'
                   MOVE 'CS05210018'  TO WGLOB-MSG-REF-INFO
                   MOVE 'M, N, O'     TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDIT-VALIDITY-SW
               END-IF
           ELSE
               IF  WS-HOLD-ADDL-LIST-TYPE = 'N'
                   IF MIR-PLAN-PKG-WP-CD-T (1) = SPACES
557659*                MOVE MIR-PLAN-PKG-WP-CD-T (1)
557659*                               TO RPACK-WP-ALLOW-IND
557659                 MOVE MIR-PLAN-PKG-WP-CD-T (1)
                                      TO RPACK-PLAN-PKG-WP-CD
                   ELSE
      *                'WP-IND MUST BE BLANK FOR ADDL-PLAN-TYPE = "N"'
                       MOVE 'CS05210016'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                       MOVE 'N'       TO WS-DATA-EDIT-VALIDITY-SW
557660             END-IF
557660         END-IF
557660     END-IF.

       5520-EDIT-WP-ADDL-X.
           EXIT.

      /
      ************************
       5600-EDIT-ADB-REQUIRED.
      ************************

           IF MIR-PLAN-PKG-ADB-CD-T (1) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-PLAN-PKG-ADB-CD-T (1)
557660     END-IF.

           IF  MIR-ADDL-PLAN-ID = SPACES
      *        THIS IS A BASIC PLAN ENTRY
               PERFORM  5610-EDIT-ADB-BASIC
                   THRU 5610-EDIT-ADB-BASIC-X
           ELSE
      *        THIS IS AN ADDITIONAL PLAN ENTRY
               PERFORM  5620-EDIT-ADB-ADDL
                   THRU 5620-EDIT-ADB-ADDL-X
557660     END-IF.

       5600-EDIT-ADB-REQUIRED-X.
           EXIT.
      /
      *********************
       5610-EDIT-ADB-BASIC.
      *********************

           IF  MIR-PLAN-PKG-TYP-CD-T (1) = SPACES
               IF MIR-PLAN-PKG-ADB-CD-T (1) = SPACES
557659*            MOVE MIR-PLAN-PKG-ADB-CD-T (1) TO RPACK-AD-ALLOW-IND
557659             MOVE MIR-PLAN-PKG-ADB-CD-T (1)
                                      TO RPACK-PLAN-PKG-ADB-CD
               ELSE
      *            'ADB-IND MUST BE BLANK FOR ADDL-PLAN-TYPE = " "'
                   MOVE 'CS05210020'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDIT-VALIDITY-SW
               END-IF
           ELSE
               IF MIR-PLAN-PKG-ADB-CD-T (1) = 'M'
557660         OR MIR-PLAN-PKG-ADB-CD-T (1) = 'N'
               OR MIR-PLAN-PKG-ADB-CD-T (1) = 'O'
557659*            MOVE MIR-PLAN-PKG-ADB-CD-T (1)  TO RPACK-AD-ALLOW-IND
557659             MOVE MIR-PLAN-PKG-ADB-CD-T (1)
                                      TO RPACK-PLAN-PKG-ADB-CD
               ELSE
                   MOVE 'CS05210021'  TO WGLOB-MSG-REF-INFO
                   MOVE 'M, N, O'     TO WGLOB-MSG-PARM (1)
      *            MSG: 'INVALID VALUE FOR ADB-REQUIRED INDICATOR'
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDIT-VALIDITY-SW
557660         END-IF
557660     END-IF.

       5610-EDIT-ADB-BASIC-X.
           EXIT.
      /
      ********************
       5620-EDIT-ADB-ADDL.
      ********************

557659*    IF  MIR-ADDL-PLAN-MAND-IND-T (1) = 'M'
557659     IF  MIR-ADDL-PLAN-MAND-IND-T (1) = 'Y'
           OR  WS-HOLD-ADDL-LIST-TYPE = 'O'
557660         IF MIR-PLAN-PKG-ADB-CD-T (1) = 'M'
               OR MIR-PLAN-PKG-ADB-CD-T (1) = 'N'
               OR MIR-PLAN-PKG-ADB-CD-T (1) = 'O'
557659*            MOVE MIR-PLAN-PKG-ADB-CD-T (1) TO RPACK-AD-ALLOW-IND
557659             MOVE MIR-PLAN-PKG-ADB-CD-T (1)
                                      TO RPACK-PLAN-PKG-ADB-CD
               ELSE
                   MOVE 'CS05210021'  TO WGLOB-MSG-REF-INFO
                   MOVE 'M, N, O'     TO WGLOB-MSG-PARM (1)
      *            MSG: 'INVALID VALUE FOR ADB-REQUIRED INDICATOR'
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDIT-VALIDITY-SW
557660         END-IF
           ELSE
               IF   WS-HOLD-ADDL-LIST-TYPE = 'N'
                   IF MIR-PLAN-PKG-ADB-CD-T (1) = SPACES
557659*                MOVE MIR-PLAN-PKG-ADB-CD-T (1)
557659*                                            TO RPACK-AD-ALLOW-IND
557659                 MOVE MIR-PLAN-PKG-ADB-CD-T (1)
                                      TO RPACK-PLAN-PKG-ADB-CD
                   ELSE
      *                'ADB-IND MUST BE BLANK FOR ADDL-PLAN-TYPE = "N"'
                       MOVE 'CS05210019'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                       MOVE 'N'       TO WS-DATA-EDIT-VALIDITY-SW
557660             END-IF
557660         END-IF
557660     END-IF.

       5620-EDIT-ADB-ADDL-X.
           EXIT.
      /
      *----------------------------------------------------------
      *   DELETE PROCESSING:
      *       FORCE = 1: USER HAS ENTERED KEY DETAILS.
      *       FORCE = 9: USER HAS VERIFIED DELETE REQUEST.
      *----------------------------------------------------------
      *-------------------
       6000-PROCESS-DELETE.
      *-------------------

014221     MOVE MIR-BASIC-PLAN-ID      TO WPH-PLAN-ID.

014221     PERFORM  PH-2000-UPDATE-TWRK-TS
014221         THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF WPH-IO-NOT-FOUND
014221*MSG: 'PLAN (@1) NOT FOUND'
014221         SET WS-KEY-EDIT-INVALID TO TRUE
014221         MOVE 'XS00000049'      TO WGLOB-MSG-REF-INFO
014221         MOVE WPH-PLAN-ID       TO WGLOB-MSG-PARM (01)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.
014221
014221     IF MIR-RETRN-TS-MISMATCH
014221*MSG: 'TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*      PROCESS NOT COMPLETE'
014221         SET WS-KEY-EDIT-INVALID TO TRUE
014221         MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'              TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID       TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF  MIR-ADDL-PLAN-ID = SPACES
               MOVE SPACES            TO WPACK-KEY
               MOVE WGLOB-COMPANY-CODE                    TO WPACK-CO-ID
               MOVE MIR-BASIC-PLAN-ID TO WPACK-BASIC-PLAN-ID
010302         MOVE MIR-LOC-GR-ID     TO WPACK-LOC-GR-ID
010418         MOVE MIR-SBSDRY-CO-ID  TO WPACK-SBSDRY-CO-ID
557659*        MOVE 'M'                   TO WPACK-ADDL-PLAN-MAND-CD
557659         MOVE 'Y'               TO WPACK-ADDL-PLAN-MAND-IND
               MOVE HIGH-VALUES       TO WPACK-ENDBR-KEY
               MOVE WPACK-BASIC-PLAN-ID
                                      TO WPACK-ENDBR-BASIC-PLAN-ID
010302         MOVE WPACK-LOC-GR-ID   TO WPACK-ENDBR-LOC-GR-ID
010418         MOVE WPACK-SBSDRY-CO-ID       TO WPACK-ENDBR-SBSDRY-CO-ID
557660         PERFORM  6120-CHECK-ATTACH-PLANS
557660             THRU 6120-CHECK-ATTACH-PLANS-X
557660         IF WS-ADDTNL-PLANS-FOUND
                   GO TO 6000-PROCESS-DELETE-X
               END-IF
557660     END-IF.

      * FETCH RECORD:
      *
           PERFORM  8000-BUILD-PACK-KEY
               THRU 8000-BUILD-PACK-KEY-X.

           PERFORM  PACK-1000-READ-FOR-UPDATE
               THRU PACK-1000-READ-FOR-UPDATE-X.

           IF WPACK-IO-NOT-FOUND
      *        MSG: 'LOST RECORD IN DELETE (@1) - CONTACT SYSTEMS'
               MOVE WPACK-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  PH-3000-UNLOCK
014221             THRU PH-3000-UNLOCK-X
           ELSE
               PERFORM  PACK-1000-DELETE
                   THRU PACK-1000-DELETE-X
014221         PERFORM  PH-2000-REWRITE
014221             THRU PH-2000-REWRITE-X
014221         PERFORM  PH-1000-READ-TWRK-TS
014221             THRU PH-1000-READ-TWRK-TS-X
      *        MSG: 'DELETE COMPLETED - CONTINUE'.
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
557660*----------------------------------------------------------
557660*   BEFORE DELETING, CHECK WHETHER ADDITIONAL RECORDS EXIST
557660*----------------------------------------------------------
557660 6120-CHECK-ATTACH-PLANS.
557660*
557660     SET WS-NO-ADDTNL-PLANS-FOUND      TO TRUE.
557660
           PERFORM  PACK-1000-BROWSE
               THRU PACK-1000-BROWSE-X.

010302*    IF  NOT WPACK-IO-OK
010302*        GO TO 6120-CHECK-ATTACH-PLANS-X
010302*    END-IF.
010302*
           PERFORM  PACK-2000-READ-NEXT
               THRU PACK-2000-READ-NEXT-X.

           IF  NOT WPACK-IO-OK
010311         PERFORM  PACK-3000-END-BROWSE
010311             THRU PACK-3000-END-BROWSE-X
557660         GO TO 6120-CHECK-ATTACH-PLANS-X
557660     END-IF.
557660
010302*    IF  RPACK-BASIC-PLAN-ID-BASE = MIR-BASIC-PLAN-ID
010302*    AND RPACK-BASIC-PLAN-ID-RS = MIR-BSRTS
      *     'BASIC PLAN STILL HAS ADDITIONAL PLANS ATTACHED
010302*        MOVE 'CS05210022'    TO WGLOB-MSG-REF-INFO
010302*        PERFORM  0260-1000-GENERATE-MESSAGE
010302*            THRU 0260-1000-GENERATE-MESSAGE-X
010302*        PERFORM  9400-SET-ATTRIBUTES-1
010302*            THRU 9400-SET-ATTRIBUTES-1-X
010302*        PERFORM  PACK-3000-END-BROWSE
010302*            THRU PACK-3000-END-BROWSE-X
010302*        SET WS-ADDTNL-PLANS-FOUND    TO TRUE
010302*    ELSE
010302*        PERFORM  PACK-3000-END-BROWSE
010302*            THRU PACK-3000-END-BROWSE-X
010302*    END-IF.
010302
010302     IF  WPACK-IO-OK
010302*     'BASIC PLAN STILL HAS ADDITIONAL PLANS ATTACHED
010302         MOVE 'CS05210022'      TO WGLOB-MSG-REF-INFO
010302         PERFORM  0260-1000-GENERATE-MESSAGE
010302             THRU 0260-1000-GENERATE-MESSAGE-X
010302         SET WS-ADDTNL-PLANS-FOUND    TO TRUE
010302     END-IF.
010302
010302     PERFORM  PACK-3000-END-BROWSE
010302         THRU PACK-3000-END-BROWSE-X.
010302
557660 6120-CHECK-ATTACH-PLANS-X.
557660     EXIT.
      /
010418
      *******************
       7000-PROCESS-KLON.
      *******************

      *---- VALIDATION

           PERFORM  7110-KLON-1ST-EDITS
               THRU 7110-KLON-1ST-EDITS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 7000-PROCESS-KLON-X
           END-IF.
      *
           PERFORM  7210-KLON-2ND-EDITS
               THRU 7210-KLON-2ND-EDITS-X.

           IF WGLOB-MSG-ERROR-SW > ZEROS
      * MSG: RECORDS NOT KLOND
              MOVE 'CS05210032'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-PROCESS-KLON-X
           END-IF.

           MOVE LOW-VALUES            TO WPACK-KEY.
           MOVE MIR-BASIC-PLAN-ID     TO WPACK-BASIC-PLAN-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WPACK-SBSDRY-CO-ID.
           MOVE HIGH-VALUES           TO WPACK-ENDBR-KEY.
           MOVE MIR-BASIC-PLAN-ID     TO WPACK-ENDBR-BASIC-PLAN-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WPACK-ENDBR-SBSDRY-CO-ID.
      *
           PERFORM  PACK-1000-BROWSE
               THRU PACK-1000-BROWSE-X.

           IF NOT WPACK-IO-OK
           OR WPACK-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
      *MSG: RECORD NOT KLOND
016483*        MOVE 'CS05210033'      TO WGLOB-MSG-REF-INFO
016483         MOVE 'CS05210032'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 7000-PROCESS-KLON-X
           ELSE
               PERFORM  PACK-2000-READ-NEXT
                   THRU PACK-2000-READ-NEXT-X
               IF WPACK-IO-EOF
               OR NOT WPACK-IO-OK
                   PERFORM  PACK-3000-END-BROWSE
                       THRU PACK-3000-END-BROWSE-X
                   MOVE 'XS00000025'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
      *MSG: RECORD NOT KLOND
016483*            MOVE 'CS05210033'  TO WGLOB-MSG-REF-INFO
016483             MOVE 'CS05210032'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   PERFORM  9100-BLANK-DATA-FIELDS
                       THRU 9100-BLANK-DATA-FIELDS-X
                   GO TO 7000-PROCESS-KLON-X
               END-IF
           END-IF.
      *
      *---- KLON UNTIL PACK END-OF-FILE OR OUTSIDE KLON RANGE
      *
           MOVE 0                     TO COUNT-KLON-RECS.
      *
           PERFORM  7220-CHECK-KLON-ONE-REC
               THRU 7220-CHECK-KLON-ONE-REC-X
                UNTIL WPACK-IO-EOF.

           PERFORM  PACK-3000-END-BROWSE
               THRU PACK-3000-END-BROWSE-X.

      * MSG: @1 PACK RECORDS KLOND
           MOVE 'CS05210028'          TO WGLOB-MSG-REF-INFO.
           MOVE COUNT-KLON-RECS       TO WGLOB-MSG-PARM (1).
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

       7000-PROCESS-KLON-X.
           EXIT.
      /
010418*****************
010418 7110-KLON-1ST-EDITS.
010418*****************
010418*
010418* LG, ADDL PLAN, RS, MANDATORY NOT REQUIRED FOR KLON FUNCTION
010418*
010418     IF MIR-LOC-GR-ID NOT = SPACES
010418        MOVE SPACES             TO  MIR-LOC-GR-ID
010418     END-IF.

010418     IF MIR-ADDL-PLAN-ID NOT = SPACES
010418        MOVE SPACES             TO  MIR-ADDL-PLAN-ID
010418     END-IF.

010418     IF MIR-ADDL-PLAN-MAND-IND NOT = SPACES
010418        MOVE SPACES             TO  MIR-ADDL-PLAN-MAND-IND
010418     END-IF.

010418*
010418*---- CHECK KLON SOURCE EXIST OR NOT
010418*
010418     MOVE LOW-VALUES            TO WPACK-KEY.
           MOVE MIR-BASIC-PLAN-ID     TO WPACK-BASIC-PLAN-ID.
010418     MOVE MIR-SBSDRY-CO-ID      TO WPACK-SBSDRY-CO-ID.
010418
010418     MOVE HIGH-VALUES           TO WPACK-ENDBR-KEY.
           MOVE MIR-BASIC-PLAN-ID     TO WPACK-ENDBR-BASIC-PLAN-ID.
010418     MOVE MIR-SBSDRY-CO-ID      TO WPACK-ENDBR-SBSDRY-CO-ID.
010418*
010418     PERFORM  PACK-1000-BROWSE
010418         THRU PACK-1000-BROWSE-X.
010418*
010418     IF WPACK-IO-EOF
010418     OR NOT WPACK-IO-OK
010418* MSG: KLON SOURCE NOT FOUND
010418         MOVE 'CS05210027'      TO WGLOB-MSG-REF-INFO
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418         GO TO 7110-KLON-1ST-EDITS-X
010418     ELSE
010418         PERFORM  PACK-2000-READ-NEXT
010418             THRU PACK-2000-READ-NEXT-X
010418         IF WPACK-IO-EOF
010418         OR NOT WPACK-IO-OK
010418* MSG: KLON SOURCE NOT FOUND
010418             MOVE 'CS05210027'  TO WGLOB-MSG-REF-INFO
010418             PERFORM  0260-1000-GENERATE-MESSAGE
010418                 THRU 0260-1000-GENERATE-MESSAGE-X
010418         END-IF
010418     END-IF.

010418     PERFORM PACK-3000-END-BROWSE
010418        THRU PACK-3000-END-BROWSE-X.
010418*
010418 7110-KLON-1ST-EDITS-X.
010418     EXIT.
010418*
010418*********************
010418 7210-KLON-2ND-EDITS.
010418*********************
010418
010418* CHECK DESTINATION PLAN ID
010418
           MOVE MIR-BASIC-PLAN-ID-2   TO  WPH-PLAN-ID.

010418     PERFORM  PH-1000-READ
010418         THRU PH-1000-READ-X.

010418     IF NOT WPH-IO-OK
010418*        MSG: 'BASIC PLAN INVALID - @1 '
014591*        MOVE WPH-PLAN-ID-BASE  TO WGLOB-MSG-PARM (1)
014591*        MOVE WPH-PLAN-ID-RS    TO WGLOB-MSG-PARM (2)
014591         MOVE WPH-PLAN-ID       TO WGLOB-MSG-PARM (1)
010418         MOVE 'CS05210001'      TO WGLOB-MSG-REF-INFO
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418         GO TO 7210-KLON-2ND-EDITS-X
010418     END-IF.
010418*
010418*
010418*---- CHECK KLON DESTINATION MUST NOT EXIST IN PACK
010418*
010418     MOVE LOW-VALUES            TO WPACK-KEY.
010418     MOVE HIGH-VALUES           TO WPACK-ENDBR-KEY.
           MOVE MIR-BASIC-PLAN-ID-2   TO WPACK-BASIC-PLAN-ID.
           MOVE MIR-BASIC-PLAN-ID-2   TO WPACK-ENDBR-BASIC-PLAN-ID.
           MOVE MIR-SBSDRY-CO-ID-2    TO WPACK-SBSDRY-CO-ID.
010418     MOVE MIR-SBSDRY-CO-ID-2    TO WPACK-ENDBR-SBSDRY-CO-ID.
010418*
010418     PERFORM  PACK-1000-BROWSE
010418         THRU PACK-1000-BROWSE-X.
010418*
010418     IF NOT WPACK-IO-OK
010418     OR WPACK-IO-EOF
010418         GO TO 7210-KLON-2ND-EDITS-X
010418     ELSE
010418         PERFORM PACK-2000-READ-NEXT
010418             THRU PACK-2000-READ-NEXT-X
010418         IF NOT WPACK-IO-EOF
010418* MSG:  KLON DESTINATION <@1 @2 @3> ALREADY EXISTS
010418             MOVE 'CS05210029'  TO WGLOB-MSG-REF-INFO
010418             MOVE MIR-BASIC-PLAN-ID-2
                                      TO WGLOB-MSG-PARM (1)
010418             MOVE MIR-SBSDRY-CO-ID-2
                                      TO WGLOB-MSG-PARM (3)
010418             PERFORM  0260-1000-GENERATE-MESSAGE
010418                 THRU 0260-1000-GENERATE-MESSAGE-X
010418         END-IF
010418     END-IF.

010418     PERFORM  PACK-3000-END-BROWSE
010418         THRU PACK-3000-END-BROWSE-X.
010418*
010418 7210-KLON-2ND-EDITS-X.
010418     EXIT.
010418*************************
010418 7220-CHECK-KLON-ONE-REC.
010418*************************
010418
010418*
010418*==== USING SEPARATE BRWOSE AND WRITE CURSOR
010418*
010418     MOVE WPACK-KEY             TO HOLD-LAST-PACK-KEY.
010418*
010418*---- CREATE PACK WITH NEW KLONED BASIC PLAN AND SUB-COMPANY
010418*----        USING SAME ROUTINE IN CREATION LOGIC
           MOVE MIR-BASIC-PLAN-ID-2   TO WPACK-BASIC-PLAN-ID.
           MOVE MIR-BASIC-PLAN-ID-2   TO RPACK-BASIC-PLAN-ID.
           MOVE MIR-SBSDRY-CO-ID-2    TO WPACK-SBSDRY-CO-ID.
           MOVE MIR-SBSDRY-CO-ID-2    TO RPACK-SBSDRY-CO-ID.
010418
010418     PERFORM  PACK-1000-WRITE
010418         THRU PACK-1000-WRITE-X.
010418
014221     MOVE MIR-BASIC-PLAN-ID     TO WPH-PLAN-ID.

014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.

010418     IF WGLOB-MSG-ERROR-SW = ZERO
010418         ADD 1                   TO COUNT-KLON-RECS
010418     END-IF.
010418     MOVE HOLD-LAST-PACK-KEY    TO WPACK-KEY.
010418     PERFORM  PACK-2000-READ-NEXT
010418         THRU PACK-2000-READ-NEXT-X.
010418*
010418 7220-CHECK-KLON-ONE-REC-X.
010418     EXIT.
010418
      /
      *----------------------------------------------------------
      *   BUILD PACK READ KEY.
      *----------------------------------------------------------
       8000-BUILD-PACK-KEY.

           MOVE MIR-BASIC-PLAN-ID     TO WPACK-BASIC-PLAN-ID.
010302     MOVE MIR-LOC-GR-ID         TO WPACK-LOC-GR-ID.
010418     MOVE MIR-SBSDRY-CO-ID      TO WPACK-SBSDRY-CO-ID.
           MOVE MIR-ADDL-PLAN-ID      TO WPACK-ADDL-PLAN-ID.
557659*    MOVE MIR-ADDL-PLAN-MAND-IND  TO WPACK-ADDL-PLAN-MAND-CD.
557659     MOVE MIR-ADDL-PLAN-MAND-IND  TO WPACK-ADDL-PLAN-MAND-IND.

       8000-BUILD-PACK-KEY-X.
           EXIT.
      /
      *----------------------------------------------------------
      *   BLANK DATA FIELDS: SET EACH DATA (NON-KEY AND NON-CONTROL)
      *   FIELD ON THE SCREEN TO SPACES.
      *----------------------------------------------------------
       9100-BLANK-DATA-FIELDS.

           PERFORM  9110-BLANK-DISPLAY-LINE
               THRU 9110-BLANK-DISPLAY-LINE-X
                 VARYING WS-LINE FROM 1 BY 1
                   UNTIL WS-LINE > WS-NUMBER-OF-DISPLAY-LINES.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *----------------------------------------------------------
      *   BLANK EACH DATA LINE ON SCREEN
      *----------------------------------------------------------
       9110-BLANK-DISPLAY-LINE.

           MOVE SPACES                TO MIR-BASIC-PLAN-ID-T (WS-LINE).
010302     MOVE SPACES                TO MIR-LOC-GR-ID-T  (WS-LINE).
010418     MOVE SPACES                TO MIR-SBSDRY-CO-ID-T (WS-LINE).
           MOVE SPACES                TO MIR-ADDL-PLAN-ID-T (WS-LINE).
           MOVE SPACES            TO MIR-ADDL-PLAN-MAND-IND-T (WS-LINE).
           MOVE SPACES               TO MIR-PLAN-PKG-TYP-CD-T (WS-LINE).
           MOVE SPACES                TO MIR-PLAN-PKG-WP-CD-T (WS-LINE).
           MOVE SPACES               TO MIR-PLAN-PKG-ADB-CD-T (WS-LINE).
010418*    MOVE SPACES      TO C0521-PLAN-ID.
010418*    MOVE SPACES      TO C0521-RATE-SCALE.
010418*    MOVE SPACES      TO C0521-SBSDRY-CO-ID.

       9110-BLANK-DISPLAY-LINE-X.
           EXIT.
      /
      *----------------------------------------------------------
      *   RECORD TO SCREEN:                                   INPUT: WS
      *   SHIFT DATA FROM RECORD BUFFER TO THE SCREEN DISPLAY LINE GIVE
      *   THE INPUT ITEM WS-LINE.
      *----------------------------------------------------------
       9200-MOVE-RECORD-TO-SCREEN.

           MOVE RPACK-BASIC-PLAN-ID
                                      TO MIR-BASIC-PLAN-ID-T (WS-LINE).
010302     MOVE RPACK-LOC-GR-ID       TO MIR-LOC-GR-ID-T (WS-LINE).
010418     MOVE RPACK-SBSDRY-CO-ID    TO MIR-SBSDRY-CO-ID-T (WS-LINE).
           MOVE RPACK-ADDL-PLAN-ID
                                      TO MIR-ADDL-PLAN-ID-T (WS-LINE).
557659*    MOVE RPACK-ADDL-PLAN-MAND-CD TO
557659*                           TO MIR-ADDL-PLAN-MAND-IND-T (WS-LINE).
557659     MOVE RPACK-ADDL-PLAN-MAND-IND
557659                            TO MIR-ADDL-PLAN-MAND-IND-T (WS-LINE).
557659*    MOVE RPACK-ADDL-PLAN-TYP-IND TO
557659*                           TO MIR-PLAN-PKG-TYP-CD-T (WS-LINE).
557659     MOVE RPACK-PLAN-PKG-TYP-CD
                                     TO MIR-PLAN-PKG-TYP-CD-T (WS-LINE).
557659*    MOVE RPACK-WP-ALLOW-IND   TO MIR-PLAN-PKG-WP-CD-T (WS-LINE).
557659     MOVE RPACK-PLAN-PKG-WP-CD  TO MIR-PLAN-PKG-WP-CD-T (WS-LINE).
557659*    MOVE RPACK-AD-ALLOW-IND   TO MIR-PLAN-PKG-ADB-CD-T (WS-LINE).
557659     MOVE RPACK-PLAN-PKG-ADB-CD
                                     TO MIR-PLAN-PKG-ADB-CD-T (WS-LINE).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *----------------------------------------------------------
      *   UPDATE SCREEN KEYS FROM RECORD:
      *   UPDATE THE SCREEN KEYS FROM THE RECORD BUFFER FOR BROWSE TYPE
      *   INQUIRIES FOR PAGING.
      *----------------------------------------------------------
       9250-UPDATE-SCREEN-KEYS.

           MOVE RPACK-BASIC-PLAN-ID   TO MIR-BASIC-PLAN-ID.
010302     MOVE RPACK-LOC-GR-ID       TO MIR-LOC-GR-ID.
010418     MOVE RPACK-SBSDRY-CO-ID    TO MIR-SBSDRY-CO-ID.
557659*    MOVE RPACK-ADDL-PLAN-MAND-CD TO MIR-ADDL-PLAN-MAND-IND.
557659     MOVE RPACK-ADDL-PLAN-MAND-IND
                                      TO MIR-ADDL-PLAN-MAND-IND.
           MOVE RPACK-ADDL-PLAN-ID
                                      TO MIR-ADDL-PLAN-ID.

       9250-UPDATE-SCREEN-KEYS-X.
           EXIT.
      /
      *----------------------------------------------------------
      *   SET REFERENCE: MOVE DATA WHICH IDENTIFIES THE OBJECT THAT IS
      *   WORKED ON TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING.
      *----------------------------------------------------------
       9300-SETUP-MSIN-REFERENCE.

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE       WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     SET WS-NUMBER-OF-LINES-DEFAULT TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT        TO TRUE.
025970     SET WS-KEY-EDIT-VALID  TO TRUE.
025970     SET WS-DATA-EDIT-VALID TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK                TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
      /
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY PH
014221                         '$VAR2' BY 'PH'.
014660*COPY XCPPMEXT.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
010302 COPY CCPELGAS.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
      /
       COPY CCPAPACK.
       COPY CCPBPACK.
       COPY CCPNPACK.
       COPY CCPUPACK.
       COPY CCPXPACK.
       COPY CCPCPACK.
      /
010302 COPY CCPNEDIT.
      /
010418 COPY CCPNSCOM.
      /
016537*COPY CCPBPH.
       COPY CCPNPH.
014221 COPY CCPUPH.
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM0521                     **
      *****************************************************************
