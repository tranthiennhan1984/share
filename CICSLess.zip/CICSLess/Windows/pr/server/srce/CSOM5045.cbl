      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM5045.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5045                                         **
      **  REMARKS:  CREDIT CARD DRAW HISTORY POLICY LIST             **
      **                                                             **
      **  DOMAIN:   BC                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016395**  6.2       NEW                                              **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
021042**  6.4       KEY SETUP FOR CRTY                               **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5045'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

021930*COPY XCWEBLCH.

025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LIST-LINES                   PIC S9(04) BINARY.
025970         88  WS-MAX-LIST-LINES-DEFAULT       VALUE +100.

       01  WS-WORKING-STORAGE.
025970*    05  WS-SUB                      PIC S9(4)  VALUE ZERO COMP.
025970     05  WS-SUB                      PIC S9(4)  VALUE ZERO BINARY.
025970*    05  WS-MAX-LIST-LINES           PIC S9(4)  VALUE +100 COMP.
           05  WS-BUS-FCN-ID               PIC X(04).
               88  WS-BUS-FCN-LIST-POL                VALUE '5045'.
           05  DISPLAY-NUMBER-3            PIC 999.
           05  WS-PIC-999                  PIC 999.
           05  WS-DUE-DATE                 PIC X(10).
           05  WS-POL-ID.
               10  WS-POL-ID-BASE          PIC X(9).
               10  WS-POL-ID-SUFFIX        PIC X.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWCRTY.
       COPY CCFRCRTX.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWL0280.
      /
       COPY XCWL0290.
      /
       COPY XCWL1640.
      /
021930*COPY XCWL1660.
021930*
021930*COPY XCWL1670.
021930*
021930*COPY XCWL1680.
021930*
       COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM5045.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST-POL
                    PERFORM  2000-PROCESS-LIST-POLICY
                        THRU 2000-PROCESS-LIST-POLICY-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM5045'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'     TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-------------------------
       2000-PROCESS-LIST-POLICY.
      *-------------------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  CRTY-1000-BROWSE
               THRU CRTY-1000-BROWSE-X.

           PERFORM  CRTY-2000-READ-NEXT
               THRU CRTY-2000-READ-NEXT-X.

           IF  NOT WCRTY-IO-OK
      * MSG: RECORD NOT FOUND TO DISPLAY.
               MOVE 'XS00000034'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-PROCESS-LIST-POLICY-X
           END-IF.

           PERFORM  2010-BROWSE-CRTY
               THRU 2010-BROWSE-CRTY-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-LIST-LINES
               OR WCRTY-IO-EOF.

           IF  WCRTY-IO-EOF
               MOVE 'XS00000015' TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
               MOVE 'XS00000014' TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RCRTX-CRC-TYP-CD        TO MIR-CRC-TYP-CD
               MOVE RCRTX-CRC-ID            TO MIR-CRC-ID
               MOVE RCRTX-CRC-TRXN-DT       TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE     TO MIR-CRC-TRXN-DT
               MOVE RCRTX-POL-ID-BASE       TO MIR-POL-ID-BASE
               MOVE RCRTX-POL-ID-SFX        TO MIR-POL-ID-SFX
               MOVE RCRTX-CRC-TRXN-DUE-DT   TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE     TO MIR-CRC-TRXN-DUE-DT
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                       RCRTX-CRC-TRXN-SEQ-NUM   * 1
020874         MOVE RCRTX-CRC-TRXN-SEQ-NUM  TO L0290-INPUT-V00
               MOVE 0                       TO L0290-PRECISION
               MOVE LENGTH OF MIR-CRC-TRXN-SEQ-NUM
                                            TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA     TO MIR-CRC-TRXN-SEQ-NUM
           END-IF.

           PERFORM  CRTY-3000-END-BROWSE
               THRU CRTY-3000-END-BROWSE-X.

       2000-PROCESS-LIST-POLICY-X.
           EXIT.
      /
      *-----------------
       2010-BROWSE-CRTY.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  CRTY-2000-READ-NEXT
               THRU CRTY-2000-READ-NEXT-X.

       2010-BROWSE-CRTY-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE MIR-CRC-TYP-CD        TO WCRTY-CRC-TYP-CD.
           MOVE MIR-CRC-ID            TO WCRTY-CRC-ID.
           MOVE MIR-CRC-TRXN-DT       TO L1640-EXTERNAL-DATE.

020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
021042*        MOVE WWKDT-ZERO-DT     TO WCRTY-CRC-TRXN-DT
021042         MOVE WWKDT-LOW-DT      TO WCRTY-CRC-TRXN-DT
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO WCRTY-CRC-TRXN-DT
           END-IF.

           MOVE MIR-CRC-TRXN-SEQ-NUM  TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED  TO TRUE.
           MOVE 4                     TO L0280-LENGTH.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 4                     TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT      TO WCRTY-CRC-TRXN-SEQ-NUM
           ELSE
      * MSG: 'INVALID NUMERIC FIELD'
               MOVE 'XS00000018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE ZERO              TO WCRTY-CRC-TRXN-SEQ-NUM
           END-IF.

           MOVE MIR-POL-ID-BASE       TO WS-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WS-POL-ID-SUFFIX.
           IF  WS-POL-ID = SPACES
               MOVE LOW-VALUES        TO WCRTY-POL-ID
           ELSE
               MOVE WS-POL-ID         TO WCRTY-POL-ID
           END-IF.

           MOVE MIR-CRC-TRXN-DUE-DT   TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               MOVE WWKDT-LOW-DT      TO WCRTY-CRC-TRXN-DUE-DT
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO WCRTY-CRC-TRXN-DUE-DT
           END-IF.

           MOVE WCRTY-KEY             TO WCRTY-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WCRTY-ENDBR-POL-ID.
           MOVE WWKDT-HIGH-DT         TO WCRTY-ENDBR-CRC-TRXN-DUE-DT.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES            TO MIR-CRC-TRXN-STAT-CD-G.
           MOVE SPACES            TO MIR-POL-ID-BASE-G.
           MOVE SPACES            TO MIR-POL-ID-SFX-G.
           MOVE SPACES            TO MIR-CRC-TRXN-DUE-DT-G.
           MOVE SPACES            TO MIR-CRC-TRXN-AMT-G.
           MOVE SPACES            TO MIR-CRC-TRXN-MPREM-AMT-G.
           MOVE SPACES            TO MIR-CRC-TRXN-LOAN-AMT-G.
           MOVE SPACES            TO MIR-CRC-TRXN-SNDRY-AMT-G.
           MOVE SPACES            TO MIR-PREM-SUSP-AMT-G.
           MOVE SPACES            TO MIR-CRC-TRXN-RCHRG-IND-G.
           MOVE SPACES            TO MIR-CRC-TRXN-CRCY-CD-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RCRTX-POL-ID-SFX      TO MIR-POL-ID-SFX-T (WS-SUB).
           MOVE RCRTX-POL-ID-BASE     TO MIR-POL-ID-BASE-T (WS-SUB).
           MOVE RCRTX-CRC-TRXN-DUE-DT TO L1640-INTERNAL-DATE.

020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE   TO MIR-CRC-TRXN-DUE-DT-T (WS-SUB).


           MOVE RCRTX-CRC-TRXN-STAT-CD
                                     TO MIR-CRC-TRXN-STAT-CD-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         RCRTX-CRC-TRXN-AMT         * 100.
020874     MOVE RCRTX-CRC-TRXN-AMT    TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CRC-TRXN-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA  TO MIR-CRC-TRXN-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         RCRTX-CRC-TRXN-MPREM-AMT   * 100.
020874     MOVE RCRTX-CRC-TRXN-MPREM-AMT  TO L0290-INPUT-V02.
           MOVE 2                         TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CRC-TRXN-MPREM-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA  TO MIR-CRC-TRXN-MPREM-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         RCRTX-CRC-TRXN-LOAN-AMT    *  100.
020874     MOVE RCRTX-CRC-TRXN-LOAN-AMT  TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CRC-TRXN-LOAN-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA   TO MIR-CRC-TRXN-LOAN-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         RCRTX-CRC-TRXN-SNDRY-AMT   *  100.
020874     MOVE RCRTX-CRC-TRXN-SNDRY-AMT  TO L0290-INPUT-V02.
           MOVE 2                         TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CRC-TRXN-SNDRY-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA  TO MIR-CRC-TRXN-SNDRY-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         RCRTX-PREM-SUSP-AMT    *  100.
020874     MOVE RCRTX-PREM-SUSP-AMT   TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           SET L0290-SIGN-DISPLAY          TO TRUE.
           SET L0290-SIGN-POS-DISPLAY      TO TRUE.
           MOVE LENGTH OF MIR-PREM-SUSP-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-PREM-SUSP-AMT-T (WS-SUB).

           MOVE RCRTX-CRC-TRXN-RCHRG-IND
                                 TO MIR-CRC-TRXN-RCHRG-IND-T (WS-SUB).

           MOVE RCRTX-CRC-TRXN-CRCY-CD
                                 TO MIR-CRC-TRXN-CRCY-CD-T (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     INITIALIZE WS-WORKING-STORAGE.
025970     MOVE SPACES                    TO WWKDT-WORK-FIELDS.
025970     SET WS-MAX-LIST-LINES-DEFAULT  TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY XCPL0260.
      /
       COPY XCPL0290.
       COPY XCPS0290.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
021930*COPY XCPL1660.
021930*
021930*COPY XCPL1680.
021930*
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPBCRTY.
021930*COPY CCPNCRTY.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      /
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM5045                     **
      *****************************************************************
