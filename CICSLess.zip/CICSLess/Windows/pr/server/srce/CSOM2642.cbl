      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2642.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2642                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE RECORD UPDATE FUNCTION  **
      **            FOR THE PBMF TABLE                               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2642'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-UPDATE         VALUE '2642'.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970*                                      VALUE '2642'.                                          
025970 01  WS-CONSTANT-FIELDS.
025970     05  WS-TWRK-KEY                      PIC X(04).  
025970         88  WS-TWRK-KEY-DEFAULT          VALUE '2642'. 

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWEBLCH.
      /
       COPY XCWL8090.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
       COPY CCFWPBMF.
       COPY CCFRPBMF.
      /
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL8960.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2642.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
           SET MIR-RETRN-OK                   TO TRUE.


           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2642'               TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'             TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST     TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-----------
       2000-UPDATE.
      *-----------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  8010-EDIT-KEY-FIELDS
               THRU 8010-EDIT-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-EDIT-ERROR       TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.
      *
      *  THE GROUP LEVEL RECORD MUST EXIST AND HAVE A CURRENT TIMESTAMP
      *
           PERFORM  PH-2000-UPDATE-TWRK-TS
               THRU PH-2000-UPDATE-TWRK-TS-X.

           IF  WPH-IO-NOT-FOUND
      *MSG: LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS
               MOVE 'WPH'                      TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'               TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED       TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG: PROCESS FAILED - RE-ENTER DATA AS ANOTHER PROCESS HAS
      *     UPDATED - TABLE (@1), KEY @2
              MOVE 'XS00000303'                TO WGLOB-MSG-REF-INFO
              MOVE 'PH'                        TO WGLOB-MSG-PARM (1)
              MOVE WPH-KEY                     TO WGLOB-MSG-PARM (2)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-TS-MISMATCH       TO TRUE
              GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  PBMF-1000-READ-FOR-UPDATE
               THRU PBMF-1000-READ-FOR-UPDATE-X.

           IF  WPBMF-IO-OK
               CONTINUE
           ELSE
               PERFORM  PH-3000-UNLOCK
                   THRU PH-3000-UNLOCK-X
      *MSG: PBMF (@1) NOT FOUND
               MOVE 'CS26420005'               TO WGLOB-MSG-REF-INFO
               MOVE WPBMF-KEY                  TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED       TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.
      *
      *  EDIT THE DATA ENTERED FOR THE RECORD
      *
           PERFORM  8020-EDIT-PLAN-BMF-FCT
               THRU 8020-EDIT-PLAN-BMF-FCT-X

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  PBMF-3000-UNLOCK
                   THRU PBMF-3000-UNLOCK-X
               PERFORM  PH-3000-UNLOCK
                   THRU PH-3000-UNLOCK-X
               SET MIR-RETRN-EDIT-ERROR        TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X

           PERFORM  PBMF-2000-REWRITE
               THRU PBMF-2000-REWRITE-X.

           PERFORM  PH-2000-REWRITE
               THRU PH-2000-REWRITE-X.
      *
      *  UPDATE GROUP LEVEL TIMESTAMP FOR LOGICAL LOCKING
      *
           PERFORM  PH-1000-READ-TWRK-TS
               THRU PH-1000-READ-TWRK-TS-X.

       2000-UPDATE-X.
           EXIT.

      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE MIR-PLAN-ID                  TO WPBMF-PLAN-ID.
           MOVE MIR-PLAN-BMF-BILL-CD         TO WPBMF-PLAN-BMF-BILL-CD.
           MOVE MIR-PLAN-BMF-MODE-CD         TO WPBMF-PLAN-BMF-MODE-CD.
           MOVE MIR-PLAN-BMF-TYP-CD          TO WPBMF-PLAN-BMF-TYP-CD.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *--------------------
       8010-EDIT-KEY-FIELDS.
      *--------------------

           PERFORM  8011-EDIT-PLAN-ID
               THRU 8011-EDIT-PLAN-ID-X.

           PERFORM  8012-EDIT-BMF-BILL-CD
               THRU 8012-EDIT-BMF-BILL-CD-X.

           PERFORM  8013-EDIT-BMF-MODE-CD
               THRU 8013-EDIT-BMF-MODE-CD-X.

           PERFORM  8014-EDIT-BMF-TYP-CD
               THRU 8014-EDIT-BMF-TYP-CD-X.

       8010-EDIT-KEY-FIELDS-X.
           EXIT.

      *------------------
       8011-EDIT-PLAN-ID.
      *------------------

           IF  MIR-PLAN-ID =  SPACES
           OR  MIR-PLAN-ID = EBLCH-BLANK-FIELD-CHAR
      *MSG: PLAN CODE MUST NOT BE BLANK
               MOVE 'CS26420001'              TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                        TO WGLOB-MSG-ERROR-SW
               GO TO 8011-EDIT-PLAN-ID-X
           END-IF.

           MOVE MIR-PLAN-ID                   TO  WPH-PLAN-ID.

           PERFORM  PH-1000-READ
               THRU PH-1000-READ-X.

           IF  WPH-IO-NOT-FOUND
      *MSG: RECORD (@1) NOT FOUND
              MOVE WPH-PLAN-ID                TO WGLOB-MSG-PARM (1)
              MOVE 'PH'                       TO WGLOB-MSG-PARM (2)
              MOVE 'XS00000001'               TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                        TO WGLOB-MSG-ERROR-SW
              GO TO 8011-EDIT-PLAN-ID-X
           END-IF.

       8011-EDIT-PLAN-ID-X.
           EXIT.

      *---------------------
       8012-EDIT-BMF-BILL-CD.
      *---------------------

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'PLAN-BILL-TYP-CD'            TO L8960-AV-TBL-CD.
           MOVE MIR-PLAN-BMF-BILL-CD          TO L8960-AV-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.

           IF  L8960-RETRN-OK
               CONTINUE
           ELSE
      *MSG: INVALID PLAN BILLING CODE @1
               MOVE 'CS26420002'             TO WGLOB-MSG-REF-INFO
               MOVE MIR-PLAN-BMF-BILL-CD     TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                        TO WGLOB-MSG-ERROR-SW
               GO TO 8012-EDIT-BMF-BILL-CD-X
           END-IF.

       8012-EDIT-BMF-BILL-CD-X.
           EXIT.

      *---------------------
       8013-EDIT-BMF-MODE-CD.
      *---------------------

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'PLAN-BILL-MODE-CD'          TO L8960-AV-TBL-CD.
           MOVE MIR-PLAN-BMF-MODE-CD         TO L8960-AV-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.

           IF  L8960-RETRN-OK
               CONTINUE
           ELSE
      *MSG: INVALID PLAN BILLING MODE @1
               MOVE 'CS26420003'             TO WGLOB-MSG-REF-INFO
               MOVE MIR-PLAN-BMF-MODE-CD     TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                        TO WGLOB-MSG-ERROR-SW
               GO TO 8013-EDIT-BMF-MODE-CD-X
           END-IF.

       8013-EDIT-BMF-MODE-CD-X.
           EXIT.

      *---------------------
       8014-EDIT-BMF-TYP-CD.
      *---------------------

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'PLAN-BMF-TYP-CD'            TO L8960-AV-TBL-CD.
           MOVE MIR-PLAN-BMF-TYP-CD          TO L8960-AV-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.

           IF  L8960-RETRN-OK
               CONTINUE
           ELSE
      *MSG: INVALID PLAN BILLING FACTOR @1
               MOVE 'CS26420004'             TO WGLOB-MSG-REF-INFO
               MOVE MIR-PLAN-BMF-TYP-CD      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                        TO WGLOB-MSG-ERROR-SW
               GO TO 8014-EDIT-BMF-TYP-CD-X
           END-IF.

       8014-EDIT-BMF-TYP-CD-X.
           EXIT.

      *-----------------------
       8020-EDIT-PLAN-BMF-FCT.
      *-----------------------

           MOVE MIR-PLAN-BMF-FCT            TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-PLAN-BMF-FCT  TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
           MOVE +7                          TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V07        TO RPBMF-PLAN-BMF-FCT
               MOVE L0280-OUTPUT-V07        TO L0290-INPUT-V07
               MOVE 7                       TO L0290-PRECISION
               MOVE LENGTH OF MIR-PLAN-BMF-FCT
                                            TO L0290-MAX-OUT-LEN
               SET  L0290-SIGN-SUPPRESS     TO TRUE
               PERFORM 0290-2000-FORMAT-FOR-MIR
                  THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA       TO MIR-PLAN-BMF-FCT
           ELSE
      *MSG: PLAN FACTOR REQUIRES A NUMERIC VALUE
               MOVE 'CS26420006'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 8020-EDIT-PLAN-BMF-FCT-X
           END-IF.

       8020-EDIT-PLAN-BMF-FCT-X.
           EXIT.
      /
      *----------------------
       9000-BLANK-DATA-FIELDS.
      *----------------------

           MOVE SPACES                       TO MIR-IO-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9200-MOVE-RECORD-TO-MIR.
      *--------------------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           MOVE RPBMF-PLAN-BMF-FCT           TO L0290-INPUT-V07.
           MOVE 7                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PLAN-BMF-FCT   TO L0290-MAX-OUT-LEN.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA            TO MIR-PLAN-BMF-FCT.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                       TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE           TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
      
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE      WS-WORKING-STORAGE.
025970*    CONTINUE.
025970     SET  WS-TWRK-KEY-DEFAULT            TO TRUE.
025970     MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  PH
                                '$VAR2'   BY 'PH'.
       COPY XCPL8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
      /
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
       COPY XCPS8960.
       COPY XCPL8960.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPH.
       COPY CCPUPH.
      /
       COPY CCPUPBMF.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM 'CSOM2642'                   **
      *****************************************************************
