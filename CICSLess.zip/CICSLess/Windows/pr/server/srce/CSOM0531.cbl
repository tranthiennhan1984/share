      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0531.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0531                                         **
      **  REMARKS:  MAINTAIN THE HEALTH PACKAGING MATRIX (PACH) TABLE**
      **            THIS PROGRAM PERFORMS TABLE MAINTENANCE FUNCTIONS**
      **            ON THE PACKAGING MATRIX TABLE FOR DISABILITY     **
      **            AND OTHER HEALTH PRODUCTS (PACH).  THE MATRIX    **
      **            DEFINES THE PLANS, BENEFITS, AND RIDERS THAT     **
      **            ARE ALLOWED TO BE SOLD TOGETHER.  ALL BASIC OR   **
      **            ADDITIONAL PLANS ENTERED FOR PACKAGING MUST      **
      **            ALREADY EXIST ON THE PLAN HEADER (PH) TABLE.     **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       RENAME FILED RPACH-LTB-ALLOW-IND WITH            **
557659**            RPACH-LTB-ALLOW-CD                               **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557708**  5.5       CHANGES TO CICS ABEND PROCESSING                 **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010302**  5.6       ADD FUNCTIONALITY FOR NEW KEY FIELD              **
010302**            LOCATION GROUP CODE                              **
010311**  5.6       CODE CLEAN-UP                                    **
010418**  5.6       MODIFICATIONS TO PACH TO ALLOW CLONING           **
010418**            AND TO ADD SUB-CO                                **
013578**  6.0       ELIMINATE SUPPORT FOR THE CHARACTER INTERFACE    **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       MESSAGE SUPPORT - REMOVAL OF XCPPMEXT            **
014221**  6.2       LOGICAL RECORD LOCKING                           **
014591**  6.2       COMBINE PLAN-ID & RS                             **
016483**  6.2       MESSAGE CLEANUP                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0531'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-CONSTANTS.
016548*    05  WS-NO-OF-DISPLAY-LINE        PIC S9(08) COMP
025970*    05  WS-NO-OF-DISPLAY-LINE        PIC S9(08) BINARY
025970*                                     VALUE +100.
025970     05  WS-NO-OF-DISPLAY-LINE        PIC S9(08) BINARY.
025970         88  WS-NO-LINE-DEFAULT       VALUE +100.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '0400'.

       01  WS-COUNTERS.
016548*    05  WS-LINE                      PIC S9(04) COMP.
016548     05  WS-LINE                      PIC S9(04) BINARY.

       01  WS-SWITCHES.
           05  WS-DATA-EDITS-SW             PIC X(01).
               88  WS-DATA-EDITS-OK         VALUE 'Y'.
014221         88  WS-DATA-EDITS-NOT-OK     VALUE 'N'.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '0400' '0401'
                                                  '0402' '0403'
                                                  '0404' '0405'
                                                  '0406'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '0400'.
               88  WS-BUS-FCN-CREATE        VALUE '0401'.
               88  WS-BUS-FCN-UPDATE        VALUE '0402'.
               88  WS-BUS-FCN-DELETE        VALUE '0403'.
               88  WS-BUS-FCN-LIST          VALUE '0404'.
               88  WS-BUS-FCN-SUMMARY       VALUE '0405'.
               88  WS-BUS-FCN-KLON          VALUE '0406'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '0400'.
           05  WS-LIST-TYPE                 PIC X(01).
               88  WS-LIST-TYPE-VALID       VALUE SPACE 'O' 'N'.
           05  WS-QUALIFIER                 PIC X(01).
               88  WS-QUALIFIER-VALID       VALUE '#' '=' '<' '>'.
               88  WS-QUALIFIER-VALID-BP    VALUE '#' '='.
           05  WS-BENEFIT-IND               PIC X(01).
               88  WS-BENEFIT-IND-VALID     VALUE 'N' 'Y'.
               88  WS-BENEFIT-IND-VALID-ATT VALUE 'N' 'Y' 'S' 'O' 'D'.
           05  WS-LIST-TYPE-CHANGED-SW      PIC X(01).
               88  WS-LIST-TYPE-CHANGED     VALUE 'Y'.
014591*    05  WS-PLAN-ID.
014591*        10  WS-PLAN-ID-BASE          PIC X(05).
014591*        10  WS-PLAN-ID-RS            PIC X(01).
010418     05  COUNT-KLON-RECS              PIC 9(4).
010418     05  HOLD-LAST-PACH-KEY           PIC X(17).

       01  WS-WORKING-STORAGE.
           05  WS-PIC-999                   PIC 9(03).
           05  WS-SAVE-LIST-TYPE            PIC X(01).

       COPY XCWEBLCH.
014221 COPY CCWWLOCK.
       COPY XCWWMATC.
016537*COPY XCWWWKDT.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
010418 COPY CCFWSCOM.
010418 COPY CCFRSCOM.
      /
       COPY CCFWPACH.
       COPY CCFRPACH.
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
       COPY XCWL0280.
020874 COPY XCWL0290.      
014221 COPY XCWL8090.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0531.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

025970*    SET MIR-RETRN-OK              TO  TRUE.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *****************************************************************
      *  PERFORM SECURITY PROCESSING AND INVOKE MODULES TO
      *      PROCESS USER REQUEST
      *****************************************************************

      *--------------------
       2000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *    MOVE ENTER CODE TO A WORK FIELD.
      *

           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

      *
      *    PROCESS SCREEN FUNCTIONS
      *

           IF  MIR-CONN-PLAN-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CONN-PLAN-ID
           END-IF.

           IF  MIR-CONN-PKG-NUM = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CONN-PKG-NUM
           END-IF.

           EVALUATE TRUE
              WHEN WS-BUS-FCN-RETRIEVE
                   PERFORM 2100-VALIDATE-KEY-FIELDS
                      THRU 2100-VALIDATE-KEY-FIELDS-X
                   IF WS-DATA-EDITS-OK
                      PERFORM  3000-PROCESS-RETRIEVE
                          THRU 3000-PROCESS-RETRIEVE-X
                   END-IF

              WHEN WS-BUS-FCN-LIST
              WHEN WS-BUS-FCN-SUMMARY
                   PERFORM 2100-VALIDATE-KEY-FIELDS
                      THRU 2100-VALIDATE-KEY-FIELDS-X
                   IF WS-DATA-EDITS-OK
                      PERFORM  3500-PROCESS-LIST
                          THRU 3500-PROCESS-LIST-X
                   END-IF

              WHEN WS-BUS-FCN-CREATE
                   PERFORM  4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

              WHEN  WS-BUS-FCN-UPDATE
                   PERFORM 2100-VALIDATE-KEY-FIELDS
                      THRU 2100-VALIDATE-KEY-FIELDS-X
                   IF WS-DATA-EDITS-OK
                      PERFORM  5000-PROCESS-UPDATE
                          THRU 5000-PROCESS-UPDATE-X
                   END-IF

              WHEN  WS-BUS-FCN-DELETE
                   PERFORM 2100-VALIDATE-KEY-FIELDS
                      THRU 2100-VALIDATE-KEY-FIELDS-X
                   IF WS-DATA-EDITS-OK
                      PERFORM  6000-PROCESS-DELETE
                          THRU 6000-PROCESS-DELETE-X
                   END-IF

               WHEN  WS-BUS-FCN-KLON
                   PERFORM 2100-VALIDATE-KEY-FIELDS
                      THRU 2100-VALIDATE-KEY-FIELDS-X
                   IF WS-DATA-EDITS-OK
                      PERFORM  7000-PROCESS-KLON
                          THRU 7000-PROCESS-KLON-X
                   END-IF

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                   MOVE 'XS00000237'         TO  WGLOB-MSG-REF-INFO
                   MOVE MIR-BUS-FCN-ID       TO  WGLOB-MSG-PARM (1)
                   MOVE 'CSOM0531'           TO  WGLOB-MSG-PARM (2)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-INVALD-RQST     TO  TRUE

           END-EVALUATE.


       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      **************************
       2100-VALIDATE-KEY-FIELDS.
      **************************

           MOVE 'Y'                   TO WS-DATA-EDITS-SW.

           IF MIR-DI-PKG-NUM = SPACES
               MOVE '001'             TO MIR-DI-PKG-NUM
           ELSE
               PERFORM 4120-EDIT-PKG-NO
                  THRU 4120-EDIT-PKG-NO-X
557660     END-IF.

           IF MIR-CONN-PKG-NUM NOT = SPACES
               PERFORM 4140-EDIT-ATT-PKG-NO
                  THRU 4140-EDIT-ATT-PKG-NO-X
557660     END-IF.

       2100-VALIDATE-KEY-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  INQUIRY PROCESSING: SETUP INQUIRE KEYS, AND READ RECORD
      *****************************************************************
      *---------------------
       3000-PROCESS-RETRIEVE.
      *---------------------

014221     MOVE MIR-PLAN-ID          TO WPH-PLAN-ID.

014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      ***  SETUP BROWSE KEY LIMITS
           PERFORM  8000-BUILD-PACH-KEY
               THRU 8000-BUILD-PACH-KEY-X.

           PERFORM  PACH-1000-READ
               THRU PACH-1000-READ-X.

           IF WPACH-IO-OK
               MOVE +1                TO WS-LINE
               PERFORM 9200-MOVE-RECORD-TO-SCREEN
                  THRU 9200-MOVE-RECORD-TO-SCREEN-X
      *MSG: (I) "INQUIRE COMPLETE, CONTINUE"
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG: "RECORD  @1 NOT FOUND "
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WPACH-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660         GO TO 3000-PROCESS-RETRIEVE-X
557660     END-IF.

      ***  ON INQUIRY, RESET BROWSE LIMITS SO THAT ONLY RECORDS
      ***  FOR THE CURRENT PACKAGE ARE READ

013578     MOVE RPACH-PLAN-ID         TO MIR-PLAN-ID.
010302     MOVE RPACH-LOC-GR-ID       TO MIR-LOC-GR-ID.
010418     MOVE RPACH-SBSDRY-CO-ID    TO MIR-SBSDRY-CO-ID.
           MOVE RPACH-DI-PKG-NUM      TO MIR-DI-PKG-NUM.
           MOVE RPACH-CONN-PLAN-ID    TO MIR-CONN-PLAN-ID
           MOVE RPACH-CONN-PKG-NUM    TO MIR-CONN-PKG-NUM.


       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      /
      *****************************************************************
      *  INQUIRY DISPLAY PROCESSING: DISPLAY THE CURRENT RECORD ONTO
      *  THE SCREEN DATA LINE GIVEN BY WS-LINE AND RETRIEVE THE NEXT
      *  RECORD.
      *****************************************************************
      *--------------------
       3100-DISPLAY-RECORD.
      *--------------------
      *
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
      *
           PERFORM  PACH-2000-READ-NEXT
               THRU PACH-2000-READ-NEXT-X.

           IF WS-BUS-FCN-SUMMARY
               PERFORM  PACH-2000-READ-NEXT
                   THRU PACH-2000-READ-NEXT-X
                   UNTIL RPACH-CONN-PKG-INFO = SPACES
                      OR NOT WPACH-IO-OK
557660     END-IF.
      *
       3100-DISPLAY-RECORD-X.
           EXIT.
      /
      *****************************************************************
      *  INQUIRY PROCESSING: SETUP BROWSE KEYS, BEGIN BROWSE, AND
      *  LOAD DATA UNTIL END-OF-FILE OR SCREEN IS FULL.
      *****************************************************************
      *-----------------
       3500-PROCESS-LIST.
      *-----------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      ***  SETUP BROWSE KEY LIMITS
           PERFORM  8000-BUILD-PACH-KEY
               THRU 8000-BUILD-PACH-KEY-X.

           MOVE HIGH-VALUES           TO WPACH-ENDBR-KEY.
           IF WS-BUS-FCN-LIST
               MOVE WPACH-PLAN-ID       TO WPACH-ENDBR-PLAN-ID
010418         MOVE WPACH-SBSDRY-CO-ID  TO WPACH-ENDBR-SBSDRY-CO-ID
010302         MOVE WPACH-LOC-GR-ID     TO WPACH-ENDBR-LOC-GR-ID
               MOVE WPACH-DI-PKG-NUM    TO WPACH-ENDBR-DI-PKG-NUM
557660     END-IF.

      ***  POSITION AT AND READ FIRST RECORD.
           PERFORM  PACH-1000-BROWSE
               THRU PACH-1000-BROWSE-X.
           IF NOT WPACH-IO-OK
      *MSG: 'NO RECORD FOUND TO DISPLAY'
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO  3500-PROCESS-LIST-X
557660     END-IF.

           PERFORM  PACH-2000-READ-NEXT
               THRU PACH-2000-READ-NEXT-X.

           IF NOT WPACH-IO-OK
010311        PERFORM  PACH-3000-END-BROWSE
010311            THRU PACH-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO  3500-PROCESS-LIST-X
557660     END-IF.

      *** IF SUMMARY DISPLAY, GET NEXT "BASE" PACKAGE
           IF WS-BUS-FCN-SUMMARY
               PERFORM  PACH-2000-READ-NEXT
                   THRU PACH-2000-READ-NEXT-X
                   UNTIL RPACH-CONN-PKG-INFO = SPACES
                      OR NOT WPACH-IO-OK
               IF NOT WPACH-IO-OK
                   PERFORM PACH-3000-END-BROWSE
                       THRU PACH-3000-END-BROWSE-X
      *MSG: 'NO RECORDS TO DISPLAY'
                   MOVE 'XS00000025'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO  3500-PROCESS-LIST-X
557660         END-IF
557660     END-IF.

           MOVE RPACH-PLAN-ID         TO MIR-PLAN-ID.
010302     MOVE RPACH-LOC-GR-ID       TO MIR-LOC-GR-ID.
010418     MOVE RPACH-SBSDRY-CO-ID    TO MIR-SBSDRY-CO-ID.
           MOVE RPACH-DI-PKG-NUM      TO MIR-DI-PKG-NUM.
           MOVE RPACH-CONN-PLAN-ID    TO MIR-CONN-PLAN-ID.
           MOVE RPACH-CONN-PKG-NUM    TO MIR-CONN-PKG-NUM.

      ***  LOAD SCREEN DATA ARRAY.
           PERFORM 3100-DISPLAY-RECORD
               THRU 3100-DISPLAY-RECORD-X
               VARYING WS-LINE FROM 1 BY 1
               UNTIL (WS-LINE > WS-NO-OF-DISPLAY-LINE)
                  OR (WPACH-IO-EOF).

      *  COMPLETION MESSAGE

           IF WPACH-IO-EOF
               IF WS-BUS-FCN-LIST
                   MOVE 'XS00000015'  TO WGLOB-MSG-REF-INFO
               ELSE
                   MOVE 'XS00000025'  TO WGLOB-MSG-REF-INFO
557660         END-IF
           ELSE
               MOVE RPACH-PLAN-ID              TO MIR-PLAN-ID
010302         MOVE RPACH-LOC-GR-ID   TO MIR-LOC-GR-ID
010418         MOVE RPACH-SBSDRY-CO-ID   TO MIR-SBSDRY-CO-ID
               MOVE RPACH-DI-PKG-NUM  TO MIR-DI-PKG-NUM
               MOVE RPACH-CONN-PLAN-ID
                                      TO MIR-CONN-PLAN-ID
               MOVE RPACH-CONN-PKG-NUM   TO MIR-CONN-PKG-NUM
      *MSG: '(I) PRESS ENTER TO VIEW MORE DATA'
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X

      ***  END THE BROWSE.
           PERFORM  PACH-3000-END-BROWSE
               THRU PACH-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *****************************************************************
      *  CREATE PROCESSING: TWO PASSES REQUIRED
      *      CHECK FOR RECORD.  IF NOT FOUND CREATE RECORD AND
      *      ALLOW USER TO MODIFY UNDER MAINTAIN PROCESSING
      *****************************************************************
      *-------------------
       4000-PROCESS-CREATE.
      *-------------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      ***  VALID CONTROL FIELDS MUST HAVE BEEN ENTERED.
           PERFORM  4100-EDIT-KEY-FIELDS
               THRU 4100-EDIT-KEY-FIELDS-X.
           IF NOT WS-DATA-EDITS-OK
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

      ***  BUILD CONTROL FIELDS.
           PERFORM  8000-BUILD-PACH-KEY
               THRU 8000-BUILD-PACH-KEY-X.

      ***  CHECK RECORD EXISTENCE.
           PERFORM  PACH-1000-READ
               THRU PACH-1000-READ-X.
           IF WPACH-IO-OK
      *MSG: 'RECORD (@1) ALREADY EXISTS'
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               MOVE WPACH-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE +1                TO WS-LINE
               PERFORM 9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

      ***  CREATE NEW RECORD.
           PERFORM  PACH-1000-CREATE
               THRU PACH-1000-CREATE-X.
           PERFORM  PACH-1000-WRITE
               THRU PACH-1000-WRITE-X.
      *MSG: '(I) RECORD CREATED'
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.

014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.

           MOVE +1                    TO WS-LINE.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

      *MSG: '(I) MAINTAIN DETAILS'
           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT KEY FIELDS ACCORDING TO THE DATA DICTIONARY
      *****************************************************************
      *---------------------
       4100-EDIT-KEY-FIELDS.
      *---------------------

           MOVE 'Y'                   TO WS-DATA-EDITS-SW.

           PERFORM  4110-EDIT-PLAN
               THRU 4110-EDIT-PLAN-X.

010418     PERFORM  4112-EDIT-SUB-CO-ID
010418         THRU 4112-EDIT-SUB-CO-ID-X.

010302     PERFORM  4114-EDIT-LOCATION-GROUP
010302         THRU 4114-EDIT-LOCATION-GROUP-X.

           PERFORM  4120-EDIT-PKG-NO
               THRU 4120-EDIT-PKG-NO-X.

           PERFORM  4130-EDIT-ATT-PLAN
               THRU 4130-EDIT-ATT-PLAN-X.

           PERFORM  4140-EDIT-ATT-PKG-NO
               THRU 4140-EDIT-ATT-PKG-NO-X.

           PERFORM  4190-XEDIT-KEY-FIELDS
               THRU 4190-XEDIT-KEY-FIELDS-X.

       4100-EDIT-KEY-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT PLAN:  MUST BE A VALID PLAN
      *****************************************************************
      *---------------
       4110-EDIT-PLAN.
      *---------------

010418*    IF MIR-RTSCL NOT = WMATC-MATCH-ANY-CHAR
           MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.

010418     PERFORM  PH-1000-READ
010418         THRU PH-1000-READ-X.
010418     IF WPH-IO-OK
010418         GO TO 4110-EDIT-PLAN-X
010418     ELSE
010418*MSG: 'PLAN CODE/RS MUST EXIST ON PHDR'
010418         MOVE 'CS05310001'      TO WGLOB-MSG-REF-INFO
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418         MOVE 'N'               TO WS-DATA-EDITS-SW
010418         GO TO 4110-EDIT-PLAN-X
010418     END-IF.

010418*    MOVE MIR-PLAN-ID      TO WPH-PLAN-ID-BASE.
010418*    MOVE HIGH-VALUES    TO WPH-PLAN-ID-RS.
010418*    MOVE WPH-PLAN-ID    TO WPH-ENDBR-PLAN-ID.
010418*    MOVE LOW-VALUES     TO WPH-PLAN-ID-RS.
010418*    PERFORM PH-1000-BROWSE
010418*       THRU PH-1000-BROWSE-X.
010418*
010418*    IF NOT WPH-IO-OK
010418*MSG: 'PLAN (WITH ANY RATE SCALE) MUST EXIST ON PHDR'
010418*        MOVE 'CS05310002'         TO WGLOB-MSG-REF-INFO
010418*        PERFORM 0260-1000-GENERATE-MESSAGE
010418*           THRU 0260-1000-GENERATE-MESSAGE-X
010418*        MOVE -1                   TO MIR-PLAN-ID-L
010418*        MOVE TATRB-KEYS-ERROR     TO MIR-PLAN-ID-A
010418*        MOVE TATRB-KEYS-ERROR     TO MIR-RTSCL-A
010418*        MOVE 'N'                  TO WS-DATA-EDITS-SW
010418*        GO TO 4110-EDIT-PLAN-X
010418*    END-IF.

010418*    PERFORM PH-2000-READ-NEXT
010418*       THRU PH-2000-READ-NEXT-X.

010418*    IF RPH-PLAN-ID-BASE NOT = MIR-PLAN-ID
010418*MSG: 'PLAN (WITH ANY RATE SCALE) MUST EXIST ON PHDR'
010418*        MOVE 'CS05310002'         TO WGLOB-MSG-REF-INFO
010418*        PERFORM 0260-1000-GENERATE-MESSAGE
010418*           THRU 0260-1000-GENERATE-MESSAGE-X
010418*        MOVE -1                   TO MIR-PLAN-ID-L
010418*        MOVE TATRB-KEYS-ERROR     TO MIR-PLAN-ID-A
010418*        MOVE TATRB-KEYS-ERROR     TO MIR-RTSCL-A
010418*        MOVE 'N'                  TO WS-DATA-EDITS-SW
010418*    END-IF.

010418*    PERFORM  PH-3000-END-BROWSE
010418*        THRU PH-3000-END-BROWSE-X.

       4110-EDIT-PLAN-X.
           EXIT.
      /
010418*******************
010418*  EDIT COMPANY ID.
010418*******************
010418*--------------------
010418 4112-EDIT-SUB-CO-ID.
010418*--------------------
010418     MOVE MIR-SBSDRY-CO-ID      TO WSCOM-SBSDRY-CO-ID.
010418     PERFORM  SCOM-1000-READ
010418         THRU SCOM-1000-READ-X.
010418     IF NOT WSCOM-IO-OK
010418*MSG: 'SUB-CO ID MUST EXIST ON SUB-COMPANY PROFILE'
010418          MOVE 'CS05310034'     TO WGLOB-MSG-REF-INFO
010418          PERFORM  0260-1000-GENERATE-MESSAGE
010418              THRU 0260-1000-GENERATE-MESSAGE-X
010418          MOVE 'N'              TO WS-DATA-EDITS-SW
010418     END-IF.

010418 4112-EDIT-SUB-CO-ID-X.
010418            EXIT.

010302*****************************************************************
010302*  EDIT LOCACTION GROUP; AGAINST EDIT/LOCGP
010302*****************************************************************

010302*-----------------------
010302 4114-EDIT-LOCATION-GROUP.
010302*------------------------

010302     IF MIR-LOC-GR-ID = SPACES
010302* MSG: 'LOCATION GROUP MUST NOT BE BLANK'
010302        MOVE 'CS05310041'       TO  WGLOB-MSG-REF-INFO
010302        PERFORM  0260-1000-GENERATE-MESSAGE
010302            THRU 0260-1000-GENERATE-MESSAGE-X
010302        MOVE 'N'                TO  WS-DATA-EDITS-SW
010302     ELSE
010302        MOVE SPACES             TO  WEDIT-KEY
010302        MOVE MIR-LOC-GR-ID      TO  WEDIT-ETBL-VALU-ID
010302        PERFORM  LGAS-1000-EDIT-LGAS-LOCATION
010302            THRU LGAS-1000-EDIT-LGAS-LOCATION-X
010302        IF NOT WEDIT-IO-OK
010302* MSG: 'LOCATION GROUP MUST BE IN EDIT/LOCGP TABLE'
010302           MOVE 'CS05310040'    TO  WGLOB-MSG-REF-INFO
010302           PERFORM  0260-1000-GENERATE-MESSAGE
010302               THRU 0260-1000-GENERATE-MESSAGE-X
010302           MOVE 'N'             TO  WS-DATA-EDITS-SW
010302        END-IF
010302     END-IF.

010302 4114-EDIT-LOCATION-GROUP-X.
010302     EXIT.
      /
      *****************************************************************
      *  EDIT PACKAGE NUMBER:  MUST BE NUMERIC, FORMAT 999
      *****************************************************************
      *-----------------
       4120-EDIT-PKG-NO.
      *-----------------

           IF MIR-DI-PKG-NUM = SPACES
               MOVE '001'             TO MIR-DI-PKG-NUM
               GO TO 4120-EDIT-PKG-NO-X
557660     END-IF.

      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE MIR-DI-PKG-NUM        TO L0280-INPUT-DATA.

           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-PIC-999
020874*        MOVE WS-PIC-999        TO MIR-DI-PKG-NUM
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-DI-PKG-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-DI-PKG-NUM
           ELSE
      *MSG: 'PACKAGE NUMBER MUST BE NUMERIC IN FORMAT 999'
               MOVE 'CS05310004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
557660     END-IF.

       4120-EDIT-PKG-NO-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT OTHER PLAN:  MUST BE A VALID PLAN
      *****************************************************************
      *-------------------
       4130-EDIT-ATT-PLAN.
      *-------------------

           IF MIR-CONN-PLAN-ID = SPACES
           AND MIR-CONN-PKG-NUM = SPACES
               GO TO 4130-EDIT-ATT-PLAN-X
557660     END-IF.

014591*    MOVE MIR-CONN-PLAN-ID      TO  WS-PLAN-ID.
014591*
014591*    IF WS-PLAN-ID-RS NOT = WMATC-MATCH-ANY-CHAR
014591*        MOVE MIR-CONN-PLAN-ID  TO WPH-PLAN-ID
014591*        PERFORM PH-1000-READ
014591*            THRU PH-1000-READ-X
014591*        IF WPH-IO-OK
014591*            GO TO 4130-EDIT-ATT-PLAN-X
014591*        ELSE
014591*MSG: 'PLAN CODE/RS MUST EXIST ON PHDR'
014591*            MOVE 'CS05310005'  TO WGLOB-MSG-REF-INFO
014591*            PERFORM 0260-1000-GENERATE-MESSAGE
014591*               THRU 0260-1000-GENERATE-MESSAGE-X
014591*            MOVE 'N'           TO WS-DATA-EDITS-SW
014591*            GO TO 4130-EDIT-ATT-PLAN-X
014591*        END-IF
014591*    END-IF.
014591*
014591     MOVE MIR-CONN-PLAN-ID      TO WPH-PLAN-ID.
014591     PERFORM  PH-1000-READ
014591         THRU PH-1000-READ-X.
014591     IF  NOT WPH-IO-OK
014591*MSG: 'PLAN CODE/RS MUST EXIST ON PHDR'
014591         MOVE 'CS05310005'      TO WGLOB-MSG-REF-INFO
014591         PERFORM 0260-1000-GENERATE-MESSAGE
014591            THRU 0260-1000-GENERATE-MESSAGE-X
014591         MOVE 'N'               TO WS-DATA-EDITS-SW
014591     END-IF.
014591
014591*    MOVE MIR-CONN-PLAN-ID      TO WPH-PLAN-ID.
014591*    MOVE LOW-VALUES            TO WPH-PLAN-ID-RS.
014591*    PERFORM PH-1000-BROWSE
014591*        THRU PH-1000-BROWSE-X.
014591*
014591*    IF NOT WPH-IO-OK
014591*MSG: 'PLAN (WITH ANY RATE SCALE) MUST EXIST ON PHDR'
014591*        MOVE 'CS05310006'      TO WGLOB-MSG-REF-INFO
014591*        PERFORM 0260-1000-GENERATE-MESSAGE
014591*           THRU 0260-1000-GENERATE-MESSAGE-X
014591*        MOVE 'N'               TO WS-DATA-EDITS-SW
014591*        GO TO 4130-EDIT-ATT-PLAN-X
014591*    END-IF.
014591*
014591*    PERFORM PH-2000-READ-NEXT
014591*        THRU PH-2000-READ-NEXT-X.
014591*
014591*    IF RPH-PLAN-ID-BASE  NOT = WS-PLAN-ID-BASE
014591*MSG: 'PLAN (WITH ANY RATE SCALE) MUST EXIST ON PHDR'
014591*        MOVE 'CS05310006'      TO WGLOB-MSG-REF-INFO
014591*        PERFORM 0260-1000-GENERATE-MESSAGE
014591*           THRU 0260-1000-GENERATE-MESSAGE-X
014591*        MOVE 'N'               TO WS-DATA-EDITS-SW
014591*    END-IF.
014591*
014591*    PERFORM PH-3000-END-BROWSE
014591*        THRU PH-3000-END-BROWSE-X.
014591*
       4130-EDIT-ATT-PLAN-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT OTHER PACKAGE NUMBER:  MUST BE NUMERIC, FORMAT 999
      *****************************************************************
      *---------------------
       4140-EDIT-ATT-PKG-NO.
      *---------------------

           IF MIR-CONN-PLAN-ID = SPACES
           AND MIR-CONN-PKG-NUM = SPACES
               GO TO 4140-EDIT-ATT-PKG-NO-X
557660     END-IF.

      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE MIR-CONN-PKG-NUM      TO L0280-INPUT-DATA.

           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-PIC-999
020874*        MOVE WS-PIC-999        TO MIR-CONN-PKG-NUM
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CONN-PKG-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-CONN-PKG-NUM
           ELSE
      *MSG: 'OTHER PACKAGE NUMBER MUST BE NUMERIC IN FORMAT 999'
               MOVE 'CS05310003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
557660     END-IF.

       4140-EDIT-ATT-PKG-NO-X.
           EXIT.
      /
      *****************************************************************
      *  XEDIT KEY FIELDS:  IF CREATING AN OTHER CVG ENTRY, MUST
      *  ALREADY HAVE A BASE ENTRY
      *****************************************************************
      *----------------------
       4190-XEDIT-KEY-FIELDS.
      *----------------------

           IF MIR-CONN-PLAN-ID = SPACES
           AND MIR-CONN-PKG-NUM = SPACES
               GO TO 4190-XEDIT-KEY-FIELDS-X
557660     END-IF.

           MOVE MIR-PLAN-ID           TO WPACH-PLAN-ID.
010302     MOVE MIR-LOC-GR-ID         TO WPACH-LOC-GR-ID.
010418     MOVE MIR-SBSDRY-CO-ID      TO WPACH-SBSDRY-CO-ID.
           MOVE MIR-DI-PKG-NUM        TO WPACH-DI-PKG-NUM.
           MOVE SPACES                TO WPACH-CONN-PKG-INFO.
           PERFORM PACH-1000-READ
               THRU PACH-1000-READ-X.

           IF NOT WPACH-IO-OK
      *MSG: 'REQUIRE BASE ENTRY BEFORE CREATING OTHER CVG ENTRIES'
               MOVE 'CS05310029'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
               GO TO 4190-XEDIT-KEY-FIELDS-X
557660     END-IF.

           IF RPACH-DI-PKG-LIST-TYP-CD = SPACE
      *MSG: 'PACKAGING TURNED OFF-NO OTHER CVG ENTRIES ALLOWED'
               MOVE 'CS05310030'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
557660     END-IF.

       4190-XEDIT-KEY-FIELDS-X.
           EXIT.
      /
      *-----------
       5000-PROCESS-UPDATE.
      *------------

014221     MOVE MIR-PLAN-ID                TO WPH-PLAN-ID.

014221     PERFORM  PH-2000-UPDATE-TWRK-TS
014221         THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF WPH-IO-NOT-FOUND
014221*MSG: 'PLAN (@1) NOT FOUND'
014221         SET WS-DATA-EDITS-NOT-OK TO TRUE
014221         MOVE 'XS00000049'        TO WGLOB-MSG-REF-INFO
014221         MOVE WPH-PLAN-ID         TO WGLOB-MSG-PARM (01)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.
014221
014221     IF MIR-RETRN-TS-MISMATCH
014221*MSG: 'TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*      PROCESS NOT COMPLETE'
014221         SET WS-DATA-EDITS-NOT-OK TO TRUE
014221         MOVE 'XS00000303'        TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'                TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID         TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  8000-BUILD-PACH-KEY
               THRU 8000-BUILD-PACH-KEY-X.
           PERFORM  PACH-1000-READ-FOR-UPDATE
               THRU PACH-1000-READ-FOR-UPDATE-X.

           IF WPACH-IO-NOT-FOUND
      *MSG: 'RECORD (@1) LOST IN MAINTAIN'
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WPACH-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  PH-3000-UNLOCK
014221             THRU PH-3000-UNLOCK-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

           MOVE +1                    TO WS-LINE.
           PERFORM  5300-EDIT-DATA-FIELDS
               THRU 5300-EDIT-DATA-FIELDS-X.

           MOVE RPACH-PLAN-ID         TO MIR-PLAN-ID-T (WS-LINE).
010302     MOVE RPACH-LOC-GR-ID       TO MIR-LOC-GR-ID-T (WS-LINE).
010418     MOVE RPACH-SBSDRY-CO-ID    TO MIR-SBSDRY-CO-ID-T (WS-LINE).
           MOVE RPACH-DI-PKG-NUM      TO MIR-DI-PKG-NUM-T (WS-LINE).
           MOVE RPACH-CONN-PLAN-ID    TO MIR-CONN-PLAN-ID-T (WS-LINE).
           MOVE RPACH-CONN-PKG-NUM    TO MIR-CONN-PKG-NUM-T (WS-LINE).

           PERFORM  PACH-2000-REWRITE
               THRU PACH-2000-REWRITE-X.
014221     PERFORM  PH-2000-REWRITE
014221         THRU PH-2000-REWRITE-X.
014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.

           PERFORM  5250-CHECK-LIST-TYPE
               THRU 5250-CHECK-LIST-TYPE-X.

      ***  RESET ENTER CODE TO INQUIRE WHEN MAINTAIN IS COMPLETE.
           IF WS-DATA-EDITS-OK
      *MSG: '(I) MAINTAIN COMPLETE - CONTINUE'
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
           ELSE
      *MSG: '(I) RECORD UPDATED'
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *---------------------
       5250-CHECK-LIST-TYPE.
      *---------------------

           MOVE LOW-VALUES            TO WPACH-KEY.
           MOVE MIR-PLAN-ID           TO WPACH-PLAN-ID.
010302     MOVE MIR-LOC-GR-ID         TO WPACH-LOC-GR-ID.
010418     MOVE MIR-SBSDRY-CO-ID      TO WPACH-SBSDRY-CO-ID.
           MOVE MIR-DI-PKG-NUM        TO WPACH-DI-PKG-NUM.

           MOVE HIGH-VALUES           TO WPACH-ENDBR-KEY.
           MOVE MIR-PLAN-ID           TO WPACH-ENDBR-PLAN-ID.
010302     MOVE MIR-LOC-GR-ID         TO WPACH-ENDBR-LOC-GR-ID.
010418     MOVE MIR-SBSDRY-CO-ID      TO WPACH-ENDBR-SBSDRY-CO-ID.
           MOVE MIR-DI-PKG-NUM        TO WPACH-ENDBR-DI-PKG-NUM.

           PERFORM  PACH-1000-BROWSE
               THRU PACH-1000-BROWSE-X.

           IF NOT WPACH-IO-OK
               GO TO 5250-CHECK-LIST-TYPE-X
557660     END-IF.

           PERFORM  PACH-2000-READ-NEXT
               THRU PACH-2000-READ-NEXT-X.

           IF NOT WPACH-IO-OK
               PERFORM  PACH-3000-END-BROWSE
                   THRU PACH-3000-END-BROWSE-X
               GO TO 5250-CHECK-LIST-TYPE-X
557660     END-IF.

           MOVE RPACH-DI-PKG-LIST-TYP-CD
                                      TO WS-SAVE-LIST-TYPE.

           PERFORM  PACH-2000-READ-NEXT
               THRU PACH-2000-READ-NEXT-X.

           IF NOT WPACH-IO-OK
               PERFORM  PACH-3000-END-BROWSE
                   THRU PACH-3000-END-BROWSE-X
               GO TO 5250-CHECK-LIST-TYPE-X
557660     END-IF.

           IF WS-SAVE-LIST-TYPE = SPACES
      *MSG: 'LIST TYPE SHOULD NOT BE BLANK-OTHER CVG ENTRIES EXIST'
               MOVE 'CS05310032'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF WS-LIST-TYPE-CHANGED
      *MSG: 'LIST TYPE HAS BEEN CHANGED-CHECK OTHER CVG ENTRIES'
                   MOVE 'CS05310033'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

           PERFORM PACH-3000-END-BROWSE
              THRU PACH-3000-END-BROWSE-X.

       5250-CHECK-LIST-TYPE-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT DATA FIELDS ACCORDING TO THE DATA DICTIONARY
      *****************************************************************
      *----------------------
       5300-EDIT-DATA-FIELDS.
      *----------------------

           MOVE 'Y'                   TO WS-DATA-EDITS-SW.

           PERFORM  5305-EDIT-LIST-TYPE
               THRU 5305-EDIT-LIST-TYPE-X.

           PERFORM  5310-EDIT-SUB-TABLE1-QUAL
               THRU 5310-EDIT-SUB-TABLE1-QUAL-X.

           PERFORM  5315-EDIT-SUB-TABLE1
               THRU 5315-EDIT-SUB-TABLE1-X.

           PERFORM  5320-EDIT-SUB-TABLE2-QUAL
               THRU 5320-EDIT-SUB-TABLE2-QUAL-X.

           PERFORM  5325-EDIT-SUB-TABLE2
               THRU 5325-EDIT-SUB-TABLE2-X.

           PERFORM  5330-EDIT-SUB-TABLE3-QUAL
               THRU 5330-EDIT-SUB-TABLE3-QUAL-X.

           PERFORM  5335-EDIT-SUB-TABLE3
               THRU 5335-EDIT-SUB-TABLE3-X.

           PERFORM  5340-EDIT-SUB-TABLE4-QUAL
               THRU 5340-EDIT-SUB-TABLE4-QUAL-X.

           PERFORM  5345-EDIT-SUB-TABLE4
               THRU 5345-EDIT-SUB-TABLE4-X.

           PERFORM  5350-EDIT-HOSP-IND
               THRU 5350-EDIT-HOSP-IND-X.

           PERFORM  5355-EDIT-OCC-IND
               THRU 5355-EDIT-OCC-IND-X.

           PERFORM  5360-EDIT-LTA-IND
               THRU 5360-EDIT-LTA-IND-X.

           PERFORM  5365-EDIT-LTB-IND
               THRU 5365-EDIT-LTB-IND-X.

           PERFORM  5370-EDIT-PDIS-IND
               THRU 5370-EDIT-PDIS-IND-X.

           PERFORM  5375-EDIT-COLA-IND
               THRU 5375-EDIT-COLA-IND-X.

           PERFORM  5390-XEDIT-DATA-FIELDS
               THRU 5390-XEDIT-DATA-FIELDS-X.

       5300-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT LIST TYPE:  MUST BE SPACE, O OR N
      *****************************************************************
      *--------------------
       5305-EDIT-LIST-TYPE.
      *--------------------

           IF MIR-DI-PKG-LIST-TYP-CD-T (WS-LINE) = SPACES
               MOVE RPACH-DI-PKG-LIST-TYP-CD
                                TO MIR-DI-PKG-LIST-TYP-CD-T (WS-LINE)
               MOVE 'N'         TO WS-LIST-TYPE-CHANGED-SW
               GO TO 5305-EDIT-LIST-TYPE-X
557660     END-IF.

           IF MIR-DI-PKG-LIST-TYP-CD-T (WS-LINE)
                                 NOT = RPACH-DI-PKG-LIST-TYP-CD
               MOVE 'Y'          TO WS-LIST-TYPE-CHANGED-SW
557660     END-IF.

           IF MIR-DI-PKG-LIST-TYP-CD-T (WS-LINE)
                                     = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE       TO MIR-DI-PKG-LIST-TYP-CD-T (WS-LINE)
               MOVE SPACE       TO RPACH-DI-PKG-LIST-TYP-CD
               GO TO 5305-EDIT-LIST-TYPE-X
557660     END-IF.

           MOVE MIR-DI-PKG-LIST-TYP-CD-T (WS-LINE)  TO WS-LIST-TYPE.

           IF WS-LIST-TYPE-VALID
               MOVE MIR-DI-PKG-LIST-TYP-CD-T (WS-LINE)
                                   TO RPACH-DI-PKG-LIST-TYP-CD
           ELSE
      *MSG: 'LIST TYPE MUST BE BLANK, O, OR N'
               MOVE 'CS05310007'   TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'           TO WS-DATA-EDITS-SW
557660     END-IF.

       5305-EDIT-LIST-TYPE-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT SUB TABLE 1 QUALIFIER:  MUST BE =, <, > OR #
      *****************************************************************
      *--------------------------
       5310-EDIT-SUB-TABLE1-QUAL.
      *--------------------------

           IF MIR-DI-PKG-QP-CD-T (WS-LINE) = SPACES
               MOVE RPACH-DI-PKG-QP-CD   TO MIR-DI-PKG-QP-CD-T (WS-LINE)
               GO TO 5310-EDIT-SUB-TABLE1-QUAL-X
557660     END-IF.

           IF MIR-DI-PKG-QP-CD-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
               MOVE WMATC-MATCH-ANY-CHAR TO MIR-DI-PKG-QP-CD-T (WS-LINE)
               MOVE WMATC-MATCH-ANY-CHAR TO RPACH-DI-PKG-QP-CD
               GO TO 5310-EDIT-SUB-TABLE1-QUAL-X
557660     END-IF.

           MOVE MIR-DI-PKG-QP-CD-T (WS-LINE) TO WS-QUALIFIER.
           IF WS-QUALIFIER-VALID
               MOVE MIR-DI-PKG-QP-CD-T (WS-LINE)
                                             TO RPACH-DI-PKG-QP-CD
           ELSE
      *MSG: 'SUB TABLE QUALIFIER MUST BE =, <, >, OR #'
               MOVE 'CS05310008'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
557660     END-IF.

       5310-EDIT-SUB-TABLE1-QUAL-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT SUB TABLE 1:  MUST BE ON EDIT, TYPE STB1
      *****************************************************************
      *---------------------
       5315-EDIT-SUB-TABLE1.
      *---------------------

           IF MIR-DI-PKG-QP-DUR-T (WS-LINE) = SPACES
               MOVE RPACH-DI-PKG-QP-DUR
                                      TO MIR-DI-PKG-QP-DUR-T (WS-LINE)
               GO TO 5315-EDIT-SUB-TABLE1-X
557660     END-IF.

           IF MIR-DI-PKG-QP-DUR-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-DI-PKG-QP-DUR-T (WS-LINE)
               MOVE SPACES            TO RPACH-DI-PKG-QP-DUR
               GO TO 5315-EDIT-SUB-TABLE1-X
557660     END-IF.

           MOVE MIR-DI-PKG-QP-DUR-T (WS-LINE)  TO WEDIT-ETBL-VALU-ID.

           PERFORM STB1-1000-EDIT-SUB-TABLE-1
               THRU STB1-1000-EDIT-SUB-TABLE-1-X.

           IF WEDIT-IO-OK
               MOVE MIR-DI-PKG-QP-DUR-T (WS-LINE)
                                               TO RPACH-DI-PKG-QP-DUR
           ELSE
      *MSG: 'QUAL PERIOD MUST BE ON EDIT, TYPE STB1'
               MOVE 'CS05310009'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
557660     END-IF.

       5315-EDIT-SUB-TABLE1-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT SUB TABLE 2 QUALIFIER:  MUST BE =, <, > OR #
      *****************************************************************
      *--------------------------
       5320-EDIT-SUB-TABLE2-QUAL.
      *--------------------------

           IF MIR-DI-PKG-EP-CD-T (WS-LINE) = SPACES
               MOVE RPACH-DI-PKG-EP-CD   TO MIR-DI-PKG-EP-CD-T (WS-LINE)
               GO TO 5320-EDIT-SUB-TABLE2-QUAL-X
557660     END-IF.

           IF MIR-DI-PKG-EP-CD-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
               MOVE WMATC-MATCH-ANY-CHAR TO MIR-DI-PKG-EP-CD-T (WS-LINE)
               MOVE WMATC-MATCH-ANY-CHAR TO RPACH-DI-PKG-EP-CD
               GO TO 5320-EDIT-SUB-TABLE2-QUAL-X
557660     END-IF.

           MOVE MIR-DI-PKG-EP-CD-T (WS-LINE)  TO WS-QUALIFIER.
           IF WS-QUALIFIER-VALID
               MOVE MIR-DI-PKG-EP-CD-T (WS-LINE)
                                              TO RPACH-DI-PKG-EP-CD
           ELSE
      *MSG: 'SUB TABLE QUALIFIER MUST BE =, <, >, OR #'
               MOVE 'CS05310010'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
557660     END-IF.

       5320-EDIT-SUB-TABLE2-QUAL-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT SUB TABLE 2:  MUST BE ON EDIT, TYPE STB2
      *****************************************************************
      *---------------------
       5325-EDIT-SUB-TABLE2.
      *---------------------

           IF MIR-DI-PKG-EP-DUR-T (WS-LINE) = SPACES
               MOVE RPACH-DI-PKG-EP-DUR
                                      TO MIR-DI-PKG-EP-DUR-T (WS-LINE)
               GO TO 5325-EDIT-SUB-TABLE2-X
557660     END-IF.

           IF MIR-DI-PKG-EP-DUR-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-DI-PKG-EP-DUR-T (WS-LINE)
               MOVE SPACES            TO RPACH-DI-PKG-EP-DUR
               GO TO 5325-EDIT-SUB-TABLE2-X
557660     END-IF.

           MOVE MIR-DI-PKG-EP-DUR-T (WS-LINE)  TO WEDIT-ETBL-VALU-ID.

           PERFORM STB2-1000-EDIT-SUB-TABLE-2
               THRU STB2-1000-EDIT-SUB-TABLE-2-X.

           IF WEDIT-IO-OK
               MOVE MIR-DI-PKG-EP-DUR-T (WS-LINE)
                                      TO RPACH-DI-PKG-EP-DUR
           ELSE
      *MSG: 'ELIM PERIOD MUST BE ON EDIT, TYPE STB2'
               MOVE 'CS05310011'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'         TO WS-DATA-EDITS-SW
557660     END-IF.

       5325-EDIT-SUB-TABLE2-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT SUB TABLE 3 QUALIFIER:  MUST BE =, <, > OR #
      *****************************************************************
      *--------------------------
       5330-EDIT-SUB-TABLE3-QUAL.
      *--------------------------

           IF MIR-DI-PKG-BP-CD-T (WS-LINE) = SPACES
               MOVE RPACH-DI-PKG-BP-CD
                                  TO MIR-DI-PKG-BP-CD-T (WS-LINE)
               GO TO 5330-EDIT-SUB-TABLE3-QUAL-X
557660     END-IF.

           IF MIR-DI-PKG-BP-CD-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
               MOVE WMATC-MATCH-ANY-CHAR
                                  TO MIR-DI-PKG-BP-CD-T (WS-LINE)
               MOVE WMATC-MATCH-ANY-CHAR
                                  TO RPACH-DI-PKG-BP-CD
               GO TO 5330-EDIT-SUB-TABLE3-QUAL-X
557660     END-IF.

           MOVE MIR-DI-PKG-BP-CD-T (WS-LINE)
                                   TO WS-QUALIFIER.
           IF WS-QUALIFIER-VALID-BP
               MOVE MIR-DI-PKG-BP-CD-T (WS-LINE)
                                   TO RPACH-DI-PKG-BP-CD
           ELSE
      *MSG: 'SUB TABLE QUALIFIER MUST BE =, <, >, OR #'
               MOVE 'CS05310012'   TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'         TO WS-DATA-EDITS-SW
557660     END-IF.

       5330-EDIT-SUB-TABLE3-QUAL-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT SUB TABLE 3:  MUST BE ON EDIT, TYPE STB3
      *****************************************************************
      *---------------------
       5335-EDIT-SUB-TABLE3.
      *---------------------

           IF MIR-DI-PKG-BP-DUR-T (WS-LINE) = SPACES
               MOVE RPACH-DI-PKG-BP-DUR
                                  TO MIR-DI-PKG-BP-DUR-T (WS-LINE)
               GO TO 5335-EDIT-SUB-TABLE3-X
557660     END-IF.

           IF MIR-DI-PKG-BP-DUR-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES        TO MIR-DI-PKG-BP-DUR-T (WS-LINE)
               MOVE SPACES        TO RPACH-DI-PKG-BP-DUR
               GO TO 5335-EDIT-SUB-TABLE3-X
557660     END-IF.

           MOVE MIR-DI-PKG-BP-DUR-T (WS-LINE)
                                  TO WEDIT-ETBL-VALU-ID.

           PERFORM STB3-1000-EDIT-SUB-TABLE-3
               THRU STB3-1000-EDIT-SUB-TABLE-3-X.

           IF WEDIT-IO-OK
               MOVE MIR-DI-PKG-BP-DUR-T (WS-LINE)
                                  TO RPACH-DI-PKG-BP-DUR
           ELSE
      *MSG: 'BENEFIT PERIOD MUST BE ON EDIT, TYPE STB3'
               MOVE 'CS05310013'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'           TO WS-DATA-EDITS-SW
557660     END-IF.

       5335-EDIT-SUB-TABLE3-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT SUB TABLE 4 QUALIFIER:  MUST BE =, <, > OR #
      *****************************************************************
      *--------------------------
       5340-EDIT-SUB-TABLE4-QUAL.
      *--------------------------

           IF MIR-OCCP-CLAS-QUALF-CD-T (WS-LINE) = SPACES
               MOVE RPACH-OCCP-CLAS-QUALF-CD
                                TO MIR-OCCP-CLAS-QUALF-CD-T (WS-LINE)
               GO TO 5340-EDIT-SUB-TABLE4-QUAL-X
557660     END-IF.

           IF MIR-OCCP-CLAS-QUALF-CD-T (WS-LINE)
                                           = EBLCH-BLANK-FIELD-CHAR
               MOVE WMATC-MATCH-ANY-CHAR
                                 TO MIR-OCCP-CLAS-QUALF-CD-T (WS-LINE)
               MOVE WMATC-MATCH-ANY-CHAR
                                 TO RPACH-OCCP-CLAS-QUALF-CD
               GO TO 5340-EDIT-SUB-TABLE4-QUAL-X
557660     END-IF.

           MOVE MIR-OCCP-CLAS-QUALF-CD-T (WS-LINE)
                                 TO WS-QUALIFIER.
           IF WS-QUALIFIER-VALID
               MOVE MIR-OCCP-CLAS-QUALF-CD-T (WS-LINE)
                                 TO RPACH-OCCP-CLAS-QUALF-CD
           ELSE
      *MSG: 'SUB TABLE QUALIFIER MUST BE =, <, >, OR #'
               MOVE 'CS05310014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'         TO WS-DATA-EDITS-SW
557660     END-IF.

       5340-EDIT-SUB-TABLE4-QUAL-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT SUB TABLE 4:  MUST BE ON EDIT, TYPE STB4
      *****************************************************************
      *---------------------
       5345-EDIT-SUB-TABLE4.
      *---------------------

           IF MIR-OCCP-CLAS-CD-T (WS-LINE) = SPACES
               MOVE RPACH-OCCP-CLAS-CD   TO MIR-OCCP-CLAS-CD-T (WS-LINE)
               GO TO 5345-EDIT-SUB-TABLE4-X
557660     END-IF.

           IF MIR-OCCP-CLAS-CD-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-OCCP-CLAS-CD-T (WS-LINE)
               MOVE SPACES            TO RPACH-OCCP-CLAS-CD
               GO TO 5345-EDIT-SUB-TABLE4-X
557660     END-IF.

           MOVE MIR-OCCP-CLAS-CD-T (WS-LINE) TO WEDIT-ETBL-VALU-ID.

           PERFORM STB4-1000-EDIT-SUB-TABLE-4
               THRU STB4-1000-EDIT-SUB-TABLE-4-X.

           IF WEDIT-IO-OK
               MOVE MIR-OCCP-CLAS-CD-T (WS-LINE) TO RPACH-OCCP-CLAS-CD
           ELSE
      *MSG: 'OCC CLASS MUST BE ON EDIT, TYPE STB4'
               MOVE 'CS05310015'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS-SW
557660     END-IF.

       5345-EDIT-SUB-TABLE4-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT HOSP BENEFIT INDICATOR:
      *      IF ATTACHED PLAN IS BLANK, MUST BE Y OR N
      *      IF ATTACHED PLAN IS NOT BLANK, MUST BE Y, N, S, D, OR O
      *****************************************************************
      *-------------------
       5350-EDIT-HOSP-IND.
      *-------------------

           IF MIR-REDC-EP-ALLOW-CD-T (WS-LINE) = SPACES
               MOVE RPACH-REDC-EP-ALLOW-CD
                               TO MIR-REDC-EP-ALLOW-CD-T (WS-LINE)
               GO TO 5350-EDIT-HOSP-IND-X
557660     END-IF.

           IF MIR-REDC-EP-ALLOW-CD-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
               MOVE 'Y'          TO MIR-REDC-EP-ALLOW-CD-T (WS-LINE)
               MOVE 'Y'          TO RPACH-REDC-EP-ALLOW-CD
               GO TO 5350-EDIT-HOSP-IND-X
557660     END-IF.

           MOVE MIR-REDC-EP-ALLOW-CD-T (WS-LINE) TO WS-BENEFIT-IND.
           IF RPACH-CONN-PKG-INFO = SPACES
               IF WS-BENEFIT-IND-VALID
                   MOVE MIR-REDC-EP-ALLOW-CD-T (WS-LINE)
                                      TO RPACH-REDC-EP-ALLOW-CD
               ELSE
      *MSG: 'HOSP IND MUST BE Y OR N'
                   MOVE 'CS05310016'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDITS-SW
557660         END-IF
           ELSE
               IF WS-BENEFIT-IND-VALID-ATT
                   MOVE MIR-REDC-EP-ALLOW-CD-T (WS-LINE)
                                      TO RPACH-REDC-EP-ALLOW-CD
               ELSE
      *MSG: 'HOSP IND ON OTHER PLAN MUST BE Y, N, S, D, OR O'
                   MOVE 'CS05310017'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDITS-SW
557660         END-IF
557660     END-IF.

       5350-EDIT-HOSP-IND-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT OCC BENEFIT INDICATOR:
      *      IF ATTACHED PLAN IS BLANK, MUST BE Y OR N
      *      IF ATTACHED PLAN IS NOT BLANK, MUST BE Y, N, S, D, OR O
      *****************************************************************
      *------------------
       5355-EDIT-OCC-IND.
      *------------------

           IF MIR-OWN-OCCP-ALLOW-CD-T (WS-LINE) = SPACES
               MOVE RPACH-OWN-OCCP-ALLOW-CD
                                TO MIR-OWN-OCCP-ALLOW-CD-T (WS-LINE)
               GO TO 5355-EDIT-OCC-IND-X
557660     END-IF.

           IF MIR-OWN-OCCP-ALLOW-CD-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
               MOVE 'Y'         TO MIR-OWN-OCCP-ALLOW-CD-T (WS-LINE)
               MOVE 'Y'         TO RPACH-OWN-OCCP-ALLOW-CD
               GO TO 5355-EDIT-OCC-IND-X
557660     END-IF.

           MOVE MIR-OWN-OCCP-ALLOW-CD-T (WS-LINE)  TO WS-BENEFIT-IND.
           IF RPACH-CONN-PKG-INFO = SPACES
               IF WS-BENEFIT-IND-VALID
                   MOVE MIR-OWN-OCCP-ALLOW-CD-T (WS-LINE)
                                TO RPACH-OWN-OCCP-ALLOW-CD
               ELSE
      *MSG: 'OCC IND MUST BE Y OR N'
                   MOVE 'CS05310018'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDITS-SW
557660         END-IF
           ELSE
               IF WS-BENEFIT-IND-VALID-ATT
                   MOVE MIR-OWN-OCCP-ALLOW-CD-T (WS-LINE)
                                      TO RPACH-OWN-OCCP-ALLOW-CD
               ELSE
      *MSG: 'OCC IND ON OTHER PLAN MUST BE Y, N, S, D, OR O'
                   MOVE 'CS05310019'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDITS-SW
557660         END-IF
557660     END-IF.

       5355-EDIT-OCC-IND-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT LTA BENEFIT INDICATOR:
      *      IF ATTACHED PLAN IS BLANK, MUST BE Y OR N
      *      IF ATTACHED PLAN IS NOT BLANK, MUST BE Y, N, S, D, OR O
      *****************************************************************
      *------------------
       5360-EDIT-LTA-IND.
      *------------------

           IF MIR-LTA-ALLOW-CD-T (WS-LINE) = SPACES
               MOVE RPACH-LTA-ALLOW-CD   TO MIR-LTA-ALLOW-CD-T (WS-LINE)
               GO TO 5360-EDIT-LTA-IND-X
557660     END-IF.

           IF MIR-LTA-ALLOW-CD-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
               MOVE 'Y'               TO MIR-LTA-ALLOW-CD-T (WS-LINE)
               MOVE 'Y'               TO RPACH-LTA-ALLOW-CD
               GO TO 5360-EDIT-LTA-IND-X
557660     END-IF.

           MOVE MIR-LTA-ALLOW-CD-T (WS-LINE)   TO WS-BENEFIT-IND.

           IF RPACH-CONN-PKG-INFO = SPACES
               IF WS-BENEFIT-IND-VALID
                   MOVE MIR-LTA-ALLOW-CD-T (WS-LINE)
                                      TO RPACH-LTA-ALLOW-CD
               ELSE
      *MSG: 'LTA IND MUST BE Y OR N'
                   MOVE 'CS05310020'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDITS-SW
               END-IF
           ELSE
               IF WS-BENEFIT-IND-VALID-ATT
                   MOVE MIR-LTA-ALLOW-CD-T (WS-LINE)
                                      TO RPACH-LTA-ALLOW-CD
               ELSE
      *MSG: 'LTA IND ON OTHER PLAN MUST BE Y, N, S, D, OR O'
                   MOVE 'CS05310021'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDITS-SW
557660         END-IF
557660     END-IF.

       5360-EDIT-LTA-IND-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT LTB BENEFIT INDICATOR:
      *      IF ATTACHED PLAN IS BLANK, MUST BE Y OR N
      *      IF ATTACHED PLAN IS NOT BLANK, MUST BE Y, N, S, D, OR O
      *****************************************************************
      *------------------
       5365-EDIT-LTB-IND.
      *------------------

           IF MIR-LTB-ALLOW-CD-T (WS-LINE) = SPACES
557659*        MOVE RPACH-LTB-ALLOW-IND  TO MIR-LTB-ALLOW-CD-T (WS-LINE)
557659         MOVE RPACH-LTB-ALLOW-CD   TO MIR-LTB-ALLOW-CD-T (WS-LINE)
               GO TO 5365-EDIT-LTB-IND-X
557660     END-IF.

           IF MIR-LTB-ALLOW-CD-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
               MOVE 'Y'               TO MIR-LTB-ALLOW-CD-T (WS-LINE)
557659*        MOVE 'Y'                     TO RPACH-LTB-ALLOW-IND
557659         MOVE 'Y'               TO RPACH-LTB-ALLOW-CD
               GO TO 5365-EDIT-LTB-IND-X
557660     END-IF.

           MOVE MIR-LTB-ALLOW-CD-T (WS-LINE)
                                      TO WS-BENEFIT-IND.
           IF RPACH-CONN-PKG-INFO = SPACES
               IF WS-BENEFIT-IND-VALID
557659*            MOVE MIR-LTB-ALLOW-CD-T (WS-LINE)
557659*                               TO RPACH-LTB-ALLOW-IND
557659             MOVE MIR-LTB-ALLOW-CD-T (WS-LINE)
                                      TO RPACH-LTB-ALLOW-CD
               ELSE
      *MSG: 'LTB IND MUST BE Y OR N'
                   MOVE 'CS05310022'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDITS-SW
               END-IF
           ELSE
               IF WS-BENEFIT-IND-VALID-ATT
557659*            MOVE MIR-LTB-ALLOW-CD-T (WS-LINE)
557659*                                       TO RPACH-LTB-ALLOW-IND
557659             MOVE MIR-LTB-ALLOW-CD-T (WS-LINE)
                                              TO RPACH-LTB-ALLOW-CD
               ELSE
      *MSG: 'LTB IND ON OTHER PLAN MUST BE Y, N, S, D, OR O'
                   MOVE 'CS05310023'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDITS-SW
557660         END-IF
557660     END-IF.

       5365-EDIT-LTB-IND-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT PDIS BENEFIT INDICATOR:
      *      IF ATTACHED PLAN IS BLANK, MUST BE Y OR N
      *      IF ATTACHED PLAN IS NOT BLANK, MUST BE Y, N, S, D, OR O
      *****************************************************************
      *-------------------
       5370-EDIT-PDIS-IND.
      *-------------------

           IF MIR-PDISAB-ALLOW-CD-T (WS-LINE) = SPACES
               MOVE RPACH-PDISAB-ALLOW-CD
                                   TO MIR-PDISAB-ALLOW-CD-T (WS-LINE)
               GO TO 5370-EDIT-PDIS-IND-X
557660     END-IF.

           IF MIR-PDISAB-ALLOW-CD-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
               MOVE 'Y'            TO MIR-PDISAB-ALLOW-CD-T (WS-LINE)
               MOVE 'Y'            TO RPACH-PDISAB-ALLOW-CD
               GO TO 5370-EDIT-PDIS-IND-X
557660     END-IF.

           MOVE MIR-PDISAB-ALLOW-CD-T (WS-LINE)
                                      TO WS-BENEFIT-IND.
           IF RPACH-CONN-PKG-INFO = SPACES
               IF WS-BENEFIT-IND-VALID
                   MOVE MIR-PDISAB-ALLOW-CD-T (WS-LINE)
                                      TO RPACH-PDISAB-ALLOW-CD
               ELSE
      *MSG: 'PDIS IND MUST BE Y OR N'
                   MOVE 'CS05310024'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDITS-SW
               END-IF
           ELSE
               IF WS-BENEFIT-IND-VALID-ATT
                   MOVE MIR-PDISAB-ALLOW-CD-T (WS-LINE)
                                      TO RPACH-PDISAB-ALLOW-CD
               ELSE
      *MSG: 'PDIS IND ON OTHER PLAN MUST BE Y, N, S, D, OR O'
                   MOVE 'CS05310025'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDITS-SW
557660         END-IF
557660     END-IF.

       5370-EDIT-PDIS-IND-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT COLA BENEFIT INDICATOR:
      *      IF ATTACHED PLAN IS BLANK, MUST BE Y OR N
      *      IF ATTACHED PLAN IS NOT BLANK, MUST BE Y, N, S, D, OR O
      *****************************************************************
      *-------------------
       5375-EDIT-COLA-IND.
      *-------------------

           IF MIR-COLA-ALLOW-CD-T (WS-LINE) = SPACES
               MOVE RPACH-COLA-ALLOW-CD
                                      TO MIR-COLA-ALLOW-CD-T (WS-LINE)
               GO TO 5375-EDIT-COLA-IND-X
557660     END-IF.

           IF MIR-COLA-ALLOW-CD-T (WS-LINE) = EBLCH-BLANK-FIELD-CHAR
               MOVE 'Y'               TO MIR-COLA-ALLOW-CD-T (WS-LINE)
               MOVE 'Y'               TO RPACH-COLA-ALLOW-CD
               GO TO 5375-EDIT-COLA-IND-X
557660     END-IF.

           MOVE MIR-COLA-ALLOW-CD-T (WS-LINE)
                                      TO WS-BENEFIT-IND.
           IF RPACH-CONN-PKG-INFO = SPACES
               IF WS-BENEFIT-IND-VALID
                   MOVE MIR-COLA-ALLOW-CD-T (WS-LINE)
                                      TO RPACH-COLA-ALLOW-CD
               ELSE
      *MSG: 'COLA IND MUST BE Y OR N'
                   MOVE 'CS05310026'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDITS-SW
               END-IF
           ELSE
               IF WS-BENEFIT-IND-VALID-ATT
                   MOVE MIR-COLA-ALLOW-CD-T (WS-LINE)
                                      TO RPACH-COLA-ALLOW-CD
               ELSE
      *MSG: 'COLA IND ON OTHER PLAN MUST BE Y, N, S, D, OR O'
                   MOVE 'CS05310027'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDITS-SW
557660         END-IF
557660     END-IF.

       5375-EDIT-COLA-IND-X.
           EXIT.
      /
      ****************************************************************
      *  XEDIT DATA FIELDS
      *     IF QUALIFIER IS #, FIELD QUALIFIED SHOULD BE BLANK
      ****************************************************************

      *-----------------------
       5390-XEDIT-DATA-FIELDS.
      *-----------------------

           IF RPACH-DI-PKG-QP-CD    = '#'
               IF RPACH-DI-PKG-QP-DUR NOT = SPACES
      *MSG: '(I) @1 SHOULD BE BLANK WHEN @1 QUALIFIER IS '#''
                   MOVE 'CS05310031'  TO WGLOB-MSG-REF-INFO
                   MOVE 'QP'          TO WGLOB-MSG-PARM (1)
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDITS-SW
557660         END-IF
557660     END-IF.

           IF RPACH-DI-PKG-EP-CD    = '#'
               IF RPACH-DI-PKG-EP-DUR NOT = SPACES
      *MSG: (I) @1 SHOULD BE BLANK WHEN @1 QUALIFIER IS '#'
                   MOVE 'CS05310031'  TO WGLOB-MSG-REF-INFO
                   MOVE 'EP'          TO WGLOB-MSG-PARM (1)
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDITS-SW
557660         END-IF
557660     END-IF.

           IF RPACH-DI-PKG-BP-CD    = '#'
               IF RPACH-DI-PKG-BP-DUR NOT = SPACES
      *MSG: '(I) @1 SHOULD BE BLANK WHEN @1 QUALIFIER IS '#''
                   MOVE 'CS05310031'  TO WGLOB-MSG-REF-INFO
                   MOVE 'BP'          TO WGLOB-MSG-PARM (1)
                   PERFORM 0260-1000-GENERATE-MESSAGE
557660                THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDITS-SW
557660         END-IF
557660     END-IF.

           IF RPACH-OCCP-CLAS-QUALF-CD = '#'
               IF RPACH-OCCP-CLAS-CD NOT = SPACES
      *MSG: (I) @1 SHOULD BE BLANK WHEN @1 QUALIFIER IS '#'
                   MOVE 'CS05310031'  TO WGLOB-MSG-REF-INFO
                   MOVE 'OC'          TO WGLOB-MSG-PARM (1)
                   PERFORM 0260-1000-GENERATE-MESSAGE
557660                THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDITS-SW
557660         END-IF
557660     END-IF.

       5390-XEDIT-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  DELETE PROCESSING:
      *      FORCE = 1:  USER HAS ENTERED KEY DETAILS
      *      FORCE = 9:  USER HAS VERIFIED DELETE REQUEST
      *****************************************************************
      *-------------------
       6000-PROCESS-DELETE.
      *-------------------

014221     MOVE MIR-PLAN-ID              TO WPH-PLAN-ID.

014221     PERFORM  PH-2000-UPDATE-TWRK-TS
014221         THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF WPH-IO-NOT-FOUND
014221*MSG: 'PLAN (@1) NOT FOUND'
014221         SET WS-DATA-EDITS-NOT-OK TO TRUE
014221         MOVE 'XS00000049'        TO WGLOB-MSG-REF-INFO
014221         MOVE WPH-PLAN-ID         TO WGLOB-MSG-PARM (01)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.
014221
014221     IF MIR-RETRN-TS-MISMATCH
014221*MSG: 'TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*      PROCESS NOT COMPLETE'
014221         SET WS-DATA-EDITS-NOT-OK TO TRUE
014221         MOVE 'XS00000303'        TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'                TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID         TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  8000-BUILD-PACH-KEY
               THRU 8000-BUILD-PACH-KEY-X.

           PERFORM  PACH-1000-READ
               THRU PACH-1000-READ-X.

           IF WPACH-IO-NOT-FOUND
      *MSG: 'RECORD (@1) NOT FOUND'
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WPACH-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-DELETE-X
557660     END-IF.

           MOVE +1                    TO WS-LINE.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           IF MIR-CONN-PLAN-ID = SPACES
           AND MIR-CONN-PKG-NUM = SPACES
               MOVE WPACH-KEY         TO WPACH-ENDBR-KEY
               MOVE HIGH-VALUES       TO WPACH-ENDBR-CONN-PKG-INFO
               PERFORM PACH-1000-BROWSE
                   THRU PACH-1000-BROWSE-X
               PERFORM PACH-2000-READ-NEXT
                   THRU PACH-2000-READ-NEXT-X
               PERFORM PACH-2000-READ-NEXT
                   THRU PACH-2000-READ-NEXT-X
               IF WPACH-IO-OK
                   PERFORM PACH-3000-END-BROWSE
                       THRU PACH-3000-END-BROWSE-X
      *MSG: 'CANNOT DELETE BASE ENTRY-OTHER CVG ENTRIES EXIST'
                   MOVE 'CS05310028'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 6000-PROCESS-DELETE-X
               ELSE
                   PERFORM PACH-3000-END-BROWSE
                       THRU PACH-3000-END-BROWSE-X
557660         END-IF
557660     END-IF.

           PERFORM  8000-BUILD-PACH-KEY
               THRU 8000-BUILD-PACH-KEY-X.
           PERFORM  PACH-1000-READ-FOR-UPDATE
               THRU PACH-1000-READ-FOR-UPDATE-X.

           IF WPACH-IO-NOT-FOUND
      *MSG: 'RECORD (@1) LOST IN DELETE'
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WPACH-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
014221         PERFORM  PH-3000-UNLOCK
014221             THRU PH-3000-UNLOCK-X
           ELSE
      *MSG: '(I) RECORD DELETED - CONTINUE'
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  PACH-1000-DELETE
                   THRU PACH-1000-DELETE-X
014221         PERFORM  PH-2000-REWRITE
014221             THRU PH-2000-REWRITE-X
014221         PERFORM  PH-1000-READ-TWRK-TS
014221             THRU PH-1000-READ-TWRK-TS-X
557660     END-IF.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
010418****************************************************************
010418*  KLON PROCESS
010418****************************************************************
010418*
010418*******************
010418 7000-PROCESS-KLON.
010418*******************
010418*
010418*
010418*---- SET DEFAULT KLON SCREEN ENVIRONMENT
010418*
010418     PERFORM 9100-BLANK-DATA-FIELDS
010418         THRU 9100-BLANK-DATA-FIELDS-X.

      *---- VALIDATION
      *
           PERFORM 7110-KLON-1ST-EDITS
               THRU 7110-KLON-1ST-EDITS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 7000-PROCESS-KLON-X
           END-IF.
      *
           MOVE SPACES                TO MIR-LOC-GR-ID.
           MOVE SPACES                TO MIR-DI-PKG-NUM.
           MOVE SPACES                TO MIR-CONN-PLAN-ID.
           MOVE SPACES                TO MIR-CONN-PKG-NUM.

           PERFORM  7210-KLON-2ND-EDITS
               THRU 7210-KLON-2ND-EDITS-X.

           IF WGLOB-MSG-ERROR-SW > ZEROS
               MOVE 'CS05310042'      TO WGLOB-MSG-REF-INFO
      * MSG: RECORD(S) NOT CLONED
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-PROCESS-KLON-X
           END-IF.
      *
      *---- BROWSE PACH WITH HIDDEN PLAN/RATE SCALE AND SUB-COMPANY
      *
           MOVE LOW-VALUES            TO WPACH-KEY.
           MOVE MIR-PLAN-ID           TO WPACH-PLAN-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WPACH-SBSDRY-CO-ID.

           MOVE HIGH-VALUES           TO WPACH-ENDBR-KEY.
           MOVE MIR-PLAN-ID           TO WPACH-ENDBR-PLAN-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WPACH-ENDBR-SBSDRY-CO-ID.
      *
           PERFORM  PACH-1000-BROWSE
               THRU PACH-1000-BROWSE-X.

           IF NOT WPACH-IO-OK
           OR WPACH-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
      * MSG : RECORD(S> NOT CLONED
016483*        MOVE 'CS05310043'      TO WGLOB-MSG-REF-INFO
016483         MOVE 'CS05310042'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 7000-PROCESS-KLON-X
           ELSE
               PERFORM  PACH-2000-READ-NEXT
                   THRU PACH-2000-READ-NEXT-X
               IF WPACH-IO-EOF
               OR NOT WPACH-IO-OK
                   PERFORM  PACH-3000-END-BROWSE
                       THRU PACH-3000-END-BROWSE-X
                   MOVE 'XS00000025'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
      * MSG : RECORD(S> NOT CLONED
016483*            MOVE 'CS05310043'  TO WGLOB-MSG-REF-INFO
016483             MOVE 'CS05310042'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   PERFORM  9100-BLANK-DATA-FIELDS
                       THRU 9100-BLANK-DATA-FIELDS-X
                   GO TO 7000-PROCESS-KLON-X
               END-IF
           END-IF.
      *
      *---- KLON UNTIL PACH END-OF-FILE OR OUTSIDE KLON RANGE
      *
           MOVE 0                     TO COUNT-KLON-RECS.

           PERFORM  7220-CHECK-KLON-ONE-REC
               THRU 7220-CHECK-KLON-ONE-REC-X
                 UNTIL WPACH-IO-EOF.

           PERFORM  PACH-3000-END-BROWSE
               THRU PACH-3000-END-BROWSE-X.

           MOVE COUNT-KLON-RECS       TO WGLOB-MSG-PARM (1).
           MOVE 'CS05310037'          TO WGLOB-MSG-REF-INFO.
      * MSG: @1 PACK RECORDS CLONED
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

       7000-PROCESS-KLON-X.
           EXIT.

010418*****************
010418 7110-KLON-1ST-EDITS.
010418*****************

010418      IF MIR-LOC-GR-ID NOT = SPACES
010418         MOVE SPACES            TO  MIR-LOC-GR-ID
010418      END-IF.

010418      IF MIR-DI-PKG-NUM NOT = SPACES
010418         MOVE SPACES            TO  MIR-DI-PKG-NUM
010418      END-IF.

010418      IF MIR-CONN-PLAN-ID NOT = SPACES
010418         MOVE SPACES            TO  MIR-CONN-PLAN-ID
010418      END-IF.

010418      IF MIR-CONN-PKG-NUM NOT = SPACES
010418         MOVE SPACES            TO  MIR-CONN-PKG-NUM
010418      END-IF.

010418*
010418*---- CHECK KLON SOURCE EXIST OR NOT
010418*
010418     MOVE LOW-VALUES            TO WPACH-KEY.
           MOVE MIR-PLAN-ID           TO WPACH-PLAN-ID.
010418     MOVE MIR-SBSDRY-CO-ID      TO WPACH-SBSDRY-CO-ID.
010418
010418     MOVE HIGH-VALUES           TO WPACH-ENDBR-KEY.
           MOVE MIR-PLAN-ID           TO WPACH-ENDBR-PLAN-ID.
010418     MOVE MIR-SBSDRY-CO-ID      TO WPACH-ENDBR-SBSDRY-CO-ID.
010418*
010418     PERFORM  PACH-1000-BROWSE
010418         THRU PACH-1000-BROWSE-X.
010418*
010418     IF WPACH-IO-EOF
010418     OR NOT WPACH-IO-OK
010418         MOVE 'CS05310036'      TO WGLOB-MSG-REF-INFO
010418* MSG: CLONE SOURCE NOT FOUND
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418         GO TO 7110-KLON-1ST-EDITS-X
010418     ELSE
010418         PERFORM  PACH-2000-READ-NEXT
010418             THRU PACH-2000-READ-NEXT-X
010418         IF WPACH-IO-EOF
010418             MOVE 'CS05310036'  TO WGLOB-MSG-REF-INFO
010418* MSG: CLONE SOURCE NOT FOUND
010418             PERFORM  0260-1000-GENERATE-MESSAGE
010418                 THRU 0260-1000-GENERATE-MESSAGE-X
010418         END-IF
010418     END-IF.
010418*
010418     PERFORM  PACH-3000-END-BROWSE
010418         THRU PACH-3000-END-BROWSE-X.
010418*
010418 7110-KLON-1ST-EDITS-X.
010418     EXIT.
010418*
010418*
010418/
010418*********************
010418 7210-KLON-2ND-EDITS.
010418*********************

           MOVE MIR-PLAN-ID-2         TO WPH-PLAN-ID.
010418     PERFORM  PH-1000-READ
010418         THRU PH-1000-READ-X.
010418*
010418     IF NOT WPH-IO-OK
010418*MSG: 'PLAN CODE/RS MUST EXIST ON PHDR'
010418         MOVE 'CS05310001'      TO WGLOB-MSG-REF-INFO
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418         GO TO 7210-KLON-2ND-EDITS-X
010418     END-IF.

010418     IF MIR-DI-PKG-NUM = SPACES
010418        MOVE '001'              TO MIR-DI-PKG-NUM
010418     END-IF.
010418*
010418*---- CHECK KLON DESTINATION MUST NOT EXIST IN PACK
010418*
010418     MOVE LOW-VALUES            TO WPACH-KEY.
           MOVE MIR-PLAN-ID-2         TO WPACH-PLAN-ID.
           MOVE MIR-SBSDRY-CO-ID-2    TO WPACH-SBSDRY-CO-ID.

010418     MOVE HIGH-VALUES           TO WPACH-ENDBR-KEY.
           MOVE MIR-PLAN-ID-2         TO WPACH-ENDBR-PLAN-ID.
           MOVE MIR-SBSDRY-CO-ID-2    TO WPACH-ENDBR-SBSDRY-CO-ID.
010418*
010418     PERFORM  PACH-1000-BROWSE
010418         THRU PACH-1000-BROWSE-X.
010418*
010418     IF NOT WPACH-IO-OK
010418     OR WPACH-IO-EOF
010418         GO TO 7210-KLON-2ND-EDITS-X
010418     ELSE
010418         PERFORM  PACH-2000-READ-NEXT
010418             THRU PACH-2000-READ-NEXT-X
010418         IF NOT WPACH-IO-EOF
010418             MOVE 'CS05310038'  TO WGLOB-MSG-REF-INFO
010418* MSG:  CLONE DESTINATION (@1 @2 @3) ALREADY EXISTS
                   MOVE MIR-PLAN-ID-2 TO WGLOB-MSG-PARM (1)
                   MOVE SPACES        TO WGLOB-MSG-PARM (2)
                   MOVE MIR-SBSDRY-CO-ID-2
                                      TO WGLOB-MSG-PARM (3)
010418             PERFORM  0260-1000-GENERATE-MESSAGE
010418                 THRU 0260-1000-GENERATE-MESSAGE-X
010418         END-IF
010418     END-IF.

010418     PERFORM  PACH-3000-END-BROWSE
010418         THRU PACH-3000-END-BROWSE-X.
010418*
010418 7210-KLON-2ND-EDITS-X.
010418     EXIT.
010418*
010418/
010418*************************
010418 7220-CHECK-KLON-ONE-REC.
010418*************************
010418
010418*
010418*==== USE SEPARATE BROWSE AND WRITE CURSOR
010418*
010418     MOVE RPACH-KEY             TO HOLD-LAST-PACH-KEY.
010418*
010418*---- CREATE PACH WITH NEW KLONED SECURITY AND COMPANY
010418*----        USING SAME ROUTINE IN CREATION LOGIC
           MOVE MIR-PLAN-ID-2         TO WPACH-PLAN-ID.
           MOVE MIR-PLAN-ID-2         TO RPACH-PLAN-ID.
           MOVE MIR-SBSDRY-CO-ID-2    TO WPACH-SBSDRY-CO-ID
                                         RPACH-SBSDRY-CO-ID.
010418
010418     PERFORM  PACH-1000-WRITE
010418         THRU PACH-1000-WRITE-X.
010418
014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.

014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.

010418*
010418     IF WGLOB-MSG-ERROR-SW = ZERO
010418         ADD 1                     TO COUNT-KLON-RECS
010418     END-IF.
010418*
010418     MOVE HOLD-LAST-PACH-KEY    TO WPACH-KEY.
010418     PERFORM  PACH-2000-READ-NEXT
010418         THRU PACH-2000-READ-NEXT-X.
010418*
010418 7220-CHECK-KLON-ONE-REC-X.
010418     EXIT.
010418*
      *****************************************************************
      *  BUILD PACH KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
      *****************************************************************
       8000-BUILD-PACH-KEY.

           MOVE MIR-PLAN-ID           TO WPACH-PLAN-ID.
010302     MOVE MIR-LOC-GR-ID         TO WPACH-LOC-GR-ID.
010418     MOVE MIR-SBSDRY-CO-ID      TO WPACH-SBSDRY-CO-ID.
           MOVE MIR-DI-PKG-NUM        TO WPACH-DI-PKG-NUM.
           MOVE MIR-CONN-PLAN-ID      TO WPACH-CONN-PLAN-ID.
           MOVE MIR-CONN-PKG-NUM      TO WPACH-CONN-PKG-NUM.

       8000-BUILD-PACH-KEY-X.
           EXIT.
      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
       9100-BLANK-DATA-FIELDS.

           MOVE SPACES                TO MIR-PLAN-ID-G.
           MOVE SPACES                TO MIR-LOC-GR-ID-G.
           MOVE SPACES                TO MIR-SBSDRY-CO-ID-G.
           MOVE SPACES                TO MIR-DI-PKG-NUM-G.
           MOVE SPACES                TO MIR-CONN-PLAN-ID-G.
           MOVE SPACES                TO MIR-CONN-PKG-NUM-G.
           MOVE SPACES                TO MIR-DI-PKG-LIST-TYP-CD-G.
           MOVE SPACES                TO MIR-DI-PKG-QP-CD-G.
           MOVE SPACES                TO MIR-DI-PKG-QP-DUR-G.
           MOVE SPACES                TO MIR-DI-PKG-EP-CD-G.
           MOVE SPACES                TO MIR-DI-PKG-EP-DUR-G.
           MOVE SPACES                TO MIR-DI-PKG-BP-CD-G.
           MOVE SPACES                TO MIR-DI-PKG-BP-DUR-G.
           MOVE SPACES                TO MIR-OCCP-CLAS-QUALF-CD-G.
           MOVE SPACES                TO MIR-OCCP-CLAS-CD-G.
           MOVE SPACES                TO MIR-REDC-EP-ALLOW-CD-G.
           MOVE SPACES                TO MIR-OWN-OCCP-ALLOW-CD-G.
           MOVE SPACES                TO MIR-LTA-ALLOW-CD-G.
           MOVE SPACES                TO MIR-LTB-ALLOW-CD-G.
           MOVE SPACES                TO MIR-PDISAB-ALLOW-CD-G.
           MOVE SPACES                TO MIR-COLA-ALLOW-CD-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
       9200-MOVE-RECORD-TO-SCREEN.

           MOVE RPACH-PLAN-ID         TO MIR-PLAN-ID-T (WS-LINE).
010302     MOVE RPACH-LOC-GR-ID       TO MIR-LOC-GR-ID-T (WS-LINE).
010418     MOVE RPACH-SBSDRY-CO-ID    TO MIR-SBSDRY-CO-ID-T (WS-LINE).
           MOVE RPACH-DI-PKG-NUM      TO MIR-DI-PKG-NUM-T (WS-LINE).
           MOVE RPACH-CONN-PLAN-ID    TO MIR-CONN-PLAN-ID-T (WS-LINE).
           MOVE RPACH-CONN-PKG-NUM    TO MIR-CONN-PKG-NUM-T (WS-LINE).
           MOVE RPACH-DI-PKG-LIST-TYP-CD
                                  TO MIR-DI-PKG-LIST-TYP-CD-T (WS-LINE).
           MOVE RPACH-DI-PKG-QP-CD   TO MIR-DI-PKG-QP-CD-T (WS-LINE).
           MOVE RPACH-DI-PKG-QP-DUR  TO MIR-DI-PKG-QP-DUR-T (WS-LINE).
           MOVE RPACH-DI-PKG-EP-CD   TO MIR-DI-PKG-EP-CD-T (WS-LINE).
           MOVE RPACH-DI-PKG-EP-DUR  TO MIR-DI-PKG-EP-DUR-T (WS-LINE).
           MOVE RPACH-DI-PKG-BP-CD   TO MIR-DI-PKG-BP-CD-T (WS-LINE).
           MOVE RPACH-DI-PKG-BP-DUR  TO MIR-DI-PKG-BP-DUR-T (WS-LINE).
           MOVE RPACH-OCCP-CLAS-QUALF-CD
                                  TO MIR-OCCP-CLAS-QUALF-CD-T (WS-LINE).
           MOVE RPACH-OCCP-CLAS-CD   TO MIR-OCCP-CLAS-CD-T (WS-LINE).
           MOVE RPACH-COLA-ALLOW-CD  TO MIR-COLA-ALLOW-CD-T (WS-LINE).
           MOVE RPACH-REDC-EP-ALLOW-CD
                                  TO MIR-REDC-EP-ALLOW-CD-T (WS-LINE).
           MOVE RPACH-OWN-OCCP-ALLOW-CD
                                  TO MIR-OWN-OCCP-ALLOW-CD-T (WS-LINE).
           MOVE RPACH-LTA-ALLOW-CD   TO MIR-LTA-ALLOW-CD-T (WS-LINE).
557659*    MOVE RPACH-LTB-ALLOW-IND  TO MIR-LTB-ALLOW-CD-T (WS-LINE).
557659     MOVE RPACH-LTB-ALLOW-CD   TO MIR-LTB-ALLOW-CD-T (WS-LINE).
           MOVE RPACH-PDISAB-ALLOW-CD
                                     TO MIR-PDISAB-ALLOW-CD-T (WS-LINE).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
       9300-SETUP-MSIN-REFERENCE.

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  WS-SWITCHES.
025970     INITIALIZE  WS-COUNTERS.
025970     INITIALIZE  WS-WORKING-STORAGE.
025970     INITIALIZE  WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE  WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE  WMATC-WORK-AREA.
025970     SET WMATC-MATCH-ANY-CHAR-DEFAULT TO TRUE.
025970     SET WS-NO-LINE-DEFAULT  TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
025970     MOVE MIR-BUS-FCN-ID     TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK       TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
      /
       COPY CCPESTB1.
       COPY CCPESTB2.
       COPY CCPESTB3.
       COPY CCPESTB4.
010302 COPY CCPELGAS.
      /
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
020874 COPY XCPL0290.
020874 COPY XCPS0290.     
      /
       COPY XCPPINIT.
      /
014660*COPY XCPPMEXT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY PH
014221                         '$VAR2' BY 'PH'.
      /
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS                                 *
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNEDIT.
       COPY CCPAPACH.
       COPY CCPBPACH.
       COPY CCPNPACH.
       COPY CCPUPACH.
       COPY CCPXPACH.
       COPY CCPCPACH.
      /
       COPY CCPNSCOM.
      /
021930*COPY CCPBPH.
       COPY CCPNPH.
014221 COPY CCPUPH.
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0531                     **
      *****************************************************************
