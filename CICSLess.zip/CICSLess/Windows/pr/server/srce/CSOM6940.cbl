      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID.  CSOM6940.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM6940                                         **
      **  REMARKS:  POLI - POLICY INQUIRY - POLICY RELATIONSHIPS     **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
013578**  6.0       CREATION                                         **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
016686**  6.2       INGENIUM PROCESSING DATE CHANGES FOR CONCURRENCY **
018732**  6.3       CLIENT RETRIEVAL ENHANCEMENTS                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019143**  6.3       AMEND/DISPLAY CLIENT CONTACT INFORMATION (6.1.2J)**
019144**  6.3       CLIENT ADDRESS EXPANSION (6.1.2J)                **
019152**  6.3       GROUP CODE FIX                                   **
019155**  6.3       ADD STATUS AND DATE CHANGE FOR 2ND ADDRESS       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
015705**  6.4       NAME FORMATTING                                  **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM6940'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
           05  WS-FOUND-PRIMARY-SW                PIC X(01).
               88  WS-FOUND-PRIMARY               VALUE 'Y'.
               88  WS-NO-PRIMARY-EXISTS           VALUE 'N'.
016548*    05  WS-SUB                             PIC S9(04) COMP.
016548     05  WS-SUB                             PIC S9(04) BINARY.

       01  WS-EDIT-PROCESS-CHECKS.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-ID-BLANK      VALUE SPACES.
               88  WS-BUS-FCN-VALID         VALUE '6940'.
               88  WS-BUS-FCN-RELATIONSHIPS VALUE '6940'.

           05  WS-ERROR-SW                  PIC X(01).
               88  WS-ERROR-FOUND           VALUE 'Y'.
               88  WS-NO-ERRORS-FOUND       VALUE 'N'.

           05  WS-POLICY.
               10  WS-POL-ID-BASE           PIC X(09).
               10  WS-POL-ID-SFX            PIC X(01).
018732*    05  WS-CV-DATE.
018732*        10  WS-CV-DATE-YR            PIC 9(04).
018732*        10  FILLER                   PIC X(01).
018732*        10  WS-CV-DATE-MO            PIC 9(02).
018732*        10  FILLER                   PIC X(01).
018732*        10  WS-CV-DATE-DY            PIC 9(02).
016686*    05  WS-SCREEN-DATE               PIC X(10).

018732*01  WS-NUMERIC-CONVERSIONS.
018732*    05  WS-PIC-0-5                   PIC -.9(5).
018732*    05  WS-PIC-1-2                   PIC -9.99.
018732*    05  WS-PIC-1-4                   PIC -9.9(4).
018732*    05  WS-PIC-1-5                   PIC -9.9(5).
018732*    05  WS-PIC-2                     PIC -(2)9.
018732*    05  WS-PIC-2-3                   PIC -(2)9.9(3).
018732*    05  WS-PIC-2-7                   PIC --9.9(7).
018732*    05  WS-PIC-P3-1                  PIC 999.9.
018732*    05  WS-PIC-3-2                   PIC -(3)9.99.
018732*    05  WS-PIC-3-3                   PIC -(3)9.999.
018732*    05  WS-PIC-3-4                   PIC -(3)9.9(4).
018732*    05  WS-PIC-2-4                   PIC -(2)9.9(4).
018732*    05  WS-PIC-2-5                   PIC Z9.9(5).
018732*    05  WS-PIC-3-6                   PIC -(3)9.9(6).
018732*    05  WS-PIC-4-5                   PIC -(4)9.9(5).
018732*    05  WS-PIC-5-4                   PIC -(5)9.9(4).
018732*    05  WS-PIC-P6-5                  PIC Z(5)9.9(5).
018732*    05  WS-PIC-8-5                   PIC -(8)9.9(5).
018732*
018732     05  WS-GR-CD                     PIC S9(04) BINARY.
018732         88  WS-GR-ALPHA              VALUE 1.
018732         88  WS-GR-KANJI              VALUE 2.
018732         88  WS-GR-KATAKANA           VALUE 3.
018732
025970 01  WS-CONSTANTS.
018732     05  WS-GR-CD-MAX                 PIC S9(04) BINARY
018732                                      VALUE +3.
018732
018732     05  WS-REL-TBL-SIZE              PIC S9(04) BINARY
018732                                      VALUE +12.
018732
      ************************************************************
      * COMMON WORKING STORAGE COPYBOOKS                         *
      ************************************************************
      *
       COPY CCWWINDX.
      *
      ************************************************************
      * FILE I/O WORKING STORAGE COPYBOOKS                       *
      ************************************************************
       COPY CCFWPOL.
      *
       COPY CCFWPOLC.
       COPY CCFRPOLC.
      *
      ************************************************************
      * LINKAGE WORKING STORAGE COPYBOOKS                        *
      ************************************************************
028298 COPY CCWL2626.
       COPY XCWL0290.

       COPY CCWL0620.
       COPY CCWL2430.
      *
       COPY CCWL5400.
      *
       COPY CCWL6940.
      *
       COPY XCWLDTLK.
016537*COPY XCWL0225.
016537*COPY XCWL0280.
       COPY XCWL1640.
      *
      *01  WGLOB-GLOBAL-AREA.
      *COPY XCWWGLOB.
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM6940.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           INITIALIZE L2430-OUTPUT-PARM-INFO.
           INITIALIZE RPOL-REC-INFO.

           PERFORM 0290-1000-BUILD-PARM-INFO
              THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  0100-SET-MIR-VALUES
               THRU 0100-SET-MIR-VALUES-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      *--------------------
       0100-SET-MIR-VALUES.
      *--------------------

           MOVE WS-POL-ID-BASE        TO MIR-POL-ID-BASE.
           MOVE WS-POL-ID-SFX         TO MIR-POL-ID-SFX.
016686*    MOVE WS-SCREEN-DATE        TO MIR-APPL-CTL-PRCES-DT.

       0100-SET-MIR-VALUES-X.
           EXIT.

      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------


           PERFORM  9000-SETUP-MSIN-REFERENCE
               THRU 9000-SETUP-MSIN-REFERENCE-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  2050-SET-WS-FROM-MIR
               THRU 2050-SET-WS-FROM-MIR-X.


           SET WS-NO-ERRORS-FOUND      TO TRUE.

           IF  WS-ERROR-FOUND
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2200-MORE-INITIAL-EDITS
               THRU 2200-MORE-INITIAL-EDITS-X.

           IF  WS-ERROR-FOUND
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2300-COMMON-LINE-SET
               THRU 2300-COMMON-LINE-SET-X.

           PERFORM  3000-PROCESS-INQUIRE
               THRU 3000-PROCESS-INQUIRE-X.


       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *---------------------
       2050-SET-WS-FROM-MIR.
      *---------------------

           MOVE MIR-POL-ID-BASE       TO WS-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WS-POL-ID-SFX.
016686*    MOVE MIR-APPL-CTL-PRCES-DT TO WS-SCREEN-DATE.

016686*    IF  MIR-APPL-CTL-PRCES-DT = SPACES
016686*        MOVE WGLOB-PROCESS-DATE  TO L1640-INTERNAL-DATE
016686*        PERFORM  1640-2000-INTERNAL-TO-EXT
016686*            THRU 1640-2000-INTERNAL-TO-EXT-X
016686*        MOVE L1640-EXTERNAL-DATE
016686*                               TO WS-SCREEN-DATE
016686*    ELSE
016686*        MOVE MIR-APPL-CTL-PRCES-DT
016686*                               TO WS-SCREEN-DATE
016686*    END-IF.


       2050-SET-WS-FROM-MIR-X.
           EXIT.
      *
      *------------------------
       2200-MORE-INITIAL-EDITS.
      *------------------------

           MOVE WS-POL-ID-BASE        TO WPOL-POL-ID-BASE.
           MOVE WS-POL-ID-SFX         TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-OK
               CONTINUE
           ELSE
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    POLICY RECORD NOT FOUND (@1)
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


016686*    MOVE WS-SCREEN-DATE        TO L1640-EXTERNAL-DATE.
016686*
016686*    PERFORM  1640-3000-EXTERNAL-TO-INT
016686*        THRU 1640-3000-EXTERNAL-TO-INT-X.
016686*
016686*    IF  L1640-NOT-VALID
016686*        SET WS-ERROR-FOUND      TO TRUE
016686*MSG:    'DATE @1 INVALID'
016686*        MOVE 'CS69400001'      TO WGLOB-MSG-REF-INFO
016686*        MOVE WS-SCREEN-DATE    TO WGLOB-MSG-PARM (1)
016686*        PERFORM  0260-1000-GENERATE-MESSAGE
016686*            THRU 0260-1000-GENERATE-MESSAGE-X
016686*    END-IF.

           IF  WS-ERROR-FOUND
               GO TO 2200-MORE-INITIAL-EDITS-X
           END-IF.

      *
      * PERFORM CONFIDENTIAL POLICY AND BRANCH LEVEL SECURITY CHECKS
      *
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF L5400-CNFD-ACCS-RESTRICTED
           OR L5400-BRCH-ACCS-RESTRICTED
               SET WS-ERROR-FOUND      TO TRUE
               GO TO 2200-MORE-INITIAL-EDITS-X
           END-IF.

       2200-MORE-INITIAL-EDITS-X.
           EXIT.
      *
      *---------------------
       2300-COMMON-LINE-SET.
      *---------------------

      *
      * READ AND FORMAT OWNERS NAME
      *
           PERFORM  2320-GET-OWNER
               THRU 2320-GET-OWNER-X.

           INITIALIZE L0620-INPUT-PARM-INFO.
           IF L2430-CLI-SEX-COMPANY
               MOVE L2430-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
           ELSE
               MOVE L2430-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
               MOVE L2430-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
015705         MOVE L2430-CLI-MID-INIT-NM
015705                                TO L0620-CLI-MID-INIT-NM
015705         MOVE L2430-CLI-SFX-NM  TO L0620-CLI-SFX-NM

           END-IF.
           MOVE L2430-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           MOVE L0620-SCREEN-NAME     TO MIR-DV-OWN-CLI-NM.
           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD.
           MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.

       2300-COMMON-LINE-SET-X.
           EXIT.
      *
      *---------------
       2320-GET-OWNER.
      *---------------

           MOVE +0                    TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  L2430-CLI-ID = SPACES
               PERFORM  2400-CHECK-FOR-OWNER-CLI
                   THRU 2400-CHECK-FOR-OWNER-CLI-X
           ELSE
               IF  L2430-CLI-NM-COMPRESSED = SPACES
      *MSG:        OWNER CLIENT NAME = SPACES
                   MOVE 'CS69400006'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       2320-GET-OWNER-X.
           EXIT.
      *
      *-------------------------
       2400-CHECK-FOR-OWNER-CLI.
      *-------------------------

      *
      * BUILD START/END BROWSE KEY
      *
           MOVE LOW-VALUES            TO  WPOLC-KEY.
           MOVE RPOL-POL-ID           TO  WPOLC-POL-ID.
           MOVE 'O'                   TO  WPOLC-POL-CLI-REL-TYP-CD.

           MOVE WPOLC-KEY             TO  WPOLC-ENDBR-KEY.
           MOVE HIGH-VALUES           TO  WPOLC-ENDBR-CLI-ID.

      *
      *  POSITION AT THE FIRST RECORD FOR THE GIVEN RELATIONSHIP
      *
           PERFORM  POLC-1000-BROWSE
               THRU POLC-1000-BROWSE-X.

           IF  WPOLC-IO-OK
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
           END-IF.

           IF  WPOLC-IO-EOF
               MOVE 'CS69400007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-3000-END-BROWSE
                   THRU POLC-3000-END-BROWSE-X
               GO TO  2400-CHECK-FOR-OWNER-CLI-X
           END-IF.

           SET  WS-NO-PRIMARY-EXISTS TO TRUE.
           PERFORM  2500-DETERMINE-IF-PRIMARY
               THRU 2500-DETERMINE-IF-PRIMARY-X
               UNTIL WPOLC-IO-EOF
               OR    WS-FOUND-PRIMARY.

           IF  WS-NO-PRIMARY-EXISTS
               MOVE 'CS69400007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-3000-END-BROWSE
                   THRU POLC-3000-END-BROWSE-X
               GO TO  2400-CHECK-FOR-OWNER-CLI-X
           END-IF.

           PERFORM  2600-FIND-OWNERS-LOOP
               THRU 2600-FIND-OWNERS-LOOP-X
               UNTIL WPOLC-IO-EOF.

           PERFORM  POLC-3000-END-BROWSE
               THRU POLC-3000-END-BROWSE-X.


       2400-CHECK-FOR-OWNER-CLI-X.
           EXIT.

      *--------------------------
       2500-DETERMINE-IF-PRIMARY.
      *--------------------------

           IF  RPOLC-POL-CLI-REL-SUB-CD = 'P'
               SET WS-FOUND-PRIMARY TO TRUE
               GO TO 2500-DETERMINE-IF-PRIMARY-X
           END-IF.

           PERFORM  POLC-2000-READ-NEXT
               THRU POLC-2000-READ-NEXT-X.

       2500-DETERMINE-IF-PRIMARY-X.
           EXIT.

      *----------------------
       2600-FIND-OWNERS-LOOP.
      *----------------------

           IF  RPOLC-POL-CLI-REL-SUB-CD NOT = 'P'
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
               GO TO 2600-FIND-OWNERS-LOOP-X
           END-IF.

           MOVE +0                    TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

      *
      * WE HAVE FOUND THE REQUIRED RECORD, READ THE CLIENT FILE
      *
           MOVE  RPOLC-CLI-ID         TO  L2430-CLI-ID.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  NOT L2430-RETRN-OK
               MOVE 'XS00000058'      TO WGLOB-MSG-REF-INFO
               MOVE L2430-CLI-ID      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
           END-IF.

       2600-FIND-OWNERS-LOOP-X.
           EXIT.
      *
      *--------------------
       3000-PROCESS-INQUIRE.
      *--------------------

018732*    IF WGLOB-COUNTRY-JAPAN
018732*
018732*
018732*       PERFORM  6940-1000-BUILD-PARM-INFO
018732*           THRU 6940-1000-BUILD-PARM-INFO-X
018732*
018732*       PERFORM  6940-1000-INQUIRE
018732*           THRU 6940-1000-INQUIRE-X
018732*
018732*       PERFORM  9200-MOVE-PRIMARY-RECORD
018732*          THRU  9200-MOVE-PRIMARY-RECORD-X
018732*
018732*       PERFORM  6940-1000-BUILD-PARM-INFO
018732*           THRU 6940-1000-BUILD-PARM-INFO-X
018732*
018732*       PERFORM  6940-1000-INQUIRE
018732*           THRU 6940-1000-INQUIRE-X
018732*
018732*       PERFORM  9300-MOVE-SECONDARY-RECORD
018732*          THRU  9300-MOVE-SECONDARY-RECORD-X
018732*
018732*    ELSE
018732*
018732*        SET L6940-CLI-GR-ALPHA        TO TRUE
018732*
018732*        PERFORM  6940-1000-INQUIRE
018732*            THRU 6940-1000-INQUIRE-X
018732*
018732*        PERFORM  9200-MOVE-PRIMARY-RECORD
018732*           THRU  9200-MOVE-PRIMARY-RECORD-X
018732*
018732*    END-IF.
018732*
018732     PERFORM
018732         VARYING WS-GR-CD
018732         FROM 1 BY 1
018732         UNTIL WS-GR-CD > WS-GR-CD-MAX
018732
018732         PERFORM  6940-1000-BUILD-PARM-INFO
018732             THRU 6940-1000-BUILD-PARM-INFO-X
018732
018732         EVALUATE TRUE
018732
018732             WHEN WS-GR-ALPHA
018732                  SET L6940-CLI-ADDR-GR-ALPHA   TO TRUE
018732                  SET L6940-CLI-NM-GR-ALPHA     TO TRUE
018732
018732             WHEN WS-GR-KANJI
018732                  SET L6940-CLI-ADDR-GR-KANJI   TO TRUE
018732                  SET L6940-CLI-NM-GR-KANJI     TO TRUE
018732
018732             WHEN WS-GR-KATAKANA
018732                  SET L6940-CLI-ADDR-GR-KATAKANA TO TRUE
018732                  SET L6940-CLI-NM-GR-KATAKANA   TO TRUE
018732
018732         END-EVALUATE
018732
018732         PERFORM  6940-1000-INQUIRE
018732             THRU 6940-1000-INQUIRE-X
018732
018732         PERFORM  9100-MOVE-DATA-MIR
018732             THRU 9100-MOVE-DATA-MIR-X
018732
018732     END-PERFORM.

       3000-PROCESS-INQUIRE-X.
           EXIT.
      *

      *--------------------------
       9000-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY      TO TRUE.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.

       9000-SETUP-MSIN-REFERENCE-X.
           EXIT.
      *
018732*---------------------------
018732 9100-MOVE-DATA-MIR.
018732*---------------------------
018732
018732     IF  L6940-CLI-ADDR
018732         MOVE L6940-CLI-ADDR-GR-CD    TO MIR-CLI-ADDR-GR-CD
018732     END-IF.
018732
018732     IF  L6940-CLI-NM
018732         MOVE L6940-CLI-NM-GR-CD      TO MIR-DV-CLI-NM-GR-CD
018732     END-IF.
018732
018732
018732     MOVE L6940-ADRNM
018732     TO MIR-DV-LBILL-CLI-NM-T (WS-GR-CD).
018732
018732     MOVE L6940-ADRLN1
018732     TO MIR-CLI-ADDR-LN-1-TXT-T (WS-GR-CD).
018732
018732     MOVE L6940-ADRLN2
018732     TO MIR-CLI-ADDR-LN-2-TXT-T (WS-GR-CD).
018732
018732     MOVE L6940-ADRLN3
018732     TO MIR-CLI-ADDR-LN-3-TXT-T (WS-GR-CD).
018732
018732     MOVE L6940-ADRLN4
018732     TO MIR-DV-CLI-ADDR-LN-4-TXT-T (WS-GR-CD).
018732
018732     MOVE L6940-ADRLN5
018732     TO MIR-DV-CLI-ADDR-LN-5-TXT-T (WS-GR-CD).
018732
018732     MOVE L6940-ADRLN6
018732     TO MIR-DV-CLI-ADDR-LN-6-TXT-T (WS-GR-CD).
018732
018732     MOVE L6940-ADRADDL
018732     TO MIR-CLI-ADDR-ADDL-TXT-T (WS-GR-CD).
018732
018732     MOVE L6940-ADRST
018732     TO MIR-CLI-ADDR-STAT-CD-T (WS-GR-CD).
018732
018732     MOVE L6940-ADRDT                 TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
018732     MOVE L1640-EXTERNAL-DATE
018732     TO MIR-CLI-ADDR-CHNG-DT-T (WS-GR-CD)
018732
018732     MOVE L6940-ADRTP
018732     TO MIR-CLI-ADDR-TYP-CD-T (WS-GR-CD).
018732
018732     MOVE L6940-CLI-ADDR-CNTCT-TXT
018732     TO MIR-CLI-ADDR-CNTCT-TXT-T (WS-GR-CD).
018732
018732     MOVE L6940-PURDSC
018732     TO MIR-POL-INS-PURP-CD.
018732
018732     PERFORM
018732         VARYING WS-SUB FROM 1 BY 1
018732         UNTIL   WS-SUB > WS-REL-TBL-SIZE
018732
018732         MOVE L6940-EDTTD-T (WS-SUB)
018732         TO MIR-POL-CLI-REL-TYP-CD-T (WS-SUB)
018732
018732         MOVE L6940-ASSTY-T (WS-SUB)
018732         TO MIR-POL-CLI-REL-SUB-CD-T (WS-SUB)
018732
018732         MOVE L6940-BENRL-T (WS-SUB)
018732         TO MIR-POL-CLI-INSRD-CD-T (WS-SUB)
018732
018732         MOVE L6940-CLINN-T (WS-SUB)
018732         TO MIR-CLI-ID-T (WS-SUB)
018732
018732         EVALUATE TRUE
018732
018732             WHEN WS-GR-ALPHA
018732                  MOVE L6940-LTNAM-T (WS-SUB)
018732                  TO MIR-DV-CLI-NM-1-T (WS-SUB)
018732
018732             WHEN WS-GR-KANJI
018732                  MOVE L6940-LTNAM-T (WS-SUB)
018732                  TO MIR-DV-CLI-NM-2-T (WS-SUB)
018732
018732             WHEN OTHER
018732                  MOVE L6940-LTNAM-T (WS-SUB)
018732                  TO MIR-DV-CLI-NM-3-T (WS-SUB)
018732
018732         END-EVALUATE
018732
018732     END-PERFORM.
018732
018732 9100-MOVE-DATA-MIR-X.
018732     EXIT.
023514
018732
018732*--------------------------
018732*9200-MOVE-PRIMARY-RECORD.
018732*--------------------------
018732*
018732* BUILD OUTPUT PARMS
018732*
018732*    MOVE L6940-ADRDT            TO L1640-INTERNAL-DATE.
018732*    PERFORM  1640-2000-INTERNAL-TO-EXT
018732*        THRU 1640-2000-INTERNAL-TO-EXT-X.
018732*    MOVE L1640-EXTERNAL-DATE    TO MIR-CLI-ADDR-CHNG-DT.
018732*
018732*    MOVE L6940-ADRTP            TO MIR-CLI-ADDR-TYP-CD.
018732*    MOVE L6940-ADRST            TO MIR-CLI-ADDR-STAT-CD.
018732*    MOVE L6940-ADRNM            TO MIR-DV-CLI-NM.
018732*    MOVE L6940-ADRLN1           TO MIR-CLI-ADDR-LN-1-TXT.
018732*    MOVE L6940-ADRLN2           TO MIR-CLI-ADDR-LN-2-TXT.
018732*    MOVE L6940-ADRLN3           TO MIR-CLI-ADDR-LN-3-TXT.
015904*    MOVE L6940-ADRLN4           TO MIR-CLI-ADDR-LN-4-TXT.
018732*    MOVE L6940-ADRLN4           TO MIR-DV-CLI-ADDR-LN-4-TXT.
015904*    MOVE L6940-ADRLN5           TO MIR-CLI-ADDR-LN-5-TXT.
018732*    MOVE L6940-ADRLN5           TO MIR-DV-CLI-ADDR-LN-5-TXT.
018732*    MOVE L6940-ADRLN6           TO MIR-DV-CLI-ADDR-LN-6-TXT.
018732*    MOVE L6940-ADRADDL          TO MIR-CLI-ADDR-ADDL-TXT.
019155*    MOVE L6940-CLI-JP-ADDR-CD   TO MIR-CLI-JP-ADDR-CD.
018732*    MOVE L6940-PURDSC           TO MIR-POL-INS-PURP-CD.
018732*
018732*    PERFORM
018732*        VARYING WS-SUB FROM 1 BY 1
018732*        UNTIL   WS-SUB > 12
018732*
018732*        MOVE L6940-EDTTD-T (WS-SUB)
018732*                             TO MIR-POL-CLI-REL-TYP-CD-T (WS-SUB)
018732*
018732*        MOVE L6940-ASSTY-T (WS-SUB)
018732*                             TO MIR-POL-CLI-REL-SUB-CD-T (WS-SUB)
018732*
018732*        MOVE L6940-BENRL-T (WS-SUB)
018732*                               TO MIR-POL-CLI-INSRD-CD-T (WS-SUB)
018732*
018732*        MOVE L6940-CLINN-T (WS-SUB) TO MIR-CLI-ID-T (WS-SUB)
018732*
018732*        MOVE L6940-LTNAM-T (WS-SUB)
018732*                                  TO MIR-DV-CLI-NM-T (WS-SUB)
018732*
018732*    END-PERFORM.
018732*
018732*
018732*9200-MOVE-PRIMARY-RECORD-X.
018732*    EXIT.
018732*
018732*--------------------------
018732*9300-MOVE-SECONDARY-RECORD.
018732*--------------------------
018732*
018732* BUILD OUTPUT PARMS
018732*
018732*    MOVE L6940-ADRDT            TO L1640-INTERNAL-DATE.
018732*    PERFORM  1640-2000-INTERNAL-TO-EXT
018732*        THRU 1640-2000-INTERNAL-TO-EXT-X.
018732*    MOVE L1640-EXTERNAL-DATE    TO MIR-CLI-ADDR-CHNG-DT-2.
018732*
018732*    MOVE L6940-ADRST            TO MIR-CLI-ADDR-STAT-CD-2.
018732*
018732*    MOVE L6940-ADRNM            TO MIR-DV-CLI-NM-2.
018732*    MOVE L6940-ADRLN1           TO MIR-CLI-ADDR-LN-1-TXT-2.
018732*    MOVE L6940-ADRLN2           TO MIR-CLI-ADDR-LN-2-TXT-2.
018732*    MOVE L6940-ADRLN3           TO MIR-CLI-ADDR-LN-3-TXT-2.
018732*    MOVE L6940-ADRLN4           TO MIR-DV-CLI-ADDR-LN-4-TXT-2.
018732*    MOVE L6940-ADRLN5           TO MIR-DV-CLI-ADDR-LN-5-TXT-2.
018732*    MOVE L6940-ADRLN6           TO MIR-DV-CLI-ADDR-LN-6-TXT-2.
018732*    MOVE L6940-ADRADDL          TO MIR-CLI-ADDR-ADDL-TXT-2.
018732*
018732*    PERFORM
018732*        VARYING WS-SUB FROM 1 BY 1
018732*        UNTIL   WS-SUB > 12
018732*
018732*        MOVE L6940-LTNAM-T (WS-SUB)
018732*                                  TO MIR-DV-CLI-NM-2-T (WS-SUB)
018732*
018732*    END-PERFORM.
018732*
018732*
018732*9300-MOVE-SECONDARY-RECORD-X.
018732*    EXIT.
      *
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6940-0000-INIT-PARM-INFO
025970         THRU 6940-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WS-EDIT-PROCESS-CHECKS.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *****************************************************************
      *  PROCESSING COPYBOOKS
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
      *****************************************************************
      *  LINKAGE COPYBOOKS
      *****************************************************************
      *
       COPY CCPSPGA.
      *
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0620.
      *
       COPY XCPS0290.
016537*COPY XCPL0290.
      *
       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      *
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      *
       COPY CCPS6940.
018764*COPY CCCL6940.
018764 COPY CCPL6940.
      *
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
      *
016537*COPY XCCL0225.
      *
      *
016537*COPY XCPL0280.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
      *
       COPY CCPNPOL.
      *
       COPY CCPBPOLC.
      *
      *****************************************************************
      *  ERROR PROCESSING COPYPBOOKS
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      *
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM6940                     **
      *****************************************************************


