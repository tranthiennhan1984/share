      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2575.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2575                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE COPY FUNCTION     **
      **            FOR THE PLIP TABLE                               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020463**  6.4       INVESTOR PROFILES                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2575'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-COPY              VALUE '2575'.

       01  WS-CONSTANT-AREA.
           05  WS-TWRK-KEY                      PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT          VALUE '2575'.
025970*                                         VALUE '2575'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
      /
       COPY XCWL8090.
      /
       COPY XCWEBLCH.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWPH.
       COPY CCFRPH.
      /
       COPY CCFWPD.
       COPY CCFRPD.
      /
       COPY CCFWIPRE.
       COPY CCFRIPRD.
      /
       COPY CCFWIPRO.
       COPY CCFRIPRO.
      /
       COPY CCFWPLIP.
       COPY CCFHPLIP.
       COPY CCFRPLIP.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2575.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-COPY
                    PERFORM  2000-COPY
                        THRU 2000-COPY-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2575'       TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'     TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *----------
       2000-COPY.
      *----------
      *
      *  THE PROTOTYPE RECORD SHOULD EXIST ON A COPY
      *
           PERFORM  7000-BUILD-FROM-REC-KEYS
               THRU 7000-BUILD-FROM-REC-KEYS-X.

           PERFORM  PLIP-1000-READ
               THRU PLIP-1000-READ-X.

           IF  NOT WPLIP-IO-OK
      *MSG: RECORD @1 NOT FOUND
               MOVE WPLIP-KEY            TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-COPY-X
           END-IF.

           MOVE  RPLIP-REC-INFO          TO HPLIP-REC-INFO.

      *   THE NEW RECORD SHOULD NOT EXIST ON A COPY

           PERFORM  7100-BUILD-TO-REC-KEYS
               THRU 7100-BUILD-TO-REC-KEYS-X.

           PERFORM  PLIP-1000-READ
               THRU PLIP-1000-READ-X.

           IF  WPLIP-IO-OK
      *MSG: 'RECORD @1 ALREADY EXISTS'
               MOVE WPLIP-KEY            TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-COPY-X
           END-IF.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           PERFORM  2200-XEDIT-FIELDS
               THRU 2200-XEDIT-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-COPY-X
           END-IF.

      *  ESTABLISH CREATE RECORD KEY

           PERFORM  7100-BUILD-TO-REC-KEYS
               THRU 7100-BUILD-TO-REC-KEYS-X.

      *
      *  CREATE THE NEW RECORD
      *
           PERFORM  PLIP-1000-CREATE
               THRU PLIP-1000-CREATE-X.

      *  COPY PROTOTYPE RECORD AND RESTORE THE NEW RECORD KEY

           MOVE HPLIP-REC-INFO           TO RPLIP-REC-INFO.
           MOVE MIR-PLAN-ID-2            TO RPLIP-PLAN-ID.
           MOVE MIR-PRFL-ID-2            TO RPLIP-PRFL-ID.
           MOVE MIR-SBSDRY-CO-ID-2       TO RPLIP-SBSDRY-CO-ID.
           MOVE MIR-LOC-GR-ID-2          TO RPLIP-LOC-GR-ID.
           MOVE WWKDT-ZERO-DT            TO RPLIP-PLAN-PRFL-CHNG-DT.

           PERFORM  PLIP-1000-WRITE
               THRU PLIP-1000-WRITE-X.

      *MSG: RECORD CREATED SUCCESSFULLY - CONTINUE

           MOVE 'CS25750011'           TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
               
      *  UPDATE THE TIMESTAMP FOR LOGICAL LOCKING

           PERFORM  PLIP-1000-READ-TWRK-TS
               THRU PLIP-1000-READ-TWRK-TS-X.

       2000-COPY-X.
           EXIT.

      /
      *-----------------------
       2100-VALIDATE-KEYS.
      *-----------------------

           PERFORM  4110-EDIT-PLAN-ID
               THRU 4110-EDIT-PLAN-ID-X.

           PERFORM  4120-EDIT-PRFL-ID
               THRU 4120-EDIT-PRFL-ID-X.

           PERFORM  4130-EDIT-SBSDRY-CO-ID
               THRU 4130-EDIT-SBSDRY-CO-ID-X.

           PERFORM  4140-EDIT-LOC-GR-ID
               THRU 4140-EDIT-LOC-GR-ID-X.

       2100-VALIDATE-KEYS-X.
           EXIT.

      *-----------------------
       2200-XEDIT-FIELDS.
      *-----------------------

           PERFORM  5110-XEDIT-INS-TYP-CD
               THRU 5110-XEDIT-INS-TYP-CD-X.

           PERFORM  5120-XEDIT-PRFLD-STAT-CD
               THRU 5120-XEDIT-PRFLD-STAT-CD-X.

           PERFORM  5130-XEDIT-PRFL-XPRY-DT
               THRU 5130-XEDIT-PRFL-XPRY-DT-X.

       2200-XEDIT-FIELDS-X.
           EXIT.

      /
      *-----------------------
       4110-EDIT-PLAN-ID.
      *-----------------------

           IF  MIR-PLAN-ID-2 =  SPACES
           OR  MIR-PLAN-ID-2 = EBLCH-BLANK-FIELD-CHAR
      *MSG: PLAN CODE MUST NOT BE BLANK
               MOVE 'CS25750001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 4110-EDIT-PLAN-ID-X
           END-IF.

           MOVE MIR-PLAN-ID-2            TO  WPH-PLAN-ID.

           PERFORM  PH-1000-READ
               THRU PH-1000-READ-X.

           IF  WPH-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WPH-KEY              TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 4110-EDIT-PLAN-ID-X
           END-IF.

       4110-EDIT-PLAN-ID-X.
           EXIT.

      *-----------------------
       4120-EDIT-PRFL-ID.
      *-----------------------

           IF  MIR-PRFL-ID-2 =  SPACES
           OR  MIR-PRFL-ID-2 = EBLCH-BLANK-FIELD-CHAR
      *MSG: INVESTOR PROFILE ID MUST NOT BE BLANK
               MOVE 'CS25750003'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 4120-EDIT-PRFL-ID-X
           END-IF.

      *
      *   CHECK WHETHER INVESTOR PROFILE ID IS VALID
      *
            MOVE 'IPROF'                 TO WEDIT-ETBL-TYP-ID.
            MOVE MIR-PRFL-ID-2           TO WEDIT-ETBL-VALU-ID.
            MOVE WGLOB-EDIT-LANG         TO WEDIT-ETBL-LANG-CD.
            PERFORM EDIT-1000-READ
               THRU EDIT-1000-READ-X.

            IF NOT WEDIT-IO-OK
      *MSG: INVESTOR PROFILE MUST BE DEFINED ON EDIT TYPE @1
               MOVE WEDIT-ETBL-TYP-ID    TO WGLOB-MSG-PARM (1)
               MOVE 'CS25750004'         TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 4120-EDIT-PRFL-ID-X
            END-IF.

       4120-EDIT-PRFL-ID-X.
           EXIT.

      *-----------------------
       4130-EDIT-SBSDRY-CO-ID.
      *-----------------------

           IF  MIR-SBSDRY-CO-ID-2 =  SPACES
           OR  MIR-SBSDRY-CO-ID-2 = EBLCH-BLANK-FIELD-CHAR
      *MSG: SUB-COMPANY ID MUST NOT BE BLANK
               MOVE 'CS25750005'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 4130-EDIT-SBSDRY-CO-ID-X
           END-IF.

      *
      *   CHECK WHETHER SUB-COMPANY ID IS VALID
      *
            MOVE 'SUBCO'                 TO WEDIT-ETBL-TYP-ID.
            MOVE MIR-SBSDRY-CO-ID-2      TO WEDIT-ETBL-VALU-ID.
            MOVE WGLOB-EDIT-LANG         TO WEDIT-ETBL-LANG-CD.
            PERFORM EDIT-1000-READ
               THRU EDIT-1000-READ-X.

            IF NOT WEDIT-IO-OK
      *MSG: SUB-COMPANY ID MUST BE DEFINED ON EDIT TYPE @1
               MOVE WEDIT-ETBL-TYP-ID    TO WGLOB-MSG-PARM (1)
               MOVE 'CS25750006'         TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                   TO WGLOB-MSG-ERROR-SW
               GO TO 4130-EDIT-SBSDRY-CO-ID-X
            END-IF.

       4130-EDIT-SBSDRY-CO-ID-X.
           EXIT.

      *-----------------------
       4140-EDIT-LOC-GR-ID.
      *-----------------------

           IF  MIR-LOC-GR-ID-2 =  SPACES
           OR  MIR-LOC-GR-ID-2 = EBLCH-BLANK-FIELD-CHAR
      *MSG: LOCATION GROUP MUST NOT BE BLANK
               MOVE WEDIT-ETBL-TYP-ID   TO WGLOB-MSG-PARM (1)
               MOVE 'CS25750007'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                   TO WGLOB-MSG-ERROR-SW
               GO TO  4140-EDIT-LOC-GR-ID-X
           END-IF.

      *
      *   CHECK WHETHER SUB-COMPANY ID IS VALID
      *
            MOVE 'LOCGP'                TO WEDIT-ETBL-TYP-ID.
            MOVE MIR-LOC-GR-ID          TO WEDIT-ETBL-VALU-ID.
            MOVE WGLOB-EDIT-LANG        TO WEDIT-ETBL-LANG-CD.
            PERFORM EDIT-1000-READ
               THRU EDIT-1000-READ-X.

            IF NOT WEDIT-IO-OK
      *MSG: LOCATION GROUP MUST BE DEFINED ON EDIT TYPE @1
               MOVE WEDIT-ETBL-TYP-ID   TO WGLOB-MSG-PARM (1)
               MOVE 'CS25750008'        TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                   TO WGLOB-MSG-ERROR-SW
               GO TO  4140-EDIT-LOC-GR-ID-X
            END-IF.

       4140-EDIT-LOC-GR-ID-X.
           EXIT.
      /
      *--------------------------
       5110-XEDIT-INS-TYP-CD.
      *--------------------------
      *
      * CHECK INSURANCE TYPE CODE
      *
           MOVE RPH-KEY       TO WPD-KEY.

           PERFORM  PD-1000-READ
               THRU PD-1000-READ-X.

           IF  WPH-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WPD-KEY             TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                   TO WGLOB-MSG-ERROR-SW
               GO TO 5110-XEDIT-INS-TYP-CD-X
           END-IF.

           IF  RPD-PLAN-INS-TYP-SEG-FUND
           OR  RPD-PLAN-INS-TYP-FPA
           OR  RPD-PLAN-INS-TYP-RRIF
               CONTINUE
           ELSE
      *MSG: PLAN MUST BE FLEXIBLE ANNUITY/UL/VARIABLE FUND/RRIF
               MOVE 'CS25750002'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                   TO WGLOB-MSG-ERROR-SW
               GO TO 5110-XEDIT-INS-TYP-CD-X
           END-IF.

       5110-XEDIT-INS-TYP-CD-X.
           EXIT.

      *--------------------------
       5120-XEDIT-PRFLD-STAT-CD.
      *--------------------------
      *
      * CHECK THE PROFILE STAUS CODE ON INVESTOR PROFILE DETAILS
      *
            MOVE MIR-PRFL-ID-2          TO WIPRE-PRFL-ID.
            SET WIPRE-PRFLD-STAT-ACTV   TO TRUE.

            MOVE WIPRE-KEY              TO WIPRE-ENDBR-KEY.

            PERFORM  IPRE-1000-BROWSE
                THRU IPRE-1000-BROWSE-X.

            PERFORM  IPRE-2000-READ-NEXT
                THRU IPRE-2000-READ-NEXT-X
               UNTIL NOT WIPRE-IO-OK
                  OR RIPRD-PRFLD-STAT-ACTV.

            EVALUATE TRUE
                WHEN RIPRD-PRFLD-STAT-ACTV
                     CONTINUE
                WHEN OTHER
      *MSG: NO ACTIVE RECORDS EXIST ON INVESTOR PROFILE
      *     DETAIL TABLE FOR SELECTED PROFILE (@1)
                      MOVE MIR-PRFL-ID  TO WGLOB-MSG-PARM (1)
                      MOVE 'CS25750009' TO WGLOB-MSG-REF-INFO
                      PERFORM  0260-1000-GENERATE-MESSAGE
                          THRU 0260-1000-GENERATE-MESSAGE-X
                      MOVE 1            TO WGLOB-MSG-ERROR-SW
            END-EVALUATE.

            PERFORM  IPRE-3000-END-BROWSE
                THRU IPRE-3000-END-BROWSE-X.

       5120-XEDIT-PRFLD-STAT-CD-X.
           EXIT.
      /
      *--------------------------
       5130-XEDIT-PRFL-XPRY-DT.
      *--------------------------
      *
      * CHECK THE EXPIRY DATE ON INVESTOR PROFILE
      *
            MOVE MIR-PRFL-ID-2          TO WIPRO-PRFL-ID.

            PERFORM  IPRO-1000-READ
                THRU IPRO-1000-READ-X.

            IF  WIPRO-IO-OK
                CONTINUE
            ELSE
               MOVE WIPRO-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                   TO WGLOB-MSG-ERROR-SW
                   GO TO 5130-XEDIT-PRFL-XPRY-DT-X
            END-IF.

            IF  RIPRO-PRFL-XPRY-DT = WWKDT-ZERO-DT
                CONTINUE
            ELSE
                IF  WGLOB-PROCESS-DATE >= RIPRO-PRFL-XPRY-DT
      *MSG: INVESTOR PROFILE (@1) HAS EXPIRED
                   MOVE MIR-PRFL-ID-2    TO WGLOB-MSG-PARM (1)
                   MOVE 'CS25750010'     TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 1                TO WGLOB-MSG-ERROR-SW
                   GO TO 5130-XEDIT-PRFL-XPRY-DT-X
                END-IF
            END-IF.

       5130-XEDIT-PRFL-XPRY-DT-X.
           EXIT.
      /
      *-------------------------
       7000-BUILD-FROM-REC-KEYS.
      *-------------------------

           MOVE MIR-PLAN-ID              TO WPLIP-PLAN-ID.
           MOVE MIR-PRFL-ID              TO WPLIP-PRFL-ID.
           MOVE MIR-SBSDRY-CO-ID         TO WPLIP-SBSDRY-CO-ID.
           MOVE MIR-LOC-GR-ID            TO WPLIP-LOC-GR-ID.

       7000-BUILD-FROM-REC-KEYS-X.
           EXIT.
      /
      *-------------------------
       7100-BUILD-TO-REC-KEYS.
      *-------------------------

           MOVE MIR-PLAN-ID-2            TO WPLIP-PLAN-ID.
           MOVE MIR-PRFL-ID-2            TO WPLIP-PRFL-ID.
           MOVE MIR-SBSDRY-CO-ID-2       TO WPLIP-SBSDRY-CO-ID.
           MOVE MIR-LOC-GR-ID-2          TO WPLIP-LOC-GR-ID.

       7100-BUILD-TO-REC-KEYS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      /
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.
025970     SET WS-TWRK-KEY-DEFAULT   TO TRUE.
025970     SET  MIR-RETRN-OK         TO TRUE.
025970     MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.


      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  PLIP
                                '$VAR2'   BY 'PLIP'.
       COPY XCPL8090.
025970 COPY XCPS8090.
      /
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPH.
      /
       COPY CCPNPD.
      /
       COPY CCPNEDIT.
      /
       COPY CCPBIPRE.
      /
       COPY CCPNIPRO.
      /
       COPY CCPAPLIP.
       COPY CCPCPLIP.
       COPY CCPNPLIP.
       COPY CCPUPLIP.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM 'CSOM2575'                   **
      *****************************************************************
