      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2570.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2570                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE RETRIEVE FUNCTION     **
      **            FOR THE PLIP TABLE                               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020463**  6.4       INVESTOR PROFILES                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2570'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-RETRIEVE       VALUE '2570'.

       01  WS-CONSTANT-AREA.
           05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '2570'.
025970*                                      VALUE '2570'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWL8090.
      /
       COPY XCWEBLCH.
      /
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWPLIP.
       COPY CCFRPLIP.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
      /
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2570.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

      /
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2570'       TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'     TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *-------------
       2000-RETRIEVE.
      *-------------
      *
           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

      *  UPDATE TIMESTAMP FOR LOGICAL LOCKING

           PERFORM  PLIP-1000-READ-TWRK-TS
               THRU PLIP-1000-READ-TWRK-TS-X.

           IF  WPLIP-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WPLIP-KEY             TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.
      *
      *  MOVE RECORD INFORMATION TO THE MIR
      *
           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X.

       2000-RETRIEVE-X.
           EXIT.

      /
      *-----------------------
       2100-VALIDATE-KEYS.
      *-----------------------

           PERFORM  4110-EDIT-PLAN-ID
               THRU 4110-EDIT-PLAN-ID-X.

           PERFORM  4120-EDIT-PRFL-ID
               THRU 4120-EDIT-PRFL-ID-X.

           PERFORM  4130-EDIT-SBSDRY-CO-ID
               THRU 4130-EDIT-SBSDRY-CO-ID-X.

           PERFORM  4140-EDIT-LOC-GR-ID
               THRU 4140-EDIT-LOC-GR-ID-X.

       2100-VALIDATE-KEYS-X.
           EXIT.

      *------------------
       4110-EDIT-PLAN-ID.
      *------------------

           IF  MIR-PLAN-ID =  SPACES
           OR  MIR-PLAN-ID = EBLCH-BLANK-FIELD-CHAR
      *MSG: PLAN CODE MUST NOT BE BLANK
               MOVE 'CS25700001'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                     TO WGLOB-MSG-ERROR-SW
               GO TO 4110-EDIT-PLAN-ID-X
           END-IF.

      *
      *   CHECK WHETHER PLAN ID IS VALID
      *
            MOVE 'PLAN'                   TO WEDIT-ETBL-TYP-ID.
            MOVE MIR-PLAN-ID              TO WEDIT-ETBL-VALU-ID.
            MOVE WGLOB-EDIT-LANG          TO WEDIT-ETBL-LANG-CD.
            PERFORM EDIT-1000-READ
               THRU EDIT-1000-READ-X.

            IF NOT WEDIT-IO-OK
      *MSG: PLAN ID MUST BE DEFINED ON EDIT TYPE @1
               MOVE WEDIT-ETBL-TYP-ID     TO WGLOB-MSG-PARM (1)
               MOVE 'CS25700002'          TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                     TO WGLOB-MSG-ERROR-SW
               GO TO 4110-EDIT-PLAN-ID-X
            END-IF.


       4110-EDIT-PLAN-ID-X.
           EXIT.

      *-----------------------
       4120-EDIT-PRFL-ID.
      *-----------------------

           IF  MIR-PRFL-ID =  SPACES
           OR  MIR-PRFL-ID = EBLCH-BLANK-FIELD-CHAR
      *MSG: INVESTOR PROFILE ID MUST NOT BE BLANK
               MOVE 'CS25700003'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                     TO WGLOB-MSG-ERROR-SW
               GO TO 4120-EDIT-PRFL-ID-X
           END-IF.

      *
      *   CHECK WHETHER INVESTOR PROFILE ID IS VALID
      *
            MOVE 'IPROF'                  TO WEDIT-ETBL-TYP-ID.
            MOVE MIR-PRFL-ID              TO WEDIT-ETBL-VALU-ID.
            MOVE WGLOB-EDIT-LANG          TO WEDIT-ETBL-LANG-CD.
            PERFORM EDIT-1000-READ
               THRU EDIT-1000-READ-X.

            IF NOT WEDIT-IO-OK
      *MSG: INVESTOR PROFILE MUST BE DEFINED ON EDIT TYPE @1
               MOVE WEDIT-ETBL-TYP-ID     TO WGLOB-MSG-PARM (1)
               MOVE 'CS25700004'          TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                     TO WGLOB-MSG-ERROR-SW
               GO TO 4120-EDIT-PRFL-ID-X
            END-IF.

       4120-EDIT-PRFL-ID-X.
           EXIT.

      *-----------------------
       4130-EDIT-SBSDRY-CO-ID.
      *-----------------------

           IF  MIR-SBSDRY-CO-ID =  SPACES
           OR  MIR-SBSDRY-CO-ID = EBLCH-BLANK-FIELD-CHAR
      *MSG: SUB-COMPANY ID MUST NOT BE BLANK
               MOVE 'CS25700005'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                     TO WGLOB-MSG-ERROR-SW
               GO TO 4130-EDIT-SBSDRY-CO-ID-X
           END-IF.

      *
      *   CHECK WHETHER SUB-COMPANY ID IS VALID
      *
            MOVE 'SUBCO'                  TO WEDIT-ETBL-TYP-ID.
            MOVE MIR-SBSDRY-CO-ID         TO WEDIT-ETBL-VALU-ID.
            MOVE WGLOB-EDIT-LANG          TO WEDIT-ETBL-LANG-CD.
            PERFORM EDIT-1000-READ
               THRU EDIT-1000-READ-X.

            IF NOT WEDIT-IO-OK
      *MSG: SUB-COMPANY ID MUST BE DEFINED ON EDIT TYPE @1
               MOVE WEDIT-ETBL-TYP-ID     TO WGLOB-MSG-PARM (1)
               MOVE 'CS25700006'          TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                     TO WGLOB-MSG-ERROR-SW
               GO TO 4130-EDIT-SBSDRY-CO-ID-X
            END-IF.

       4130-EDIT-SBSDRY-CO-ID-X.
           EXIT.

      *-----------------------
       4140-EDIT-LOC-GR-ID.
      *-----------------------

           IF  MIR-LOC-GR-ID =  SPACES
           OR  MIR-LOC-GR-ID = EBLCH-BLANK-FIELD-CHAR
      *MSG: LOCATION GROUP MUST NOT BE BLANK
               MOVE WEDIT-ETBL-TYP-ID     TO WGLOB-MSG-PARM (1)
               MOVE 'CS25700007'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                     TO WGLOB-MSG-ERROR-SW
               GO TO  4140-EDIT-LOC-GR-ID-X
           END-IF.

      *
      *   CHECK WHETHER SUB-COMPANY ID IS VALID
      *
            MOVE 'LOCGP'                  TO WEDIT-ETBL-TYP-ID.
            MOVE MIR-LOC-GR-ID            TO WEDIT-ETBL-VALU-ID.
            MOVE WGLOB-EDIT-LANG          TO WEDIT-ETBL-LANG-CD.
            PERFORM EDIT-1000-READ
               THRU EDIT-1000-READ-X.

            IF NOT WEDIT-IO-OK
      *MSG: LOCATION GROUP MUST BE DEFINED ON EDIT TYPE @1
               MOVE WEDIT-ETBL-TYP-ID     TO WGLOB-MSG-PARM (1)
               MOVE 'CS25700008'          TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                     TO WGLOB-MSG-ERROR-SW
               GO TO  4140-EDIT-LOC-GR-ID-X
            END-IF.

       4140-EDIT-LOC-GR-ID-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE MIR-PLAN-ID               TO WPLIP-PLAN-ID.
           MOVE MIR-PRFL-ID               TO WPLIP-PRFL-ID.
           MOVE MIR-SBSDRY-CO-ID          TO WPLIP-SBSDRY-CO-ID.
           MOVE MIR-LOC-GR-ID             TO WPLIP-LOC-GR-ID.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                    TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.


      /
      *--------------------------
       9200-MOVE-RECORD-TO-MIR.
      *--------------------------

           MOVE RPLIP-PLAN-PRFL-REBAL-CD  TO MIR-PLAN-PRFL-REBAL-CD.

           MOVE RPLIP-PLAN-PRFL-CHNG-DT   TO L1640-INTERNAL-DATE.

           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X

           MOVE L1640-EXTERNAL-DATE       TO MIR-PRFLD-POL-CHNG-DT.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                    TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE        TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     SET WS-TWRK-KEY-DEFAULT          TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK                TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.


      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  PLIP
                                '$VAR2'   BY 'PLIP'.
       COPY XCPL8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
      /
025970 COPY XCPS8090.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNEDIT.
      /
       COPY CCPNPLIP.
       COPY CCPUPLIP.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM CSOM2570                        **
      *****************************************************************
