      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4923.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4923                                         **
      **  REMARKS:  THIS MODULE PROVIDES A LIST OF ACTIVE INVESTOR   **
      **            POROFILES AVAILABLE. IF FILTER FIELDS ARE        **
      **            ARE POPULATED THEN A FURTHER FILTER IS BASED ON  **
      **            PLIP.                                            **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020463**  6.4       INVESTOR PROFILES                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4923'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
      /
025970 01  WS-CONSTANT-AREA.
025970     05  WS-MAX-LIST-LINES                 PIC 9(03) VALUE 200.
025970         88  WS-MAX-LIST-LINES-DEFAULT               VALUE 200.
025970
       01  WS-WORKING-STORAGE.
           05  WS-BUSINESS-FUNCTION              PIC X(04).
               88  WS-BUSINESS-FUNCTION-LIST     VALUE '4923'.
           05  WS-SUB                            PIC S9(04) BINARY SYNC.
           05  WS-DUP-SUB                        PIC S9(04) BINARY SYNC.
025970*    05  WS-MAX-LIST-LINES                 PIC 9(03) VALUE 200.
           05  WS-PLIP-KEY-ERR-IND               PIC X(01).
               88  WS-PLIP-KEY-ERR-Y             VALUE 'Y'.
               88  WS-PLIP-KEY-ERR-N             VALUE 'N'.

      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
025970 COPY CCWWINDX.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
025970 COPY CCFRPOL.
025970 COPY CCWWCVGS.
025970
       COPY CCFWPH.
       COPY CCFRPH.
      /
       COPY CCFRPLIP.
       COPY CCFWPLIR.
      /
       COPY CCFRIPRD.
       COPY CCFWIPRE.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY CCWL3330.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM4923.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM 9990-INIT-WORKING-STORAGE
              THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUSINESS-FUNCTION.

           EVALUATE TRUE

               WHEN WS-BUSINESS-FUNCTION-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID           TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM4923'               TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------
       2000-LIST.
      *------------
      * PUT SPACES IN THE FIRST LIST ENTRY
           MOVE 1 TO WS-SUB.

           MOVE SPACES TO WEDIT-ETBL-VALU-ID.
           PERFORM IPRO-1000-EDIT-IPROF-READ
              THRU IPRO-1000-EDIT-IPROF-READ-X.

           IF WEDIT-IO-OK
               PERFORM 9200-MOVE-RECORD-TO-SCREEN
                  THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

      * IF ANY OF THE MAIN FILTER FIELDS ARE MISSING ONLY SELECT ACTIVE
      * PROFILES FROM THE IPRD TABLE

           IF MIR-POL-ISS-LOC-CD   = SPACES
           OR MIR-PLAN-ID          = SPACES
           OR MIR-POL-ISS-EFF-DT   = SPACES
           OR MIR-POL-ISS-EFF-DT   = WWKDT-ZERO-DT
           OR MIR-POL-APP-SIGN-DT  = SPACES
           OR MIR-POL-APP-SIGN-DT  = WWKDT-ZERO-DT

               PERFORM 3000-FILTER-ACTV-ONLY
                  THRU 3000-FILTER-ACTV-ONLY-X
               GO TO 2000-LIST-X
           END-IF.

      * USING THE FILTER FIELDS BUILD THE KEY FOR THE PLIP BROWSE

           PERFORM 7000-BUILD-PLIP-KEY
              THRU 7000-BUILD-PLIP-KEY-X.

      * IF THE BUILD OF THE KEY FAILS NEED TO BUILD FROM ACTIVE
      * PROFILES ON THE IPRD TABLE

           IF WS-PLIP-KEY-ERR-Y
               PERFORM 3000-FILTER-ACTV-ONLY
                  THRU 3000-FILTER-ACTV-ONLY-X
               GO TO 2000-LIST-X
           END-IF.

           PERFORM PLIR-4000-BROWSE-INDEX
              THRU PLIR-4000-BROWSE-INDEX-X.

           PERFORM PLIR-5000-READ-NEXT-INDEX
              THRU PLIR-5000-READ-NEXT-INDEX-X.

           IF WPLIR-IO-OK
               PERFORM 2100-POPULATE-LIST
                  THRU 2100-POPULATE-LIST-X
             UNTIL WPLIR-IO-EOF
             OR WS-SUB > WS-MAX-LIST-LINES
           END-IF.

           PERFORM PLIR-6000-END-BROWSE-INDEX
              THRU PLIR-6000-END-BROWSE-INDEX-X.


       2000-LIST-X.
           EXIT.
      /
      *-----------------
       2100-POPULATE-LIST.
      *-----------------

           MOVE RPLIP-PRFL-ID        TO WEDIT-ETBL-VALU-ID.
           PERFORM IPRO-1000-EDIT-IPROF-READ
              THRU IPRO-1000-EDIT-IPROF-READ-X.

           IF WEDIT-IO-OK
               PERFORM 9200-MOVE-RECORD-TO-SCREEN
                  THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           PERFORM PLIR-5000-READ-NEXT-INDEX
              THRU PLIR-5000-READ-NEXT-INDEX-X.

       2100-POPULATE-LIST-X.
           EXIT.
      /
      *--------------------
       3000-FILTER-ACTV-ONLY.
      *--------------------

           MOVE SPACES TO   WIPRE-KEY.

           SET WIPRE-PRFLD-STAT-ACTV TO TRUE.

           MOVE WIPRE-KEY   TO WIPRE-ENDBR-KEY.
           MOVE HIGH-VALUES TO WIPRE-ENDBR-PRFL-ID.

           PERFORM IPRE-4000-BROWSE-INDEX
              THRU IPRE-4000-BROWSE-INDEX-X.

           PERFORM IPRE-5000-READ-NEXT-INDEX
              THRU IPRE-5000-READ-NEXT-INDEX-X.

           IF WIPRE-IO-OK
               PERFORM 3100-POPULATE-LIST
                  THRU 3100-POPULATE-LIST-X
             UNTIL WIPRE-IO-EOF
             OR WS-SUB > WS-MAX-LIST-LINES
           END-IF.

           PERFORM IPRE-6000-END-BROWSE-INDEX
              THRU IPRE-6000-END-BROWSE-INDEX-X.

       3000-FILTER-ACTV-ONLY-X.
           EXIT.
      /
      *--------------------
       3100-POPULATE-LIST.
      *--------------------

           MOVE RIPRD-PRFL-ID        TO WEDIT-ETBL-VALU-ID.
           PERFORM IPRO-1000-EDIT-IPROF-READ
              THRU IPRO-1000-EDIT-IPROF-READ-X.

           IF WEDIT-IO-OK
               PERFORM 9200-MOVE-RECORD-TO-SCREEN
                  THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           PERFORM IPRE-5000-READ-NEXT-INDEX
              THRU IPRE-5000-READ-NEXT-INDEX-X.

       3100-POPULATE-LIST-X.
           EXIT.
      /
      *--------------------
       7000-BUILD-PLIP-KEY.
      *--------------------

           MOVE LOW-VALUES             TO WPLIR-KEY.

           MOVE MIR-PLAN-ID            TO WPH-PLAN-ID.

           PERFORM PH-1000-READ
              THRU PH-1000-READ-X.

      * IF THE PLAN IS NOT ON PH CAN'T BE VALID SO EXIT
           IF NOT WPH-IO-OK
               SET WS-PLIP-KEY-ERR-Y   TO TRUE
               GO TO 7000-BUILD-PLIP-KEY-X
           END-IF.

           MOVE MIR-PLAN-ID            TO WPLIR-PLAN-ID.

           MOVE MIR-CLI-CRNT-LOC-CD    TO L3330-POL-CRNT-LOC-CD.
           MOVE MIR-POL-ISS-LOC-CD     TO L3330-POL-ISS-LOC-CD.
           MOVE RPH-LOC-GR-COLCT-ID    TO L3330-LOC-GR-COLCT-ID.
           MOVE MIR-POL-ISS-EFF-DT     TO L3330-POL-ISS-EFF-DT.
           MOVE MIR-POL-APP-SIGN-DT    TO L3330-POL-APP-SIGN-DT.
           MOVE MIR-POL-ISS-EFF-DT     TO L3330-CVG-ISS-EFF-DT.

      * IF THE MIR-CLI-CRNT-LOC-CD IS SPACES NEED TO DO ISSUE LOCATION
           IF  MIR-CLI-CRNT-LOC-CD = SPACES
               SET L3330-LOC-GR-TYP-IPRF   TO TRUE
           ELSE
      * CURRENTLY ONLY ISSUE LOCATION HAS BEEN SET UP
               SET L3330-LOC-GR-TYP-IPRF   TO TRUE
           END-IF.

           PERFORM  3330-1000-GET-LOC-GROUP
               THRU 3330-1000-GET-LOC-GROUP-X.

           IF  L3330-RETRN-OK
               MOVE L3330-LOC-GR-ID    TO WPLIR-LOC-GR-ID
           ELSE
               SET WS-PLIP-KEY-ERR-Y   TO TRUE
               GO TO 7000-BUILD-PLIP-KEY-X
           END-IF.

           MOVE MIR-SBSDRY-CO-ID       TO WPLIR-SBSDRY-CO-ID.

           MOVE WPLIR-KEY              TO WPLIR-ENDBR-KEY.
           MOVE HIGH-VALUES            TO WPLIR-ENDBR-PRFL-ID.

       7000-BUILD-PLIP-KEY-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE REDIT-ETBL-VALU-ID  TO MIR-DV-SBOX-CD-T (WS-SUB).
           MOVE REDIT-ETBL-DESC-TXT TO MIR-DV-SBOX-DESC-TXT-T (WS-SUB).

           ADD 1 TO WS-SUB.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  3330-0000-INIT-PARM-INFO
025970         THRU 3330-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE            L3330-PARM-INFO.
           INITIALIZE            WGLOB-MSG-ERROR-SW.
           INITIALIZE            WS-WORKING-STORAGE.
025970     INITIALIZE WWKDT-WORK-FIELDS.
           SET WS-PLIP-KEY-ERR-N TO TRUE.
025970     SET  WS-MAX-LIST-LINES-DEFAULT   TO TRUE.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970     MOVE MIR-BUS-FCN-ID   TO WS-BUSINESS-FUNCTION.
025970*    MOVE 200              TO WS-MAX-LIST-LINES.
           MOVE SPACES           TO MIR-DV-SBOX-CD-G.
           MOVE SPACES           TO MIR-DV-SBOX-DESC-TXT-G.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
025970 COPY CCPPMIDT.
025970
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY CCPL3330.
025970 COPY CCPS3330.
      /
       COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBIPRE.
      /
       COPY CCPEIPRO.
       COPY CCPNEDIT.
      /
       COPY CCPNPH.
      /
       COPY CCPBPLIR.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM4923                     **
      *****************************************************************
