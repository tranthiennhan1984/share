      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM2250.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM2250                                         **
      **  REMARKS:  TOTH - MAINTAIN INSURANCE (HEALTH) TOTALS.       **
      **            THIS MODULE PROVIDES INQUIRY AND UPDATE          **
      **            FUNCTIONS FOR UNDERWRITING SPECIFIC INFORMATION  **
      **            - TOTAL HEALTH INSURANCE INFORCE FOR THIS CLIENT.**
      **            THIS IS ACCOMPLISHED VIA THE TOTH TRANSACTION    **
      **            WHICH USES INFORMATION FROM TWO DIFERENT TABLES  **
      **            - APPF (INSURED FIXED INFORMATION) AND CLIO      **
      **            (CLIENT OTHER INSURANCE INFORMATION)             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
556874**  5.5       ADD NEW WARNING MESSAGE                          **
557658**  5.5       YEAR - 2000                                      **
557659**  5.5       DATA ARCHITECTURE MODIFICATIONS                  **
557660**  5.5       CODE CLEANUP                                     **
557698**  5.5       MIXED-CASE SUPPORT                               **
557708**  5.5       CICS ABEND HANDLING                              **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
012624**  6.0       SECURITY                                         **
013578**  6.0       MIR RENAME ; 3270 REMOVAL                        **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       MODIFICATIONS FOR FORMAT FULL NAME               **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016387**  6.2       REMOVE CLIENT CONSOLIDATION SUPPORT              **
016537**  6.2       CODE CLEAN UP                                    **
017313**  6.2       RE-ORGANIZE OTHER HEALTH INSURANCE UPDATE        **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM2250'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-COUNTERS.
           05  WS-SUB                       PIC 9(01).

       01  WS-SWITCHES.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '2250' '2252'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '2250'.
               88  WS-BUS-FCN-UPDATE        VALUE '2252'.
           05  WS-EDIT-OK-SW                PIC X(01).
               88  WS-EDIT-OK               VALUE '0'.
               88  WS-CROSS-EDIT-ERR        VALUE '2'.
           05  WS-TEST-HTYPE                PIC X(01).
               88  WS-HTYPE-OK              VALUE 'I' 'O'.
           05  WS-TEST-YES-NO               PIC X(01).
               88  WS-YES-NO-OK             VALUE 'Y' 'N'.
           05  WS-TEST-HOIIP                PIC X(01).
               88  WS-HOIIP-OK              VALUE 'I' 'P'.
           05  WS-TEST-HOIBP                PIC X(01).
               88  WS-HOIBP-OK              VALUE 'B' 'P'.
           05  WS-HEALTH-DATA-ENTERED-SW    PIC X(01).
               88  WS-HEALTH-DATA-ENTERED   VALUE 'Y'.
           05  WS-CLIO-DATA-SW              PIC X(01).
               88  WS-CLIO-DATA-TO-WRITE    VALUE 'Y'.
               88  WS-CLIO-NO-DATA-TO-WRITE VALUE ' '.

      ** A VALUE OF 'D' IN THIS FIELD INDICATES THAT THE RECORD IS
      ** TO BE DELETED BECAUSE THE USER HAS ENTERED AN '**' IN THE
      ** COMPANY NAME TO REMOVE THE ENTIRE LINE OF INFO

       01  WS-PGM-WORK-AREA.
           05  WS-PIC-2-0                   PIC 9(02).
           05  WS-PIC-4-0                   PIC 9(04).
008455*    05  WS-PIC-5-0                   PIC 9(05).
008455*    05  WS-PIC-6-0                   PIC 9(06).
008455*    05  WS-PIC-9-0                   PIC 9(09).
025970*    05  WS-MAX-WRITE                 PIC 9(02) VALUE 6.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '2250'.
025970/
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                VALUE '2250'.
025970     05  WS-MAX-WRITE                 PIC 9(02).
025970         88  WS-DEFAULT-MAX-WRITE               VALUE 6.
      /
016537*COPY XCWWWKDT.
014221 COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      /
       COPY XCWEBLCH.

       COPY CCWL0620.
028298 COPY CCWL2626.

       COPY CCWL5600.

       COPY NCWL5850.
       COPY NCFWAPPF.
       COPY NCFRAPPF.
014221 COPY CCFWCLI.
014221 COPY CCFRCLI.
       COPY CCFWEDIT.
       COPY CCFREDIT.
       COPY NCWL2437.
       COPY XCWL0280.
016537*COPY XCWL0015.
       COPY XCWLDTLK.
       COPY XCWL1640.
008455 COPY XCWL0290.
014221 COPY XCWL8090.

007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      /
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM2250.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-TRANSACTIONS
               THRU 2000-PROCESS-TRANSACTIONS-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.


026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      ***************************
       2000-PROCESS-TRANSACTIONS.
      ***************************

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID    TO WS-BUS-FCN-ID.
025970*    SET MIR-RETRN-OK       TO TRUE.

           IF  MIR-DV-PRCES-STATE-CD = '1'
           OR  WS-BUS-FCN-RETRIEVE
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
557660     END-IF.

           PERFORM  2100-VALIDATE-CLIENT
               THRU 2100-VALIDATE-CLIENT-X.

           IF  L5600-CNFD-ACCS-RESTRICTED
           OR  L2437-RETRN-CLI-NOT-FOUND
               GO TO 2000-PROCESS-TRANSACTIONS-X
           END-IF.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST
                                  TO TRUE
           END-EVALUATE.

       2000-PROCESS-TRANSACTIONS-X.
           EXIT.
      /
      **********************
       2100-VALIDATE-CLIENT.
      **********************

           MOVE MIR-CLI-ID        TO L2437-CLI-ID.

           PERFORM  2437-1000-OBTAIN-CLI-INFO
               THRU 2437-1000-OBTAIN-CLI-INFO-X.

           IF  L2437-RETRN-CLI-NOT-FOUND
      *** MSG (S) RECORD (@1) NOT FOUND
               MOVE 'XS00000001'  TO WGLOB-MSG-REF-INFO
               MOVE L2437-CLI-ID  TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2100-VALIDATE-CLIENT-X
557660     END-IF.

           MOVE L2437-CLI-SEX-CD  TO L0620-CLI-SEX-CD.
557698*    MOVE L2437-CLI-CO-NM   TO L0620-CLI-CO-NM.
557698*    MOVE L2437-CLI-GIV-NM  TO L0620-CLI-GIV-NM.
557698*    MOVE L2437-CLI-SUR-NM  TO L0620-CLI-SUR-NM.
557698     MOVE L2437-CLI-ENTR-CO-NM
                                  TO L0620-CLI-CO-NM.
557698     MOVE L2437-CLI-ENTR-GIV-NM
                                  TO L0620-CLI-GIV-NM.
557698     MOVE L2437-CLI-ENTR-SUR-NM
                                  TO L0620-CLI-SUR-NM.

014653     MOVE L2437-CLI-MID-INIT-NM
014653                            TO L0620-CLI-MID-INIT-NM.
014653     MOVE L2437-CLI-SFX-NM  TO L0620-CLI-SFX-NM.
014653
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
      *
           MOVE L0620-SCREEN-NAME TO MIR-DV-INSRD-CLI-NM.

           PERFORM  5600-0000-INIT-PARM-INFO
               THRU 5600-0000-INIT-PARM-INFO-X.
           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.
           MOVE L2437-CLI-ID      TO L5600-CLI-ID.
016387*    SET L5600-GEN-CNSLDT-MSG-WARN
016387*                           TO TRUE.

           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.

       2100-VALIDATE-CLIENT-X.
           EXIT.
      /
      **************
       3000-PROCESS-RETRIEVE.
      **************

           PERFORM  8000-BUILD-APPF-KEY
               THRU 8000-BUILD-APPF-KEY-X.

014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

           PERFORM  APPF-1000-READ
               THRU APPF-1000-READ-X.

           IF NOT WAPPF-IO-OK
      *** MSG (S) NO DETAILS FOUND (@1)
               MOVE 'XS00000118'  TO WGLOB-MSG-REF-INFO
               MOVE WAPPF-KEY     TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-RETRIEVE-X
           ELSE
               PERFORM  8200-BUILD-CLIO-KEY
                   THRU 8200-BUILD-CLIO-KEY-X
               PERFORM  5850-1000-LOAD-CLIO-ARRAY
                   THRU 5850-1000-LOAD-CLIO-ARRAY-X
557660     END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

      *** MSG (I) INQUIRE COMPLETED - CONTINUE
           MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      **********
       5000-PROCESS-UPDATE.
      **********

017313*    IF  MIR-DV-PRCES-STATE-CD = '1'
017313*        PERFORM  5100-PROCESS-UPDATE-PART-1
017313*            THRU 5100-PROCESS-UPDATE-PART-1-X
017313*    ELSE
017313*        PERFORM  5200-PROCESS-UPDATE-PART-2
017313*            THRU 5200-PROCESS-UPDATE-PART-2-X
017313*    END-IF.

017313     IF  L5600-CCAS-ACCS-RESTRICTED
017313         GO TO 5000-PROCESS-UPDATE-X
017313     END-IF.

017313     PERFORM  8000-BUILD-APPF-KEY
017313         THRU 8000-BUILD-APPF-KEY-X.

017313*  CHECK IF RECORD EXISTS

017313     PERFORM  APPF-1000-READ
017313         THRU APPF-1000-READ-X.

017313     INITIALIZE  L5850-PARM-INFO.

017313     IF  WAPPF-IO-OK
017313         PERFORM  8200-BUILD-CLIO-KEY
017313             THRU 8200-BUILD-CLIO-KEY-X
017313         PERFORM  5850-1000-LOAD-CLIO-ARRAY
017313             THRU 5850-1000-LOAD-CLIO-ARRAY-X
017313     ELSE
017313         PERFORM  APPF-1000-CREATE
017313             THRU APPF-1000-CREATE-X
017313         PERFORM  5120-DEFAULT-PREGNANCY-IND
017313             THRU 5120-DEFAULT-PREGNANCY-IND-X
017313         PERFORM  APPF-1000-WRITE
017313             THRU APPF-1000-WRITE-X
014221         PERFORM  CLI-1000-READ-TWRK-TS
014221             THRU CLI-1000-READ-TWRK-TS-X
017313     END-IF.

017313     PERFORM  8000-BUILD-APPF-KEY
017313         THRU 8000-BUILD-APPF-KEY-X.

014221     PERFORM  CLI-2000-UPDATE-TWRK-TS
014221         THRU CLI-2000-UPDATE-TWRK-TS-X.

014221     IF  WCLI-IO-NOT-FOUND
014221*MSG:  'CLIENT NOT ON CLIENT FILE'
014221         MOVE 'XS00000058'       TO WGLOB-MSG-REF-INFO
014221         MOVE WCLI-CLI-ID        TO WGLOB-MSG-PARM (01)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'CLI'              TO WGLOB-MSG-PARM (01)
014221         MOVE WCLI-CLI-ID        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

017313     PERFORM  APPF-1000-READ-FOR-UPDATE
017313         THRU APPF-1000-READ-FOR-UPDATE-X.

017313     IF  WAPPF-IO-OK
017313         PERFORM  8200-BUILD-CLIO-KEY
017313             THRU 8200-BUILD-CLIO-KEY-X
017313         PERFORM  5850-1000-LOAD-CLIO-ARRAY
017313             THRU 5850-1000-LOAD-CLIO-ARRAY-X
017313     ELSE
017313* MSG: (I) LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS
017313         MOVE 'XS00000016'        TO WGLOB-MSG-REF-INFO
017313         MOVE WAPPF-KEY           TO WGLOB-MSG-PARM (1)
017313         PERFORM  0260-1000-GENERATE-MESSAGE
017313             THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  CLI-3000-UNLOCK
014221             THRU CLI-3000-UNLOCK-X
017313         GO TO 5000-PROCESS-UPDATE-X
017313     END-IF.

017313     PERFORM  5300-EDIT-FIELDS
017313         THRU 5300-EDIT-FIELDS-X.

017313     PERFORM  APPF-2000-REWRITE
017313         THRU APPF-2000-REWRITE-X.

014221     PERFORM  CLI-2000-REWRITE
014221         THRU CLI-2000-REWRITE-X.
014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.


017313*  UPDATE THE LAST UPD DATE ON SCREEN

017313     PERFORM  5210-CHECK-FOR-DATA-TO-WRITE
017313         THRU 5210-CHECK-FOR-DATA-TO-WRITE-X
017313         VARYING WS-SUB FROM +1 BY +1
017313         UNTIL WS-SUB > WS-MAX-WRITE

017313     IF  WS-CLIO-DATA-TO-WRITE
017313         PERFORM  5850-2000-UPDATE-CLIO
017313             THRU 5850-2000-UPDATE-CLIO-X
017313             VARYING L5850-SUB FROM +1 BY +1
017313             UNTIL L5850-SUB > WS-MAX-WRITE
017313     END-IF.

017313     MOVE RAPPF-PREV-UPDT-TS TO WWKDT-INT-TS.
017313     MOVE WWKDT-INT-TS            TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

017313     MOVE L1640-EXTERNAL-DATE     TO MIR-DV-PREV-UPDT-DT.

017313     IF  WS-EDIT-OK
017313* MSG : (I) MAINTENANCE COMPLETED - CONTINUE
017313         MOVE 'XS00000007'        TO WGLOB-MSG-REF-INFO
017313         PERFORM  0260-1000-GENERATE-MESSAGE
017313             THRU 0260-1000-GENERATE-MESSAGE-X
017313     ELSE
017313* MSG (I) RECORD UPDATED
017313         MOVE 'XS00000008'        TO WGLOB-MSG-REF-INFO
017313         PERFORM  0260-1000-GENERATE-MESSAGE
017313             THRU 0260-1000-GENERATE-MESSAGE-X
017313     END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
017313*****************
017313*5100-PROCESS-UPDATE-PART-1.
017313*****************
017313*
017313*    IF  L5600-CCAS-ACCS-RESTRICTED
017313*        GO TO 5100-PROCESS-UPDATE-PART-1-X
017313*    END-IF.
017313*
017313*    PERFORM  8000-BUILD-APPF-KEY
017313*        THRU 8000-BUILD-APPF-KEY-X.
017313*
017313*    PERFORM  APPF-1000-READ
017313*        THRU APPF-1000-READ-X.
017313*
017313*    INITIALIZE L5850-PARM-INFO.
017313*
017313*    IF WAPPF-IO-OK
017313*        PERFORM 8200-BUILD-CLIO-KEY
017313*            THRU 8200-BUILD-CLIO-KEY-X
017313*        PERFORM  5850-1000-LOAD-CLIO-ARRAY
017313*            THRU 5850-1000-LOAD-CLIO-ARRAY-X
017313*    ELSE
017313*        PERFORM  APPF-1000-CREATE
017313*            THRU APPF-1000-CREATE-X
017313*        PERFORM  5120-DEFAULT-PREGNANCY-IND
017313*            THRU 5120-DEFAULT-PREGNANCY-IND-X
017313*        PERFORM  APPF-1000-WRITE
017313*            THRU APPF-1000-WRITE-X
017313*    END-IF.
017313*
017313*    PERFORM  9200-MOVE-RECORD-TO-SCREEN
017313*        THRU 9200-MOVE-RECORD-TO-SCREEN-X.
017313*
017313*5100-PROCESS-UPDATE-PART-1-X.
017313*    EXIT.
017313*
017313****************************
       5120-DEFAULT-PREGNANCY-IND.
      ****************************

           IF  L2437-CLI-SEX-CD NOT = 'F'
               MOVE 'N'           TO RAPPF-CLI-PREG-IND
557660     END-IF.

       5120-DEFAULT-PREGNANCY-IND-X.
           EXIT.
      /
017313*****************
017313*5200-PROCESS-UPDATE-PART-2.
017313*****************
017313*
017313*    IF  L5600-CCAS-ACCS-RESTRICTED
017313*        GO TO 5200-PROCESS-UPDATE-PART-2-X
017313*    END-IF.
017313*
017313*    PERFORM  8000-BUILD-APPF-KEY
017313*        THRU 8000-BUILD-APPF-KEY-X.
017313*
017313*    PERFORM  APPF-1000-READ-FOR-UPDATE
017313*        THRU APPF-1000-READ-FOR-UPDATE-X.
017313*
017313*    IF WAPPF-IO-OK
017313*        PERFORM  8200-BUILD-CLIO-KEY
017313*            THRU 8200-BUILD-CLIO-KEY-X
017313*        PERFORM  5850-1000-LOAD-CLIO-ARRAY
017313*            THRU 5850-1000-LOAD-CLIO-ARRAY-X
017313*    ELSE
017313*** MSG (I) LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS
017313*        MOVE 'XS00000016'  TO WGLOB-MSG-REF-INFO
017313*        MOVE WAPPF-KEY     TO WGLOB-MSG-PARM (1)
017313*        PERFORM  0260-1000-GENERATE-MESSAGE
017313*            THRU 0260-1000-GENERATE-MESSAGE-X
017313*        GO TO 5200-PROCESS-UPDATE-PART-2-X
017313*    END-IF.
017313*
017313*    PERFORM  5300-EDIT-FIELDS
017313*        THRU 5300-EDIT-FIELDS-X.
017313*
017313*    PERFORM  APPF-2000-REWRITE
017313*        THRU APPF-2000-REWRITE-X.
017313*
017313* UPDATE THE LAST UPD DATE ON THE SCREEN
017313*
017313*    PERFORM  5210-CHECK-FOR-DATA-TO-WRITE
017313*        THRU 5210-CHECK-FOR-DATA-TO-WRITE-X
017313*        VARYING WS-SUB FROM 1 BY 1
017313*        UNTIL WS-SUB > 6.
017313*
017313*    IF WS-CLIO-DATA-TO-WRITE
017313*        PERFORM  5850-2000-UPDATE-CLIO
017313*            THRU 5850-2000-UPDATE-CLIO-X
017313*            VARYING L5850-SUB FROM 1 BY 1
017313*              UNTIL L5850-SUB > 6
017313*    END-IF.
014221*    MOVE RAPPF-PREV-UPDT-DT
014221*    MOVE RAPPF-PREV-UPDT-TS
014221*                           TO L1640-INTERNAL-DATE.
017313*    MOVE RAPPF-PREV-UPDT-TS
017313*                           TO WWKDT-INT-TS.
017313*    MOVE WWKDT-INT-TS      TO L1640-INTERNAL-DATE.
017313*    PERFORM  1640-2000-INTERNAL-TO-EXT
017313*        THRU 1640-2000-INTERNAL-TO-EXT-X.
017313*    MOVE L1640-EXTERNAL-DATE
017313*                           TO MIR-PREV-UPDT-DT.
017313*                           TO MIR-DV-PREV-UPDT-DT.
017313*
017313*    IF WS-EDIT-OK
017313*** MSG (I) MAINTENANCE COMPLETED - CONTINUE
017313*        MOVE 'XS00000007'  TO WGLOB-MSG-REF-INFO
017313*        PERFORM  0260-1000-GENERATE-MESSAGE
017313*            THRU 0260-1000-GENERATE-MESSAGE-X
017313*    ELSE
017313*** MSG (I) RECORD UPDATED
017313*        MOVE 'XS00000008'  TO WGLOB-MSG-REF-INFO
017313*        PERFORM  0260-1000-GENERATE-MESSAGE
017313*            THRU 0260-1000-GENERATE-MESSAGE-X
017313*    END-IF.
017313*
017313*5200-PROCESS-UPDATE-PART-2-X.
017313*    EXIT.
      /
       5210-CHECK-FOR-DATA-TO-WRITE.

           IF MIR-CLI-OINS-CO-NM-T (WS-SUB) NOT = SPACES
           OR MIR-OINS-INFC-PEND-CD-T (WS-SUB) NOT = SPACES
           OR MIR-OINS-THIS-CO-IND-T (WS-SUB) NOT = SPACES
           OR MIR-OINS-BUS-PERS-CD-T (WS-SUB) NOT = SPACES
           OR MIR-DI-OINS-INS-TYP-CD-T (WS-SUB) NOT = SPACES
           OR MIR-CLI-OINS-ISS-YR-T (WS-SUB) > ZERO
           OR MIR-CLI-OINS-TOT-AMT-T (WS-SUB) > ZERO
           OR MIR-CLI-OINS-ADB-AMT-T (WS-SUB) > ZERO
           OR MIR-DI-OINS-EP-DUR-T (WS-SUB) NOT = SPACES
           OR MIR-DI-OINS-BP-DUR-T (WS-SUB) NOT = SPACES
           OR MIR-DI-OINS-TAXBL-CD-T (WS-SUB) NOT = SPACES
           OR MIR-DI-OINS-REPL-IND-T (WS-SUB) NOT = SPACES
               MOVE 'Y'           TO WS-CLIO-DATA-SW
               MOVE 'Y'           TO L5850-CLIO-DATA-THIS-LINE (WS-SUB)
557660     END-IF.
      *
       5210-CHECK-FOR-DATA-TO-WRITE-X.
557660     EXIT.
      /
      ******************
       5300-EDIT-FIELDS.
      ******************

           MOVE '0'               TO WS-EDIT-OK-SW.

           PERFORM  5310-EDIT-HOIPI
               THRU 5310-EDIT-HOIPI-X.

           PERFORM  5320-EDIT-INS-DETAIL-ARRAY
               THRU 5320-EDIT-INS-DETAIL-ARRAY-X
                    VARYING WS-SUB FROM 1 BY 1
                    UNTIL WS-SUB > 6.

           PERFORM  5450-EDIT-HRFIN
               THRU 5450-EDIT-HRFIN-X.

           PERFORM  5460-EDIT-H-REFUSED
               THRU 5460-EDIT-H-REFUSED-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > 2.

           PERFORM  5510-EDIT-ELGIN
               THRU 5510-EDIT-ELGIN-X.

           PERFORM  5520-EDIT-ELGYR
               THRU 5520-EDIT-ELGYR-X.

           PERFORM  5530-EDIT-ELGMN
               THRU 5530-EDIT-ELGMN-X.

           PERFORM  5540-EDIT-ELGAM
               THRU 5540-EDIT-ELGAM-X.

           PERFORM  5550-EDIT-ELGEP
               THRU 5550-EDIT-ELGEP-X.

           PERFORM  5560-EDIT-ELGBP
               THRU 5560-EDIT-ELGBP-X.

           MOVE 'N'               TO WS-HEALTH-DATA-ENTERED-SW.

           PERFORM  5570-OINS-CROSS-EDITS
               THRU 5570-OINS-CROSS-EDITS-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > 6.

           IF  MIR-CLI-DI-OINS-IND = 'Y'
           AND NOT WS-HEALTH-DATA-ENTERED
      *** MSG (S) OTHER HEALTH INS IND IS 'Y', REQUIRE DETAILS
               MOVE 'NS22500001'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WS-EDIT-OK
                   MOVE '2'       TO WS-EDIT-OK-SW
034802*        ELSE
034802*            NEXT SENTENCE
557660         END-IF
           ELSE
               IF  MIR-CLI-DI-OINS-IND = 'N'
               AND WS-HEALTH-DATA-ENTERED
      *** MSG (S) OTHER HEALTH INS IND IS 'N', DETAILS NOT ALLOWED
                   MOVE 'NS22500002'
                                  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   IF WS-EDIT-OK
                       MOVE '2'   TO WS-EDIT-OK-SW
557660             END-IF
557660         END-IF
557660     END-IF.

           MOVE 'N'               TO WS-HEALTH-DATA-ENTERED-SW.

           PERFORM 5580-XEDIT-H-REFUSED
               THRU 5580-XEDIT-H-REFUSED-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > 2.

           IF  MIR-DI-INS-REFUS-IND = 'Y'
           AND NOT WS-HEALTH-DATA-ENTERED
      *** MSG (S) REFUSED HEALTH INS IND IS 'Y', REQUIRE DETAILS
               MOVE 'NS22500003'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WS-EDIT-OK
                   MOVE '2'       TO WS-EDIT-OK-SW
034802*        ELSE
034802*            NEXT SENTENCE
557660         END-IF
           ELSE
               IF  MIR-DI-INS-REFUS-IND = 'N'
               AND WS-HEALTH-DATA-ENTERED
      *** MSG (S) REFUSED HEALTH INS IND IS 'N', DETAILS NOT ALLOWED
                   MOVE 'NS22500004'
                                  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   IF WS-EDIT-OK
                       MOVE '2'   TO WS-EDIT-OK-SW
557660             END-IF
557660         END-IF
557660     END-IF.

           PERFORM 5590-XEDIT-ELIGIBLE
               THRU 5590-XEDIT-ELIGIBLE-X.

       5300-EDIT-FIELDS-X.
           EXIT.
      /
       5310-EDIT-HOIPI.

           IF MIR-CLI-DI-OINS-IND = SPACES
               MOVE RAPPF-CLI-DI-OINS-IND
                                  TO MIR-CLI-DI-OINS-IND
               GO TO 5310-EDIT-HOIPI-X
557660     END-IF.

           IF MIR-CLI-DI-OINS-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE         TO RAPPF-CLI-DI-OINS-IND
               MOVE SPACE         TO MIR-CLI-DI-OINS-IND
               GO TO 5310-EDIT-HOIPI-X
557660     END-IF.

           MOVE MIR-CLI-DI-OINS-IND
                                  TO WS-TEST-YES-NO.

           IF WS-YES-NO-OK
               MOVE MIR-CLI-DI-OINS-IND
                                  TO RAPPF-CLI-DI-OINS-IND
           ELSE
      *** MSG (S) OTHER INS INFORCE/PENDING MUST BE BLANK, Y OR N
               MOVE 'NS22500005'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5310-EDIT-HOIPI-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT OTHER INSURANCE DETAIL INFORMATION
      *****************************************************************
       5320-EDIT-INS-DETAIL-ARRAY.

           IF MIR-CLI-OINS-CO-NM-T (WS-SUB) = EBLCH-BLANK-FIELD-GROUP
               MOVE 'Y'           TO WS-CLIO-DATA-SW
               MOVE 'D'           TO L5850-CLIO-DATA-THIS-LINE (WS-SUB)
                MOVE EBLCH-BLANK-FIELD-CHAR
                                  TO MIR-CLI-OINS-CO-NM-T (WS-SUB)
                MOVE EBLCH-BLANK-FIELD-CHAR
                                  TO MIR-OINS-INFC-PEND-CD-T (WS-SUB)
                MOVE EBLCH-BLANK-FIELD-CHAR
                                  TO MIR-OINS-THIS-CO-IND-T (WS-SUB)
                MOVE EBLCH-BLANK-FIELD-CHAR
                                  TO MIR-OINS-BUS-PERS-CD-T (WS-SUB)
                MOVE EBLCH-BLANK-FIELD-CHAR
                                  TO MIR-DI-OINS-INS-TYP-CD-T (WS-SUB)
                MOVE EBLCH-BLANK-FIELD-CHAR
                                  TO MIR-CLI-OINS-ISS-YR-T (WS-SUB)
                MOVE EBLCH-BLANK-FIELD-CHAR
                                  TO MIR-CLI-OINS-TOT-AMT-T (WS-SUB)
                MOVE EBLCH-BLANK-FIELD-CHAR
                                  TO MIR-CLI-OINS-ADB-AMT-T (WS-SUB)
                MOVE EBLCH-BLANK-FIELD-CHAR
                                  TO MIR-DI-OINS-EP-DUR-T (WS-SUB)
                MOVE EBLCH-BLANK-FIELD-CHAR
                                  TO MIR-DI-OINS-BP-DUR-T (WS-SUB)
                MOVE EBLCH-BLANK-FIELD-CHAR
                                  TO MIR-DI-OINS-TAXBL-CD-T (WS-SUB)
                MOVE EBLCH-BLANK-FIELD-CHAR
                                  TO MIR-DI-OINS-REPL-IND-T (WS-SUB)
556874     ELSE
556874         IF MIR-CLI-OINS-CO-NM-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
556874* MSG: WARNING: USE ** TO ENSURE ALL FIELDS ARE RESET
556874            MOVE 'NS22500035'
                                  TO WGLOB-MSG-REF-INFO
556874            PERFORM 0260-1000-GENERATE-MESSAGE
556874               THRU 0260-1000-GENERATE-MESSAGE-X
556874         END-IF
557660     END-IF.

           PERFORM  5330-EDIT-HOICO
               THRU 5330-EDIT-HOICO-X.

           PERFORM  5340-EDIT-HOIIP
               THRU 5340-EDIT-HOIIP-X.

           PERFORM  5350-EDIT-HOICI
               THRU 5350-EDIT-HOICI-X.

           PERFORM  5360-EDIT-HOIBP
               THRU 5360-EDIT-HOIBP-X.

           PERFORM  5370-EDIT-HTYPE
               THRU 5370-EDIT-HTYPE-X.

           PERFORM  5380-EDIT-HYRIS
               THRU 5380-EDIT-HYRIS-X.

           PERFORM  5390-EDIT-HFACE
               THRU 5390-EDIT-HFACE-X.

           PERFORM  5400-EDIT-ADDAM
               THRU 5400-EDIT-ADDAM-X.

           PERFORM  5410-EDIT-HEP
               THRU 5410-EDIT-HEP-X.

           PERFORM  5420-EDIT-HBP
               THRU 5420-EDIT-HBP-X.

           PERFORM  5430-EDIT-TAXIN
               THRU 5430-EDIT-TAXIN-X.

           PERFORM  5440-EDIT-REPIN
               THRU 5440-EDIT-REPIN-X.

       5320-EDIT-INS-DETAIL-ARRAY-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT COMPANY NAME
      *****************************************************************

       5330-EDIT-HOICO.

           IF MIR-CLI-OINS-CO-NM-T (WS-SUB) = SPACES
               MOVE L5850-CLI-OINS-CO-NM (WS-SUB)
                                  TO MIR-CLI-OINS-CO-NM-T (WS-SUB)
               GO TO 5330-EDIT-HOICO-X
557660     END-IF.

           IF MIR-CLI-OINS-CO-NM-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES        TO MIR-CLI-OINS-CO-NM-T (WS-SUB)
               MOVE SPACES        TO L5850-CLI-OINS-CO-NM (WS-SUB)
               GO TO 5330-EDIT-HOICO-X
557660     END-IF.

           MOVE MIR-CLI-OINS-CO-NM-T (WS-SUB)
                                  TO L5850-CLI-OINS-CO-NM (WS-SUB).

       5330-EDIT-HOICO-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT INFORCE/PENDING INDICATOR - MUST BE BLANK, I OR P
      *****************************************************************

       5340-EDIT-HOIIP.

           IF MIR-OINS-INFC-PEND-CD-T (WS-SUB) = SPACES
               MOVE L5850-OINS-INFC-PEND-CD (WS-SUB)
                                  TO MIR-OINS-INFC-PEND-CD-T (WS-SUB)
               GO TO 5340-EDIT-HOIIP-X
557660     END-IF.

           IF MIR-OINS-INFC-PEND-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES        TO MIR-OINS-INFC-PEND-CD-T (WS-SUB)
               MOVE SPACES        TO L5850-OINS-INFC-PEND-CD (WS-SUB)
               GO TO 5340-EDIT-HOIIP-X
557660     END-IF.

           MOVE MIR-OINS-INFC-PEND-CD-T (WS-SUB)
                                  TO WS-TEST-HOIIP.

           IF WS-HOIIP-OK
               MOVE MIR-OINS-INFC-PEND-CD-T (WS-SUB)
                                  TO L5850-OINS-INFC-PEND-CD (WS-SUB)
           ELSE
      *** MSG (S) IN-FORCE/PENDING IND MUST BE BLANK, I OR P
               MOVE 'NS22500006'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5340-EDIT-HOIIP-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT THIS COMPANY INDICATOR - MUST BE BLANK, Y OR N
      *****************************************************************

       5350-EDIT-HOICI.

           IF MIR-OINS-THIS-CO-IND-T (WS-SUB) = SPACES
               MOVE L5850-OINS-THIS-CO-IND (WS-SUB)
                                  TO MIR-OINS-THIS-CO-IND-T (WS-SUB)
               GO TO 5350-EDIT-HOICI-X
557660     END-IF.

           IF MIR-OINS-THIS-CO-IND-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE         TO MIR-OINS-THIS-CO-IND-T (WS-SUB)
               MOVE SPACE         TO L5850-OINS-THIS-CO-IND (WS-SUB)
               GO TO 5350-EDIT-HOICI-X
557660     END-IF.

           MOVE MIR-OINS-THIS-CO-IND-T (WS-SUB)
                                  TO WS-TEST-YES-NO.

           IF WS-YES-NO-OK
               MOVE MIR-OINS-THIS-CO-IND-T (WS-SUB)
                                  TO L5850-OINS-THIS-CO-IND (WS-SUB)
           ELSE
      *** MSG (S) THIS COMPANY INDICATOR MUST BE BLANK, Y OR N
               MOVE 'NS22500007'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5350-EDIT-HOICI-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT BUSINESS OR PERSONAL IND - MUST BE BLANK, I OR P
      *****************************************************************

       5360-EDIT-HOIBP.

           IF MIR-OINS-BUS-PERS-CD-T (WS-SUB) = SPACES
               MOVE L5850-OINS-BUS-PERS-CD (WS-SUB)
                                  TO MIR-OINS-BUS-PERS-CD-T (WS-SUB)
               GO TO 5360-EDIT-HOIBP-X
557660     END-IF.

           IF MIR-OINS-BUS-PERS-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES        TO MIR-OINS-BUS-PERS-CD-T (WS-SUB)
               MOVE SPACES        TO L5850-OINS-BUS-PERS-CD (WS-SUB)
               GO TO 5360-EDIT-HOIBP-X
557660     END-IF.

           MOVE MIR-OINS-BUS-PERS-CD-T (WS-SUB)
                                  TO WS-TEST-HOIBP.

           IF WS-HOIBP-OK
               MOVE MIR-OINS-BUS-PERS-CD-T (WS-SUB)
                                  TO L5850-OINS-BUS-PERS-CD (WS-SUB)
           ELSE
      *** MSG (S) BUSINESS/PERSONAL IND MUST BE BLANK, I OR P
               MOVE 'NS22500008'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5360-EDIT-HOIBP-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT HEALTH INSURANCE TYPE - MUST BE BLANK, I OR P
      *****************************************************************

       5370-EDIT-HTYPE.

           IF MIR-DI-OINS-INS-TYP-CD-T (WS-SUB) = SPACES
               MOVE L5850-DI-OINS-INS-TYP-CD (WS-SUB)
                                  TO MIR-DI-OINS-INS-TYP-CD-T (WS-SUB)
               GO TO 5370-EDIT-HTYPE-X
557660     END-IF.

           IF MIR-DI-OINS-INS-TYP-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE         TO MIR-DI-OINS-INS-TYP-CD-T (WS-SUB)
               MOVE SPACE         TO L5850-DI-OINS-INS-TYP-CD (WS-SUB)
               GO TO 5370-EDIT-HTYPE-X
557660     END-IF.

           MOVE MIR-DI-OINS-INS-TYP-CD-T (WS-SUB)
                                  TO WS-TEST-HTYPE.

           IF WS-HTYPE-OK
               MOVE MIR-DI-OINS-INS-TYP-CD-T (WS-SUB)
                                  TO L5850-DI-OINS-INS-TYP-CD (WS-SUB)
           ELSE
      *** MSG (S) I/O IND MUST BE BLANK, I OR O
               MOVE 'NS22500009'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5370-EDIT-HTYPE-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT YEAR OF ISSUE - MUST BE NUMERIC, FORMAT 9999
      *                       CANNOT EXCEED CURRENT YEAR
      *****************************************************************

       5380-EDIT-HYRIS.

           IF MIR-CLI-OINS-ISS-YR-T (WS-SUB) = SPACES
557659*        MOVE L5850-OINS-ISS-YR-QTY (WS-SUB) TO WS-PIC-4-0
020874*        MOVE L5850-CLI-OINS-ISS-YR (WS-SUB)
020874*                           TO WS-PIC-4-0
020874*        MOVE WS-PIC-4-0    TO MIR-CLI-OINS-ISS-YR-T (WS-SUB)
020874         MOVE L5850-CLI-OINS-ISS-YR (WS-SUB) TO L0290-INPUT-V00
020874         MOVE 0             TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLI-OINS-ISS-YR-T (WS-SUB)
020874                            TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA
020874                            TO MIR-CLI-OINS-ISS-YR-T (WS-SUB)
               GO TO 5380-EDIT-HYRIS-X
557660     END-IF.

           IF MIR-CLI-OINS-ISS-YR-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
557659*        MOVE ZEROS         TO L5850-OINS-ISS-YR-QTY (WS-SUB)
557659         MOVE ZEROS         TO L5850-CLI-OINS-ISS-YR (WS-SUB)
               MOVE ZEROS         TO MIR-CLI-OINS-ISS-YR-T (WS-SUB)
               GO TO 5380-EDIT-HYRIS-X
557660     END-IF.

           MOVE 'N'               TO L0280-SIGN-IND.
           MOVE ZERO              TO L0280-PRECISION.
           MOVE 4                 TO L0280-LENGTH.
           MOVE 4                 TO L0280-INPUT-SIZE.
           MOVE MIR-CLI-OINS-ISS-YR-T (WS-SUB)
                                  TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT  TO WS-PIC-4-0
020874*        MOVE WS-PIC-4-0    TO MIR-CLI-OINS-ISS-YR-T (WS-SUB)
020874         MOVE L0280-OUTPUT  TO L0290-INPUT-V00
020874         MOVE 0             TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLI-OINS-ISS-YR-T (WS-SUB)
020874                            TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA
020874                            TO MIR-CLI-OINS-ISS-YR-T (WS-SUB)
           ELSE
      *** MSG (S) ISSUE YEAR MUST BE NUMERIC, FORMAT 9999
               MOVE 'NS22500010'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
               GO TO 5380-EDIT-HYRIS-X
557660     END-IF.

           MOVE WGLOB-PROCESS-DATE
                                  TO L1640-INTERNAL-DATE.
           IF L0280-OUTPUT > (L1640-YYYY-1 + 1800)
      *** MSG (S) ISSUE YEAR CANNOT EXCEED CURRENT YEAR
               MOVE 'NS22500011'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
               GO TO 5380-EDIT-HYRIS-X
557660     END-IF.

557659*    MOVE L0280-OUTPUT      TO L5850-OINS-ISS-YR-QTY (WS-SUB).
557659     MOVE L0280-OUTPUT      TO L5850-CLI-OINS-ISS-YR (WS-SUB).

       5380-EDIT-HYRIS-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT TOTAL AMOUNT - MUST BE NUMERIC, FORMAT 999999999
      *****************************************************************

       5390-EDIT-HFACE.

           IF MIR-CLI-OINS-TOT-AMT-T (WS-SUB) = SPACES
008455*        MOVE L5850-CLI-OINS-TOT-AMT (WS-SUB) TO WS-PIC-9-0
008455*        MOVE WS-PIC-9-0   TO MIR-CLI-OINS-TOT-AMT-T (WS-SUB)
008455         MOVE L5850-CLI-OINS-TOT-AMT (WS-SUB)
020874*                           TO L0290-INPUT-NUMBER
020874                            TO L0290-INPUT-V00
008455         PERFORM  9350-FORMAT-HFACE-T
008455             THRU 9350-FORMAT-HFACE-T-X
               GO TO 5390-EDIT-HFACE-X
557660     END-IF.

           IF MIR-CLI-OINS-TOT-AMT-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO          TO L5850-CLI-OINS-TOT-AMT (WS-SUB)
008455*        MOVE ZERO          TO MIR-CLI-OINS-TOT-AMT-T (WS-SUB)
020874*        MOVE 0             TO L0290-INPUT-NUMBER
020874         MOVE ZEROS         TO L0290-INPUT-V00
008455         PERFORM  9350-FORMAT-HFACE-T
008455             THRU 9350-FORMAT-HFACE-T-X
               GO TO 5390-EDIT-HFACE-X
557660     END-IF.

           MOVE 'N'               TO L0280-SIGN-IND.
           MOVE ZERO              TO L0280-PRECISION.
008455*    MOVE 9                      TO L0280-LENGTH.
008455*    MOVE 9                      TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CLI-OINS-TOT-AMT-T (WS-SUB)
008455                            TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
           MOVE MIR-CLI-OINS-TOT-AMT-T (WS-SUB)
                                  TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT  TO L5850-CLI-OINS-TOT-AMT (WS-SUB)
008455*        MOVE L0280-OUTPUT     TO WS-PIC-9-0
008455*        MOVE WS-PIC-9-0       TO MIR-CLI-OINS-TOT-AMT-T (WS-SUB)
020874*        MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT  TO L0290-INPUT-V00
008455         PERFORM  9350-FORMAT-HFACE-T
008455             THRU 9350-FORMAT-HFACE-T-X
           ELSE
008455*** MSG (S) BENEFIT AMOUNT MUST BE NUMERIC, FORMAT 999999999
008455*** MSG (S) BENEFIT AMOUNT MUST BE NUMERIC
               MOVE 'NS22500012'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5390-EDIT-HFACE-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT ADD AMOUNT - MUST BE NUMERIC, FORMAT 999999
      *****************************************************************

       5400-EDIT-ADDAM.

           IF MIR-CLI-OINS-ADB-AMT-T (WS-SUB) = SPACES
008455*        MOVE L5850-CLI-OINS-ADB-AMT (WS-SUB)
008455*                           TO WS-PIC-6-0
008455*        MOVE WS-PIC-6-0    TO MIR-CLI-OINS-ADB-AMT-T (WS-SUB)
008455         MOVE L5850-CLI-OINS-ADB-AMT (WS-SUB)
020874*                           TO L0290-INPUT-NUMBER
020874                            TO L0290-INPUT-V00
008455         PERFORM  9352-FORMAT-ADDAM-T
008455             THRU 9352-FORMAT-ADDAM-T-X
               GO TO 5400-EDIT-ADDAM-X
557660     END-IF.

           IF MIR-CLI-OINS-ADB-AMT-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO          TO L5850-CLI-OINS-ADB-AMT (WS-SUB)
008455*        MOVE ZERO              TO MIR-CLI-OINS-ADB-AMT-T (WS-SUB)
020874*        MOVE 0             TO L0290-INPUT-NUMBER
020874         MOVE ZEROS         TO L0290-INPUT-V00
008455         PERFORM  9352-FORMAT-ADDAM-T
008455             THRU 9352-FORMAT-ADDAM-T-X
               GO TO 5400-EDIT-ADDAM-X
557660     END-IF.

           MOVE 'N'               TO L0280-SIGN-IND.
           MOVE ZERO              TO L0280-PRECISION.
008455*    MOVE 6                      TO L0280-LENGTH.
008455*    MOVE 6                      TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CLI-OINS-ADB-AMT-T (WS-SUB)
008455                            TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
           MOVE MIR-CLI-OINS-ADB-AMT-T (WS-SUB)
                                  TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
008455*        MOVE L0280-OUTPUT  TO WS-PIC-6-0
008455*        MOVE WS-PIC-6-0    TO MIR-CLI-OINS-ADB-AMT-T (WS-SUB)
020874*        MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT  TO L0290-INPUT-V00
008455         PERFORM  9352-FORMAT-ADDAM-T
008455             THRU 9352-FORMAT-ADDAM-T-X
               MOVE L0280-OUTPUT  TO L5850-CLI-OINS-ADB-AMT (WS-SUB)
           ELSE
      *** MSG (S) ADD AMOUNT MUST BE NUMERIC - FORMAT 999999
               MOVE 'NS22500013'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5400-EDIT-ADDAM-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT ELIMINATION PERIOD - MUST BE IN EDIT, TYPE STB2
      *****************************************************************

       5410-EDIT-HEP.

           IF MIR-DI-OINS-EP-DUR-T (WS-SUB) = SPACES
               MOVE L5850-DI-OINS-EP-DUR (WS-SUB)
                                  TO MIR-DI-OINS-EP-DUR-T (WS-SUB)
               GO TO 5410-EDIT-HEP-X
557660     END-IF.

           IF MIR-DI-OINS-EP-DUR-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE         TO MIR-DI-OINS-EP-DUR-T (WS-SUB)
               MOVE SPACE         TO L5850-DI-OINS-EP-DUR (WS-SUB)
               GO TO 5410-EDIT-HEP-X
557660     END-IF.

           MOVE MIR-DI-OINS-EP-DUR-T (WS-SUB)
                                  TO WEDIT-ETBL-VALU-ID.

           PERFORM  STB2-1000-EDIT-SUB-TABLE-2
               THRU STB2-1000-EDIT-SUB-TABLE-2-X.

           IF WEDIT-IO-OK
               MOVE MIR-DI-OINS-EP-DUR-T (WS-SUB)
                                  TO L5850-DI-OINS-EP-DUR (WS-SUB)
           ELSE
      *** MSG (S) EP MUST BE IN EDIT - TYPE STB2
               MOVE 'NS22500014'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5410-EDIT-HEP-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT BENEFIT PERIOD - MUST BE IN EDIT, TYPE STB3
      *****************************************************************

       5420-EDIT-HBP.

           IF MIR-DI-OINS-BP-DUR-T (WS-SUB) = SPACES
               MOVE L5850-DI-OINS-BP-DUR (WS-SUB)
                                  TO MIR-DI-OINS-BP-DUR-T (WS-SUB)
               GO TO 5420-EDIT-HBP-X
557660     END-IF.

           IF MIR-DI-OINS-BP-DUR-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE         TO MIR-DI-OINS-BP-DUR-T (WS-SUB)
               MOVE SPACE         TO L5850-DI-OINS-BP-DUR (WS-SUB)
               GO TO 5420-EDIT-HBP-X
557660     END-IF.

           MOVE MIR-DI-OINS-BP-DUR-T (WS-SUB)
                                  TO WEDIT-ETBL-VALU-ID.

           PERFORM  STB3-1000-EDIT-SUB-TABLE-3
               THRU STB3-1000-EDIT-SUB-TABLE-3-X.

           IF WEDIT-IO-OK
               MOVE MIR-DI-OINS-BP-DUR-T (WS-SUB)
                                  TO L5850-DI-OINS-BP-DUR (WS-SUB)
           ELSE
      *** MSG (S) BP MUST BE IN EDIT - TYPE STB3
               MOVE 'NS22500015'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5420-EDIT-HBP-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT TAXABLE INDICATOR - MUST BE BLANK, Y OR N
      *****************************************************************

       5430-EDIT-TAXIN.

           IF MIR-DI-OINS-TAXBL-CD-T (WS-SUB) = SPACES
               MOVE L5850-DI-OINS-TAXBL-CD (WS-SUB)
                                  TO MIR-DI-OINS-TAXBL-CD-T (WS-SUB)
               GO TO 5430-EDIT-TAXIN-X
557660     END-IF.

           IF MIR-DI-OINS-TAXBL-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE         TO MIR-DI-OINS-TAXBL-CD-T (WS-SUB)
               MOVE SPACE         TO L5850-DI-OINS-TAXBL-CD (WS-SUB)
               GO TO 5430-EDIT-TAXIN-X
557660     END-IF.

           MOVE MIR-DI-OINS-TAXBL-CD-T (WS-SUB)
                                  TO WS-TEST-YES-NO.

           IF WS-YES-NO-OK
               MOVE MIR-DI-OINS-TAXBL-CD-T (WS-SUB)
                                  TO L5850-DI-OINS-TAXBL-CD (WS-SUB)
           ELSE
      *** MSG (S) TAXABLE INDICATOR MUST BE BLANK, Y OR N
               MOVE 'NS22500016'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5430-EDIT-TAXIN-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT REPLACED INDICATOR - MUST BE BLANK, Y OR N
      *****************************************************************

       5440-EDIT-REPIN.

           IF MIR-DI-OINS-REPL-IND-T (WS-SUB) = SPACES
557659*        MOVE L5850-DI-OINS-REPL-CD (WS-SUB)
557659         MOVE L5850-DI-OINS-REPL-IND (WS-SUB)
                                  TO MIR-DI-OINS-REPL-IND-T (WS-SUB)
               GO TO 5440-EDIT-REPIN-X
557660     END-IF.

           IF MIR-DI-OINS-REPL-IND-T (WS-SUB)
                                  = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE         TO MIR-DI-OINS-REPL-IND-T (WS-SUB)
557659*        MOVE SPACE         TO L5850-DI-OINS-REPL-CD (WS-SUB)
557659         MOVE SPACE         TO L5850-DI-OINS-REPL-IND (WS-SUB)
               GO TO 5440-EDIT-REPIN-X
557660     END-IF.

           MOVE MIR-DI-OINS-REPL-IND-T (WS-SUB)
                                  TO WS-TEST-YES-NO.

           IF WS-YES-NO-OK
               MOVE MIR-DI-OINS-REPL-IND-T (WS-SUB)
557659*          TO L5850-DI-OINS-REPL-CD (WS-SUB)
557659                            TO L5850-DI-OINS-REPL-IND (WS-SUB)
           ELSE
      *** MSG (S) REPLACED INDICATOR MUST BE BLANK, Y OR N
               MOVE 'NS22500017'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5440-EDIT-REPIN-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT REFUSED INSURANCE INDICATOR - MUST BE BLANK, Y OR N
      *****************************************************************

       5450-EDIT-HRFIN.

           IF MIR-DI-INS-REFUS-IND = SPACES
               MOVE RAPPF-DI-INS-REFUS-IND
                                  TO MIR-DI-INS-REFUS-IND
               GO TO 5450-EDIT-HRFIN-X
557660     END-IF.

           IF MIR-DI-INS-REFUS-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE         TO MIR-DI-INS-REFUS-IND
               MOVE SPACE         TO RAPPF-DI-INS-REFUS-IND
               GO TO 5450-EDIT-HRFIN-X
557660     END-IF.

           MOVE MIR-DI-INS-REFUS-IND
                                  TO WS-TEST-YES-NO.

           IF WS-YES-NO-OK
               MOVE MIR-DI-INS-REFUS-IND
                                  TO RAPPF-DI-INS-REFUS-IND
           ELSE
      *** MSG (S) EXTRA PREM REFUSED IND MUST BE BLANK, Y OR N
               MOVE 'NS22500018'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5450-EDIT-HRFIN-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT REFUSED INSURANCE INFORMATION
      *****************************************************************

       5460-EDIT-H-REFUSED.

           PERFORM  5470-EDIT-HRFYR
               THRU 5470-EDIT-HRFYR-X.

           PERFORM  5480-EDIT-HRFCO
               THRU 5480-EDIT-HRFCO-X.

           PERFORM  5490-EDIT-HRFTC
               THRU 5490-EDIT-HRFTC-X.

           PERFORM  5500-EDIT-HRRSN
               THRU 5500-EDIT-HRRSN-X.

       5460-EDIT-H-REFUSED-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT REFUSED INSURANCE YEAR - MUST BE NUMERIC, FORMAT 9999
      *                                CANNOT EXCEED CURRENT YEAR
      *****************************************************************

       5470-EDIT-HRFYR.

           IF MIR-CLI-DI-REFUS-1-YR-T (WS-SUB) = SPACES
557659*        MOVE RAPPF-DI-REFUS-YR-QTY (WS-SUB) TO WS-PIC-4-0
020874*        MOVE RAPPF-CLI-DI-REFUS-YR (WS-SUB)
020874*                           TO WS-PIC-4-0
020874*        MOVE WS-PIC-4-0    TO MIR-CLI-DI-REFUS-1-YR-T (WS-SUB)
020874         MOVE RAPPF-CLI-DI-REFUS-YR (WS-SUB) TO L0290-INPUT-V00
020874         MOVE 0             TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLI-DI-REFUS-1-YR-T (WS-SUB)
020874                            TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA
020874                            TO MIR-CLI-DI-REFUS-1-YR-T (WS-SUB)
               GO TO 5470-EDIT-HRFYR-X
557660     END-IF.

           IF MIR-CLI-DI-REFUS-1-YR-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
557659*        MOVE ZERO          TO RAPPF-DI-REFUS-YR-QTY (WS-SUB)
557659         MOVE ZERO          TO RAPPF-CLI-DI-REFUS-YR (WS-SUB)
               MOVE ZERO          TO MIR-CLI-DI-REFUS-1-YR-T (WS-SUB)
               GO TO 5470-EDIT-HRFYR-X
557660     END-IF.

           MOVE 'N'               TO L0280-SIGN-IND.
           MOVE ZERO              TO L0280-PRECISION.
           MOVE 4                 TO L0280-LENGTH.
           MOVE 4                 TO L0280-INPUT-SIZE.
           MOVE MIR-CLI-DI-REFUS-1-YR-T (WS-SUB)
                                  TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT  TO WS-PIC-4-0
020874*        MOVE WS-PIC-4-0    TO MIR-CLI-DI-REFUS-1-YR-T (WS-SUB)
020874         MOVE L0280-OUTPUT  TO L0290-INPUT-V00
020874         MOVE 0             TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLI-DI-REFUS-1-YR-T (WS-SUB)
020874                            TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA
020874                            TO MIR-CLI-DI-REFUS-1-YR-T (WS-SUB)
           ELSE
      *** MSG (S) INSURANCE REFUSED YEAR MUST BE NUMERIC, FORMAT 9999
               MOVE 'NS22500019'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
               GO TO 5470-EDIT-HRFYR-X
557660     END-IF.

           MOVE WGLOB-PROCESS-DATE
                                  TO L1640-INTERNAL-DATE.
           IF L0280-OUTPUT > (L1640-YYYY-1 + 1800)
      *** MSG (S) INSURANCE REFUSED YEAR CANNOT EXCEED CURRENT YEAR
               MOVE 'NS22500020'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
               GO TO 5470-EDIT-HRFYR-X
557660     END-IF.

557659*    MOVE L0280-OUTPUT         TO RAPPF-DI-REFUS-YR-QTY (WS-SUB).
557659     MOVE L0280-OUTPUT      TO RAPPF-CLI-DI-REFUS-YR (WS-SUB).

       5470-EDIT-HRFYR-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT REFUSED INSURANCE COMPANY - NO EDITS
      *****************************************************************

       5480-EDIT-HRFCO.

           IF MIR-DI-REFUS-CO-1-NM-T (WS-SUB) = SPACES
               MOVE RAPPF-DI-REFUS-CO-NM (WS-SUB)
                                  TO MIR-DI-REFUS-CO-1-NM-T (WS-SUB)
               GO TO 5480-EDIT-HRFCO-X
557660     END-IF.

           IF MIR-DI-REFUS-CO-1-NM-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE         TO MIR-DI-REFUS-CO-1-NM-T (WS-SUB)
557660     END-IF.

           MOVE MIR-DI-REFUS-CO-1-NM-T (WS-SUB)
                                  TO RAPPF-DI-REFUS-CO-NM (WS-SUB).

       5480-EDIT-HRFCO-X.
           EXIT.
      /
      ******************************************************************
      *  EDIT REFUSED INSURANCE THIS COMPANY IND - MSUT BE BLANK, Y OR N
      ******************************************************************

       5490-EDIT-HRFTC.

           IF MIR-DI-REFUS-CO-1-IND-T (WS-SUB) = SPACES
               MOVE RAPPF-DI-REFUS-CO-IND (WS-SUB) TO
                   MIR-DI-REFUS-CO-1-IND-T (WS-SUB)
               GO TO 5490-EDIT-HRFTC-X
557660     END-IF.

           IF MIR-DI-REFUS-CO-1-IND-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE         TO MIR-DI-REFUS-CO-1-IND-T (WS-SUB)
               MOVE SPACE         TO RAPPF-DI-REFUS-CO-IND (WS-SUB)
               GO TO 5490-EDIT-HRFTC-X
557660     END-IF.

           MOVE MIR-DI-REFUS-CO-1-IND-T (WS-SUB)
                                  TO WS-TEST-YES-NO.

           IF WS-YES-NO-OK
               MOVE MIR-DI-REFUS-CO-1-IND-T (WS-SUB)
                                  TO RAPPF-DI-REFUS-CO-IND (WS-SUB)
           ELSE
      *** MSG (S) EXTRA PREM COMPANY IND MUST BE BLANK, Y OR N
               MOVE 'NS22500021'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5490-EDIT-HRFTC-X.
           EXIT.
      /
      ******************************************************************
      *  EDIT REFUSED INSURANCE REASON - MUST BE IN EDIT, TYPE RREAS
      ******************************************************************

       5500-EDIT-HRRSN.

           IF MIR-DI-REFUS-1-TXT-T (WS-SUB) = SPACES
               MOVE RAPPF-DI-REFUS-TXT (WS-SUB)
                                  TO MIR-DI-REFUS-1-TXT-T (WS-SUB)
               GO TO 5500-EDIT-HRRSN-X
557660     END-IF.

           IF MIR-DI-REFUS-1-TXT-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE         TO MIR-DI-REFUS-1-TXT-T (WS-SUB)
               MOVE SPACE         TO RAPPF-DI-REFUS-TXT (WS-SUB)
               GO TO 5500-EDIT-HRRSN-X
557660     END-IF.

           MOVE MIR-DI-REFUS-1-TXT-T (WS-SUB)
                                  TO WEDIT-ETBL-VALU-ID.

           PERFORM RRES-1000-EDIT
               THRU RRES-1000-EDIT-X.

           IF WEDIT-IO-OK
               MOVE MIR-DI-REFUS-1-TXT-T (WS-SUB)
                                  TO RAPPF-DI-REFUS-TXT (WS-SUB)
           ELSE
      *** MSG (S) INS REFUSED REASON MUST BE IN EDIT - TYPE RREAS
               MOVE 'NS22500022'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5500-EDIT-HRRSN-X.
           EXIT.
      /
      ******************************************************************
      *  EDIT ELGIBLE SOON IND - MUST BE BLANK, Y OR N
      ******************************************************************

       5510-EDIT-ELGIN.

           IF MIR-CLI-DI-ELIG-IND = SPACES
557659*        MOVE RAPPF-DI-ELIG-CD   TO MIR-CLI-DI-ELIG-IND
557659         MOVE RAPPF-CLI-DI-ELIG-IND
                                  TO MIR-CLI-DI-ELIG-IND
               GO TO 5510-EDIT-ELGIN-X
557660     END-IF.

           IF MIR-CLI-DI-ELIG-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE         TO MIR-CLI-DI-ELIG-IND
557659*        MOVE SPACE             TO RAPPF-DI-ELIG-CD
557659         MOVE SPACE         TO RAPPF-CLI-DI-ELIG-IND
               GO TO 5510-EDIT-ELGIN-X
557660     END-IF.

           MOVE MIR-CLI-DI-ELIG-IND
                                  TO WS-TEST-YES-NO.

           IF WS-YES-NO-OK
557659*        MOVE MIR-CLI-DI-ELIG-IND TO RAPPF-DI-ELIG-CD
557659         MOVE MIR-CLI-DI-ELIG-IND
                                  TO RAPPF-CLI-DI-ELIG-IND
           ELSE
      *** MSG (S) ELIGIBLE SOON IND MUST BE BLANK, Y OR N
               MOVE 'NS22500023'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5510-EDIT-ELGIN-X.
           EXIT.
      /
      ******************************************************************
557658*  EDIT ELGIBLE SOON YEAR - MUST BE NUMERIC, FORMAT 9999
      ******************************************************************

       5520-EDIT-ELGYR.

           IF MIR-CLI-DI-ELIG-YR = SPACES
557658*        MOVE RAPPF-DI-ELIG-YR-QTY  TO WS-PIC-2-0
020874*        MOVE RAPPF-CLI-DI-ELIG-YR
020874*                           TO WS-PIC-4-0
557658*        MOVE WS-PIC-2-0        TO MIR-CLI-DI-ELIG-YR
020874*        MOVE WS-PIC-4-0    TO MIR-CLI-DI-ELIG-YR
020874         MOVE RAPPF-CLI-DI-ELIG-YR TO L0290-INPUT-V00
020874         MOVE 0                    TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLI-DI-ELIG-YR
020874                                   TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA    TO MIR-CLI-DI-ELIG-YR
               GO TO 5520-EDIT-ELGYR-X
557660     END-IF.

           IF MIR-CLI-DI-ELIG-YR = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO          TO MIR-CLI-DI-ELIG-YR
557658*        MOVE ZERO              TO RAPPF-DI-ELIG-YR-QTY
557658         MOVE ZERO          TO RAPPF-CLI-DI-ELIG-YR
               GO TO 5520-EDIT-ELGYR-X
557660     END-IF.

           MOVE 'N'               TO L0280-SIGN-IND.
           MOVE ZERO              TO L0280-PRECISION.
557658*    MOVE 2                    TO L0280-LENGTH.
557658     MOVE 4                 TO L0280-LENGTH.
557658*    MOVE 2                    TO L0280-INPUT-SIZE.
557658     MOVE 4                 TO L0280-INPUT-SIZE.
           MOVE MIR-CLI-DI-ELIG-YR
                                  TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
557658*        MOVE L0280-OUTPUT      TO RAPPF-DI-ELIG-YR-QTY
557658         MOVE L0280-OUTPUT  TO RAPPF-CLI-DI-ELIG-YR
557658*        MOVE L0280-OUTPUT      TO WS-PIC-2-0
020874*        MOVE L0280-OUTPUT  TO WS-PIC-4-0
557658*        MOVE WS-PIC-2-0        TO MIR-CLI-DI-ELIG-YR
020874*        MOVE WS-PIC-4-0    TO MIR-CLI-DI-ELIG-YR
020874         MOVE L0280-OUTPUT  TO L0290-INPUT-V00
020874         MOVE 0             TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLI-DI-ELIG-YR
020874                            TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CLI-DI-ELIG-YR
           ELSE
      *** MSG (S) ELIGIBLE SOON YEAR MUST BE NUMERIC FORMAT 9999
               MOVE 'NS22500024'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5520-EDIT-ELGYR-X.
           EXIT.
      /
      ******************************************************************
      *  EDIT ELGIBLE SOON MONTH - MUST BE NUMERIC, FORMAT 99
      ******************************************************************

       5530-EDIT-ELGMN.

013578*    IF MIR-CLI-DI-ELIG-MO = SPACES
013578*        MOVE RAPPF-CLI-DI-ELIG-MO
013578*                           TO WS-PIC-2-0
013578*        MOVE WS-PIC-2-0    TO MIR-CLI-DI-ELIG-MO
013578*        GO TO 5530-EDIT-ELGMN-X
013578*    END-IF.
013578*
013578*    IF MIR-CLI-DI-ELIG-MO = EBLCH-BLANK-FIELD-CHAR
013578*        MOVE ZERO          TO MIR-CLI-DI-ELIG-MO
013578*        MOVE ZERO          TO RAPPF-CLI-DI-ELIG-MO
013578*        GO TO 5530-EDIT-ELGMN-X
013578*    END-IF.
013578*
013578     IF  MIR-CLI-DI-ELIG-MO = SPACES
013578     OR  MIR-CLI-DI-ELIG-MO = ZEROES
013578         MOVE ZERO          TO RAPPF-CLI-DI-ELIG-MO
013578         GO TO 5530-EDIT-ELGMN-X
013578     END-IF.
013578
           MOVE 'N'               TO L0280-SIGN-IND.
           MOVE ZERO              TO L0280-PRECISION.
           MOVE 2                 TO L0280-LENGTH.
           MOVE 2                 TO L0280-INPUT-SIZE.
           MOVE MIR-CLI-DI-ELIG-MO
                                  TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT  TO WS-PIC-2-0
020874*        MOVE WS-PIC-2-0    TO MIR-CLI-DI-ELIG-MO
020874         MOVE L0280-OUTPUT  TO L0290-INPUT-V00
020874         MOVE 0             TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CLI-DI-ELIG-MO
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CLI-DI-ELIG-MO
           ELSE
      *** MSG (S) ELIGIBLE SOON MONTH MUST BE NUMERIC FORMAT 99
               MOVE 'NS22500025'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
               GO TO 5530-EDIT-ELGMN-X
557660     END-IF.

           IF L0280-OUTPUT < 1
           OR L0280-OUTPUT > 12
      *** MSG (S) ELIGIBLE SOON MONTH MUST BE BETWEEN 01 AND 12
               MOVE 'NS22500026'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
               GO TO 5530-EDIT-ELGMN-X
557660     END-IF.

557658*    MOVE L0280-OUTPUT            TO RAPPF-DI-ELIG-MO-QTY.
557658     MOVE L0280-OUTPUT      TO RAPPF-CLI-DI-ELIG-MO.

       5530-EDIT-ELGMN-X.
           EXIT.
      /
      ******************************************************************
      *  EDIT ELGIBLE SOON AMOUNT - MUST BE NUMERIC, FORMAT 99999
      ******************************************************************

       5540-EDIT-ELGAM.

           IF MIR-DI-ELIG-AMT = SPACES
008455*        MOVE RAPPF-DI-ELIG-AMT   TO WS-PIC-5-0
008455*        MOVE WS-PIC-5-0          TO MIR-DI-ELIG-AMT
008455         MOVE RAPPF-DI-ELIG-AMT
020874*                           TO L0290-INPUT-NUMBER
020874                            TO L0290-INPUT-V00
008455         PERFORM  9354-FORMAT-ELGAM
008455             THRU 9354-FORMAT-ELGAM-X
               GO TO 5540-EDIT-ELGAM-X
557660     END-IF.

           IF MIR-DI-ELIG-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE ZERO                TO MIR-DI-ELIG-AMT
020874*        MOVE 0             TO L0290-INPUT-NUMBER
020874         MOVE ZEROS         TO L0290-INPUT-V00
008455         PERFORM  9354-FORMAT-ELGAM
008455             THRU 9354-FORMAT-ELGAM-X
               MOVE ZERO          TO RAPPF-DI-ELIG-AMT
               GO TO 5540-EDIT-ELGAM-X
557660     END-IF.

           MOVE 'N'               TO L0280-SIGN-IND.
           MOVE ZERO              TO L0280-PRECISION.
008455*    MOVE 5                       TO L0280-LENGTH.
008455*    MOVE 5                       TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-DI-ELIG-AMT
                                  TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
           MOVE MIR-DI-ELIG-AMT   TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT  TO RAPPF-DI-ELIG-AMT
008455*        MOVE L0280-OUTPUT        TO WS-PIC-5-0
008455*        MOVE WS-PIC-5-0          TO MIR-DI-ELIG-AMT
020874*        MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT  TO L0290-INPUT-V00
008455         PERFORM  9354-FORMAT-ELGAM
008455             THRU 9354-FORMAT-ELGAM-X
           ELSE
008455*** MSG (S) ELIGIBLE SOON AMOUNT MUST BE NUMERIC FORMAT 99999
008455*** MSG (S) ELIGIBLE SOON AMOUNT MUST BE NUMERIC
               MOVE 'NS22500027'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5540-EDIT-ELGAM-X.
           EXIT.
      /
      ******************************************************************
      *  EDIT ELGIBLE SOON EP - MUST BE IN EDIT, TYPE STB2
      ******************************************************************

       5550-EDIT-ELGEP.

           IF MIR-CLI-ELIG-EP-DUR = SPACES
               MOVE RAPPF-CLI-ELIG-EP-DUR
                                  TO MIR-CLI-ELIG-EP-DUR
               GO TO 5550-EDIT-ELGEP-X
557660     END-IF.

           IF MIR-CLI-ELIG-EP-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE         TO MIR-CLI-ELIG-EP-DUR
               MOVE SPACE         TO RAPPF-CLI-ELIG-EP-DUR
               GO TO 5550-EDIT-ELGEP-X
557660     END-IF.

           MOVE MIR-CLI-ELIG-EP-DUR
                                  TO WEDIT-ETBL-VALU-ID.

           PERFORM  STB2-1000-EDIT-SUB-TABLE-2
               THRU STB2-1000-EDIT-SUB-TABLE-2-X.

           IF WEDIT-IO-OK
               MOVE MIR-CLI-ELIG-EP-DUR
                                  TO RAPPF-CLI-ELIG-EP-DUR
           ELSE
      *** MSG (S) ELIGIBLE SOON EP MUST BE IN EDIT, TYPE STB2
               MOVE 'NS22500028'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5550-EDIT-ELGEP-X.
           EXIT.
      /
      ******************************************************************
      *  EDIT ELGIBLE SOON BP - MUST BE IN EDIT, TYPE STB3
      ******************************************************************

       5560-EDIT-ELGBP.

           IF MIR-CLI-ELIG-BP-DUR = SPACES
               MOVE RAPPF-CLI-ELIG-BP-DUR
                                  TO MIR-CLI-ELIG-BP-DUR
               GO TO 5560-EDIT-ELGBP-X
557660     END-IF.

           IF MIR-CLI-ELIG-BP-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE         TO MIR-CLI-ELIG-BP-DUR
               MOVE SPACE         TO RAPPF-CLI-ELIG-BP-DUR
               GO TO 5560-EDIT-ELGBP-X
557660     END-IF.

           MOVE MIR-CLI-ELIG-BP-DUR
                                  TO WEDIT-ETBL-VALU-ID.

           PERFORM  STB3-1000-EDIT-SUB-TABLE-3
               THRU STB3-1000-EDIT-SUB-TABLE-3-X.

           IF WEDIT-IO-OK
               MOVE MIR-CLI-ELIG-BP-DUR
                                  TO RAPPF-CLI-ELIG-BP-DUR
           ELSE
      *** MSG (S) ELIGIBLE SOON BP MUST BE IN EDIT, TYPE STB3
               MOVE 'NS22500029'  TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'           TO WS-EDIT-OK-SW
557660     END-IF.

       5560-EDIT-ELGBP-X.
           EXIT.
      /
       5570-OINS-CROSS-EDITS.

           IF  L5850-CLI-OINS-CO-NM (WS-SUB) NOT = SPACES
           OR  L5850-OINS-INFC-PEND-CD (WS-SUB) NOT = SPACES
           OR  L5850-OINS-THIS-CO-IND (WS-SUB) NOT = SPACES
           OR  L5850-OINS-BUS-PERS-CD (WS-SUB) NOT = SPACES
           OR  L5850-DI-OINS-INS-TYP-CD (WS-SUB) NOT = SPACES
557659*    OR  L5850-OINS-ISS-YR-QTY (WS-SUB) NOT = ZEROES
557659     OR  L5850-CLI-OINS-ISS-YR (WS-SUB) NOT = ZEROES
           OR  L5850-CLI-OINS-TOT-AMT (WS-SUB) NOT = ZEROES
           OR  L5850-CLI-OINS-ADB-AMT (WS-SUB) NOT = ZEROES
           OR  L5850-DI-OINS-EP-DUR (WS-SUB) NOT = SPACES
           OR  L5850-DI-OINS-BP-DUR (WS-SUB) NOT = SPACES
           OR  L5850-DI-OINS-TAXBL-CD (WS-SUB) NOT = SPACES
557659*    OR  L5850-DI-OINS-REPL-CD (WS-SUB) NOT = SPACES
557659     OR  L5850-DI-OINS-REPL-IND (WS-SUB) NOT = SPACES
               MOVE 'Y'           TO WS-HEALTH-DATA-ENTERED-SW
               IF L5850-CLI-OINS-CO-NM (WS-SUB) = SPACES
               OR L5850-OINS-INFC-PEND-CD (WS-SUB) = SPACE
               OR L5850-OINS-THIS-CO-IND (WS-SUB) = SPACE
               OR L5850-OINS-BUS-PERS-CD (WS-SUB) = SPACE
               OR L5850-DI-OINS-INS-TYP-CD (WS-SUB) = SPACE
557659*        OR L5850-OINS-ISS-YR-QTY (WS-SUB) = ZEROS
557659         OR L5850-CLI-OINS-ISS-YR (WS-SUB) = ZEROS
               OR L5850-CLI-OINS-TOT-AMT (WS-SUB) = ZEROS
               OR L5850-DI-OINS-EP-DUR (WS-SUB) = SPACE
               OR L5850-DI-OINS-BP-DUR (WS-SUB) = SPACE
               OR L5850-DI-OINS-TAXBL-CD (WS-SUB) = SPACE
557659*        OR L5850-DI-OINS-REPL-CD (WS-SUB) = SPACE
557659         OR L5850-DI-OINS-REPL-IND (WS-SUB) = SPACE
      *** MSG (S) MISSING REQUIRED TOTH HEALTH INS FIELDS ON LINE (@1)
                   MOVE 'NS22500030'
                                  TO WGLOB-MSG-REF-INFO
                   MOVE WS-SUB    TO WGLOB-MSG-PARM (1)
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   IF WS-EDIT-OK
                       MOVE '2'   TO WS-EDIT-OK-SW
557660             END-IF
557660         END-IF
557660     END-IF.

       5570-OINS-CROSS-EDITS-X.
           EXIT.
      /
       5580-XEDIT-H-REFUSED.

557659*    IF RAPPF-DI-REFUS-YR-QTY (WS-SUB) NOT = ZEROS
557659     IF RAPPF-CLI-DI-REFUS-YR (WS-SUB) NOT = ZEROS
           OR RAPPF-DI-REFUS-CO-NM (WS-SUB) NOT = SPACES
           OR RAPPF-DI-REFUS-CO-IND (WS-SUB) NOT = SPACE
           OR RAPPF-DI-REFUS-TXT (WS-SUB) NOT = SPACES
               MOVE 'Y' TO WS-HEALTH-DATA-ENTERED-SW
557659*        IF RAPPF-DI-REFUS-YR-QTY (WS-SUB) = ZEROS
557659         IF RAPPF-CLI-DI-REFUS-YR (WS-SUB) = ZEROS
               OR RAPPF-DI-REFUS-CO-NM (WS-SUB) = SPACES
               OR RAPPF-DI-REFUS-CO-IND (WS-SUB) = SPACE
               OR RAPPF-DI-REFUS-TXT (WS-SUB) = SPACES
      *** MSG (S) MISSING REQUIRED TOTH REFUSED FIELDS ON LINE (@1)
                   MOVE 'NS22500031'
                                  TO WGLOB-MSG-REF-INFO
                   MOVE WS-SUB    TO WGLOB-MSG-PARM (1)
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   IF WS-EDIT-OK
                       MOVE '2'   TO WS-EDIT-OK-SW
557660             END-IF
557660         END-IF
557660     END-IF.

       5580-XEDIT-H-REFUSED-X.
           EXIT.
      /
       5590-XEDIT-ELIGIBLE.

           MOVE 'N' TO WS-HEALTH-DATA-ENTERED-SW.

557658*    IF RAPPF-DI-ELIG-YR-QTY  NOT = ZEROS
557658     IF RAPPF-CLI-DI-ELIG-YR  NOT = ZEROS
557658*    OR RAPPF-DI-ELIG-MO-QTY  NOT = ZEROS
557658     OR RAPPF-CLI-DI-ELIG-MO  NOT = ZEROS
           OR RAPPF-DI-ELIG-AMT  NOT = ZEROS
           OR RAPPF-CLI-ELIG-EP-DUR NOT = SPACES
           OR RAPPF-CLI-ELIG-BP-DUR NOT = SPACES
               MOVE 'Y' TO WS-HEALTH-DATA-ENTERED-SW
557658*        IF RAPPF-DI-ELIG-YR-QTY  = ZEROS
557658         IF RAPPF-CLI-DI-ELIG-YR  = ZEROS
557658*        OR RAPPF-DI-ELIG-MO-QTY  = ZEROS
557658         OR RAPPF-CLI-DI-ELIG-MO  = ZEROS
               OR RAPPF-DI-ELIG-AMT  = ZEROS
               OR RAPPF-CLI-ELIG-EP-DUR = SPACES
               OR RAPPF-CLI-ELIG-BP-DUR = SPACES
      *** MSG (S) MISSING REQUIRED ELIGIBLE FIELDS ON TOTH
                   MOVE 'NS22500032'
                                  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   IF WS-EDIT-OK
                       MOVE '2'   TO WS-EDIT-OK-SW
557660             END-IF
557660         END-IF
557660     END-IF.

557659*    IF  RAPPF-DI-ELIG-CD   = 'Y'
557659     IF  RAPPF-CLI-DI-ELIG-IND   = 'Y'
           AND NOT WS-HEALTH-DATA-ENTERED
      *** MSG (S) ELIGIBLE SOON IND IS 'Y', REQUIRE DETAILS
               MOVE 'NS22500033'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WS-EDIT-OK
                   MOVE '2'       TO WS-EDIT-OK-SW
034802*        ELSE
034802*            NEXT SENTENCE
557660         END-IF
           ELSE
               IF  MIR-CLI-DI-ELIG-IND = 'N'
               AND WS-HEALTH-DATA-ENTERED
      *** MSG (S) ELIGIBLE SOON IND IS 'N', DETAILS NOT ALLOWED
                   MOVE 'NS22500034'
                                  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   IF WS-EDIT-OK
                       MOVE '2'   TO WS-EDIT-OK-SW
557660             END-IF
557660         END-IF
557660     END-IF.

       5590-XEDIT-ELIGIBLE-X.
           EXIT.
      /
      *****************************************************************
      *  BUILD APPF KEY: SETS UP THE KEY TO BE USED IN A SUBSEQUENT
      *  READ.
      *****************************************************************
       8000-BUILD-APPF-KEY.

           MOVE MIR-CLI-ID       TO WAPPF-CLI-ID.
014221     MOVE MIR-CLI-ID       TO  WCLI-CLI-ID.

       8000-BUILD-APPF-KEY-X.
           EXIT.

      /
      *****************************************************************
      *  BUILD CLIO KEY
      *****************************************************************
       8200-BUILD-CLIO-KEY.

           MOVE MIR-CLI-ID        TO L5850-CLI-ID.
           MOVE 'H'               TO L5850-CLI-OINS-TYP-CD.

       8200-BUILD-CLIO-KEY-X.
           EXIT.
      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************

       9100-BLANK-DATA-FIELDS.

014221*    MOVE SPACES            TO MIR-PREV-UPDT-DT.
014221     MOVE SPACES            TO MIR-DV-PREV-UPDT-DT.
           MOVE SPACES            TO MIR-CLI-DI-OINS-IND.
           MOVE SPACES            TO MIR-CLI-OINS-CO-NM-G.
           MOVE SPACES            TO MIR-OINS-INFC-PEND-CD-G.
           MOVE SPACES            TO MIR-OINS-THIS-CO-IND-G.
           MOVE SPACES            TO MIR-OINS-BUS-PERS-CD-G.
           MOVE SPACES            TO MIR-DI-OINS-INS-TYP-CD-G.
           MOVE SPACES            TO MIR-DV-CLI-OINS-ISS-YR-G.
           MOVE SPACES            TO MIR-CLI-OINS-TOT-AMT-G.
           MOVE SPACES            TO MIR-CLI-OINS-ADB-AMT-G.
           MOVE SPACES            TO MIR-DI-OINS-EP-DUR-G.
           MOVE SPACES            TO MIR-DI-OINS-BP-DUR-G.
           MOVE SPACES            TO MIR-DI-OINS-TAXBL-CD-G.
           MOVE SPACES            TO MIR-DV-DI-OINS-REPL-IND-G.
           MOVE SPACES            TO MIR-DI-INS-REFUS-IND.
           MOVE SPACES            TO MIR-CLI-DI-REFUS-1-YR-G.
           MOVE SPACES            TO MIR-DI-REFUS-CO-NM-G.
           MOVE SPACES            TO MIR-DI-REFUS-CO-IND-G.
           MOVE SPACES            TO MIR-DI-REFUS-TXT-G.
           MOVE SPACES            TO MIR-CLI-DI-ELIG-IND.
           MOVE SPACES            TO MIR-CLI-DI-ELIG-YR.
           MOVE SPACES            TO MIR-CLI-DI-ELIG-MO.
           MOVE SPACES            TO MIR-DI-ELIG-AMT.
           MOVE SPACES            TO MIR-CLI-ELIG-EP-DUR.
           MOVE SPACES            TO MIR-CLI-ELIG-BP-DUR.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************

       9200-MOVE-RECORD-TO-SCREEN.

014221*    MOVE RAPPF-PREV-UPDT-DT
014221*    MOVE RAPPF-PREV-UPDT-TS
014221*                           TO L1640-INTERNAL-DATE.
014221     MOVE RAPPF-PREV-UPDT-TS
014221                            TO WWKDT-INT-TS.
014221     MOVE WWKDT-INT-TS      TO L1640-INTERNAL-DATE.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE
014221*                           TO MIR-PREV-UPDT-DT.
014221                            TO MIR-DV-PREV-UPDT-DT.

           MOVE RAPPF-CLI-DI-OINS-IND
                                  TO MIR-CLI-DI-OINS-IND.
           MOVE RAPPF-DI-INS-REFUS-IND
                                  TO MIR-DI-INS-REFUS-IND.
557659*    MOVE RAPPF-DI-ELIG-CD         TO MIR-CLI-DI-ELIG-IND.
557659     MOVE RAPPF-CLI-DI-ELIG-IND
                                  TO MIR-CLI-DI-ELIG-IND.
557658*    MOVE RAPPF-DI-ELIG-YR-QTY     TO WS-PIC-2-0.
020874*    MOVE RAPPF-CLI-DI-ELIG-YR
020874*                           TO WS-PIC-4-0.
557658*    MOVE WS-PIC-2-0               TO MIR-CLI-DI-ELIG-YR.
020874*    MOVE WS-PIC-4-0        TO MIR-CLI-DI-ELIG-YR.
020874     MOVE RAPPF-CLI-DI-ELIG-YR TO L0290-INPUT-V00.
020874     MOVE 0                 TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CLI-DI-ELIG-YR
020874                            TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA TO MIR-CLI-DI-ELIG-YR.
557658*    MOVE RAPPF-DI-ELIG-MO-QTY     TO WS-PIC-2-0.
020874*    MOVE RAPPF-CLI-DI-ELIG-MO
020874*                           TO WS-PIC-2-0.
020874*    MOVE WS-PIC-2-0        TO MIR-CLI-DI-ELIG-MO.
020874     MOVE RAPPF-CLI-DI-ELIG-MO TO L0290-INPUT-V00.
020874     MOVE 0                 TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CLI-DI-ELIG-MO
020874                            TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA TO MIR-CLI-DI-ELIG-MO.
008455*    MOVE RAPPF-DI-ELIG-AMT        TO WS-PIC-5-0.
008455*    MOVE WS-PIC-5-0               TO MIR-DI-ELIG-AMT.
020874*    MOVE RAPPF-DI-ELIG-AMT TO L0290-INPUT-NUMBER.
020874     MOVE RAPPF-DI-ELIG-AMT TO L0290-INPUT-V00.
008455     PERFORM  9354-FORMAT-ELGAM
008455         THRU 9354-FORMAT-ELGAM-X.
           MOVE RAPPF-CLI-ELIG-EP-DUR
                                  TO MIR-CLI-ELIG-EP-DUR.
           MOVE RAPPF-CLI-ELIG-BP-DUR
                                  TO MIR-CLI-ELIG-BP-DUR.

           PERFORM  9210-DATA-LINES
               THRU 9210-DATA-LINES-X
                    VARYING WS-SUB FROM 1 BY 1
                        UNTIL WS-SUB GREATER 6.

           PERFORM  9220-REFUSE-LINES
               THRU 9220-REFUSE-LINES-X
                    VARYING WS-SUB FROM 1 BY 1
                        UNTIL WS-SUB GREATER 2.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
       9210-DATA-LINES.

           MOVE L5850-CLI-OINS-CO-NM (WS-SUB)
                                  TO MIR-CLI-OINS-CO-NM-T (WS-SUB).
           MOVE L5850-OINS-INFC-PEND-CD (WS-SUB)
                                  TO MIR-OINS-INFC-PEND-CD-T (WS-SUB).
           MOVE L5850-OINS-THIS-CO-IND (WS-SUB)
                                  TO MIR-OINS-THIS-CO-IND-T (WS-SUB).
           MOVE L5850-OINS-BUS-PERS-CD (WS-SUB)
                                  TO MIR-OINS-BUS-PERS-CD-T (WS-SUB).
           MOVE L5850-DI-OINS-INS-TYP-CD (WS-SUB)
                                  TO MIR-DI-OINS-INS-TYP-CD-T (WS-SUB).
557659*    MOVE L5850-OINS-ISS-YR-QTY (WS-SUB)
020874*    MOVE L5850-CLI-OINS-ISS-YR (WS-SUB)
020874*                           TO WS-PIC-4-0.
020874*    MOVE WS-PIC-4-0        TO MIR-CLI-OINS-ISS-YR-T (WS-SUB).
020874     MOVE L5850-CLI-OINS-ISS-YR (WS-SUB) TO L0290-INPUT-V00.
020874     MOVE 0                 TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CLI-OINS-ISS-YR-T (WS-SUB)
020874                            TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA TO MIR-CLI-OINS-ISS-YR-T (WS-SUB).
008455*    MOVE L5850-CLI-OINS-TOT-AMT (WS-SUB)
008455*                           TO WS-PIC-9-0.
008455*    MOVE WS-PIC-9-0        TO MIR-CLI-OINS-TOT-AMT-T (WS-SUB).
008455     MOVE L5850-CLI-OINS-TOT-AMT (WS-SUB)
020874*                           TO L0290-INPUT-NUMBER.
020874                            TO L0290-INPUT-V00.
008455     PERFORM  9350-FORMAT-HFACE-T
008455         THRU 9350-FORMAT-HFACE-T-X.
008455*    MOVE L5850-CLI-OINS-ADB-AMT (WS-SUB)
008455*                           TO WS-PIC-6-0.
008455*    MOVE WS-PIC-6-0        TO MIR-CLI-OINS-ADB-AMT-T (WS-SUB).
008455     MOVE L5850-CLI-OINS-ADB-AMT (WS-SUB)
020874*                           TO L0290-INPUT-NUMBER.
020874                            TO L0290-INPUT-V00.
008455     PERFORM  9352-FORMAT-ADDAM-T
008455         THRU 9352-FORMAT-ADDAM-T-X.
           MOVE L5850-DI-OINS-EP-DUR (WS-SUB)
                                  TO MIR-DI-OINS-EP-DUR-T (WS-SUB).
           MOVE L5850-DI-OINS-BP-DUR (WS-SUB)
                                  TO MIR-DI-OINS-BP-DUR-T (WS-SUB).
           MOVE L5850-DI-OINS-TAXBL-CD (WS-SUB)
                                  TO MIR-DI-OINS-TAXBL-CD-T (WS-SUB).
557659*    MOVE L5850-DI-OINS-REPL-CD (WS-SUB)
557659*                           TO MIR-DI-OINS-REPL-IND-T (WS-SUB).
557659     MOVE L5850-DI-OINS-REPL-IND (WS-SUB)
                                  TO MIR-DI-OINS-REPL-IND-T (WS-SUB).

       9210-DATA-LINES-X.
           EXIT.
      /
       9220-REFUSE-LINES.

557659*    MOVE RAPPF-DI-REFUS-YR-QTY (WS-SUB)
020874*    MOVE RAPPF-CLI-DI-REFUS-YR (WS-SUB)
020874*                           TO WS-PIC-4-0
020874*    MOVE WS-PIC-4-0        TO MIR-CLI-DI-REFUS-1-YR-T (WS-SUB).
020874     MOVE RAPPF-CLI-DI-REFUS-YR (WS-SUB) TO L0290-INPUT-V00.
020874     MOVE 0                 TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CLI-DI-REFUS-1-YR-T (WS-SUB)
020874                            TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA TO MIR-CLI-DI-REFUS-1-YR-T (WS-SUB).
           MOVE RAPPF-DI-REFUS-CO-NM (WS-SUB)
                                  TO MIR-DI-REFUS-CO-1-NM-T (WS-SUB).
           MOVE RAPPF-DI-REFUS-CO-IND (WS-SUB)
                                  TO MIR-DI-REFUS-CO-1-IND-T (WS-SUB).
           MOVE RAPPF-DI-REFUS-TXT (WS-SUB)
                                  TO MIR-DI-REFUS-1-TXT-T (WS-SUB).

       9220-REFUSE-LINES-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *  TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************

       9300-SETUP-MSIN-REFERENCE.

           MOVE SPACES            TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
                                  TO WGLOB-REF-COMPANY-CODE.
           MOVE 'C'               TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-CLI-ID        TO WGLOB-REF-CLIENT-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
008455 9350-FORMAT-HFACE-T.
008455     MOVE 0                 TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CLI-OINS-TOT-AMT-T (WS-SUB)
                                  TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-CLI-OINS-TOT-AMT-T (WS-SUB).
008455 9350-FORMAT-HFACE-T-X.
008455     EXIT.
008455/
008455 9352-FORMAT-ADDAM-T.
008455     MOVE 0                 TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CLI-OINS-ADB-AMT-T (WS-SUB)
                                  TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-CLI-OINS-ADB-AMT-T (WS-SUB).
008455 9352-FORMAT-ADDAM-T-X.
008455     EXIT.
008455/
008455 9354-FORMAT-ELGAM.
008455     MOVE 0                 TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DI-ELIG-AMT
                                  TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-DI-ELIG-AMT.
008455 9354-FORMAT-ELGAM-X.
008455     EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5850-0000-INIT-PARM-INFO
025970         THRU 5850-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WS-COUNTERS.
025970     INITIALIZE                         WS-SWITCHES.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-MAX-WRITE           TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.
025970     MOVE SPACES                       TO WWKDT-WORK-FIELDS.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
008455/
      ****************************************************************
      * PROCESSING COPYBOOKS
      ****************************************************************
      *
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPESTB2.
       COPY CCPESTB3.
      /
025970 COPY XCPS8090.
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0620.
      /
018764*COPY CCCL5600.
018764 COPY CCPL5600.
       COPY CCPS5600.
      /
018764*COPY NCCL2437.
025970 COPY NCPS2437.
018764 COPY NCPL2437.
      /
018764*COPY NCCL5850.
025970 COPY NCPS5850.
018764 COPY NCPL5850.
       COPY NCPERRES.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  HOUSEKEEPING
      *****************************************************************
       COPY XCPPINIT.
       COPY XCPPEXIT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CLI
014221                         '$VAR2' BY 'CLI'.
      /
      *****************************************************************
      *  LINK TO COPYBOOKS
      *****************************************************************
025970 COPY XCPS0280.
       COPY XCPL0280.
025970 COPY XCPS1640.
       COPY XCPL1640.
008455 COPY XCPL0290.
008455 COPY XCPS0290.
      /
      *****************************************************************
      *  MESSAGE PROCESSING MODULES
      *****************************************************************
012624*COPY XCPPMEXT.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY NCPAAPPF.
       COPY NCPCAPPF.
       COPY NCPNAPPF.
       COPY NCPUAPPF.
014221 COPY CCPNCLI.
014221 COPY CCPUCLI.
       COPY CCPNEDIT.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM NSOM2250                     **
      *****************************************************************

