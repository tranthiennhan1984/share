      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM6165.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM6165                                         **
      **  REMARKS:  SPIN - SECURITY PERSONAL IDENTIFICATION NUMBER.  **
      **                                                             **
      **            THIS MODULE WILL CONTROL THE MAINTENANCE AND     **
      **            RESET PROCESSING OF PERSONAL IDENTIFICATION      **
      **            NUMBER IN CLIENT INFORMATION (CLI).              **
      **                                                             **
      **            FOR MAINTENANCE (M) : CHANGE PIN FROM DEFAULT    **
      **                                  VALUE.                     **
      **                RESET (R)       : RESET PIN TO DEFAULT VALUE **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557667**  5.5       ORIGINAL - INGENIUM RELEASE 5.5                  **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       CODE CLEAN-UP                                    **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       MESSAGE SUPPORT - REMOVAL OF XCPPMEXT            **
015508**  6.0       CLIENT ENHANCEMENT FOR JAPAN                     **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017104**  6.3       JAPANESE DISPLAYED NAME CHANGES                  **
018732**  6.3       CLIENT RETRIEVAL ENHANCEMENTS                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM6165'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT                 VALUE '1080'.

       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID                    VALUE '1080'
                                                             '1081'
                                                             '1082'.
               88  WS-BUS-FCN-RETRIEVE                 VALUE '1080'.
               88  WS-BUS-FCN-RESET                    VALUE '1081'.
               88  WS-BUS-FCN-UPDATE                   VALUE '1082'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '1080'.
           05  WS-SPACE-SW                  PIC X(01).
               88  WS-SPACE-FOUND                      VALUE 'Y'.
               88  WS-SPACE-NOT-FOUND                  VALUE 'N'.
           05  WS-EMBEDDED-SW               PIC X(01).
               88  WS-EMBEDDED-OK                      VALUE 'Y'.
               88  WS-EMBEDDED-NOT-OK                  VALUE 'N'.
           05  WS-PIN                       PIC X(06).
           05  WS-PIN-R REDEFINES WS-PIN    PIC X(01) OCCURS 6 TIMES.
           05  WS-SUR-NAME.
               10  WS-SUR-NM-1-5            PIC X(05).
               10  WS-SUR-NM-REST           PIC X(21).
           05  WS-FIRST-NAME.
               10  WS-FIRST-NM-INIT         PIC X(01).
               10  WS-FIRST-NM-REST         PIC X(24).
      /
      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
016537*COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      *
016537*COPY XCWEBLCH.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFRCLI.
       COPY CCFWCLI.
      /
020478*COPY CCFRCLNM.
020478*COPY CCFWCLNM.
      /
015508 COPY CCFRCLNC.
015508 COPY CCFWCLNC.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
      * LINKAGE TO NUMERIC VALIDATION MODULE
016537*COPY XCWL0280.
      *
      * LINKAGE TO SCREEN NAME REFORMATTING
       COPY CCWL0620.
028298 COPY CCWL2626.
020478/
020478 COPY CCWL2435.
      *
      * LINKAGE TO UTILITY TO COMPRESS EMBEDDED SPACES OF A WORD
       COPY XCWL0015.
014221* LINKAGE TO TWRK FOR LOGICAL LOCKING
014221 COPY XCWL8090.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************
      * COMM AREA
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM6165.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           SET MIR-RETRN-OK             TO  TRUE.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.


           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *--------------------
       2000-PROCESS-REQUEST.
      *---------------------
      *
      *    NORMAL PROCESSING: CHECK SECURITY PERMISSION & DISTRIBUTE
      *    CONTROL TO APPROPRIATE PROCESSING ROUTINE.
      *
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

      * MOVE ENTER CODE TO A WORK FIELD FOR SECURITY CEHECKING

           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           IF  WGLOB-MSG-ERROR-SW > ZERO OR
               NOT WGLOB-GOOD-RETURN
               SET WGLOB-RETURN-ERROR     TO  TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  7000-GET-CLIENT-INFO
               THRU 7000-GET-CLIENT-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO OR
               NOT WGLOB-GOOD-RETURN
               SET WGLOB-RETURN-ERROR     TO  TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

      *
      * CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-RESET
                    PERFORM  6000-PROCESS-RESET
                        THRU 6000-PROCESS-RESET-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE 'XS00000237'         TO  WGLOB-MSG-REF-INFO
                    MOVE MIR-BUS-FCN-ID       TO  WGLOB-MSG-PARM (1)
                    MOVE 'CSOM6165'           TO  WGLOB-MSG-PARM (2)
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST     TO  TRUE
                    SET WGLOB-RETURN-ERROR TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *--------------------
       3000-PROCESS-RETRIEVE.
      *--------------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           MOVE RCLI-CLI-PIN-ID   TO  MIR-CLI-PIN-ID.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *-------------------
       5000-PROCESS-UPDATE.
      *-------------------

           PERFORM  8000-SET-UP-PIN
               THRU 8000-SET-UP-PIN-X.

      *
      *    MAINTAIN CAN ONLY BE DONE WHEN PIN = DEFAULT VALUE
      *    THAT IS THE FIRST INTIAL AND FIRST 5 CHARACTERS OF
      *    THE CLIENT SURNAME.

           IF RCLI-CLI-PIN-ID NOT = WS-PIN
              MOVE 'CS61650002'       TO  WGLOB-MSG-REF-INFO
      *    MSG: PIN CANNOT BE CHANGED EXCEPT EQUAL TO DEFAULT VALUE
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
017104        PERFORM  9200-MOVE-RECORD-TO-SCREEN
017104            THRU 9200-MOVE-RECORD-TO-SCREEN-X
              GO TO 5000-PROCESS-UPDATE-X
           END-IF.

      *
      * VALIDATE THE INPUT PIN NUMBER
      *
           IF MIR-CLI-PIN-ID = SPACES
               MOVE RCLI-CLI-PIN-ID   TO  WS-PIN
           ELSE
               MOVE MIR-CLI-PIN-ID    TO  WS-PIN
           END-IF.

           PERFORM  5210-VALIDATE-PIN
               THRU 5210-VALIDATE-PIN-X.

           IF WS-EMBEDDED-NOT-OK
              MOVE 'CS61650007'       TO  WGLOB-MSG-REF-INFO
      *    MSG: NO EMBEDDED SPACE IS ALLOWED FOR THE PIN CODE
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              PERFORM  9200-MOVE-RECORD-TO-SCREEN
                  THRU 9200-MOVE-RECORD-TO-SCREEN-X
              GO TO 5000-PROCESS-UPDATE-X
           END-IF.

      *
      *    IF THE PIN EQUAL TO DEFAULT, NEW PIN PASSWORD SHOULD
      *    BE ENTERED
           IF WS-PIN = RCLI-CLI-PIN-ID
              MOVE 'CS61650003'       TO  WGLOB-MSG-REF-INFO
      *    MSG: NEW PIN PASSWORD SHOULD BE ENTERED
              SET WGLOB-RETURN-ERROR      TO  TRUE
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              PERFORM  9200-MOVE-RECORD-TO-SCREEN
                  THRU 9200-MOVE-RECORD-TO-SCREEN-X
              GO TO 5000-PROCESS-UPDATE-X
           END-IF.

010311*    INITIALIZE                     WCLI-IO-WORK-AREA.
           INITIALIZE                     RCLI-REC-INFO.
           MOVE MIR-CLI-ID            TO  RCLI-CLI-ID.
           MOVE MIR-CLI-ID            TO  WCLI-CLI-ID.

014221*    PERFORM  CLI-1000-READ-FOR-UPDATE
014221*        THRU CLI-1000-READ-FOR-UPDATE-X.
014221     PERFORM  CLI-2000-UPDATE-TWRK-TS
014221         THRU CLI-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'CLI'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WCLI-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF WCLI-IO-NOT-FOUND
              MOVE 'CS61650001'       TO  WGLOB-MSG-REF-INFO
      *    MSG: CLIENT (@) NOT FOUND
              MOVE WCLI-CLI-ID        TO  WGLOB-MSG-PARM (1)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              PERFORM  9100-BLANK-DATA-FIELDS
                  THRU 9100-BLANK-DATA-FIELDS-X
              GO TO 5000-PROCESS-UPDATE-X
           END-IF.

      *    WRITE OUT THE CLIENT RECORD

           PERFORM  7100-UPDATE-CLIENT-PIN
               THRU 7100-UPDATE-CLIENT-PIN-X.

           IF  WGLOB-MSG-ERROR-SW NOT = ZEROS OR
               NOT WGLOB-GOOD-RETURN
               MOVE 'XS00000008'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'CS61650004'      TO WGLOB-MSG-REF-INFO
      *  MSG: PIN WAS MAINTAINED SUCCESSFULLY
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *-----------------
       5210-VALIDATE-PIN.
      *-----------------

           SET WS-EMBEDDED-OK             TO  TRUE.
           SET WS-SPACE-NOT-FOUND         TO  TRUE.

           PERFORM
              VARYING WS-SUB FROM +1 BY +1
              UNTIL WS-SUB > +6 OR
                    NOT WS-EMBEDDED-OK
              IF WS-PIN-R (WS-SUB) = SPACES
                 SET WS-SPACE-FOUND         TO  TRUE
              ELSE
                 IF WS-SPACE-FOUND
                    SET WS-EMBEDDED-NOT-OK  TO  TRUE
                 END-IF
              END-IF
           END-PERFORM.

       5210-VALIDATE-PIN-X.
           EXIT.
      /
      *------------------
       6000-PROCESS-RESET.
      *------------------

           PERFORM  8000-SET-UP-PIN
               THRU 8000-SET-UP-PIN-X.

      *
      *    RESET CAN ONLY BE USED WHEN PIN NOT EQUAL TO DEFAULT VALUE
      *    THAT IS THE FIRST INTIAL AND FIRST 5 CHARACTERS OF
      *    THE CLIENT SURNAME.
      *

           IF RCLI-CLI-PIN-ID = WS-PIN
              MOVE 'CS61650005'       TO  WGLOB-MSG-REF-INFO
      *    MSG: PIN EQUAL DEFAULT VALUE, MAINTAIN FUNCTION SHOULD BE
      *         USED.
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 6000-PROCESS-RESET-X
           END-IF.

010311*    INITIALIZE                     WCLI-IO-WORK-AREA.
           INITIALIZE                     RCLI-REC-INFO.
           MOVE MIR-CLI-ID            TO  WCLI-CLI-ID.
           MOVE MIR-CLI-ID            TO  RCLI-CLI-ID.

014221*    PERFORM  CLI-1000-READ-FOR-UPDATE
014221*        THRU CLI-1000-READ-FOR-UPDATE-X.
014221     PERFORM  CLI-2000-UPDATE-TWRK-TS
014221         THRU CLI-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'CLI'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WCLI-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 6000-PROCESS-RESET-X
014221     END-IF.
           
           IF WCLI-IO-NOT-FOUND
              MOVE 'CS61650001'       TO  WGLOB-MSG-REF-INFO
      *    MSG: CLIENT (@) NOT FOUND
              MOVE WCLI-CLI-ID        TO  WGLOB-MSG-PARM (1)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              PERFORM  9100-BLANK-DATA-FIELDS
                  THRU 9100-BLANK-DATA-FIELDS-X
              GO TO 6000-PROCESS-RESET-X
           END-IF.

           MOVE WS-PIN                TO MIR-CLI-PIN-ID.
      *
      *    WRITE OUT THE CLIENT RECORD

           PERFORM  7100-UPDATE-CLIENT-PIN
               THRU 7100-UPDATE-CLIENT-PIN-X.
      *
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           IF  WGLOB-MSG-ERROR-SW NOT = ZEROS OR
               NOT WGLOB-GOOD-RETURN
               MOVE 'XS00000008'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'CS61650006'      TO WGLOB-MSG-REF-INFO
      *  MSG: PIN WAS RESET SUCCESSFULLY
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       6000-PROCESS-RESET-X.
           EXIT.
      /
      *---------------------
       7000-GET-CLIENT-INFO.
      *---------------------

010311*    INITIALIZE                     WCLI-IO-WORK-AREA.
           INITIALIZE                     RCLI-REC-INFO.
           MOVE MIR-CLI-ID            TO  WCLI-CLI-ID.
           MOVE MIR-CLI-ID            TO  RCLI-CLI-ID.

014221*    PERFORM  CLI-1000-READ
014221*        THRU CLI-1000-READ-X.
014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

           IF WCLI-IO-NOT-FOUND
              MOVE 'CS61650001'       TO  WGLOB-MSG-REF-INFO
      *    MSG: CLIENT (@) NOT FOUND
              MOVE WCLI-CLI-ID        TO  WGLOB-MSG-PARM (1)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
015508        GO TO 7000-GET-CLIENT-INFO-X
           END-IF.

015508     IF WGLOB-COUNTRY-JAPAN
020478*       SET WCLNM-CLI-INDV-GR-KATAKANA   TO  TRUE
015508        SET WCLNC-CLI-CO-GR-KATAKANA     TO  TRUE
015508     ELSE
020478*       SET WCLNM-CLI-INDV-GR-ALPHA      TO  TRUE
015508        SET WCLNC-CLI-CO-GR-ALPHA        TO  TRUE
015508     END-IF.

020478*    MOVE '001'                      TO  WCLNM-CLI-INDV-SEQ-NUM.
020478*    SET WCLNM-CLI-INDV-NM-TYP-CRNT      TO  TRUE.
015508     SET WCLNC-CLI-CO-NM-TYP-CLI         TO  TRUE.

015508     IF RCLI-CLI-SEX-COMPANY
015508        MOVE RCLI-CLI-ID                 TO  WCLNC-CLI-ID
015508        PERFORM  CLNC-1000-READ
015508            THRU CLNC-1000-READ-X
015508        IF  NOT WCLNC-IO-OK
018732*           MOVE 'CS61650008'       TO  WGLOB-MSG-REF-INFO
015508* MSG: CLIENT COMPANY NAME NOT FOUND
018732*           MOVE WCLNC-CLI-ID       TO  WGLOB-MSG-PARM (1)
018732*           PERFORM  0260-1000-GENERATE-MESSAGE
018732*               THRU 0260-1000-GENERATE-MESSAGE-X
018732*           GO TO 7000-GET-CLIENT-INFO-X
018732            PERFORM  7110-RETRY-CLIENT-INFO
018732                THRU 7110-RETRY-CLIENT-INFO-X
015508        END-IF
015508     ELSE
020478*       MOVE RCLI-CLI-ID                TO  WCLNM-CLI-ID
020478*       PERFORM  CLNM-1000-READ
020478*           THRU CLNM-1000-READ-X
020478        PERFORM  2435-1000-BUILD-PARM-INFO
020478            THRU 2435-1000-BUILD-PARM-INFO-X
020478        MOVE RCLI-CLI-ID                TO L2435-CLI-ID
020478        PERFORM  2435-2000-CRNT-CLI-NAME
020478            THRU 2435-2000-CRNT-CLI-NAME-X

020478        IF  NOT L2435-RETRN-OK
020478            MOVE 'CS61650009'       TO  WGLOB-MSG-REF-INFO
020478* MSG: CLIENT NAME NOT FOUND
020478            MOVE RCLI-CLI-ID        TO  WGLOB-MSG-PARM (1)
020478            PERFORM  0260-1000-GENERATE-MESSAGE
020478                THRU 0260-1000-GENERATE-MESSAGE-X
020478        END-IF
020478*       IF  NOT WCLNM-IO-OK
018732*           MOVE 'CS61650009'       TO  WGLOB-MSG-REF-INFO
015508* MSG: CLIENT NAME NOT FOUND
018732*           MOVE WCLNM-CLI-ID       TO  WGLOB-MSG-PARM (1)
018732*           PERFORM  0260-1000-GENERATE-MESSAGE
018732*               THRU 0260-1000-GENERATE-MESSAGE-X
018732*           GO TO 7000-GET-CLIENT-INFO-X
020478*           PERFORM  7110-RETRY-CLIENT-INFO
020478*               THRU 7110-RETRY-CLIENT-INFO-X
020478*       END-IF
015508     END-IF.

       7000-GET-CLIENT-INFO-X.
           EXIT.
      /
      *----------------------
       7100-UPDATE-CLIENT-PIN.
      *----------------------

            MOVE MIR-CLI-PIN-ID       TO  RCLI-CLI-PIN-ID.

            PERFORM  CLI-2000-REWRITE
                THRU CLI-2000-REWRITE-X.
                
014221      PERFORM  CLI-1000-READ-TWRK-TS
014221          THRU CLI-1000-READ-TWRK-TS-X.

       7100-UPDATE-CLIENT-PIN-X.
           EXIT.
      /
018732*---------------------
018732 7110-RETRY-CLIENT-INFO.
018732*---------------------
018732
018732
018732     IF WGLOB-COUNTRY-JAPAN
020478*       SET WCLNM-CLI-INDV-GR-ALPHA       TO  TRUE
018732        SET WCLNC-CLI-CO-GR-ALPHA         TO  TRUE
018732     ELSE
020478*       SET WCLNM-CLI-INDV-GR-KATAKANA    TO  TRUE
018732        SET WCLNC-CLI-CO-GR-KATAKANA      TO  TRUE
018732     END-IF.
018732
020478*    MOVE '001'                      TO  WCLNM-CLI-INDV-SEQ-NUM.
020478*    SET WCLNM-CLI-INDV-NM-TYP-CRNT      TO  TRUE.
018732     SET WCLNC-CLI-CO-NM-TYP-CLI         TO  TRUE.
018732
018732     IF RCLI-CLI-SEX-COMPANY
018732        MOVE RCLI-CLI-ID                 TO  WCLNC-CLI-ID
018732        PERFORM  CLNC-1000-READ
018732            THRU CLNC-1000-READ-X
018732        IF  NOT WCLNC-IO-OK
018732            MOVE 'CS61650008'       TO  WGLOB-MSG-REF-INFO
018732* MSG: CLIENT COMPANY NAME NOT FOUND
018732            MOVE WCLNC-CLI-ID       TO  WGLOB-MSG-PARM (1)
018732            PERFORM  0260-1000-GENERATE-MESSAGE
018732                THRU 0260-1000-GENERATE-MESSAGE-X
018732            GO TO 7110-RETRY-CLIENT-INFO-X
018732        END-IF
020478*    ELSE
020478*       MOVE RCLI-CLI-ID                TO  WCLNM-CLI-ID
020478*       PERFORM  CLNM-1000-READ
020478*           THRU CLNM-1000-READ-X
020478*       IF  NOT WCLNM-IO-OK
020478*           MOVE 'CS61650009'       TO  WGLOB-MSG-REF-INFO
020478* MSG: CLIENT NAME NOT FOUND
020478*           MOVE WCLNM-CLI-ID       TO  WGLOB-MSG-PARM (1)
020478*           PERFORM  0260-1000-GENERATE-MESSAGE
020478*               THRU 0260-1000-GENERATE-MESSAGE-X
020478*           GO TO 7110-RETRY-CLIENT-INFO-X
020478*       END-IF
018732     END-IF.
018732
018732 7110-RETRY-CLIENT-INFO-X.
018732     EXIT.
018732/
      *----------------
       8000-SET-UP-PIN.
      *----------------

015508*    MOVE RCLI-CLI-SUR-NM       TO  WS-SUR-NAME.
015508*    MOVE RCLI-CLI-GIV-NM       TO  WS-FIRST-NAME.

015508     IF RCLI-CLI-SEX-COMPANY
015508        MOVE RCLNC-CLI-CO-NM    TO  WS-SUR-NAME
015508        MOVE SPACES             TO  WS-FIRST-NAME
015508     ELSE
020478*       MOVE RCLNM-CLI-INDV-SUR-NM   TO  WS-SUR-NAME
020478*       MOVE RCLNM-CLI-INDV-GIV-NM   TO  WS-FIRST-NAME
020478        MOVE L2435-CLI-SUR-NM   TO  WS-SUR-NAME
020478        MOVE L2435-CLI-GIV-NM   TO  WS-FIRST-NAME
015508     END-IF.
      *
      *    COMPRESS LAST NAME, TAKE OUT ALL SPACES
      *
           MOVE SPACES                TO  L0015-COMP-AREA-IN.
           MOVE SPACES                TO  L0015-COMP-AREA-OUT.
           MOVE WS-SUR-NAME           TO  L0015-COMP-AREA-IN-FIRST.
           MOVE SPACES                TO  L0015-COMP-AREA-IN-LAST.
           PERFORM  0015-2000-COMPRESS-NO-BLANKS
               THRU 0015-2000-COMPRESS-NO-BLANKS-X.

           MOVE L0015-COMP-AREA-OUT   TO  WS-SUR-NAME.

      *
      *    COMPRESS FIRST NAME, TAKE OUT ALL SPACES
      *
           MOVE SPACES                TO  L0015-COMP-AREA-IN.
           MOVE SPACES                TO  L0015-COMP-AREA-OUT.
           MOVE WS-FIRST-NAME         TO  L0015-COMP-AREA-IN-FIRST.
           MOVE SPACES                TO  L0015-COMP-AREA-IN-LAST.
           PERFORM  0015-2000-COMPRESS-NO-BLANKS
               THRU 0015-2000-COMPRESS-NO-BLANKS-X.

           MOVE L0015-COMP-AREA-OUT   TO  WS-FIRST-NAME.

      *
      *    COMPRESS FIRST 5 CHARACTER OF LAST NAME +
      *             FIRST 1 CHARACTER OF FIRST NAME
      *
           MOVE SPACES                TO  L0015-COMP-AREA-IN.
           MOVE SPACES                TO  L0015-COMP-AREA-OUT.
           MOVE WS-SUR-NM-1-5         TO  L0015-COMP-AREA-IN-FIRST.
           MOVE WS-FIRST-NM-INIT      TO  L0015-COMP-AREA-IN-LAST.

           PERFORM  0015-2000-COMPRESS-NO-BLANKS
               THRU 0015-2000-COMPRESS-NO-BLANKS-X.

           MOVE L0015-COMP-AREA-OUT   TO  WS-PIN.

       8000-SET-UP-PIN-X.
           EXIT.
      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO  MIR-DV-OWN-CLI-NM.
           MOVE SPACES                TO  MIR-CLI-PIN-ID.
           MOVE SPACES                TO  MIR-CLI-PIN-RESET-TXT.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE SPACES                    TO  MIR-CLI-PIN-ID.
           MOVE RCLI-CLI-PIN-RESET-TXT    TO  MIR-CLI-PIN-RESET-TXT.

      *
      *    MOVE RCLI-INFORMATION TO L0620 LINKAGE
      *    REFORMAT THE SCREEN NAME UISNG 0620 MODULE
      *

           IF RCLI-CLI-SEX-COMPANY
015508*       MOVE RCLI-CLI-ENTR-CO-NM               TO  L0620-CLI-CO-NM
015508        MOVE RCLNC-CLI-CO-ENTR-NM              TO  L0620-CLI-CO-NM
           ELSE
015508*       MOVE RCLI-CLI-ENTR-GIV-NM
020478*       MOVE RCLNM-ENTR-GIV-NM
020478        MOVE L2435-CLI-ENTR-GIV-NM
                                      TO  L0620-CLI-GIV-NM
015508*       MOVE RCLI-CLI-ENTR-SUR-NM
020478*       MOVE RCLNM-ENTR-SUR-NM
020478        MOVE L2435-CLI-ENTR-SUR-NM
                                      TO  L0620-CLI-SUR-NM
           END-IF.
           MOVE RCLI-CLI-SEX-CD       TO  L0620-CLI-SEX-CD.
           MOVE SPACES                TO  L0620-CLI-MID-INIT-NM.
           MOVE SPACES                TO  L0620-CLI-SFX-NM.

           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.

           MOVE L0620-SCREEN-NAME     TO  MIR-DV-OWN-CLI-NM.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------
      * MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      * TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'C'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-CLI-ID            TO WGLOB-REF-CLIENT-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0015-0000-INIT-PARM-INFO
025970         THRU 0015-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-TWRK-KEY-DEFAULT    TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ******************************************************************
      *                      PROCESSING COPYBOOKS                      *
      ******************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CLI
014221                         '$VAR2' BY 'CLI'.
      /
      ******************************************************************
      *                      LINK COPYBOOKS                            *
      ******************************************************************
025970 COPY XCPS8090.
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0620.
020478/
020478 COPY CCPS2435.
020478 COPY CCPL2435.
025970 COPY XCPS0015.
       COPY XCPL0015.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      ******************************************************************
      *                     FILE HANDLING COPYBOOKS                    *
      ******************************************************************
016537*COPY CCPACLI.
       COPY CCPNCLI.
       COPY CCPUCLI.
      /
020478*COPY CCPNCLNM.
015508 COPY CCPNCLNC.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM6165                     **
      *****************************************************************
