      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3050.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3050                                         **
      **  REMARKS:  PROCESS DRIVER FOR PNFO                          **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
010304**  5.6       NEW PROGRAM.                                     **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
012522**  6.3       MONTHIVERSARY PROCESSING FOR INVESTMENTS (6.1.1E)**
015795**  6.3       INCREASE NUMBER OF OCCURS FOR PNFO               **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3050'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.
014221 COPY XCWL8090.


       01  WS-PGM-WORK-AREA.
           05  WS-EDIT-CHECKS.
               10  WS-BUS-FCN-ID            PIC X(04).
                   88  WS-BUS-FCN-RETRIEVE  VALUE '0820'.
                   88  WS-BUS-FCN-CREATE    VALUE '0821'.
                   88  WS-BUS-FCN-UPDATE    VALUE '0822'.
                   88  WS-BUS-FCN-DELETE    VALUE '0823'.
                   88  WS-BUS-FCN-LIST      VALUE '0824'.
               10  WS-NFO-CODE              PIC X(01).
012522*            88  VALID-NFO-CODE    VALUE '0' '2' '3' '4' '5' '6'.
012522             88  VALID-NFO-CODE    VALUE '0' '2' '3' '4' '5' '6'
012522                                         '7'.
               10  WS-DEFAULT               PIC X(01).
                   88  WS-DEFAULT-VALID     VALUE 'Y', 'N'.
               10  WS-EDIT-ERRORS-SW        PIC X(01).
                   88  WS-EDIT-ERRORS       VALUE 'Y'.
                   88  WS-NO-EDIT-ERRORS    VALUE 'N'.
014221     05  WS-TWRK-KEY                  PIC X(04)
014221                                      VALUE '0820'.
025970         88 WS-TWRK-KEY-DEFAULT          VALUE '0820'.

           05  WS-SAVE-DEFAULT              PIC X(01).

016548*    05  WS-SUB                       PIC S9(04) COMP.
016548     05  WS-SUB                       PIC S9(04) BINARY.
016548*    05  WS-MAX-LINES                 PIC S9(04) COMP
015795*    05  WS-MAX-LINES                 PIC S9(04) BINARY
015795*                                         VALUE +12.
015795     05  WS-MAX-LINES                 PIC S9(04) BINARY
015795                                          VALUE +100.
025970         88 WS-MAX-LINES-DEFAULT          VALUE +100.
016548*    05  WS-NBR-OF-DEFAULTS           PIC S9(02) COMP.
016548     05  WS-NBR-OF-DEFAULTS           PIC S9(02) BINARY.
           05  WS-PLAN-ID                   PIC X(06).

      /
       COPY XCWEBLCH.
014221/
014221 COPY CCWWLOCK.
      /
       COPY CCFWPNFO.
       COPY CCFRPNFO.
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
016537*COPY XCWWWKDT.

      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3050.

      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /

      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           SET  MIR-RETRN-OK       TO TRUE.
           MOVE MIR-BUS-FCN-ID     TO WS-BUS-FCN-ID.
      *
      * PROCESS SCREEN FUNCTIONS

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM 3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM 4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM 5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM 6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST  TO TRUE


           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /

      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------
      *
      * READ PNFO FILE FOR SPECIFIC RECORD AND DISPLAY               *
      *

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  7100-BUILD-PNFO-KEY
               THRU 7100-BUILD-PNFO-KEY-X.

014221     MOVE MIR-PLAN-ID       TO WPH-PLAN-ID
014221     PERFORM PH-1000-READ-TWRK-TS
014221        THRU PH-1000-READ-TWRK-TS-X
014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221        MOVE WPH-PLAN-ID    TO WGLOB-MSG-PARM (1)
014221        MOVE 'PH'           TO WGLOB-MSG-PARM (2)
014221        MOVE 'XS00000001'   TO WGLOB-MSG-REF-INFO
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 3000-PROCESS-RETRIEVE-X
014221     END-IF.

           PERFORM  PNFO-1000-READ
               THRU PNFO-1000-READ-X.

           IF  WPNFO-IO-NOT-FOUND
               MOVE WPNFO-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *------------------
       3500-PROCESS-LIST.
      *------------------

      *
      *  EDIT AND PROCESS THE ENTER CODE FIELD
      *
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           MOVE LOW-VALUES            TO WPNFO-KEY.
           MOVE HIGH-VALUES           TO WPNFO-ENDBR-KEY.

           MOVE MIR-PLAN-ID           TO WPNFO-PLAN-ID.
           MOVE WPNFO-PLAN-ID         TO WPNFO-ENDBR-PLAN-ID.
           MOVE MIR-LOC-GR-ID         TO WPNFO-LOC-GR-ID.
           MOVE MIR-PLAN-NFO-CD       TO WPNFO-PLAN-NFO-CD.

           PERFORM  PNFO-1000-BROWSE
               THRU PNFO-1000-BROWSE-X.

           IF  WPNFO-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM  PNFO-2000-READ-NEXT
               THRU PNFO-2000-READ-NEXT-X.

           IF  WPNFO-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           MOVE +1                    TO WS-SUB.

           PERFORM  3600-PNFO-INQ-READ
               THRU 3600-PNFO-INQ-READ-X
               UNTIL (WS-SUB  > WS-MAX-LINES)
               OR   WPNFO-IO-EOF.

           IF  WPNFO-IO-EOF
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE RPNFO-LOC-GR-ID   TO MIR-LOC-GR-ID
               MOVE RPNFO-PLAN-NFO-CD TO MIR-PLAN-NFO-CD
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  PNFO-3000-END-BROWSE
               THRU PNFO-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *-------------------
       3600-PNFO-INQ-READ.
      *-------------------

           MOVE RPNFO-LOC-GR-ID       TO MIR-LOC-GR-ID-T (WS-SUB).
           MOVE RPNFO-PLAN-NFO-CD     TO MIR-PLAN-NFO-CD-T (WS-SUB).
           MOVE RPNFO-PLAN-NFO-DFLT-IND
                                   TO MIR-PLAN-NFO-DFLT-IND-T (WS-SUB).
           ADD  +1                         TO WS-SUB.

           PERFORM  PNFO-2000-READ-NEXT
               THRU PNFO-2000-READ-NEXT-X.

       3600-PNFO-INQ-READ-X.
           EXIT.
      /

      *--------------------
       4000-PROCESS-CREATE.
      *--------------------
      *
      * CREATE NEW PNFO RECORD.  THE RECORD IS CREATED WITH THE
      * KEY FIELDS ENTERED.  THE REMAINING DATA WILL BE UPDATED VIA
      * THE MAINTAIN SCREEN.
      *

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  7100-BUILD-PNFO-KEY
               THRU 7100-BUILD-PNFO-KEY-X.

           PERFORM  PNFO-1000-READ
               THRU PNFO-1000-READ-X.

           IF  WPNFO-IO-OK
               MOVE WPNFO-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  4100-CREATE-EDITS
               THRU 4100-CREATE-EDITS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  7100-BUILD-PNFO-KEY
               THRU 7100-BUILD-PNFO-KEY-X.

           PERFORM  PNFO-1000-CREATE
               THRU PNFO-1000-CREATE-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  PNFO-1000-WRITE
               THRU PNFO-1000-WRITE-X.

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM PNFO-1000-CALL-AUDIT
                  THRU PNFO-1000-CALL-AUDIT-X
           END-IF.

014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-1000-READ-TWRK-TS
014221        THRU PH-1000-READ-TWRK-TS-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *------------------
       4100-CREATE-EDITS.
      *------------------
      *
      * EDIT INPUT FIELDS.
      *

           MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.

           PERFORM  PH-1000-READ
               THRU PH-1000-READ-X.

           IF  NOT WPH-IO-OK
      * MSG: PLAN MUST BE VALID IN THE PLAN TABLE
               MOVE 'CS30500001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-LOC-GR-ID         TO WEDIT-ETBL-VALU-ID.

           PERFORM  LCGP-1000-EDIT-LCGP-LOCATION
               THRU LCGP-1000-EDIT-LCGP-LOCATION-X.

           IF  NOT WEDIT-IO-OK
      * MSG: LOCATION GROUP MUST BE VALID IN EDIT, TYPE = LOCGP
               MOVE 'CS30500002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-PLAN-NFO-CD       TO WS-NFO-CODE.

           IF  VALID-NFO-CODE
               CONTINUE
           ELSE
      * MSG: NFO OPTION MUST BE VALID
               MOVE 'CS30500003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4100-CREATE-EDITS-X.
           EXIT.
      /

      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------
      *
014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-2000-UPDATE-TWRK-TS
014221        THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (1)
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  7100-BUILD-PNFO-KEY
               THRU 7100-BUILD-PNFO-KEY-X.

           PERFORM  PNFO-1000-READ-FOR-UPDATE
               THRU PNFO-1000-READ-FOR-UPDATE-X.

           IF  WPNFO-IO-OK
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM PNFO-1000-CALL-AUDIT
                      THRU PNFO-1000-CALL-AUDIT-X
               END-IF
           ELSE
014221         PERFORM  PH-3000-UNLOCK
014221             THRU PH-3000-UNLOCK-X
               MOVE WPNFO-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           MOVE RPNFO-PLAN-NFO-DFLT-IND
                                      TO WS-SAVE-DEFAULT.

           PERFORM  5210-EDIT-DATA-FIELDS
               THRU 5210-EDIT-DATA-FIELDS-X.

           IF  WS-NO-EDIT-ERRORS
               PERFORM  5220-CROSS-EDITS
                   THRU 5220-CROSS-EDITS-X
           END-IF.

      *
      * THE WS- FIELD WILL CONTAIN THE CURRENT RECORD VALUE OR THE
      * MIR VALUE IF IT PASSED THE EDITS.
      *
           MOVE WS-SAVE-DEFAULT       TO RPNFO-PLAN-NFO-DFLT-IND.

           PERFORM  PNFO-2000-REWRITE
               THRU PNFO-2000-REWRITE-X.

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM PNFO-1000-CALL-AUDIT
                  THRU PNFO-1000-CALL-AUDIT-X
           END-IF.

014221     PERFORM  PH-2000-REWRITE
014221         THRU PH-2000-REWRITE-X.
014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.


       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *----------------------
       5210-EDIT-DATA-FIELDS.
      *----------------------

           SET WS-NO-EDIT-ERRORS           TO TRUE.

           IF  MIR-PLAN-NFO-DFLT-IND = SPACES
               MOVE WS-SAVE-DEFAULT   TO MIR-PLAN-NFO-DFLT-IND
               GO TO 5210-EDIT-DATA-FIELDS-X
           ELSE
               IF  MIR-PLAN-NFO-DFLT-IND = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-PLAN-NFO-DFLT-IND
               END-IF
           END-IF.

           MOVE MIR-PLAN-NFO-DFLT-IND TO WS-DEFAULT.

           IF  WS-DEFAULT-VALID
               MOVE WS-DEFAULT        TO WS-SAVE-DEFAULT
           ELSE
               SET WS-EDIT-ERRORS          TO TRUE
      * MSG: DEFAULT INDICATOR INVALID - ENTER Y OR N
               MOVE 'CS30500004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5210-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      *-----------------
       5220-CROSS-EDITS.
      *-----------------

           IF  WS-DEFAULT = 'Y'
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               GO TO 5220-CROSS-EDITS-X
           END-IF.

           MOVE LOW-VALUES            TO WPNFO-KEY.
           MOVE MIR-PLAN-ID           TO WPNFO-PLAN-ID.
           MOVE MIR-LOC-GR-ID         TO WPNFO-LOC-GR-ID.
           MOVE WPNFO-KEY             TO WPNFO-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WPNFO-ENDBR-PLAN-NFO-CD.


           PERFORM  PNFO-1000-BROWSE
               THRU PNFO-1000-BROWSE-X.

           PERFORM  PNFO-2000-READ-NEXT
               THRU PNFO-2000-READ-NEXT-X.

           IF  WPNFO-IO-OK
               MOVE ZEROES            TO WS-NBR-OF-DEFAULTS
               PERFORM  5221-COUNT-DEFAULTS
                   THRU 5221-COUNT-DEFAULTS-X
                   UNTIL WPNFO-IO-EOF
               IF  WS-NBR-OF-DEFAULTS > 0
                   MOVE 'N'           TO WS-SAVE-DEFAULT
      *MSG: ONLY ONE NON-FORFEITURE DEFAULT IS ALLOWED PER PLAN/LOCATION
                   MOVE 'CS30500005'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           PERFORM  PNFO-3000-END-BROWSE
               THRU PNFO-3000-END-BROWSE-X.

           MOVE MIR-PLAN-ID           TO RPNFO-PLAN-ID.
           MOVE MIR-LOC-GR-ID         TO RPNFO-LOC-GR-ID.
           MOVE MIR-PLAN-NFO-CD       TO RPNFO-PLAN-NFO-CD.


       5220-CROSS-EDITS-X.
           EXIT.
      /
      *--------------------
       5221-COUNT-DEFAULTS.
      *--------------------

           IF  RPNFO-PLAN-NFO-DFLT-IND = 'Y'
               IF  RPNFO-CO-ID          = WGLOB-COMPANY-CODE
               AND RPNFO-PLAN-ID        = MIR-PLAN-ID
               AND RPNFO-LOC-GR-ID      = MIR-LOC-GR-ID
               AND RPNFO-PLAN-NFO-CD    = MIR-PLAN-NFO-CD
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   ADD +1          TO WS-NBR-OF-DEFAULTS
               END-IF
           END-IF.

           PERFORM  PNFO-2000-READ-NEXT
               THRU PNFO-2000-READ-NEXT-X.

       5221-COUNT-DEFAULTS-X.
           EXIT.
      /
      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-2000-UPDATE-TWRK-TS
014221        THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (1)
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           PERFORM  7100-BUILD-PNFO-KEY
               THRU 7100-BUILD-PNFO-KEY-X.

           PERFORM  PNFO-1000-READ-FOR-UPDATE
               THRU PNFO-1000-READ-FOR-UPDATE-X.

           IF  WPNFO-IO-OK
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM PNFO-1000-CALL-AUDIT
                      THRU PNFO-1000-CALL-AUDIT-X
               END-IF
               PERFORM  PNFO-1000-DELETE
                   THRU PNFO-1000-DELETE-X
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE SPACES            TO MIR-PLAN-NFO-DFLT-IND
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM PNFO-1000-CALL-AUDIT
                      THRU PNFO-1000-CALL-AUDIT-X
               END-IF
014221         PERFORM  PH-2000-REWRITE
014221             THRU PH-2000-REWRITE-X
014221         PERFORM  PH-1000-READ-TWRK-TS
014221             THRU PH-1000-READ-TWRK-TS-X
           ELSE
014221         PERFORM  PH-3000-UNLOCK
014221             THRU PH-3000-UNLOCK-X
               MOVE WPNFO-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *--------------------
       7100-BUILD-PNFO-KEY.
      *--------------------

      *
      * BUILD THE KEY.                                               *

           MOVE MIR-PLAN-ID           TO WPNFO-PLAN-ID.
           MOVE MIR-LOC-GR-ID         TO WPNFO-LOC-GR-ID.
           MOVE MIR-PLAN-NFO-CD       TO WPNFO-PLAN-NFO-CD.


       7100-BUILD-PNFO-KEY-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           IF  WS-BUS-FCN-LIST
               MOVE SPACES            TO MIR-LOC-GR-ID-G
               MOVE SPACES            TO MIR-PLAN-NFO-CD-G
               MOVE SPACES            TO MIR-PLAN-NFO-DFLT-IND-G
           ELSE
               MOVE SPACES            TO MIR-PLAN-NFO-DFLT-IND
           END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /

      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RPNFO-PLAN-NFO-DFLT-IND TO MIR-PLAN-NFO-DFLT-IND.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
025970     SET WS-MAX-LINES-DEFAULT TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY PH
014221                         '$VAR2' BY 'PH'.

       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      ****************************************************************
      * LINKING COPYBOOKS                                            *
      ****************************************************************

018764*COPY CCCLPNFO.
018764 COPY CCPLPNFO.
025970 COPY XCPS8090.
      /
       COPY CCPELCGP.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS
      ****************************************************************

014660*COPY XCPPMEXT.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNPH.
014221 COPY CCPUPH.
       COPY CCPNEDIT.

       COPY CCPAPNFO.
       COPY CCPBPNFO.
       COPY CCPCPNFO.
       COPY CCPNPNFO.
       COPY CCPUPNFO.
       COPY CCPXPNFO.

      *****************************************************************
      **                 END OF PROGRAM CSOM3050                     **
      *****************************************************************
