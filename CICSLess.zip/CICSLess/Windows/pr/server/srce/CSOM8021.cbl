      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM8021.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM8021                                         **
      **  REMARKS:  PROCESS DRIVER FOR COVERAGE CREATE               **
      **            THIS MODULES PERFORMS THE COVERAGE CREATE        **
      **            FUNCTION                                         **
      **                                                             **
      **  DOMAIN :  CV                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       NEW FOR RELEASE 6.0                              **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
014221**  6.2       LOGICAL LOCKING                                  **
014591**  6.2       COMBINE PLAN-ID & RS                             **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEAN UP                                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018633**  6.4       TWRK CLEANUP                                     **
020463**  6.4       INVESTOR PROFILES                                **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
027105**  6.6       99 COVERAGES HANDLING                            **
026766**  6.6       PERFORMANCE MONITORING                           **
027183**  6.7       USER MESSAGE MISSING POLICY SUFFIX               **
027641**  6.7       RESET DEATH BENEFIT CODE TO NONE                 **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
035568**  7.0       INIT COVERAGE WORK AREA                          **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM8021'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

018764*COPY XCWLPTR.

014590*COPY XCWL0030.
       COPY XCWL8090.

       COPY XCWWCVGM.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                     PIC X(04).
               88  WS-BUS-FCN-CREATE             VALUE '8021'.
           05  WS-ERROR-SW                       PIC X(01).
               88  WS-ERROR-FOUND                VALUE 'Y'.
               88  WS-ERROR-FOUND-NONE           VALUE 'N'.


018633*01  WS-TWRK-KEY                     PIC X(04)  VALUE '8020'.
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '8020'.
018633     15  FILLER                       PIC X(01).
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWINDX.
       COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
020463 COPY CCFWPD.
020463 COPY CCFRPD.
      /
021930*COPY CCFWPOIQ.
021930*COPY CCFRPOIP.
021930*
016537*COPY CCFWPH.
016537*COPY CCFRPH.
      /
       COPY CCFWPOL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
016537*COPY XCWLDTLK.
020463/
020478 COPY CCWL2626.
020463 COPY CCWL2735.
      /
       COPY CCWL5400.
      /
       COPY CCWL6170.
      /
016503 COPY CCWL0289.
      /
       COPY CCWLPGA.
      /
       COPY CCFRPOL.
      /
       COPY CCWWCVGS.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM8021.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

018633     PERFORM  COMM-1000-INITIALIZE
018633         THRU COMM-1000-INITIALIZE-X.
018633
034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           SET MIR-RETRN-OK                    TO  TRUE.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-CREATE
                        THRU 2000-CREATE-X

               WHEN OTHER
      *MSG:   INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM8021'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST           TO  TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-CREATE.
      *------------

018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.

           MOVE MIR-POL-ID             TO WPOL-POL-ID.

           PERFORM  2010-INITIAL-SYSTEM-EDITS
               THRU 2010-INITIAL-SYSTEM-EDITS-X.

           IF  WS-ERROR-FOUND
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM CVGS-1000-LOAD-CVGS-ARRAY
              THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

      *
      *  BUILD GENERAL PARM AREA
      *
           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

      *
      *  SET UP THE PLAN HEADER KEY
      *
           PERFORM  2030-COVERAGE-CREATE
               THRU 2030-COVERAGE-CREATE-X.

027641     IF  WS-ERROR-FOUND
027641         PERFORM  POL-3000-UNLOCK
027641             THRU POL-3000-UNLOCK-X
027641         GO TO 2000-CREATE-X
027641     END-IF.

           IF  MIR-RETRN-OK
016503* UPDATE NEXT ACTIVITY INFORMATION
016503         PERFORM  0289-1000-INIT-PARM-INFO
016503             THRU 0289-1000-INIT-PARM-INFO-X
016503         PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503             THRU 0289-1000-OBTAIN-NXT-ACTV-X
016503         IF L0289-RETRN-OK
016503            MOVE L0289-NXT-ACTV-TYP-CD
016503                        TO RPOL-NXT-ACTV-TYP-CD
016503            MOVE L0289-NXT-ACTV-DT
016503                        TO RPOL-POL-NXT-ACTV-DT
016503         ELSE
016503            MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
016503            MOVE WGLOB-PROCESS-DATE
016503                        TO RPOL-POL-NXT-ACTV-DT
016503         END-IF
               PERFORM  POL-2000-REWRITE
                   THRU POL-2000-REWRITE-X

014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X

               IF RPOL-POL-CVG-REC-CTR-N > ZERO
                   PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
                      THRU  CVGR-1000-REWRITE-CVGS-ARRAY-X
               END-IF
           END-IF.

       2000-CREATE-X.
           EXIT.

      /
      *--------------------------
       2010-INITIAL-SYSTEM-EDITS.
      *--------------------------

           SET WS-ERROR-FOUND-NONE     TO TRUE.
      *
      * DETERMINE IF THE POLICY EXISTS
      *
014221*    PERFORM  POL-1000-READ-FOR-UPDATE
014221*        THRU POL-1000-READ-FOR-UPDATE-X.
014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221         SET  WS-ERROR-FOUND      TO TRUE
014221        GO TO 2010-INITIAL-SYSTEM-EDITS-X
014221     END-IF.

           IF WPOL-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *MSG: POLICY NOT IN FILE
               MOVE 'CS00000019'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  WS-ERROR-FOUND      TO TRUE
               GO TO 2010-INITIAL-SYSTEM-EDITS-X
           END-IF.

016440*    IF  RPOL-POL-SUSPENDED
016440*    AND RPOL-POL-APPL-CTL-ADMIN
016440*MSG:    POLICY CURRENTLY SUSPENDED - CANNOT MAINTAIN OR PROCESS
016440*        MOVE 'XS00000240'         TO WGLOB-MSG-REF-INFO
016440*        PERFORM  0260-1000-GENERATE-MESSAGE
016440*            THRU 0260-1000-GENERATE-MESSAGE-X
016440*        IF  WGLOB-MSG-SEVRTY-FATAL
016440*            SET  WS-ERROR-FOUND      TO TRUE
016440*            GO TO 2010-INITIAL-SYSTEM-EDITS-X
016440*        END-IF
016440*    END-IF.
      *
      *  POLICY CONTROL CHECK
      *
           PERFORM  5400-1000-BUILD-PARM-INFO
              THRU  5400-1000-BUILD-PARM-INFO-X.
016440     SET L5400-POL-XFER-UPDATE       TO TRUE.
           PERFORM  5400-1000-POL-CHK
              THRU  5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
016440     OR  L5400-XFER-ACCS-RESTRICTED
           OR  NOT L5400-RETRN-OK
               SET  WS-ERROR-FOUND      TO TRUE
               GO TO 2010-INITIAL-SYSTEM-EDITS-X
           END-IF.

014591*    IF  RPOL-PLAN-ID-BASE       NOT > SPACES
014591     IF  RPOL-PLAN-ID NOT > SPACES
      *MSG: COVERAGE CANNOT BE CREATED WITHOUT A BASE POLICY PLAN
               MOVE 'CS80210002'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  WS-ERROR-FOUND      TO TRUE
               GO TO 2010-INITIAL-SYSTEM-EDITS-X
           END-IF.

020463     PERFORM  2735-1000-BUILD-PARM-INFO
020463         THRU 2735-1000-BUILD-PARM-INFO-X.
020463     MOVE  RPOL-POL-ID   TO L2735-POL-ID.
020463     PERFORM  2735-1000-GET-PRFL
020463         THRU 2735-1000-GET-PRFL-X.
020463
020463     IF L2735-RETRN-PRFL-FND
020463         PERFORM  2020-CHECK-PLAN-FUND-PROFILE
020463             THRU 2020-CHECK-PLAN-FUND-PROFILE-X
020463         IF WS-ERROR-FOUND
020463*MSG: COVERAGE CANNOT BE CREATED WHEN A PROFILE EXISTS
020463             MOVE 'CS80210003'    TO WGLOB-MSG-REF-INFO
020463             PERFORM  0260-1000-GENERATE-MESSAGE
020463                 THRU 0260-1000-GENERATE-MESSAGE-X
020463             GO TO 2010-INITIAL-SYSTEM-EDITS-X
020463         END-IF
020463     END-IF.

       2010-INITIAL-SYSTEM-EDITS-X.
           EXIT.
      /
      *-----------------------------
020463 2020-CHECK-PLAN-FUND-PROFILE.
      *-----------------------------

020463     MOVE MIR-PLAN-ID            TO WPD-PLAN-ID.

020463     PERFORM  PDIN-1000-PLAN-DEFAULTS-IN
020463         THRU PDIN-1000-PLAN-DEFAULTS-IN-X.

020463* ALLOW ADDITION OF SIDE FUNDS, RISK ONLY, RRIF AND LCF
020463     IF RPD-PLAN-FND-TYP-SIDE
020463     OR RPD-PLAN-INS-TYP-UL-INS-ONLY
020463     OR RPD-PLAN-INS-TYP-RRIF
020463     OR (RPD-PLAN-FND-TYP-NONE AND RPD-PLAN-COLFND)
020463         CONTINUE
020463     ELSE
020463         SET WS-ERROR-FOUND      TO TRUE
020463     END-IF.

020463 2020-CHECK-PLAN-FUND-PROFILE-X.
020463     EXIT.
      /
      *---------------------
       2030-COVERAGE-CREATE.
      *---------------------

           PERFORM 6170-1000-BUILD-PARM-INFO
              THRU 6170-1000-BUILD-PARM-INFO-X.

           MOVE MIR-PLAN-ID            TO L6170-PLAN-ID.

           IF RPOL-POL-CVG-REC-CTR-N = ZERO
               MOVE RPOL-PLAN-ID       TO L6170-PLAN-ID
           END-IF.

           SET L6170-DEFAULT-INSURED   TO TRUE.

027105*    COMPUTE L6170-CVG-NUM = RPOL-POL-CVG-REC-CTR-N + 1.
027105*
027105*    MOVE L6170-CVG-NUM TO I.
027105*
027105     COMPUTE I = RPOL-POL-CVG-REC-CTR-N + 1.
027105
027105*    IF L6170-CVG-NUM > WCVGM-MAX-WCVGS-NUM
027105     IF  I > WCVGM-MAX-WCVGS-NUM
      *MSG: CANNOT CREATE COVERAGE - MAX COVERAGES @1 REACHED
               MOVE WCVGM-MAX-WCVGS-NUM TO  WGLOB-MSG-PARM (1)
               MOVE 'CS80210001'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  WS-ERROR-FOUND      TO TRUE
               GO TO 2030-COVERAGE-CREATE-X
           END-IF.

027105     MOVE I                           TO L6170-CVG-NUM.
027105
           PERFORM 6170-1000-DEFAULT-CVG
              THRU 6170-1000-DEFAULT-CVG-X.

           IF  L6170-RETRN-ERROR
               SET  WS-ERROR-FOUND       TO TRUE
027641         SET  MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 2030-COVERAGE-CREATE-X
           END-IF.

           MOVE RPOL-POL-CVG-REC-CTR-N   TO MIR-CVG-NUM.
           MOVE RPOL-POL-CVG-REC-CTR-N   TO I.

       2030-COVERAGE-CREATE-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

            MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
            MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
            MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
027183*     MOVE MIR-POL-ID            TO WGLOB-REF-POLICY-NUMBER.
027183      MOVE MIR-POL-ID            TO WGLOB-REF-POLICY-ID.
            MOVE MIR-CVG-NUM           TO WGLOB-REF-COVERAGE-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2735-0000-INIT-PARM-INFO
025970         THRU 2735-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6170-0000-INIT-PARM-INFO
025970         THRU 6170-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
035568     INITIALIZE WCVGS-WORK-AREA.
025970     MOVE SPACES                  TO WWKDT-WORK-FIELDS.
025970
025970     MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
018633*--------------------
018633*9500-BUILD-TWRK-KEY.
018633*--------------------
018633*
018633*    MOVE WS-TWRK-KEY               TO  L8090-BUS-FCN-ID.
018633*    MOVE ZEROS                     TO  L8090-TEMP-WRK-SEQ-NUM.
018633*    SET  L8090-USAGE-COMM          TO TRUE.
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*-----------------
018633*9900-DELETE-TWRK.
018633*-----------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-3000-DELETE-TWRK
018633*        THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
020463 COPY CCPPPDIN.
      /
       COPY NCPPCVGR.
       COPY NCPPCVGS.
      /
034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      /
018633 COPY XCPSCOMM.
018633 COPY XCPPCOMM.
018633
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      /
014660*COPY XCPPMEXT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
020463 COPY CCPS2735.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
020463 COPY CCPL2735.
020463/
018764*COPY CCCL5400.
018764 COPY CCPL5400.
       COPY CCPS5400.
      /
018764*COPY CCCL6170.
018764 COPY CCPL6170.
       COPY CCPS6170.
      /
018764*COPY CCCL0289.
018764 COPY CCPL0289.
016503 COPY CCPS0289.
      /
       COPY CCPSPGA.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
018764*COPY XCCL8090.
018633 COPY XCPS8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
014221 COPY CCPNPOL.
       COPY CCPUPOL.
      /
       COPY CCPNCVG.
      /
       COPY CCPUCVG.
      /
020463 COPY CCPNPD.
      /
016537*COPY CCPNPH.
      /
016537*COPY CCPCPH.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM8021                     **
      *****************************************************************
