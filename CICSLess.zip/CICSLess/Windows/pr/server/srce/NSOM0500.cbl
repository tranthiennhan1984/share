      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM0500.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM0500                                         **
      **  REMARKS:  UWAS - MAINTAIN UNDERWRITING ASSIGNMENTS TABLE.  **
      **            THIS PROGRAM WILL MAINTAIN THE UNDERWRITING      **
      **            CRITERIA FOR THE AUTOMATIC ASSIGNMENT OF         **
      **            UNDERWRITERS TO CLIENTS WHO HAVE FAILED CLEAR    **
      **            CASE TESTING.  DEPENDING ON COMPANY SPECIFICA-   **
      **            TIONS ON PCOM, UNDERWRITERS CAN BE ASSIGNED      **
      **            CASES BASED ON ANY COMBINATION OF CRITERIA       **
      **            SUCH AS LINE OF BUSINESS, BRANCH LOCATION,       **
      **            TOTAL AMOUNT TO BE UNDERWRITTEN, FIRST LETTER    **
      **            OF THE CLIENT'S LAST NAME.                       **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP/STANDARDIZATION                     **
557698**  5.5       MODIFICATIONS TO SUPPORT MIXED-CASE DATA         **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
557973**  5.5       AMOUNT FIELDS SIZE CHANGES                       **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
012624**  6.0       SECURITY                                         **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0500'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

016537*COPY XCWWWKDT.
       COPY XCWEBLCH.
      /
557698 COPY XCWL0005.
557698/
       01  WS-PGM-WORK-AREA.
           05  WS-DATA-EDITS                PIC X(01)  VALUE SPACES.
               88  WS-DATA-EDITS-OK                    VALUE 'Y'.
           05  WS-VALIDATE-CONTROL          PIC X(01)  VALUE SPACES.
               88  WS-INVALID-CONTROL                  VALUE 'Y'.
           05  WS-VALIDATE-AMOUNT           PIC X(01)  VALUE SPACES.
               88  WS-INVALID-AMOUNT                   VALUE 'Y'.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '0500' THRU '0504'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '0500'.
               88  WS-BUS-FCN-CREATE        VALUE '0501'.
               88  WS-BUS-FCN-UPDATE        VALUE '0502'.
               88  WS-BUS-FCN-DELETE        VALUE '0503'.
               88  WS-BUS-FCN-LIST          VALUE '0504'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '0500'.
008455*    05  WS-NUM-9-LEN9                PIC 9(09)  VALUE ZEROS.
025970*    05  WS-NUM-9-13-HIGH             PIC S9(13)
025970*                                     VALUE +9999999999999.
           05  WS-SAVE-CLASS                PIC X      VALUE SPACES.
               88  WS-CLASS-VALID           VALUE 'A' 'E' 'H' 'L'.
025970*    05  WS-LINE                      PIC S9(03) COMP-3
025970*                                     VALUE +1.
025970     05  WS-LINE                      PIC S9(03) COMP-3.
025970         88  WS-DEFAULT-LINE          VALUE +1.
025970*    05  WS-NUMBER-OF-DISPLAY-LINES   PIC S9(03) COMP-3
025970*                                     VALUE +12.
      **** THREE REQUIRED FIELDS FOR INITIALIZING PGA CODED HERE
      **** INSTEAD OF PULLING IN THE POLICY AND COVERAGE FILES
           05  RPOL-POL-ID                  PIC X(10)  VALUE SPACES.
           05  RPOL-POL-BASE-CVG-NUM        PIC 9(02)  VALUE ZERO.
      **** HOLD-RUN-ID IS REQUIRED BY CCPSPGA, THAT'S WHY IT'S HERE.
025970*    05  HOLD-RUN-ID                  PIC X(01)  VALUE '0'.
025970     05  HOLD-RUN-ID                  PIC X(01).
025970         88  WS-DEFAULT-HOLD-RUN-ID              VALUE '0'.

557973 01  WS-WUWAS-KEY.
557973     05  WS-WUWAS-CO-ID                  PIC X(02).
557973     05  WS-WUWAS-UWAR-BUS-CLAS-CD       PIC X(01).
557973     05  WS-WUWAS-BR-ID                  PIC X(05).
008455*    05  WS-WUWAS-UWAR-TCR-AMT           PIC X(09).
008455     05  WS-WUWAS-UWAR-TCR-AMT           PIC 9(13).
557973     05  WS-WUWAS-UWAR-ALPHA-CD          PIC X(01).
025970/
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                 VALUE '0500'.
025970     05  WS-NUM-9-13-HIGH             PIC S9(13).
025970         88  WS-DEFAULT-NUM-9-13-HIGH     VALUE +9999999999999.
025970     05  WS-NUMBER-OF-DISPLAY-LINES   PIC S9(03) COMP-3.
025970         88  WS-DEFAULT-NO-OF-DISPLAY-LINES      VALUE +12.
      /
      ***************************
      * FILE LAYOUT AND WORK AREA
      ***************************
      *
       COPY CCFWBRCH.
       COPY CCFRBRCH.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY CCFWPCOM.
       COPY CCFRPCOM.
      /
       COPY NCFWUWAS.
       COPY NCFRUWAS.
      /
014221 COPY CCWWLOCK.
      *********************
      * WS PARAMATER AREA
      *********************
       COPY XCWL0220.
      /
       COPY XCWL0280.
      /
014221 COPY XCWL8090.
      /
008455 COPY XCWL0290.
008455/
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0500.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.
      *
026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      **********************
       2000-PROCESS-REQUEST.
      **********************

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
025970*    SET MIR-RETRN-OK           TO TRUE.


           IF  MIR-BR-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-BR-ID
           END-IF.

           IF  MIR-UWAR-BUS-CLAS-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-UWAR-BUS-CLAS-CD
           END-IF.

      *
      *    PROCESS SCREEN FUNCTIONS
      *
           IF  WS-BUS-FCN-CREATE
               PERFORM  4000-PROCESS-CREATE
                   THRU 4000-PROCESS-CREATE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.
      *
           PERFORM  7200-CHECK-NUMERIC-KEYS
               THRU 7200-CHECK-NUMERIC-KEYS-X.

           IF WS-INVALID-CONTROL
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM  3500-PROCESS-LIST
                        THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  6000-PROCESS-DELETE
                        THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST
                                      TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------
      *
           PERFORM  7100-BUILD-UWAS-KEY
               THRU 7100-BUILD-UWAS-KEY-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

014221*    PERFORM  UWAS-1000-READ
014221*        THRU UWAS-1000-READ-X.
014221     PERFORM  UWAS-1000-READ-TWRK-TS
014221         THRU UWAS-1000-READ-TWRK-TS-X.
      *
           IF WUWAS-IO-NOT-FOUND
               MOVE 'NS05000001'      TO WGLOB-MSG-REF-INFO
557973*        MOVE WUWAS-KEY         TO WGLOB-MSG-PARM (1)
557973         MOVE WUWAS-CO-ID       TO WS-WUWAS-CO-ID
557973         MOVE WS-WUWAS-KEY      TO WGLOB-MSG-PARM (1)
           ELSE
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
               MOVE +1                TO WS-LINE
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
557660     END-IF.
      *
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *------------------
       3500-PROCESS-LIST.
      *------------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           IF MIR-UWAR-TCR-AMT = SPACES
008455*        MOVE ZEROS             TO WS-NUM-9-LEN9
008455*        MOVE WS-NUM-9-LEN9     TO MIR-UWAR-TCR-AMT
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE ZEROS             TO L0290-INPUT-V00
008455         PERFORM  9250-FORMAT-UAAMT
008455             THRU 9250-FORMAT-UAAMT-X
557660     END-IF.
      *
           PERFORM  7100-BUILD-UWAS-KEY
               THRU 7100-BUILD-UWAS-KEY-X.
      *
           MOVE HIGH-VALUES           TO WUWAS-ENDBR-KEY.
557973     MOVE WS-NUM-9-13-HIGH      TO WUWAS-ENDBR-UWAR-TCR-AMT.
      *
      ***  POSITION AT AND READ FIRST RECORD.
           PERFORM  UWAS-1000-BROWSE
               THRU UWAS-1000-BROWSE-X.

           IF WUWAS-IO-OK
               PERFORM  UWAS-2000-READ-NEXT
                   THRU UWAS-2000-READ-NEXT-X
           ELSE
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
557660     END-IF.

           IF WUWAS-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  UWAS-3000-END-BROWSE
                   THRU UWAS-3000-END-BROWSE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.
      *
      ***  LOAD SCREEN DATA ARRAY.

557660     PERFORM  3550-DISPLAY-RECORD
557660         THRU 3550-DISPLAY-RECORD-X
               VARYING WS-LINE FROM 1 BY 1
               UNTIL (WS-LINE > WS-NUMBER-OF-DISPLAY-LINES)
                  OR (WUWAS-IO-EOF).
      *
      ***  COMPLETION MESSAGE
           IF WUWAS-IO-EOF
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
           ELSE
               SET WGLOB-MORE-DATA-EXISTS
                                      TO TRUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
      ***  IF THE LAST DISPLAY LINE IS BEING FILLED MOVE THE
      ***  RECORD VALUES TO THE CONTROL LINE.

           IF WUWAS-IO-OK
               MOVE RUWAS-UWAR-BUS-CLAS-CD
                                      TO MIR-UWAR-BUS-CLAS-CD
               MOVE RUWAS-BR-ID       TO MIR-BR-ID
008455*        MOVE RUWAS-UWAR-TCR-AMT
008455*                               TO WS-NUM-9-LEN9
008455*        MOVE WS-NUM-9-LEN9     TO MIR-UWAR-TCR-AMT
008455         MOVE RUWAS-UWAR-TCR-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
008455         PERFORM  9250-FORMAT-UAAMT
008455             THRU 9250-FORMAT-UAAMT-X
               MOVE RUWAS-UWAR-ALPHA-CD
                                      TO MIR-UWAR-ALPHA-CD
           END-IF.

      ***  END THE BROWSE.

           PERFORM  UWAS-3000-END-BROWSE
               THRU UWAS-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *****************************************************************
      *  INQUIRY DISPLAY PROCESSING: DISPLAY THE CURRENT RECORD ONTO
      *  THE SCREEN DATA LINE GIVEN BY WS-LINE AND RETRIEVE THE NEXT
      *  RECORD.
      *****************************************************************
      *--------------------
557660 3550-DISPLAY-RECORD.
      *--------------------
      *
           MOVE RUWAS-UWAR-BUS-CLAS-CD
                                    TO MIR-UWAR-BUS-CLAS-CD-T (WS-LINE).
           MOVE RUWAS-BR-ID           TO MIR-BR-ID-T (WS-LINE).
008455*    MOVE RUWAS-UWAR-TCR-AMT    TO WS-NUM-9-LEN9.
008455*    MOVE WS-NUM-9-LEN9         TO MIR-UWAR-TCR-AMT-T (WS-LINE).
020874*    MOVE RUWAS-UWAR-TCR-AMT    TO L0290-INPUT-NUMBER.
020874     MOVE RUWAS-UWAR-TCR-AMT    TO L0290-INPUT-V00.
008455     PERFORM  9255-FORMAT-UAAMT-T
008455         THRU 9255-FORMAT-UAAMT-T-X.
           MOVE RUWAS-UWAR-ALPHA-CD   TO MIR-UWAR-ALPHA-CD-T (WS-LINE).
           MOVE RUWAS-USER-ID         TO MIR-USER-ID-T (WS-LINE).
      *
           PERFORM  UWAS-2000-READ-NEXT
               THRU UWAS-2000-READ-NEXT-X.
      *
557660 3550-DISPLAY-RECORD-X.
           EXIT.
      /
      *--------------------
       4000-PROCESS-CREATE.
      *--------------------
      *
013578*    PERFORM  9100-BLANK-DATA-FIELDS
013578*        THRU 9100-BLANK-DATA-FIELDS-X.
013578*
      ***  VALID CONTROL FIELDS MUST HAVE BEEN ENTERED.

           PERFORM  7000-VALIDATE-CTL-FIELDS
               THRU 7000-VALIDATE-CTL-FIELDS-X.

           IF  WS-INVALID-CONTROL
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.
      *
      ***  BUILD KEY USING CONTROL FIELDS.

           PERFORM  7100-BUILD-UWAS-KEY
               THRU 7100-BUILD-UWAS-KEY-X.
      *
      ***  CHECK RECORD EXISTENCE.

           PERFORM  UWAS-1000-READ
               THRU UWAS-1000-READ-X.

           IF WUWAS-IO-OK
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
557973*        MOVE WUWAS-KEY         TO WGLOB-MSG-PARM (1)
557973         MOVE WUWAS-CO-ID       TO WS-WUWAS-CO-ID
557973         MOVE WS-WUWAS-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.
      *
      ***  CREATE NEW RECORD.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  UWAS-1000-CREATE
               THRU UWAS-1000-CREATE-X.

           PERFORM  UWAS-1000-WRITE
               THRU UWAS-1000-WRITE-X.

014221     PERFORM  UWAS-1000-READ-TWRK-TS
014221         THRU UWAS-1000-READ-TWRK-TS-X.

           MOVE +1                    TO WS-LINE.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------

           PERFORM  7100-BUILD-UWAS-KEY
               THRU 7100-BUILD-UWAS-KEY-X.

014221*    PERFORM  UWAS-1000-READ-FOR-UPDATE
014221*        THRU UWAS-1000-READ-FOR-UPDATE-X.
014221     PERFORM  UWAS-2000-UPDATE-TWRK-TS
014221         THRU UWAS-2000-UPDATE-TWRK-TS-X.
      *
           IF WUWAS-IO-NOT-FOUND
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WUWAS-CO-ID       TO WS-WUWAS-CO-ID
               MOVE WS-WUWAS-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'UWAS'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WUWAS-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.
      *
           PERFORM  7500-EDIT-DATA-FIELDS
               THRU 7500-EDIT-DATA-FIELDS-X.
      *
           IF WS-DATA-EDITS-OK
               PERFORM  UWAS-2000-REWRITE
                   THRU UWAS-2000-REWRITE-X
014221         PERFORM  UWAS-1000-READ-TWRK-TS
014221             THRU UWAS-1000-READ-TWRK-TS-X
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  UWAS-3000-UNLOCK
                   THRU UWAS-3000-UNLOCK-X
557660     END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      *
      *--------------------
       6000-PROCESS-DELETE.
      *--------------------
      *
           PERFORM  7100-BUILD-UWAS-KEY
               THRU 7100-BUILD-UWAS-KEY-X.

014221*    PERFORM  UWAS-1000-READ-FOR-UPDATE
014221*        THRU UWAS-1000-READ-FOR-UPDATE-X.

014221     PERFORM  UWAS-2000-UPDATE-TWRK-TS
014221         THRU UWAS-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'UWAS'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WUWAS-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.
      *
           IF WUWAS-IO-NOT-FOUND
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
557973*        MOVE WUWAS-KEY         TO WGLOB-MSG-PARM (1)
557973         MOVE WUWAS-CO-ID       TO WS-WUWAS-CO-ID
557973         MOVE WS-WUWAS-KEY      TO WGLOB-MSG-PARM (1)
           ELSE
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  UWAS-1000-DELETE
                   THRU UWAS-1000-DELETE-X
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT ADMIN SYSTEM FIELD AGAINST ETAB
      *****************************************************************
       7000-VALIDATE-CTL-FIELDS.
      *
           MOVE 'N'                   TO WS-VALIDATE-CONTROL.
      *
      ***  READ THE COMPANY RECORD FROM THE COMPANY TABLE TO DETERMINE
      ***  WHICH KEY FIELDS ARE REQUIRED.
           MOVE WGLOB-REF-COMPANY-CODE
                                      TO WPCOM-CO-ID.
           PERFORM PCOM-1000-READ
              THRU PCOM-1000-READ-X.
           IF WPCOM-IO-NOT-FOUND
               MOVE 'XS00000053'      TO WGLOB-MSG-REF-INFO
               MOVE 'Y'               TO WS-VALIDATE-CONTROL
               MOVE WPCOM-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-VALIDATE-CTL-FIELDS-X
557660     END-IF.
      *
      ***  VALIDATE LINE OF BUSINESS FIELD.
           PERFORM 7010-VALIDATE-BUSCL-FIELD
              THRU 7010-VALIDATE-BUSCL-FIELD-X.
      *
      ***  VALIDATE BRANCH.
           PERFORM 7020-VALIDATE-BRANCH-FIELD
              THRU 7020-VALIDATE-BRANCH-FIELD-X.
      *
      ***  VALIDATE AMOUNT. IF AMOUNT NOT REQUIRED AND THE USER
      ***  BLANKED OUT THE FIELD, CONVERT THE BLANKS TO ZEROS.
           PERFORM 7030-VALIDATE-AMOUNT-FIELD
              THRU 7030-VALIDATE-AMOUNT-FIELD-X.
      *
      ***  VALIDATE SPLIT FIELD.
           PERFORM 7040-VALIDATE-SPLIT-FIELD
              THRU 7040-VALIDATE-SPLIT-FIELD-X.
      *
       7000-VALIDATE-CTL-FIELDS-X.
           EXIT.
      *
      /
      *****************************************************************
      *  VALIDATE THE LINE OF BUSINESS FIELD.
      *****************************************************************
       7010-VALIDATE-BUSCL-FIELD.
      *
      ***  VALIDATE LINE OF BUSINESS FIELD.
           IF RPCOM-UWAR-LOB-IND = 'Y'
               IF MIR-UWAR-BUS-CLAS-CD = SPACES
                   MOVE 'NS05000003'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'Y'           TO WS-VALIDATE-CONTROL
               ELSE
                   PERFORM 7015-EDIT-BUSCL-FIELD
                       THRU 7015-EDIT-BUSCL-FIELD-X
557660         END-IF
           ELSE
               IF MIR-UWAR-BUS-CLAS-CD NOT = SPACES
                   MOVE 'NS05000004'  TO WGLOB-MSG-REF-INFO
                   MOVE MIR-UWAR-BUS-CLAS-CD
                                      TO WGLOB-MSG-PARM (1)
                   MOVE SPACES        TO WUWAS-UWAR-BUS-CLAS-CD
                   MOVE SPACES        TO MIR-UWAR-BUS-CLAS-CD
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                       MOVE 'Y'       TO WS-VALIDATE-CONTROL
557660         END-IF
557660     END-IF.
      *
       7010-VALIDATE-BUSCL-FIELD-X.
           EXIT.
      *
      /
      *****************************************************************
      *  EDIT CONTROL FIELDS (LINE OF BUSINESS - LOB)
      *****************************************************************
       7015-EDIT-BUSCL-FIELD.
      *
      ***  VALIDATE LOB AGAINST EDIT TABLE.
           MOVE MIR-UWAR-BUS-CLAS-CD  TO WEDIT-ETBL-VALU-ID.

           PERFORM CLAS-1000-EDIT-CLASS
              THRU CLAS-1000-EDIT-CLASS-X.

           IF WEDIT-IO-NOT-FOUND
               MOVE 'NS05000012'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VALIDATE-CONTROL
557660     END-IF.
      *
       7015-EDIT-BUSCL-FIELD-X.
           EXIT.
      *
      /
      *****************************************************************
      *  EDIT BRANCH FIELD.
      *****************************************************************
       7020-VALIDATE-BRANCH-FIELD.
      *
      ***  VALIDATE BRANCH.
           IF RPCOM-UWAR-SERV-BR-IND = 'Y'
               IF MIR-BR-ID = SPACES
                   MOVE 'NS05000005'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'Y'           TO WS-VALIDATE-CONTROL
               ELSE
                   PERFORM 7025-EDIT-BRANCH-FIELD
                       THRU 7025-EDIT-BRANCH-FIELD-X
557660         END-IF
           ELSE
               IF MIR-BR-ID NOT = SPACES
                   MOVE 'NS05000006'  TO WGLOB-MSG-REF-INFO
                   MOVE MIR-BR-ID     TO WGLOB-MSG-PARM (1)
                   MOVE SPACES        TO WUWAS-BR-ID
                   MOVE SPACES        TO MIR-BR-ID
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   IF WGLOB-MSG-SEVRTY-WARNING
034802*                NEXT SENTENCE
034802                 CONTINUE
                   ELSE
                       MOVE 'Y'       TO WS-VALIDATE-CONTROL
557660             END-IF
557660         END-IF
557660     END-IF.
      *
       7020-VALIDATE-BRANCH-FIELD-X.
           EXIT.
      *
      /
      *****************************************************************
      *  EDIT CONTROL FIELDS: (BRANCH)
      *****************************************************************
       7025-EDIT-BRANCH-FIELD.
      *
      *
      *  VALIDATE BRANCH AGAINST BRCH TABLE
      *
           MOVE MIR-BR-ID             TO WBRCH-BR-ID.
           PERFORM  BRCH-1000-READ
               THRU BRCH-1000-READ-X.
           IF WBRCH-IO-NOT-FOUND
      *MSG: 'BRANCH CODE MUST BE IN BRCH TABLE'
               MOVE 'XS00000078'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VALIDATE-CONTROL
557660     END-IF.
      *
       7025-EDIT-BRANCH-FIELD-X.
           EXIT.
      *
      /
      *
      *****************************************************************
      *  VALIDATE THE NUMERIC AMOUNT KEY FIELD.
      *****************************************************************
       7030-VALIDATE-AMOUNT-FIELD.
      *
      ***  VALIDATE AMOUNT. IF AMOUNT NOT REQUIRED AND THE USER
      ***  BLANKED OUT THE FIELD, CONVERT THE BLANKS TO ZEROS.
016537*    IF RPCOM-UWAR-TCR-AMT-IND = 'Y'
016537*        IF MIR-UWAR-TCR-AMT = ZEROS
016537*            MOVE 'NS05000007'  TO WGLOB-MSG-REF-INFO
016537*            PERFORM 0260-1000-GENERATE-MESSAGE
016537*               THRU 0260-1000-GENERATE-MESSAGE-X
016537*            MOVE 'Y'           TO WS-VALIDATE-CONTROL
016537*        ELSE
016537*            PERFORM 7035-EDIT-AMOUNT-FIELD
016537*               THRU 7035-EDIT-AMOUNT-FIELD-X
016537*        END-IF
016537*    ELSE
016537*        IF MIR-UWAR-TCR-AMT = SPACES
008455*            MOVE ZEROS         TO WS-NUM-9-LEN9
008455*            MOVE WS-NUM-9-LEN9 TO MIR-UWAR-TCR-AMT
016537*            MOVE 0             TO L0290-INPUT-NUMBER
016537*            PERFORM  9250-FORMAT-UAAMT
016537*                THRU 9250-FORMAT-UAAMT-X
016537*        ELSE
016537*            IF MIR-UWAR-TCR-AMT NOT = ZEROS
016537*                MOVE 'NS05000008'
016537*                               TO WGLOB-MSG-REF-INFO
016537*                MOVE MIR-UWAR-TCR-AMT
016537*                               TO WGLOB-MSG-PARM (1)
008455*                MOVE ZEROS     TO WS-NUM-9-LEN9
008455*                MOVE WS-NUM-9-LEN9
008455*                               TO WUWAS-UWAR-TCR-AMT
008455*                MOVE WS-NUM-9-LEN9
008455*                               TO MIR-UWAR-TCR-AMT
016537*                MOVE 0         TO L0290-INPUT-NUMBER
016537*                PERFORM  9250-FORMAT-UAAMT
016537*                    THRU 9250-FORMAT-UAAMT-X
016537*                MOVE 0         TO WUWAS-UWAR-TCR-AMT
016537*                PERFORM 0260-1000-GENERATE-MESSAGE
016537*                   THRU 0260-1000-GENERATE-MESSAGE-X
016537*                IF WGLOB-MSG-SEVRTY-WARNING
016537*                    NEXT SENTENCE
016537*                ELSE
016537*                    MOVE 'Y'   TO WS-VALIDATE-CONTROL
016537*                END-IF
016537*            END-IF
016537*        END-IF
016537*    END-IF.
016537*
016537     EVALUATE TRUE
016537     WHEN RPCOM-UWAR-TCR-AMT-IND = 'Y'
016537          IF  MIR-UWAR-TCR-AMT = ZEROS
016537              MOVE 'NS05000007'  TO WGLOB-MSG-REF-INFO
016537              PERFORM 0260-1000-GENERATE-MESSAGE
016537                 THRU 0260-1000-GENERATE-MESSAGE-X
016537              MOVE 'Y'           TO WS-VALIDATE-CONTROL
016537          ELSE
016537              PERFORM 7035-EDIT-AMOUNT-FIELD
016537                 THRU 7035-EDIT-AMOUNT-FIELD-X
016537          END-IF
016537
016537     WHEN MIR-UWAR-TCR-AMT = SPACES
020874*         MOVE 0             TO L0290-INPUT-NUMBER
020874          MOVE ZEROS         TO L0290-INPUT-V00
016537          PERFORM  9250-FORMAT-UAAMT
016537              THRU 9250-FORMAT-UAAMT-X
016537
016537     WHEN MIR-UWAR-TCR-AMT NOT = ZEROS
016537          MOVE 'NS05000008'
016537                         TO WGLOB-MSG-REF-INFO
016537          MOVE MIR-UWAR-TCR-AMT
016537                         TO WGLOB-MSG-PARM (1)
020874*         MOVE 0             TO L0290-INPUT-NUMBER
020874          MOVE ZEROS         TO L0290-INPUT-V00
016537          PERFORM  9250-FORMAT-UAAMT
016537              THRU 9250-FORMAT-UAAMT-X
016537          MOVE 0         TO WUWAS-UWAR-TCR-AMT
016537          PERFORM 0260-1000-GENERATE-MESSAGE
016537             THRU 0260-1000-GENERATE-MESSAGE-X
016537          IF WGLOB-MSG-SEVRTY-WARNING
034802*             NEXT SENTENCE
034802              CONTINUE
016537          ELSE
016537              MOVE 'Y'   TO WS-VALIDATE-CONTROL
016537          END-IF
016537
016537     END-EVALUATE.
      *
       7030-VALIDATE-AMOUNT-FIELD-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT CONTROL FIELDS: ASSIGN AMOUNT
      *****************************************************************
       7035-EDIT-AMOUNT-FIELD.
      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '0'                   TO L0280-PRECISION.
008455*    MOVE '9'                   TO L0280-LENGTH.
008455*    MOVE '9'                   TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-UWAR-TCR-AMT
008455                                TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
      *
      ***  PERFORM NUMERIC EDIT ON AMOUNT.
           MOVE MIR-UWAR-TCR-AMT      TO L0280-INPUT-DATA.
           MOVE 'N'                   TO WS-VALIDATE-AMOUNT.
           PERFORM 7800-NUMERIC-EDIT
              THRU 7800-NUMERIC-EDIT-X.
           IF L0280-OK
008455*        MOVE L0280-OUTPUT      TO WS-NUM-9-LEN9
008455*        MOVE WS-NUM-9-LEN9     TO MIR-UWAR-TCR-AMT
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
008455         PERFORM  9250-FORMAT-UAAMT
008455             THRU 9250-FORMAT-UAAMT-X
           ELSE
               MOVE 'NS05000014'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VALIDATE-CONTROL
557660     END-IF.
      *
       7035-EDIT-AMOUNT-FIELD-X.
           EXIT.
      *
      /
      *****************************************************************
      *  EDIT ADMIN SYSTEM FIELD AGAINST ETAB
      *****************************************************************
       7040-VALIDATE-SPLIT-FIELD.
      *
      ***  VALIDATE SPLIT FIELD.
           IF RPCOM-UWAR-ALPHA-IND = 'Y'
               IF MIR-UWAR-ALPHA-CD = SPACES
                   MOVE 'NS05000009'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'Y'           TO WS-VALIDATE-CONTROL
               ELSE
                   PERFORM 7045-EDIT-SPLIT-FIELD
                      THRU 7045-EDIT-SPLIT-FIELD-X
557660         END-IF
           ELSE
               IF MIR-UWAR-ALPHA-CD NOT = SPACES
                   MOVE 'NS05000010'  TO WGLOB-MSG-REF-INFO
                   MOVE MIR-UWAR-ALPHA-CD
                                      TO WGLOB-MSG-PARM (1)
                   MOVE SPACES        TO WUWAS-UWAR-ALPHA-CD
                   MOVE SPACES        TO MIR-UWAR-ALPHA-CD
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   IF WGLOB-MSG-SEVRTY-WARNING
034802*                NEXT SENTENCE
034802                 CONTINUE
                   ELSE
                       MOVE 'Y'       TO WS-VALIDATE-CONTROL
557660             END-IF
557660         END-IF
557660     END-IF.
      *
       7040-VALIDATE-SPLIT-FIELD-X.
           EXIT.
      *
      /
      *****************************************************************
      *  EDIT CONTROL FIELDS: ALPHA-SPLIT
      *****************************************************************
       7045-EDIT-SPLIT-FIELD.
      *
      ***  MUST BE A LETTER WITH NO ACCENTS.
557698     PERFORM  0005-1000-BUILD-PARM-INFO
557698         THRU 0005-1000-BUILD-PARM-INFO-X.
557698     MOVE MIR-UWAR-ALPHA-CD     TO L0005-INPUT-STRING.
557698     PERFORM  0005-2000-CONVERT-NO-ACCENTS
557698         THRU 0005-2000-CONVERT-NO-ACCENTS-X.
557698*    IF MIR-UWAR-ALPHA-CD NOT ALPHABETIC
557698     IF L0005-RETRN-OK
557698       IF L0005-OUTPUT-STRING NOT ALPHABETIC
               MOVE 'NS05000015'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VALIDATE-CONTROL
557698       END-IF
557698     ELSE
557698       IF MIR-UWAR-ALPHA-CD NOT ALPHABETIC
557698         MOVE 'NS05000015'      TO WGLOB-MSG-REF-INFO
557698         PERFORM 0260-1000-GENERATE-MESSAGE
557698            THRU 0260-1000-GENERATE-MESSAGE-X
557698         MOVE 'Y'               TO WS-VALIDATE-CONTROL
557698       END-IF
557660     END-IF.
      *
       7045-EDIT-SPLIT-FIELD-X.
           EXIT.
      *
      *
      *****************************************************************
      *  BUILD UWAS KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
      *****************************************************************
       7100-BUILD-UWAS-KEY.
      *
           MOVE MIR-UWAR-BUS-CLAS-CD  TO WUWAS-UWAR-BUS-CLAS-CD.
           MOVE MIR-BR-ID             TO WUWAS-BR-ID.
557973*    MOVE MIR-UWAR-TCR-AMT      TO WUWAS-UWAR-TCR-AMT.
008455*    MOVE MIR-UWAR-TCR-AMT      TO WS-NUM-9-LEN9.
008455*    MOVE WS-NUM-9-LEN9         TO WUWAS-UWAR-TCR-AMT.
008455     MOVE MIR-UWAR-TCR-AMT      TO L0280-INPUT-DATA.
008455     MOVE 'N'                   TO L0280-SIGN-IND.
008455     MOVE 0                     TO L0280-PRECISION.
008455     MOVE LENGTH OF MIR-UWAR-TCR-AMT
008455                                TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH  =  L0280-INPUT-SIZE.
008455     PERFORM  7800-NUMERIC-EDIT
008455         THRU 7800-NUMERIC-EDIT-X.
008455     MOVE L0280-OUTPUT          TO WUWAS-UWAR-TCR-AMT.
           MOVE MIR-UWAR-ALPHA-CD     TO WUWAS-UWAR-ALPHA-CD.
557973*
557973*  BUILD DISPLAY WUWAS-KEY FIELD FOR ERROR MESSAGE
557973*
557973     MOVE MIR-UWAR-BUS-CLAS-CD  TO WS-WUWAS-UWAR-BUS-CLAS-CD.
557973     MOVE MIR-BR-ID             TO WS-WUWAS-BR-ID.
008455*    MOVE MIR-UWAR-TCR-AMT      TO WS-WUWAS-UWAR-TCR-AMT.
008455     MOVE L0280-OUTPUT          TO WS-WUWAS-UWAR-TCR-AMT.
557973     MOVE MIR-UWAR-ALPHA-CD     TO WS-WUWAS-UWAR-ALPHA-CD.
      *
       7100-BUILD-UWAS-KEY-X.
           EXIT.
      /
      *
      *****************************************************************
      *  FORMAT NUMERIC KEY FIELDS: ASSIGN AMOUNT IS FORMATTED.
      *****************************************************************
       7200-CHECK-NUMERIC-KEYS.
      *
           MOVE 'N'                   TO WS-VALIDATE-CONTROL.
      *
      ***  READ THE COMPANY RECORD FROM THE COMPANY TABLE TO DETERMINE
      ***  WHICH KEY FIELDS ARE REQUIRED.
           MOVE WGLOB-REF-COMPANY-CODE
                                      TO WPCOM-CO-ID.
           PERFORM PCOM-1000-READ
              THRU PCOM-1000-READ-X.

           IF WPCOM-IO-NOT-FOUND
               MOVE 'XS00000053'      TO WGLOB-MSG-REF-INFO
               MOVE 'Y'               TO WS-VALIDATE-CONTROL
               MOVE WPCOM-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660*        GO TO 7000-VALIDATE-CTL-FIELDS-X
557660         GO TO 7200-CHECK-NUMERIC-KEYS-X
557660     END-IF.
      *
      ***  VALIDATE AMOUNT. IF AMOUNT NOT REQUIRED AND THE USER
      ***  BLANKED OUT THE FIELD, CONVERT THE BLANKS TO ZEROS.
           IF MIR-UWAR-TCR-AMT = SPACES
008455*        MOVE ZEROS             TO WS-NUM-9-LEN9
008455*        MOVE WS-NUM-9-LEN9     TO MIR-UWAR-TCR-AMT
008455         MOVE ZEROS             TO MIR-UWAR-TCR-AMT
557660     END-IF.

           PERFORM 7035-EDIT-AMOUNT-FIELD
              THRU 7035-EDIT-AMOUNT-FIELD-X.
      *
       7200-CHECK-NUMERIC-KEYS-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT DATA FIELDS ACCORDING TO THE DATA DICTIONARY
      *****************************************************************
       7500-EDIT-DATA-FIELDS.
      *
           MOVE 'Y'                   TO WS-DATA-EDITS.
      *
           PERFORM  7510-EDIT-INITIALS
               THRU 7510-EDIT-INITIALS-X.
      *
       7500-EDIT-DATA-FIELDS-X.
           EXIT.
      *
      /
      *****************************************************************
      *  USERID: MUST EXIST ON USER PROFILE TABLE.
      *****************************************************************
       7510-EDIT-INITIALS.
      *
           IF MIR-USER-ID-T (1) = SPACES
               MOVE RUWAS-USER-ID     TO MIR-USER-ID-T (1)
               GO TO 7510-EDIT-INITIALS-X
           ELSE
               IF MIR-USER-ID-T (1) = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-USER-ID-T (1)
557660         END-IF
557660     END-IF.
      *
           MOVE MIR-USER-ID-T (1)     TO L0220-USER-ID.
           MOVE WGLOB-COMPANY-CODE    TO L0220-COMPANY-CODE.

           PERFORM  0220-1000-VERIFY-USER-ID
               THRU 0220-1000-VERIFY-USER-ID-X.

           IF L0220-USER-OK
               MOVE MIR-USER-ID-T (1) TO RUWAS-USER-ID
           ELSE
               MOVE 'NS05000016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.
      *
       7510-EDIT-INITIALS-X.
           EXIT.
      *
      /
       7800-NUMERIC-EDIT.
      *
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               GO TO 7800-NUMERIC-EDIT-X
557660     END-IF.
      *
           IF L0280-ARGS-INVALID
               MOVE 'XS00000020'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7800-NUMERIC-EDIT-X
557660     END-IF.
      *
       7800-NUMERIC-EDIT-X.
           EXIT.
      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
       9100-BLANK-DATA-FIELDS.
      *
           PERFORM  9110-BLANK-DISPLAY-LINES
               THRU 9110-BLANK-DISPLAY-LINES-X
               VARYING WS-LINE FROM 1 BY 1
               UNTIL (WS-LINE > WS-NUMBER-OF-DISPLAY-LINES).
      *
       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *****************************************************************
      *  SET EACH DISPLAY LINE TO BLANKS
      *****************************************************************
       9110-BLANK-DISPLAY-LINES.
      *
           MOVE SPACES              TO MIR-UWAR-BUS-CLAS-CD-T (WS-LINE).
           MOVE SPACES                TO MIR-BR-ID-T (WS-LINE).
           MOVE SPACES                TO MIR-UWAR-TCR-AMT-T (WS-LINE).
           MOVE SPACES                TO MIR-UWAR-ALPHA-CD-T (WS-LINE).
           MOVE SPACES                TO MIR-USER-ID-T (WS-LINE).
      *
       9110-BLANK-DISPLAY-LINES-X.
           EXIT.
      *
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
       9200-MOVE-RECORD-TO-SCREEN.
      *
           MOVE RUWAS-UWAR-BUS-CLAS-CD
                                    TO MIR-UWAR-BUS-CLAS-CD-T (WS-LINE).
           MOVE RUWAS-BR-ID           TO MIR-BR-ID-T (WS-LINE).
008455*    MOVE RUWAS-UWAR-TCR-AMT    TO WS-NUM-9-LEN9.
008455*    MOVE WS-NUM-9-LEN9         TO MIR-UWAR-TCR-AMT-T (WS-LINE).
020874*    MOVE RUWAS-UWAR-TCR-AMT    TO L0290-INPUT-NUMBER.
020874     MOVE RUWAS-UWAR-TCR-AMT    TO L0290-INPUT-V00.
008455     PERFORM  9255-FORMAT-UAAMT-T
008455         THRU 9255-FORMAT-UAAMT-T-X.
           MOVE RUWAS-UWAR-ALPHA-CD   TO MIR-UWAR-ALPHA-CD-T (WS-LINE).
           MOVE RUWAS-USER-ID         TO MIR-USER-ID-T (WS-LINE).
      *
           ADD +1 TO WS-LINE.
      *
       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
008455*****************************************************************
008455*  NUMERIC FORMAT OF MIR-UWAR-TCR-AMT
008455*****************************************************************
008455 9250-FORMAT-UAAMT.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-UWAR-TCR-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-UWAR-TCR-AMT.
008455 9250-FORMAT-UAAMT-X.
008455     EXIT.
008455/
008455*****************************************************************
008455*  NUMERIC FORMAT OF MIR-UWAR-TCR-AMT-T
008455*****************************************************************
008455 9255-FORMAT-UAAMT-T.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-UWAR-TCR-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-UWAR-TCR-AMT-T (WS-LINE).
008455 9255-FORMAT-UAAMT-T-X.
008455     EXIT.
008455/
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
       9300-SETUP-MSIN-REFERENCE.
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
      *
       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0005-0000-INIT-PARM-INFO
025970         THRU 0005-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0220-0000-INIT-PARM-INFO
025970         THRU 0220-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WS-WUWAS-KEY.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-LINE                TO TRUE.
025970     SET WS-DEFAULT-NUM-9-13-HIGH       TO TRUE.
025970     SET WS-DEFAULT-HOLD-RUN-ID         TO TRUE.
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-NO-OF-DISPLAY-LINES TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************

026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
      /
025970 COPY XCPS8090.
       COPY CCPSPGA.
      /
       COPY CCPECLAS.
      /
       COPY XCPPINIT.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY UWAS
014221                         '$VAR2' BY 'UWAS'.
      /
      ****************************************************************
      * LINK COPYBOOKS                                               *
      ****************************************************************

018764*COPY XCCL0220.
025970 COPY XCPS0220.
018764 COPY XCPL0220.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
008455 COPY XCPL0290.
008455 COPY XCPS0290.
008455
557698 COPY XCPS0005.
557698/
557698 COPY XCPL0005.
557698/
      ****************************************************************
      * MESSAGE COPYBOOKS                                            *
      ****************************************************************

018764*COPY XCCL0260.
018764 COPY XCPL0260.

012624*COPY XCPPMEXT.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
      *
       COPY CCPNBRCH.
      /
       COPY CCPNEDIT.
      /
       COPY CCPNPCOM.
      /
       COPY NCPAUWAS.
      /
       COPY NCPBUWAS.
      /
       COPY NCPNUWAS.
      /
       COPY NCPUUWAS.
      /
       COPY NCPXUWAS.
      /
       COPY NCPCUWAS.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM0500                     **
      *****************************************************************

