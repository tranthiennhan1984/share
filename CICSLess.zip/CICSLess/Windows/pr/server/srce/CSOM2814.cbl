      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2814.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2814                                         **
      **  REMARKS:  LIST PROCESS DRIVER FOR THE SPECIFIC             **
      **            ROLLOVER DESTINATION INSTRUCTIONS                **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023112**  6.5       CASH FLOW DESTINATION INSTRUCTIONS               **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
032659**  7.1       PERFORMANCE IMPROVEMENT - CFLW BROWSE FOR GIA CV **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2814'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

032659*01  WS-CONSTANT-AREA.
032659*    05  WS-MAX-LINES                 PIC S9(3)  COMP-3.
032659*        88  WS-MAX-LINES-DEFAULT     VALUE +100.
025970*    05  WS-MAX-LINES                 PIC S9(3)  COMP-3
025970*                                     VALUE +100.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-LIST          VALUE '2814'.

           05  WS-SUB                       PIC S9(3)  COMP-3.
           05  WS-CF-FOUND-SW               PIC X(01).
               88  WS-CF-FOUND              VALUE 'Y'.
               88  WS-CF-NOTFND             VALUE 'N'.

           05  WS-END-LOOP-SW               PIC X(01).
               88  WS-END-LOOP              VALUE 'Y'.
               88  WS-END-LOOP-NO           VALUE 'N'.

           05  WS-CVG-NUM                   PIC 9(02).
           05  WS-POL-PAYO-NUM-X.
               10  WS-POL-PAYO-NUM          PIC 9(05).
           05  WS-CF-EFF-DT                 PIC X(10).
032659*    05  WS-NXT-LF-CF-DT              PIC X(10).
032659*    05  WS-NXT-LF-CF-SEQ-NUM         PIC S9(03) COMP-3.
           05  WS-IO-STATUS                 PIC 9(01).
               88  WS-IO-OK                 VALUE ZERO.
032659     05  WS-MAX-LINES                 PIC S9(3)  COMP-3.
      /
       COPY XCWLCOMM REPLACING '$VAR1' BY '0230'.
           15  LCOMM-CURR-KEY.
               20  LCOMM-POL-ID                 PIC X(10).
               20  LCOMM-CVG-NUM                PIC X(02).
               20  LCOMM-POL-PAYO-EFF-DT        PIC X(10).

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY CCWWCVGS.
      /
       COPY CCWWINDX.
026057 COPY CCWWIHSD.
      /
       COPY XCWWWKDT.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFRCDSA.
       COPY CCFWCDSA.
      /
       COPY CCFRCDSI.
       COPY CCFWCDSI.
      /
       COPY CCFRCFLW.
       COPY CCFWCFLW.
      /
       COPY CCFRCVG.
       COPY CCFWCVG.
      /
       COPY CCFRPOL.
       COPY CCFWPOL.
      /
       COPY CCFRPOLP.
       COPY CCFWPOLQ.
       COPY CCFWPOLR.
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
028298 COPY CCWL2626.
       COPY CCWLPGA.
      /
032659 COPY CCWL5511.
       COPY CCWL5400.
      /
       COPY XCWLDTLK.
      /
       COPY XCWL0280.
       COPY XCWL0290.
      /
       COPY XCWL1640.
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
      /
       COPY XCWL8090.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2814.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  COMM-1000-INITIALIZE
               THRU COMM-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

025970*    MOVE MIR-BUS-FCN-ID         TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                   PERFORM  2000-PROCESS-LIST
                       THRU 2000-PROCESS-LIST-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                   MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                   MOVE 'CSOM2814'     TO WGLOB-MSG-PARM (2)
                   MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-INVALD-RQST
                                       TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------------
       2000-PROCESS-LIST.
      *------------------

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-PROCESS-LIST-X
           END-IF.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-PROCESS-LIST-X
           END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  8000-BUILD-POLP-KEY
               THRU 8000-BUILD-POLP-KEY-X.

           PERFORM  8100-BROWSE-POLP-PREV
               THRU 8100-BROWSE-POLP-PREV-X.

           PERFORM  8200-READ-POLP-PREV
               THRU 8200-READ-POLP-PREV-X.

           PERFORM  3000-MOVE-RECORDS-TO-MIR
               THRU 3000-MOVE-RECORDS-TO-MIR-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL NOT WS-IO-OK
               OR   WS-SUB > WS-MAX-LINES.

           IF  WS-IO-OK
      * MSG:  TO VIEW MORE DATA PRESS ENTER
               MOVE 'XS00000014'       TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RPOLP-POL-ID       TO MIR-POL-ID
               MOVE RPOLP-POL-PAYO-EFF-DT TO L1640-INTERNAL-DATE
               PERFORM 1640-8000-INTERNAL-TO-MIR
                  THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                       TO MIR-POL-PAYO-EFF-DT
               MOVE RPOLP-CVG-NUM      TO MIR-CVG-NUM
               COMPUTE L0290-INPUT-V00 =  100000
                                       -  RPOLP-POL-PAYO-NUM
               MOVE ZERO               TO L0290-PRECISION
               MOVE LENGTH OF MIR-POL-PAYO-NUM
                 TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                  THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA  TO MIR-POL-PAYO-NUM
           ELSE
               MOVE 'XS00000025'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  8300-END-BROWSE-PREV
               THRU 8300-END-BROWSE-PREV-X.

           MOVE MIR-POL-ID             TO LCOMM-POL-ID.
           MOVE MIR-CVG-NUM            TO LCOMM-CVG-NUM.
           MOVE MIR-POL-PAYO-EFF-DT    TO LCOMM-POL-PAYO-EFF-DT.

           PERFORM  COMM-3000-DELETE-TWRK
               THRU COMM-3000-DELETE-TWRK-X.
           PERFORM  COMM-2000-WRITE-TWRK
               THRU COMM-2000-WRITE-TWRK-X.

       2000-PROCESS-LIST-X.
           EXIT.

      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------

           MOVE MIR-POL-ID-BASE        TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX         TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: POLICY NOT ON FILE
               MOVE 'CS28140001'       TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-CF-EFF-DT             TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
026057     END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-POL-XFER-INQ      TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-XFER-ACCS-RESTRICTED
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

       2100-VALIDATE-KEYS-X.
           EXIT.

      *-------------------------
       3000-MOVE-RECORDS-TO-MIR.
      *-------------------------

           PERFORM  3200-MOVE-POLP-TO-MIR
               THRU 3200-MOVE-POLP-TO-MIR-X.

           PERFORM  3400-MOVE-CFLW-TO-MIR
               THRU 3400-MOVE-CFLW-TO-MIR-X.

           PERFORM  8200-READ-POLP-PREV
               THRU 8200-READ-POLP-PREV-X.

       3000-MOVE-RECORDS-TO-MIR-X.
           EXIT.

      *----------------------
       3200-MOVE-POLP-TO-MIR.
      *----------------------

           MOVE RPOLP-CVG-NUM          TO MIR-CVG-NUM-T (WS-SUB).
           MOVE RPOLP-CVG-NUM-N        TO WS-CVG-NUM.

           MOVE RPOLP-POL-PAYO-EFF-DT  TO L1640-INTERNAL-DATE
           PERFORM 1640-8000-INTERNAL-TO-MIR
              THRU 1640-8000-INTERNAL-TO-MIR-X
           MOVE L1640-EXTERNAL-DATE    TO MIR-POL-PAYO-EFF-DT-T
                                          (WS-SUB).

           MOVE RPOLP-POL-PAYO-STAT-CD
                                       TO MIR-POL-PAYO-STAT-CD-T
                                          (WS-SUB).

           COMPUTE L0290-INPUT-V00     =  100000
                                       -  RPOLP-POL-PAYO-NUM.
           MOVE 0                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-PAYO-NUM-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-PAYO-NUM-T
                                          (WS-SUB).

           MOVE RPOLP-POL-PAYO-AMT     TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-PAYO-AMT-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-PAYO-AMT-T
                                          (WS-SUB).

       3200-MOVE-POLP-TO-MIR-X.
           EXIT.

      *-----------------------
       3400-MOVE-CFLW-TO-MIR.
      *-----------------------

           IF  (RPOLP-POL-PAYO-EFF-DT > RPOL-LATST-ACTV-DT)
           OR  (RPOLP-POL-PAYO-EFF-DT = RPOL-LATST-ACTV-DT
           AND  NOT RPOLP-POL-PAYO-STAT-HIST)
               PERFORM  3410-FUTURE-DATED-CFLW
                   THRU 3410-FUTURE-DATED-CFLW-X
           ELSE
               PERFORM  3450-CURRENT-CFLW
                   THRU 3450-CURRENT-CFLW-X
           END-IF.

       3400-MOVE-CFLW-TO-MIR-X.
           EXIT.

      *-----------------------
       3410-FUTURE-DATED-CFLW.
      *-----------------------

           SET WS-CF-NOTFND            TO TRUE.
           SET WS-END-LOOP-NO          TO TRUE.

           MOVE RPOL-POL-ID            TO WCFLW-POL-ID.
           MOVE WS-CVG-NUM             TO WCFLW-CVG-NUM-N.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG-NUM)
                                       TO WCFLW-CF-TYP-CD.
032659*    MOVE WCVGS-FRST-LF-CF-DT (WS-CVG-NUM)
032659*                                TO WCFLW-CF-EFF-DT.
032659*    MOVE WCVGS-FRST-LF-CF-SEQ-NUM-N (WS-CVG-NUM)
032659*                                TO WCFLW-CF-SEQ-NUM-N.

032659*    PERFORM  CFLW-1000-READ
032659*        THRU CFLW-1000-READ-X.
032659     PERFORM  5511-0000-INIT-PARM-INFO
032659         THRU 5511-0000-INIT-PARM-INFO-X.
032659     MOVE WS-CVG-NUM             TO L5511-CVG-NUM-N.
032659     MOVE WGLOB-PROCESS-DATE     TO L5511-ACTV-DT.
032659     SET  L5511-ORDR-ANY         TO TRUE.
032659     PERFORM  5511-1000-BROWSE-ACTV-DPOS
032659         THRU 5511-1000-BROWSE-ACTV-DPOS-X.

032659*    IF  WCFLW-IO-OK
032659*        MOVE RCFLW-NXT-LF-CF-DT TO WS-NXT-LF-CF-DT
032659*        MOVE RCFLW-NXT-LF-CF-SEQ-NUM-N
032659*                                TO WS-NXT-LF-CF-SEQ-NUM
032659     IF  L5511-RETRN-OK
               PERFORM  3420-READ-CFLW-CHAIN
                   THRU 3420-READ-CFLW-CHAIN-X
                   UNTIL WS-CF-FOUND
032659             OR    L5511-IO-EOF
032659*            OR    WS-END-LOOP
032659         PERFORM  5511-3000-END-BROWSE-DPOS
032659             THRU 5511-3000-END-BROWSE-DPOS-X
           END-IF.

           IF  WS-CF-NOTFND
      *MSG : CASH FLOW RECORD NOT FOUND
               MOVE 'CS28140002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  3480-MOVE-CFLW-VALUE
                   THRU 3480-MOVE-CFLW-VALUE-X

               PERFORM  3470-LOCATE-DEPOSIT
                   THRU 3470-LOCATE-DEPOSIT-X
               IF  WCFLW-IO-OK
                   PERFORM  3490-MOVE-ORIG-CFLW-VALUE
                       THRU 3490-MOVE-ORIG-CFLW-VALUE-X
               ELSE
      *MSG : CASH FLOW RECORD NOT FOUND
                   MOVE 'CS28140002'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       3410-FUTURE-DATED-CFLW-X.
           EXIT.

      *----------------------
       3420-READ-CFLW-CHAIN.
      *----------------------

032659     PERFORM  5511-2000-READ-NEXT-DPOS
032659         THRU 5511-2000-READ-NEXT-DPOS-X.
032659
032659     IF  L5511-IO-EOF
032659         GO TO      3420-READ-CFLW-CHAIN-X
032659     END-IF.
032659
032659     PERFORM
032659        UNTIL RCFLW-NXT-CF-DT = WWKDT-ZERO-DT
032659        OR    RCFLW-CF-ROLOVR-PAYO-NUM = RPOLP-POL-PAYO-NUM
032659        MOVE RCFLW-NXT-CF-DT        TO WCFLW-CF-EFF-DT
032659        MOVE RCFLW-NXT-CF-SEQ-NUM-N TO WCFLW-CF-SEQ-NUM-N
032659        PERFORM  CFLW-1000-READ
032659            THRU CFLW-1000-READ-X
032659     END-PERFORM.

           IF  RCFLW-CF-ROLOVR-PAYO-NUM = RPOLP-POL-PAYO-NUM
               SET WS-CF-FOUND         TO TRUE
               GO TO 3420-READ-CFLW-CHAIN-X
           END-IF.

032659*    IF  RCFLW-NXT-CF-DT = WWKDT-ZERO-DT
032659*        IF  WS-NXT-LF-CF-DT = WWKDT-ZERO-DT
032659*            SET WS-END-LOOP     TO TRUE
032659*            GO TO 3420-READ-CFLW-CHAIN-X
032659*        ELSE
032659*            MOVE WS-NXT-LF-CF-DT
032659*                                TO WCFLW-CF-EFF-DT
032659*            MOVE WS-NXT-LF-CF-SEQ-NUM
032659*                                TO WCFLW-CF-SEQ-NUM-N
032659*            PERFORM  CFLW-1000-READ
032659*                THRU CFLW-1000-READ-X
032659*            MOVE RCFLW-NXT-LF-CF-DT
032659*                                TO WS-NXT-LF-CF-DT
032659*            MOVE RCFLW-NXT-LF-CF-SEQ-NUM-N
032659*                                TO WS-NXT-LF-CF-SEQ-NUM
032659*        END-IF
032659*    ELSE
032659*        MOVE RCFLW-NXT-CF-DT    TO WCFLW-CF-EFF-DT
032659*        MOVE RCFLW-NXT-CF-SEQ-NUM-N
032659*                                TO WCFLW-CF-SEQ-NUM-N
032659*        PERFORM  CFLW-1000-READ
032659*            THRU CFLW-1000-READ-X
032659*    END-IF.
032659*
032659*    IF  NOT WCFLW-IO-OK
032659*        SET WS-END-LOOP         TO TRUE
032659*    END-IF.

       3420-READ-CFLW-CHAIN-X.
           EXIT.

      *-------------------
       3450-CURRENT-CFLW.
      *-------------------

           MOVE RPOL-POL-ID            TO WCDSA-POL-ID.
           SET WCDSA-CDA-TYP-ROLOVR-PAYO
                                       TO TRUE
           MOVE RPOLP-POL-PAYO-NUM     TO WCDSA-POL-PAYO-NUM.

           MOVE RPOLP-POL-PAYO-EFF-DT
                                       TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE    TO WCDSA-CDA-EFF-IDT-NUM.
           MOVE 999                    TO WCDSA-CDA-SEQ-NUM.

           PERFORM  CDSA-1000-READ
               THRU CDSA-1000-READ-X.

           IF  NOT WCDSA-IO-OK
      *MSG : CASH FLOW RECORD NOT FOUND
               MOVE 'CS28140002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3450-CURRENT-CFLW-X
           END-IF.

           MOVE RCDSA-POL-ID           TO WCFLW-POL-ID.
           MOVE RCDSA-CVG-NUM-N        TO WCFLW-CVG-NUM-N.
           MOVE RCDSA-SRC-CF-TYP-CD    TO WCFLW-CF-TYP-CD.
           MOVE RCDSA-SRC-CF-EFF-DT    TO WCFLW-CF-EFF-DT.
           MOVE RCDSA-SRC-CF-SEQ-NUM-N TO WCFLW-CF-SEQ-NUM-N.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

           IF  NOT WCFLW-IO-OK
      *MSG : CASH FLOW RECORD NOT FOUND
               MOVE 'CS28140002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3450-CURRENT-CFLW-X
           END-IF.

           PERFORM  3480-MOVE-CFLW-VALUE
               THRU 3480-MOVE-CFLW-VALUE-X

           PERFORM  3470-LOCATE-DEPOSIT
               THRU 3470-LOCATE-DEPOSIT-X.

           IF  WCFLW-IO-OK
               PERFORM  3490-MOVE-ORIG-CFLW-VALUE
                   THRU 3490-MOVE-ORIG-CFLW-VALUE-X
           ELSE
      *MSG : CASH FLOW RECORD NOT FOUND
               MOVE 'CS28140002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3450-CURRENT-CFLW-X.
           EXIT.

      *--------------------
       3470-LOCATE-DEPOSIT.
      *--------------------

           MOVE RCFLW-PAYO-CLUST-CF-DT TO WCFLW-CF-EFF-DT.
           MOVE RCFLW-CLUST-CF-SEQ-NUM TO WCFLW-CF-SEQ-NUM-N.
           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

       3470-LOCATE-DEPOSIT-X.
           EXIT.

      *----------------------
       3480-MOVE-CFLW-VALUE.
      *----------------------

           MOVE RCFLW-CF-EFF-DT        TO L1640-INTERNAL-DATE.
           PERFORM 1640-8000-INTERNAL-TO-MIR
              THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO MIR-CF-EFF-DT-T
                                          (WS-SUB).

           MOVE RCFLW-CF-SEQ-NUM-N     TO L0290-INPUT-V00.
           MOVE ZERO                   TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CF-SEQ-NUM-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-CF-SEQ-NUM-T
                                          (WS-SUB).

       3480-MOVE-CFLW-VALUE-X.
           EXIT.
      /
      *---------------------------
       3490-MOVE-ORIG-CFLW-VALUE.
      *---------------------------

           MOVE RCFLW-PAYO-CLUST-CF-DT TO L1640-INTERNAL-DATE.
           PERFORM 1640-8000-INTERNAL-TO-MIR
              THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO MIR-CF-ORIG-LF-DT-T
                                          (WS-SUB).

           MOVE RCFLW-CF-CLI-TRXN-AMT  TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CF-CLI-TRXN-AMT-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY      TO TRUE.
           SET L0290-SIGN-POS-DISPLAY  TO TRUE.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA      TO MIR-CF-CLI-TRXN-AMT-T
                                          (WS-SUB).

           MOVE RCFLW-CF-DPOS-TRM-MO-DUR
                                       TO MIR-CF-DPOS-TRM-MO-DUR-T
                                          (WS-SUB).
           MOVE RCFLW-CF-DPOS-TRM-DY-DUR
                                       TO MIR-CF-DPOS-TRM-DY-DUR-T
                                          (WS-SUB).

           MOVE RCFLW-CF-INT-PCT       TO L0290-INPUT-V04.
           MOVE 4                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CF-INT-PCT-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-CF-INT-PCT-T
                                          (WS-SUB).

       3490-MOVE-ORIG-CFLW-VALUE-X.
           EXIT.
      /

      *----------------
       7000-BUILD-KEYS.
      *----------------

           IF  MIR-POL-ID = SPACE
      *MSG: THE POLICY ID MUST BE ENTERED
               MOVE 'CS28140003'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           IF  MIR-CVG-NUM = SPACE
               MOVE ZERO               TO MIR-CVG-NUM
               MOVE ZERO               TO WS-CVG-NUM
           ELSE
               SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE
               SET L0280-SPACES-PERMITTED
                                       TO TRUE
               MOVE ZERO               TO L0280-PRECISION
               MOVE LENGTH OF MIR-CVG-NUM
                                       TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
               MOVE MIR-CVG-NUM        TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-RETRN-OK
                   MOVE L0280-OUTPUT-V00
                                       TO WS-CVG-NUM
               ELSE
      *MSG: COVERAGE NUMBER IS INVALID
                   MOVE 'CS28140004'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF
           END-IF.

           IF  MIR-POL-PAYO-NUM = SPACE
               MOVE ZERO               TO MIR-POL-PAYO-NUM
               MOVE ZERO               TO WS-POL-PAYO-NUM
           ELSE
               SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE
               SET L0280-SPACES-PERMITTED
                                       TO TRUE
               MOVE ZERO               TO L0280-PRECISION
               MOVE LENGTH OF MIR-POL-PAYO-NUM
                                       TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
               MOVE MIR-POL-PAYO-NUM   TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-RETRN-OK
                   COMPUTE WS-POL-PAYO-NUM = 100000
                                           - L0280-OUTPUT-V00
               ELSE
      *MSG: PAYOUT NUMBER IS INVALID
                   MOVE 'CS28140006'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF
           END-IF.

           IF  MIR-POL-PAYO-EFF-DT = SPACE
               MOVE WWKDT-HIGH-DT      TO WS-CF-EFF-DT
           ELSE
               MOVE MIR-POL-PAYO-EFF-DT
                                       TO L1640-EXTERNAL-DATE
               PERFORM  1640-7000-MIR-TO-INT
                   THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-RETRN-OK
                   MOVE L1640-INTERNAL-DATE
                                       TO WS-CF-EFF-DT
               ELSE
      *MSG: CASH FLOW EFFECTIVE DATE IS INVALID
                   MOVE 'CS28140005'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF
           END-IF.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *--------------------
       8000-BUILD-POLP-KEY.
      *--------------------

           PERFORM  COMM-1000-RETRIEVE-TWRK
               THRU COMM-1000-RETRIEVE-TWRK-X

           IF  LCOMM-RETRN-OK
               IF  MIR-POL-ID NOT = LCOMM-POL-ID
               OR  MIR-CVG-NUM NOT = LCOMM-CVG-NUM
               OR  MIR-POL-PAYO-EFF-DT NOT = LCOMM-POL-PAYO-EFF-DT
                   SET MIR-DV-SCROLL-REFRESH TO TRUE
               END-IF
           ELSE
               SET MIR-DV-SCROLL-REFRESH     TO TRUE
           END-IF.

           IF  MIR-DV-SCROLL-REFRESH
               MOVE ZERO                     TO WS-POL-PAYO-NUM
               IF  WS-CVG-NUM = ZERO
                   SET MIR-DV-SCROLL-POLQ    TO TRUE
               ELSE
                   SET MIR-DV-SCROLL-POLR    TO TRUE
               END-IF
           END-IF.

           EVALUATE TRUE

               WHEN MIR-DV-SCROLL-POLQ
                    MOVE HIGH-VALUE      TO WPOLQ-KEY
                    MOVE RPOL-POL-ID     TO WPOLQ-POL-ID
                    MOVE 'Q'             TO WPOLQ-POL-PAYO-TYP-CD
                    MOVE WS-CF-EFF-DT    TO WPOLQ-POL-PAYO-EFF-DT
                    MOVE +99999          TO WPOLQ-POL-PAYO-NUM

                    MOVE WPOLQ-KEY       TO WPOLQ-ENDBR-KEY
                    MOVE WWKDT-LOW-DT    TO WPOLQ-ENDBR-POL-PAYO-EFF-DT
                    MOVE WS-CVG-NUM      TO WPOLQ-ENDBR-CVG-NUM
                    MOVE WS-POL-PAYO-NUM TO WPOLQ-ENDBR-POL-PAYO-NUM

               WHEN MIR-DV-SCROLL-POLR
                    MOVE HIGH-VALUE      TO WPOLR-KEY
                    MOVE RPOL-POL-ID     TO WPOLR-POL-ID
                    MOVE 'Q'             TO WPOLR-POL-PAYO-TYP-CD
                    MOVE WS-CVG-NUM      TO WPOLR-CVG-NUM
                    MOVE WS-CF-EFF-DT    TO WPOLR-POL-PAYO-EFF-DT
                    MOVE +99999          TO WPOLR-POL-PAYO-NUM

                    MOVE WPOLR-KEY       TO WPOLR-ENDBR-KEY
                    MOVE WWKDT-LOW-DT    TO WPOLR-ENDBR-POL-PAYO-EFF-DT
                    MOVE WS-POL-PAYO-NUM TO WPOLR-ENDBR-POL-PAYO-NUM

           END-EVALUATE.

       8000-BUILD-POLP-KEY-X.
           EXIT.
      /
      *----------------------------
       8100-BROWSE-POLP-PREV.
      *----------------------------

           IF  MIR-DV-SCROLL-POLQ
               PERFORM  POLQ-1000-BROWSE-PREV
                   THRU POLQ-1000-BROWSE-PREV-X
           ELSE
               PERFORM  POLR-1000-BROWSE-PREV
                   THRU POLR-1000-BROWSE-PREV-X
           END-IF.

       8100-BROWSE-POLP-PREV-X.
           EXIT.

      *----------------------------
       8200-READ-POLP-PREV.
      *----------------------------

           IF  MIR-DV-SCROLL-POLQ
               PERFORM  POLQ-2000-READ-PREV
                   THRU POLQ-2000-READ-PREV-X
               MOVE WPOLQ-IO-STATUS    TO WS-IO-STATUS
           ELSE
               PERFORM  POLR-2000-READ-PREV
                   THRU POLR-2000-READ-PREV-X
               MOVE WPOLR-IO-STATUS    TO WS-IO-STATUS
           END-IF.

       8200-READ-POLP-PREV-X.
           EXIT.

      *----------------------------
       8300-END-BROWSE-PREV.
      *----------------------------

           IF  MIR-DV-SCROLL-POLQ
               PERFORM  POLQ-3000-END-BROWSE-PREV
                   THRU POLQ-3000-END-BROWSE-PREV-X
           ELSE
               PERFORM  POLR-3000-END-BROWSE-PREV
                   THRU POLR-3000-END-BROWSE-PREV-X
           END-IF.

       8300-END-BROWSE-PREV-X.
           EXIT.

      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACE                   TO MIR-CVG-NUM-G.
           MOVE SPACE                   TO MIR-POL-PAYO-EFF-DT-G.
           MOVE SPACE                   TO MIR-POL-PAYO-STAT-CD-G.
           MOVE SPACE                   TO MIR-POL-PAYO-NUM-G.
           MOVE SPACE                   TO MIR-POL-PAYO-AMT-G.
           MOVE SPACE                   TO MIR-CF-ORIG-LF-DT-G.
           MOVE SPACE                   TO MIR-CF-CLI-TRXN-AMT-G.
           MOVE SPACE                   TO MIR-CF-DPOS-TRM-MO-DUR-G.
           MOVE SPACE                   TO MIR-CF-DPOS-TRM-DY-DUR-G.
           MOVE SPACE                   TO MIR-CF-INT-PCT-G.
           MOVE SPACE                   TO MIR-CF-EFF-DT-G.
           MOVE SPACE                   TO MIR-CF-SEQ-NUM-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
032659     PERFORM  5511-0000-INIT-PARM-INFO
032659         THRU 5511-0000-INIT-PARM-INFO-X.
032659
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORK-AREA.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.
032659*    SET WS-MAX-LINES-DEFAULT  TO TRUE.
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
025970     SET MIR-RETRN-OK                TO TRUE.

032659     COMPUTE WS-MAX-LINES = LENGTH OF MIR-CVG-NUM-G
032659                          / LENGTH OF MIR-CVG-NUM-T (1).
032659
       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

026057 COPY CCPPIHSD.
       COPY NCPPCVGS.
      /
       COPY XCPPEXIT.
      /
       COPY XCPPINIT.
      /
025970 COPY XCPS1670.
       COPY XCPSCOMM.
       COPY XCPPCOMM.

      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
       COPY CCPS5400.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
032659 COPY CCPS5511.
032659 COPY CCPL5511.
       COPY CCPL5400.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
       COPY XCPS8090.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCDSA.
       COPY CCPBCDSI.
       COPY CCPNCFLW.
       COPY CCPNCVG.
       COPY CCPNPOL.
       COPY CCPVPOLQ.
       COPY CCPVPOLR.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM2814                     *
      ****************************************************************
