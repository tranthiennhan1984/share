      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM8223.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM8223                                         **
      **  REMARKS:  TRANSFER - AMOUNT TO PERCENTAGE                  **
      **                                                             **
      **            THIS MODULE IS USED TO PROCESS TRANSFER FOR      **
      **            CASH VALUE ANNUITIES AND SEGREGATED FUNDS - FROM **
      **            AMOUNT TO PERCENTAGE. THESE TRANSACTIONS ARE     **
      **            PROCESSED AT THE POLICY LEVEL.                   **
      **                                                             **
      **            THIS PROCESS DRIVER HANDLE BOTH CURRENT AND      **
      **            FUTURE DATED TRANSFER.                           **
      **                                                             **
      **  DOMAIN :  CV                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020478**  6.6       FUTURE DATED TRANSACTION                         **
028262**  6.7       GLOBAL MESSAGE ERROR INDICATOR                   **
031034**  7.0       TAX COMPONENTIZATION                             **
031036**  7.0       EXEMPT STATUS MANAGEMENT                         **
031065**  7.0       FUND VALUE DISPLAY NO SIGN FOR NEGATIVE AMOUNT   **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

       DATA DIVISION.
       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM8223'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

       COPY XCWEBLCH.

       COPY CCWWINDX.

       COPY CCWWLOCK.

       COPY XCWWWKDT.

       01  WS-WORK-FIELDS.
           05  WS-POL-CRCY-CD                PIC X(02)  VALUE SPACES.
           05  WS-SWITCHES.
               10  WS-REDO-SW                PIC X(01).
                   88  WS-REDO-OK                       VALUE 'Y'.
                   88  WS-REDO-NOT-OK                   VALUE 'N'.
           05  WS-EDIT-CHECKS.
               10  WS-BUS-FCN-ID             PIC X(04).
                   88  WS-BUS-FCN-ID-VALID              VALUE '1148'
                                                              '8223'.
                   88  WS-BUS-FCN-TSFR                  VALUE '1148'.
                   88  WS-BUS-FCN-FUTURE-DATED-TSFR     VALUE '8223'.
           05  WS-BASIC-EDIT-SW              PIC X(01).
               88  WS-BASIC-EDIT-OK                     VALUE 'Y'.
               88  WS-BASIC-EDIT-FAILED                 VALUE 'N'.
           05  WS-POL-ID.
               10  WS-POLNO                  PIC X(09).
               10  WS-SUFF                   PIC X(01).
           05  WS-EFF-DT                     PIC X(10).
           05  WS-WORK-AMT                   PIC S9(13)V99
                                                        COMP-3.
           05  WS-AMT-FROM                   PIC S9(13)V99
                                                        COMP-3.
           05  WS-WORK-PCT                   PIC S9(3)V9(4)
                                                        COMP-3.
           05  WS-CVG-NUM                    PIC S9(04) BINARY.
           05  WS-TOTAL-AMT                  PIC S9(13)V99
                                                        COMP-3.
           05  WS-ZERO-AMT                   PIC X(16).
           05  WS-ZERO-PCT                   PIC X(08).
           05  WS-FROM-FND-TYP-CD            PIC X(01).
               88  WS-FROM-FND-TYP-SIDE      VALUE 'S'.
               88  WS-FROM-FND-TYP-REG       VALUE 'R'.
               88  WS-FROM-FND-TYP-BOTH      VALUE 'B'.
           05  WS-TO-FND-TYP-CD              PIC X(01).
               88  WS-TO-FND-TYP-SIDE        VALUE 'S'.
               88  WS-TO-FND-TYP-REG         VALUE 'R'.
               88  WS-TO-FND-TYP-BOTH        VALUE 'B'.

       COPY CCWL0201.

       COPY CCWL0289.

       COPY CCWL0620.

       COPY CCWL2430.

       COPY CCWL2626.

       COPY CCWL4750.

       COPY CCWL4780.

       COPY CCWL5400.

       COPY CCWL8233.

       COPY CCWLPGA.

031034*COPY CCWLPGAL.

       COPY FCWL8150.

       COPY FCWL8180.

       COPY FCWL8200.

       COPY FCWLFUND.

036742*COPY XCWL0035.

       COPY XCWL0279.

       COPY XCWL0280.

       COPY XCWL0290.

       COPY XCWL1640.

       COPY XCWL8090.

       COPY XCWL8640.

       COPY XCWLDTLK.

       COPY CCFWPOL.
       COPY CCFRPOL.
       COPY CCFHPOL.

           EXEC SQL INCLUDE CCFWPORQ END-EXEC.
           EXEC SQL INCLUDE CCFRPORQ END-EXEC.

       COPY CCFWCVG.
       COPY CCFRCVG.
       COPY CCWWCVGS.

       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM8223.
      /
      ********************
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      ********************

      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-TSFR
               WHEN WS-BUS-FCN-FUTURE-DATED-TSFR
                   PERFORM  2000-PROCESS-REQUEST
                       THRU 2000-PROCESS-REQUEST-X

               WHEN OTHER
                   SET MIR-RETRN-INVALD-RQST
                                          TO TRUE
                   MOVE MIR-RETRN-CD      TO WGLOB-ERR-RETRN-CD
                   PERFORM  0030-5000-LOGIC-ERROR
                       THRU 0030-5000-LOGIC-ERROR-X

           END-EVALUATE.

           IF  WS-BASIC-EDIT-FAILED
           OR  WS-BUS-FCN-TSFR
               MOVE 'N'                  TO MIR-DV-ENBL-FTL-OVRID-IND
           ELSE
               IF  WGLOB-MSG-ERROR-SW > ZERO
                   MOVE 'Y'              TO MIR-DV-ENBL-FTL-OVRID-IND
028262             SET MIR-RETRN-ERROR-OVRID
028262                                   TO TRUE
               ELSE
                   MOVE 'N'              TO MIR-DV-ENBL-FTL-OVRID-IND
               END-IF
           END-IF.

           PERFORM  FPCK-1000-CHECK-POLICY
               THRU FPCK-1000-CHECK-POLICY-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.

      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-POL-ID-BASE              TO WS-POLNO.
           MOVE MIR-POL-ID-SFX               TO WS-SUFF.
           MOVE WS-POL-ID                    TO WPOL-POL-ID.

           IF  NOT MIR-DV-PRCES-STATE-CD = '3'
               PERFORM  POL-1000-READ-TWRK-TS
                   THRU POL-1000-READ-TWRK-TS-X
           ELSE
               PERFORM  POL-2000-UPDATE-TWRK-TS
                   THRU POL-2000-UPDATE-TWRK-TS-X

               IF  MIR-RETRN-TS-MISMATCH
      *  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
      *  NOT COMPLETE
                   SET WS-BASIC-EDIT-FAILED  TO TRUE
                   MOVE 'XS00000303'         TO WGLOB-MSG-REF-INFO
                   MOVE 'POL'                TO WGLOB-MSG-PARM (01)
                   MOVE WPOL-KEY             TO WGLOB-MSG-PARM (02)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 2000-PROCESS-REQUEST-X
               ELSE
                   IF  WPOL-IO-OK
                       PERFORM  POL-3000-UNLOCK
                           THRU POL-3000-UNLOCK-X
                   END-IF
               END-IF
           END-IF.

           IF  NOT WPOL-IO-OK
      * MSG: POLICY NOT IN FILE
               MOVE 'CS00000019'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-BASIC-EDIT-FAILED      TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-CRCY-MSG-REQD           TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
               SET WS-BASIC-EDIT-FAILED      TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM CVGS-1000-LOAD-CVGS-ARRAY
              THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           IF  WGLOB-MSG-ERROR-SW NOT = ZERO
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF  NOT RPOL-POL-STAT-IN-FORCE
      *MSG: POLICY MUST BE IN FORCE TO PROCESS
               SET WS-BASIC-EDIT-FAILED      TO TRUE
               MOVE 'XS00000238'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           MOVE RPOL-POL-ID                  TO L2430-POL-ID.
           MOVE ZERO                         TO I.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  L2430-RETRN-OK
               INITIALIZE                    L0620-INPUT-PARM-INFO
               IF  L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM
                                             TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM
                                             TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM
                                             TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM     TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD         TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME        TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES                   TO MIR-DV-OWN-CLI-NM
               SET WS-BASIC-EDIT-FAILED      TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           MOVE MIR-CIA-EFF-DT               TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X

           IF  L1640-NOT-VALID
               SET WS-BASIC-EDIT-FAILED     TO TRUE
      *MSG: INVALID EFFECTIVE DATE
               MOVE 'XS00000355'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-PROCESS-REQUEST-X
           ELSE
               MOVE L1640-INTERNAL-DATE      TO WS-EFF-DT
           END-IF.

           IF  WGLOB-MSG-ERROR-SW > ZERO
           OR  MIR-RETRN-TS-MISMATCH
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

031034*    PERFORM  PGAL-0000-INIT-PARM-INFO
031034*        THRU PGAL-0000-INIT-PARM-INFO-X.

           PERFORM  2200-INITIALIZE-WORK-AREAS
               THRU 2200-INITIALIZE-WORK-AREAS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM 3000-PROCESS-TRANSFER
              THRU 3000-PROCESS-TRANSFER-X.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *---------------------------
       2200-INITIALIZE-WORK-AREAS.
      *---------------------------

           MOVE RPOL-POL-CRCY-CD             TO WS-POL-CRCY-CD.

           PERFORM 8200-1000-BUILD-PARM-INFO
              THRU 8200-1000-BUILD-PARM-INFO-X.
           MOVE WS-EFF-DT                    TO L8200-EFF-DT.
031036     SET L8200-CDI-TYP-PART-SUR        TO TRUE.

           PERFORM 8200-1000-INIT-INSTR
              THRU 8200-1000-INIT-INSTR-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET WS-BASIC-EDIT-FAILED      TO TRUE
               GO TO 2200-INITIALIZE-WORK-AREAS-X
           END-IF.

           PERFORM 8180-1000-BUILD-PARM-INFO
              THRU 8180-1000-BUILD-PARM-INFO-X.
           MOVE WS-EFF-DT                    TO L8180-EFF-DT.
           PERFORM  8180-1000-CALC-FUND-VAL
               THRU 8180-1000-CALC-FUND-VAL-X.

           SET LFUND-ACTV-TRANSFER           TO TRUE.

       2200-INITIALIZE-WORK-AREAS-X.
           EXIT.

      *-----------------------
       3000-PROCESS-TRANSFER.
      *-----------------------

           EVALUATE TRUE
               WHEN MIR-DV-PRCES-STATE-CD = '1'
                   PERFORM 3100-PROCESS-TRANSFER-1
                      THRU 3100-PROCESS-TRANSFER-1-X
               WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM 3200-PROCESS-TRANSFER-2
                      THRU 3200-PROCESS-TRANSFER-2-X
               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM 3400-PROCESS-TRANSFER-3
                      THRU 3400-PROCESS-TRANSFER-3-X
           END-EVALUATE.

       3000-PROCESS-TRANSFER-X.
           EXIT.

      *-------------------------
       3100-PROCESS-TRANSFER-1.
      *-------------------------

           PERFORM  8233-1000-BUILD-PARM-INFO
               THRU 8233-1000-BUILD-PARM-INFO-X.

           PERFORM  5000-FILL-INPUT-DATA-1
               THRU 5000-FILL-INPUT-DATA-1-X.

           IF  WS-BUS-FCN-TSFR
               PERFORM  8233-1000-EDIT-CURR-TSFR-1
                   THRU 8233-1000-EDIT-CURR-TSFR-1-X
           ELSE
               PERFORM  8233-2000-EDIT-FUTURE-TSFR-1
                   THRU 8233-2000-EDIT-FUTURE-TSFR-1-X
           END-IF.

           IF  L8233-RETRN-EDIT-ERROR
               SET WS-BASIC-EDIT-FAILED      TO TRUE
               GO TO 3100-PROCESS-TRANSFER-1-X
           END-IF.

           IF  NOT L8233-RETRN-OK
               GO TO 3100-PROCESS-TRANSFER-1-X
           END-IF.

           PERFORM  9100-CLEAR-DATA-FIELDS
               THRU 9100-CLEAR-DATA-FIELDS-X.

           MOVE ZEROS                        TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-TO-FND-AMT-T (1)
                                             TO L0290-MAX-OUT-LEN.
           PERFORM  0290-1000-NUMERIC-FORMAT
               THRU 0290-1000-NUMERIC-FORMAT-X.
           MOVE L0290-OUTPUT-DATA            TO WS-ZERO-AMT.

           MOVE ZEROS                        TO L0290-INPUT-V02.
           MOVE 4                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (1)
                                             TO L0290-MAX-OUT-LEN.
           PERFORM  0290-1000-NUMERIC-FORMAT
               THRU 0290-1000-NUMERIC-FORMAT-X.
           MOVE L0290-OUTPUT-DATA            TO WS-ZERO-AMT.

           PERFORM  6000-DISPLAY-TSFR-COMMON
               THRU 6000-DISPLAY-TSFR-COMMON-X.

           MOVE ZEROS                        TO WS-TOTAL-AMT.

           PERFORM  6200-DISPLAY-XFER-AMT-TO-PCT
               THRU 6200-DISPLAY-XFER-AMT-TO-PCT-X
               VARYING JJ FROM +1 BY +1
               UNTIL   JJ > LFUND-FND-CTR.

           PERFORM  6220-DISPLAY-XFER-PCT-AMT
               THRU 6220-DISPLAY-XFER-PCT-AMT-X
               VARYING JJ FROM +1 BY +1
               UNTIL   JJ > LFUND-FND-CTR.

           IF  WS-BUS-FCN-FUTURE-DATED-TSFR
      *MSG: VALUES SHOWN ARE CALCULATED AS OF THE CURRENT PROCESSING
      *     DATE
               MOVE 'CS82230001'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3100-PROCESS-TRANSFER-1-X.
           EXIT.

      *-------------------------
       3200-PROCESS-TRANSFER-2.
      *-------------------------

           PERFORM  8233-1000-BUILD-PARM-INFO
               THRU 8233-1000-BUILD-PARM-INFO-X.

           IF  WS-BUS-FCN-FUTURE-DATED-TSFR
           AND MIR-DV-FTL-MSG-OVRID-IND = 'Y'
               SET L8233-FUTURE-OVERRIDE     TO TRUE
           END-IF.

           PERFORM  5200-FILL-INPUT-FUND-DATA
               THRU 5200-FILL-INPUT-FUND-DATA-X.

           IF  WS-BUS-FCN-TSFR
               PERFORM  8233-3000-EDIT-CURR-TSFR-2
                   THRU 8233-3000-EDIT-CURR-TSFR-2-X
           ELSE
               PERFORM  8233-4000-EDIT-FUTURE-TSFR-2
                   THRU 8233-4000-EDIT-FUTURE-TSFR-2-X
           END-IF.

           IF  L8233-RETRN-EDIT-ERROR
               SET WS-BASIC-EDIT-FAILED      TO TRUE
               GO TO 3200-PROCESS-TRANSFER-2-X
           ELSE
               IF  L8233-RETRN-ERROR
                   GO TO 3200-PROCESS-TRANSFER-2-X
               END-IF
           END-IF.

           IF  NOT WS-BUS-FCN-TSFR
      *MSG: YOU ARE ABOUT TO SCHEDULE A FUTURE DATED TRANSFER REQUEST
               MOVE 'CS82230002'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

      *MSG: ANY FINANCIAL ACTIVITIES THAT OCCUR PRIOR TO THE FUTURE
      *     DATE MAY AFFECT THE PROCESSING OF THE FUTURE DATED ACTIVITY
               MOVE 'CS82230003'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

           END-IF.

           IF  WS-BUS-FCN-FUTURE-DATED-TSFR
           AND MIR-DV-FTL-MSG-OVRID-IND = 'Y'
               GO TO 3200-PROCESS-TRANSFER-2-X
           END-IF.

           MOVE ZEROS                        TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-TO-FND-AMT-T (1)
                                             TO L0290-MAX-OUT-LEN.
           PERFORM  0290-1000-NUMERIC-FORMAT
               THRU 0290-1000-NUMERIC-FORMAT-X.
           MOVE L0290-OUTPUT-DATA            TO WS-ZERO-AMT.

           MOVE ZEROS                        TO L0290-INPUT-V02.
           MOVE 4                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (1)
                                             TO L0290-MAX-OUT-LEN.
           PERFORM  0290-1000-NUMERIC-FORMAT
               THRU 0290-1000-NUMERIC-FORMAT-X.
           MOVE L0290-OUTPUT-DATA            TO WS-ZERO-AMT.

           PERFORM  6000-DISPLAY-TSFR-COMMON
               THRU 6000-DISPLAY-TSFR-COMMON-X.

           MOVE ZEROS                        TO WS-TOTAL-AMT.

           PERFORM  6000-DISPLAY-TSFR-COMMON
               THRU 6000-DISPLAY-TSFR-COMMON-X.

           MOVE ZEROS                        TO WS-TOTAL-AMT.

           PERFORM  6200-DISPLAY-XFER-AMT-TO-PCT
               THRU 6200-DISPLAY-XFER-AMT-TO-PCT-X
               VARYING JJ FROM +1 BY +1
               UNTIL   JJ > LFUND-FND-CTR.

           IF  WS-BUS-FCN-FUTURE-DATED-TSFR
      *MSG: VALUES SHOWN ARE CALCULATED AS OF THE CURRENT PROCESSING
      *     DATE
               MOVE 'CS82230001'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


       3200-PROCESS-TRANSFER-2-X.
           EXIT.

      *-------------------------
       3400-PROCESS-TRANSFER-3.
      *-------------------------

           PERFORM  8233-1000-BUILD-PARM-INFO
               THRU 8233-1000-BUILD-PARM-INFO-X.

           PERFORM  5200-FILL-INPUT-FUND-DATA
               THRU 5200-FILL-INPUT-FUND-DATA-X.


           IF  WS-BUS-FCN-TSFR
               PERFORM  3420-PROCESS-CURR-TSFR-3
                   THRU 3420-PROCESS-CURR-TSFR-3-X
           ELSE
               PERFORM  3440-PROCESS-FUTURE-TSFR-3
                   THRU 3440-PROCESS-FUTURE-TSFR-3-X
           END-IF.

       3400-PROCESS-TRANSFER-3-X.
           EXIT.

      *------------------------
       3420-PROCESS-CURR-TSFR-3.
      *------------------------

           PERFORM  8233-5000-EDIT-CURR-TSFR-3
               THRU 8233-5000-EDIT-CURR-TSFR-3-X.

           IF  NOT L8233-RETRN-OK
      *MSG: INCOMPETE TRANSACTION
               MOVE 'CS82230004'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3420-PROCESS-CURR-TSFR-3-X
           END-IF.

           PERFORM  3460-AUTO-REDO
               THRU 3460-AUTO-REDO-X.

           IF  WS-REDO-NOT-OK
               GO TO 3420-PROCESS-CURR-TSFR-3-X
           END-IF.

           PERFORM  8600-INVOKE-UNDO
               THRU 8600-INVOKE-UNDO-X.

           IF  NOT WGLOB-GOOD-RETURN
               GO TO 3420-PROCESS-CURR-TSFR-3-X
           END-IF.

031034*    PERFORM  PGAL-0000-INIT-PARM-INFO
031034*        THRU PGAL-0000-INIT-PARM-INFO-X.

           PERFORM  3422-BUILD-8150-LINKAGE
               THRU 3422-BUILD-8150-LINKAGE-X.

           PERFORM  3424-ELIMINATE-UNUSED-FUNDS
               THRU 3424-ELIMINATE-UNUSED-FUNDS-X.

           PERFORM  8150-1000-PRCES-XFER
               THRU 8150-1000-PRCES-XFER-X.

           IF  L8150-RETRN-OK
               PERFORM  8500-UPDATE-POLICY-AND-CVGS
                   THRU 8500-UPDATE-POLICY-AND-CVGS-X
      * MSG: TRANSACTION PROCESSED SUCCESSFULLY
               MOVE 'CS82230005'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
      *MSG: INCOMPETE TRANSACTION
               MOVE 'CS82230004'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  8100-RESET-DEFAULTS
               THRU 8100-RESET-DEFAULTS-X.

       3420-PROCESS-CURR-TSFR-3-X.
           EXIT.

      *------------------------
       3422-BUILD-8150-LINKAGE.
      *------------------------

           PERFORM  8150-1000-BUILD-PARM-INFO
               THRU 8150-1000-BUILD-PARM-INFO-X.

           SET L8150-REASON-INTRNL-XFER      TO TRUE.
           SET L8150-TRXN-FEE-OVRID          TO TRUE.
           SET L8150-REDO-WARNING            TO TRUE.
           SET L8150-DEFR-ALLOWED            TO TRUE.
           SET L8150-XFER-OVRID              TO TRUE.
           SET L8150-PRCES-TYP-ALL           TO TRUE.

           MOVE 'I'                          TO L8150-ALLOC-CD.
           MOVE L8233-CIA-EFF-DT-R           TO L8150-EFF-DT.
           MOVE L8233-SUPRES-CNFRM-IND       TO L8150-SUPR-CONF-IND.

       3422-BUILD-8150-LINKAGE-X.
           EXIT.

      *----------------------------
       3424-ELIMINATE-UNUSED-FUNDS.
      *----------------------------

           MOVE ZERO                         TO JJ.
           PERFORM
               VARYING J FROM 1 BY 1
               UNTIL   J > LFUND-FND-CTR

               IF  LFUND-ALLOC-AMT (J)      = ZERO
               AND LFUND-ALLOC-PCT (J)      = ZERO
               AND LFUND-ALLOC-UNIT-QTY (J) = ZERO
                   CONTINUE
               ELSE
                   ADD +1                    TO JJ
                   MOVE LFUND-FND-INFO (J)
                     TO LFUND-FND-INFO (JJ)
               END-IF

           END-PERFORM.
           MOVE JJ                           TO LFUND-FND-CTR.

       3424-ELIMINATE-UNUSED-FUNDS-X.
           EXIT.

      *--------------------------
       3440-PROCESS-FUTURE-TSFR-3.
      *--------------------------

           IF  WS-BUS-FCN-FUTURE-DATED-TSFR
           AND MIR-DV-FTL-MSG-OVRID-IND = 'Y'
               SET L8233-FUTURE-OVERRIDE     TO TRUE
           END-IF.

           PERFORM  8233-6000-EDIT-FUTURE-TSFR-3
               THRU 8233-6000-EDIT-FUTURE-TSFR-3-X.

           IF  NOT L8233-RETRN-OK
               GO TO 3440-PROCESS-FUTURE-TSFR-3-X
           END-IF.

           PERFORM  3460-AUTO-REDO
               THRU 3460-AUTO-REDO-X.

           IF  L4780-RETRN-ERROR
               GO TO 3440-PROCESS-FUTURE-TSFR-3-X
           END-IF.

           MOVE MIR-POL-ID                   TO WPORQ-POL-ID.
036742*    PERFORM  0035-5000-TIMESTAMP
036742*        THRU 0035-5000-TIMESTAMP-X.
036742*
036742*    MOVE L0035-TIMESTAMP              TO WPORQ-POL-RQST-CREAT-TS.
036742     MOVE WS-EFF-DT                    TO WPORQ-POL-RQST-EFF-DT
           PERFORM  PORQ-1000-CREATE
               THRU PORQ-1000-CREATE-X

036742*    MOVE WS-EFF-DT                    TO RPORQ-POL-RQST-EFF-DT
           SET RPORQ-POL-RQST-TYP-XFER       TO TRUE.
           SET RPORQ-POL-RQST-STAT-PEND      TO TRUE.
           MOVE MIR-BUS-FCN-ID               TO RPORQ-BUS-FCN-ID.
           MOVE WGLOB-USER-ID                TO RPORQ-USER-ID.
           MOVE LENGTH OF MIR-PARM-AREA
                                  TO RPORQ-POL-RQST-MSG-INFO-LENGTH
           MOVE MIR-PARM-AREA     TO RPORQ-POL-RQST-MSG-INFO-DATA
                                  (1:RPORQ-POL-RQST-MSG-INFO-LENGTH)
           PERFORM  PORQ-1000-WRITE
               THRU PORQ-1000-WRITE-X.

      *MSG: FUTURE DATED WITHDRAWAL REQUEST HAS BEEN SCHEDULED.  VIEW
      *     DETAILS ON FUTURE DATED POLICY ACTIVITY BUSINESS PROCESS.
            MOVE 'CS82230006'                TO WGLOB-MSG-REF-INFO
            PERFORM  0260-1000-GENERATE-MESSAGE
                THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  8720-SET-POL-NXT-ACTV
               THRU 8720-SET-POL-NXT-ACTV-X.
           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.
           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

       3440-PROCESS-FUTURE-TSFR-3-X.
           EXIT.

      *----------------
       3460-AUTO-REDO.
      *----------------

           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.

           IF  NOT WPOL-IO-OK
      *MSG: POLICY NOT IN FILE
               MOVE 'CS00000019'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3460-AUTO-REDO-X
           END-IF.
           MOVE RPOL-REC-INFO                TO HPOL-REC-INFO.

           PERFORM  0289-1000-INIT-PARM-INFO
               THRU 0289-1000-INIT-PARM-INFO-X.

           MOVE WS-EFF-DT                    TO L0289-PROC-EFF-DT.
           MOVE WS-EFF-DT                    TO L0289-LO-PAC-DT.
           MOVE WS-EFF-DT                    TO L0289-LO-CRC-DT.
           MOVE WS-EFF-DT                    TO L0289-LO-DD2-DT.

           PERFORM  0289-1000-OBTAIN-NXT-ACTV
               THRU 0289-1000-OBTAIN-NXT-ACTV-X.

           IF  L0289-RETRN-OK
               MOVE L0289-NXT-ACTV-TYP-CD    TO RPOL-NXT-ACTV-TYP-CD
               MOVE L0289-NXT-ACTV-DT        TO RPOL-POL-NXT-ACTV-DT
           ELSE
               MOVE 'RSH'                    TO RPOL-NXT-ACTV-TYP-CD
               MOVE WGLOB-PROCESS-DATE       TO RPOL-POL-NXT-ACTV-DT
           END-IF.

           SET WS-REDO-OK                    TO TRUE.

           IF  (RPOL-POL-NXT-ACTV-DT > WWKDT-ZERO-DT
           AND  RPOL-POL-NXT-ACTV-DT > WGLOB-PROCESS-DATE)
               CONTINUE
           ELSE
               PERFORM  8550-INVOKE-REDO
                   THRU 8550-INVOKE-REDO-X
           END-IF.

       3460-AUTO-REDO-X.
           EXIT.

      *-----------------------
       5000-FILL-INPUT-DATA-1.
      *-----------------------

           MOVE MIR-CIA-EFF-DT               TO L8233-CIA-EFF-DT.
           MOVE MIR-SUPRES-CNFRM-IND         TO L8233-SUPRES-CNFRM-IND.

       5000-FILL-INPUT-DATA-1-X.
           EXIT.

      *---------------------------
       5200-FILL-INPUT-FUND-DATA.
      *---------------------------

           PERFORM  5000-FILL-INPUT-DATA-1
               THRU 5000-FILL-INPUT-DATA-1-X.

           PERFORM
               VARYING J FROM +1 BY +1
               UNTIL   J > LFUND-FND-CTR

               MOVE MIR-DV-FROM-FND-AMT-T (J)
                                            TO L8233-DV-FROM-FND-AMT-T
                                               (J)
               MOVE MIR-FIA-IN-ALLOC-PCT-T (J)
                                            TO L8233-FIA-IN-ALLOC-PCT-T
                                               (J)
           END-PERFORM.

       5200-FILL-INPUT-FUND-DATA-X.
           EXIT.

      *------------------------
       6000-DISPLAY-TSFR-COMMON.
      *------------------------

           MOVE L8233-SUPRES-CNFRM-IND      TO MIR-SUPRES-CNFRM-IND.

       6000-DISPLAY-TSFR-COMMON-X.
           EXIT.

      *------------------------------
       6200-DISPLAY-XFER-AMT-TO-PCT.
      *------------------------------

           PERFORM  8000-DISPLAY-FUND-KEYS
               THRU 8000-DISPLAY-FUND-KEYS-X.

           EVALUATE  TRUE

               WHEN LFUND-ALLOC-AMT (JJ) < ZEROS

                   MOVE WS-ZERO-PCT          TO MIR-FIA-IN-ALLOC-PCT-T
                                                (JJ)
                   COMPUTE L0290-INPUT-V02   =  LFUND-ALLOC-AMT (JJ)
                                             *  -1
                   MOVE 2                    TO L0290-PRECISION
                   MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (JJ)
                                             TO L0290-MAX-OUT-LEN
                   PERFORM  0290-2000-FORMAT-FOR-MIR
                       THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA    TO MIR-DV-FROM-FND-AMT-T
                                                (JJ)
                   ADD LFUND-ALLOC-AMT (JJ)  TO WS-TOTAL-AMT

               WHEN LFUND-ALLOC-AMT (JJ) > ZEROS
               WHEN LFUND-ALLOC-AMT (JJ) = ZEROS
                   MOVE WS-ZERO-AMT          TO MIR-DV-TO-FND-AMT-T
                                                (JJ)

           END-EVALUATE.

           EVALUATE  TRUE

               WHEN LFUND-ALLOC-PCT (JJ) > ZEROS
                   MOVE WS-ZERO-AMT          TO MIR-DV-FROM-FND-AMT-T
                                                (JJ)
                   MOVE LFUND-ALLOC-PCT (JJ)
                                             TO L0290-INPUT-V04
                   MOVE 4                    TO L0290-PRECISION
                   MOVE LENGTH OF MIR-FIA-IN-ALLOC-PCT-T (JJ)
                                             TO L0290-MAX-OUT-LEN
                   PERFORM  0290-2000-FORMAT-FOR-MIR
                       THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA    TO MIR-FIA-IN-ALLOC-PCT-T
                                                (JJ)

              WHEN LFUND-ALLOC-PCT (JJ) < ZEROS
              WHEN LFUND-ALLOC-PCT (JJ) = ZEROS
                   MOVE WS-ZERO-PCT          TO MIR-FIA-IN-ALLOC-PCT-T
                                                (JJ)

           END-EVALUATE.

           MOVE ZEROS                        TO L0290-INPUT-V04.
           MOVE 4                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (JJ)
                                             TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO MIR-FIA-OUT-ALLOC-PCT-T
                                                (JJ).

           MOVE ZEROS                        TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-TO-FND-AMT-T (JJ)
                                             TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO MIR-DV-TO-FND-AMT-T
                                                (JJ).


       6200-DISPLAY-XFER-AMT-TO-PCT-X.
           EXIT.

      *-------------------------
       6220-DISPLAY-XFER-PCT-AMT.
      *-------------------------

           EVALUATE  TRUE

               WHEN LFUND-ALLOC-AMT (JJ) < ZEROS
                   COMPUTE WS-WORK-PCT ROUNDED
                         = LFUND-ALLOC-AMT (JJ)
                         / WS-TOTAL-AMT
                         * 100
                   COMPUTE L0290-INPUT-V04 ROUNDED
                         = WS-WORK-PCT
                   MOVE 4                    TO L0290-PRECISION
                   MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (JJ)
                                             TO L0290-MAX-OUT-LEN
                   PERFORM  0290-2000-FORMAT-FOR-MIR
                       THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA    TO MIR-FIA-OUT-ALLOC-PCT-T
                                                (JJ)

               WHEN LFUND-ALLOC-PCT (JJ) > ZEROS
                   COMPUTE L0279-CRCY-AMT
                         = LFUND-ALLOC-PCT (JJ)
                         * WS-TOTAL-AMT
                         / 100
                   PERFORM  0279-1000-CRCY-RND
                       THRU 0279-1000-CRCY-RND-X

                   MOVE L0279-CRCY-AMT       TO WS-WORK-AMT
                   COMPUTE L0290-INPUT-V02 ROUNDED
                         = WS-WORK-AMT
                   MOVE 2                    TO L0290-PRECISION
                   MOVE LENGTH OF MIR-DV-TO-FND-AMT-T (JJ)
                                             TO L0290-MAX-OUT-LEN
                   PERFORM  0290-2000-FORMAT-FOR-MIR
                       THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA    TO MIR-DV-TO-FND-AMT-T
                                                (JJ)

           END-EVALUATE.

       6220-DISPLAY-XFER-PCT-AMT-X.
           EXIT.

      *-----------------------
       8000-DISPLAY-FUND-KEYS.
      *-----------------------

           MOVE LFUND-FND-ID (JJ)         TO L8640-FND-ID.
           PERFORM  8640-1000-GET-FND-CRCY-CD
               THRU 8640-1000-GET-FND-CRCY-CD-X.
           IF  L8640-RETRN-OK
               MOVE L8640-FND-CRCY-CD     TO MIR-FIA-CRCY-CD-T (JJ)
           ELSE
               MOVE SPACES                TO MIR-FIA-CRCY-CD-T (JJ)

      * CASHFLOW TYPE PRODUCTS WILL BY DEFINITION HAVE LFUND-FND-ID (JJ)
      * SET TO SPACES

               IF  LFUND-FND-ID (JJ) = SPACES
                   MOVE WS-POL-CRCY-CD    TO MIR-FIA-CRCY-CD-T (JJ)
               END-IF
           END-IF.

      *    FOR EACH OF THE FUNDS MOVE THE POLICY CURRENCY CODE TO MIR

           MOVE WS-POL-CRCY-CD            TO MIR-CIA-CRCY-CD-T (JJ).
           MOVE LFUND-CVG-NUM (JJ)        TO MIR-CVG-NUM-T (JJ).
           MOVE LFUND-FND-ID (JJ)         TO MIR-FND-ID-T (JJ).
           COMPUTE L0290-INPUT-V02
                  =  L8180-CFN-CV-AMT (JJ)
                  + L8180-CFN-DEFR-IN-AMT (JJ)
                  + L8180-CFN-DEFR-OUT-AMT (JJ).
           MOVE 2                         TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-CFN-APROX-AMT-T (1)
                                          TO L0290-MAX-OUT-LEN.
031065*    SET L0290-SIGN-POS-DISPLAY     TO TRUE.
031065     SET L0290-SIGN-DISPLAY         TO TRUE.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA         TO MIR-DV-CFN-APROX-AMT-T
                                             (JJ).

           COMPUTE  L0290-INPUT-NUMBER
                 = (L8180-CFN-POL-CRCY-CV-AMT     (JJ)
                 +  L8180-CFN-POL-DEFR-IN-AMT     (JJ)
                 +  L8180-CFN-POL-DEFR-OUT-AMT    (JJ))
                 *  100.
           MOVE 2                         TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-FIA-POL-CRCY-AMT-T (1)
                                          TO L0290-MAX-OUT-LEN.
031065*    SET L0290-SIGN-POS-DISPLAY     TO TRUE.
031065     SET L0290-SIGN-DISPLAY         TO TRUE.
           PERFORM  0290-1000-NUMERIC-FORMAT
               THRU 0290-1000-NUMERIC-FORMAT-X.
           MOVE L0290-OUTPUT-DATA         TO MIR-DV-FIA-POL-CRCY-AMT-T
                                             (JJ).

           MOVE LFUND-CVG-NUM-N (JJ)      TO I.
           MOVE WCVGS-PLAN-ID (I)         TO MIR-PLAN-ID-T (JJ).

           PERFORM  8010-DISPLAY-FUND-UNITS
               THRU 8010-DISPLAY-FUND-UNITS-X.

           PERFORM  8020-GET-FUND-DESCRIPTION
               THRU 8020-GET-FUND-DESCRIPTION-X.

       8000-DISPLAY-FUND-KEYS-X.
           EXIT.

      *--------------------------
       8010-DISPLAY-FUND-UNITS.
      *--------------------------

           MOVE L8180-CFN-UNIT-QTY (JJ)      TO L0290-INPUT-V06.
           MOVE 6                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FIA-UNIT-CUM-QTY-T (JJ)
                                             TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-POS-DISPLAY        TO TRUE.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO MIR-FIA-UNIT-CUM-QTY-T
                                                (JJ).

       8010-DISPLAY-FUND-UNITS-X.
           EXIT.

      *--------------------------
       8020-GET-FUND-DESCRIPTION.
      *--------------------------

           IF  MIR-CVG-NUM-T (JJ) = SPACE
           AND MIR-FND-ID-T (JJ) = SPACE
               GO TO 8020-GET-FUND-DESCRIPTION-X
           END-IF.

           IF  MIR-FND-ID-T (JJ) = SPACE
               MOVE MIR-PLAN-ID-T (JJ)       TO WEDIT-ETBL-VALU-ID
               PERFORM  PLAN-2000-DESC
                   THRU PLAN-2000-DESC-X
               MOVE REDIT-ETBL-DESC-TXT      TO MIR-DV-FND-DESC-TXT-T
                                                (JJ)
           ELSE
               MOVE MIR-FND-ID-T (JJ)        TO WEDIT-ETBL-VALU-ID
               PERFORM  SGFD-2000-DESC
                   THRU SGFD-2000-DESC-X
               MOVE REDIT-ETBL-DESC-TXT      TO MIR-DV-FND-DESC-TXT-T
                                                (JJ)
           END-IF.

       8020-GET-FUND-DESCRIPTION-X.
           EXIT.

      *-------------------
       8100-RESET-DEFAULTS.
      *-------------------

           MOVE WGLOB-PROCESS-DATE           TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE          TO MIR-CIA-EFF-DT.

           MOVE SPACES                       TO MIR-DV-OWN-CLI-NM
           MOVE 'N'                          TO MIR-SUPRES-CNFRM-IND.

       8100-RESET-DEFAULTS-X.
           EXIT.

      *----------------------------
       8500-UPDATE-POLICY-AND-CVGS.
      *----------------------------

           PERFORM  8720-SET-POL-NXT-ACTV
               THRU 8720-SET-POL-NXT-ACTV-X.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL I > RPOL-POL-CVG-REC-CTR-N

               MOVE I                        TO WCVG-CVG-NUM-N
               PERFORM  CVG-1000-READ-FOR-UPDATE
                   THRU CVG-1000-READ-FOR-UPDATE-X
               IF  RCVG-CVG-INFO = WCVGS-CVG-INFO (I)
                   PERFORM  CVG-3000-UNLOCK
                       THRU CVG-3000-UNLOCK-X
               ELSE
                   MOVE WCVGS-CVG-INFO (I)   TO RCVG-CVG-INFO
                   PERFORM  CVG-2000-REWRITE
                       THRU CVG-2000-REWRITE-X
               END-IF
           END-PERFORM.

       8500-UPDATE-POLICY-AND-CVGS-X.
           EXIT.


      *----------------
       8550-INVOKE-REDO.
      *-----------------

           IF  NOT RPOL-POL-STAT-IN-FORCE
               GO TO 8550-INVOKE-REDO-X
           END-IF.

           PERFORM  4780-1000-BUILD-PARM-INFO
               THRU 4780-1000-BUILD-PARM-INFO-X.

           SET L4780-REDO-WARNING            TO TRUE.
           SET L4780-MSG-SUPPRESS            TO TRUE.
           IF  WS-BUS-FCN-TSFR
               MOVE WS-EFF-DT                TO L4780-EFF-DT
           ELSE
               MOVE WGLOB-PROCESS-DATE       TO L4780-EFF-DT
           END-IF.
           MOVE RPOL-PREV-BTCH-PRCES-DT      TO L4780-LAST-PROCESS-DATE.
           SET L4780-PRCES-INCLUSIVE         TO TRUE.

           PERFORM  4780-1000-GET-NEXT-ACT-DT
               THRU 4780-1000-GET-NEXT-ACT-DT-X.

           EVALUATE  TRUE
               WHEN L4780-RETRN-ERROR
               WHEN L4780-RETRN-INVALID-REQUEST
                    SET WS-REDO-NOT-OK       TO TRUE
                    PERFORM  POL-3000-UNLOCK
                        THRU POL-3000-UNLOCK-X

               WHEN  (L4780-RETRN-OK
               AND L4780-ACTIVITY-DUE
               AND L4780-REDO-ALLOW)
                   PERFORM  POL-3000-UNLOCK
                       THRU POL-3000-UNLOCK-X
                   IF  WS-BUS-FCN-TSFR
                       MOVE WS-EFF-DT        TO L0201-EFF-DT
                   ELSE
                       MOVE WGLOB-PROCESS-DATE
                                             TO L0201-EFF-DT
                   END-IF
                   SET L0201-AUTO-REDO       TO TRUE

                   PERFORM  0201-1000-AUTO-PROCESSING
                       THRU 0201-1000-AUTO-PROCESSING-X
                   PERFORM  8720-SET-POL-NXT-ACTV
                       THRU 8720-SET-POL-NXT-ACTV-X
                   MOVE RPOL-REC-INFO        TO HPOL-REC-INFO
                   PERFORM  POL-1000-READ-FOR-UPDATE
                       THRU POL-1000-READ-FOR-UPDATE-X
                   MOVE HPOL-REC-INFO        TO RPOL-REC-INFO

                   PERFORM  POL-2000-REWRITE
                       THRU POL-2000-REWRITE-X
                   PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
                       THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
                   PERFORM  POL-1000-READ-TWRK-TS
                       THRU POL-1000-READ-TWRK-TS-X

                   IF  L0201-RETRN-OK
                   OR  WS-BUS-FCN-FUTURE-DATED-TSFR
                       PERFORM  POL-1000-READ-FOR-UPDATE
                           THRU POL-1000-READ-FOR-UPDATE-X
                   END-IF
                   IF  L0201-RETRN-OK
                       MOVE 'XS00000307'     TO  WGLOB-MSG-REF-INFO
      *MSG: 'AUTO REDO PROCESSING COMPLETED
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                   ELSE
                       SET WS-REDO-NOT-OK    TO TRUE
                       IF  NOT L0201-INCOMPLETE-DUE-ACTV
                           MOVE 'XS00000308' TO WGLOB-MSG-REF-INFO
      *MSG: PROBLEM IN AUTO REDO PROCESSING
                           PERFORM  0260-1000-GENERATE-MESSAGE
                               THRU 0260-1000-GENERATE-MESSAGE-X
                       END-IF
                   END-IF
           END-EVALUATE.

       8550-INVOKE-REDO-X.
           EXIT.

      *-----------------
       8600-INVOKE-UNDO.
      *-----------------

           PERFORM  4750-1000-BUILD-PARM-INFO
               THRU 4750-1000-BUILD-PARM-INFO-X.

           SET L4750-FCN-DRVR-SECONDARY      TO TRUE.
           IF  WS-BUS-FCN-TSFR
               MOVE WS-EFF-DT                TO L4750-EFF-DT
           ELSE
               MOVE WGLOB-PROCESS-DATE       TO L4750-EFF-DT
           END-IF.
           MOVE MIR-SUPRES-CNFRM-IND         TO L4750-SUPP-CONF-CD.
           SET  L4750-PRCES-EXCLUSIVE        TO TRUE

      *  UNLOCK POLICY PRIOR TO UNDO

           PERFORM  POL-3000-UNLOCK
               THRU POL-3000-UNLOCK-X.

           PERFORM  4750-1000-UNDO-PROCESSING
               THRU 4750-1000-UNDO-PROCESSING-X.

           IF  NOT L4750-RETRN-OK
               SET MIR-RETRN-EDIT-ERROR      TO TRUE
               SET WGLOB-RETURN-ERROR        TO TRUE
           END-IF.

           IF  WGLOB-RETURN-ERROR
           AND L4750-POL-UPDATE-NOT-REQD
               GO TO 8600-INVOKE-UNDO-X
           END-IF.

      *  LOCK POLICY AGAIN IN ORDER TO DO UPDATES
      *  SAVE POLICY INFO TO RESTORE AFTER READ FOR UPDATE

           MOVE  RPOL-REC-INFO               TO  HPOL-REC-INFO.
           MOVE  RPOL-KEY                    TO  WPOL-KEY.
           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.
           MOVE HPOL-REC-INFO                TO  RPOL-REC-INFO.

           IF  L4750-POL-UPDATE-REQD

               PERFORM  8700-UPDATE-POL-CVG
                   THRU 8700-UPDATE-POL-CVG-X

               IF  WGLOB-GOOD-RETURN
                   MOVE  RPOL-KEY            TO  WPOL-KEY
                   PERFORM  POL-1000-READ-FOR-UPDATE
                       THRU POL-1000-READ-FOR-UPDATE-X
               END-IF

           END-IF.

       8600-INVOKE-UNDO-X.
           EXIT.

      *---------------------
       8700-UPDATE-POL-CVG.
      *---------------------

      *  UPDATE THE POLICY AND COVERAGES

           PERFORM  8720-SET-POL-NXT-ACTV
               THRU 8720-SET-POL-NXT-ACTV-X.
           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.
           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.
           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

       8700-UPDATE-POL-CVG-X.
           EXIT.

      *----------------------
       8720-SET-POL-NXT-ACTV.
      *----------------------

           PERFORM  0289-1000-INIT-PARM-INFO
               THRU 0289-1000-INIT-PARM-INFO-X.
           MOVE WS-EFF-DT                    TO L0289-LO-PAC-DT
           MOVE WS-EFF-DT                    TO L0289-LO-CRC-DT
           MOVE WS-EFF-DT                    TO L0289-LO-DD2-DT.
           MOVE WS-EFF-DT                    TO L0289-PROC-EFF-DT
           PERFORM  0289-1000-OBTAIN-NXT-ACTV
               THRU 0289-1000-OBTAIN-NXT-ACTV-X.

           IF  L0289-RETRN-OK
                MOVE L0289-NXT-ACTV-TYP-CD   TO RPOL-NXT-ACTV-TYP-CD
                MOVE L0289-NXT-ACTV-DT       TO RPOL-POL-NXT-ACTV-DT
            ELSE
                MOVE 'RSH'                   TO RPOL-NXT-ACTV-TYP-CD
                MOVE WGLOB-PROCESS-DATE      TO RPOL-POL-NXT-ACTV-DT
            END-IF.

       8720-SET-POL-NXT-ACTV-X.
           EXIT.

      *-------------------------
       9100-CLEAR-DATA-FIELDS.
      *-------------------------

           MOVE SPACES                    TO MIR-CVG-NUM-G.
           MOVE SPACES                    TO MIR-PLAN-ID-G.
           MOVE SPACES                    TO MIR-FND-ID-G.
           MOVE SPACES                    TO MIR-DV-CFN-APROX-AMT-G.
           MOVE SPACES                    TO MIR-DV-FROM-FND-AMT-G.
           MOVE SPACES                    TO MIR-DV-TO-FND-AMT-G.
           MOVE SPACES                    TO MIR-FIA-OUT-ALLOC-PCT-G.
           MOVE SPACES                    TO MIR-FIA-IN-ALLOC-PCT-G.
           MOVE SPACES                    TO MIR-FIA-OUT-ALLOC-PCT-G.
           MOVE SPACES                    TO MIR-FIA-CRCY-CD-G.
           MOVE SPACES                    TO MIR-CIA-CRCY-CD-G.
           MOVE SPACES                    TO MIR-DV-FIA-POL-CRCY-AMT-G.

       9100-CLEAR-DATA-FIELDS-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                    TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE        TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                       TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE           TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX            TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0201-0000-INIT-PARM-INFO
               THRU 0201-0000-INIT-PARM-INFO-X.

           PERFORM  0279-0000-INIT-PARM-INFO
               THRU 0279-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0289-0000-INIT-PARM-INFO
               THRU 0289-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  0620-0000-INIT-PARM-INFO
               THRU 0620-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

           PERFORM  2430-0000-INIT-PARM-INFO
               THRU 2430-0000-INIT-PARM-INFO-X.

           PERFORM  2626-0000-INIT-PARM-INFO
               THRU 2626-0000-INIT-PARM-INFO-X.

           PERFORM  4750-0000-INIT-PARM-INFO
               THRU 4750-0000-INIT-PARM-INFO-X.

           PERFORM  4780-0000-INIT-PARM-INFO
               THRU 4780-0000-INIT-PARM-INFO-X.

           PERFORM  5400-0000-INIT-PARM-INFO
               THRU 5400-0000-INIT-PARM-INFO-X.

           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           PERFORM  8150-0000-INIT-PARM-INFO
               THRU 8150-0000-INIT-PARM-INFO-X.

           PERFORM  8180-0000-INIT-PARM-INFO
               THRU 8180-0000-INIT-PARM-INFO-X.

           PERFORM  8200-0000-INIT-PARM-INFO
               THRU 8200-0000-INIT-PARM-INFO-X.

           PERFORM  8233-0000-INIT-PARM-INFO
               THRU 8233-0000-INIT-PARM-INFO-X.

           PERFORM  8640-0000-INIT-PARM-INFO
               THRU 8640-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORK-FIELDS.
           INITIALIZE LFUND-FND-CTR.
           INITIALIZE LFUND-ACTV-CD.
           INITIALIZE FREQUENTLY-USED-INDICES.

           INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
           INITIALIZE WLOCK-TWRK-OTHER-INFO.

           PERFORM
               VARYING I FROM +1 BY +1
               UNTIL I > LFUND-FND-MAX-CTR

               INITIALIZE LFUND-FND-INFO (I)

           END-PERFORM.

           SET WS-BASIC-EDIT-OK              TO TRUE.

           MOVE SPACES                       TO WWKDT-WORK-FIELDS.
           MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      ****************************************************************
      *   PROCESSING COPYBOOKS
      ****************************************************************

       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY CCPPFPCK.
       COPY NCPPCVGR.
       COPY NCPPCVGS.

       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                                '$VAR2' BY 'POL'.
       COPY XCPPINIT.
       COPY XCPPEXIT.

       COPY CCPEPLAN.
       COPY CCPESGFD.
      /
      ****************************************************************
      *   LINKAGE COPYBOOKS
      ****************************************************************

       COPY XCPS8090.
       COPY XCPS8640.
       COPY CCPS0201.
       COPY CCPL0201.

       COPY CCPS0289.
       COPY CCPL0289.

       COPY CCPS0620.
       COPY CCPL0620.

       COPY CCPS2430.
       COPY CCPL2430.

       COPY CCPS2626.
       COPY CCPL2626.

       COPY CCPS4750.
       COPY CCPL4750.

       COPY CCPS4780.
       COPY CCPL4780.

       COPY CCPS5400.
       COPY CCPL5400.

       COPY CCPS8233.
       COPY CCPL8233.

       COPY CCPSPGA.

031034*COPY CCPSPGAL.

       COPY FCPS8150.
       COPY FCPL8150.

       COPY FCPS8200.
       COPY FCPL8200.

       COPY FCPS8180.
       COPY FCPL8180.

036742*COPY XCPL0035.

       COPY XCPL0260.

       COPY XCPS0279.
       COPY XCPL0279.

       COPY XCPS0280.
       COPY XCPL0280.

       COPY XCPS0290.
       COPY XCPL0290.

       COPY XCPS1640.
       COPY XCPL1640.

       COPY XCPL8090.

       COPY XCPL8640.
      /
      *****************************************************************
      *   FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.

       COPY CCPAPORQ.
       COPY CCPCPORQ.

       COPY CCPNCVG.

       COPY CCPUCVG.

       COPY CCPNEDIT.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************

       COPY XCCP0030.

       COPY XCCPERR.

      *****************************************************************
      **                 END OF PROGRAM CSOM8223                     **
      *****************************************************************
