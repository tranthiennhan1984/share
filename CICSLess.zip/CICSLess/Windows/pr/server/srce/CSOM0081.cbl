      *****************************************************************
      **  MEMBER :  CSOM0081                                         **
      **  REMARKS:  AGNT/STAG PROCESS DRIVER                         **
      **            THIS PROGRAM WILL VALIDATE AND MAINTAIN THE      **
      **            WRITING AND SERVICING AGENTS FOR BUSINESS        **
      **            APPLICATIONS.                                    **
      **                                                             **
      **  DOMAIN :  AG                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       DATA ARCHITECTURE MODIFICATIONS                  **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557667**  5.5       ADDITIONAL CLIENT RELATED INFO                   **
557668**  5.5       STANDARD CLIENT SCREEN NAME FORMATTING           **
557670**  5.5       MODIFICATIONS FOR AGENT PAYMENTS VIA EFT         **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
557973**  5.5       AMOUNT FIELDS SIZE CHANGES                       **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       VSAM TAGS REMOVED                                **
010418**  5.6       MODIFICATIONS FOR MULTI-COMPANY                  **
010793**  5.6       INCORRECT CURSOR PLACEMENT WHEN EDITING          **
010793**            THE BRANCH CODE FIELD                            **
012148**  5.6V      ADD TRAIL COMMISSION INDICATOR TO SCREEN-02      **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015543**  6.0       CODE CLEANUP                                     **
014221**  6.2       LOGICAL LOCKING                                  **
016440**  6.2       COMBINE NB AND ADMIN - ONLINE REQUIREMENTS       **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017235**  6.2       CLEAN UP TRANSFER AGENT NAME                     **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019524**  6.4       PCT DATABASE FIELDS CHANGED NUMERIC              **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
016955**  6.5       SET UP AGT-CMPNST-SCHD-CD IN EDIT TABLE          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
028786**  6.7       EXTERNAL AGENCY INTEGRATION - COMPENSATION CALC. **
030652**  6.7       AGENT TRANSFER INFORMATION                       **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

       IDENTIFICATION DIVISION.

       PROGRAM-ID.    CSOM0081.

       COPY XCWWCRHT.

      **********************
       ENVIRONMENT DIVISION.
      **********************
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0081'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

025970*01  WS-PGM-IDENTIFIER.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'AGNT'.
      /
       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '1420' '1421'
                                                  '1422' '1423'
                                                  '1424'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '1420'.
               88  WS-BUS-FCN-CREATE        VALUE '1421'.
               88  WS-BUS-FCN-UPDATE        VALUE '1422'.
               88  WS-BUS-FCN-DELETE        VALUE '1423'.
               88  WS-BUS-FCN-LIST          VALUE '1424'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '1420'.
016548*    05  INDX-CHAR                    PIC S9(04) COMP SYNC.
016548     05  INDX-CHAR                    PIC S9(04) BINARY SYNC.
016548*    05  INDX-BLANK                   PIC S9(04) COMP SYNC.
016548     05  INDX-BLANK                   PIC S9(04) BINARY SYNC.
016548*    05  L-SUB                        PIC S9(04) COMP SYNC.
016548     05  L-SUB                        PIC S9(04) BINARY SYNC.
016548*    05  M-SUB                        PIC S9(04) COMP SYNC.
016548     05  M-SUB                        PIC S9(04) BINARY SYNC.
016548*    05  N-SUB                        PIC S9(04) COMP SYNC.
016548     05  N-SUB                        PIC S9(04) BINARY SYNC.
016548*    05  WS-LINES-ON-SCREEN           PIC S9(04) COMP SYNC.
016548     05  WS-LINES-ON-SCREEN           PIC S9(04) BINARY SYNC.
016548*    05  WS-SUB                       PIC S9(04) COMP SYNC.
016548     05  WS-SUB                       PIC S9(04) BINARY SYNC.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(04) COMP SYNC
025970*    05  WS-MAX-BROWSE-LINES          PIC S9(04) BINARY SYNC
025970*                                     VALUE +12.
           05  WS-COMPRESSED-NAME           PIC X(51)  VALUE SPACES.
           05  WS-AGENT-RL-FOUND-SW         PIC X(01) VALUE 'N'.
               88  WS-AGENT-RL-FOUND        VALUE 'Y'.
025970         88  WS-AGENT-RL-NOT-FOUND    VALUE 'N'.
      /
      /
       01  WS-EDIT-CHECKS.

           05  WS-ERROR-SW                  PIC X(01).
               88  ERROR-FOUND              VALUE 'Y'.
               88  NO-ERRORS-FOUND          VALUE 'N'.

557667*    WORK AREA TO STORE THE 'R' AND 'M' AGENT CLIENT RELATIONSHIPS
557667 01  WS-AGNT-CLI-REL-GR.
557667     05  WS-MAIL-CLIENT-READ          PIC X(01).
557667         88  MAIL-CLIENT-READ         VALUE 'Y'.
557667         88  MAIL-CLIENT-NOT-READ     VALUE 'N'.
557667     05  WS-MAIL-CLIENT.
557667         10  WS-MAIL-CLI-ID           PIC X(10).
557667         10  WS-MAIL-ADDR-TYP-CD      PIC X(02).
557670         10  WS-MAIL-BNK-ACCT-NUM     PIC S9(03) COMP-3.
557667     05  WS-RES-CLIENT-READ           PIC X(01).
557667         88  RES-CLIENT-READ          VALUE 'Y'.
557667         88  RES-CLIENT-NOT-READ      VALUE 'N'.
557667     05  WS-RES-CLIENT.
557667         10  WS-RES-CLI-ID            PIC X(10).
557667         10  WS-RES-ADDR-TYP-CD       PIC X(02).
557670         10  WS-RES-BNK-ACCT-NUM      PIC S9(03) COMP-3.
557667
       01  OTHER-MISC-WORK-AREAS.

008455*    05  EDIT-1                       PIC Z(6)9.99.
           05  EDIT-2                       PIC 999.99.
008455*    05  EDIT-3                       PIC ---------9.
008455*    05  EDIT-3D                      PIC +999999999.
008455*    05  EDIT-4                       PIC 9(5).99.
008455*    05  EDIT-4S                      PIC -9(5).99.
           05  EDIT-5                       PIC 99.
008455*    05  EDIT-6                       PIC 9999.
008455*    05  EDIT-7                       PIC -------9.99.
           05  EDIT-8                       PIC 9.
           05  HOLD-AGENT                   PIC X(06).
           05  HOLD-AGENT-CHARS REDEFINES HOLD-AGENT.
               10  AGENT-CHAR               PIC X(01) OCCURS 6 TIMES.
008455*    05  PART-ADV-AMT                 PIC 9(05)V99.
008455     05  PART-ADV-AMT                 PIC 9(11)V99.
           05  PART-ADV-TYP                 PIC X(01).
           05  PARTIAL-ADV-SW               PIC X(01).
               88  VALID-NUMERIC-ADVANCE    VALUE 'Y'.

           05  HOLD-5.
               10  HOLD-5-NO                PIC 9(02).
           05  HOLD-5-R REDEFINES HOLD-5    PIC X(02).

           05  HOLD-6.
               10  HOLD-6-NO                PIC 9(04).
           05  HOLD-6-R REDEFINES HOLD-6    PIC X(04).
010418     05  WS-AGT-PAYBL-BAL-AMT         PIC S9(11)V99 COMP-3.


025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-TRANS-NAME-DEFAULT    VALUE 'AGNT'.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '1420'.
025970     05  WS-MAX-BROWSE-LINES          PIC S9(04) BINARY SYNC.
025970         88  WS-MAX-BROWSE-LINES-DEFAULT  VALUE +12.
      /
       COPY CCWL2440.
028298 COPY CCWL2626.
      /
       COPY CCFWAG.
       COPY CCFRAG.
      /
       COPY CCFRBRCH.
       COPY CCFWBRCH.
      /
       COPY CCFWAB.
016537*COPY CCFRAB.
      /
028786 COPY CCFWAGRC.
028786 COPY CCFRAGRC.
028786/
028786 COPY CCFWAGRP.
028786 COPY CCFRAGRP.
028786/
       COPY CCFWAS.
       COPY CCFRAS.
      /
       COPY CCFWCC.
       COPY CCFRCC.
      /
028786*COPY CCFWRL.
028786*COPY CCFRRL.
028786*
       COPY CCFWEDIT.
       COPY CCFREDIT.
008455/
008455 COPY XCFWCRCY.
008455 COPY XCFRCRCY.
      /
020478*COPY CCFWCLIN.
020478*COPY CCFRCLIB.
557670/
       COPY XCWEBLCH.
      /
       COPY CCWL2435.
      /
020478 COPY CCWL5020.
      /
557667 COPY CCWL0840.
      /
557668 COPY CCWL0620.
557668/
       COPY XCWL0280.
      /
008455 COPY XCWL0290.
008455/
014221 COPY XCWL8090.
014221
       COPY XCWLDTLK.
       COPY XCWL1640.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
557659 COPY XCWWWKDT.
014221 COPY CCWWLOCK.
557659/
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0081.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

025970*    MOVE MIR-BUS-FCN-ID     TO  WS-BUS-FCN-ID.
025970*    SET  MIR-RETRN-OK       TO  TRUE.

           IF  NOT WS-BUS-FCN-VALID
               SET MIR-RETRN-INVALD-RQST TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

008455     PERFORM 0290-1000-BUILD-PARM-INFO
008455        THRU 0290-1000-BUILD-PARM-INFO-X.
008455

           MOVE 'N'                   TO WS-ERROR-SW.
557667     SET RES-CLIENT-NOT-READ   TO TRUE.
557667     SET MAIL-CLIENT-NOT-READ  TO TRUE.


           IF WS-BUS-FCN-CREATE
           OR WS-BUS-FCN-RETRIEVE
           OR WS-BUS-FCN-UPDATE
           OR WS-BUS-FCN-DELETE
               MOVE MIR-AGT-ID        TO WAG-AGT-ID
010418*        MOVE MIR-AGT-ID        TO WAB-AGT-ID
               PERFORM  AG-1000-READ
                   THRU AG-1000-READ-X
010418*        PERFORM  AB-1000-READ
010418*            THRU AB-1000-READ-X
               IF WS-BUS-FCN-CREATE
                   IF WAG-IO-OK
010418*            OR WAB-IO-OK
                       MOVE 'CS00810001'
                                      TO WGLOB-MSG-REF-INFO
                       MOVE 'Y'       TO WS-ERROR-SW
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                   END-IF
               ELSE
                   IF NOT WAG-IO-OK
                       MOVE 'XS00000064'
                                      TO WGLOB-MSG-REF-INFO
                       MOVE WAG-KEY   TO WGLOB-MSG-PARM (1)
                       MOVE 'Y'       TO WS-ERROR-SW
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                   ELSE
010418*                IF NOT WAB-IO-OK
010418*                    MOVE 'CS00810030' TO WGLOB-MSG-REF-INFO
010418*                    MOVE WAB-KEY      TO WGLOB-MSG-PARM (1)
010418*                    MOVE 'Y'          TO WS-ERROR-SW
010418*                    PERFORM  0260-1000-GENERATE-MESSAGE
010418*                        THRU 0260-1000-GENERATE-MESSAGE-X
010418*                END-IF
557667                 PERFORM  7100-GET-AGT-RELATIONSHIPS
557667                     THRU 7100-GET-AGT-RELATIONSHIPS-X
                   END-IF
               END-IF
           END-IF.

           IF  ERROR-FOUND
               PERFORM  2400-CLEAR-SCREEN-VALUES
                   THRU 2400-CLEAR-SCREEN-VALUES-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           EVALUATE TRUE
              WHEN  WS-BUS-FCN-RETRIEVE
                 PERFORM  3000-PROCESS-RETRIEVE
                    THRU  3000-PROCESS-RETRIEVE-X

              WHEN  WS-BUS-FCN-LIST
                 PERFORM  3500-PROCESS-LIST
                    THRU  3500-PROCESS-LIST-X

              WHEN  WS-BUS-FCN-CREATE
                 PERFORM  4000-PROCESS-CREATE
                    THRU  4000-PROCESS-CREATE-X

              WHEN  WS-BUS-FCN-UPDATE
                 PERFORM  5000-PROCESS-UPDATE
                    THRU  5000-PROCESS-UPDATE-X

              WHEN  WS-BUS-FCN-DELETE
                 PERFORM  6000-PROCESS-DELETE
                    THRU  6000-PROCESS-DELETE-X

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-------------------------
       2400-CLEAR-SCREEN-VALUES.
      *-------------------------

           MOVE SPACES                TO  MIR-AGT-ID-G.
           MOVE SPACES                TO  MIR-DV-AGT-CLI-NM-G.
           MOVE SPACES                TO  MIR-BR-ID-G.
           MOVE SPACES                TO  MIR-AGT-STAT-CD-G.
           MOVE SPACES                TO  MIR-AGT-CMPNST-SCHD-CD-G.
           MOVE SPACES                TO  MIR-OVRID-BASE-AGT-ID-G.
010418     MOVE SPACES                TO  MIR-OVRID-ID-G.
      *  SCREEN 02
           MOVE SPACES                TO  MIR-CLI-ID.
           MOVE SPACES                TO  MIR-ADDR-TYP-CD.
           MOVE SPACES                TO  MIR-DV-AGT-MAIL-CLI-ID.
           MOVE SPACES                TO  MIR-DV-AGT-MAIL-TYP-CD.
           MOVE SPACES                TO  MIR-AGT-PHON-NUM.
           MOVE SPACES                TO  MIR-BR-ID.
           MOVE SPACES                TO  MIR-AGT-CMPNST-CRCY-CD.
           MOVE SPACES                TO  MIR-AGT-CNTRCT-STRT-DT.
           MOVE SPACES                TO  MIR-OVRID-BASE-AGT-ID.
           MOVE SPACES                TO  MIR-AGT-CNTRCT-TRMN-DT.
           MOVE SPACES                TO  MIR-OVRID-ID.
           MOVE SPACES                TO  MIR-FYR-COMM-CALC-CD.
           MOVE SPACES                TO  MIR-PARTL-ADV-COMM-CD.
           MOVE SPACES                TO  MIR-RENW-COMM-CALC-CD.
           MOVE SPACES                TO  MIR-PARTL-ADV-COMM-AMT.
           MOVE SPACES                TO  MIR-AGT-SERV-FEE-IND.
           MOVE SPACES                TO  MIR-SERV-COMM-RTBL2-ID.
           MOVE SPACES                TO  MIR-AUTO-COMM-PMT-CD.
           MOVE SPACES                TO  MIR-AGT-CCAS-QUALF-IND.
557670     MOVE SPACES                TO  MIR-AGT-PMT-MTHD-CD.
557670     MOVE SPACES                TO  MIR-BNK-ACCT-NUM.
           MOVE SPACES                TO  MIR-AGT-LOC-LIC-CD.
           MOVE SPACES                TO  MIR-AGT-CLAS-LIC-CD.
      * SCREEN 03
           MOVE SPACES                TO  MIR-AGT-STAT-CD.
557659*    MOVE SPACES TO  MIR-PREV.
557659     MOVE SPACES                TO  MIR-PREV-AGT-ID.
557659     MOVE SPACES                TO  MIR-PREV-BR-ID.
           MOVE SPACES                TO  MIR-AGT-TYP-CD.
           MOVE SPACES                TO  MIR-AGT-SPNSR-LIC-IND.
           MOVE SPACES                TO  MIR-AGT-CMPNST-SCHD-CD.
           MOVE SPACES                TO  MIR-AGT-PRIM-LIC-ID.
           MOVE SPACES                TO  MIR-NMED-UWG-PRVLG-IND.
           MOVE SPACES                TO  MIR-AGT-COMM-WTHLD-PCT.
           MOVE SPACES                TO  MIR-AGT-BROK-OVRID-IND.
           MOVE SPACES                TO  MIR-DEV-PGM-INCM-AMT.
           MOVE SPACES                TO  MIR-AGT-FRNG-BNFT-IND.
           MOVE SPACES                TO  MIR-AGT-VEST-INT-AMT.
           MOVE SPACES                TO  MIR-QLTY-BON-PGM-IND.
           MOVE SPACES                TO  MIR-AGT-OTHR-CMPNST-CD.
           MOVE SPACES                TO  MIR-AGT-FIN-ARANG-IND.
010418* SCREEN 04
010418*    MOVE SPACES TO  MIR-FYRCMO.
010418*    MOVE SPACES TO  MIR-FYRYTD.
010418*    MOVE SPACES TO  MIR-RYRCMO.
010418*    MOVE SPACES TO  MIR-RYRYTD.
010418*    MOVE SPACES TO  MIR-BONCMO.
010418*    MOVE SPACES TO  MIR-BONYTD.
010418*    MOVE SPACES TO  MIR-PAYCMO.
010418*    MOVE SPACES TO  MIR-PAYYTD.
010418*    MOVE SPACES TO  MIR-CURBAL.
           MOVE SPACES                TO  MIR-XFER-SERV-AGT-ID.
           MOVE SPACES                TO  MIR-SERV-AGT-XFER-DT.
           MOVE SPACES                TO  MIR-DV-SERV-AGT-CLI-NM.
           MOVE SPACES                TO  MIR-XFER-WRIT-AGT-ID.
           MOVE SPACES                TO  MIR-WRIT-AGT-XFER-DT.
           MOVE SPACES                TO  MIR-DV-WRIT-AGT-NM.
           MOVE SPACES                TO  MIR-XFER-COMM-AGT-ID.
           MOVE SPACES                TO  MIR-COMM-AGT-XFER-DT.
           MOVE SPACES                TO  MIR-DV-COMM-AGT-NM.
010418*  SCREEN 05
010418*    MOVE SPACES TO  MIR-FAMT-TABLE.
010418*    MOVE SPACES TO  MIR-RAMT-TABLE.
010418*  SCREEN 06
010418*    MOVE SPACES TO  MIR-PRST-TABLE.
010418*    MOVE SPACES TO  MIR-PRDL-TABLE.
010418*    MOVE SPACES TO  MIR-MDRT-TABLE.
010418*    MOVE SPACES TO  MIR-CONV-TABLE.
010418*    MOVE SPACES TO  MIR-APPA-TABLE.
010418*    MOVE SPACES TO  MIR-NQA-TABLE.
010418*  SCREEN 07
010418*    MOVE SPACES TO  MIR-FPRCMO.
010418*    MOVE SPACES TO  MIR-FPRYTD.
010418*    MOVE SPACES TO  MIR-FCMCMO.
010418*    MOVE SPACES TO  MIR-FCMYTD.
010418*    MOVE SPACES TO  MIR-RPRCMO.
010418*    MOVE SPACES TO  MIR-RPRYTD.
010418*    MOVE SPACES TO  MIR-RCMCMO.
010418*    MOVE SPACES TO  MIR-RCMYTD.
010418*    MOVE SPACES TO  MIR-QTYCMO.
010418*    MOVE SPACES TO  MIR-QTYYTD.
010418*    MOVE SPACES TO  MIR-MKTCMO.
010418*    MOVE SPACES TO  MIR-MKTYTD.
010418*    MOVE SPACES TO  MIR-NHCMO.
010418*    MOVE SPACES TO  MIR-NHYTD.
010418*    MOVE SPACES TO  MIR-PRWCMO.
010418*    MOVE SPACES TO  MIR-PRWYTD.
010418*    MOVE SPACES TO  MIR-LPRCMO.
010418*    MOVE SPACES TO  MIR-LPRYTD.
010418*    MOVE SPACES TO  MIR-APPCMO.
010418*    MOVE SPACES TO  MIR-APPYTD.

       2400-CLEAR-SCREEN-VALUES-X.
           EXIT.
      /
      *-----------------------
       3000-PROCESS-RETRIEVE.
      *-----------------------

014221     MOVE MIR-AGT-ID        TO WAG-AGT-ID.

014221     PERFORM  AG-1000-READ-TWRK-TS
014221         THRU AG-1000-READ-TWRK-TS-X.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.


       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /

      *--------------------
       3200-GET-AGENT-NAME.
      *--------------------

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

557667     IF  RES-CLIENT-NOT-READ
557667         PERFORM  7100-GET-AGT-RELATIONSHIPS
557667             THRU 7100-GET-AGT-RELATIONSHIPS-X
557667     END-IF.
557667*    IF  RAG-RES-ADDR-CLI-ID = SPACES
557667     IF  WS-RES-CLI-ID = SPACES
557668         MOVE SPACES            TO L0620-SCREEN-NAME
               GO TO 3200-GET-AGENT-NAME-X
           END-IF.

557667*    MOVE RAG-RES-ADDR-CLI-ID  TO L2435-CLI-ID.
557667     MOVE WS-RES-CLI-ID         TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.

557668     IF  L2435-RETRN-OK
557668         PERFORM  7300-GET-STD-FMT-CLI-NAME
557668             THRU 7300-GET-STD-FMT-CLI-NAME-X
557668     ELSE
557668         MOVE SPACES            TO L0620-SCREEN-NAME
557668     END-IF.
557668
       3200-GET-AGENT-NAME-X.
           EXIT.
      /

      *--------------------------
       3300-GET-TRANS-AGENT-NAME.
      *--------------------------

017235     MOVE SPACES                TO WS-COMPRESSED-NAME.

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           PERFORM  AG-1000-READ
               THRU AG-1000-READ-X.

           IF  WAG-IO-OK
557667*        MOVE RAG-RES-ADDR-CLI-ID TO L2435-CLI-ID
557667         CONTINUE
557667     ELSE
557667         GO TO 3300-GET-TRANS-AGENT-NAME-X
557667     END-IF.
557667
557667*    GET AGENT RESIDENTIAL RELATIONSHIP
557667     INITIALIZE L0840-IO-PARM-INFO.
557667     MOVE RAG-AGT-ID            TO L0840-AGT-ID.
557667     SET L0840-REL-TYP-RESIDENTIAL  TO TRUE.
557667     PERFORM  0840-5000-GET-AGT-REL
557667         THRU 0840-5000-GET-AGT-REL-X.
557667     IF L0840-RETRN-OK
557667         MOVE L0840-CLI-ID      TO L2435-CLI-ID
               PERFORM  2435-1000-OBTAIN-CLI-INFO
                   THRU 2435-1000-OBTAIN-CLI-INFO-X
               IF  L2435-RETRN-OK
557668*            MOVE L2435-CLI-NM-COMPRESSED TO WS-COMPRESSED-NAME
557668             PERFORM  7300-GET-STD-FMT-CLI-NAME
557668                 THRU 7300-GET-STD-FMT-CLI-NAME-X
557668             MOVE L0620-SCREEN-NAME
                                      TO WS-COMPRESSED-NAME
               ELSE
                   MOVE SPACES        TO WS-COMPRESSED-NAME
               END-IF
           END-IF.

       3300-GET-TRANS-AGENT-NAME-X.
           EXIT.
      /

      *------------------
       3500-PROCESS-LIST.
      *------------------

           MOVE SPACES                TO MIR-DV-AGT-CLI-NM-G.
           MOVE SPACES                TO MIR-BR-ID-G.
           MOVE SPACES                TO MIR-AGT-STAT-CD-G.
010418*    MOVE SPACES                 TO MIR-BALA-G.
           MOVE SPACES                TO MIR-AGT-CMPNST-SCHD-CD-G.
           MOVE SPACES                TO MIR-OVRID-BASE-AGT-ID-G.
           MOVE SPACES                TO MIR-OVRID-ID-G.

           MOVE LOW-VALUES            TO WAG-KEY.
           IF MIR-AGT-ID  = SPACES
               MOVE LOW-VALUES        TO WAG-KEY
               MOVE SPACES            TO MIR-AGT-ID-G
           ELSE
               MOVE MIR-AGT-ID        TO WAG-AGT-ID
               IF WGLOB-MSG-ERROR-SW > ZERO
                   MOVE MIR-AGT-ID-T (1)
                                      TO WAG-AGT-ID
               ELSE
                   MOVE SPACES        TO MIR-AGT-ID-G
               END-IF
           END-IF.
           MOVE HIGH-VALUES           TO WAG-ENDBR-KEY.

           PERFORM  AG-1000-BROWSE
               THRU AG-1000-BROWSE-X.

           IF WAG-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM  AG-2000-READ-NEXT
               THRU AG-2000-READ-NEXT-X.

           IF WAG-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               MOVE WAG-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM  3510-PROCESS-BROWSE-READ
               THRU 3510-PROCESS-BROWSE-READ-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-BROWSE-LINES
               OR    WAG-IO-EOF.

           IF WAG-IO-EOF
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               MOVE WAG-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE MIR-AGT-ID-T (01) TO MIR-AGT-ID
           ELSE
               IF WGLOB-MSG-ERROR-SW = ZERO
                   SET WGLOB-MORE-DATA-EXISTS TO TRUE
                   MOVE 'XS00000014'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE RAG-AGT-ID    TO MIR-AGT-ID
               END-IF
           END-IF.

           PERFORM  AG-3000-END-BROWSE
               THRU AG-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /

      *-------------------------
       3510-PROCESS-BROWSE-READ.
      *-------------------------

           MOVE RAG-AGT-ID            TO  MIR-AGT-ID-T (WS-SUB).

557667     SET RES-CLIENT-NOT-READ      TO TRUE.
557667     SET MAIL-CLIENT-NOT-READ     TO TRUE.
           PERFORM  3200-GET-AGENT-NAME
               THRU 3200-GET-AGENT-NAME-X.

557668*    MOVE L2435-CLI-NM-COMPRESSED TO MIR-DV-AGT-CLI-NM-T (WS-SUB).
557668     MOVE L0620-SCREEN-NAME     TO  MIR-DV-AGT-CLI-NM-T (WS-SUB).
           MOVE RAG-BR-ID             TO  MIR-BR-ID-T (WS-SUB).
           MOVE RAG-AGT-STAT-CD       TO  MIR-AGT-STAT-CD-T (WS-SUB).
010418*    MOVE RAG-AGT-ID              TO  WAB-AGT-ID.

010418*    PERFORM  AB-1000-READ
010418*        THRU AB-1000-READ-X.

010418*    IF  WAB-IO-OK
010418*        NEXT SENTENCE
010418*    ELSE
010418*        MOVE ZEROS              TO  RAB-AGT-PAYBL-BAL-AMT
010418*    END-IF.

008455*    MOVE RAB-AGT-PAYBL-BAL-AMT  TO  EDIT-7.
008455*    MOVE EDIT-7                 TO  MIR-BALA-T (WS-SUB).
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PAYBL-BAL-AMT * 100.
010418*    MOVE +2                     TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-BALA-T (WS-SUB)
010418*                                TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY     TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
010418*    SET  L0290-SIGN-FLOAT       TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA      TO  MIR-BALA-T (WS-SUB).
008455
           MOVE RAG-AGT-CMPNST-SCHD-CD
                                  TO  MIR-AGT-CMPNST-SCHD-CD-T (WS-SUB).
           MOVE RAG-OVRID-BASE-AGT-ID
                                   TO  MIR-OVRID-BASE-AGT-ID-T (WS-SUB).
           MOVE RAG-OVRID-ID          TO  MIR-OVRID-ID-T (WS-SUB).

           PERFORM  AG-2000-READ-NEXT
               THRU AG-2000-READ-NEXT-X.

       3510-PROCESS-BROWSE-READ-X.
           EXIT.

      /
      *--------------------
       4000-PROCESS-CREATE.
      *--------------------

      ***  ENSURE THAT AGENT NUMBER DOES NOT HAVE IMBEDDED SPACES

           MOVE WAG-AGT-ID            TO HOLD-AGENT.

           PERFORM
               VARYING INDX-CHAR FROM 6 BY -1
               UNTIL INDX-CHAR < 1
               OR AGENT-CHAR (INDX-CHAR) NOT = SPACE
015543         CONTINUE
           END-PERFORM.

           PERFORM
               VARYING INDX-BLANK FROM 1 BY 1
               UNTIL INDX-BLANK > 6
               OR AGENT-CHAR (INDX-BLANK) = SPACE
015543         CONTINUE
           END-PERFORM.

           IF  INDX-BLANK        <  INDX-CHAR
           OR  WAG-AGT-ID        =  SPACES
               MOVE 'CS00810002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  2400-CLEAR-SCREEN-VALUES
                   THRU 2400-CLEAR-SCREEN-VALUES-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  AG-1000-CREATE
               THRU AG-1000-CREATE-X.

      *  DEFAULT VALUE FOR NEW FIELDS
557667*    MOVE 'PR'             TO RAG-RES-CLI-ADDR-ID.
557667*    MOVE 'PR'             TO WS-MAIL-ADDR-TYP-CD.

010418*    PERFORM  AB-1000-CREATE
010418*        THRU AB-1000-CREATE-X.

           PERFORM  AG-1000-WRITE
               THRU AG-1000-WRITE-X.
010418*    PERFORM  AB-1000-WRITE
010418*        THRU AB-1000-WRITE-X.

014221     PERFORM  AG-1000-READ-TWRK-TS
014221         THRU AG-1000-READ-TWRK-TS-X.

557667*  SAVE AGENT RELATIONSHIPS
557667     INITIALIZE WS-RES-CLIENT.
557667     MOVE WAG-AGT-ID            TO WS-RES-CLI-ID.
557667     MOVE 'PR'                  TO WS-RES-ADDR-TYP-CD.
557667     INITIALIZE WS-MAIL-CLIENT.
557667     MOVE WAG-AGT-ID            TO WS-MAIL-CLI-ID.
557667     MOVE 'PR'                  TO WS-MAIL-ADDR-TYP-CD.
557667     SET RES-CLIENT-READ   TO TRUE.
557667     SET MAIL-CLIENT-READ  TO TRUE.
557667

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           MOVE 'CS00810004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.


       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *---------------------
       5000-PROCESS-UPDATE.
      *---------------------

           MOVE MIR-AGT-ID            TO WAG-AGT-ID.

014221*    PERFORM  AG-1000-READ-FOR-UPDATE
014221*        THRU AG-1000-READ-FOR-UPDATE-X.

014221     PERFORM  AG-2000-UPDATE-TWRK-TS
014221         THRU AG-2000-UPDATE-TWRK-TS-X.

           IF  WAG-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
014221         EVALUATE TRUE
014221           WHEN  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
014221               MOVE 'XS00000303'     TO WGLOB-MSG-REF-INFO
014221               MOVE 'AG'             TO WGLOB-MSG-PARM (01)
014221               MOVE WAG-KEY          TO WGLOB-MSG-PARM (02)
014221               PERFORM  0260-1000-GENERATE-MESSAGE
014221                   THRU 0260-1000-GENERATE-MESSAGE-X
014221               PERFORM  2400-CLEAR-SCREEN-VALUES
014221                   THRU 2400-CLEAR-SCREEN-VALUES-X
014221               GO TO 5000-PROCESS-UPDATE-X
014221           WHEN OTHER
                     MOVE 'XS00000064'     TO WGLOB-MSG-REF-INFO
                     MOVE WAG-KEY          TO WGLOB-MSG-PARM (1)
                     PERFORM  0260-1000-GENERATE-MESSAGE
                         THRU 0260-1000-GENERATE-MESSAGE-X
                     PERFORM  2400-CLEAR-SCREEN-VALUES
                         THRU 2400-CLEAR-SCREEN-VALUES-X
                     GO TO 5000-PROCESS-UPDATE-X
014221         END-EVALUATE
           END-IF.

010418*    MOVE MIR-AGT-ID        TO WAB-AGT-ID.
010418*    PERFORM  AB-1000-READ-FOR-UPDATE
010418*        THRU AB-1000-READ-FOR-UPDATE-X.
010418*    IF  WAB-IO-OK
010418*        NEXT SENTENCE
010418*    ELSE
010418*        MOVE 'CS00810030' TO WGLOB-MSG-REF-INFO
010418*        MOVE WAB-KEY      TO WGLOB-MSG-PARM (1)
010418*        PERFORM  0260-1000-GENERATE-MESSAGE
010418*            THRU 0260-1000-GENERATE-MESSAGE-X
010418*        PERFORM  9400-SET-ATTRIBUTES-1
010418*            THRU 9400-SET-ATTRIBUTES-1-X
010418*        PERFORM  AG-3000-UNLOCK
010418*            THRU AG-3000-UNLOCK-X
010418*        PERFORM  2400-CLEAR-SCREEN-VALUES
010418*            THRU 2400-CLEAR-SCREEN-VALUES-X
010418*        GO TO 5200-MAINTENANCE-PART-2-X
010418*    END-IF.

557667     PERFORM  7100-GET-AGT-RELATIONSHIPS
557667         THRU 7100-GET-AGT-RELATIONSHIPS-X.
557667
           MOVE  'N'                  TO  WS-ERROR-SW.

      ***  CLEAR THE TABLE OF ERROR NUMBERS WHICH ARE USED TO BUILD
      ***  THE SPECIFIC ERROR MESSAGES TO THE SCREEN

           PERFORM  5300-AGENT-FLD-MNT
               THRU 5300-AGENT-FLD-MNT-X.

           PERFORM  AG-2000-REWRITE
               THRU AG-2000-REWRITE-X.

014221     PERFORM  AG-1000-READ-TWRK-TS
014221         THRU AG-1000-READ-TWRK-TS-X.

010418*    PERFORM  AB-2000-REWRITE
010418*        THRU AB-2000-REWRITE-X.

557667     PERFORM  7200-UPDT-AGT-RELATIONSHIPS
557667         THRU 7200-UPDT-AGT-RELATIONSHIPS-X.
557667
           IF  NO-ERRORS-FOUND
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *-------------------
       5300-AGENT-FLD-MNT.
      *-------------------

           PERFORM  3200-GET-AGENT-NAME
               THRU 3200-GET-AGENT-NAME-X.

557668*    MOVE L2435-CLI-NM-COMPRESSED TO MIR-DV-AGT-CLI-NM.
557668     MOVE L0620-SCREEN-NAME     TO MIR-DV-AGT-CLI-NM.
           MOVE WAG-AGT-ID            TO MIR-AGT-ID.

           PERFORM  8100-EDIT-SCR-01
               THRU 8100-EDIT-SCR-01-X.

           PERFORM  8200-EDIT-SCR-02
               THRU 8200-EDIT-SCR-02-X.

010418*    PERFORM  8500-EDIT-SCR-05
010418*        THRU 8500-EDIT-SCR-05-X
010418*        VARYING WS-SUB FROM 1 BY 1
010418*        UNTIL WS-SUB > 4.

010418*    PERFORM  8600-EDIT-SCR-06
010418*        THRU 8600-EDIT-SCR-06-X.

       5300-AGENT-FLD-MNT-X.
           EXIT.
      /
      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

           MOVE 'N'                   TO WS-AGENT-RL-FOUND-SW.
557660*    PERFORM  6100-SCAN-RL
557660*        THRU 6100-SCAN-RL-X.
028786*    PERFORM  6400-SCAN-RL
028786*        THRU 6400-SCAN-RL-X.
028786     PERFORM  6400-SCAN-AGT-REL
028786         THRU 6400-SCAN-AGT-REL-X.

010418     MOVE ZERO                  TO WS-AGT-PAYBL-BAL-AMT.
010418     MOVE RAG-AGT-ID            TO WAB-AGT-ID.
010418     MOVE LOW-VALUE             TO WAB-SBSDRY-CO-ID.
010418     MOVE WAB-KEY               TO WAB-ENDBR-KEY.
010418     MOVE HIGH-VALUE            TO WAB-ENDBR-SBSDRY-CO-ID.
010418
010418*    PERFORM  AB-1000-BROWSE
010418*        THRU AB-1000-BROWSE-X.
010418*
010418*    IF  NOT WAB-IO-EOF
010418*        PERFORM  AB-2000-READ-NEXT
010418*            THRU AB-2000-READ-NEXT-X
010418*    END-IF.
010418*
010418*    PERFORM
010418*        UNTIL WAB-IO-EOF
010418*        ADD RAB-AGT-PAYBL-BAL-AMT      TO WS-AGT-PAYBL-BAL-AMT
010418*        PERFORM  AB-2000-READ-NEXT
010418*            THRU AB-2000-READ-NEXT-X
010418*    END-PERFORM.
010418*
010418*    PERFORM  AB-3000-END-BROWSE
010418*        THRU AB-3000-END-BROWSE-X.
010418*
010418     IF  WS-AGT-PAYBL-BAL-AMT      NOT = 0
010418*    IF  RAB-AGT-PAYBL-BAL-AMT     NOT = 0
               MOVE 'CS00810003'      TO WGLOB-MSG-REF-INFO
010418*        MOVE RAB-KEY      TO WGLOB-MSG-PARM (1)
010418         MOVE RAG-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

           IF  WS-AGENT-RL-FOUND
               MOVE 'CS00810033'      TO WGLOB-MSG-REF-INFO
      *MSG: AGENT CANNOT BE DELETED - AGENT RELATIONSHIPS EXIST
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

557667
557667     PERFORM  0840-0000-INIT-PARM-INFO
557667         THRU 0840-0000-INIT-PARM-INFO-X.
557667     MOVE RAG-AGT-ID            TO L0840-AGT-ID.
557667     SET L0840-REL-TYP-SERVICING    TO TRUE.
557667     PERFORM  0840-7000-CHK-AGT-REL-EXIST
557667         THRU 0840-7000-CHK-AGT-REL-EXIST-X.
557667     IF L0840-REL-EXIST-YES
557667         MOVE 'CS00810005'      TO WGLOB-MSG-REF-INFO
557667*MSG: AGENT CANNOT BE DELETED - SERVICING RELATIONSHIPS EXIST
557667         PERFORM  0260-1000-GENERATE-MESSAGE
557667             THRU 0260-1000-GENERATE-MESSAGE-X
557667         GO TO 6000-PROCESS-DELETE-X
557667     END-IF.
557667

           MOVE MIR-AGT-ID            TO WAG-AGT-ID.
           MOVE MIR-AGT-ID            TO WAB-AGT-ID.
014221*    PERFORM  AG-1000-READ-FOR-UPDATE
014221*        THRU AG-1000-READ-FOR-UPDATE-X.

014221     PERFORM  AG-2000-UPDATE-TWRK-TS
014221         THRU AG-2000-UPDATE-TWRK-TS-X.

           IF WAG-IO-OK
557667*       DELETE AGENT RELATIONSHIPS
557667        INITIALIZE WS-RES-CLIENT
557667        INITIALIZE WS-MAIL-CLIENT
557667        PERFORM  7200-UPDT-AGT-RELATIONSHIPS
557667            THRU 7200-UPDT-AGT-RELATIONSHIPS-X
557667
              PERFORM  AG-1000-DELETE
                  THRU AG-1000-DELETE-X
              MOVE 'CS00810032'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
014221         EVALUATE TRUE
014221           WHEN  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
014221               MOVE 'XS00000303'     TO WGLOB-MSG-REF-INFO
014221               MOVE 'AG'             TO WGLOB-MSG-PARM (01)
014221               MOVE WAG-KEY          TO WGLOB-MSG-PARM (02)
014221               PERFORM  0260-1000-GENERATE-MESSAGE
014221                   THRU 0260-1000-GENERATE-MESSAGE-X
014221               PERFORM  2400-CLEAR-SCREEN-VALUES
014221                   THRU 2400-CLEAR-SCREEN-VALUES-X
014221           WHEN OTHER
                     MOVE WAG-KEY            TO WGLOB-MSG-PARM (1)
                     MOVE 'XS00000010'       TO WGLOB-MSG-REF-INFO
                     PERFORM  0260-1000-GENERATE-MESSAGE
                         THRU 0260-1000-GENERATE-MESSAGE-X
014221         END-EVALUATE
           END-IF.

           PERFORM  2400-CLEAR-SCREEN-VALUES
               THRU 2400-CLEAR-SCREEN-VALUES-X.

           MOVE SPACES                TO MIR-DV-AGT-CLI-NM.
           MOVE SPACES                TO MIR-BR-ID.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *-------------
557660*6100-SCAN-RL.
028786*6400-SCAN-RL.
028786 6400-SCAN-AGT-REL.
      *-------------

028786*    MOVE LOW-VALUES            TO WRL-KEY.
557667*    MOVE RAG-RES-ADDR-CLI-ID        TO WRL-CLI-ID.
028786*    MOVE WS-RES-CLI-ID         TO WRL-CLI-ID.
016440*    MOVE 'ADMIN'               TO WRL-REL-SYS-ID.
028786*    MOVE WGLOB-SYS-CTL-ID      TO WRL-REL-SYS-ID.
028786*    MOVE HIGH-VALUES           TO WRL-ENDBR-KEY.
557667*    MOVE RAG-RES-ADDR-CLI-ID        TO WRL-ENDBR-CLI-ID.
028786*    MOVE WS-RES-CLI-ID         TO WRL-ENDBR-CLI-ID.
016440*    MOVE 'ADMIN'               TO WRL-ENDBR-REL-SYS-ID.
028786*    MOVE WGLOB-SYS-CTL-ID      TO WRL-ENDBR-REL-SYS-ID.
028786* FIRST CHECK FOR EXISTENCE OF AGENT POLICY RELATIONSHIP
028786     MOVE LOW-VALUES           TO WAGRP-KEY.
028786     MOVE RAG-AGT-ID           TO WAGRP-AGT-ID.
028786     MOVE HIGH-VALUES          TO WAGRP-ENDBR-KEY.
028786     MOVE RAG-AGT-ID           TO WAGRP-ENDBR-AGT-ID.


557660*    PERFORM  6150-SCAN-RL-SYSTEM
557660*        THRU 6150-SCAN-RL-SYSTEM-X.
028786*    PERFORM  6450-SCAN-RL-SYSTEM
028786*        THRU 6450-SCAN-RL-SYSTEM-X.
028786     PERFORM  6450-SCAN-AGRP
028786         THRU 6450-SCAN-AGRP-X.

           IF  WS-AGENT-RL-FOUND
557660*        GO TO 6100-SCAN-RL-X
028786*        GO TO 6400-SCAN-RL-X
028786         GO TO 6400-SCAN-AGT-REL-X
           END-IF.
028786
028786* CHECK FOR EXISTENCE OF AGENT COVERAGE RELATIONSHIP
028786
028786     MOVE LOW-VALUES           TO WAGRC-KEY.
028786     MOVE RAG-AGT-ID           TO WAGRC-AGT-ID.
028786     MOVE HIGH-VALUES          TO WAGRC-ENDBR-KEY.
028786     MOVE RAG-AGT-ID           TO WAGRC-ENDBR-AGT-ID.
028786
028786     PERFORM  6460-SCAN-AGRC
028786         THRU 6460-SCAN-AGRC-X.
028786
028786     IF  WS-AGENT-RL-FOUND
028786         GO TO 6400-SCAN-AGT-REL-X
028786     END-IF.

016440*    MOVE LOW-VALUES            TO WRL-KEY.
557667*    MOVE RAG-RES-ADDR-CLI-ID        TO WRL-CLI-ID.
016440*    MOVE WS-RES-CLI-ID         TO WRL-CLI-ID.
016440*    MOVE 'NEWBUS  '            TO WRL-REL-SYS-ID.
016440*    MOVE HIGH-VALUES           TO WRL-ENDBR-KEY.
557667*    MOVE RAG-RES-ADDR-CLI-ID        TO WRL-ENDBR-CLI-ID.
016440*    MOVE WS-RES-CLI-ID         TO WRL-ENDBR-CLI-ID.
016440*    MOVE 'NEWBUS  '            TO WRL-ENDBR-REL-SYS-ID.

557660*    PERFORM  6150-SCAN-RL-SYSTEM
557660*        THRU 6150-SCAN-RL-SYSTEM-X.
016440*    PERFORM  6450-SCAN-RL-SYSTEM
016440*        THRU 6450-SCAN-RL-SYSTEM-X.

557660*6100-SCAN-RL-X.
028786*6400-SCAN-RL-X.
028786 6400-SCAN-AGT-REL-X.
           EXIT.

028786*--------------------
557660*6150-SCAN-RL-SYSTEM.
028786*6450-SCAN-RL-SYSTEM.
028786*--------------------
028786*
028786*    PERFORM  RL-1000-BROWSE
028786*        THRU RL-1000-BROWSE-X.
028786*
028786*    IF  NOT WRL-IO-OK
557660*        GO TO 6150-SCAN-RL-SYSTEM-X
028786*        GO TO 6450-SCAN-RL-SYSTEM-X
028786*    END-IF.
028786*
028786*    PERFORM  RL-2000-READ-NEXT
028786*        THRU RL-2000-READ-NEXT-X.
028786*    IF  NOT WRL-IO-OK
028786*        NEXT SENTENCE
028786*    ELSE
028786*        IF  RRL-REL-TYP-CD             =  'V'
028786*        OR  RRL-REL-TYP-CD             =  'W'
028786*        OR  RRL-REL-TYP-CD             =  'C'
028786*            MOVE 'Y'           TO WS-AGENT-RL-FOUND-SW
028786*        ELSE
028786*            PERFORM  RL-2000-READ-NEXT
028786*                THRU RL-2000-READ-NEXT-X
028786*               UNTIL NOT WRL-IO-OK
557667*                  OR WRL-CLI-ID NOT      =  RAG-RES-ADDR-CLI-ID
028786*                  OR WRL-CLI-ID      NOT =  WS-RES-CLI-ID
016440*                  OR WRL-REL-SYS-ID NOT  =  'ADMIN'
028786*                  OR WRL-REL-SYS-ID NOT  =  WGLOB-SYS-CTL-ID
028786*                  OR WRL-REL-TYP-CD      =  'V'
028786*                  OR WRL-REL-TYP-CD      =  'W'
028786*                  OR WRL-REL-TYP-CD      =  'C'
028786*            IF  WRL-REL-TYP-CD         =  'V'
028786*            OR  WRL-REL-TYP-CD         =  'W'
028786*            OR  WRL-REL-TYP-CD         =  'C'
028786*                MOVE 'Y'       TO WS-AGENT-RL-FOUND-SW
028786*            END-IF
028786*        END-IF
028786*    END-IF.
028786*
028786*    PERFORM  RL-3000-END-BROWSE
028786*        THRU RL-3000-END-BROWSE-X.
028786*
557660*6150-SCAN-RL-SYSTEM-X.
028786*6450-SCAN-RL-SYSTEM-X.
028786*    EXIT.
      /
028786*--------------------
028786 6450-SCAN-AGRP.
028786*--------------------
028786
028786     PERFORM  AGRP-4000-BROWSE-INDEX
028786         THRU AGRP-4000-BROWSE-INDEX-X.
028786
028786     PERFORM  AGRP-5000-READ-NEXT-INDEX
028786         THRU AGRP-5000-READ-NEXT-INDEX-X.
028786
028786     IF  WAGRP-IO-OK
028786         SET  WS-AGENT-RL-FOUND  TO TRUE
028786     END-IF.
028786
028786     PERFORM  AGRP-6000-END-BROWSE-INDEX
028786         THRU AGRP-6000-END-BROWSE-INDEX-X.
028786 
028786 6450-SCAN-AGRP-X.
028786     EXIT.
028786/
028786*---------------
028786 6460-SCAN-AGRC.
028786*---------------
028786
028786     PERFORM  AGRC-4000-BROWSE-INDEX
028786         THRU AGRC-4000-BROWSE-INDEX-X.
028786
028786     PERFORM  AGRC-5000-READ-NEXT-INDEX
028786         THRU AGRC-5000-READ-NEXT-INDEX-X.
028786
028786     IF  WAGRC-IO-OK
028786         SET  WS-AGENT-RL-FOUND  TO TRUE
028786     END-IF.
028786
028786     PERFORM  AGRC-6000-END-BROWSE-INDEX
028786         THRU AGRC-6000-END-BROWSE-INDEX-X.
028786
028786 6460-SCAN-AGRC-X.
028786     EXIT.
028786/
557667*---------------------------
557667 7100-GET-AGT-RELATIONSHIPS.
557667*---------------------------
557667
557667*    GET AGENT RESIDENTIAL RELATIONSHIP
557667     INITIALIZE L0840-IO-PARM-INFO.
557667     INITIALIZE WS-RES-CLIENT.
557667     MOVE RAG-AGT-ID            TO L0840-AGT-ID.
557667     SET L0840-REL-TYP-RESIDENTIAL  TO TRUE.
557667     PERFORM  0840-5000-GET-AGT-REL
557667         THRU 0840-5000-GET-AGT-REL-X.
557667     IF L0840-RETRN-OK
557667         MOVE L0840-CLI-ID      TO WS-RES-CLI-ID
557667         MOVE L0840-ADDR-TYP-CD TO WS-RES-ADDR-TYP-CD
557670         MOVE L0840-BNK-ACCT-NUM            TO WS-RES-BNK-ACCT-NUM
557667     END-IF.
557667     SET RES-CLIENT-READ            TO TRUE.
557667
557667*    GET AGENT MAILING RELATIONSHIP
557667     INITIALIZE L0840-IO-PARM-INFO.
557667     INITIALIZE WS-MAIL-CLIENT.
557667     MOVE RAG-AGT-ID            TO L0840-AGT-ID.
557667     SET L0840-REL-TYP-MAILING      TO TRUE.
557667     PERFORM  0840-5000-GET-AGT-REL
557667         THRU 0840-5000-GET-AGT-REL-X.
557667     IF L0840-RETRN-OK
557667         MOVE L0840-CLI-ID      TO WS-MAIL-CLI-ID
557667         MOVE L0840-ADDR-TYP-CD TO WS-MAIL-ADDR-TYP-CD
557670         MOVE L0840-BNK-ACCT-NUM           TO WS-MAIL-BNK-ACCT-NUM
557667     END-IF.
557667     SET MAIL-CLIENT-READ           TO TRUE.
557667
557667 7100-GET-AGT-RELATIONSHIPS-X.
557667     EXIT.
557667/
557667*---------------------------
557667 7200-UPDT-AGT-RELATIONSHIPS.
557667*---------------------------
557667
557667*    UPDATE AGENT RESIDENTIAL RELATIONSHIP
557667     MOVE WAG-AGT-ID            TO L0840-AGT-ID.
557667     SET L0840-REL-TYP-RESIDENTIAL  TO TRUE.
557667     MOVE WS-RES-CLI-ID         TO L0840-CLI-ID.
557667     MOVE WS-RES-ADDR-TYP-CD    TO L0840-ADDR-TYP-CD.
557670     MOVE WS-RES-BNK-ACCT-NUM   TO L0840-BNK-ACCT-NUM.
018764*557667     PERFORM  0840-1000-UPDT-AGT-REL
018764*557667         THRU 0840-1000-UPDT-AGT-REL-X.
018764     PERFORM  0840-1000-UPD-AGT-REL
018764         THRU 0840-1000-UPD-AGT-REL-X.
557667
557667*    UPDATE AGENT MAILING RELATIONSHIP
557667     MOVE WAG-AGT-ID            TO L0840-AGT-ID.
557667     SET L0840-REL-TYP-MAILING      TO TRUE.
557667     MOVE WS-MAIL-CLI-ID        TO L0840-CLI-ID.
557667     MOVE WS-MAIL-ADDR-TYP-CD   TO L0840-ADDR-TYP-CD.
557670     MOVE WS-MAIL-BNK-ACCT-NUM  TO L0840-BNK-ACCT-NUM.
018764*557667     PERFORM  0840-1000-UPDT-AGT-REL
018764*557667         THRU 0840-1000-UPDT-AGT-REL-X.
018764     PERFORM  0840-1000-UPD-AGT-REL
018764         THRU 0840-1000-UPD-AGT-REL-X.
557667
557667 7200-UPDT-AGT-RELATIONSHIPS-X.
557667     EXIT.
557667/
557668*-------------------------
557668 7300-GET-STD-FMT-CLI-NAME.
557668*-------------------------
557668*
557668*    CALL STANDARD ROUTINE CSDU0620 TO GET CLIENT NAME IN
557668*    THE STANDARD SCREEN FORMAT
557668*
557668     INITIALIZE L0620-INPUT-PARM-INFO.
557668     IF L2435-CLI-SEX-CD = 'C'
557668         MOVE L2435-CLI-FULL-NAME
                                      TO L0620-CLI-CO-NM
557668     ELSE
557668         MOVE L2435-CLI-GIV-NM  TO L0620-CLI-GIV-NM
557668         MOVE L2435-CLI-SUR-NM  TO L0620-CLI-SUR-NM
               MOVE L2435-CLI-MID-INIT-NM
                                      TO L0620-CLI-MID-INIT-NM
               MOVE L2435-CLI-SFX-NM  TO L0620-CLI-SFX-NM
557668     END-IF.
557668     MOVE L2435-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
557668
557668     PERFORM  0620-1000-FORMAT-SCREEN-NAME
557668         THRU 0620-1000-FORMAT-SCREEN-NAME-X.
557668
557668 7300-GET-STD-FMT-CLI-NAME-X.
557668     EXIT.
557668/
      **** NEW ROUTINE FOR THE EDIT OF SCREEN 01
      *-----------------
       8100-EDIT-SCR-01.
      *-----------------

      *********************
      ***   EDIT MIR-CLI-ID
      *********************

           MOVE SPACES                TO HOLD-AGENT.

           IF  MIR-CLI-ID                  =  SPACES
557667*         MOVE RAG-RES-ADDR-CLI-ID    TO MIR-CLI-ID
557667          MOVE WS-RES-CLI-ID    TO MIR-CLI-ID
           END-IF.

           IF  MIR-CLI-ID = SPACES
      * MSG: AGENT CLIENT # MUST BE IN BIOP
               MOVE 'Y'               TO WS-ERROR-SW
               MOVE 'CS00810009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  8101-EDIT-AGTCLI
                   THRU 8101-EDIT-AGTCLI-X
           END-IF.

      ********************
      ***   EDIT MIR-ADDR-TYP-CD
      ********************
           IF MIR-ADDR-TYP-CD           =  SPACES
557667*        MOVE RAG-RES-CLI-ADDR-ID TO MIR-ADDR-TYP-CD
557667         MOVE WS-RES-ADDR-TYP-CD  TO MIR-ADDR-TYP-CD
           ELSE
               IF MIR-ADDR-TYP-CD       =  EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-ADDR-TYP-CD
               END-IF
               PERFORM  8102-EDIT-ADTY
                   THRU 8102-EDIT-ADTY-X
           END-IF.

      *********************
      ***   EDIT MIR-DV-AGT-MAIL-CLI-ID
      *********************

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

010418*    MOVE SPACES                    TO MIR-DV-AGT-CLI-NM.
           IF  MIR-DV-AGT-MAIL-CLI-ID = SPACES
557667*        MOVE RAG-MAIL-ADDR-CLI-ID  TO MIR-CLI-ID
557667         MOVE WS-MAIL-CLI-ID    TO MIR-DV-AGT-MAIL-CLI-ID
           END-IF.

           IF  MIR-DV-AGT-MAIL-CLI-ID = SPACES
      *MSG:    MAIL CLIENT # MUST BE IN BIOP
               MOVE 'Y'               TO WS-ERROR-SW
               MOVE 'CS00810010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE MIR-DV-AGT-MAIL-CLI-ID  TO L2435-CLI-ID
               PERFORM  2435-1000-OBTAIN-CLI-INFO
                   THRU 2435-1000-OBTAIN-CLI-INFO-X
               IF  L2435-RETRN-OK
557667*            MOVE MIR-CLI-ID         TO RAG-MAIL-ADDR-CLI-ID
557667             MOVE MIR-DV-AGT-MAIL-CLI-ID  TO WS-MAIL-CLI-ID
557667             IF  MIR-DV-AGT-MAIL-TYP-CD = SPACES
557667                 MOVE 'PR'      TO MIR-DV-AGT-MAIL-TYP-CD
557667             END-IF
               ELSE
      *MSG:        MAIL CLIENT # MUST BE IN BIOP
                   MOVE 'CS00810010'  TO WGLOB-MSG-REF-INFO
                   MOVE 'Y'           TO WS-ERROR-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
      *MSG:        GENERATE NEW WARNING MESSAGE AND BLANK OUT FIELD #7
                   MOVE 'CS00810034'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557667             MOVE 'PR'          TO MIR-DV-AGT-MAIL-TYP-CD
               END-IF
           END-IF.

557667*    MOVE RAG-MAIL-ADDR-CLI-ID      TO L2435-CLI-ID.
557667*    IF  RAG-MAIL-ADDR-CLI-ID NOT    =  SPACES
557667*    AND RAG-MAIL-ADDR-CLI-ID NOT    =  RAG-RES-ADDR-CLI-ID
557667     MOVE WS-MAIL-CLI-ID        TO L2435-CLI-ID.
557667     IF  WS-MAIL-CLI-ID NOT    =  SPACES
557667     AND WS-MAIL-CLI-ID NOT    =  WS-RES-CLI-ID
               PERFORM  2435-1000-OBTAIN-CLI-INFO
                   THRU 2435-1000-OBTAIN-CLI-INFO-X
               IF L2435-RETRN-OK
557668*            MOVE L2435-CLI-NM-COMPRESSED TO MIR-DV-AGT-CLI-NM
557668             PERFORM  7300-GET-STD-FMT-CLI-NAME
557668                 THRU 7300-GET-STD-FMT-CLI-NAME-X
010418*            MOVE L0620-SCREEN-NAME       TO MIR-DV-AGT-CLI-NM
               END-IF
           END-IF.

557667*    IF  RAG-MAIL-ADDR-CLI-ID       =  RAG-RES-ADDR-CLI-ID
557667*    AND RAG-MAIL-ADDR-CLI-ID NOT   =  SPACES
557667     IF  WS-MAIL-CLI-ID       =  WS-RES-CLI-ID
557667     AND WS-MAIL-CLI-ID NOT   =  SPACES
557668*        MOVE L2435-CLI-NM-COMPRESSED     TO MIR-DV-AGT-CLI-NM
557668         MOVE L0620-SCREEN-NAME TO MIR-DV-AGT-CLI-NM
           END-IF.

      ********************
      ***   EDIT MIR-MADTY
      ********************
           IF MIR-DV-AGT-MAIL-TYP-CD   =  SPACES
557667*        MOVE RAG-MAIL-CLI-ADDR-ID TO MIR-MADTY
557667         MOVE WS-MAIL-ADDR-TYP-CD
                                      TO MIR-DV-AGT-MAIL-TYP-CD
           ELSE
               IF MIR-DV-AGT-MAIL-TYP-CD =  EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-DV-AGT-MAIL-TYP-CD
               END-IF
               PERFORM  8103-EDIT-MADTY
                   THRU 8103-EDIT-MADTY-X
           END-IF.

      *********************
      ***   EDIT MIR-AGT-PHON-NUM
      *********************

           IF  MIR-AGT-PHON-NUM      =  SPACES
               MOVE RAG-AGT-PHON-NUM  TO MIR-AGT-PHON-NUM
           ELSE
               IF  MIR-AGT-PHON-NUM  =  EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-AGT-PHON-NUM
               END-IF
           END-IF.

           MOVE MIR-AGT-PHON-NUM      TO RAG-AGT-PHON-NUM.

      *********************
      ***   EDIT MIR-BR-ID
      *********************

           IF MIR-BR-ID = SPACES
           AND RAG-BR-ID = SPACES
               MOVE  'Y'              TO WS-ERROR-SW
               MOVE 'CS00810007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF MIR-BR-ID = SPACES
                   MOVE RAG-BR-ID     TO MIR-BR-ID
               END-IF
               IF MIR-BR-ID = SPACES
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810007'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE MIR-BR-ID     TO WBRCH-BR-ID
                   PERFORM  BRCH-1000-READ
                       THRU BRCH-1000-READ-X
                   IF WBRCH-IO-OK
                        MOVE MIR-BR-ID                      TO RAG-BR-ID
                        MOVE RAG-BR-ID                      TO MIR-BR-ID
                    ELSE
                        MOVE  'Y'     TO WS-ERROR-SW
                        MOVE 'CS00810008'
                                      TO WGLOB-MSG-REF-INFO
                        PERFORM  0260-1000-GENERATE-MESSAGE
                            THRU 0260-1000-GENERATE-MESSAGE-X
                   END-IF
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-CMPNST-CRCY-CD
      *********************
           IF  MIR-AGT-CMPNST-CRCY-CD    = SPACES
               MOVE RAG-AGT-CMPNST-CRCY-CD
                                      TO MIR-AGT-CMPNST-CRCY-CD
           ELSE
               IF MIR-AGT-CMPNST-CRCY-CD    = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-AGT-CMPNST-CRCY-CD
               END-IF
008455*        MOVE MIR-AGT-CMPNST-CRCY-CD  TO WEDIT-ETBL-VALU-ID
008455*        PERFORM  CURR-1000-EDIT-CURRENCY
008455*            THRU CURR-1000-EDIT-CURRENCY-X
008455         MOVE WGLOB-COMPANY-CODE  TO WCRCY-CO-ID
008455         MOVE MIR-AGT-CMPNST-CRCY-CD
                                      TO WCRCY-CRCY-CD
008455         PERFORM  CRCY-1000-READ
008455             THRU CRCY-1000-READ-X

008455*        IF WEDIT-IO-OK
008455         IF WCRCY-IO-OK
                   MOVE MIR-AGT-CMPNST-CRCY-CD
                                      TO RAG-AGT-CMPNST-CRCY-CD
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810025'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-CNTRCT-STRT-DT
      *********************

           IF  MIR-AGT-CNTRCT-STRT-DT                     =  SPACES
               MOVE RAG-AGT-CNTRCT-STRT-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-AGT-CNTRCT-STRT-DT
               IF MIR-AGT-CNTRCT-STRT-DT = SPACES
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810052'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           ELSE
      ***      CHECK THE VALUE ENTERED FOR CONTRACT DATE AGAINST THE
      ***      SYSTEM JULIAN DATE FORMAT TO ENSURE THAT THE DATE IS
      ***      NOT IN THE FUTURE
               MOVE MIR-AGT-CNTRCT-STRT-DT
                                      TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X
               IF L1640-VALID
                   IF  L1640-INTERNAL-DATE >  WGLOB-SYSTEM-DATE-INT
                       MOVE  'Y'      TO WS-ERROR-SW
                       MOVE 'XS00000035'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                   ELSE
                       MOVE L1640-INTERNAL-DATE
                                      TO RAG-AGT-CNTRCT-STRT-DT
                   END-IF
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810052'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-OVRID-BASE-AGT-ID
      *********************
           IF  MIR-OVRID-BASE-AGT-ID    = SPACES
               MOVE RAG-OVRID-BASE-AGT-ID
                                      TO MIR-OVRID-BASE-AGT-ID
           ELSE
               IF MIR-OVRID-BASE-AGT-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-OVRID-BASE-AGT-ID
               END-IF
           END-IF.

           MOVE MIR-OVRID-BASE-AGT-ID TO RAG-OVRID-BASE-AGT-ID.
           MOVE RAG-OVRID-BASE-AGT-ID TO MIR-OVRID-BASE-AGT-ID.

      *********************
      ***   EDIT MIR-AGT-CNTRCT-TRMN-DT
      *********************
           IF  MIR-AGT-CNTRCT-TRMN-DT  =  SPACES
557659*        MOVE RAG-CNTRCT-TRMN-DT-TXT  TO MIR-AGT-CNTRCT-TRMN-DT
557659         MOVE RAG-AGT-CNTRCT-TRMN-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
557659         MOVE L1640-EXTERNAL-DATE
                                      TO MIR-AGT-CNTRCT-TRMN-DT
           ELSE
               IF  MIR-AGT-CNTRCT-TRMN-DT =  EBLCH-BLANK-FIELD-CHAR
557659*            MOVE SPACES        TO RAG-CNTRCT-TRMN-DT-TXT
557659             MOVE WWKDT-ZERO-DT TO RAG-AGT-CNTRCT-TRMN-DT
                   MOVE SPACES        TO MIR-AGT-CNTRCT-TRMN-DT
               ELSE
                   MOVE MIR-AGT-CNTRCT-TRMN-DT
                                      TO L1640-EXTERNAL-DATE
020462*            PERFORM 1640-3000-EXTERNAL-TO-INT
020462*               THRU 1640-3000-EXTERNAL-TO-INT-X
020462             PERFORM 1640-7000-MIR-TO-INT
020462                THRU 1640-7000-MIR-TO-INT-X
                   IF  L1640-VALID
557659*                MOVE L1640-EXTERNAL-DATE
557659*                    TO RAG-CNTRCT-TRMN-DT-TXT
557659                 MOVE L1640-INTERNAL-DATE
557659                                TO RAG-AGT-CNTRCT-TRMN-DT
                   ELSE
557659*                IF (MIR-AGT-CNTRCT-TRMN-DT = 'SEE FILE '
557659*                OR 'VOIR FICH')
557659*                    MOVE MIR-AGT-CNTRCT-TRMN-DT
557659*                               TO RAG-CNTRCT-TRMN-DT-TXT
557659*                ELSE
                           MOVE  'Y'  TO WS-ERROR-SW
                           MOVE 'CS00810053'
                                      TO WGLOB-MSG-REF-INFO
                           PERFORM  0260-1000-GENERATE-MESSAGE
                               THRU 0260-1000-GENERATE-MESSAGE-X
557659*                END-IF
                   END-IF
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-OVRID-ID
      *********************
           IF  MIR-OVRID-ID  = SPACES
               MOVE RAG-OVRID-ID      TO MIR-OVRID-ID
           ELSE
               IF MIR-OVRID-ID  = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-OVRID-ID
               END-IF
      ***  EDIT AGENT SITUATION CODE.
               IF MIR-OVRID-ID = 'NO'
                   MOVE MIR-OVRID-ID  TO RAG-OVRID-ID
               ELSE
                   MOVE RAG-OVRID-BASE-AGT-ID
                                      TO WAS-OVRID-BASE-AGT-ID
                   MOVE MIR-OVRID-ID  TO WAS-OVRID-ID
                   PERFORM  AS-1000-READ
                       THRU AS-1000-READ-X
                   IF  WAS-IO-NOT-FOUND
                       MOVE  'Y'      TO WS-ERROR-SW
                       MOVE 'CS00810026'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                   ELSE
                       MOVE MIR-OVRID-ID
                                      TO RAG-OVRID-ID
                   END-IF
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-FYR-COMM-CALC-CD
      *********************
           IF  MIR-FYR-COMM-CALC-CD  = SPACES
               MOVE RAG-FYR-COMM-CALC-CD
                                      TO MIR-FYR-COMM-CALC-CD
           ELSE
               IF MIR-FYR-COMM-CALC-CD = 'A'
               OR MIR-FYR-COMM-CALC-CD = 'B'
               OR MIR-FYR-COMM-CALC-CD = 'C'
               OR MIR-FYR-COMM-CALC-CD = 'D'
                   MOVE MIR-FYR-COMM-CALC-CD
                                      TO RAG-FYR-COMM-CALC-CD
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810093'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-PARTL-ADV-COMM-CD
      *********************
           IF  MIR-PARTL-ADV-COMM-CD                  =  SPACES
               MOVE RAG-PARTL-ADV-COMM-CD
                                      TO MIR-PARTL-ADV-COMM-CD
               MOVE RAG-PARTL-ADV-COMM-CD
                                      TO PART-ADV-TYP
           ELSE
557660         IF  MIR-PARTL-ADV-COMM-CD  =  'P'
               OR  MIR-PARTL-ADV-COMM-CD  =  'F'
               OR  MIR-PARTL-ADV-COMM-CD  =  'N'
                   MOVE MIR-PARTL-ADV-COMM-CD
                                      TO PART-ADV-TYP
                   MOVE MIR-PARTL-ADV-COMM-CD
                                      TO RAG-PARTL-ADV-COMM-CD
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810011'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-RENW-COMM-CALC-CD
      *********************

           IF  MIR-RENW-COMM-CALC-CD  = SPACES
               MOVE RAG-RENW-COMM-CALC-CD
                                      TO MIR-RENW-COMM-CALC-CD
           ELSE
557660         IF MIR-RENW-COMM-CALC-CD = 'A'
               OR MIR-RENW-COMM-CALC-CD = 'B'
               OR MIR-RENW-COMM-CALC-CD = 'C'
               OR MIR-RENW-COMM-CALC-CD = 'D'
                   MOVE MIR-RENW-COMM-CALC-CD
                                      TO RAG-RENW-COMM-CALC-CD
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810095'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-PARTL-ADV-COMM-AMT
      *********************
           MOVE 'Y'                   TO PARTIAL-ADV-SW.

           IF  MIR-PARTL-ADV-COMM-AMT =  SPACES
008455*        MOVE RAG-PARTL-ADV-COMM-AMT  TO EDIT-4
               MOVE RAG-PARTL-ADV-COMM-AMT
                                      TO PART-ADV-AMT
008455*        MOVE EDIT-4                  TO MIR-PARTL-ADV-COMM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RAG-PARTL-ADV-COMM-AMT * 100
020874         MOVE RAG-PARTL-ADV-COMM-AMT TO L0290-INPUT-V02
008455         MOVE +2                TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PARTL-ADV-COMM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PARTL-ADV-COMM-AMT
           ELSE
               IF  MIR-PARTL-ADV-COMM-AMT  =  EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS               TO EDIT-4
008455*            MOVE EDIT-4              TO MIR-PARTL-ADV-COMM-AMT
008455             MOVE ZEROS         TO MIR-PARTL-ADV-COMM-AMT
               END-IF
               MOVE 'N'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
008455*        MOVE 5                       TO L0280-LENGTH
008455*        MOVE 8                       TO L0280-INPUT-SIZE
008455         MOVE LENGTH OF MIR-PARTL-ADV-COMM-AMT
                                      TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3
               MOVE MIR-PARTL-ADV-COMM-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   COMPUTE PART-ADV-AMT     =  L0280-OUTPUT-DOLLAR
008455*            MOVE PART-ADV-AMT        TO EDIT-4
008455*            MOVE EDIT-4              TO MIR-PARTL-ADV-COMM-AMT
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
008455             MOVE +2            TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-PARTL-ADV-COMM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-PARTL-ADV-COMM-AMT
                   MOVE PART-ADV-AMT  TO RAG-PARTL-ADV-COMM-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'N'           TO PARTIAL-ADV-SW
                   MOVE 'CS00810054'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-SERV-FEE-IND
      *********************
           IF  MIR-AGT-SERV-FEE-IND  = SPACES
               MOVE RAG-AGT-SERV-FEE-IND
                                      TO MIR-AGT-SERV-FEE-IND
           ELSE
557660         IF MIR-AGT-SERV-FEE-IND  = 'Y'
               OR MIR-AGT-SERV-FEE-IND  = 'N'
                   MOVE MIR-AGT-SERV-FEE-IND
                                      TO RAG-AGT-SERV-FEE-IND
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                    MOVE 'CS00810037' TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-SERV-COMM-RTBL2-ID
      *********************
           IF  MIR-SERV-COMM-RTBL2-ID  = SPACES
               MOVE RAG-SERV-COMM-RTBL2-ID
                                      TO MIR-SERV-COMM-RTBL2-ID
           ELSE
               IF MIR-SERV-COMM-RTBL2-ID  = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-SERV-COMM-RTBL2-ID
                   MOVE MIR-SERV-COMM-RTBL2-ID
                                      TO RAG-SERV-COMM-RTBL2-ID
               ELSE
                   MOVE MIR-SERV-COMM-RTBL2-ID
                                      TO WCC-RTBL2-ID
                   PERFORM  CC-1000-READ
                       THRU CC-1000-READ-X
                   IF  WCC-IO-NOT-FOUND
                       MOVE  'Y'      TO WS-ERROR-SW
                       MOVE 'CS00810027'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM 0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                   ELSE
                       MOVE MIR-SERV-COMM-RTBL2-ID
                                      TO RAG-SERV-COMM-RTBL2-ID
                   END-IF
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AUTO-COMM-PMT-CD
      *********************

           IF  MIR-AUTO-COMM-PMT-CD   = SPACES
               MOVE RAG-AUTO-COMM-PMT-CD
                                      TO MIR-AUTO-COMM-PMT-CD
           ELSE
557660         IF MIR-AUTO-COMM-PMT-CD = 'Y'
               OR MIR-AUTO-COMM-PMT-CD = 'N'
               OR MIR-AUTO-COMM-PMT-CD = 'M'
                   MOVE MIR-AUTO-COMM-PMT-CD
                                      TO RAG-AUTO-COMM-PMT-CD
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810023'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-CCAS-QUALF-IND
      *********************

           IF  MIR-AGT-CCAS-QUALF-IND  = SPACES
557659*        MOVE RAG-AGT-CCAS-QUALF-CD  TO MIR-AGT-CCAS-QUALF-IND
557659         MOVE RAG-AGT-CCAS-QUALF-IND
                                      TO MIR-AGT-CCAS-QUALF-IND
           ELSE
557660         IF MIR-AGT-CCAS-QUALF-IND = 'Y'
               OR MIR-AGT-CCAS-QUALF-IND = 'N'
557659*            MOVE MIR-AGT-CCAS-QUALF-IND TO RAG-AGT-CCAS-QUALF-CD
557659             MOVE MIR-AGT-CCAS-QUALF-IND
                                      TO RAG-AGT-CCAS-QUALF-IND
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810038'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

557670*********************
557670***   EDIT MIR-AGT-PMT-MTHD-CD
557670*********************
557670
557670     IF  MIR-AGT-PMT-MTHD-CD  = SPACES
557670         IF  RAG-AGT-PMT-MTHD-CD = SPACES
557670             MOVE 'C'           TO MIR-AGT-PMT-MTHD-CD
557670             MOVE 'C'           TO RAG-AGT-PMT-MTHD-CD
557670         ELSE
557670             MOVE RAG-AGT-PMT-MTHD-CD
                                      TO MIR-AGT-PMT-MTHD-CD
557670         END-IF
557670     ELSE
557670         IF MIR-AGT-PMT-MTHD-CD = 'C'
557670         OR MIR-AGT-PMT-MTHD-CD = 'E'
557670             MOVE MIR-AGT-PMT-MTHD-CD
                                      TO RAG-AGT-PMT-MTHD-CD
557670         ELSE
557670*MSG:    PAYMENT TYPE MUST BE 'C' OR 'E'
557670             MOVE  'Y'          TO WS-ERROR-SW
557670             MOVE 'CS00810017'  TO WGLOB-MSG-REF-INFO
557670             PERFORM 0260-1000-GENERATE-MESSAGE
557670                 THRU 0260-1000-GENERATE-MESSAGE-X
557670         END-IF
557670     END-IF.
557670
557670*********************
557670***   EDIT MIR-BNK-ACCT-NUM
557670*********************
557670
557670     IF  MIR-BNK-ACCT-NUM  = SPACES
020874*        MOVE WS-RES-BNK-ACCT-NUM
020874*                               TO EDIT-8
020874*        MOVE EDIT-8            TO MIR-BNK-ACCT-NUM
020874         MOVE WS-RES-BNK-ACCT-NUM   TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-BNK-ACCT-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-BNK-ACCT-NUM
557670     ELSE
557670         IF MIR-BNK-ACCT-NUM = EBLCH-BLANK-FIELD-CHAR
020874*            MOVE ZEROS         TO EDIT-8
020874*            MOVE EDIT-8        TO MIR-BNK-ACCT-NUM
020874             MOVE ZEROS          TO L0290-INPUT-V00
020874             MOVE ZERO                  TO L0290-PRECISION
020874             MOVE LENGTH OF MIR-BNK-ACCT-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
020874             MOVE L0290-OUTPUT-DATA     TO MIR-BNK-ACCT-NUM
557670         END-IF
557670     END-IF.
557670     MOVE 'N'                   TO L0280-SIGN-IND.
557670     MOVE ZERO                  TO L0280-PRECISION.
557670     MOVE 1                     TO L0280-LENGTH.
557670     MOVE 1                     TO L0280-INPUT-SIZE.
557670     MOVE MIR-BNK-ACCT-NUM      TO L0280-INPUT-DATA.
557670     PERFORM  0280-1000-NUMERIC-EDIT
557670         THRU 0280-1000-NUMERIC-EDIT-X.
557670     IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO EDIT-8
020874*        MOVE EDIT-8            TO MIR-BNK-ACCT-NUM
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE ZERO                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-BNK-ACCT-NUM
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-BNK-ACCT-NUM
557670         MOVE L0280-OUTPUT      TO WS-RES-BNK-ACCT-NUM
557670     ELSE
557670*MSG:    BANK ACCOUNT # MUST BE NUMERIC
557670         MOVE  'Y'              TO WS-ERROR-SW
557670         MOVE 'CS00810018'      TO WGLOB-MSG-REF-INFO
557670         PERFORM  0260-1000-GENERATE-MESSAGE
557670             THRU 0260-1000-GENERATE-MESSAGE-X
557670     END-IF.
557670
      *********************
      ***   EDIT MIR-AGT-LOC-LIC-CD
      *********************
           IF  MIR-AGT-LOC-LIC-CD  = SPACES
               MOVE RAG-AGT-LOC-LIC-CD TO MIR-AGT-LOC-LIC-CD
           ELSE
557660         IF MIR-AGT-LOC-LIC-CD = 'A'
               OR MIR-AGT-LOC-LIC-CD = 'C'
                   MOVE MIR-AGT-LOC-LIC-CD
                                      TO RAG-AGT-LOC-LIC-CD
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810047'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-CLAS-LIC-CD
      *********************
           IF  MIR-AGT-CLAS-LIC-CD  = SPACES
               MOVE RAG-AGT-CLAS-LIC-CD
                                      TO MIR-AGT-CLAS-LIC-CD
           ELSE
557660         IF MIR-AGT-CLAS-LIC-CD = 'A'
               OR MIR-AGT-CLAS-LIC-CD = 'C'
                   MOVE MIR-AGT-CLAS-LIC-CD
                                      TO RAG-AGT-CLAS-LIC-CD
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810048'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.
      *********************
      ***   CROSS EDITS
      *********************
557660     IF  PART-ADV-TYP  =  'F'
           AND VALID-NUMERIC-ADVANCE
               IF  PART-ADV-AMT           =  ZERO
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810012'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

557660     IF PART-ADV-TYP  =  'N'
           AND VALID-NUMERIC-ADVANCE
               IF  PART-ADV-AMT NOT       =  ZERO
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810013'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

557660     IF PART-ADV-TYP  =  'P'
           AND VALID-NUMERIC-ADVANCE
               IF  PART-ADV-AMT    NOT    <  100.00
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810014'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   IF  PART-ADV-AMT       =  ZERO
                       MOVE  'Y'      TO WS-ERROR-SW
                       MOVE 'CS00810012'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM 0260-1000-GENERATE-MESSAGE
                          THRU 0260-1000-GENERATE-MESSAGE-X
                   END-IF
               END-IF
           END-IF.

557660     IF  RAG-RENW-COMM-CALC-CD    = 'B'
           OR  RAG-RENW-COMM-CALC-CD    = 'D'
               IF RAG-PARTL-ADV-COMM-CD  NOT = 'N'
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810020'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

557670*    PAYMENT TYPE AND BANK ACCOUNT EDITS
557670     IF RAG-AGT-PMT-MTHD-CD = 'E'
557670         IF WS-RES-BNK-ACCT-NUM = ZERO
557670*MSG    BANK ACCOUNT # 1-9 MUST BE ENTERED WHEN PAYMENT TYPE = E
557670             MOVE  'Y'          TO WS-ERROR-SW
557670             MOVE 'CS00810024'  TO WGLOB-MSG-REF-INFO
557670             PERFORM  0260-1000-GENERATE-MESSAGE
557670                 THRU 0260-1000-GENERATE-MESSAGE-X
557670         ELSE
557670*    READ CLIENT BANK ACCOUNT TABLE USING ALTERNATE ACCESS
020478*            MOVE WS-RES-CLI-ID TO WCLIN-CLI-ID
020478*            MOVE WS-RES-BNK-ACCT-NUM
020478*                               TO WCLIN-CLI-BNK-ACCT-NUM
020478*            PERFORM  CLIN-1000-READ
020478*                THRU CLIN-1000-READ-X
020478             MOVE WS-RES-CLI-ID TO L5020-CLI-ID
020478             MOVE WS-RES-BNK-ACCT-NUM
020478                                TO L5020-PAC-NUM
020478             PERFORM  5020-2000-GET-SPECIFIC-BANK
020478                 THRU 5020-2000-GET-SPECIFIC-BANK-X
020478*            IF NOT WCLIN-IO-OK
020478             IF NOT L5020-RETRN-OK
557670*MSG:    BANK INFO (@1) REQUIRED FOR AGENT (@2)
557670                 MOVE  'Y'      TO WS-ERROR-SW
557670                 MOVE 'CS00810035'
                                      TO WGLOB-MSG-REF-INFO
557670                 MOVE MIR-BNK-ACCT-NUM
                                      TO WGLOB-MSG-PARM (1)
557670                 MOVE MIR-CLI-ID   TO WGLOB-MSG-PARM (2)
557670                 PERFORM  0260-1000-GENERATE-MESSAGE
557670                     THRU 0260-1000-GENERATE-MESSAGE-X
557670             END-IF
557670         END-IF
557670     END-IF.
557670
557670     IF RAG-AGT-PMT-MTHD-CD = 'C'
557670         IF WS-RES-BNK-ACCT-NUM NOT = ZERO
557670*MSG    BANK ACCOUNT # MUST BE ZERO WHEN PAYMENT TYPE = C
557670             MOVE  'Y'          TO WS-ERROR-SW
557670             MOVE 'CS00810031'  TO WGLOB-MSG-REF-INFO
557670             PERFORM  0260-1000-GENERATE-MESSAGE
557670                 THRU 0260-1000-GENERATE-MESSAGE-X
557670         END-IF
557670     END-IF.
557670
       8100-EDIT-SCR-01-X.
           EXIT.
      /
      *-----------------
       8101-EDIT-AGTCLI.
      *-----------------

           MOVE 'N'                   TO WS-AGENT-RL-FOUND-SW
557667*    MOVE RAG-RES-ADDR-CLI-ID    TO HOLD-AGENT
557667     MOVE WS-RES-CLI-ID         TO HOLD-AGENT
557660*    PERFORM  6100-SCAN-RL
557660*        THRU 6100-SCAN-RL-X.
028786*    PERFORM  6400-SCAN-RL
028786*        THRU 6400-SCAN-RL-X.
028786     PERFORM  6400-SCAN-AGT-REL
028786         THRU 6400-SCAN-AGT-REL-X.
           IF  WS-AGENT-RL-FOUND
557667*    AND MIR-CLI-ID NOT = RAG-RES-ADDR-CLI-ID
557667     AND MIR-CLI-ID NOT = WS-RES-CLI-ID
      * MSG:  AGENT RL EXISTS, CANNOT CHANGE
557667*        MOVE RAG-RES-ADDR-CLI-ID  TO WGLOB-MSG-PARM (01)
557667         MOVE WS-RES-CLI-ID     TO WGLOB-MSG-PARM (01)
               MOVE 'CS00810036'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  WGLOB-MSG-ERROR-SW > ZEROS
               MOVE 'Y'               TO WS-ERROR-SW
               GO TO 8101-EDIT-AGTCLI-X
           END-IF.

           IF  WS-AGENT-RL-FOUND
557667*    AND MIR-CLI-ID NOT = RAG-RES-ADDR-CLI-ID
557667     AND MIR-CLI-ID NOT = WS-RES-CLI-ID
           AND WGLOB-MSG-SEVRTY-FATAL
034802*        NEXT SENTENCE
034802         CONTINUE
      *MSG:    AGENT RL EXISTS, CANNOT CHANGE
           ELSE
               PERFORM  2435-1000-BUILD-PARM-INFO
                   THRU 2435-1000-BUILD-PARM-INFO-X
               MOVE MIR-CLI-ID        TO L2435-CLI-ID
               PERFORM  2435-1000-OBTAIN-CLI-INFO
                   THRU 2435-1000-OBTAIN-CLI-INFO-X
               IF  L2435-RETRN-OK
557667*            MOVE MIR-CLI-ID    TO RAG-RES-ADDR-CLI-ID
557667             MOVE MIR-CLI-ID    TO WS-RES-CLI-ID
557668*            MOVE L2435-CLI-NM-COMPRESSED TO MIR-DV-AGT-CLI-NM
557668             PERFORM  7300-GET-STD-FMT-CLI-NAME
557668                 THRU 7300-GET-STD-FMT-CLI-NAME-X
557668             MOVE L0620-SCREEN-NAME
                                      TO MIR-DV-AGT-CLI-NM
557667             IF  MIR-ADDR-TYP-CD = SPACES
557667                 MOVE 'PR'      TO MIR-ADDR-TYP-CD
557667             END-IF
               ELSE
      * MSG: AGENT CLIENT # MUST BE IN BIOP
                   MOVE 'Y'           TO WS-ERROR-SW
                   MOVE 'CS00810009'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
      * GENERATE NEW WARNING MESSAGE AND BLANK OUT FIELD #4
                   MOVE 'CS00810034'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557667             MOVE 'PR'          TO MIR-ADDR-TYP-CD
               END-IF
           END-IF.

       8101-EDIT-AGTCLI-X.
           EXIT.
      /
      *---------------
       8102-EDIT-ADTY.
      *---------------

           MOVE MIR-ADDR-TYP-CD       TO WEDIT-ETBL-VALU-ID.

           PERFORM  ADDR-1000-EDIT
               THRU ADDR-1000-EDIT-X.

           IF  WEDIT-IO-OK
557667*        MOVE MIR-ADDR-TYP-CD          TO RAG-RES-CLI-ADDR-ID
557667         MOVE MIR-ADDR-TYP-CD   TO WS-RES-ADDR-TYP-CD
           ELSE
               MOVE 'Y'               TO WS-ERROR-SW
      * MSG: ADDRESS TYPE MUST BE IN EDIT TYPE 'ADTYP'
               MOVE 'CS00810028'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8102-EDIT-ADTY-X
           END-IF.

020478     PERFORM  2440-0000-INIT-PARM-INFO
020478         THRU 2440-0000-INIT-PARM-INFO-X.
557667*    MOVE RAG-RES-ADDR-CLI-ID  TO L2440-CLI-ID.
557667*    MOVE RAG-RES-CLI-ADDR-ID  TO L2440-CLI-ADDR-TYP-CD.
557667     MOVE WS-RES-CLI-ID         TO L2440-CLI-ID.
557667     MOVE WS-RES-ADDR-TYP-CD    TO L2440-CLI-ADDR-TYP-CD.
557667     IF  L2435-RETRN-OK
557667         IF  MIR-ADDR-TYP-CD = 'PR'
557667             PERFORM  2440-1000-PRIMARY-ADDRESS
557667                THRU 2440-1000-PRIMARY-ADDRESS-X
557667         ELSE
557667             PERFORM  2440-3000-CHK-OTHER-ADDRESS
557667                THRU 2440-3000-CHK-OTHER-ADDRESS-X
557667         END-IF
           END-IF.
      *
      ****IF OTHER ADDRESS NOT FOUND DEFAULT PRIMARY
      *
           IF  L2440-RETRN-NO-ADDRESS
557667*        MOVE 'PR'          TO RAG-RES-CLI-ADDR-ID
557667         MOVE 'PR'              TO WS-RES-ADDR-TYP-CD
557667         IF  MIR-ADDR-TYP-CD NOT = 'PR'
557667             MOVE 'PR'          TO MIR-ADDR-TYP-CD
557667             MOVE 'XS00000214'  TO WGLOB-MSG-REF-INFO
557667             PERFORM  0260-1000-GENERATE-MESSAGE
557667                THRU 0260-1000-GENERATE-MESSAGE-X
557667         END-IF
           END-IF.

           IF L2440-ADDR-STAT-ERROR
               MOVE L2440-CLI-ID      TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000211'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8102-EDIT-ADTY-X.
           EXIT.
      /
      *----------------
       8103-EDIT-MADTY.
      *----------------
           MOVE MIR-DV-AGT-MAIL-TYP-CD TO WEDIT-ETBL-VALU-ID.

           PERFORM  ADDR-1000-EDIT
               THRU ADDR-1000-EDIT-X.

           IF  WEDIT-IO-OK
557667*        MOVE MIR-MADTY         TO RAG-MAIL-CLI-ADDR-ID
557667         MOVE MIR-DV-AGT-MAIL-TYP-CD TO WS-MAIL-ADDR-TYP-CD
           ELSE
               MOVE 'Y'               TO WS-ERROR-SW
      * MSG: MAIL ADDRESS TYPE MUST BE IN EDIT TYPE 'ADTYP'
               MOVE 'CS00810029'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8103-EDIT-MADTY-X
           END-IF.

020478     PERFORM  2440-0000-INIT-PARM-INFO
020478         THRU 2440-0000-INIT-PARM-INFO-X.
557667*    MOVE RAG-MAIL-ADDR-CLI-ID  TO L2440-CLI-ID.
557667*    MOVE RAG-MAIL-CLI-ADDR-ID  TO L2440-CLI-ADDR-TYP-CD.
557667     MOVE WS-MAIL-CLI-ID        TO L2440-CLI-ID.
557667     MOVE WS-MAIL-ADDR-TYP-CD   TO L2440-CLI-ADDR-TYP-CD.
557667     IF  L2435-RETRN-OK
557667         IF  MIR-DV-AGT-MAIL-TYP-CD = 'PR'
557667             PERFORM  2440-1000-PRIMARY-ADDRESS
557667                 THRU 2440-1000-PRIMARY-ADDRESS-X
557667         ELSE
557667             PERFORM  2440-3000-CHK-OTHER-ADDRESS
557667                 THRU 2440-3000-CHK-OTHER-ADDRESS-X
557667         END-IF
           END-IF.
      *
      ****IF OTHER ADDRESS NOT FOUND DEFAULT PRIMARY
      *
           IF  L2440-RETRN-NO-ADDRESS
557667*        MOVE 'PR'          TO RAG-MAIL-CLI-ADDR-ID
557667         MOVE 'PR'              TO WS-MAIL-ADDR-TYP-CD
557667         IF  MIR-DV-AGT-MAIL-TYP-CD NOT = 'PR'
557667             MOVE 'PR'          TO MIR-DV-AGT-MAIL-TYP-CD
557667             MOVE 'XS00000214'  TO WGLOB-MSG-REF-INFO
557667             PERFORM  0260-1000-GENERATE-MESSAGE
557667                 THRU 0260-1000-GENERATE-MESSAGE-X
557667         END-IF
           END-IF.

           IF L2440-ADDR-STAT-ERROR
               MOVE L2440-CLI-ID      TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000211'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8103-EDIT-MADTY-X.
           EXIT.
      /
      **** NEW ROUTINE FOR THE EDIT OF SCREEN 02
      *-----------------
       8200-EDIT-SCR-02.
      *-----------------

      *********************
      ***   EDIT MIR-AGT-STAT-CD
      *********************
           IF  MIR-AGT-STAT-CD  = SPACES
               MOVE RAG-AGT-STAT-CD   TO MIR-AGT-STAT-CD
           ELSE
557660         IF MIR-AGT-STAT-CD = 'A'
               OR MIR-AGT-STAT-CD = 'I'
               OR MIR-AGT-STAT-CD = 'V'
                   MOVE MIR-AGT-STAT-CD
                                      TO RAG-AGT-STAT-CD
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810015'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-PREV
      *********************

557659*    IF MIR-PREV     = SPACES
557659*        MOVE RAG-PREV-AGT-BR-ID TO MIR-PREV
557659*    ELSE
557659*        IF MIR-PREV = EBLCH-BLANK-FIELD-CHAR
557659*            MOVE SPACES         TO MIR-PREV
557659*        END-IF
557659*    END-IF.
557659*
557659*    MOVE MIR-PREV           TO RAG-PREV-AGT-BR-ID.
557659*    MOVE RAG-PREV-AGT-BR-ID TO MIR-PREV.

557659**********************
557659***   EDIT MIR-PREV-AGT-ID
557659**********************
557659
557659     IF MIR-PREV-AGT-ID  = SPACES
557659         MOVE RAG-PREV-AGT-ID   TO MIR-PREV-AGT-ID
557659     ELSE
557659         IF MIR-PREV-AGT-ID = EBLCH-BLANK-FIELD-CHAR
557659             MOVE SPACES        TO MIR-PREV-AGT-ID
557659         END-IF
557659     END-IF.
557659
557659     MOVE MIR-PREV-AGT-ID       TO RAG-PREV-AGT-ID.
557659     MOVE RAG-PREV-AGT-ID       TO MIR-PREV-AGT-ID.
557659
557659**********************
557659***   EDIT MIR-PREV-BR-ID
557659**********************
557659
557659     IF MIR-PREV-BR-ID  = SPACES
557659         MOVE RAG-PREV-BR-ID    TO MIR-PREV-BR-ID
557659     ELSE
557659         IF MIR-PREV-BR-ID = EBLCH-BLANK-FIELD-CHAR
557659             MOVE SPACES        TO MIR-PREV-BR-ID
557659         END-IF
557659     END-IF.
557659
557659     MOVE MIR-PREV-BR-ID        TO RAG-PREV-BR-ID.
557659     MOVE RAG-PREV-BR-ID        TO MIR-PREV-BR-ID.
557659
      *********************
      ***   EDIT MIR-AGT-TYP-CD
      *********************
           IF  MIR-AGT-TYP-CD   = SPACES
               MOVE RAG-AGT-TYP-CD    TO MIR-AGT-TYP-CD
           ELSE
557660         IF MIR-AGT-TYP-CD  = 'A'
               OR MIR-AGT-TYP-CD  = 'B'
               OR MIR-AGT-TYP-CD  = 'N'
                   MOVE MIR-AGT-TYP-CD   TO RAG-AGT-TYP-CD
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810016'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-SPNSR-LIC-IND
      *********************

           IF  MIR-AGT-SPNSR-LIC-IND  = SPACES
               MOVE RAG-AGT-SPNSR-LIC-IND
                                      TO MIR-AGT-SPNSR-LIC-IND
           ELSE
557660         IF MIR-AGT-SPNSR-LIC-IND = 'Y'
               OR MIR-AGT-SPNSR-LIC-IND = 'N'
                   MOVE MIR-AGT-SPNSR-LIC-IND
                                      TO RAG-AGT-SPNSR-LIC-IND
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810039'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-CMPNST-SCHD-CD
      *********************
           IF  MIR-AGT-CMPNST-SCHD-CD    = SPACES
               MOVE RAG-AGT-CMPNST-SCHD-CD
                                      TO MIR-AGT-CMPNST-SCHD-CD
           ELSE
016955*        IF MIR-AGT-CMPNST-SCHD-CD   = 'A'
016955*        OR MIR-AGT-CMPNST-SCHD-CD   = 'B'
016955*        OR MIR-AGT-CMPNST-SCHD-CD   = 'C'
016955*        OR MIR-AGT-CMPNST-SCHD-CD   = 'D'
016955*            MOVE MIR-AGT-CMPNST-SCHD-CD
016955*                               TO RAG-AGT-CMPNST-SCHD-CD
016955         MOVE MIR-AGT-CMPNST-SCHD-CD     TO WEDIT-ETBL-VALU-ID
016955
016955         PERFORM  AGSC-1000-EDIT
016955             THRU AGSC-1000-EDIT-X
016955
016955         IF  WEDIT-IO-OK
016955             MOVE MIR-AGT-CMPNST-SCHD-CD TO RAG-AGT-CMPNST-SCHD-CD
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810094'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-PRIM-LIC-ID
      *********************
           IF  MIR-AGT-PRIM-LIC-ID  = SPACES
               MOVE RAG-AGT-PRIM-LIC-ID
                                      TO MIR-AGT-PRIM-LIC-ID
           ELSE
               IF MIR-AGT-PRIM-LIC-ID  = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-AGT-PRIM-LIC-ID
               END-IF
           END-IF.

           MOVE MIR-AGT-PRIM-LIC-ID   TO RAG-AGT-PRIM-LIC-ID.
           MOVE RAG-AGT-PRIM-LIC-ID   TO MIR-AGT-PRIM-LIC-ID.

      *********************
      ***   EDIT MIR-NMED-UWG-PRVLG-IND
      *********************

           IF  MIR-NMED-UWG-PRVLG-IND  = SPACES
               MOVE RAG-NMED-UWG-PRVLG-IND
                                      TO MIR-NMED-UWG-PRVLG-IND
           ELSE
557660         IF MIR-NMED-UWG-PRVLG-IND = 'Y'
               OR MIR-NMED-UWG-PRVLG-IND = 'N'
                   MOVE MIR-NMED-UWG-PRVLG-IND
                                      TO RAG-NMED-UWG-PRVLG-IND
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810040'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-COMM-WTHLD-PCT
      *********************
           IF  MIR-AGT-COMM-WTHLD-PCT    =  SPACES
019524*        MOVE RAG-AGT-COMM-WTHLD-PCT-N
019524*                               TO MIR-AGT-COMM-WTHLD-PCT
019524         MOVE RAG-AGT-COMM-WTHLD-PCT TO L0290-INPUT-V00
019524         MOVE ZERO                  TO L0290-PRECISION
019524         MOVE LENGTH OF MIR-AGT-COMM-WTHLD-PCT
019524                                    TO L0290-MAX-OUT-LEN
019524         PERFORM 0290-2000-FORMAT-FOR-MIR
019524            THRU 0290-2000-FORMAT-FOR-MIR-X
019524         MOVE L0290-OUTPUT-DATA     TO MIR-AGT-COMM-WTHLD-PCT
           ELSE
               IF MIR-AGT-COMM-WTHLD-PCT =  EBLCH-BLANK-FIELD-CHAR
020874*            MOVE ZEROS         TO EDIT-5
020874*            MOVE EDIT-5        TO MIR-AGT-COMM-WTHLD-PCT
020874             MOVE ZEROS                 TO L0290-INPUT-V00
020874             MOVE ZERO                  TO L0290-PRECISION
020874             MOVE LENGTH OF MIR-AGT-COMM-WTHLD-PCT
020874                                TO L0290-MAX-OUT-LEN
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
020874             MOVE L0290-OUTPUT-DATA     TO MIR-AGT-COMM-WTHLD-PCT
               END-IF
               MOVE 'N'               TO L0280-SIGN-IND
               MOVE 0                 TO L0280-PRECISION
019524*        MOVE 2                 TO L0280-LENGTH
019524         MOVE LENGTH OF MIR-AGT-COMM-WTHLD-PCT
019524                                TO L0280-LENGTH
019524*        MOVE 2                 TO L0280-INPUT-SIZE
019524         MOVE LENGTH OF MIR-AGT-COMM-WTHLD-PCT
019524                                TO L0280-INPUT-SIZE
               MOVE MIR-AGT-COMM-WTHLD-PCT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
019524*            MOVE L0280-OUTPUT  TO RAG-AGT-COMM-WTHLD-PCT-N
019524             MOVE L0280-OUTPUT  TO RAG-AGT-COMM-WTHLD-PCT
020874*            MOVE RAG-AGT-COMM-WTHLD-PCT-N
020874*                               TO EDIT-5
020874*            MOVE EDIT-5        TO MIR-AGT-COMM-WTHLD-PCT
019524*            MOVE RAG-AGT-COMM-WTHLD-PCT-N  TO L0290-INPUT-V00
019524             MOVE RAG-AGT-COMM-WTHLD-PCT    TO L0290-INPUT-V00
020874             MOVE ZERO                      TO L0290-PRECISION
020874             MOVE LENGTH OF MIR-AGT-COMM-WTHLD-PCT
020874                                            TO L0290-MAX-OUT-LEN
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
020874             MOVE L0290-OUTPUT-DATA     TO MIR-AGT-COMM-WTHLD-PCT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810055'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-BROK-OVRID-IND
      *********************
           IF  MIR-AGT-BROK-OVRID-IND  = SPACES
               MOVE RAG-AGT-BROK-OVRID-IND
                                      TO MIR-AGT-BROK-OVRID-IND
           ELSE
               IF MIR-AGT-BROK-OVRID-IND = 'Y'
               OR MIR-AGT-BROK-OVRID-IND = 'N'
                   MOVE MIR-AGT-BROK-OVRID-IND
                                      TO RAG-AGT-BROK-OVRID-IND
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810041'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-DEV-PGM-INCM-AMT
      *********************
           IF MIR-DEV-PGM-INCM-AMT                   =  SPACES
557973*        MOVE RAG-DEV-PGM-INCM-AMT-N TO MIR-DEV-PGM-INCM-AMT
008455*        MOVE RAG-DEV-PGM-INCM-AMT   TO EDIT-6
008455*        MOVE EDIT-6                 TO MIR-DEV-PGM-INCM-AMT
020874*        MOVE RAG-DEV-PGM-INCM-AMT
020874*                               TO L0290-INPUT-NUMBER
020874         MOVE RAG-DEV-PGM-INCM-AMT
020874                                TO L0290-INPUT-V00
008455         MOVE +0                TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DEV-PGM-INCM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-DEV-PGM-INCM-AMT
           ELSE
               IF MIR-DEV-PGM-INCM-AMT  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-6
008455*            MOVE EDIT-6             TO MIR-DEV-PGM-INCM-AMT
008455             MOVE ZEROS         TO MIR-DEV-PGM-INCM-AMT
               END-IF
               MOVE 'N'               TO L0280-SIGN-IND
               MOVE 0                 TO L0280-PRECISION
008455*        MOVE 4                      TO L0280-LENGTH
008455*        MOVE 4                      TO L0280-INPUT-SIZE
008455         MOVE LENGTH OF MIR-DEV-PGM-INCM-AMT
                                      TO L0280-INPUT-SIZE
008455         MOVE L0280-INPUT-SIZE  TO L0280-LENGTH
               MOVE MIR-DEV-PGM-INCM-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
557973*            MOVE L0280-OUTPUT       TO RAG-DEV-PGM-INCM-AMT-N
557973*            MOVE RAG-DEV-PGM-INCM-AMT-N  TO EDIT-6
557973             MOVE L0280-OUTPUT  TO RAG-DEV-PGM-INCM-AMT
008455*            MOVE RAG-DEV-PGM-INCM-AMT
008455*                                    TO EDIT-6
008455*            MOVE EDIT-6             TO MIR-DEV-PGM-INCM-AMT
020874*            MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
020874             MOVE L0280-OUTPUT  TO L0290-INPUT-V00
008455             MOVE +0            TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-DEV-PGM-INCM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-DEV-PGM-INCM-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810056'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-FRNG-BNFT-IND
      *********************

           IF  MIR-AGT-FRNG-BNFT-IND  = SPACES
               MOVE RAG-AGT-FRNG-BNFT-IND
                                      TO MIR-AGT-FRNG-BNFT-IND
           ELSE
               IF MIR-AGT-FRNG-BNFT-IND = 'Y'
               OR MIR-AGT-FRNG-BNFT-IND = 'N'
                   MOVE MIR-AGT-FRNG-BNFT-IND
                                      TO RAG-AGT-FRNG-BNFT-IND
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810042'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-VEST-INT-AMT
      *********************
           IF MIR-AGT-VEST-INT-AMT                   =  SPACES
008455*        MOVE RAG-AGT-VEST-INT-AMT   TO EDIT-1
008455*        MOVE EDIT-1                 TO MIR-AGT-VEST-INT-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RAG-AGT-VEST-INT-AMT * 100
020874         MOVE RAG-AGT-VEST-INT-AMT TO L0290-INPUT-V02
008455         MOVE +2                   TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-AGT-VEST-INT-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        SET L0290-LEAD-ZEROS-SUPPRESS  TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-AGT-VEST-INT-AMT
           ELSE
               IF MIR-AGT-VEST-INT-AMT  =  EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-1
008455*            MOVE EDIT-1             TO MIR-AGT-VEST-INT-AMT
008455             MOVE ZEROS         TO MIR-AGT-VEST-INT-AMT
               END-IF
               MOVE 'N'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 10                     TO L0280-INPUT-SIZE
008455         MOVE LENGTH OF MIR-AGT-VEST-INT-AMT
                                      TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3
               MOVE MIR-AGT-VEST-INT-AMT
                                      TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT-DOLLAR
                                      TO RAG-AGT-VEST-INT-AMT
008455*            MOVE RAG-AGT-VEST-INT-AMT TO EDIT-1
008455*            MOVE EDIT-1               TO MIR-AGT-VEST-INT-AMT
                   MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
008455             MOVE +2            TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-AGT-VEST-INT-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-AGT-VEST-INT-AMT
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810057'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-QLTY-BON-PGM-IND
      *********************
           IF  MIR-QLTY-BON-PGM-IND   = SPACES
               MOVE RAG-QLTY-BON-PGM-IND
                                      TO MIR-QLTY-BON-PGM-IND
           ELSE
               IF MIR-QLTY-BON-PGM-IND  = 'Y'
               OR MIR-QLTY-BON-PGM-IND  = 'N'
                   MOVE MIR-QLTY-BON-PGM-IND
                                      TO RAG-QLTY-BON-PGM-IND
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810043'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-NHS-CMPNST-PGM-IND
      *********************
           IF  MIR-NHS-CMPNST-PGM-IND  = SPACES
               MOVE RAG-NHS-CMPNST-PGM-IND
                                      TO MIR-NHS-CMPNST-PGM-IND
           ELSE
557660         IF MIR-NHS-CMPNST-PGM-IND = 'Y'
               OR MIR-NHS-CMPNST-PGM-IND = 'N'
                   MOVE MIR-NHS-CMPNST-PGM-IND
                                      TO RAG-NHS-CMPNST-PGM-IND
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810044'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-MKT-BON-PGM-IND
      *********************

           IF MIR-MKT-BON-PGM-IND  = SPACES
               MOVE RAG-MKT-BON-PGM-IND
                                      TO MIR-MKT-BON-PGM-IND
           ELSE
557660         IF MIR-MKT-BON-PGM-IND = 'Y'
               OR MIR-MKT-BON-PGM-IND = 'N'
                   MOVE MIR-MKT-BON-PGM-IND
                                      TO RAG-MKT-BON-PGM-IND
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810045'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-OTHR-CMPNST-CD
      *********************

           IF MIR-AGT-OTHR-CMPNST-CD     = SPACES
               MOVE RAG-AGT-OTHR-CMPNST-CD
                                      TO MIR-AGT-OTHR-CMPNST-CD
           ELSE
557660         IF MIR-AGT-OTHR-CMPNST-CD = 'A'
               OR MIR-AGT-OTHR-CMPNST-CD = 'B'
               OR MIR-AGT-OTHR-CMPNST-CD = 'C'
               OR MIR-AGT-OTHR-CMPNST-CD = 'D'
                   MOVE MIR-AGT-OTHR-CMPNST-CD
                                      TO RAG-AGT-OTHR-CMPNST-CD
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810092'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *********************
      ***   EDIT MIR-AGT-FIN-ARANG-IND
      *********************

           IF MIR-AGT-FIN-ARANG-IND  = SPACES
               MOVE RAG-AGT-FIN-ARANG-IND
                                      TO MIR-AGT-FIN-ARANG-IND
           ELSE
557660         IF MIR-AGT-FIN-ARANG-IND = 'Y'
               OR MIR-AGT-FIN-ARANG-IND = 'N'
                   MOVE MIR-AGT-FIN-ARANG-IND
                                      TO RAG-AGT-FIN-ARANG-IND
               ELSE
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810046'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.
012148
012148*********************
012148***   EDIT MIR-AGT-TRAIL-COMM-IND
012148*********************
012148
012148     IF  MIR-AGT-TRAIL-COMM-IND  = SPACES
012148         MOVE RAG-AGT-TRAIL-COMM-IND
                                      TO MIR-AGT-TRAIL-COMM-IND
012148     ELSE
012148         IF  MIR-AGT-TRAIL-COMM-IND = 'Y'
012148         OR  MIR-AGT-TRAIL-COMM-IND = 'N'
012148             MOVE MIR-AGT-TRAIL-COMM-IND
                                      TO RAG-AGT-TRAIL-COMM-IND
012148         ELSE
012148             MOVE  'Y'          TO WS-ERROR-SW
012148* MSG: TRAIL COMMISSION INDICATOR MUST BE 'Y' OR 'N'
012148             MOVE 'CS00810096'  TO WGLOB-MSG-REF-INFO
012148             PERFORM  0260-1000-GENERATE-MESSAGE
012148                 THRU 0260-1000-GENERATE-MESSAGE-X
012148         END-IF
012148     END-IF.

      *********************
      ***   CROSS EDITS
      *********************
           IF RAG-FYR-COMM-CALC-CD = 'B'
           OR RAG-FYR-COMM-CALC-CD = 'D'
               IF RAG-PARTL-ADV-COMM-CD  NOT = 'N'
                   MOVE  'Y'          TO WS-ERROR-SW
                   MOVE 'CS00810019'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF RAG-AGT-STAT-CD = 'A'
557659*    AND RAG-CNTRCT-TRMN-DT-TXT NOT = SPACES
557659     AND MIR-AGT-CNTRCT-TRMN-DT NOT = SPACES
               MOVE  'Y'              TO WS-ERROR-SW
               MOVE 'CS00810021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

557659*    MOVE RAG-CNTRCT-TRMN-DT-TXT TO L1640-EXTERNAL-DATE.
557659*    PERFORM  1640-3000-EXTERNAL-TO-INT
557659*        THRU 1640-3000-EXTERNAL-TO-INT-X.
557659*    IF L1640-VALID
557659*        IF L1640-INTERNAL-DATE < RAG-AGT-CNTRCT-STRT-DT
557659*            MOVE  'Y'              TO WS-ERROR-SW
557659*            MOVE 'CS00810022'      TO WGLOB-MSG-REF-INFO
557659*            PERFORM  0260-1000-GENERATE-MESSAGE
557659*                THRU 0260-1000-GENERATE-MESSAGE-X
557659*        END-IF
557659*    END-IF.
557659     IF  MIR-AGT-CNTRCT-TRMN-DT NOT = SPACES
557659     AND RAG-AGT-CNTRCT-TRMN-DT < RAG-AGT-CNTRCT-STRT-DT
557659         MOVE  'Y'              TO WS-ERROR-SW
557659         MOVE 'CS00810022'      TO WGLOB-MSG-REF-INFO
557659         PERFORM  0260-1000-GENERATE-MESSAGE
557659             THRU 0260-1000-GENERATE-MESSAGE-X
557659     END-IF.

       8200-EDIT-SCR-02-X.
           EXIT.
      /
      **** NEW ROUTINE FOR THE EDIT OF SCREEN 05
      *-----------------
010418*8500-EDIT-SCR-05.
      *-----------------
      *
      *********************
      ***   EDIT MIR-PRST-T
      *********************

010418*    IF MIR-PRST-T (WS-SUB) = SPACES
010418*        MOVE RAB-AGT-PRST-PCT (WS-SUB) TO EDIT-2
010418*        MOVE EDIT-2                    TO MIR-PRST-T (WS-SUB)
010418*    ELSE
010418*        IF MIR-PRST-T (WS-SUB)  = EBLCH-BLANK-FIELD-CHAR
010418*            MOVE ZEROS              TO EDIT-2
010418*            MOVE EDIT-2             TO MIR-PRST-T (WS-SUB)
010418*        END-IF
010418*        MOVE 'N'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
010418*        MOVE 3                      TO L0280-LENGTH
010418*        MOVE 6                      TO L0280-INPUT-SIZE
010418*        MOVE MIR-PRST-T (WS-SUB)    TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF L0280-OK
010418*            MOVE L0280-OUTPUT-DOLLAR TO RAB-AGT-PRST-PCT (WS-SUB)
010418*            MOVE RAB-AGT-PRST-PCT (WS-SUB) TO EDIT-2
010418*            MOVE EDIT-2             TO MIR-PRST-T (WS-SUB)
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-PRST-T-A (WS-SUB)
010418*            MOVE -1                 TO MIR-PRST-T-L (WS-SUB)
010418*            MOVE WS-SUB             TO EDIT-8
010418*            MOVE EDIT-8             TO WGLOB-MSG-PARM (1)
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810069'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-PRDL-T
      *********************

010418*    IF MIR-PRDL-T (WS-SUB) = SPACES
008455*        MOVE RAB-AGT-PROD-AMT (WS-SUB) TO EDIT-3D
008455*        MOVE EDIT-3D                   TO MIR-PRDL-T (WS-SUB)
010418*        MOVE RAB-AGT-PROD-AMT (WS-SUB) TO L0290-INPUT-NUMBER
010418*        MOVE +0                        TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-PRDL-T (WS-SUB)
010418*                                       TO L0290-MAX-OUT-LEN
010418*        SET  L0290-SIGN-DISPLAY        TO TRUE
010418*        SET  L0290-SIGN-POS-DISPLAY    TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA         TO MIR-PRDL-T (WS-SUB)
010418*    ELSE
010418*        IF MIR-PRDL-T (WS-SUB)  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '+000000000'       TO MIR-PRDL-T (WS-SUB)
010418*            MOVE ZEROS              TO MIR-PRDL-T (WS-SUB)
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 0                      TO L0280-PRECISION
008455*        MOVE 9                      TO L0280-LENGTH
008455*        MOVE 10                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-PRDL-T (WS-SUB)
010418*                                    TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 1
010418*        MOVE MIR-PRDL-T (WS-SUB)    TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF L0280-OK
010418*            MOVE L0280-OUTPUT       TO RAB-AGT-PROD-AMT (WS-SUB)
008455*            MOVE RAB-AGT-PROD-AMT (WS-SUB) TO EDIT-3D
008455*            MOVE EDIT-3D            TO MIR-PRDL-T (WS-SUB)
010418*            MOVE L0280-OUTPUT          TO L0290-INPUT-NUMBER
010418*            MOVE +0                    TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-PRDL-T (WS-SUB)
010418*                                       TO L0290-MAX-OUT-LEN
010418*            SET L0290-SIGN-DISPLAY     TO TRUE
010418*            SET L0290-SIGN-POS-DISPLAY TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA     TO MIR-PRDL-T (WS-SUB)
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-PRDL-T-A (WS-SUB)
010418*            MOVE -1                 TO MIR-PRDL-T-L (WS-SUB)
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE WS-SUB             TO EDIT-8
010418*            MOVE EDIT-8             TO WGLOB-MSG-PARM (1)
010418*            MOVE 'CS00810070'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-MDRT-T
      *********************

010418*    IF MIR-MDRT-T (WS-SUB) = SPACES
008455*        MOVE RAB-AGT-MDRT-AMT (WS-SUB) TO EDIT-3D
008455*        MOVE EDIT-3D                   TO MIR-MDRT-T (WS-SUB)
010418*        MOVE RAB-AGT-MDRT-AMT (WS-SUB) TO L0290-INPUT-NUMBER
010418*        MOVE +0                        TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-MDRT-T (WS-SUB)
010418*                                       TO L0290-MAX-OUT-LEN
010418*        SET  L0290-SIGN-DISPLAY        TO TRUE
010418*        SET  L0290-SIGN-POS-DISPLAY    TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA         TO MIR-MDRT-T (WS-SUB)
010418*    ELSE
010418*        IF MIR-MDRT-T (WS-SUB)  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '+000000000'       TO MIR-MDRT-T (WS-SUB)
010418*            MOVE ZEROS              TO MIR-MDRT-T (WS-SUB)
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 0                      TO L0280-PRECISION
008455*        MOVE 9                      TO L0280-LENGTH
008455*        MOVE 10                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-MDRT-T (WS-SUB)
010418*                                    TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 1
010418*        MOVE MIR-MDRT-T (WS-SUB)    TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF L0280-OK
010418*            MOVE L0280-OUTPUT       TO RAB-AGT-MDRT-AMT (WS-SUB)
008455*            MOVE RAB-AGT-MDRT-AMT (WS-SUB) TO EDIT-3D
008455*            MOVE EDIT-3D            TO MIR-MDRT-T (WS-SUB)
010418*            MOVE L0280-OUTPUT              TO L0290-INPUT-NUMBER
010418*            MOVE +0                        TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-MDRT-T (WS-SUB)
010418*                                           TO L0290-MAX-OUT-LEN
010418*            SET  L0290-SIGN-DISPLAY        TO TRUE
010418*            SET  L0290-SIGN-POS-DISPLAY    TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA         TO MIR-MDRT-T (WS-SUB)
010418*         ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-MDRT-T-A (WS-SUB)
010418*            MOVE -1                 TO MIR-MDRT-T-L (WS-SUB)
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE WS-SUB             TO EDIT-8
010418*            MOVE EDIT-8             TO WGLOB-MSG-PARM (1)
010418*            MOVE 'CS00810071'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***  EDIT MIR-CONV-T
      *********************

557659*    IF  MIR-CONV-T (WS-SUB)  = SPACES
557659*        MOVE RAB-CNVTN-ATND-IND (WS-SUB) TO MIR-CONV-T (WS-SUB)
557659*    ELSE
010418*        IF MIR-CONV-T(WS-SUB) =  'Y'
010418*        OR MIR-CONV-T(WS-SUB) =  'N'
557659*        OR MIR-CONV-T(WS-SUB) =  'U'
010418*        OR MIR-CONV-T(WS-SUB) =  ' '
010418*            MOVE MIR-CONV-T(WS-SUB) TO RAB-CNVTN-ATND-IND(WS-SUB)
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-CONV-T-A (WS-SUB)
010418*            MOVE -1                 TO MIR-CONV-T-L (WS-SUB)
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE WS-SUB             TO EDIT-8
010418*            MOVE EDIT-8             TO WGLOB-MSG-PARM (1)
010418*            MOVE 'CS00810049'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF.
557659*        END-IF
557659*    END-IF.

      *********************
      *** EDIT MIR-APPA-T
      *********************

557659*    IF  MIR-APPA-T (WS-SUB)  = SPACES
557659*        MOVE RAB-APTVTY-AWD-IND (WS-SUB) TO MIR-APPA-T (WS-SUB)
557659*    ELSE
010418*        IF MIR-APPA-T (WS-SUB)  =  'Y'
010418*        OR MIR-APPA-T (WS-SUB)  =  'N'
557659*        OR MIR-APPA-T (WS-SUB)  =  'U'
010418*        OR MIR-APPA-T (WS-SUB)  =  ' '
010418*            MOVE MIR-APPA-T(WS-SUB) TO RAB-APTVTY-AWD-IND(WS-SUB)
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-APPA-T-A (WS-SUB)
010418*            MOVE -1                 TO MIR-APPA-T-L (WS-SUB)
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE WS-SUB             TO EDIT-8
010418*            MOVE EDIT-8             TO WGLOB-MSG-PARM (1)
010418*            MOVE 'CS00810050'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF.
557659*        END-IF
557659*    END-IF.

      *********************
      ***   EDIT MIR-NQA-T
      *********************
557659*    IF  MIR-NQA-T (WS-SUB)  = SPACES
557659*        MOVE RAB-NQA-IND (WS-SUB)   TO MIR-NQA-T (WS-SUB)
557659*    ELSE
010418*        IF MIR-NQA-T (WS-SUB)  =  'Y'
010418*        OR MIR-NQA-T (WS-SUB)  =  'N'
557659*        OR MIR-NQA-T (WS-SUB)  =  'U'
010418*        OR MIR-NQA-T (WS-SUB)  =  ' '
010418*            MOVE MIR-NQA-T (WS-SUB) TO RAB-NQA-IND (WS-SUB)
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-NQA-T-A (WS-SUB)
010418*            MOVE -1                 TO MIR-NQA-T-L (WS-SUB)
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE WS-SUB             TO EDIT-8
010418*            MOVE EDIT-8             TO WGLOB-MSG-PARM (1)
010418*            MOVE 'CS00810051'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF.
557659*        END-IF
557659*    END-IF.

010418*8500-EDIT-SCR-05-X.
010418*    EXIT.
      **** NEW ROUTINE FOR THE EDIT OF SCREEN 06
      *-----------------
010418*8600-EDIT-SCR-06.
      *-----------------

      *********************
      ***   EDIT MIR-FPRCMO
      *********************

010418*    IF  MIR-FPRCMO  = SPACES
008455*        MOVE RAB-FYR-CPREM-CMO-AMT  TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-FPRCMO
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-FYR-CPREM-CMO-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-FPRCMO   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-FPRCMO
010418*    ELSE
010418*        IF MIR-FPRCMO  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-FPRCMO
010418*            MOVE ZEROS              TO MIR-FPRCMO
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-FPRCMO   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-FPRCMO             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-FYR-CPREM-CMO-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-FYR-CPREM-CMO-AMT TO EDIT-7
008455*            MOVE EDIT-7                TO MIR-FPRCMO
010418*            MOVE L0280-OUTPUT          TO L0290-INPUT-NUMBER
010418*            MOVE +2                    TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-FPRCMO  TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE
010418*            SET  L0290-SIGN-DISPLAY    TO TRUE
010418*            SET  L0290-SIGN-FLOAT      TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA     TO MIR-FPRCMO
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-FPRCMO-A
010418*            MOVE -1                 TO MIR-FPRCMO-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810072'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-FPRYTD
      *********************

010418*    IF  MIR-FPRYTD  = SPACES
008455*        MOVE RAB-FYR-CPREM-YTD-AMT  TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-FPRYTD
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-FYR-CPREM-YTD-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-FPRYTD   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-FPRYTD
010418*    ELSE
010418*        IF MIR-FPRYTD  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-FPRYTD
010418*            MOVE ZEROS              TO MIR-FPRYTD
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-FPRYTD   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-FPRYTD             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-FYR-CPREM-YTD-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-FYR-CPREM-YTD-AMT TO EDIT-7
008455*            MOVE EDIT-7                TO MIR-FPRYTD
010418*            MOVE L0280-OUTPUT          TO L0290-INPUT-NUMBER
010418*            MOVE +2                    TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-FPRYTD  TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE
010418*            SET  L0290-SIGN-DISPLAY    TO TRUE
010418*            SET  L0290-SIGN-FLOAT      TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA     TO MIR-FPRYTD
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-FPRYTD-A
010418*            MOVE -1                 TO MIR-FPRYTD-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810073'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-FCMCMO
      *********************
010418*    IF  MIR-FCMCMO  = SPACES
008455*        MOVE RAB-FYR-LCOMM-CMO-AMT  TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-FCMCMO
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-FYR-LCOMM-CMO-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-FCMCMO   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-FCMCMO
010418*    ELSE
010418*        IF MIR-FCMCMO  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-FCMCMO
010418*            MOVE ZEROS              TO MIR-FCMCMO
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-FCMCMO   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-FCMCMO             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-FYR-LCOMM-CMO-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-FYR-LCOMM-CMO-AMT TO EDIT-7
008455*            MOVE EDIT-7                TO MIR-FCMCMO
010418*            MOVE L0280-OUTPUT          TO L0290-INPUT-NUMBER
010418*            MOVE +2                    TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-FCMCMO  TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE
010418*            SET  L0290-SIGN-DISPLAY    TO TRUE
010418*            SET  L0290-SIGN-FLOAT      TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA     TO MIR-FCMCMO
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-FCMCMO-A
010418*            MOVE -1                 TO MIR-FCMCMO-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810074'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM 0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-FCMYTD
      *********************

010418*    IF  MIR-FCMYTD  = SPACES
008455*        MOVE RAB-FYR-LCOMM-YTD-AMT  TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-FCMYTD
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-FYR-LCOMM-YTD-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-FCMYTD   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-FCMYTD
010418*    ELSE
010418*        IF MIR-FCMYTD  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-FCMYTD
010418*            MOVE ZEROS              TO MIR-FCMYTD
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-FCMYTD   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-FCMYTD             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-FYR-LCOMM-YTD-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-FYR-LCOMM-YTD-AMT TO EDIT-7
008455*            MOVE EDIT-7                TO MIR-FCMYTD
010418*            MOVE L0280-OUTPUT          TO L0290-INPUT-NUMBER
010418*            MOVE +2                    TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-FCMYTD  TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE
010418*            SET  L0290-SIGN-DISPLAY    TO TRUE
010418*            SET  L0290-SIGN-FLOAT      TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA     TO MIR-FCMYTD
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-FCMYTD-A
010418*            MOVE -1                 TO MIR-FCMYTD-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810075'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM 0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-RPRCMO
      *********************
010418*    IF  MIR-RPRCMO  = SPACES
008455*        MOVE RAB-RENW-CPREM-CMO-AMT TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-RPRCMO
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-RENW-CPREM-CMO-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-RPRCMO   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-RPRCMO
010418*    ELSE
010418*        IF MIR-RPRCMO  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-RPRCMO
010418*            MOVE ZEROS              TO MIR-RPRCMO
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-RPRCMO   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-RPRCMO             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-RENW-CPREM-CMO-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-RENW-CPREM-CMO-AMT TO EDIT-7
008455*            MOVE EDIT-7                 TO MIR-RPRCMO
010418*            MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER
010418*            MOVE +2                     TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-RPRCMO   TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE
010418*            SET  L0290-SIGN-DISPLAY     TO TRUE
010418*            SET  L0290-SIGN-FLOAT       TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA      TO MIR-RPRCMO
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-RPRCMO-A
010418*            MOVE -1                 TO MIR-RPRCMO-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810076'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM 0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-RPRYTD
      *********************
010418*    IF  MIR-RPRYTD  = SPACES
008455*        MOVE RAB-RENW-CPREM-YTD-AMT TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-RPRYTD
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-RENW-CPREM-YTD-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-RPRYTD   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-RPRYTD
010418*    ELSE
010418*        IF MIR-RPRYTD  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-RPRYTD
010418*            MOVE ZEROS              TO MIR-RPRYTD
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-RPRYTD   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-RPRYTD             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-RENW-CPREM-YTD-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-RENW-CPREM-YTD-AMT TO EDIT-7
008455*            MOVE EDIT-7                 TO MIR-RPRYTD
010418*            MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER
010418*            MOVE +2                     TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-RPRYTD   TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE
010418*            SET  L0290-SIGN-DISPLAY     TO TRUE
010418*            SET  L0290-SIGN-FLOAT       TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA      TO MIR-RPRYTD
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-RPRYTD-A
010418*            MOVE -1                 TO MIR-RPRYTD-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810077'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-RCMCMO
      *********************

010418*    IF  MIR-RCMCMO  = SPACES
008455*        MOVE RAB-RENW-LCOMM-CMO-AMT TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-RCMCMO
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-RENW-LCOMM-CMO-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-RCMCMO   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-RCMCMO
010418*    ELSE
010418*        IF MIR-RCMCMO  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-RCMCMO
010418*            MOVE ZEROS              TO MIR-RCMCMO
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-RCMCMO   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-RCMCMO             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-RENW-LCOMM-CMO-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-RENW-LCOMM-CMO-AMT TO EDIT-7
008455*            MOVE EDIT-7                 TO MIR-RCMCMO
010418*            MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER
010418*            MOVE +2                     TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-RCMCMO   TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE
010418*            SET  L0290-SIGN-DISPLAY     TO TRUE
010418*            SET  L0290-SIGN-FLOAT       TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA      TO MIR-RCMCMO
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-RCMCMO-A
010418*            MOVE -1                 TO MIR-RCMCMO-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810078'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-RCMYTD
      *********************

010418*    IF  MIR-RCMYTD  = SPACES
008455*        MOVE RAB-RENW-LCOMM-YTD-AMT TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-RCMYTD
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-RENW-LCOMM-YTD-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-RCMYTD   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                    TO TRUE
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-RCMYTD
010418*    ELSE
010418*        IF MIR-RCMYTD  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-RCMYTD
010418*            MOVE ZEROS              TO MIR-RCMYTD
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-RCMYTD   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-RCMYTD             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-RENW-LCOMM-YTD-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-RENW-LCOMM-YTD-AMT TO EDIT-7
008455*            MOVE EDIT-7                 TO MIR-RCMYTD
010418*            MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER
010418*            MOVE +2                     TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-RCMYTD   TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                        TO TRUE
010418*            SET  L0290-SIGN-DISPLAY     TO TRUE
010418*            SET  L0290-SIGN-FLOAT       TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA      TO MIR-RCMYTD
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-RCMYTD-A
010418*            MOVE -1                 TO MIR-RCMYTD-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810079'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-QTYCMO
      *********************

010418*    IF  MIR-QTYCMO  = SPACES
008455*        MOVE RAB-QLTY-BON-CMO-AMT   TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-QTYCMO
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-QLTY-BON-CMO-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-QTYCMO   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                    TO TRUE
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-QTYCMO
010418*    ELSE
010418*        IF MIR-QTYCMO  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-QTYCMO
010418*            MOVE ZEROS              TO MIR-QTYCMO
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-QTYCMO   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-QTYCMO             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-QLTY-BON-CMO-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-QLTY-BON-CMO-AMT TO EDIT-7
008455*            MOVE EDIT-7               TO MIR-QTYCMO
010418*            MOVE L0280-OUTPUT         TO L0290-INPUT-NUMBER
010418*            MOVE +2                   TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-QTYCMO TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                      TO TRUE
010418*            SET  L0290-SIGN-DISPLAY   TO TRUE
010418*            SET  L0290-SIGN-FLOAT     TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA    TO MIR-QTYCMO
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-QTYCMO-A
010418*            MOVE -1                 TO MIR-QTYCMO-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810080'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM 0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-QTYYTD
      *********************

010418*    IF  MIR-QTYYTD  = SPACES
008455*        MOVE RAB-QLTY-BON-YTD-AMT   TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-QTYYTD
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-QLTY-BON-YTD-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-QTYYTD   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                    TO TRUE
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-QTYYTD
010418*    ELSE
010418*        IF MIR-QTYYTD  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-QTYYTD
010418*            MOVE ZEROS              TO MIR-QTYYTD
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-QTYYTD   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-QTYYTD             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-QLTY-BON-YTD-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-QLTY-BON-YTD-AMT TO EDIT-7
008455*            MOVE EDIT-7               TO MIR-QTYYTD
010418*            MOVE L0280-OUTPUT         TO L0290-INPUT-NUMBER
010418*            MOVE +2                   TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-QTYYTD TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                      TO TRUE
010418*            SET  L0290-SIGN-DISPLAY   TO TRUE
010418*            SET  L0290-SIGN-FLOAT     TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA    TO MIR-QTYYTD
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-QTYYTD-A
010418*            MOVE -1                 TO MIR-QTYYTD-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810081'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM 0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-MKTCMO
      *********************

010418*    IF  MIR-MKTCMO  = SPACES
008455*        MOVE RAB-MKT-BON-CMO-AMT    TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-MKTCMO
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-MKT-BON-CMO-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-MKTCMO   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                    TO TRUE
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-MKTCMO
010418*    ELSE
010418*        IF MIR-MKTCMO  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-MKTCMO
010418*            MOVE ZEROS              TO MIR-MKTCMO
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-MKTCMO   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-MKTCMO             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-MKT-BON-CMO-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-MKT-BON-CMO-AMT TO EDIT-7
008455*            MOVE EDIT-7              TO MIR-MKTCMO
010418*            MOVE L0280-OUTPUT         TO L0290-INPUT-NUMBER
010418*            MOVE +2                   TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-MKTCMO TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                      TO TRUE
010418*            SET  L0290-SIGN-DISPLAY   TO TRUE
010418*            SET  L0290-SIGN-FLOAT     TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA    TO MIR-MKTCMO
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-MKTCMO-A
010418*            MOVE -1                 TO MIR-MKTCMO-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810082'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-MKTYTD
      *********************

010418*    IF  MIR-MKTYTD  = SPACES
008455*        MOVE RAB-MKT-BON-YTD-AMT    TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-MKTYTD
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-MKT-BON-YTD-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-MKTYTD   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                    TO TRUE
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-MKTYTD
010418*    ELSE
010418*        IF MIR-MKTYTD  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-MKTYTD
010418*            MOVE ZEROS              TO MIR-MKTYTD
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-MKTYTD   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-MKTYTD             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-MKT-BON-YTD-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-MKT-BON-YTD-AMT TO EDIT-7
008455*            MOVE EDIT-7              TO MIR-MKTYTD
010418*            MOVE L0280-OUTPUT         TO L0290-INPUT-NUMBER
010418*            MOVE +2                   TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-MKTYTD TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                      TO TRUE
010418*            SET  L0290-SIGN-DISPLAY   TO TRUE
010418*            SET  L0290-SIGN-FLOAT     TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA    TO MIR-MKTYTD
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-MKTYTD-A
010418*            MOVE -1                 TO MIR-MKTYTD-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810083'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-NHCMO
      *********************

010418*    IF  MIR-NHCMO   = SPACES
008455*        MOVE RAB-NHS-ALLOW-CMO-AMT  TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-NHCMO
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-NHS-ALLOW-CMO-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-NHCMO    TO L0290-MAX-OUT-LEN
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                    TO TRUE
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-NHCMO
010418*    ELSE
010418*        IF MIR-NHCMO   = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-NHCMO
010418*            MOVE ZEROS              TO MIR-NHCMO
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-NHCMO    TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-NHCMO              TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-NHS-ALLOW-CMO-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-NHS-ALLOW-CMO-AMT TO EDIT-7
008455*            MOVE EDIT-7                TO MIR-NHCMO
010418*            MOVE L0280-OUTPUT         TO L0290-INPUT-NUMBER
010418*            MOVE +2                   TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-NHCMO  TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                      TO TRUE
010418*            SET  L0290-SIGN-DISPLAY   TO TRUE
010418*            SET  L0290-SIGN-FLOAT     TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA    TO MIR-NHCMO
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-NHCMO-A
010418*            MOVE -1                 TO MIR-NHCMO-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810084'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM 0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-NHYTD
      *********************

010418*    IF  MIR-NHYTD   = SPACES
008455*        MOVE RAB-NHS-ALLOW-YTD-AMT  TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-NHYTD
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-NHS-ALLOW-YTD-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-NHYTD    TO L0290-MAX-OUT-LEN
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                    TO TRUE
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-NHYTD
010418*    ELSE
010418*        IF MIR-NHYTD   = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-NHYTD
010418*            MOVE ZEROS              TO MIR-NHYTD
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-NHYTD    TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-NHYTD              TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-NHS-ALLOW-YTD-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-NHS-ALLOW-YTD-AMT TO EDIT-7
008455*            MOVE EDIT-7                TO MIR-NHYTD
010418*            MOVE L0280-OUTPUT          TO L0290-INPUT-NUMBER
010418*            MOVE +2                    TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-NHYTD   TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                       TO TRUE
010418*            SET  L0290-SIGN-DISPLAY    TO TRUE
010418*            SET  L0290-SIGN-FLOAT      TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA     TO MIR-NHYTD
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-NHYTD-A
010418*            MOVE -1                 TO MIR-NHYTD-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810085'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM 0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-PRWCMO
      *********************

010418*    IF  MIR-PRWCMO  = SPACES
008455*        MOVE RAB-AGT-PWRIT-PMO-AMT  TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-PRWCMO
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PWRIT-PMO-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-PRWCMO   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                    TO TRUE
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-PRWCMO
010418*    ELSE
010418*        IF MIR-PRWCMO  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-PRWCMO
010418*            MOVE ZEROS              TO MIR-PRWCMO
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-PRWCMO   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-PRWCMO             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-AGT-PWRIT-PMO-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-AGT-PWRIT-PMO-AMT TO EDIT-7
008455*            MOVE EDIT-7                TO MIR-PRWCMO
010418*            MOVE L0280-OUTPUT          TO L0290-INPUT-NUMBER
010418*            MOVE +2                    TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-PRWCMO  TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                       TO TRUE
010418*            SET  L0290-SIGN-DISPLAY    TO TRUE
010418*            SET  L0290-SIGN-FLOAT      TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA     TO MIR-PRWCMO
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-PRWCMO-A
010418*            MOVE -1                 TO MIR-PRWCMO-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810086'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-PRWYTD
      *********************

010418*    IF  MIR-PRWYTD  = SPACES
008455*        MOVE RAB-AGT-PWRIT-YTM-AMT  TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-PRWYTD
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PWRIT-YTM-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-PRWYTD   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                    TO TRUE
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-PRWYTD
010418*    ELSE
010418*        IF MIR-PRWYTD  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-PRWYTD
010418*            MOVE ZEROS              TO MIR-PRWYTD
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-PRWYTD   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-PRWYTD             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-AGT-PWRIT-YTM-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-AGT-PWRIT-YTM-AMT TO EDIT-7
008455*            MOVE EDIT-7                TO MIR-PRWYTD
010418*            MOVE L0280-OUTPUT          TO L0290-INPUT-NUMBER
010418*            MOVE +2                    TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-PRWYTD  TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                       TO TRUE
010418*            SET  L0290-SIGN-DISPLAY    TO TRUE
010418*            SET  L0290-SIGN-FLOAT      TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA     TO MIR-PRWYTD
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-PRWYTD-A
010418*            MOVE -1                 TO MIR-PRWYTD-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810087'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-LPRCMO
      *********************

010418*    IF  MIR-LPRCMO  = SPACES
008455*        MOVE RAB-LIFE-PWRIT-PMO-AMT TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-LPRCMO
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-LIFE-PWRIT-PMO-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-LPRCMO   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                    TO TRUE
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-LPRCMO
010418*    ELSE
010418*        IF MIR-LPRCMO  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-LPRCMO
010418*            MOVE ZEROS              TO MIR-LPRCMO
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-LPRCMO   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-LPRCMO             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-LIFE-PWRIT-PMO-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-LIFE-PWRIT-PMO-AMT TO EDIT-7
008455*            MOVE EDIT-7                 TO MIR-LPRCMO
010418*            MOVE L0280-OUTPUT          TO L0290-INPUT-NUMBER
010418*            MOVE +2                    TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-LPRCMO  TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                       TO TRUE
010418*            SET  L0290-SIGN-DISPLAY    TO TRUE
010418*            SET  L0290-SIGN-FLOAT      TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA     TO MIR-LPRCMO
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-LPRCMO-A
010418*            MOVE -1                 TO MIR-LPRCMO-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810088'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-LPRYTD
      *********************

010418*    IF  MIR-LPRYTD  = SPACES
008455*        MOVE RAB-LIFE-PWRIT-YTM-AMT TO EDIT-7
008455*        MOVE EDIT-7                 TO MIR-LPRYTD
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-LIFE-PWRIT-YTM-AMT * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-LPRYTD   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                    TO TRUE
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        SET  L0290-SIGN-FLOAT       TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-LPRYTD
010418*    ELSE
010418*        IF MIR-LPRYTD  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-7
008455*            MOVE EDIT-7             TO MIR-LPRYTD
010418*            MOVE ZEROS              TO MIR-LPRYTD
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 7                      TO L0280-LENGTH
008455*        MOVE 11                     TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-LPRYTD   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-LPRYTD             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-LIFE-PWRIT-YTM-AMT
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-LIFE-PWRIT-YTM-AMT TO EDIT-7
008455*            MOVE EDIT-7                 TO MIR-LPRYTD
010418*            MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER
010418*            MOVE +2                     TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-LPRYTD   TO L0290-MAX-OUT-LEN
010418*            SET  L0290-LEAD-ZEROS-SUPPRESS
010418*                                        TO TRUE
010418*            SET  L0290-SIGN-DISPLAY     TO TRUE
010418*            SET  L0290-SIGN-FLOAT       TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA      TO MIR-LPRYTD
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-LPRYTD-A
010418*            MOVE -1                 TO MIR-LPRYTD-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810089'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-APPCMO
      *********************

010418*    IF  MIR-APPCMO  = SPACES
008455*        MOVE RAB-AGT-APP-PMO-QTY    TO EDIT-4S
008455*        MOVE EDIT-4S                TO MIR-APPCMO
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-AGT-APP-PMO-QTY * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-APPCMO   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-APPCMO
010418*    ELSE
010418*        IF MIR-APPCMO  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-4S
008455*            MOVE EDIT-4S            TO MIR-APPCMO
010418*            MOVE ZEROS              TO MIR-APPCMO
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 5                      TO L0280-LENGTH
008455*        MOVE 8                      TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-APPCMO   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-APPCMO             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-AGT-APP-PMO-QTY
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-AGT-APP-PMO-QTY TO EDIT-4S
008455*            MOVE EDIT-4S             TO MIR-APPCMO
010418*            MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER
010418*            MOVE +2                     TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-APPCMO   TO L0290-MAX-OUT-LEN
010418*            SET  L0290-SIGN-DISPLAY     TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA      TO MIR-APPCMO
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-APPCMO-A
010418*            MOVE -1                 TO MIR-APPCMO-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810090'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

      *********************
      ***   EDIT MIR-APPYTD
      *********************

010418*    IF  MIR-APPYTD  = SPACES
008455*        MOVE RAB-AGT-APP-YTM-QTY    TO EDIT-4S
008455*        MOVE EDIT-4S                TO MIR-APPYTD
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-AGT-APP-YTM-QTY * 100
010418*        MOVE +2                     TO L0290-PRECISION
010418*        MOVE LENGTH OF MIR-APPYTD   TO L0290-MAX-OUT-LEN
010418*        SET  L0290-SIGN-DISPLAY     TO TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA      TO MIR-APPYTD
010418*    ELSE
010418*        IF MIR-APPYTD  = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO EDIT-4S
008455*            MOVE EDIT-4S            TO MIR-APPYTD
010418*            MOVE ZEROS              TO MIR-APPYTD
010418*        END-IF
010418*        MOVE 'Y'                    TO L0280-SIGN-IND
010418*        MOVE 2                      TO L0280-PRECISION
008455*        MOVE 5                      TO L0280-LENGTH
008455*        MOVE 8                      TO L0280-INPUT-SIZE
010418*        MOVE LENGTH OF MIR-APPYTD   TO L0280-INPUT-SIZE
010418*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4
010418*        MOVE MIR-APPYTD             TO L0280-INPUT-DATA
010418*        PERFORM  0280-1000-NUMERIC-EDIT
010418*            THRU 0280-1000-NUMERIC-EDIT-X
010418*        IF  L0280-OK
010418*            COMPUTE RAB-AGT-APP-YTM-QTY
010418*                              = L0280-OUTPUT-DOLLAR
008455*            MOVE RAB-AGT-APP-YTM-QTY TO EDIT-4S
008455*            MOVE EDIT-4S             TO MIR-APPYTD
010418*            MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER
010418*            MOVE +2                     TO L0290-PRECISION
010418*            MOVE LENGTH OF MIR-APPYTD   TO L0290-MAX-OUT-LEN
010418*            SET  L0290-SIGN-DISPLAY     TO TRUE
010418*            PERFORM 0290-1000-NUMERIC-FORMAT
010418*               THRU 0290-1000-NUMERIC-FORMAT-X
010418*            MOVE L0290-OUTPUT-DATA      TO MIR-APPYTD
010418*        ELSE
010418*            MOVE  'Y'               TO WS-ERROR-SW
010418*            MOVE TATRB-DATA-ERROR   TO MIR-APPYTD-A
010418*            MOVE -1                 TO MIR-APPYTD-L
010418*            MOVE 'P'                TO LTPI-CURSOR-POS-IND
010418*            MOVE 'CS00810091'       TO WGLOB-MSG-REF-INFO
010418*            PERFORM  0260-1000-GENERATE-MESSAGE
010418*                THRU 0260-1000-GENERATE-MESSAGE-X
010418*        END-IF
010418*    END-IF.

010418*8600-EDIT-SCR-06-X.
010418*    EXIT.
      ***************************************************
      ** NEW PARAGRAPH TO MOVE THE FIELDS TO THE SCREENS
      ***************************************************
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------
      * SCREEN 01

           PERFORM  3200-GET-AGENT-NAME
              THRU 3200-GET-AGENT-NAME-X.

557667*    MOVE RAG-RES-ADDR-CLI-ID         TO  MIR-CLI-ID.
557667     MOVE WS-RES-CLI-ID         TO  MIR-CLI-ID.

557668*    MOVE L2435-CLI-NM-COMPRESSED     TO  MIR-DV-AGT-CLI-NM.
557668     MOVE L0620-SCREEN-NAME     TO  MIR-DV-AGT-CLI-NM.
           MOVE RAG-BR-ID             TO  MIR-BR-ID.
557667*    MOVE RAG-RES-CLI-ADDR-ID         TO  MIR-ADDR-TYP-CD.
557667     MOVE WS-RES-ADDR-TYP-CD    TO  MIR-ADDR-TYP-CD.
557667*    MOVE RAG-MAIL-ADDR-CLI-ID        TO  MIR-CLI-ID.
557667     MOVE WS-MAIL-CLI-ID        TO  MIR-DV-AGT-MAIL-CLI-ID.
557667*    MOVE RAG-MAIL-CLI-ADDR-ID        TO  MIR-MADTY.
557667     MOVE WS-MAIL-ADDR-TYP-CD   TO  MIR-DV-AGT-MAIL-TYP-CD.
           MOVE RAG-AGT-PHON-NUM      TO  MIR-AGT-PHON-NUM.
           MOVE RAG-BR-ID             TO  MIR-BR-ID.
           MOVE RAG-AGT-CMPNST-CRCY-CD  TO  MIR-AGT-CMPNST-CRCY-CD.
           MOVE RAG-AGT-CNTRCT-STRT-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO  MIR-AGT-CNTRCT-STRT-DT.
           MOVE RAG-OVRID-BASE-AGT-ID TO  MIR-OVRID-BASE-AGT-ID.
557659*    MOVE RAG-CNTRCT-TRMN-DT-TXT      TO  MIR-AGT-CNTRCT-TRMN-DT.
557659     MOVE RAG-AGT-CNTRCT-TRMN-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
557659     MOVE L1640-EXTERNAL-DATE   TO  MIR-AGT-CNTRCT-TRMN-DT.
           MOVE RAG-OVRID-ID          TO  MIR-OVRID-ID.
           MOVE RAG-FYR-COMM-CALC-CD  TO  MIR-FYR-COMM-CALC-CD.
           MOVE RAG-PARTL-ADV-COMM-CD TO  MIR-PARTL-ADV-COMM-CD.
           MOVE RAG-RENW-COMM-CALC-CD TO  MIR-RENW-COMM-CALC-CD.
008455*    MOVE RAG-PARTL-ADV-COMM-AMT      TO  EDIT-4.
008455*    MOVE EDIT-4                      TO  MIR-PARTL-ADV-COMM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAG-PARTL-ADV-COMM-AMT * 100.
020874     MOVE RAG-PARTL-ADV-COMM-AMT TO L0290-INPUT-V02.
008455     MOVE +2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PARTL-ADV-COMM-AMT
                                      TO  L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO  MIR-PARTL-ADV-COMM-AMT.
           MOVE RAG-AGT-SERV-FEE-IND  TO  MIR-AGT-SERV-FEE-IND.
           MOVE RAG-SERV-COMM-RTBL2-ID    TO  MIR-SERV-COMM-RTBL2-ID.
           MOVE RAG-AUTO-COMM-PMT-CD  TO  MIR-AUTO-COMM-PMT-CD.
557659*    MOVE RAG-AGT-CCAS-QUALF-CD       TO  MIR-AGT-CCAS-QUALF-IND.
557659     MOVE RAG-AGT-CCAS-QUALF-IND       TO  MIR-AGT-CCAS-QUALF-IND.
557670     MOVE RAG-AGT-PMT-MTHD-CD   TO  MIR-AGT-PMT-MTHD-CD.
020874*    MOVE WS-RES-BNK-ACCT-NUM   TO  EDIT-8.
020874*    MOVE EDIT-8                TO  MIR-BNK-ACCT-NUM.
020874     MOVE WS-RES-BNK-ACCT-NUM   TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-BNK-ACCT-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-BNK-ACCT-NUM.
           MOVE RAG-AGT-LOC-LIC-CD    TO  MIR-AGT-LOC-LIC-CD.
           MOVE RAG-AGT-CLAS-LIC-CD   TO  MIR-AGT-CLAS-LIC-CD.
      * SCREEN 02
           MOVE RAG-AGT-STAT-CD       TO  MIR-AGT-STAT-CD.
557659*    MOVE RAG-PREV-AGT-BR-ID          TO  MIR-PREV.
557659     MOVE RAG-PREV-AGT-ID       TO  MIR-PREV-AGT-ID.
557659     MOVE RAG-PREV-BR-ID        TO  MIR-PREV-BR-ID.
           MOVE RAG-AGT-TYP-CD        TO  MIR-AGT-TYP-CD.
           MOVE RAG-AGT-SPNSR-LIC-IND TO  MIR-AGT-SPNSR-LIC-IND.
           MOVE RAG-AGT-CMPNST-SCHD-CD       TO  MIR-AGT-CMPNST-SCHD-CD.
           MOVE RAG-AGT-PRIM-LIC-ID   TO  MIR-AGT-PRIM-LIC-ID.
           MOVE RAG-NMED-UWG-PRVLG-IND       TO  MIR-NMED-UWG-PRVLG-IND.
019524*    MOVE RAG-AGT-COMM-WTHLD-PCT-N
019524*                               TO  MIR-AGT-COMM-WTHLD-PCT.
019524     MOVE RAG-AGT-COMM-WTHLD-PCT  TO L0290-INPUT-V00.
019524     MOVE ZERO                    TO L0290-PRECISION.
019524     MOVE LENGTH OF MIR-AGT-COMM-WTHLD-PCT
019524                                TO  L0290-MAX-OUT-LEN.
019524     PERFORM 0290-2000-FORMAT-FOR-MIR
019524        THRU 0290-2000-FORMAT-FOR-MIR-X.
019524     MOVE L0290-OUTPUT-DATA     TO  MIR-AGT-COMM-WTHLD-PCT.
           MOVE RAG-AGT-BROK-OVRID-IND       TO  MIR-AGT-BROK-OVRID-IND.
557973*    MOVE RAG-DEV-PGM-INCM-AMT-N      TO  MIR-DEV-PGM-INCM-AMT.
008455*    MOVE RAG-DEV-PGM-INCM-AMT        TO  EDIT-6.
008455*    MOVE EDIT-6                      TO  MIR-DEV-PGM-INCM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAG-DEV-PGM-INCM-AMT.
020874     MOVE RAG-DEV-PGM-INCM-AMT  TO  L0290-INPUT-V00.
008455     MOVE +0                    TO  L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DEV-PGM-INCM-AMT
                                      TO  L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO  MIR-DEV-PGM-INCM-AMT.
           MOVE RAG-AGT-FRNG-BNFT-IND TO  MIR-AGT-FRNG-BNFT-IND.
008455*    MOVE RAG-AGT-VEST-INT-AMT        TO  EDIT-1.
008455*    MOVE EDIT-1                      TO  MIR-AGT-VEST-INT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RAG-AGT-VEST-INT-AMT * 100.
020874     MOVE RAG-AGT-VEST-INT-AMT  TO  L0290-INPUT-V02.
008455     MOVE +2                    TO  L0290-PRECISION.
008455     MOVE LENGTH OF MIR-AGT-VEST-INT-AMT
                                      TO  L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS   TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO  MIR-AGT-VEST-INT-AMT.
           MOVE RAG-QLTY-BON-PGM-IND  TO  MIR-QLTY-BON-PGM-IND.
           MOVE RAG-NHS-CMPNST-PGM-IND       TO  MIR-NHS-CMPNST-PGM-IND.
           MOVE RAG-MKT-BON-PGM-IND   TO  MIR-MKT-BON-PGM-IND.
           MOVE RAG-AGT-OTHR-CMPNST-CD       TO  MIR-AGT-OTHR-CMPNST-CD.
           MOVE RAG-AGT-FIN-ARANG-IND TO  MIR-AGT-FIN-ARANG-IND.
012148     MOVE RAG-AGT-TRAIL-COMM-IND       TO  MIR-AGT-TRAIL-COMM-IND.
      * SCREEN 03
008455*    MOVE RAB-FYR-COMM-CMO-AMT        TO  EDIT-7.
008455*    MOVE EDIT-7                      TO  MIR-FYRCMO.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-FYR-COMM-CMO-AMT * 100.
010418*    MOVE +2                          TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-FYRCMO        TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY          TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT            TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS   TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA           TO  MIR-FYRCMO.
008455*    MOVE RAB-FYR-COMM-YTD-AMT        TO  EDIT-7.
008455*    MOVE EDIT-7                      TO  MIR-FYRYTD.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-FYR-COMM-YTD-AMT * 100.
010418*    MOVE +2                          TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-FYRYTD        TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY          TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT            TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS   TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA           TO  MIR-FYRYTD.
008455*    MOVE RAB-RENW-COMM-CMO-AMT       TO  EDIT-7.
008455*    MOVE EDIT-7                      TO  MIR-RYRCMO.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-RENW-COMM-CMO-AMT * 100.
010418*    MOVE +2                          TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-RYRCMO        TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY          TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT            TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS   TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA           TO  MIR-RYRCMO.
008455*    MOVE RAB-RENW-COMM-YTD-AMT       TO  EDIT-7.
008455*    MOVE EDIT-7                      TO  MIR-RYRYTD.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-RENW-COMM-YTD-AMT * 100.
010418*    MOVE +2                          TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-RYRYTD        TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY          TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT            TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS   TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA           TO  MIR-RYRYTD.
008455*    MOVE RAB-OVRID-COMM-CMO-AMT      TO  EDIT-7.
008455*    MOVE EDIT-7                      TO  MIR-BONCMO.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-OVRID-COMM-CMO-AMT * 100.
010418*    MOVE +2                          TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-BONCMO        TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY          TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT            TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS   TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA           TO  MIR-BONCMO.
008455*    MOVE RAB-OVRID-COMM-YTD-AMT      TO  EDIT-7.
008455*    MOVE EDIT-7                      TO  MIR-BONYTD.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-OVRID-COMM-YTD-AMT * 100.
010418*    MOVE +2                          TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-BONYTD        TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY          TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT            TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS   TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA           TO  MIR-BONYTD.
008455*    MOVE RAB-AGT-PAYO-CMO-AMT        TO  EDIT-7.
008455*    MOVE EDIT-7                      TO  MIR-PAYCMO.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PAYO-CMO-AMT * 100.
010418*    MOVE +2                          TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-PAYCMO        TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY          TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT            TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS   TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA           TO  MIR-PAYCMO.
008455*    MOVE RAB-AGT-PAYO-YTD-AMT        TO  EDIT-7.
008455*    MOVE EDIT-7                      TO  MIR-PAYYTD.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PAYO-YTD-AMT * 100.
010418*    MOVE +2                          TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-PAYYTD        TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY          TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT            TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS   TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA           TO  MIR-PAYYTD.
008455*    MOVE RAB-AGT-PAYBL-BAL-AMT       TO  EDIT-7.
008455*    MOVE EDIT-7                      TO  MIR-CURBAL.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PAYBL-BAL-AMT * 100.
010418*    MOVE +2                          TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-CURBAL        TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY          TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT            TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS   TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA           TO  MIR-CURBAL.

010418*    MOVE RAB-XFER-SERV-AGT-ID        TO  MIR-XFER-SERV-AGT-ID.
010418     MOVE RAG-XFER-SERV-AGT-ID  TO  MIR-XFER-SERV-AGT-ID.
010418*    MOVE RAB-XFER-SERV-AGT-ID        TO  WAG-AGT-ID.
030652*    MOVE RAG-XFER-SERV-AGT-ID  TO  WAG-AGT-ID.
010418     MOVE RAG-SERV-AGT-XFER-DT  TO  L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
010418     MOVE L1640-EXTERNAL-DATE   TO  MIR-SERV-AGT-XFER-DT.
030652*    PERFORM  3300-GET-TRANS-AGENT-NAME
030652*        THRU 3300-GET-TRANS-AGENT-NAME-X.
030652*    MOVE WS-COMPRESSED-NAME    TO  MIR-DV-SERV-AGT-CLI-NM.
010418*    MOVE RAB-SERV-AGT-XFER-DT        TO  L1640-INTERNAL-DATE.
010418*    PERFORM  1640-2000-INTERNAL-TO-EXT
010418*        THRU 1640-2000-INTERNAL-TO-EXT-X.
010418*    MOVE L1640-EXTERNAL-DATE         TO  MIR-SERV-AGT-XFER-DT.

010418*    MOVE RAB-XFER-WRIT-AGT-ID        TO  MIR-XFER-WRIT-AGT-ID.
010418     MOVE RAG-XFER-WRIT-AGT-ID  TO  MIR-XFER-WRIT-AGT-ID.
010418*    MOVE RAB-XFER-WRIT-AGT-ID        TO  WAG-AGT-ID.
030652*    MOVE RAG-XFER-WRIT-AGT-ID  TO  WAG-AGT-ID.
010418     MOVE RAG-WRIT-AGT-XFER-DT  TO  L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
010418     MOVE L1640-EXTERNAL-DATE   TO  MIR-WRIT-AGT-XFER-DT.
030652*    PERFORM  3300-GET-TRANS-AGENT-NAME
030652*        THRU 3300-GET-TRANS-AGENT-NAME-X.
030652*    MOVE WS-COMPRESSED-NAME    TO  MIR-DV-WRIT-AGT-NM.
010418*    MOVE RAB-WRIT-AGT-XFER-DT        TO  L1640-INTERNAL-DATE.
010418*    PERFORM  1640-2000-INTERNAL-TO-EXT
010418*        THRU 1640-2000-INTERNAL-TO-EXT-X.
010418*    MOVE L1640-EXTERNAL-DATE         TO  MIR-WRIT-AGT-XFER-DT.

010418*    MOVE RAB-XFER-COMM-AGT-ID        TO  MIR-XFER-COMM-AGT-ID.
010418     MOVE RAG-XFER-COMM-AGT-ID  TO  MIR-XFER-COMM-AGT-ID.
010418*    MOVE RAB-XFER-COMM-AGT-ID        TO  WAG-AGT-ID.
010418     MOVE RAG-XFER-COMM-AGT-ID  TO  WAG-AGT-ID.
010418     MOVE RAG-COMM-AGT-XFER-DT  TO  L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
010418     MOVE L1640-EXTERNAL-DATE   TO  MIR-COMM-AGT-XFER-DT.
           PERFORM  3300-GET-TRANS-AGENT-NAME
               THRU 3300-GET-TRANS-AGENT-NAME-X.
           MOVE WS-COMPRESSED-NAME    TO  MIR-DV-COMM-AGT-NM.
030652     MOVE MIR-XFER-SERV-AGT-ID  TO  WAG-AGT-ID.
030652     PERFORM  3300-GET-TRANS-AGENT-NAME
030652         THRU 3300-GET-TRANS-AGENT-NAME-X.
030652     MOVE WS-COMPRESSED-NAME    TO  MIR-DV-SERV-AGT-CLI-NM.
030652     MOVE MIR-XFER-WRIT-AGT-ID  TO  WAG-AGT-ID.
030652     PERFORM  3300-GET-TRANS-AGENT-NAME
030652         THRU 3300-GET-TRANS-AGENT-NAME-X.
030652     MOVE WS-COMPRESSED-NAME    TO  MIR-DV-WRIT-AGT-NM.

010418*    MOVE RAB-COMM-AGT-XFER-DT        TO  L1640-INTERNAL-DATE.
010418*    PERFORM  1640-2000-INTERNAL-TO-EXT
010418*        THRU 1640-2000-INTERNAL-TO-EXT-X.
010418*    MOVE L1640-EXTERNAL-DATE         TO  MIR-COMM-AGT-XFER-DT.
      * SCREEN 04
010418*    PERFORM VARYING WS-SUB FROM 1 BY 1
010418*        UNTIL WS-SUB > WS-MAX-BROWSE-LINES
008455*        MOVE RAB-FYR-COMM-AMT (WS-SUB) TO  EDIT-7
008455*        MOVE EDIT-7                    TO  MIR-FAMT-T (WS-SUB)
010418*        COMPUTE L0290-INPUT-NUMBER
010418*              = RAB-FYR-COMM-AMT (WS-SUB) * 100
010418*        MOVE +2                        TO  L0290-PRECISION
010418*        MOVE LENGTH OF MIR-FAMT-T (WS-SUB) TO  L0290-MAX-OUT-LEN
010418*        SET  L0290-SIGN-DISPLAY        TO  TRUE
010418*        SET  L0290-SIGN-FLOAT          TO  TRUE
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA         TO  MIR-FAMT-T (WS-SUB)
008455*        MOVE RAB-RENW-COMM-AMT (WS-SUB) TO EDIT-7
008455*        MOVE EDIT-7                    TO  MIR-RAMT-T (WS-SUB)
010418*        COMPUTE L0290-INPUT-NUMBER
010418*              = RAB-RENW-COMM-AMT (WS-SUB) * 100
010418*        MOVE +2                        TO  L0290-PRECISION
010418*        MOVE LENGTH OF MIR-RAMT-T (WS-SUB) TO  L0290-MAX-OUT-LEN
010418*        SET  L0290-SIGN-DISPLAY        TO  TRUE
010418*        SET  L0290-SIGN-FLOAT          TO  TRUE
010418*        SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA         TO  MIR-RAMT-T (WS-SUB)
010418*    END-PERFORM.
      * SCREEN 05
010418*    PERFORM VARYING WS-SUB FROM 1 BY 1
010418*        UNTIL WS-SUB > 4
010418*        MOVE RAB-AGT-PRST-PCT (WS-SUB) TO  EDIT-2
010418*        MOVE EDIT-2                    TO  MIR-PRST-T (WS-SUB)
008455*        MOVE RAB-AGT-PROD-AMT (WS-SUB) TO  EDIT-3D
008455*        MOVE EDIT-3D                   TO  MIR-PRDL-T (WS-SUB)
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PROD-AMT (WS-SUB)
010418*        MOVE +0                        TO  L0290-PRECISION
010418*        MOVE LENGTH OF MIR-PRDL-T (WS-SUB) TO  L0290-MAX-OUT-LEN
010418*        SET  L0290-SIGN-DISPLAY        TO  TRUE
010418*        SET  L0290-SIGN-POS-DISPLAY    TO  TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA         TO  MIR-PRDL-T (WS-SUB)
008455*        MOVE RAB-AGT-MDRT-AMT (WS-SUB) TO  EDIT-3D
008455*        MOVE EDIT-3D                   TO  MIR-MDRT-T (WS-SUB)
010418*        COMPUTE L0290-INPUT-NUMBER = RAB-AGT-MDRT-AMT (WS-SUB)
010418*        MOVE +0                        TO  L0290-PRECISION
010418*        MOVE LENGTH OF MIR-MDRT-T (WS-SUB) TO  L0290-MAX-OUT-LEN
010418*        SET  L0290-SIGN-DISPLAY        TO  TRUE
010418*        SET  L0290-SIGN-POS-DISPLAY    TO  TRUE
010418*        PERFORM 0290-1000-NUMERIC-FORMAT
010418*           THRU 0290-1000-NUMERIC-FORMAT-X
010418*        MOVE L0290-OUTPUT-DATA         TO  MIR-MDRT-T (WS-SUB)
010418*        MOVE RAB-CNVTN-ATND-IND (WS-SUB)
010418*                                       TO  MIR-CONV-T (WS-SUB)
010418*        MOVE RAB-APTVTY-AWD-IND (WS-SUB)
010418*                                       TO  MIR-APPA-T (WS-SUB)
010418*        MOVE RAB-NQA-IND      (WS-SUB) TO  MIR-NQA-T  (WS-SUB)
010418*    END-PERFORM.
      * SCREEN 06
008455*    MOVE RAB-FYR-CPREM-CMO-AMT     TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-FPRCMO.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-FYR-CPREM-CMO-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-FPRCMO      TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-FPRCMO.
008455*    MOVE RAB-FYR-CPREM-YTD-AMT     TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-FPRYTD.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-FYR-CPREM-YTD-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-FPRYTD      TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-FPRYTD.
008455*    MOVE RAB-FYR-LCOMM-CMO-AMT     TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-FCMCMO.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-FYR-LCOMM-CMO-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-FCMCMO      TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-FCMCMO.
008455*    MOVE RAB-FYR-LCOMM-YTD-AMT     TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-FCMYTD.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-FYR-LCOMM-YTD-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-FCMYTD      TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-FCMYTD.
008455*    MOVE RAB-RENW-CPREM-CMO-AMT    TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-RPRCMO.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-RENW-CPREM-CMO-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-RPRCMO      TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-RPRCMO.
008455*    MOVE RAB-RENW-CPREM-YTD-AMT    TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-RPRYTD.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-RENW-CPREM-YTD-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-RPRYTD      TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-RPRYTD.
008455*    MOVE RAB-RENW-LCOMM-CMO-AMT    TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-RCMCMO.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-RENW-LCOMM-CMO-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-RCMCMO      TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-RCMCMO.
008455*    MOVE RAB-RENW-LCOMM-YTD-AMT    TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-RCMYTD.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-RENW-LCOMM-YTD-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-RCMYTD      TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-RCMYTD.
008455*    MOVE RAB-QLTY-BON-CMO-AMT      TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-QTYCMO.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-QLTY-BON-CMO-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-QTYCMO      TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-QTYCMO.
008455*    MOVE RAB-QLTY-BON-YTD-AMT      TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-QTYYTD.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-QLTY-BON-YTD-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-QTYYTD      TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-QTYYTD.
008455*    MOVE RAB-MKT-BON-CMO-AMT       TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-MKTCMO.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-MKT-BON-CMO-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-MKTCMO      TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-MKTCMO.
008455*    MOVE RAB-MKT-BON-YTD-AMT       TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-MKTYTD.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-MKT-BON-YTD-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-MKTYTD      TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-MKTYTD.
008455*    MOVE RAB-NHS-ALLOW-CMO-AMT     TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-NHCMO.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-NHS-ALLOW-CMO-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-NHCMO       TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-NHCMO.
008455*    MOVE RAB-NHS-ALLOW-YTD-AMT     TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-NHYTD.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-NHS-ALLOW-YTD-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-NHYTD       TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-NHYTD.
008455*    MOVE RAB-AGT-PWRIT-PMO-AMT     TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-PRWCMO.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PWRIT-PMO-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-PRWCMO      TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-PRWCMO.
008455*    MOVE RAB-AGT-PWRIT-YTM-AMT     TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-PRWYTD.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-AGT-PWRIT-YTM-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-PRWYTD      TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-PRWYTD.
008455*    MOVE RAB-LIFE-PWRIT-PMO-AMT    TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-LPRCMO.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-LIFE-PWRIT-PMO-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-LPRCMO      TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-LPRCMO.
008455*    MOVE RAB-LIFE-PWRIT-YTM-AMT    TO  EDIT-7.
008455*    MOVE EDIT-7                    TO  MIR-LPRYTD.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-LIFE-PWRIT-YTM-AMT * 100.
010418*    MOVE +2                        TO  L0290-PRECISION.
010418*    MOVE LENGTH OF MIR-LPRYTD      TO  L0290-MAX-OUT-LEN.
010418*    SET  L0290-SIGN-DISPLAY        TO  TRUE.
010418*    SET  L0290-SIGN-FLOAT          TO  TRUE.
010418*    SET  L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X.
010418*    MOVE L0290-OUTPUT-DATA         TO  MIR-LPRYTD.
008455*    MOVE RAB-AGT-APP-PMO-QTY       TO  EDIT-4S.
008455*    MOVE EDIT-4S                   TO  MIR-APPCMO.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-AGT-APP-PMO-QTY * 100
010418*    MOVE +2                        TO L0290-PRECISION
010418*    MOVE LENGTH OF MIR-APPCMO      TO L0290-MAX-OUT-LEN
010418*    SET  L0290-SIGN-DISPLAY        TO TRUE
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X
010418*    MOVE L0290-OUTPUT-DATA         TO MIR-APPCMO.
008455*    MOVE RAB-AGT-APP-YTM-QTY       TO  EDIT-4S.
008455*    MOVE EDIT-4S                   TO  MIR-APPYTD.
010418*    COMPUTE L0290-INPUT-NUMBER = RAB-AGT-APP-YTM-QTY * 100
010418*    MOVE +2                        TO L0290-PRECISION
010418*    MOVE LENGTH OF MIR-APPYTD      TO L0290-MAX-OUT-LEN
010418*    SET  L0290-SIGN-DISPLAY        TO TRUE
010418*    PERFORM 0290-1000-NUMERIC-FORMAT
010418*       THRU 0290-1000-NUMERIC-FORMAT-X
010418*    MOVE L0290-OUTPUT-DATA         TO MIR-APPYTD.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0840-0000-INIT-PARM-INFO
025970         THRU 0840-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2440-0000-INIT-PARM-INFO
025970         THRU 2440-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5020-0000-INIT-PARM-INFO
025970         THRU 5020-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WS-EDIT-CHECKS.
025970     INITIALIZE WS-AGNT-CLI-REL-GR.
025970     INITIALIZE OTHER-MISC-WORK-AREAS.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.     
025970     SET WS-TRANS-NAME-DEFAULT        TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT          TO TRUE.
025970     SET WS-MAX-BROWSE-LINES-DEFAULT  TO TRUE.
025970     SET WS-AGENT-RL-NOT-FOUND        TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK                TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
      /
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
025970 COPY CCPS5020.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0280.
008455/
008455 COPY XCPS0290.
008455 COPY XCPL0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY AG
014221                         '$VAR2' BY 'AG'.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
018764*COPY CCCL2440.
020478 COPY CCPS2440.
018764 COPY CCPL2440.
      /
020478 COPY CCPL5020.
020478/
018764*COPY CCCL0840.
018764 COPY CCPL0840.
557667 COPY CCPS0840.
557667/
025970 COPY CCPS0620.
557668 COPY CCPL0620.
557668/
018764*COPY CCCL2435.
018764 COPY CCPL2435.

018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************

010418*COPY CCPAAB.
010418*COPY CCPNAB.
010418*COPY CCPUAB.
010418*COPY CCPCAB.
016537*COPY CCPBAB.
      /
       COPY CCPAAG.
       COPY CCPBAG.
       COPY CCPNAG.
       COPY CCPUAG.
       COPY CCPXAG.
       COPY CCPCAG.
      /
028786 COPY CCPBAGRC.
028786/
028786 COPY CCPBAGRP.
028786/
       COPY CCPNAS.
      /
       COPY CCPNCC.
008455/
008455 COPY XCPNCRCY.
      /
028786*COPY CCPBRL.
028786*
020478*COPY CCPNCLIN.
557670/
       COPY CCPNEDIT.
       COPY CCPNBRCH.
       COPY CCPEADDR.
016955 COPY CCPEAGSC.
008455*COPY CCPECURR.
      /
       COPY CCPS2435.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM0081                     **
      *****************************************************************


