      *************************
       IDENTIFICATION DIVISION.
      *************************

       COPY XCWWCRHT.

       PROGRAM-ID. NSOM0090.

      *****************************************************************
      **  MEMBER :  NSOM0090                                         **
      **  REMARKS:  REQT - TRACK UNDERWRITING AND ISSUE REQUIREMENTS **
      **            THIS MODULE IS USED TO KEEP TRACK OF             **
      **            UNDERWRITING OR ISSUE REQUIREMENTS WHETHER       **
      **            AUTOMATICALLY GENERATED OR ENTERED BY A USER.    **
      **            ADDITIONAL REQUIREMENTS CAN ALSO BE ADDED AND    **
      **            EXISTING REQUIREMENTS CAN BE UPDATE OR DELETED.  **
      **            FOR LABORATORY REQUIREMENTS THE USER CAN INVOKE  **
      **            A PROCESS WHICH WILL ATTEMPT TO RESOLVE          **
      **            REQUIREMENTS BY DETERMINING IF ALL REQUIRED      **
      **            TESTS HAVE BEEN RECEIVED WITH NORMAL RESULTS.    **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557658**  5.5       YEAR 2000                                        **
557659**  5.5       DATA ARCH. MODIFICATIONS                         **
557668**  5.5       NEW NAME FORMATTING                              **
557698**  5.5       MIXED-CASE SUPPORT                               **
557708**  5.5       CICS ABEND HANDLING                              **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
008445**  5.5.2     GENERATE MIR FROM TECH ARCH DATA BASE            **
008453**  5.5.2     MULTIPLE EXTERNAL DATE FORMATS                   **
010497**  5.5.2     MIXED-CASE SUPPORT FOR OWNER'S NAME              **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       CODE CLEANUP                                     **
010418**  5.6       READ SCOM FOR FINAL DISPOSITION INFO             **
010645**  5.6       VARIATIONS BY LOCATION - UW AND NB               **
011446**  5.6       "SCH-SUGGESTED BY POLICY CHANGE PROCESS"         **
011446**            WAS ADDED AS A VALID SYSTEM REQT STATUS          **
011446**            CODE                                             **
012624**  6.0       POLICY ACCESS VERIFICATION                       **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
016039**  6.1       RESET WORK FIELD FOR LAB CODE CROSS EDIT         **
016062**  6.1       USER-ID FOR RETRIEVE AND MAINTAIN                **
014221**  6.2       LOGICAL LOCKING                                  **
016387**  6.2       REMOVE CLIENT CONSOLIDATION                      **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
016717**  6.2       PCR - REQT UPDATE INCORRECT MESSAGE NS00900057   **
017944**  6.2       PCR - POLICY ANALYSIS FOR REQT 'SCH'             **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
018634**  6.4       ADD CONDITION FOR FOLLOW UP MESSAGE              **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023520**  6.5       ACCOUNT HOLDER NAME SHOULD BE MANDATORY          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
026895**  6.7       UPDATE STATUS EFFECTIVE DATE WHEN STATUS CHANGES **
029083**  6.7       REQUIREMENT FOLLOW-UP DATE RECALCULATION         **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
035393**  7.1       CITS TRANSMITTAL                                 **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0090'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.

           05  WS-EDIT-CHECKS.
               10  WS-BUS-FCN-ID                 PIC X(04).
                   88  WS-BUS-FCN-VALID          VALUE '1190' '1191'
                                                       '1192' '1193'
                                                       '1194'.
                   88  WS-BUS-FCN-RETRIEVE       VALUE '1190'.
                   88  WS-BUS-FCN-CREATE         VALUE '1191'.
                   88  WS-BUS-FCN-UPDATE         VALUE '1192'.
                   88  WS-BUS-FCN-DELETE         VALUE '1193'.
                   88  WS-BUS-FCN-LIST           VALUE '1194'.
025970*        10  WS-TWRK-KEY                   PIC X(04) VALUE '1190'.

               10  WS-EDIT-FOLLOWUP-NO           PIC X(01).
                   88  VALID-FOLLOWUP-NO         VALUE '1' '2' '3'.
               10  WS-YES-NO-VALID-SW            PIC X(01).
                   88  WS-YES-NO-VALID           VALUE 'Y' 'N'.

           05  WS-CONVERTED-KEYS.
               10  WS-POL-OR-CLI-NUMBER.
                   15  WS-POL-OR-CLI-CODE        PIC X(01).
                       88  WS-UW-REQUIREMENT     VALUE 'C'.
                       88  WS-ISSUE-REQUIREMENT  VALUE 'P'.
                   15  WS-POLICY-ID.
                       20  WS-POLICY-NUMBER      PIC X(09).
                       20  WS-POLICY-SUFFIX      PIC X(01).
                   15  WS-CLIENT-ID      REDEFINES WS-POLICY-ID.
                       20  WS-CLIENT-NUMBER      PIC X(10).
               10  WS-INTERNAL-START-DATE        PIC X(10).
008453*        10  WS-EXTERNAL-START-DATE        PIC X(09).
008453         10  WS-EXTERNAL-START-DATE        PIC X(10).
               10  WS-SEQUENCE-NO                PIC 9(03)
                                                 VALUE ZEROES.
               10  WS-SAVE-SEQ-NO                PIC 9(03).

           05  WS-STATUS-FLAGS.
               10  WS-WRITE-REWRITE-IND          PIC X(01).
                   88  WS-WRITE-REQT             VALUE 'W'.
                   88  WS-REWRITE-REQT           VALUE 'R'.
025970*        10  WS-RTAB-READ-IND              PIC X(01) VALUE 'N'.
025970         10  WS-RTAB-READ-IND              PIC X(01).
025970             88  WS-DEFAULT-RTAB-READ-IND  VALUE 'N'.
                   88  WS-RTAB-AVAILABLE         VALUE 'Y'.
025970*        10  WS-CCOMM-UPDATED-SW           PIC X(01) VALUE 'N'.
025970         10  WS-CCOMM-UPDATED-SW           PIC X(01).
025970             88  WS-DEFAULT-COMM-UPDATED-IND
025970                                           VALUE 'N'.
                   88  WS-CCOMM-UPDATED          VALUE 'Y'.

           05  WS-EDIT-FLAGS.
               10  WS-EDIT-STATUS-CODE           PIC X(03).
011446*            88  WS-SYSTEM-STATUS-CODE     VALUE 'SCC' 'SIR'
011446*                'SAA'.
011446*            88  VALID-STATUS-CODE         VALUE 'CAN' 'NTO'
011446*                'ORD' 'RAC' 'RCD' 'RRJ' 'WVD' 'SCC' 'SIR' 'SAA'.
011446             88  WS-SYSTEM-STATUS-CODE     VALUE 'SCC' 'SCH'
011446                 'SIR' 'SAA'.
011446             88  VALID-STATUS-CODE         VALUE 'CAN' 'NTO'
011446                 'ORD' 'RAC' 'RCD' 'RRJ' 'WVD' 'SCC' 'SIR' 'SAA'
011446                 'SCH'.
                   88  WS-RECEIVED-STATUS        VALUE
                       'RAC' 'RCD' 'RRJ'.
                   88  WS-WAIVED-CANCELLED       VALUE
                       'WVD' 'CAN'.
               10  WS-OLD-STATUS-CODE            PIC X(03).
                   88  WS-OLD-OUTSTANDING        VALUE
017944*                'NTO' 'ORD' 'RCD' 'SAA' 'SCC' 'SIR'.
017944                 'NTO' 'ORD' 'RCD' 'SAA' 'SCC' 'SIR' 'SCH'.
               10  WS-NEW-STATUS-CODE-IND        PIC X(01).
                   88  WS-NEW-STATUS-OK          VALUE 'Y'.
               10  WS-TEST-DATE-UPDATE-IND       PIC X(01).
                   88  WS-CALC-VALIDITY-DATE     VALUE 'Y'.
               10  WS-FUP-UPDATE                 PIC X(01).
                   88  WS-CALC-FOLLOW-UP         VALUE 'Y'.
               10  WS-FUP-NUMBER-EDIT-IND        PIC X(01).
                   88  WS-FUP-NUMBER-EDIT-OK     VALUE 'Y'.
               10  WS-VALID-LAB-CODE-IND         PIC X(01).
                   88  WS-VALID-LAB-CODE-FOUND   VALUE 'Y'.
016039             88  WS-VALID-LAB-CODE-NOTFND  VALUE 'N'.
               10  WS-TEMP-DATE                  PIC X(10).

008453*    05  WS-DATES.
008453*        10  WS-EXTERNAL-DATE.
008453*            15  WS-DDMMM                  PIC X(05).
557658*            15  WS-CENTURY                PIC X(02).
557658*            15  WS-YEAR                   PIC X(02).
008453*            15  WS-YEAR                   PIC X(04).
557658*        10  WS-DISPLAY-DATE.
557658*            15  WS-DISP-DDMMM             PIC X(05).
557658*            15  WS-DISP-YEAR              PIC X(02).

           05  WS-SWITCHES.
               10  WS-VALIDATE-FAIL-SW           PIC X(01).
                   88  WS-VALIDATE-FAIL          VALUE 'Y'.
                   88  WS-VALIDATE-OK            VALUE 'N'.
               10  WS-EDITS-OK-SW                PIC X(01).
                   88  WS-ALL-EDITS-OK           VALUE 'Y'.
                   88  WS-EDITS-FAILED           VALUE 'N'.
               10  WS-CROSS-EDITS-OK-SW          PIC X(01).
                   88  WS-CROSS-EDITS-OK         VALUE 'Y'.
                   88  WS-CROSS-EDITS-FAILED     VALUE 'N'.
025970*        10  WS-NEW-RECORD-SW              PIC X(01)
025970*                                          VALUE 'N'.
025970         10  WS-NEW-RECORD-SW              PIC X(01).
025970             88  WS-DEFAULT-NEW-RECORD-SW  VALUE 'N'.
                   88  WS-NEW-RECORD             VALUE 'Y'.
025970*        10  WS-NO-MORE-SEQ-NO-SW          PIC X(01)
025970*                                          VALUE 'N'.
025970         10  WS-NO-MORE-SEQ-NO-SW          PIC X(01).
025970             88  WS-DEFAULT-NO-MORE-SEQ-NO-SW
025970                                           VALUE 'N'.
                   88  NO-MORE-SEQ-NO            VALUE 'Y'.
016548*    05  WS-SUB                            PIC S9(04) COMP.
016548     05  WS-SUB                            PIC S9(04) BINARY.
016548*    05  WS-LINE                           PIC S9(04) COMP.
016548     05  WS-LINE                           PIC S9(04) BINARY.
016548*    05  WS-DEST                           PIC S9(04) COMP.
016548     05  WS-DEST                           PIC S9(04) BINARY.
016548*    05  WS-MAX-LINES                      PIC S9(04) COMP
025970*    05  WS-MAX-LINES                      PIC S9(04) BINARY
025970*                                          VALUE +11.
           05  WS-LANG-USED                      PIC 9(01).
           05  PASS-COMPANY-CODE                 PIC X(02).
           05  WS-PIC-ZZ9                        PIC ZZ9.
           05  WS-PIC-Z                          PIC Z.
           05  WS-POLID.
               10  WS-POLNO                      PIC X(09).
               10  WS-POLSF                      PIC X(01).
           05  WS-SAVE-REQT-STATUS               PIC X(03).
035393     05  WS-INDEX                          PIC S9(05) COMP-3.
025970/
025970 01 WS-CONSTANTS.
025970    05  WS-TWRK-KEY                        PIC X(04).
025970        88  WS-DEFAULT-TWRK-KEY            VALUE '1190'.
025970     05  WS-MAX-LINES                      PIC S9(04) BINARY.
025970         88  WS-DEFAULT-MAX-LINES          VALUE +11.
      /
       COPY CCWWINDX.
       COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      /
       COPY XCWEBLCH.
      /
035393 COPY CCWLCITC.
035393
035393 COPY CCWLCITU.
035393
016503 COPY CCWL0289.
       COPY CCWL0064.
       COPY CCWL2430.
557668 COPY CCWL0620.
028298 COPY CCWL2626.
023520 COPY CCWL5020.
       COPY CCWL5400.
       COPY CCWL5600.

       COPY NCWL0095.
       COPY NCWL0760.
       COPY NCWL1030.
       COPY NCWL1090.
       COPY NCWL2437.
       COPY NCWL7180.

016440 COPY CCWL2222.

       COPY XCWL0220.
       COPY XCWL0280.
020874 COPY XCWL0290.
035393
035393 COPY XCWL0319.
035393
       COPY XCWLDTLK.
       COPY XCWL1640.
       COPY XCWL1670.
       COPY XCWL1680.
014221 COPY XCWL8090.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
010418*COPY CCFWPCOM.
010418*COPY CCFRPCOM.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
016503 COPY CCFWCVG.
016503 COPY CCFRCVG.
016503 COPY CCWWCVGS.
      /
       COPY NCFWRTAB.
       COPY NCFRRTAB.
      /
       COPY NCFWREQT.
       COPY NCFWRQCR.
       COPY NCFRREQT.
      /
016503 COPY CCFRRL.
016503 COPY CCFWRLTP.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
      /
010418 COPY CCFWSCOM.
010418 COPY CCFRSCOM.
      /
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0090.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.


           MOVE WGLOB-COMPANY-CODE    TO PASS-COMPANY-CODE.
           MOVE WGLOB-SYSTEM-DATE-INT TO WS-INTERNAL-START-DATE.
           MOVE WGLOB-SYSTEM-DATE-INT TO L1640-INTERNAL-DATE.

020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE   TO WS-EXTERNAL-START-DATE.

020874     PERFORM  0290-1000-BUILD-PARM-INFO
020874         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X

028298     IF  MIR-CLI-ID = SPACE
028298         PERFORM  FPCK-1000-CHECK-POLICY
028298             THRU FPCK-1000-CHECK-POLICY-X
028298     ELSE
028298         PERFORM  FCCK-1000-CHECK-CLIENT
028298             THRU FCCK-1000-CHECK-CLIENT-X
028298     END-IF.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.


026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
       2000-PROCESS-REQUEST.

025970*    MOVE MIR-BUS-FCN-ID        TO  WS-BUS-FCN-ID.
           SET  MIR-RETRN-OK          TO  TRUE.

           IF  NOT WS-BUS-FCN-VALID
               SET MIR-RETRN-INVALD-RQST  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

      ***  VALIDATE KEY AND CONTROL FIELDS.

           PERFORM  2100-VALIDATE-CONTROL-FIELDS
               THRU 2100-VALIDATE-CONTROL-FIELDS-X
           IF  WS-VALIDATE-FAIL
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF  WS-BUS-FCN-LIST
               PERFORM  3000-PROCESS-LIST
                   THRU 3000-PROCESS-LIST-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF  WS-BUS-FCN-RETRIEVE
               PERFORM  3700-PROCESS-RETRIEVE
                   THRU 3700-PROCESS-RETRIEVE-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

      **** POLICY CONTROL CHECK

           IF  WS-BUS-FCN-CREATE
               PERFORM  4000-PROCESS-CREATE
                   THRU 4000-PROCESS-CREATE-X
016503         IF  WGLOB-RETURN-ERROR
016503             GO TO 2000-PROCESS-REQUEST-X
016503         END-IF
016503         IF  WS-UW-REQUIREMENT
016503             PERFORM  8000-UPDATE-CLI-POL
016503                 THRU 8000-UPDATE-CLI-POL-X
016503         ELSE
016503             PERFORM  8600-UPDATE-NEXT-ACTV
016503                 THRU 8600-UPDATE-NEXT-ACTV-X
016503         END-IF
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF  WS-BUS-FCN-UPDATE
               PERFORM  5000-PROCESS-UPDATE
                   THRU 5000-PROCESS-UPDATE-X
016503         IF  WGLOB-RETURN-ERROR
016503             GO TO 2000-PROCESS-REQUEST-X
016503         END-IF
016503         IF  WS-UW-REQUIREMENT
016503             PERFORM  8000-UPDATE-CLI-POL
016503                 THRU 8000-UPDATE-CLI-POL-X
016503         ELSE
016503             PERFORM  8600-UPDATE-NEXT-ACTV
016503                 THRU 8600-UPDATE-NEXT-ACTV-X
016503         END-IF
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF  WS-BUS-FCN-DELETE
               PERFORM  6000-PROCESS-DELETE
                   THRU 6000-PROCESS-DELETE-X
016503         IF  WGLOB-RETURN-ERROR
016503             GO TO 2000-PROCESS-REQUEST-X
016503         END-IF
016503         IF  WS-UW-REQUIREMENT
016503             PERFORM  8000-UPDATE-CLI-POL
016503                 THRU 8000-UPDATE-CLI-POL-X
016503         ELSE
016503             PERFORM  8600-UPDATE-NEXT-ACTV
016503                 THRU 8600-UPDATE-NEXT-ACTV-X
016503         END-IF
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      ****************************************************************
      *  VALIDATE CONTROL FIELDS:
      *   CHECK VALIDITY OF ALL KEY AND CONTROL FIELDS.
      *   NUMERIC FIELDS ARE RIGHT JUSTIFIED, ZERO FILLED AND CHECKED
      *   FOR VALIDITY.  DATE FIELDS ARE CHECKED FOR VALIDITY.
      ****************************************************************
       2100-VALIDATE-CONTROL-FIELDS.

           MOVE 'N'                   TO WS-VALIDATE-FAIL-SW.

           PERFORM  2200-VALIDATE-CLIENT-POLICY
               THRU 2200-VALIDATE-CLIENT-POLICY-X.

           MOVE 999                   TO WS-SEQUENCE-NO.
           IF  MIR-CPREQ-SEQ-NUM   NOT =  SPACES
               PERFORM  2300-FORMAT-SEQUENCE
                   THRU 2300-FORMAT-SEQUENCE-X
           END-IF.

           MOVE WWKDT-ZERO-DT         TO WS-INTERNAL-START-DATE.
           IF  MIR-CPREQ-CREAT-DT   NOT =  SPACES
               PERFORM  2400-FORMAT-START-DATE
                   THRU 2400-FORMAT-START-DATE-X
           END-IF.

           IF  MIR-REQIR-ID  =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-REQIR-ID
           END-IF.


       2100-VALIDATE-CONTROL-FIELDS-X.
           EXIT.
      /
      ****************************************************************
      *   VALIDATE CLIENT / POLICY.
      *   INSIST THAT ONLY ONE OF THE CLIENT NUMBER AND THE POLICY
      *   NUMBER BE GIVEN, AND CHECK THE EXISTANCE, CONFIDENTIALITY,
      *   SECURITY ETC FOR THE GIVEN KEY.
      ****************************************************************
       2200-VALIDATE-CLIENT-POLICY.

      ***  ONE OF CLIENT OR POLICY MUST BE GIVEN.

           IF (MIR-CLI-ID = SPACES) AND
              (MIR-POL-ID-BASE = SPACES) AND
              (MIR-POL-ID-SFX = SPACES)
               MOVE 'NS00900001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VALIDATE-FAIL-SW
               GO TO 2200-VALIDATE-CLIENT-POLICY-X
           END-IF.

      ***  BOTH CLIENT AND POLICY CANNOT BE GIVEN.

           IF  MIR-CLI-ID NOT              =  SPACES

               IF  MIR-POL-ID-BASE    NOT  =  SPACES
               OR  MIR-POL-ID-SFX     NOT  =  SPACES
                   MOVE 'NS00900002'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'Y'           TO WS-VALIDATE-FAIL-SW
                   GO TO 2200-VALIDATE-CLIENT-POLICY-X
               END-IF

           END-IF.

      ***  CHECK CLIENT / POLICY.

           IF  MIR-CLI-ID                  =  SPACES
               PERFORM  2250-CHECK-POLICY
                   THRU 2250-CHECK-POLICY-X
           ELSE
               PERFORM  2210-CHECK-CLIENT
                   THRU 2210-CHECK-CLIENT-X
           END-IF.

       2200-VALIDATE-CLIENT-POLICY-X.
           EXIT.
      /
      ****************************************************************
      *   CHECK CLIENT:
      *   ENSURE THAT THE CLIENT EXISTS, AND CHECK THAT THE NECESSARY
      *   LEVEL OF ACCESS TO THE CLIENT INFORMATION IS PERMISSABLE.
      ****************************************************************
       2210-CHECK-CLIENT.

010418     MOVE SPACES                TO MIR-SBSDRY-CO-ID.
010418
           PERFORM  2220-CHECK-CLIENT-ACCESS
               THRU 2220-CHECK-CLIENT-ACCESS-X

           IF  WS-VALIDATE-OK
               MOVE 'C'               TO WS-POL-OR-CLI-CODE
               MOVE MIR-CLI-ID        TO WS-CLIENT-NUMBER

               GO TO 2210-CHECK-CLIENT-X

           END-IF.

           MOVE 'Y'                   TO WS-VALIDATE-FAIL-SW.

       2210-CHECK-CLIENT-X.
           EXIT.
      /
      ****************************************************************
      *   CHECK CLIENT ACCESS:
      *   ENSURE THAT CONFIDENTIAL CHECKS ARE SATISFIED.  IF UPDATE
      *   ACCESS IS REQUIRED, ALSO CHECK THE USERS DEPARTMENT AND FOR
      *   CLIENT LOCKS.
      ****************************************************************
       2220-CHECK-CLIENT-ACCESS.

      ***  CHECK CONFIDENTIALITY.

           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.
016387*    SET L5600-CNSLDT-MSG-NOT-REQD         TO TRUE.
016387*    SET L5600-GEN-CNSLDT-MSG-ERROR        TO TRUE.
           MOVE MIR-CLI-ID            TO L5600-CLI-ID.
           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.

           IF  L5600-CNFD-ACCS-RESTRICTED
           OR  L5600-CCAS-ACCS-RESTRICTED
               SET WS-VALIDATE-FAIL              TO TRUE
           END-IF.

       2220-CHECK-CLIENT-ACCESS-X.
           EXIT.
      /
      ****************************************************************
      *   CHECK POLICY:
      *   ENSURE THAT THE POLICY EXISTS, THAT CONFIDENTIAL CHECKS ARE
      *   SATISFIED, AND THAT BRANCH SECURITY IS SATISFIED.
      *****************************************************************
       2250-CHECK-POLICY.

           MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
               MOVE MIR-POL-ID-BASE   TO WS-POLNO
               MOVE MIR-POL-ID-SFX    TO WS-POLSF
               MOVE WS-POLID          TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VALIDATE-FAIL-SW
               GO TO 2250-CHECK-POLICY-X
           END-IF.

016440     IF  WS-BUS-FCN-CREATE
016440     OR  WS-BUS-FCN-UPDATE
016440     AND RPOL-POL-STAT-IN-FORCE
016440         PERFORM 2222-1000-BUILD-PARM-INFO
016440            THRU 2222-1000-BUILD-PARM-INFO-X
016440         MOVE RPOL-POL-ID       TO L2222-POL-ID
016440         PERFORM 2222-1000-FIND-PEND-CVG
016440            THRU 2222-1000-FIND-PEND-CVG-X
016440     END-IF.

016440*    IF NOT RPOL-POL-APPL-CTL-NBS
016440     IF (WS-BUS-FCN-CREATE
016440     OR  WS-BUS-FCN-UPDATE)
016440     AND L2222-INFORCE-POL-INFORCE-CVG
016440* MSG: INFORCE POLICY/INFORCE COVERAGES, CANNOT PROCESS
012624         MOVE 'XS00000239'      TO WGLOB-MSG-REF-INFO
012624         PERFORM  0260-1000-GENERATE-MESSAGE
012624             THRU 0260-1000-GENERATE-MESSAGE-X
012624         IF  WGLOB-MSG-SEVRTY-FATAL
012624         AND NOT WS-BUS-FCN-LIST
012624             MOVE 'Y'           TO WS-VALIDATE-FAIL-SW
012624             GO TO 2250-CHECK-POLICY-X
012624         END-IF
012624     END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
           IF  WS-BUS-FCN-LIST
012624*        SET  L5400-CTL-MSG-NOT-REQD  TO TRUE
               SET L5400-STAT-MSG-NOT-REQD  TO TRUE
           END-IF.

016440     IF WS-BUS-FCN-UPDATE
016440     OR WS-BUS-FCN-CREATE
016440     OR WS-BUS-FCN-DELETE
016440        SET L5400-POL-XFER-UPDATE     TO TRUE
016440     END-IF.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
016440     OR  L5400-XFER-ACCS-RESTRICTED
               MOVE 'Y'               TO WS-VALIDATE-FAIL-SW
               GO TO 2250-CHECK-POLICY-X
           END-IF.

           IF  L5400-BRCH-ACCS-RESTRICTED
               MOVE 'Y'               TO WS-VALIDATE-FAIL-SW
               GO TO 2250-CHECK-POLICY-X
           ELSE
               MOVE 'P'               TO WS-POL-OR-CLI-CODE
               MOVE MIR-POL-ID-BASE   TO WS-POLICY-NUMBER
               MOVE MIR-POL-ID-SFX    TO WS-POLICY-SUFFIX

           END-IF.

012624*    IF  L5400-CTL-ACCS-RESTRICTED
012624*    AND NOT WS-BUS-FCN-LIST
012624*        MOVE 'Y'               TO WS-VALIDATE-FAIL-SW
012624*        GO TO 2250-CHECK-POLICY-X
012624*    END-IF.

           IF  WGLOB-MSG-ERROR-SW     >  ZERO
               MOVE 'Y'               TO WS-VALIDATE-FAIL-SW
               GO TO 2250-CHECK-POLICY-X
           END-IF.

010418     MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.
010418
       2250-CHECK-POLICY-X.
           EXIT.
      /
      ****************************************************************
      *   FORMAT SEQUENCE #:
      *   ENSURE THAT THE SUPPLIED REQUIREMENT SEQUENCE NUMBER
      *   IS NUMERIC.
      ****************************************************************
       2300-FORMAT-SEQUENCE.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE MIR-CPREQ-SEQ-NUM     TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK

               IF  L0280-OUTPUT < ZERO
               OR  L0280-OUTPUT = ZERO
                   MOVE MIR-CPREQ-SEQ-NUM
                                      TO WGLOB-MSG-PARM (1)
                   MOVE 'NS00900005'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE L0280-OUTPUT  TO WS-SEQUENCE-NO
                   MOVE WS-SEQUENCE-NO   TO MIR-CPREQ-SEQ-NUM
                   GO TO 2300-FORMAT-SEQUENCE-X
               END-IF

           ELSE
               MOVE MIR-CPREQ-SEQ-NUM TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE 'Y'                   TO WS-VALIDATE-FAIL-SW.

       2300-FORMAT-SEQUENCE-X.
           EXIT.
      /
      ****************************************************************
      *   FORMAT START DATE:
      *   ENSURE THAT THE SUPPLIED START DATE IS A VALID DATE.
      ****************************************************************
       2400-FORMAT-START-DATE.

      *** ATTEMPT TO CONVERT         TO INTERNAL FORMAT.

           MOVE MIR-CPREQ-CREAT-DT    TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO WS-INTERNAL-START-DATE
               MOVE L1640-INTERNAL-DATE
                                      TO RREQT-CPREQ-CREAT-DT
           ELSE
               MOVE MIR-CPREQ-CREAT-DT   TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VALIDATE-FAIL-SW
           END-IF.

       2400-FORMAT-START-DATE-X.
           EXIT.


      ****************************************************************
      *   INQUIRY PROCESSING:
      *   DISTRIBUTE CONTROL TO THE APPROPRIATE PROCESSING ROUTINE,
      *   BASED UPON THE EXISTANCE OF THE KEY 'REQUIREMENT CODE' AND
      *   SCROLL INDICATOR.  NOTE THAT THE DEFAULT SCROLLING DIRECTION
      *   IS BACKWARD.
      ****************************************************************
       3000-PROCESS-LIST.

           IF  MIR-REQIR-ID NOT = SPACES
           AND MIR-CPREQ-CREAT-DT = SPACES

               PERFORM  3200-REQT-PREV-PAGE
                   THRU 3200-REQT-PREV-PAGE-X

           ELSE

               PERFORM  3600-DATE-PREV-PAGE
                   THRU 3600-DATE-PREV-PAGE-X


           END-IF.

       3000-PROCESS-LIST-X.
           EXIT.
      /

      ****************************************************************
      *   REQT INQUIRY - PREVIOUS PAGE PROCESSING:
      *   SETUP REQT BROWSE KEYS, BEGIN BROWSE, AND LOAD DATA ARRAY
      *   UNTIL END-OF-FILE OR SCREEN IS FULL.  IF END-OF-FILE BEFORE
      *   SCREEN FULL THEN INVOKE SCREEN FILL ROUTINE.
      ****************************************************************
       3200-REQT-PREV-PAGE.

      ***  SETUP REVERSE BROWSE KEYS.

           MOVE HIGH-VALUES            TO WREQT-KEY.
           MOVE LOW-VALUES             TO WREQT-ENDBR-KEY.
           PERFORM  7810-BUILD-REQT-BROWSE-KEYS
               THRU 7810-BUILD-REQT-BROWSE-KEYS-X.

           MOVE WS-SEQUENCE-NO         TO WREQT-CPREQ-SEQ-NUM.

      ***  STARTING SEQ NO REQUIRED WHEN FILLING PAGE.

           MOVE WREQT-CPREQ-SEQ-NUM    TO WS-SAVE-SEQ-NO.

      ***  SETUP SCREEN FOR DISPLAY

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      ***  DISPLAY RECORDS BACKWARDS

           MOVE WS-MAX-LINES           TO WS-LINE.
           PERFORM  3220-REQT-DISPLAY-PREV-PAGE
               THRU 3220-REQT-DISPLAY-PREV-PAGE-X.

      ***  FINISHED IF SCREEN IS FULL

           IF  WS-LINE                 <  1

               IF  WREQT-IO-OK
                   SET WGLOB-MORE-DATA-EXISTS  TO TRUE
                   MOVE 'XS00000014'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   PERFORM  9260-UPDATE-SCREEN-KEYS
                       THRU 9260-UPDATE-SCREEN-KEYS-X
                   GO TO 3200-REQT-PREV-PAGE-X
               ELSE
                   MOVE 'XS00000015' TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3200-REQT-PREV-PAGE-X
               END-IF

           ELSE
               MOVE 'NS00900008' TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3200-REQT-PREV-PAGE-X.
           EXIT.

      /
      ****************************************************************
      *   REQT INQUIRY - DISPLAY PREVIOUS PAGE:        INPUT: WS-LINE
      *   BROWSE BACKWARDS FROM THE CURRENT REQT BROWSE KEY, LOADING
      *   RECORDS ONTO THE SCREEN, BEGINNING WITH WS-LINE AND
      *   REDUCING, UNTIL THE SCREEN IS FULL OR END-OF-FILE.
      ****************************************************************
       3220-REQT-DISPLAY-PREV-PAGE.

      ***  BEGIN BROWSE

           PERFORM  REQT-1000-BROWSE-PREV
               THRU REQT-1000-BROWSE-PREV-X.
           IF  NOT WREQT-IO-OK
               GO TO 3220-REQT-DISPLAY-PREV-PAGE-X
           END-IF.

      ***  READ FIRST RECORD.

           PERFORM  REQT-2000-READ-PREV
               THRU REQT-2000-READ-PREV-X.

      ***  LOAD SCREEN DATA ARRAY

           IF  WREQT-IO-OK
               PERFORM  3240-REQT-DISPLAY-REC-PREV
                   THRU 3240-REQT-DISPLAY-REC-PREV-X
                   VARYING WS-LINE FROM 1 BY 1
                   UNTIL (NOT WREQT-IO-OK)
                      OR (WS-LINE > WS-MAX-LINES)
           END-IF.

      *  RESET WS-LINE IF BROWSE RETURNS WITH EOF
      *  AND WE ARE ALREADY PAST THE END OF THE SCREEN.

           IF  WREQT-IO-EOF
           AND WS-LINE > WS-MAX-LINES
               MOVE WS-MAX-LINES     TO WS-LINE
           END-IF.


      ***  DISPLAY CLIENT OR POLICY INFO

           PERFORM  9230-DISPLAY-CLI-OR-POL-INFO
               THRU 9230-DISPLAY-CLI-OR-POL-INFO-X.

      ***  FINISH BROWSE

           PERFORM  REQT-3000-END-BROWSE-PREV
               THRU REQT-3000-END-BROWSE-PREV-X.

       3220-REQT-DISPLAY-PREV-PAGE-X.
           EXIT.
      /
      ****************************************************************
      *   REQT INQUIRY - DISPLAY RECORD PREVIOUS:     INPUT: WS-LINE
      *   DISPLAY THE CURRENT RECORD ONTO THE SCREEN DATA LINE
      *   GIVEN BY WS-LINE AND RETRIEVE THE PREVIOUS REQT RECORD.
      ****************************************************************
       3240-REQT-DISPLAY-REC-PREV.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  REQT-2000-READ-PREV
               THRU REQT-2000-READ-PREV-X.

       3240-REQT-DISPLAY-REC-PREV-X.
           EXIT.

      /
      ****************************************************************
      *   DATE INQUIRY - PREVIOUS PAGE PROCESSING:
      *   SETUP RQCR BROWSE KEYS, BEGIN BROWSE, AND LOAD DATA ARRAY
      *   UNTIL END-OF-FILE OR SCREEN IS FULL.  IF END-OF-FILE BEFORE
      *   SCREEN FULL THEN INVOKE SCREEN FILL ROUTINE.
      ****************************************************************
       3600-DATE-PREV-PAGE.

      ***  SETUP REVERSE BROWSE KEYS.

           IF  MIR-CPREQ-CREAT-DT = SPACES
               MOVE WGLOB-SYSTEM-DATE-INT    TO WS-INTERNAL-START-DATE
               MOVE WS-EXTERNAL-START-DATE   TO MIR-CPREQ-CREAT-DT
           END-IF.

           MOVE HIGH-VALUES                  TO WRQCR-KEY.
           MOVE LOW-VALUES                   TO WRQCR-ENDBR-KEY.
           MOVE WWKDT-LOW-DT          TO WRQCR-ENDBR-CPREQ-CREAT-DT.
           PERFORM  7820-BUILD-RQCR-BROWSE-KEYS
               THRU 7820-BUILD-RQCR-BROWSE-KEYS-X.

           MOVE WS-SEQUENCE-NO               TO WRQCR-CPREQ-SEQ-NUM.

           IF  WRQCR-REQIR-ID         = SPACES
               MOVE HIGH-VALUES               TO WRQCR-REQIR-ID
           END-IF.

      ***  SETUP SCREEN FOR DISPLAY

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      ***  DISPLAY RECORDS BACKWARDS

           MOVE WS-MAX-LINES TO WS-LINE.
           PERFORM  3620-DATE-DISPLAY-PREV-PAGE
               THRU 3620-DATE-DISPLAY-PREV-PAGE-X.

      ***  FINISHED IF SCREEN IS FULL

           IF  WS-LINE              >  WS-MAX-LINES

               IF  WRQCR-IO-OK
                   SET WGLOB-MORE-DATA-EXISTS  TO TRUE
                   MOVE 'XS00000014' TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   PERFORM  9260-UPDATE-SCREEN-KEYS
                       THRU 9260-UPDATE-SCREEN-KEYS-X
                   GO TO 3600-DATE-PREV-PAGE-X
               ELSE
                   MOVE 'XS00000015' TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3600-DATE-PREV-PAGE-X
               END-IF

           ELSE
               MOVE 'NS00900008'    TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3600-DATE-PREV-PAGE-X.
           EXIT.
      /
      ****************************************************************
      *   DATE INQUIRY - DISPLAY PREVIOUS PAGE:        INPUT: WS-LINE
      *   BROWSE BACKWARDS FROM THE CURRENT RQCR BROWSE KEY, LOADING
      *   RECORDS ONTO THE SCREEN, BEGINNING WITH WS-LINE AND REDUCING,
      *   UNTIL THE SCREEN IS FULL OR END-OF-FILE.
      ****************************************************************
       3620-DATE-DISPLAY-PREV-PAGE.

      ***  BEGIN BROWSE

           PERFORM  RQCR-1000-BROWSE-PREV
               THRU RQCR-1000-BROWSE-PREV-X.
           IF  NOT WRQCR-IO-OK
               GO TO 3620-DATE-DISPLAY-PREV-PAGE-X
           END-IF.

      ***  READ FIRST RECORD.

           PERFORM  RQCR-2000-READ-PREV
               THRU RQCR-2000-READ-PREV-X.

      ***  LOAD SCREEN DATA ARRAY

           IF  WRQCR-IO-OK
               PERFORM  3640-DATE-DISPLAY-REC-PREV
                   THRU 3640-DATE-DISPLAY-REC-PREV-X
                   VARYING WS-LINE FROM 1 BY 1
                   UNTIL (WS-LINE > WS-MAX-LINES)
                   OR  (NOT WRQCR-IO-OK)
           END-IF.

      *  RESET WS-LINE IF BROWSE RETURNS WITH EOF
      *  AND WE ARE ALREADY PAST THE END OF THE SCREEN.

           IF  WRQCR-IO-EOF
           AND WS-LINE               >  WS-MAX-LINES
               MOVE WS-MAX-LINES     TO WS-LINE
           END-IF.


      ***  DISPLAY CLIENT OR POLICY INFO

           PERFORM  9230-DISPLAY-CLI-OR-POL-INFO
               THRU 9230-DISPLAY-CLI-OR-POL-INFO-X.

      ***  FINISH BROWSE

           PERFORM  RQCR-3000-END-BROWSE-PREV
               THRU RQCR-3000-END-BROWSE-PREV-X.

       3620-DATE-DISPLAY-PREV-PAGE-X.
           EXIT.
      /
      ****************************************************************
      *   DATE INQUIRY - DISPLAY RECORD PREVIOUS:      INPUT: WS-LINE
      *   DISPLAY THE CURRENT RECORD ONTO THE SCREEN DATA LINE
      *   GIVEN BY WS-LINE AND RETRIEVE THE PREVIOUS RQCR RECORD.
      ****************************************************************
       3640-DATE-DISPLAY-REC-PREV.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  RQCR-2000-READ-PREV
               THRU RQCR-2000-READ-PREV-X.

       3640-DATE-DISPLAY-REC-PREV-X.
           EXIT.
      /

       3700-PROCESS-RETRIEVE.

           PERFORM  7800-BUILD-REQT-KEY
               THRU 7800-BUILD-REQT-KEY-X.
014221*    PERFORM  REQT-1000-READ
014221*        THRU REQT-1000-READ-X.

014221     PERFORM  REQT-1000-READ-TWRK-TS
014221         THRU REQT-1000-READ-TWRK-TS-X.

           IF  WREQT-IO-NOT-FOUND
               MOVE WREQT-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900016'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
016062*        MOVE WGLOB-USER-ID       TO RREQT-USER-ID
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
               PERFORM  9230-DISPLAY-CLI-OR-POL-INFO
                   THRU 9230-DISPLAY-CLI-OR-POL-INFO-X
               MOVE 'XS00000016'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3700-PROCESS-RETRIEVE-X.
           EXIT.


      /
      ****************************************************************
      *  CREATE PROCESSING:  INIT NEW RECORD AND ALLOW USER TO MODIFY*
      ****************************************************************
       4000-PROCESS-CREATE.

      ***  SWITCH TO CREATE SCREEN.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      ***  CHECK CONTROL FIELDS

           PERFORM  4100-EDIT-KEY-FIELDS
               THRU 4100-EDIT-KEY-FIELDS-X.

           IF  WS-VALIDATE-FAIL
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

      ***  CREATE RECORD AND SWITCH TO MAINTAIN MODE.
      ***  NOTE: WRITE DELAYED TILL MAINTENANCE COMPLETE.

           PERFORM  REQT-1000-CREATE
               THRU REQT-1000-CREATE-X.
           MOVE WS-INTERNAL-START-DATE   TO RREQT-CPREQ-CREAT-DT.
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
           PERFORM  9230-DISPLAY-CLI-OR-POL-INFO
               THRU 9230-DISPLAY-CLI-OR-POL-INFO-X.
           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      ****************************************************************
      *  EDIT KEY FIELDS:  CHECK VALIDITY OF ALL KEY FIELDS TO       *
      *  ENSURE THAT ALL NEW RECORDS ARE CREATED WITH VALID KEYS.    *
      ****************************************************************
       4100-EDIT-KEY-FIELDS.

           MOVE 'N'                   TO WS-VALIDATE-FAIL-SW.

      ***  FULL CLIENT / POLICY KEY EDITS.

           PERFORM  2200-VALIDATE-CLIENT-POLICY
               THRU 2200-VALIDATE-CLIENT-POLICY-X.

           IF  WS-VALIDATE-FAIL
               GO TO 4100-EDIT-KEY-FIELDS-X
           END-IF.

      ***  CHECK REQUIREMENT CODE.

           PERFORM  4200-EDIT-REQT-CODE
               THRU 4200-EDIT-REQT-CODE-X.

      ***  IF SEQUENCE GIVEN, TELL IGNORING.

           IF  MIR-CPREQ-SEQ-NUM           NOT  =  SPACES
               MOVE SPACES            TO MIR-CPREQ-SEQ-NUM
               MOVE 'NS00900009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      ***  SET / EDIT CREATE DATE.

           PERFORM  4400-EDIT-CREATE-DATE
               THRU 4400-EDIT-CREATE-DATE-X.

       4100-EDIT-KEY-FIELDS-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT REQUIREMENT CODE:
      *   CHECK THAT THE REQUIREMENT CODE IS NON-BLANK, EXISTS ON THE
      *   REQUIREMENT TABLE (RTAB) FILE AND IS OF THE CORRECT TYPE
      *   FOR THE CLIENT / POLICY KEYS SUPPLIED.
      ****************************************************************
       4200-EDIT-REQT-CODE.

      ***  LOOKUP RTAB & CHECK TYPE.

           IF  MIR-REQIR-ID               =  SPACES
               MOVE 'NS00900010'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE MIR-REQIR-ID      TO WRTAB-REQIR-ID
               PERFORM  RTAB-1000-READ
                   THRU RTAB-1000-READ-X

               IF  WRTAB-IO-OK
                   MOVE 'Y'           TO WS-RTAB-READ-IND
                   PERFORM  4300-CHECK-REQT-TYPE
                       THRU 4300-CHECK-REQT-TYPE-X
                   GO TO 4200-EDIT-REQT-CODE-X
               ELSE
                   MOVE MIR-REQIR-ID  TO WGLOB-MSG-PARM (1)
                   MOVE 'XS00000114'  TO WGLOB-MSG-REF-INFO
               END-IF

           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

      ***  ERROR PROCESSING.

           MOVE 'Y'                   TO WS-VALIDATE-FAIL-SW.

       4200-EDIT-REQT-CODE-X.
           EXIT.
      /
      ****************************************************************
      *   CHECK REQUIREMENT TYPE:
      *   CROSS-EDIT THE REQUIREMENT TYPE AGAINST THE TYPE OF KEY
      *   GIVEN, TO ENSURE THAT UNDERWRITING REQUIREMENTS ARE CREATED
      *   AT CLIENT LEVEL AND ISSUE REQUIREMENTS ARE CREATED AT POLICY
      *   LEVEL.
      ****************************************************************
       4300-CHECK-REQT-TYPE.

      ***  UNDERWRITING REQUIREMENTS AT CLIENT LEVEL.

           IF  RRTAB-REQIR-TYP-CD          =  'U'

               IF  MIR-POL-ID-BASE    NOT  =  SPACES
                   MOVE 'NS00900012'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'Y'           TO WS-VALIDATE-FAIL-SW
               END-IF

           END-IF.


      ***  ISSUE REQUIREMENTS AT POLICY LEVEL.

           IF  RRTAB-REQIR-TYP-CD          =  'I'
010311     OR  RRTAB-REQIR-TYP-CD          =  'S'

               IF  MIR-CLI-ID          NOT  =  SPACES
                   MOVE 'NS00900013'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'Y'           TO WS-VALIDATE-FAIL-SW
               END-IF

           END-IF.

       4300-CHECK-REQT-TYPE-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT CREATE DATE:
      *   IF THE START DATE FIELD IS NOT GIVEN, SET THE CREATION
      *   DATE TO THE CURRENT MACHINE DATE.  OTHERWISE, CHECK THAT THE
      *   START DATE IS VALID, AND NOT IN THE FUTURE.
      ****************************************************************
       4400-EDIT-CREATE-DATE.


      ***  SET IF NOT GIVEN.

           IF  MIR-CPREQ-CREAT-DT                     =  SPACES
               MOVE WS-EXTERNAL-START-DATE
                                      TO MIR-CPREQ-CREAT-DT
               GO TO 4400-EDIT-CREATE-DATE-X
           END-IF.

      ***  CHECK DATE VALID.

           MOVE MIR-CPREQ-CREAT-DT    TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.

           IF  NOT L1640-VALID
               MOVE MIR-CPREQ-CREAT-DT   TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE

      ***      CHECK NOT IN FUTURE.
               IF  L1640-INTERNAL-DATE   >  WGLOB-SYSTEM-DATE-INT
                   MOVE MIR-CPREQ-CREAT-DT
                                      TO WGLOB-MSG-PARM (1)
                   MOVE 'NS00900015'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

                   IF  NOT WGLOB-MSG-SEVRTY-FATAL
                       MOVE L1640-INTERNAL-DATE
                                      TO WS-INTERNAL-START-DATE
                       GO TO 4400-EDIT-CREATE-DATE-X
                   ELSE
                       CONTINUE
                   END-IF

               ELSE
                   MOVE L1640-INTERNAL-DATE
                                      TO WS-INTERNAL-START-DATE
                   GO TO 4400-EDIT-CREATE-DATE-X
               END-IF

           END-IF.


      ***  ERROR PROCESSING.

           MOVE 'Y'                   TO WS-VALIDATE-FAIL-SW.

       4400-EDIT-CREATE-DATE-X.
           EXIT.
      /
       5000-PROCESS-UPDATE.


           IF  MIR-CLI-ID =  SPACES
               MOVE 'P'               TO WS-POL-OR-CLI-CODE
               MOVE MIR-POL-ID-BASE   TO WS-POLICY-NUMBER
               MOVE MIR-POL-ID-SFX    TO WS-POLICY-SUFFIX
           ELSE
               MOVE 'C'               TO WS-POL-OR-CLI-CODE
               MOVE MIR-CLI-ID        TO WS-CLIENT-ID
           END-IF.

           IF  MIR-CPREQ-SEQ-NUM NOT  =  SPACES
               PERFORM  2300-FORMAT-SEQUENCE
                   THRU 2300-FORMAT-SEQUENCE-X
           END-IF.


      ***  ATTEMPT TO FIND REQT RECORD.

           PERFORM  7800-BUILD-REQT-KEY
               THRU 7800-BUILD-REQT-KEY-X.
014221*    PERFORM  REQT-1000-READ-FOR-UPDATE
014221*        THRU REQT-1000-READ-FOR-UPDATE-X.

014221     PERFORM  REQT-2000-UPDATE-TWRK-TS
014221         THRU REQT-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303' TO WGLOB-MSG-REF-INFO
014221         MOVE 'REQT'       TO WGLOB-MSG-PARM (01)
014221         MOVE WREQT-KEY    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221              THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF  WREQT-IO-OK
               MOVE 'R'               TO WS-WRITE-REWRITE-IND
           ELSE
               MOVE 'W'               TO WS-WRITE-REWRITE-IND
           END-IF.


      ***  FIND SEQUENCE NUMBER IF NEEDED.

           IF  WS-WRITE-REQT
               PERFORM  5220-DETERMINE-SEQUENCE
                   THRU 5220-DETERMINE-SEQUENCE-X

               IF  NO-MORE-SEQ-NO
                   MOVE 'NS00900017'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'XS00000089'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 5000-PROCESS-UPDATE-X
               ELSE
                   PERFORM  7800-BUILD-REQT-KEY
                       THRU 7800-BUILD-REQT-KEY-X
                   PERFORM  REQT-1000-CREATE
                       THRU REQT-1000-CREATE-X
                   MOVE WS-SEQUENCE-NO TO MIR-CPREQ-SEQ-NUM
               END-IF

           END-IF.

      ***  PERFORM EDITS.

           MOVE 'Y'                   TO WS-EDITS-OK-SW.
           PERFORM  5300-EDIT-DATA-FIELDS
               THRU 5300-EDIT-DATA-FIELDS-X.

           MOVE 'Y'                   TO WS-CROSS-EDITS-OK-SW.
           PERFORM  5600-CROSS-EDITS
               THRU 5600-CROSS-EDITS-X.


      ***  WRITE / REWRITE REQUIREMENT.

           IF  WS-REWRITE-REQT
               PERFORM  REQT-2000-REWRITE
                   THRU REQT-2000-REWRITE-X
035393
035393         IF  RREQT-CPREQ-STAT-CD NOT = WS-OLD-STATUS-CODE
035393             PERFORM  8750-REQS-EVENT
035393                 THRU 8750-REQS-EVENT-X
035393         ELSE
035393             PERFORM  8700-REQU-EVENT
035393                 THRU 8700-REQU-EVENT-X
035393         END-IF
035393
014221         PERFORM  REQT-1000-READ-TWRK-TS
014221             THRU REQT-1000-READ-TWRK-TS-X
           ELSE

               IF  WS-NEW-STATUS-OK
                   PERFORM  7800-BUILD-REQT-KEY
                       THRU 7800-BUILD-REQT-KEY-X
                   PERFORM  5260-SET-CREATE-DATE
                       THRU 5260-SET-CREATE-DATE-X
                   PERFORM  REQT-1000-WRITE
                       THRU REQT-1000-WRITE-X
035393             PERFORM  8720-REQC-EVENT
035393                 THRU 8720-REQC-EVENT-X
014221             PERFORM  REQT-1000-READ-TWRK-TS
014221                 THRU REQT-1000-READ-TWRK-TS-X
               ELSE
                   MOVE 'XS00000039'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 5000-PROCESS-UPDATE-X
               END-IF

           END-IF.


      ***  CHECK IF MAINTAIN REQUIRES ANALYZE.

           PERFORM  5240-CHECK-ANALYZE
               THRU 5240-CHECK-ANALYZE-X.


      ***  UPDATE ACTIVITY DATE IF CLIENT.

           IF  WS-UW-REQUIREMENT
               PERFORM  7250-UPD-CLIENT-ACTIVITY-DT
                   THRU 7250-UPD-CLIENT-ACTIVITY-DT-X
           END-IF.

      ***  CALL THE REQUIREMENT RESOLUTION MODULE IF IT WAS REQUESTED
      ***  AND THERE WERE NO EDIT OR CROSS EDIT ERRORS.
           IF  WS-ALL-EDITS-OK
           AND WS-CROSS-EDITS-OK
           AND MIR-DV-REVW-REQIR-IND = 'Y'
               MOVE 'N'               TO MIR-DV-REVW-REQIR-IND
               PERFORM  7180-1000-BUILD-PARM-INFO
                   THRU 7180-1000-BUILD-PARM-INFO-X
               MOVE RREQT-CLI-ID      TO L7180-CLI-ID
               MOVE RREQT-CPREQ-DESGNT-ID
                                      TO L7180-LAB-CD
               MOVE RREQT-REQIR-ID    TO L7180-REQIR-CD
               MOVE RREQT-CPREQ-SEQ-NUM
                                      TO L7180-SEQ-NUM
               PERFORM  7180-1000-RESOLVE-REQT
                   THRU 7180-1000-RESOLVE-REQT-X

               IF  L7180-REQIR-STAT-UPDT
                   MOVE L7180-NEW-REQIR-STAT-CD
                                      TO MIR-CPREQ-STAT-CD
               END-IF

               IF  L7180-CLI-DECISION-RQST
                   PERFORM  1030-1000-BUILD-PARM-INFO
                       THRU 1030-1000-BUILD-PARM-INFO-X
                   MOVE RREQT-CLI-ID  TO L1030-CLIENT-ID
                   PERFORM  1030-1000-CLIENT-DECISION
                       THRU 1030-1000-CLIENT-DECISION-X
               END-IF

           END-IF.


      ***  GIVE MESSAGES, SET ATTR ETC.

           IF  WS-ALL-EDITS-OK
           AND WS-CROSS-EDITS-OK
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
010311         MOVE RREQT-REQIR-ID    TO WEDIT-ETBL-VALU-ID
010311         MOVE SPACES            TO REDIT-ETBL-DESC-TXT
010311         PERFORM REQT-2000-DESC
010311            THRU REQT-2000-DESC-X
010645         MOVE RREQT-REQIR-ID    TO WRTAB-REQIR-ID
010645
010645         PERFORM  RTAB-1000-READ
010645             THRU RTAB-1000-READ-X
010645
010645         IF  NOT WRTAB-IO-OK
010645             MOVE SPACES        TO MIR-REQIR-TYP-CD
010645         ELSE
010645             MOVE RRTAB-REQIR-TYP-CD
                                      TO MIR-REQIR-TYP-CD
010645         END-IF


           ELSE
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO

           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  9230-DISPLAY-CLI-OR-POL-INFO
               THRU 9230-DISPLAY-CLI-OR-POL-INFO-X.

           MOVE RREQT-CPREQ-CREAT-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CPREQ-CREAT-DT.


       5000-PROCESS-UPDATE-X.
           EXIT.

      /
      ****************************************************************
      *   DETERMINE SEQUENCE:
      *   FIND THE SEQUENCE NUMBER FOR THE NEW REQUIREMENT
      *   RECORD, BY FETCHING THE LAST RECORD FOR THIS CLIENT &
      *   REQUIREMENT AND ADDING ONE TO ITS SEQUENCE NUMBER.
      *   IF NONE ARE FOUND, A SEQUENCE NUMBER OF 1 IS ALLOCATED.
      ****************************************************************
       5220-DETERMINE-SEQUENCE.


      ***  SETUP REVERSE BROWSE KEYS.

           MOVE HIGH-VALUES           TO WREQT-KEY.
           MOVE LOW-VALUES            TO WREQT-ENDBR-KEY.
           PERFORM  7810-BUILD-REQT-BROWSE-KEYS
               THRU 7810-BUILD-REQT-BROWSE-KEYS-X.


      ***  BEGIN BROWSE

           PERFORM  REQT-1000-BROWSE-PREV
               THRU REQT-1000-BROWSE-PREV-X.
           IF  NOT WREQT-IO-OK
               MOVE 1                 TO WS-SEQUENCE-NO
               GO TO 5220-DETERMINE-SEQUENCE-X
           END-IF.


      ***  READ FIRST RECORD.

           PERFORM  REQT-2000-READ-PREV
               THRU REQT-2000-READ-PREV-X.
           IF  WREQT-IO-OK
               MOVE RREQT-CPREQ-SEQ-NUM
                                      TO WS-SEQUENCE-NO

               IF WS-SEQUENCE-NO = 999
                   MOVE 'Y'           TO WS-NO-MORE-SEQ-NO-SW
               ELSE
                   ADD 1                TO WS-SEQUENCE-NO
               END-IF

           ELSE
               MOVE 1                 TO WS-SEQUENCE-NO
           END-IF.


      ***  FINISH BROWSE

           PERFORM  REQT-3000-END-BROWSE-PREV
               THRU REQT-3000-END-BROWSE-PREV-X.

       5220-DETERMINE-SEQUENCE-X.
           EXIT.
      /
      ****************************************************************
      *   CHECK ANALYZE:
      *   CHECK IF THIS MAINTAIN REQUIRES THAT THE INSURED / POLICY
      *   BE RE-ANALYZED TO POSSIBLY CORRECT THE STATUS CODES
      *   ON COVERAGES AND / OR POLICIES.
      ****************************************************************
       5240-CHECK-ANALYZE.


      ***  STATUS MUST BE VALID AND CHANGED.

           IF  WS-NEW-STATUS-OK AND
              (WS-OLD-STATUS-CODE NOT = RREQT-CPREQ-STAT-CD)
               CONTINUE
           ELSE
               GO TO 5240-CHECK-ANALYZE-X
           END-IF.


      ***  FOR NEW REQUIREMENTS, ONLY ANALYZE IF OUTSTANDING.

           IF  WS-WRITE-REQT AND
              (NOT RREQT-CPREQ-STAT-OUTSTANDING)
               GO TO 5240-CHECK-ANALYZE-X
           END-IF.


      ***  FOR MAINTAIN, NO ANALYZE IF WAS AND STILL IS OUTSTANDING.

           IF  WS-REWRITE-REQT AND
              (WS-OLD-OUTSTANDING AND RREQT-CPREQ-STAT-OUTSTANDING)
               GO TO 5240-CHECK-ANALYZE-X
           END-IF.


      ***  FOR MAINTAIN, NO ANALYZE IF WASN'T AND STILL
      ***  ISN'T OUTSTANDING.

           IF  WS-REWRITE-REQT AND
              (NOT WS-OLD-OUTSTANDING) AND
              (NOT RREQT-CPREQ-STAT-OUTSTANDING)
               GO TO 5240-CHECK-ANALYZE-X
           END-IF.


      ***  RE-ANALYZE.

           PERFORM  7700-FORCE-ANALYZE
               THRU 7700-FORCE-ANALYZE-X.

      *   CHECK IF CWA REQT STATUS CHANGED BY ANALYZE
           IF  MIR-REQIR-ID = 'CWA'
               MOVE RREQT-CPREQ-STAT-CD
                                      TO WS-SAVE-REQT-STATUS
               PERFORM  REQT-1000-READ
                   THRU REQT-1000-READ-X

               IF  RREQT-CPREQ-STAT-CD  NOT =  WS-SAVE-REQT-STATUS
      * MSG (S) SYSTEM DETERMINED STATUS OF (@1) CANNOT BE CHANGED TO @2
                   MOVE 'NS00900068'  TO WGLOB-MSG-REF-INFO
                   MOVE RREQT-CPREQ-STAT-CD
                                      TO WGLOB-MSG-PARM (1)
                   MOVE WS-SAVE-REQT-STATUS
                                      TO WGLOB-MSG-PARM (2)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-EDITS-OK-SW
               END-IF

           END-IF.

       5240-CHECK-ANALYZE-X.
           EXIT.
      /

       5260-SET-CREATE-DATE.

           IF MIR-CPREQ-CREAT-DT = SPACES
               MOVE WGLOB-SYSTEM-DATE-INT
                                      TO RREQT-CPREQ-CREAT-DT
           ELSE
               MOVE MIR-CPREQ-CREAT-DT            TO L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X
               MOVE L1640-INTERNAL-DATE
                                      TO RREQT-CPREQ-CREAT-DT
           END-IF.

       5260-SET-CREATE-DATE-X.
           EXIT.

      /
      ****************************************************************
      *   FIELD EDITS:
      *   FETCH RTAB RECORD (IF CAN), AND CHECK VALIDITY OF ALL DATA
      *   FIELDS, CALCULATING THE FOLLOW-UP DATE AND/OR REQUIREMENT
      *   VALIDITY DATE AS NECESSARY.
      ****************************************************************
       5300-EDIT-DATA-FIELDS.


      ***  FETCH REQUIREMENT TABLE ENTRY.

           PERFORM  5310-FETCH-RTAB
               THRU 5310-FETCH-RTAB-X.


      ***  BASIC FIELD EDITS.

           PERFORM  5320-EDIT-REQT-STATUS
               THRU 5320-EDIT-REQT-STATUS-X.
           PERFORM  5340-EDIT-REQT-STATUS-DATE
               THRU 5340-EDIT-REQT-STATUS-DATE-X.
           PERFORM  5360-EDIT-USER-ID
               THRU 5360-EDIT-USER-ID-X.
           PERFORM  5370-EDIT-DESIGNATION
               THRU 5370-EDIT-DESIGNATION-X.
           PERFORM  5380-EDIT-TEST-DATE
               THRU 5380-EDIT-TEST-DATE-X.
           PERFORM  5400-EDIT-TEST-RESULT
               THRU 5400-EDIT-TEST-RESULT-X.
           PERFORM  5405-EDIT-RESULTS-IND
               THRU 5405-EDIT-RESULTS-IND-X.
           PERFORM  5410-EDIT-RESOLVE-IND
               THRU 5410-EDIT-RESOLVE-IND-X.


      ***  FOLLOW-UP DETAILS.

029083*    IF (MIR-CPREQ-FOLWUP-NUM = SPACES) AND
029083*       (MIR-CPREQ-FOLWUP-DT = SPACES) AND
029083*       (WS-CALC-FOLLOW-UP)
029083     IF  (MIR-CPREQ-FOLWUP-NUM = SPACES
029083       OR   MIR-CPREQ-FOLWUP-NUM = ZERO)
029083     AND (MIR-CPREQ-FOLWUP-DT = SPACES
029083       OR   MIR-CPREQ-FOLWUP-DT = ZERO)
029083     AND (WS-CALC-FOLLOW-UP)
               PERFORM  5420-CALCULATE-FOLLOW-UP
                   THRU 5420-CALCULATE-FOLLOW-UP-X
           ELSE
               PERFORM  5440-EDIT-FUP-NUMBER
                   THRU 5440-EDIT-FUP-NUMBER-X
               PERFORM  5460-EDIT-FUP-DATE
                   THRU 5460-EDIT-FUP-DATE-X
           END-IF.

023520
023520*** PAC ACCOUNTHOLDER NAME MUST BE VALID
023520
023520     IF MIR-REQIR-ID = "PAC  "
023520     AND MIR-CPREQ-STAT-CD = "RAC"
023520         PERFORM  5470-CHECK-ACCT-HLDR-NM
023520             THRU 5470-CHECK-ACCT-HLDR-NM-X
023520     END-IF.
023520
      ***  VALIDITY DATE.

           IF (MIR-CPREQ-VALID-DT = SPACES) AND
              (WS-CALC-VALIDITY-DATE)
               PERFORM  5480-CALCULATE-VALIDITY-DATE
                   THRU 5480-CALCULATE-VALIDITY-DATE-X
           ELSE
               PERFORM  5500-EDIT-VALIDITY-DATE
                   THRU 5500-EDIT-VALIDITY-DATE-X
           END-IF.

      ***  DESIGNATION FIELD - LAB CODE WILL BE DEFAULTED FOR LAB
      ***  REQUIREMENTS IF NOTHING WAS ENTERED
           IF  MIR-CPREQ-DESGNT-ID      =  SPACES
           AND RREQT-CPREQ-DESGNT-ID    =  SPACES
           AND RRTAB-LAB-ID        NOT  =  SPACES
               MOVE RRTAB-LAB-ID      TO RREQT-CPREQ-DESGNT-ID
               MOVE RRTAB-LAB-ID      TO MIR-CPREQ-DESGNT-ID
           END-IF.


      ***  PAID  INDICATOR.

           IF  MIR-CPREQ-PD-IND         =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CPREQ-PD-IND
               MOVE SPACES            TO RREQT-CPREQ-PD-IND
               GO TO 5300-EDIT-DATA-FIELDS-X
           END-IF.

           IF  MIR-CPREQ-PD-IND = SPACES
               MOVE RREQT-CPREQ-PD-IND  TO MIR-CPREQ-PD-IND
           ELSE
               MOVE MIR-CPREQ-PD-IND  TO RREQT-CPREQ-PD-IND
           END-IF.

       5300-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      ****************************************************************
      *   FETCH REQUIREMENT TABLE RECORD.
      *   THE RTAB RECORD IS FETCH AND AN INDICATOR SET TO INDICATE
      *   STATUS.
      ****************************************************************
       5310-FETCH-RTAB.


      ***  FETCH RTAB RECORD.

           MOVE MIR-REQIR-ID          TO WRTAB-REQIR-ID.

           PERFORM  RTAB-1000-READ
               THRU RTAB-1000-READ-X.

           MOVE 'Y'                   TO WS-RTAB-READ-IND.

           IF  WRTAB-IO-NOT-FOUND
               MOVE MIR-REQIR-ID      TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-RTAB-READ-IND
           END-IF.

       5310-FETCH-RTAB-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT REQUIREMENT STATUS.
      ****************************************************************
       5320-EDIT-REQT-STATUS.


      ***  SAVE OLD STATUS & INIT FLAGS.

           MOVE RREQT-CPREQ-STAT-CD   TO WS-OLD-STATUS-CODE.
           MOVE 'N'                   TO WS-NEW-STATUS-CODE-IND.
           MOVE 'N'                   TO WS-FUP-UPDATE.


      ***  RESTORE FILE VALUE.

           IF  MIR-CPREQ-STAT-CD      =  SPACES
               MOVE RREQT-CPREQ-STAT-CD
                                      TO MIR-CPREQ-STAT-CD
               GO TO 5320-EDIT-REQT-STATUS-X
           END-IF.


      ***  HANDLE DELETION.

           IF  MIR-CPREQ-STAT-CD      =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CPREQ-STAT-CD
           END-IF.

           MOVE  MIR-CPREQ-STAT-CD    TO   WS-EDIT-STATUS-CODE.


      ***  SYSTEM SUGGESTED STATUS CODES CANNOT BE USED

           IF  WS-SYSTEM-STATUS-CODE
016717     AND MIR-CPREQ-STAT-CD NOT = WS-OLD-STATUS-CODE
               MOVE 'NS00900057'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   MOVE 'N'           TO WS-EDITS-OK-SW
                   GO TO 5320-EDIT-REQT-STATUS-X
               END-IF

           END-IF.


      ***  EDIT STATUS CODE.

           IF  NOT VALID-STATUS-CODE
               MOVE MIR-CPREQ-STAT-CD TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'NS00900020'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 5320-EDIT-REQT-STATUS-X
           END-IF.


      ***  DIARY LOG.

           IF (WS-OLD-STATUS-CODE NOT = MIR-CPREQ-STAT-CD)
               MOVE MIR-CPREQ-STAT-CD TO L0760-DAL-ACTION
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.


      ***  UPDATE RECORD & SET SWITCH.

           MOVE 'Y'                   TO WS-NEW-STATUS-CODE-IND.
           MOVE MIR-CPREQ-STAT-CD     TO RREQT-CPREQ-STAT-CD.
           IF WS-OLD-STATUS-CODE NOT =  RREQT-CPREQ-STAT-CD
               MOVE 'Y'               TO WS-FUP-UPDATE
           END-IF.

       5320-EDIT-REQT-STATUS-X.
           EXIT.
      /
      ****************************************************************
      *   SET / EDIT REQUIREMENT STATUS DATE.
      *   DEFAULTS TO TODAY IF NOT GIVEN.  A FATALITY CHECK IS
      *   MADE IF THE STATUS DATE IS IN THE FUTURE.
      ****************************************************************
       5340-EDIT-REQT-STATUS-DATE.


      ***  NO CHANGE IF NEITHER STATUS CODE OR DATE UPDATED.

           IF (MIR-CPREQ-EFF-DT = SPACES) AND
              (WS-OLD-STATUS-CODE = MIR-CPREQ-STAT-CD)
      ***      CONVERT TO EXTERNAL FORMAT
               MOVE RREQT-CPREQ-EFF-DT TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X

               IF  L1640-VALID
                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CPREQ-EFF-DT
                   GO TO 5340-EDIT-REQT-STATUS-DATE-X
               END-IF

           END-IF.


      ***  USE TODAY IF STATUS DATE NOT CHANGED, OR DELETED.

           IF (MIR-CPREQ-EFF-DT = SPACES) OR
              (MIR-CPREQ-EFF-DT = EBLCH-BLANK-FIELD-CHAR)
               MOVE WGLOB-SYSTEM-DATE-INT
                                      TO RREQT-CPREQ-EFF-DT
               MOVE WS-EXTERNAL-START-DATE
                                      TO MIR-CPREQ-EFF-DT
               GO TO 5340-EDIT-REQT-STATUS-DATE-X
           END-IF.


      ***  CHECK DATE VALID.

           MOVE MIR-CPREQ-EFF-DT      TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.

026895*
026895*** WHEN STATUS CODE CHANGE, UPDATE THE STATUS EFFECTIVE DATE
026895*
026895     IF  WS-OLD-STATUS-CODE NOT  = RREQT-CPREQ-STAT-CD
026895         IF  L1640-VALID
026895         AND L1640-INTERNAL-DATE = RREQT-CPREQ-EFF-DT
026895             MOVE WGLOB-SYSTEM-DATE-INT TO RREQT-CPREQ-EFF-DT
026895             MOVE WGLOB-SYSTEM-DATE-INT TO L1640-INTERNAL-DATE
026895             PERFORM 1640-8000-INTERNAL-TO-MIR
026895                 THRU 1640-8000-INTERNAL-TO-MIR-X
026895             MOVE L1640-EXTERNAL-DATE TO MIR-CPREQ-EFF-DT
026895             GO TO 5340-EDIT-REQT-STATUS-DATE-X
026895         END-IF
026895     END-IF.


           IF  L1640-NOT-VALID
               MOVE MIR-CPREQ-EFF-DT  TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 5340-EDIT-REQT-STATUS-DATE-X
           END-IF.


      ***  CHECK NOT IN FUTURE.

           IF  L1640-INTERNAL-DATE    >  WGLOB-SYSTEM-DATE-INT
               MOVE MIR-CPREQ-EFF-DT  TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900022'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               IF  WGLOB-MSG-SEVRTY-FATAL
                   MOVE 'N'           TO WS-EDITS-OK-SW
                   GO TO 5340-EDIT-REQT-STATUS-DATE-X
               END-IF

           END-IF.


      ***  DIARY LOG.

           MOVE L1640-INTERNAL-DATE   TO WS-TEMP-DATE.
           IF (L1640-INTERNAL-DATE    NOT  =  RREQT-CPREQ-EFF-DT)
               MOVE 'UPDT'            TO L0760-DAL-ACTION
557756*        PERFORM  1640-2000-INTERNAL-TO-EXT
557756*            THRU 1640-2000-INTERNAL-TO-EXT-X
557756*        MOVE L1640-EXTERNAL-DATE    TO L0760-MESSAGE-PARMS (2)
557756         MOVE L1640-INTERNAL-DATE
                                      TO L0760-MESSAGE-PARMS (2)
557756*        MOVE RREQT-CPREQ-EFF-DT     TO L1640-INTERNAL-DATE
557756*        PERFORM  1640-2000-INTERNAL-TO-EXT
557756*            THRU 1640-2000-INTERNAL-TO-EXT-X
557756*        MOVE L1640-EXTERNAL-DATE    TO L0760-MESSAGE-PARMS (1)
557756         MOVE RREQT-CPREQ-EFF-DT        TO L0760-MESSAGE-PARMS (1)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.


      ***  UPDATE RECORD.

           MOVE WS-TEMP-DATE          TO RREQT-CPREQ-EFF-DT.

       5340-EDIT-REQT-STATUS-DATE-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT USER ID:
      *   MUST BE (A) LOGON USER, (B) 'AGENT' OR (C) VALID USER ID.
      *   BOTH (B) AND (C) GENERATE A WARN/FATAL MESSAGE.
      ****************************************************************
       5360-EDIT-USER-ID.


      ***  DEFAULTS TO LOGON USER.

           IF (MIR-USER-ID = SPACES) OR
              (MIR-USER-ID = EBLCH-BLANK-FIELD-CHAR)
016062     OR (MIR-USER-ID = RREQT-USER-ID)
               MOVE WGLOB-USER-ID     TO MIR-USER-ID
               MOVE WGLOB-USER-ID     TO RREQT-USER-ID
               GO TO 5360-EDIT-USER-ID-X
           END-IF.


      ***  OWN USER ID IS OK.

           IF  MIR-USER-ID            =  WGLOB-USER-ID
               GO TO 5360-EDIT-USER-ID-X
           END-IF.


      ***  CHECK VALIDITY.

           IF  MIR-USER-ID            =  'AGENT'
               MOVE WGLOB-USER-ID     TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE  MIR-USER-ID      TO L0220-USER-ID
               MOVE  WGLOB-COMPANY-CODE
                                      TO L0220-COMPANY-CODE
014590*        MOVE  WGLOB-APPL-ID    TO L0220-APPL-ID
               PERFORM  0220-1000-VERIFY-USER-ID
                   THRU 0220-1000-VERIFY-USER-ID-X
               MOVE MIR-USER-ID       TO WGLOB-MSG-PARM (1)

               IF  L0220-USER-OK
                   MOVE WGLOB-USER-ID TO WGLOB-MSG-PARM (2)
                   MOVE 'NS00900056'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE 'NS00900024'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF

           END-IF.


      ***  HANDLE FATAL TYPE ERROR.

           IF  WGLOB-MSG-SEVRTY-FATAL
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 5360-EDIT-USER-ID-X
           END-IF.


      ***  UPDATE RECORD & DIARY LOG.

           MOVE MIR-USER-ID           TO RREQT-USER-ID.
           MOVE 'UPDT'                TO L0760-DAL-ACTION.
           MOVE 'NS0090'              TO L0760-MSG-SRCE.
           MOVE '0026'                TO L0760-MSG-NUMBER.
           MOVE WGLOB-USER-ID         TO L0760-MESSAGE-PARMS (1).
           MOVE MIR-USER-ID           TO L0760-MESSAGE-PARMS (2).
           PERFORM  7000-WRITE-DALG
               THRU 7000-WRITE-DALG-X.

       5360-EDIT-USER-ID-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT DESIGNATION.
      ****************************************************************
       5370-EDIT-DESIGNATION.

016039     SET  WS-VALID-LAB-CODE-NOTFND TO TRUE.


      ***  RESTORE FILE VALUE.

           IF  MIR-CPREQ-DESGNT-ID    =  SPACES
               MOVE RREQT-CPREQ-DESGNT-ID
                                      TO MIR-CPREQ-DESGNT-ID
               GO TO 5370-EDIT-DESIGNATION-X
           END-IF.


      ***  HANDLE DELETION.

           IF  MIR-CPREQ-DESGNT-ID    =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CPREQ-DESGNT-ID
               MOVE SPACES            TO RREQT-CPREQ-DESGNT-ID
               GO TO 5370-EDIT-DESIGNATION-X
           END-IF.

           MOVE MIR-CPREQ-DESGNT-ID   TO WEDIT-ETBL-VALU-ID.
           PERFORM  LABC-1000-EDIT-LAB-CODE
               THRU LABC-1000-EDIT-LAB-CODE-X.

           IF  WEDIT-IO-OK
               MOVE 'Y'               TO WS-VALID-LAB-CODE-IND
           ELSE
               MOVE 'N'               TO WS-VALID-LAB-CODE-IND
           END-IF.


      *  ONLY PERFORM EDIT WHEN A LAB CODE FOUND ON RTAB RECORD

           IF  RRTAB-LAB-ID           NOT  =  SPACES

              IF  NOT WEDIT-IO-OK
                   MOVE 'N'           TO WS-EDITS-OK-SW
                   MOVE 'NS00900060'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 5370-EDIT-DESIGNATION-X
               END-IF

           END-IF.


      ***  DIARY LOG.

           IF (MIR-CPREQ-DESGNT-ID NOT = RREQT-CPREQ-DESGNT-ID)
               MOVE 'UPDT'            TO L0760-DAL-ACTION
               MOVE 'NS0090'          TO L0760-MSG-SRCE
               MOVE '0027'            TO L0760-MSG-NUMBER
               MOVE RREQT-CPREQ-DESGNT-ID
                                      TO L0760-MESSAGE-PARMS (1)
               MOVE MIR-CPREQ-DESGNT-ID
                                      TO L0760-MESSAGE-PARMS (2)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.


      ***  UPDATE RECORD.

           MOVE MIR-CPREQ-DESGNT-ID   TO RREQT-CPREQ-DESGNT-ID.

       5370-EDIT-DESIGNATION-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT TEST DATE.
      *   IF TEST DATE IS DELETED, THE VALIDITY DATE WILL ALSO BE
      *   DELETED.  GIVE WARNING IF REQUIREMENT NOT AT LEAST ORDERED
      *   YET.  CHECK FATALITY IF TEST DATE IS IN THE FUTURE.
      ****************************************************************
       5380-EDIT-TEST-DATE.

           MOVE 'N'                   TO WS-TEST-DATE-UPDATE-IND.

           IF  MIR-CPREQ-TST-DT       =  SPACES
               MOVE RREQT-CPREQ-TST-DT   TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CPREQ-TST-DT
           END-IF.


      ***  HANDLE DELETION.

           IF  MIR-CPREQ-TST-DT       =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CPREQ-TST-DT
               MOVE SPACES            TO MIR-CPREQ-VALID-DT
               MOVE 'UPDT'            TO L0760-DAL-ACTION
               MOVE 'NS0090'          TO L0760-MSG-SRCE
               MOVE '0031'            TO L0760-MSG-NUMBER
557756*        MOVE RREQT-CPREQ-TST-DT     TO L1640-INTERNAL-DATE
557756*        PERFORM  1640-2000-INTERNAL-TO-EXT
557756*            THRU 1640-2000-INTERNAL-TO-EXT-X
557756*        MOVE L1640-EXTERNAL-DATE    TO L0760-MESSAGE-PARMS (1)
557756         MOVE RREQT-CPREQ-TST-DT     TO L0760-MESSAGE-PARMS (1)
               MOVE MIR-CPREQ-TST-DT  TO L0760-MESSAGE-PARMS (2)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
               MOVE WWKDT-ZERO-DT     TO RREQT-CPREQ-TST-DT
               MOVE WWKDT-ZERO-DT     TO RREQT-CPREQ-VALID-DT
               MOVE 'Y'               TO WS-TEST-DATE-UPDATE-IND

               IF  WS-RECEIVED-STATUS
                   MOVE 'NS00900058'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 5380-EDIT-TEST-DATE-X
               ELSE
                   GO TO 5380-EDIT-TEST-DATE-X
               END-IF

           END-IF.


      ***  WHEN STATUS GOES TO RECEIVED, WAIVED OR CANCELLED THEN IF
      ***  DATE CONTAINS SPACES, DEFAULT IT TO CURRENT DATE

           IF  MIR-CPREQ-TST-DT = SPACES

               IF  WS-NEW-STATUS-OK
               AND (WS-RECEIVED-STATUS
               OR  WS-WAIVED-CANCELLED)
                   MOVE WGLOB-SYSTEM-DATE-INT
                                      TO L1640-INTERNAL-DATE
020462*            PERFORM  1640-2000-INTERNAL-TO-EXT
020462*                THRU 1640-2000-INTERNAL-TO-EXT-X
020462             PERFORM 1640-8000-INTERNAL-TO-MIR
020462                THRU 1640-8000-INTERNAL-TO-MIR-X
                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CPREQ-TST-DT
               END-IF

           END-IF.


      ***  IF DATE IS BLANK THEN EXIT.

           IF  MIR-CPREQ-TST-DT = SPACES
               GO TO 5380-EDIT-TEST-DATE-X
           END-IF.


      ***  EXPECT STATUS TO BE ORDERED OR BETTER IF DATE ENTERED.

           IF  WS-NEW-STATUS-OK

               IF  RREQT-CPREQ-STAT-WANTED
               OR  RREQT-CPREQ-STAT-ORDERED
                   MOVE 'NS00900028'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

                   IF  WGLOB-MSG-SEVRTY-FATAL
                       MOVE 'N'       TO WS-EDITS-OK-SW
                       GO TO 5380-EDIT-TEST-DATE-X
                   END-IF

                END-IF

           END-IF.


      ***  CHECK VALIDITY.

           MOVE MIR-CPREQ-TST-DT      TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO WS-TEMP-DATE
           ELSE
               MOVE MIR-CPREQ-TST-DT  TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900029'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 5380-EDIT-TEST-DATE-X
           END-IF.


      ***  CHECK NOT IN FUTURE.

           IF  L1640-INTERNAL-DATE    >  WGLOB-SYSTEM-DATE-INT
               MOVE MIR-CPREQ-TST-DT  TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900030'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 'N'           TO WS-EDITS-OK-SW
                   GO TO 5380-EDIT-TEST-DATE-X
               END-IF

           END-IF.


      ***  DIARY LOG ENTRY FOR TEST DATE.

           IF (WS-TEMP-DATE NOT = RREQT-CPREQ-TST-DT)
               MOVE 'UPDT'            TO L0760-DAL-ACTION
               MOVE 'NS0090'          TO L0760-MSG-SRCE
               MOVE '0031'            TO L0760-MSG-NUMBER
557756*        MOVE RREQT-CPREQ-TST-DT       TO L1640-INTERNAL-DATE
557756*        PERFORM  1640-2000-INTERNAL-TO-EXT
557756*            THRU 1640-2000-INTERNAL-TO-EXT-X
557756*        MOVE L1640-EXTERNAL-DATE      TO L0760-MESSAGE-PARMS (1)
557756         MOVE RREQT-CPREQ-TST-DT       TO L0760-MESSAGE-PARMS (1)
557756*        MOVE MIR-CPREQ-TST-DT         TO L0760-MESSAGE-PARMS (2)
557756         MOVE WS-TEMP-DATE      TO L0760-MESSAGE-PARMS (2)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.


      ***  UPDATE RECORD.

           MOVE WS-TEMP-DATE          TO RREQT-CPREQ-TST-DT.
           MOVE 'Y'                   TO WS-TEST-DATE-UPDATE-IND.

       5380-EDIT-TEST-DATE-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT TEST RESULT:
      *   GIVE WARNING IF REQUIREMENT NOT AT LEAST ORDERED YET.
      *   LOOKUP RESULT ON THE EDIT TABLE.
      ****************************************************************
       5400-EDIT-TEST-RESULT.

           IF  MIR-CPREQ-TST-RSLT-CD = SPACES
               MOVE RREQT-CPREQ-TST-RSLT-CD
                                      TO MIR-CPREQ-TST-RSLT-CD
               GO TO 5400-EDIT-TEST-RESULT-X
           END-IF.


      ***  HANDLE DELETION.

           IF  MIR-CPREQ-TST-RSLT-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CPREQ-TST-RSLT-CD
               MOVE SPACES            TO RREQT-CPREQ-TST-RSLT-CD
               GO TO 5400-EDIT-TEST-RESULT-X
           END-IF.


      ***  EXPECT STATUS TO BE ORDERED OR BETTER.

           IF  WS-NEW-STATUS-OK
           AND RREQT-CPREQ-STAT-WANTED
               MOVE 'NS00900028'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               IF  WGLOB-MSG-SEVRTY-FATAL
                   MOVE 'N'           TO WS-EDITS-OK-SW
                   GO TO 5400-EDIT-TEST-RESULT-X
               END-IF

           END-IF.


      ***  LOOKUP ON EDIT TABLE.

           MOVE MIR-CPREQ-TST-RSLT-CD TO WEDIT-ETBL-VALU-ID.
           PERFORM  RESL-1000-EDIT-TEST-RESULT
               THRU RESL-1000-EDIT-TEST-RESULT-X.
           IF  WEDIT-IO-OK
               MOVE SPACES            TO REDIT-ETBL-DESC-TXT
               PERFORM RESL-2000-DESC
                  THRU RESL-2000-DESC-X
           ELSE
               MOVE MIR-CPREQ-TST-RSLT-CD
                                      TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900032'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 5400-EDIT-TEST-RESULT-X
           END-IF.


      ***  DIARY LOG.

           IF (MIR-CPREQ-TST-RSLT-CD NOT = RREQT-CPREQ-TST-RSLT-CD)
               MOVE 'UPDT'            TO L0760-DAL-ACTION
               MOVE 'NS0090'          TO L0760-MSG-SRCE
               MOVE '0033'            TO L0760-MSG-NUMBER
               MOVE RREQT-CPREQ-TST-RSLT-CD
                                      TO L0760-MESSAGE-PARMS (1)
               MOVE MIR-CPREQ-TST-RSLT-CD
                                      TO L0760-MESSAGE-PARMS (2)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.


      ***  UPDATE RECORD.

           MOVE MIR-CPREQ-TST-RSLT-CD TO RREQT-CPREQ-TST-RSLT-CD.

       5400-EDIT-TEST-RESULT-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT RESULTS-IND:
      *   NEW RESULTS INDICATOR MUST BE 'Y' OR 'N' (YES/NO). DETERMINES
      *   WHETHER OR NOT OLD RESULTS CAN BE USED TO RESOLVE THE REQT.
      *   OLD RESULTS ARE LAB TESTS CREATED BEFORE THE REQT WAS
      *   ORDERED.
      ****************************************************************
       5405-EDIT-RESULTS-IND.

           IF  MIR-CPREQ-NEW-RSLT-IND = SPACES
               MOVE RREQT-CPREQ-NEW-RSLT-IND
                                      TO MIR-CPREQ-NEW-RSLT-IND
               GO TO 5405-EDIT-RESULTS-IND-X
           END-IF.

      ***  HANDLE DELETION.
           IF MIR-CPREQ-NEW-RSLT-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CPREQ-NEW-RSLT-IND
           END-IF.

      ***  ONLY 'Y' OR 'N' ARE ACCEPTED.
           MOVE MIR-CPREQ-NEW-RSLT-IND   TO WS-YES-NO-VALID-SW.
           IF  WS-YES-NO-VALID
               CONTINUE
           ELSE
               MOVE 'NS00900062'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 5405-EDIT-RESULTS-IND-X
           END-IF.

      ***  DIARY LOG.
           IF (MIR-CPREQ-NEW-RSLT-IND NOT = RREQT-CPREQ-NEW-RSLT-IND)
               MOVE 'UPDT'            TO L0760-DAL-ACTION
               MOVE 'NS0090'          TO L0760-MSG-SRCE
               MOVE '0061'            TO L0760-MSG-NUMBER
               MOVE RREQT-CPREQ-NEW-RSLT-IND
                                      TO L0760-MESSAGE-PARMS (1)
               MOVE MIR-CPREQ-NEW-RSLT-IND
                                      TO L0760-MESSAGE-PARMS (2)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.


      ***  UPDATE RECORD.
           MOVE MIR-CPREQ-NEW-RSLT-IND  TO RREQT-CPREQ-NEW-RSLT-IND.


      *  THE FOLLOWING EDIT WAS ORIGINALLY IN THE CROSS EDITS SECTION.
      *  IT IS NOW HERE TO POSITION THE CURSOR WHEN THE EDIT FAILS.

           IF  RREQT-CPREQ-NEW-RSLT-ONLY
           AND RRTAB-LAB-ID   = SPACES
               MOVE 'NS00900064'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 5405-EDIT-RESULTS-IND-X
           END-IF.

       5405-EDIT-RESULTS-IND-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT RESOLVE IND:
      *   THE RESOLVE INDICATOR MUST BE 'Y' OR 'N'. THIS FIELD IS
      *   USED TO TRIGGER THE REQUIREMENT RESOLUTION PROCESSING.
      ****************************************************************
       5410-EDIT-RESOLVE-IND.

           IF  MIR-DV-REVW-REQIR-IND = SPACES
               MOVE 'N'               TO MIR-DV-REVW-REQIR-IND
               GO TO 5410-EDIT-RESOLVE-IND-X
           END-IF.

      ***  HANDLE DELETION.
           IF  MIR-DV-REVW-REQIR-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE 'N'               TO MIR-DV-REVW-REQIR-IND
           END-IF.

      ***  ONLY 'Y' OR 'N' ARE ACCEPTED.
           MOVE MIR-DV-REVW-REQIR-IND TO WS-YES-NO-VALID-SW.
           IF  WS-YES-NO-VALID
               CONTINUE
           ELSE
               MOVE 'NS00900063'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 5410-EDIT-RESOLVE-IND-X
           END-IF.

       5410-EDIT-RESOLVE-IND-X.
           EXIT.
      /
      ****************************************************************
      *   CALCULATE FOLLOW UP DETAILS:
      *   USER HAS NOT SUPPLIED FOLLOW-UP DETAILS, SO CALCULATE
      *   THE FIRST FOLLOW-UP AUTOMATICALLY.  WARNINGS WILL BE
      *   GENERATED IF THE FOLLOW-UP DATE IS PAST THE FINAL
      *   DISPOSITION WARNING DATE.
      ****************************************************************
       5420-CALCULATE-FOLLOW-UP.


      ***  IF NOT CHANGED TO ORDERED, CLEAR ANY FOLLOWUP INFORMATION.

           IF  RREQT-CPREQ-STAT-ORDERED
           AND WS-RTAB-AVAILABLE
               CONTINUE
           ELSE
               MOVE ZEROS             TO RREQT-CPREQ-FOLWUP-NUM
               MOVE SPACES            TO MIR-CPREQ-FOLWUP-NUM
               MOVE WWKDT-ZERO-DT     TO RREQT-CPREQ-FOLWUP-DT
               MOVE SPACES            TO MIR-CPREQ-FOLWUP-DT
               GO TO 5420-CALCULATE-FOLLOW-UP-X
           END-IF.


      ***  REQUIREMENT JUST ORDERED, CALCULATE FIRST FOLLOWUP.

           MOVE 1                     TO RREQT-CPREQ-FOLWUP-NUM.
           PERFORM  RFUP-1000-SET-FOLLOWUP
               THRU RFUP-1000-SET-FOLLOWUP-X.


      ***  CHECK AGAINST FINAL DISPOSITION DATE.

           PERFORM  7500-CHECK-FINAL-DISP
               THRU 7500-CHECK-FINAL-DISP-X.


      ***  UPDATE SCREEN FIELDS.

020874*    MOVE RREQT-CPREQ-FOLWUP-NUM                      TO WS-PIC-Z.
020874*    MOVE WS-PIC-Z              TO MIR-CPREQ-FOLWUP-NUM.
020874     MOVE RREQT-CPREQ-FOLWUP-NUM  TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CPREQ-FOLWUP-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CPREQ-FOLWUP-NUM.

           MOVE RREQT-CPREQ-FOLWUP-DT TO L1640-INTERNAL-DATE.
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
           IF  L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CPREQ-FOLWUP-DT
           END-IF.

       5420-CALCULATE-FOLLOW-UP-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT FOLLOW-UP NUMBER:
      *   USER HAS ENTERED SOME OR ALL OF THE FOLLOW-UP DETAILS.
      *   CHECK FOLLOW-UP NUMBER FOR VALIDITY.  NOTE THAT FOLLOW-UP
      *   DETAILS ARE PERMITTED EVEN IN THE RTAB RECORD DOES NOT
      *   CURRENTLY EXIST.
      ****************************************************************
       5440-EDIT-FUP-NUMBER.

           MOVE 'Y'                   TO WS-FUP-NUMBER-EDIT-IND.


      ***  REDISPLAY IF NOT UPDATED.

           IF  MIR-CPREQ-FOLWUP-NUM = SPACES
020874*        MOVE RREQT-CPREQ-FOLWUP-NUM
020874*                               TO WS-PIC-Z
020874*        MOVE WS-PIC-Z          TO MIR-CPREQ-FOLWUP-NUM
020874         MOVE RREQT-CPREQ-FOLWUP-NUM  TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CPREQ-FOLWUP-NUM
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CPREQ-FOLWUP-NUM
               GO TO 5440-EDIT-FUP-NUMBER-X
           END-IF.


      ***  HANDLE DELETION.

           IF  MIR-CPREQ-FOLWUP-NUM = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CPREQ-FOLWUP-NUM
               MOVE ZEROS             TO RREQT-CPREQ-FOLWUP-NUM
               GO TO 5440-EDIT-FUP-NUMBER-X
           END-IF.


      ***  EXIT IF NOT GIVEN & NOT ON RECORD.

           IF  MIR-CPREQ-FOLWUP-NUM = SPACES
               MOVE ZERO              TO RREQT-CPREQ-FOLWUP-NUM
               GO TO 5440-EDIT-FUP-NUMBER-X
           END-IF.


      ***  CHECK NUMERIC.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 1                     TO L0280-LENGTH.
           MOVE 1                     TO L0280-INPUT-SIZE.
           MOVE MIR-CPREQ-FOLWUP-NUM  TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               CONTINUE
           ELSE
               MOVE MIR-CPREQ-FOLWUP-NUM
                                      TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-FUP-NUMBER-EDIT-IND
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 5440-EDIT-FUP-NUMBER-X
           END-IF.


      ***  CHECK VALID RANGE.

           MOVE MIR-CPREQ-FOLWUP-NUM  TO WS-EDIT-FOLLOWUP-NO
           IF  NOT VALID-FOLLOWUP-NO
               MOVE MIR-CPREQ-FOLWUP-NUM
                                      TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900035'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-FUP-NUMBER-EDIT-IND
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 5440-EDIT-FUP-NUMBER-X
           END-IF.


      ***  CHECK WITHIN DEFINED FOLLOW-UPS.

           IF  WS-RTAB-AVAILABLE
               MOVE MIR-CPREQ-FOLWUP-NUM
                                      TO WS-SUB

               IF  RRTAB-FOLWUP-DY-DUR  (WS-SUB) = ZERO
                   MOVE MIR-CPREQ-FOLWUP-NUM
                                      TO WGLOB-MSG-PARM (1)
                   MOVE RRTAB-REQIR-ID
                                      TO WGLOB-MSG-PARM (2)
                   MOVE 'NS00900036'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE ZERO          TO RREQT-CPREQ-FOLWUP-NUM
                   MOVE SPACE         TO MIR-CPREQ-FOLWUP-NUM
                   GO TO 5440-EDIT-FUP-NUMBER-X
               END-IF

           END-IF.


      ***  DIARY LOG.

           IF (MIR-CPREQ-FOLWUP-NUM NOT = RREQT-CPREQ-FOLWUP-NUM)
               MOVE 'UPDT'            TO L0760-DAL-ACTION
               MOVE 'NS0090'          TO L0760-MSG-SRCE
               MOVE '0037'            TO L0760-MSG-NUMBER
               MOVE RREQT-CPREQ-FOLWUP-NUM
                                      TO L0760-MESSAGE-PARMS (1)
               MOVE MIR-CPREQ-FOLWUP-NUM
                                      TO L0760-MESSAGE-PARMS (2)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.


      ***  UPDATE RECORD.
      *    CONVERT MIR-CPREQ-FOLWUP-NUM  TO NUMERIC.
           MOVE MIR-CPREQ-FOLWUP-NUM  TO RREQT-CPREQ-FOLWUP-NUM.

       5440-EDIT-FUP-NUMBER-X.
           EXIT.
      /
      ****************************************************************
      *   EDIT FOLLOW-UP DATE:
      *   USER HAS ENTERED SOME OR ALL OF THE FOLLOW-UP DETAILS.
      *   CHECK FOLLOW-UP DATE FOR VALIDITY.  IF A FOLLOW-UP NUMBER HAS
      *   BEEN GIVEN, AND NO DATE IS KNOWN, IT WILL BE CALCULATED.
      *   IF THE FOLLOW-UP DATE (ENTERED OR CALCULATED) IS BEFORE TODAY,
      *   FATALITY WILL BE CHECKED.  WARNINGS WILL BE GENERATED IF THE
      *   FOLLOW-UP DATE IS PAST THE FINAL DISPOSITION WARNING DATE.
      ****************************************************************
       5460-EDIT-FUP-DATE.

      ***  HANDLE ENTIRE FOLLOW-UP DELETION.
           IF  WS-FUP-NUMBER-EDIT-OK AND
              (RREQT-CPREQ-FOLWUP-NUM = ZERO)
               MOVE SPACES            TO MIR-CPREQ-FOLWUP-DT
               MOVE WWKDT-ZERO-DT     TO RREQT-CPREQ-FOLWUP-DT
               GO TO 5460-EDIT-FUP-DATE-X
           END-IF.

      ***  RESTORE FILE VALUE.
           IF  MIR-CPREQ-FOLWUP-DT = SPACES
               MOVE RREQT-CPREQ-FOLWUP-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X

               IF  L1640-VALID
                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CPREQ-FOLWUP-DT
               END-IF

           END-IF.

      ***  HANDLE FIELD DELETION.
           IF  MIR-CPREQ-FOLWUP-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CPREQ-FOLWUP-DT
               MOVE WWKDT-ZERO-DT     TO RREQT-CPREQ-FOLWUP-DT
           END-IF.

      ***  HANDLE BLANK VALUE.

           IF (MIR-CPREQ-FOLWUP-DT = SPACES)

               IF  WS-FUP-NUMBER-EDIT-OK
               AND WS-RTAB-AVAILABLE
                   PERFORM  RFUP-1000-SET-FOLLOWUP
                       THRU RFUP-1000-SET-FOLLOWUP-X
                   PERFORM  7500-CHECK-FINAL-DISP
                       THRU 7500-CHECK-FINAL-DISP-X
                   GO TO 5460-EDIT-FUP-DATE-X
               ELSE
                   GO TO 5460-EDIT-FUP-DATE-X
               END-IF

           END-IF.

      ***  CHECK VALIDITY.
           MOVE MIR-CPREQ-FOLWUP-DT   TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO WS-TEMP-DATE
           ELSE
               MOVE MIR-CPREQ-FOLWUP-DT
                                      TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900038'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 5460-EDIT-FUP-DATE-X
           END-IF.

      ***  WARN USER IF FOLLOW-UP ALREADY PAST.
           IF  L1640-INTERNAL-DATE < WGLOB-SYSTEM-DATE-INT
               MOVE MIR-CPREQ-FOLWUP-DT
                                      TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900039'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               IF  WGLOB-MSG-SEVRTY-FATAL
                   MOVE 'N'           TO WS-EDITS-OK-SW
                   GO TO 5460-EDIT-FUP-DATE-X
               END-IF

           END-IF.

      ***  DIARY LOG.
           IF (WS-TEMP-DATE NOT = RREQT-CPREQ-FOLWUP-DT)
               MOVE 'UPDT'            TO L0760-DAL-ACTION
               MOVE 'NS0090'          TO L0760-MSG-SRCE
               MOVE '0040'            TO L0760-MSG-NUMBER
557756*        MOVE RREQT-CPREQ-FOLWUP-DT TO L1640-INTERNAL-DATE
557756*        PERFORM  1640-2000-INTERNAL-TO-EXT
557756*            THRU 1640-2000-INTERNAL-TO-EXT-X
557756*        MOVE L1640-EXTERNAL-DATE  TO L0760-MESSAGE-PARMS (1)
557756         MOVE RREQT-CPREQ-FOLWUP-DT
                                      TO L0760-MESSAGE-PARMS (1)
557756*        MOVE MIR-CPREQ-FOLWUP-DT  TO L0760-MESSAGE-PARMS (2)
557756         MOVE WS-TEMP-DATE      TO L0760-MESSAGE-PARMS (2)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.

      ***  UPDATE RECORD.
           MOVE WS-TEMP-DATE          TO RREQT-CPREQ-FOLWUP-DT.

      ***  CHECK AGAINST FINAL DISPOSITION DATE.
           PERFORM  7500-CHECK-FINAL-DISP
               THRU 7500-CHECK-FINAL-DISP-X.

       5460-EDIT-FUP-DATE-X.
           EXIT.
023520
023520 5470-CHECK-ACCT-HLDR-NM.
023520     MOVE ZERO                     TO I.
023520
023520     PERFORM  2430-1000-BUILD-PARM-INFO
023520         THRU 2430-1000-BUILD-PARM-INFO-X.
023520
023520     PERFORM  2430-2200-GET-PAYOR
023520         THRU 2430-2200-GET-PAYOR-X.
023520
023520     IF  NOT L2430-RETRN-OK
023520         GO TO 5470-CHECK-ACCT-HLDR-NM-X
023520     END-IF.
023520
023520     IF  L2430-RELATIONSHIP-FOUND
023520     AND L2430-CLI-ID > SPACES
023520     AND L2430-ACCT-NUM NOT = ZEROS
023520         PERFORM  5475-GET-PAC-BANK-INFO
023520             THRU 5475-GET-PAC-BANK-INFO-X
023520     END-IF.
023520
023520 5470-CHECK-ACCT-HLDR-NM-X.
023520     EXIT.
023520
023520 5475-GET-PAC-BANK-INFO.
023520*----------------------------
023520
023520*
023520* THIS ROUTINE WILL ATTEMPT TO RETRIEVE THE EXACT
023520* BANK ACCOUNT USED BY THE PAC PAYOR CLIENT.
023520*
023520
023520     PERFORM  5020-1000-BUILD-PARM-INFO
023520         THRU 5020-1000-BUILD-PARM-INFO-X.
023520
023520     MOVE L2430-CLI-ID                        TO L5020-CLI-ID.
023520     MOVE L2430-ACCT-NUM                      TO L5020-PAC-NUM.
023520     SET L5020-BANK-QTY-ONE                   TO TRUE.
023520
023520     PERFORM  5020-2000-GET-SPECIFIC-BANK
023520         THRU 5020-2000-GET-SPECIFIC-BANK-X.
023520
023520     IF  NOT L5020-RETRN-OK
023520         GO TO 5475-GET-PAC-BANK-INFO-X
023520     ELSE
023520         IF  L5020-BNK-ACCT-HLDR-NM (1) = SPACES
023520             MOVE 'NS00900042'      TO WGLOB-MSG-REF-INFO
023520             PERFORM  0260-1000-GENERATE-MESSAGE
023520                 THRU 0260-1000-GENERATE-MESSAGE-X
023520
023520             IF  WGLOB-MSG-SEVRTY-FATAL
023520                 MOVE 'N'           TO WS-EDITS-OK-SW
023520                 GO TO 5475-GET-PAC-BANK-INFO-X
023520             END-IF
023520         END-IF
023520     END-IF.
023520
023520
023520 5475-GET-PAC-BANK-INFO-X.
023520     EXIT.

      /
      ****************************************************************
      *   CALCULATE REQUIREMENT VALIDITY DATE:
      *   USER HAS NOT SUPPLIED THE VALIDITY DATE AND A VALID TEST DATE
      *   IS AVAILABLE, SO CALCULATE THE VALIDATY DATE AUTOMATICALLY.
      ****************************************************************
       5480-CALCULATE-VALIDITY-DATE.

      ***  CALCULATE NEW VALIDITY DATE (IF CAN)
           IF  WS-RTAB-AVAILABLE
               PERFORM  RVAL-1000-SET-REQT-VALIDITY
                   THRU RVAL-1000-SET-REQT-VALIDITY-X
           END-IF.

      ***  REDISPLAY VALIDITY DATE.
           IF  RREQT-CPREQ-VALID-DT   = WWKDT-ZERO-DT
               MOVE SPACES            TO MIR-CPREQ-VALID-DT
           ELSE
               MOVE RREQT-CPREQ-VALID-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CPREQ-VALID-DT
           END-IF.

       5480-CALCULATE-VALIDITY-DATE-X.
           EXIT.
      /
      ****************************************************************
      *  EDIT REQUIREMENT VALIDITY DATE:
      *  THE USER HAS ENTERED A REQUIREMENT VALIDITY DATE - CHECK VALID.
      ****************************************************************
       5500-EDIT-VALIDITY-DATE.

      ***  REDISPLAY IF BLANK.
           IF  MIR-CPREQ-VALID-DT = SPACES
               MOVE RREQT-CPREQ-VALID-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CPREQ-VALID-DT
               GO TO 5500-EDIT-VALIDITY-DATE-X
           END-IF.

      ***  FIELD DELETION.
           IF  MIR-CPREQ-VALID-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE WWKDT-ZERO-DT     TO RREQT-CPREQ-VALID-DT
               MOVE SPACES            TO MIR-CPREQ-VALID-DT

               IF  WS-RECEIVED-STATUS
                   MOVE 'NS00900059'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 5500-EDIT-VALIDITY-DATE-X
               ELSE
                   GO TO 5500-EDIT-VALIDITY-DATE-X
               END-IF

           END-IF.

      ***  CHECK PROPER DATE.
           MOVE MIR-CPREQ-VALID-DT    TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO WS-TEMP-DATE
           ELSE
               MOVE MIR-CPREQ-VALID-DT             TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900041'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 5500-EDIT-VALIDITY-DATE-X
           END-IF.

      ***  DIARY LOG.
           IF (WS-TEMP-DATE NOT = RREQT-CPREQ-VALID-DT)
               MOVE 'UPDT'            TO L0760-DAL-ACTION
               MOVE 'NS0090'          TO L0760-MSG-SRCE
               MOVE '0043'            TO L0760-MSG-NUMBER
557756*        MOVE RREQT-CPREQ-VALID-DT    TO L1640-INTERNAL-DATE
557756*        PERFORM  1640-2000-INTERNAL-TO-EXT
557756*            THRU 1640-2000-INTERNAL-TO-EXT-X
557756*        MOVE L1640-EXTERNAL-DATE     TO L0760-MESSAGE-PARMS (1)
557756         MOVE RREQT-CPREQ-VALID-DT
                                      TO L0760-MESSAGE-PARMS (1)
557756*        MOVE MIR-CPREQ-VALID-DT   TO L0760-MESSAGE-PARMS (2)
557756         MOVE WS-TEMP-DATE      TO L0760-MESSAGE-PARMS (2)
               PERFORM  7000-WRITE-DALG
                   THRU 7000-WRITE-DALG-X
           END-IF.

      ***  UPDATE RECORD.
           MOVE WS-TEMP-DATE          TO RREQT-CPREQ-VALID-DT.

       5500-EDIT-VALIDITY-DATE-X.
           EXIT.
      /
      ****************************************************************
      *  CROSS EDITS:                                                *
      *       PERFORM ANY NECESSARY CROSS EDITS.                     *
      ****************************************************************
       5600-CROSS-EDITS.

           IF  RRTAB-LAB-ID   = SPACES
           AND WS-VALID-LAB-CODE-FOUND
               MOVE 'NS00900067'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-CROSS-EDITS-OK-SW
           END-IF.

           IF  RRTAB-LAB-ID   NOT = SPACES
           AND RREQT-CPREQ-DESGNT-ID  = SPACES
               MOVE 'NS00900066'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-CROSS-EDITS-OK-SW
           END-IF.

           IF  MIR-DV-REVW-REQIR-IND = 'Y'
           AND RREQT-CPREQ-DESGNT-ID  = SPACES
               MOVE 'N'               TO MIR-DV-REVW-REQIR-IND
               MOVE 'NS00900065'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-CROSS-EDITS-OK-SW
           END-IF.

       5600-CROSS-EDITS-X.
           EXIT.
      /
       6000-PROCESS-DELETE.

           PERFORM  7800-BUILD-REQT-KEY
               THRU 7800-BUILD-REQT-KEY-X.
           PERFORM  REQT-1000-READ
               THRU REQT-1000-READ-X.
           IF  WREQT-IO-NOT-FOUND
               MOVE WREQT-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'NS00900016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

      ***  DISPLAY THE RECORD.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
           PERFORM  9230-DISPLAY-CLI-OR-POL-INFO
               THRU 9230-DISPLAY-CLI-OR-POL-INFO-X.

      ***  CHECK IF DELETE ALLOWED.
           IF  RREQT-CPREQ-STAT-WANTED
               CONTINUE
           ELSE
               MOVE 'NS00900044'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-DELETE-X
           END-IF.


           IF  MIR-CLI-ID = SPACES
               MOVE 'P'               TO WS-POL-OR-CLI-CODE
               MOVE MIR-POL-ID-BASE   TO WS-POLICY-NUMBER
               MOVE MIR-POL-ID-SFX    TO WS-POLICY-SUFFIX
           ELSE
               MOVE 'C'               TO WS-POL-OR-CLI-CODE
               MOVE MIR-CLI-ID        TO WS-CLIENT-ID
           END-IF.

           IF  MIR-CPREQ-SEQ-NUM NOT = SPACES
               PERFORM  2300-FORMAT-SEQUENCE
                   THRU 2300-FORMAT-SEQUENCE-X
           END-IF.

           PERFORM  7800-BUILD-REQT-KEY
               THRU 7800-BUILD-REQT-KEY-X.

014221*    PERFORM  REQT-1000-READ-FOR-UPDATE
014221*        THRU REQT-1000-READ-FOR-UPDATE-X.
014221     PERFORM  REQT-2000-UPDATE-TWRK-TS
014221         THRU REQT-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303' TO WGLOB-MSG-REF-INFO
014221         MOVE 'REQT'       TO WGLOB-MSG-PARM (01)
014221         MOVE WREQT-KEY    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221              THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF  WREQT-IO-NOT-FOUND
               MOVE WREQT-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

      ***  DIARY LOG.
           MOVE 'DELT'                TO L0760-DAL-ACTION.
           MOVE MIR-CPREQ-SEQ-NUM     TO L0760-MESSAGE-PARMS (1).
           MOVE RREQT-CPREQ-STAT-CD   TO L0760-MESSAGE-PARMS (2).
           MOVE 'NS0090'              TO L0760-MSG-SRCE.
           MOVE '0045'                TO L0760-MSG-NUMBER.
           PERFORM  7000-WRITE-DALG
               THRU 7000-WRITE-DALG-X.

      ***  UPDATE ACTIVITY DATE IF CLIENT.
           IF  WS-UW-REQUIREMENT
               PERFORM  7250-UPD-CLIENT-ACTIVITY-DT
                   THRU 7250-UPD-CLIENT-ACTIVITY-DT-X
           END-IF.

      ***  DELETE RECORD AND RE-ANALYZE.
           PERFORM  REQT-1000-DELETE
               THRU REQT-1000-DELETE-X.
035393     PERFORM  8740-REQD-EVENT
035393         THRU 8740-REQD-EVENT-X.
           MOVE 'XS00000011'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
           PERFORM  7700-FORCE-ANALYZE
               THRU 7700-FORCE-ANALYZE-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      ****************************************************************
      *  WRITE DIARY LOG VARIABLE:        INPUT: L0760-DAL-ACTION
      *  WRITE AN ENTRY TO THE DIARY LOG TO      L0760-MESS-NUMBER
      *  DESCRIBE THE CHANGES THAT ARE BEING     L0760-MESSAGE-PARMS ()
      *  MADE TO THE REQUIREMENT FILE.
      ****************************************************************
       7000-WRITE-DALG.

      ***  SETUP GENERAL INFORMATION FROM REQUIREMENT RECORD.
      ***  NOTE THAT RREQT-POL-CLI-ID IS EITHER POLICY OR CLIENT ID.
           MOVE RREQT-CPREQ-POL-CLI-CD   TO L0760-POL-OR-CLI-TYPE.
           MOVE RREQT-POL-CLI-ID      TO L0760-POL-OR-CLI-ID.

           IF  WS-WRITE-REQT
               MOVE MIR-REQIR-ID      TO L0760-DAL-ACTIVITY
           ELSE
               MOVE RREQT-REQIR-ID    TO L0760-DAL-ACTIVITY
           END-IF.

           MOVE ZERO                  TO L0760-CVG-NUM-N.

      ***  LINK TO DIARY LOG WRITE MODULE.
           PERFORM  0760-1000-PROCESS-DAL-ENTRY
               THRU 0760-1000-PROCESS-DAL-ENTRY-X.

       7000-WRITE-DALG-X.
           EXIT.
      /
      ****************************************************************
      *   UPDATE CLIENT ACTIVITY DATE:
      *   IF THE CLIENT IS NOT CURRENTLY LOCKED BY CLEAR CASE, LOCK
      *   THE NAL RECORD, UPDATE THE LAST ACTIVITY DATE AND REWRITE IT.
      ****************************************************************
       7250-UPD-CLIENT-ACTIVITY-DT.

      ***  LOCK THE CLIENT.
           MOVE WS-CLIENT-NUMBER      TO L2437-CLI-ID.
           MOVE WGLOB-SYSTEM-DATE-INT TO L2437-PREV-UWG-ACTV-DT.
           SET L2437-PREV-UWG-ACTV-DT-UPDT   TO TRUE.
           PERFORM  2437-2000-UPDT-CLI-INFO
               THRU 2437-2000-UPDT-CLI-INFO-X.

      ***  CHECK CLEAR CASE LOCK.

           IF  L2437-CLI-CCAS-LOCK-LOCKED
               GO TO 7250-UPD-CLIENT-ACTIVITY-DT-X
           END-IF.

       7250-UPD-CLIENT-ACTIVITY-DT-X.
           EXIT.
      /
      ****************************************************************
      *   CHECK FOLLOW-UP DATE VS FINAL DISPOSITION DATE.
      *   THE FINAL DISPOSITION DATE AND RUSH IND ARE FETCHED.  A
      *   MESSAGE IS GENERATED IF THE RUSH IND IS SET, OR IF THE FINAL
      *   DISPOSITION DATE IS BEFORE THE FOLLOW-UP DATE, OR IF THE
      *   FINAL DISPOSITION WARNING DATE IS BEFORE THE FOLLOW-UP DATE.
      ****************************************************************
       7500-CHECK-FINAL-DISP.

      ***  FETCH DATA INTO L0095 INTERFACE.
           PERFORM  7510-FETCH-FINAL-DISP
               THRU 7510-FETCH-FINAL-DISP-X.

      ***  CHECK RUSH INDICATOR.
           IF  L0095-RUSH-IND = 'Y'

               IF  WS-UW-REQUIREMENT
                   MOVE L0095-CLI-ID  TO WGLOB-MSG-PARM (1)
                   MOVE L0095-RUSH-POL-ID
                                      TO WGLOB-MSG-PARM (2)
                   MOVE 'NS00900046'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE L0095-RUSH-POL-ID
                                      TO WGLOB-MSG-PARM (1)
                   MOVE 'NS00900047'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF

           END-IF.

           IF  L0095-FINAL-DISP-DT = WWKDT-ZERO-DT
           OR  RPOL-POL-SUSPENDED
               GO TO 7500-CHECK-FINAL-DISP-X
           END-IF.

      ***  CHECK FINAL DISPOSITION AGAINST FOLLOW-UP DATE.
           IF  L0095-FINAL-DISP-DT NOT > RREQT-CPREQ-FOLWUP-DT
018634     AND NOT RPOL-POL-STAT-IN-FORCE
               MOVE L0095-FDD-POL-ID  TO WGLOB-MSG-PARM (1)
               MOVE RREQT-CPREQ-FOLWUP-DT
                                      TO L1640-INTERNAL-DATE
               PERFORM  1640-2000-INTERNAL-TO-EXT
                   THRU 1640-2000-INTERNAL-TO-EXT-X
               MOVE L1640-EXTERNAL-DATE
                                      TO WGLOB-MSG-PARM (2)
               MOVE L0095-FINAL-DISP-DT
                                      TO L1640-INTERNAL-DATE
               PERFORM  1640-2000-INTERNAL-TO-EXT
                   THRU 1640-2000-INTERNAL-TO-EXT-X
               MOVE L1640-EXTERNAL-DATE
                                      TO WGLOB-MSG-PARM (3)
               MOVE 'NS00900048'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7500-CHECK-FINAL-DISP-X
           END-IF.

010418***  FETCH COMPANY PROFILE.
010418*    PERFORM  PCOM-1000-READ
010418*        THRU PCOM-1000-READ-X.
010418*    IF  WPCOM-IO-NOT-FOUND
010418*        MOVE WGLOB-COMPANY-CODE       TO WGLOB-MSG-PARM (1)
010418*        MOVE 'XS00000053'             TO WGLOB-MSG-REF-INFO
010418*        PERFORM  0260-1000-GENERATE-MESSAGE
010418*            THRU 0260-1000-GENERATE-MESSAGE-X
010418*        GO TO 7500-CHECK-FINAL-DISP-X
010418*    END-IF.

010418***  COMPUTE FINAL DISPOSITION WARNING DATE.
010418*    SUBTRACT RPCOM-DISP-WARN-DY-QTY
010418*    SUBTRACT RPCOM-DISP-WARN-DY-DUR
010418*             FROM ZERO GIVING L1680-NUMBER-OF-DAYS.
010418*    MOVE ZERO                    TO L1680-NUMBER-OF-YEARS.
010418*    MOVE ZERO                    TO L1680-NUMBER-OF-MONTHS.
010418*    MOVE L0095-FINAL-DISP-DT     TO L1680-INTERNAL-1.
010418*    PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
010418*        THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.

010418***  FETCH SUB-COMPANY PROFILE.
010418     MOVE L0095-SBSDRY-CO-ID    TO WSCOM-SBSDRY-CO-ID.
010418     PERFORM  SCOM-1000-READ
010418         THRU SCOM-1000-READ-X.
010418     IF  WSCOM-IO-NOT-FOUND
010418         MOVE L0095-SBSDRY-CO-ID   TO WGLOB-MSG-PARM (1)
010418         MOVE 'XS00000234'      TO WGLOB-MSG-REF-INFO
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418         GO TO 7500-CHECK-FINAL-DISP-X
010418     END-IF.

010418***  COMPUTE FINAL DISPOSITION WARNING DATE.
010418*    SUBTRACT RPCOM-DISP-WARN-DY-QTY
010418     SUBTRACT RSCOM-DISP-WARN-DY-DUR
010418              FROM ZERO GIVING L1680-NUMBER-OF-DAYS.
010418     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
010418     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
010418     MOVE L0095-FINAL-DISP-DT   TO L1680-INTERNAL-1.
010418     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
010418         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
      ***  CHECK FINAL DISPOSITION WARNING AGAINST FOLLOW-UP DATE.
           IF  L1680-INTERNAL-2 NOT > RREQT-CPREQ-FOLWUP-DT
018634     AND NOT RPOL-POL-STAT-IN-FORCE
               MOVE L0095-FDD-POL-ID  TO WGLOB-MSG-PARM (1)
               MOVE RREQT-CPREQ-FOLWUP-DT
                                      TO L1640-INTERNAL-DATE
               PERFORM  1640-2000-INTERNAL-TO-EXT
                   THRU 1640-2000-INTERNAL-TO-EXT-X
               MOVE L1640-EXTERNAL-DATE
                                      TO WGLOB-MSG-PARM (2)
               MOVE L1680-INTERNAL-2  TO L1640-INTERNAL-DATE
               PERFORM  1640-2000-INTERNAL-TO-EXT
                   THRU 1640-2000-INTERNAL-TO-EXT-X
               MOVE L1640-EXTERNAL-DATE
                                      TO WGLOB-MSG-PARM (3)
               MOVE 'NS00900050'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7500-CHECK-FINAL-DISP-X.
           EXIT.
      /
      ****************************************************************
      *   FETCH FINAL DISPOSITION DATA.
      *   THE FINAL DISPOSITION DATE AND RUSH INDICATOR ARE FETCHED,
      *   FROM THE POLICY FOR ISSUE REQUIREMENTS, OR BY SEARCHING
      *   ALL POLICIES FOR UNDERWRITING REQUIREMENTS.  AT EXIT, THE
      *   DATA IS LEFT IN THE L0095 INTERFACE AREA.
      ****************************************************************
       7510-FETCH-FINAL-DISP.


      ***  ISSUE REQUIREMENT - FROM THIS POLICY.
           IF  WS-ISSUE-REQUIREMENT
               MOVE MIR-POL-ID-BASE   TO WPOL-POL-ID-BASE
               MOVE MIR-POL-ID-SFX    TO WPOL-POL-ID-SFX
               PERFORM  POL-1000-READ
                   THRU POL-1000-READ-X
               MOVE WS-POLICY-ID      TO L0095-FDD-POL-ID
                                         L0095-RUSH-POL-ID
               MOVE RPOL-POL-FINAL-DISP-DT
                                      TO L0095-FINAL-DISP-DT
               MOVE RPOL-POL-RUSH-IND TO L0095-RUSH-IND
010418         MOVE RPOL-SBSDRY-CO-ID TO L0095-SBSDRY-CO-ID
               GO TO 7510-FETCH-FINAL-DISP-X
           END-IF.

      ***  UNDERWRITING REQUIREMNT - INVOKE SEARCH WORKER.
           PERFORM  0095-1000-BUILD-PARM-INFO
               THRU 0095-1000-BUILD-PARM-INFO-X.
           MOVE WS-CLIENT-NUMBER      TO L0095-CLI-ID.
           PERFORM  0095-1000-INSRD-POL-CHK
               THRU 0095-1000-INSRD-POL-CHK-X.

       7510-FETCH-FINAL-DISP-X.
           EXIT.


      ****************************************************************
      *   FORCE ANALYZE OF INSURED / POLICY.
      *   INVOKE THE ANALYSIS PROGRAM TO UPDATE THE STATUS'S OF
      *   THE RELEVANT COVERAGES AND/OR POLICIES.  THIS ROUTINE SHOULD
      *   ONLY BE EXECUTED WHEN THERE IS A POSSIBILITY OF THE STATUS'S
      *   BEING CHANGED BY THE CHANGES MADE TO THE REQUIREMENT FILE.
      ****************************************************************
       7700-FORCE-ANALYZE.

           PERFORM  1090-1000-BUILD-PARM-INFO
               THRU 1090-1000-BUILD-PARM-INFO-X.

      ***  PERFORM ANALYSIS.
           IF  WS-UW-REQUIREMENT
               MOVE WS-CLIENT-NUMBER  TO L1090-CLI-ID
               PERFORM  1090-1000-INSRD-ANALYZE
                   THRU 1090-1000-INSRD-ANALYZE-X
           ELSE
               MOVE WS-POLICY-ID      TO L1090-POL-ID
               PERFORM  1090-2000-POL-ANALYZE
                   THRU 1090-2000-POL-ANALYZE-X
           END-IF.


      ***  CHECK ERROR.
           IF  NOT L1090-RETRN-OK
               MOVE L1090-RQST-CD     TO WGLOB-MSG-PARM (1)
               MOVE L1090-CLI-ID      TO WGLOB-MSG-PARM (2)
               MOVE L1090-POL-ID      TO WGLOB-MSG-PARM (3)
               MOVE L1090-RETRN-CD    TO WGLOB-MSG-PARM (4)
               MOVE 'NS00900051'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7700-FORCE-ANALYZE-X.
           EXIT.
      /
      ****************************************************************
      *  BUILD REQT READ KEY                                         *
      ****************************************************************
       7800-BUILD-REQT-KEY.

           MOVE WS-POL-OR-CLI-CODE    TO WREQT-CPREQ-POL-CLI-CD.
           MOVE WS-POLICY-ID          TO WREQT-POL-ID.
           MOVE MIR-REQIR-ID          TO WREQT-REQIR-ID.
           MOVE WS-SEQUENCE-NO        TO WREQT-CPREQ-SEQ-NUM.

       7800-BUILD-REQT-KEY-X.
           EXIT.


      ****************************************************************
      *   BUILD REQT BROWSE KEYS.
      ****************************************************************
       7810-BUILD-REQT-BROWSE-KEYS.

           MOVE WS-POL-OR-CLI-CODE    TO WREQT-CPREQ-POL-CLI-CD
                                        WREQT-ENDBR-CPREQ-POL-CLI-CD.

           MOVE WS-POLICY-ID          TO WREQT-POL-ID
                                        WREQT-ENDBR-POL-ID.

           MOVE MIR-REQIR-ID          TO WREQT-REQIR-ID
                                        WREQT-ENDBR-REQIR-ID.

       7810-BUILD-REQT-BROWSE-KEYS-X.
           EXIT.


      ****************************************************************
      *   BUILD RQCR BROWSE KEYS.
      ****************************************************************
       7820-BUILD-RQCR-BROWSE-KEYS.

           MOVE WS-POL-OR-CLI-CODE    TO WRQCR-CPREQ-POL-CLI-CD
                                          WRQCR-ENDBR-CPREQ-POL-CLI-CD.

           MOVE WS-POLICY-ID          TO WRQCR-POL-ID
                                          WRQCR-ENDBR-POL-ID.

           MOVE MIR-REQIR-ID          TO WRQCR-REQIR-ID.
           MOVE WS-INTERNAL-START-DATE  TO WRQCR-CPREQ-CREAT-DT.

       7820-BUILD-RQCR-BROWSE-KEYS-X.
           EXIT.
      /
016503*--------------------
016503 8000-UPDATE-CLI-POL.
016503*--------------------

016503     MOVE  LOW-VALUES           TO  WRLTP-KEY.
016503     MOVE  MIR-CLI-ID           TO  WRLTP-CLI-ID.
016503     SET WRLTP-REL-TYP-INSURED  TO  TRUE.

016503     MOVE  HIGH-VALUES          TO  WRLTP-ENDBR-KEY.
016503     MOVE  MIR-CLI-ID           TO  WRLTP-ENDBR-CLI-ID.
016503     SET WRLTP-ENDBR-REL-TYP-INSURED   TO  TRUE.

016503     PERFORM  RLTP-1000-BROWSE
016503         THRU RLTP-1000-BROWSE-X.

016503     PERFORM  RLTP-2000-READ-NEXT
016503         THRU RLTP-2000-READ-NEXT-X.

016503     IF  NOT WRLTP-IO-OK
016503         PERFORM  RLTP-3000-END-BROWSE
016503             THRU RLTP-3000-END-BROWSE-X
016503         GO TO 8000-UPDATE-CLI-POL-X
016503     END-IF.

016503     PERFORM  8200-UPDATE-SINGLE-CLI-POL
016503         THRU 8200-UPDATE-SINGLE-CLI-POL-X
016503         UNTIL  NOT WRLTP-IO-OK.

016503     PERFORM  RLTP-3000-END-BROWSE
016503         THRU RLTP-3000-END-BROWSE-X.

016503 8000-UPDATE-CLI-POL-X.
016503     EXIT.
      /
016503*--------------------------
016503 8200-UPDATE-SINGLE-CLI-POL.
016503*--------------------------

016503     MOVE RRL-REL-SYS-REF-ID        TO WPOL-POL-ID.

016503     PERFORM  POL-1000-READ
016503         THRU POL-1000-READ-X.

016503     IF  RPOL-POL-STAT-BEFORE-SETL
016503         PERFORM  8600-UPDATE-NEXT-ACTV
016503             THRU 8600-UPDATE-NEXT-ACTV-X
016503         PERFORM  RLTP-2000-READ-NEXT
016503             THRU RLTP-2000-READ-NEXT-X
016503         GO TO 8200-UPDATE-SINGLE-CLI-POL-X
016503     END-IF.


016503     PERFORM  2222-1000-BUILD-PARM-INFO
016503         THRU 2222-1000-BUILD-PARM-INFO-X.

016503     MOVE RPOL-POL-ID                TO L2222-POL-ID.

016503     INITIALIZE L2222-INFORCE-POL-PEND-CVG-IND.
016503     PERFORM  2222-1000-FIND-PEND-CVG
016503         THRU 2222-1000-FIND-PEND-CVG-X.

016503     IF  L2222-INFORCE-POL-PEND-CVG
016503         MOVE RPOL-POL-ID            TO WPOL-POL-ID
016503         PERFORM  8600-UPDATE-NEXT-ACTV
016503             THRU 8600-UPDATE-NEXT-ACTV-X
016503     END-IF.

016503     PERFORM  RLTP-2000-READ-NEXT
016503         THRU RLTP-2000-READ-NEXT-X.

016503 8200-UPDATE-SINGLE-CLI-POL-X.
016503     EXIT.
      /
016503*---------------------
016503 8600-UPDATE-NEXT-ACTV.
016503*---------------------

016503      PERFORM  POL-1000-READ-FOR-UPDATE
016503          THRU POL-1000-READ-FOR-UPDATE-X.

016503      PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
016503          THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

016503      PERFORM  0289-1000-INIT-PARM-INFO
016503          THRU 0289-1000-INIT-PARM-INFO-X.

016503      PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503          THRU 0289-1000-OBTAIN-NXT-ACTV-X.

016503      IF  L0289-RETRN-OK
016503          MOVE L0289-NXT-ACTV-TYP-CD  TO RPOL-NXT-ACTV-TYP-CD
016503          MOVE L0289-NXT-ACTV-DT      TO RPOL-POL-NXT-ACTV-DT
016503      ELSE
016503          MOVE 'RSH'                  TO RPOL-NXT-ACTV-TYP-CD
016503          MOVE WGLOB-PROCESS-DATE     TO RPOL-POL-NXT-ACTV-DT
016503      END-IF.

016503      PERFORM  POL-2000-REWRITE
016503          THRU POL-2000-REWRITE-X.

016503 8600-UPDATE-NEXT-ACTV-X.
016503     EXIT.

035393*-----------------
035393 8700-REQU-EVENT.
035393*-----------------
035393
035393     PERFORM  0319-0000-INIT-PARM-INFO
035393         THRU 0319-0000-INIT-PARM-INFO-X.
035393
035393     IF  WS-UW-REQUIREMENT
035393         SET L0319-XTRNL-EVNT-CITS-CRQUPDT
035393                                     TO TRUE
035393     ELSE
035393         SET L0319-XTRNL-EVNT-CITS-REQUPDT
035393                                     TO TRUE
035393     END-IF.
035393
035393     MOVE WGLOB-SYS-CTL-ID           TO L0319-SYS-CTL-ID
035393     PERFORM  0319-1000-GET-EVNT-EXIT-PGM
035393         THRU 0319-1000-GET-EVNT-EXIT-PGM-X.
035393
035393     IF  WS-UW-REQUIREMENT
035393         PERFORM  8770-CITU-EXIT
035393             THRU 8770-CITU-EXIT-X
035393     ELSE
035393         PERFORM  8780-CITC-EXIT
035393             THRU 8780-CITC-EXIT-X
035393     END-IF.
035393
035393 8700-REQU-EVENT-X.
035393     EXIT.
035393
035393*-----------------
035393 8720-REQC-EVENT.
035393*-----------------
035393
035393     PERFORM  0319-0000-INIT-PARM-INFO
035393         THRU 0319-0000-INIT-PARM-INFO-X.
035393
035393     IF  WS-UW-REQUIREMENT
035393         SET L0319-XTRNL-EVNT-CITS-CRQCREAT
035393                                     TO TRUE
035393     ELSE
035393         SET L0319-XTRNL-EVNT-CITS-REQCREAT
035393                                     TO TRUE
035393     END-IF.
035393
035393     MOVE WGLOB-SYS-CTL-ID           TO L0319-SYS-CTL-ID
035393     PERFORM  0319-1000-GET-EVNT-EXIT-PGM
035393         THRU 0319-1000-GET-EVNT-EXIT-PGM-X.
035393
035393     IF  WS-UW-REQUIREMENT
035393         PERFORM  8770-CITU-EXIT
035393             THRU 8770-CITU-EXIT-X
035393     ELSE
035393         PERFORM  8780-CITC-EXIT
035393             THRU 8780-CITC-EXIT-X
035393     END-IF.
035393
035393 8720-REQC-EVENT-X.
035393     EXIT.
035393
035393*-----------------
035393 8740-REQD-EVENT.
035393*-----------------
035393
035393     PERFORM  0319-0000-INIT-PARM-INFO
035393         THRU 0319-0000-INIT-PARM-INFO-X.
035393
035393     IF  WS-UW-REQUIREMENT
035393         SET L0319-XTRNL-EVNT-CITS-CRQDELT
035393                                     TO TRUE
035393     ELSE
035393         SET L0319-XTRNL-EVNT-CITS-REQDELT
035393                                     TO TRUE
035393     END-IF.
035393
035393     MOVE WGLOB-SYS-CTL-ID           TO L0319-SYS-CTL-ID
035393     PERFORM  0319-1000-GET-EVNT-EXIT-PGM
035393         THRU 0319-1000-GET-EVNT-EXIT-PGM-X.
035393
035393     IF  WS-UW-REQUIREMENT
035393         PERFORM  8770-CITU-EXIT
035393             THRU 8770-CITU-EXIT-X
035393     ELSE
035393         PERFORM  8780-CITC-EXIT
035393             THRU 8780-CITC-EXIT-X
035393     END-IF.
035393
035393 8740-REQD-EVENT-X.
035393     EXIT.
035393
035393*-----------------
035393 8750-REQS-EVENT.
035393*-----------------
035393
035393     PERFORM  0319-0000-INIT-PARM-INFO
035393         THRU 0319-0000-INIT-PARM-INFO-X.
035393
035393     IF  WS-UW-REQUIREMENT
035393         SET L0319-XTRNL-EVNT-CITS-CRQSTAT
035393                                     TO TRUE
035393     ELSE
035393         SET L0319-XTRNL-EVNT-CITS-REQSTAT
035393                                     TO TRUE
035393     END-IF.
035393
035393     MOVE WGLOB-SYS-CTL-ID           TO L0319-SYS-CTL-ID
035393     PERFORM  0319-1000-GET-EVNT-EXIT-PGM
035393         THRU 0319-1000-GET-EVNT-EXIT-PGM-X.
035393
035393     IF  WS-UW-REQUIREMENT
035393         PERFORM  8770-CITU-EXIT
035393             THRU 8770-CITU-EXIT-X
035393     ELSE
035393         PERFORM  8780-CITC-EXIT
035393             THRU 8780-CITC-EXIT-X
035393     END-IF.
035393
035393 8750-REQS-EVENT-X.
035393     EXIT.
035393
035393*---------------
035393 8770-CITU-EXIT.
035393*---------------
035393
035393     PERFORM
035393         VARYING WS-INDEX FROM 1     BY 1
035393         UNTIL   WS-INDEX > L0319-XTRNL-EVNT-CNT
035393
035393         IF  L0319-XTRNL-EVNT-PUBLISH (WS-INDEX)
035393
035393             PERFORM  CITU-0000-INIT-PARM-INFO
035393                 THRU CITU-0000-INIT-PARM-INFO-X
035393             MOVE MIR-CLI-ID         TO LCITU-CLI-ID
035393             MOVE L0319-XTRNL-EVNT-PGM-ID (WS-INDEX)
035393                                     TO LCITU-CALL-PGM-ID
035393             MOVE L0319-XTRNL-DOC-ID (WS-INDEX)
035393                                     TO LCITU-DOC-ID
035393             MOVE L0319-XTRNL-SYS-ID (WS-INDEX)
035393                                     TO LCITU-XTRNL-SYS-ID
035393             MOVE L0319-XTRNL-EVNT-ID
035393                                     TO LCITU-XTRNL-EVNT-ID
035393             PERFORM  CITU-1000-UW-CHANGE
035393                 THRU CITU-1000-UW-CHANGE-X
035393
035393         END-IF
035393     END-PERFORM.
035393
035393 8770-CITU-EXIT-X.
035393     EXIT.
035393
035393*---------------
035393 8780-CITC-EXIT.
035393*---------------
035393
035393     PERFORM
035393         VARYING WS-INDEX FROM 1     BY 1
035393         UNTIL   WS-INDEX > L0319-XTRNL-EVNT-CNT
035393
035393         IF  L0319-XTRNL-EVNT-PUBLISH (WS-INDEX)
035393
035393             PERFORM  CITC-0000-INIT-PARM-INFO
035393                 THRU CITC-0000-INIT-PARM-INFO-X
035393             MOVE RPOL-POL-ID        TO LCITC-POL-ID
035393             MOVE RPOL-SERV-BR-ID    TO LCITC-SERV-BR-ID
035393             MOVE RPOL-SERV-AGT-ID   TO LCITC-AGT-ID
035393             MOVE L0319-XTRNL-EVNT-PGM-ID (WS-INDEX)
035393                                     TO LCITC-CALL-PGM-ID
035393             MOVE L0319-XTRNL-DOC-ID (WS-INDEX)
035393                                     TO LCITC-DOC-ID
035393             MOVE L0319-XTRNL-SYS-ID (WS-INDEX)
035393                                     TO LCITC-XTRNL-SYS-ID
035393             MOVE L0319-XTRNL-EVNT-ID
035393                                     TO LCITC-XTRNL-EVNT-ID
035393             PERFORM  CITC-1000-PEND-POL-CHANGE
035393                 THRU CITC-1000-PEND-POL-CHANGE-X
035393
035393         END-IF
035393     END-PERFORM.
035393
035393 8780-CITC-EXIT-X.
035393     EXIT.

      ****************************************************************
      *  BLANK DATA FIELDS:  SET EACH DATA (NON-KEY AND NON-CONTROL) *
      *  FIELD ON THE SCREEN TO SPACES.                              *
      ****************************************************************
       9100-BLANK-DATA-FIELDS.

           MOVE SPACES                TO  MIR-DV-INSRD-CLI-NM.
           MOVE SPACES                TO  MIR-SERV-BR-ID.

           IF  WS-BUS-FCN-LIST
               PERFORM  9110-BLANK-OUTPUT-ARRAY
                   THRU 9110-BLANK-OUTPUT-ARRAY-X
           ELSE
               MOVE SPACES            TO  MIR-CPREQ-STAT-CD
               MOVE SPACES            TO  MIR-CPREQ-EFF-DT
               MOVE SPACES            TO  MIR-USER-ID
               MOVE SPACES            TO  MIR-CPREQ-DESGNT-ID
               MOVE SPACES            TO  MIR-CPREQ-TST-DT
               MOVE SPACES            TO  MIR-CPREQ-TST-RSLT-CD
               MOVE SPACES            TO  MIR-CPREQ-FOLWUP-NUM
               MOVE SPACES            TO  MIR-CPREQ-FOLWUP-DT
               MOVE SPACES            TO  MIR-CPREQ-VALID-DT
               MOVE SPACES            TO  MIR-CPREQ-NEW-RSLT-IND
               MOVE SPACES            TO  MIR-DV-REVW-REQIR-IND
               MOVE SPACES            TO  MIR-CPREQ-PD-IND
           END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.


       9110-BLANK-OUTPUT-ARRAY.

           MOVE SPACES                TO MIR-REQIR-ID-G
                                         MIR-CPREQ-SEQ-NUM-G
                                         MIR-CPREQ-STAT-CD-G
                                         MIR-CPREQ-EFF-DT-G
                                         MIR-USER-ID-G
                                         MIR-CPREQ-DESGNT-ID-G
                                         MIR-CPREQ-TST-DT-G
                                         MIR-CPREQ-TST-RSLT-CD-G
                                         MIR-CPREQ-FOLWUP-NUM-G
                                         MIR-CPREQ-FOLWUP-DT-G
                                         MIR-CPREQ-PD-IND-G
                                         MIR-CPREQ-VALID-DT-G.

       9110-BLANK-OUTPUT-ARRAY-X.
           EXIT.
      /
       9200-MOVE-RECORD-TO-SCREEN.

      ***  DISPLAY REQUIREMENT DATA.

           IF  WS-BUS-FCN-LIST
               PERFORM  9210-MOVE-RECORD-TO-SCREEN-1
                   THRU 9210-MOVE-RECORD-TO-SCREEN-1-X
           ELSE
               PERFORM  9220-MOVE-RECORD-TO-SCREEN-2
                   THRU 9220-MOVE-RECORD-TO-SCREEN-2-X
           END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      ****************************************************************
      *  RECORD TO SCREEN 1:                         INPUT:  WS-LINE *
      *     SHIFT DATA FROM RECORD BUFFER TO THE SCREEN DISPLAY      *
      *     LINE GIVEN BY THE INPUT ITEM WS-LINE.                    *
      ****************************************************************
       9210-MOVE-RECORD-TO-SCREEN-1.

           MOVE RREQT-REQIR-ID        TO MIR-REQIR-ID-T (WS-LINE).
010645
010645***  FETCH REQUIREMENT TABLE ENTRY.
010645
010645     MOVE RREQT-REQIR-ID        TO WRTAB-REQIR-ID.
010645
010645     PERFORM  RTAB-1000-READ
010645         THRU RTAB-1000-READ-X.
010645
010645     IF  NOT WRTAB-IO-OK
010645         MOVE SPACES            TO MIR-REQIR-TYP-CD-T (WS-LINE)
010645     ELSE
010645         MOVE RRTAB-REQIR-TYP-CD TO MIR-REQIR-TYP-CD-T (WS-LINE)
010645     END-IF.
010645
           MOVE RREQT-CPREQ-STAT-CD   TO MIR-CPREQ-STAT-CD-T (WS-LINE).
           MOVE RREQT-USER-ID         TO MIR-USER-ID-T (WS-LINE).
           MOVE RREQT-CPREQ-DESGNT-ID
                                     TO MIR-CPREQ-DESGNT-ID-T (WS-LINE).
           MOVE RREQT-CPREQ-TST-RSLT-CD
                                   TO MIR-CPREQ-TST-RSLT-CD-T (WS-LINE).
           MOVE RREQT-CPREQ-PD-IND    TO MIR-CPREQ-PD-IND-T (WS-LINE).

020874*    MOVE RREQT-CPREQ-FOLWUP-NUM TO WS-PIC-Z.
020874*    MOVE WS-PIC-Z            TO MIR-CPREQ-FOLWUP-NUM-T (WS-LINE).
020874     MOVE RREQT-CPREQ-FOLWUP-NUM  TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CPREQ-FOLWUP-NUM-T (WS-LINE)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA   TO MIR-CPREQ-FOLWUP-NUM-T (WS-LINE).
           MOVE RREQT-CPREQ-SEQ-NUM   TO WS-SEQUENCE-NO.
           MOVE WS-SEQUENCE-NO        TO MIR-CPREQ-SEQ-NUM-T (WS-LINE).

           MOVE RREQT-CPREQ-EFF-DT    TO L1640-INTERNAL-DATE.
008453*    PERFORM  9215-CONVERT-DATE
008453*        THRU 9215-CONVERT-DATE-X.
008453*    MOVE WS-EXTERNAL-DATE      TO MIR-CPREQ-EFF-DT-T (WS-LINE).
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
008453     MOVE L1640-EXTERNAL-DATE   TO MIR-CPREQ-EFF-DT-T (WS-LINE).

           MOVE RREQT-CPREQ-TST-DT    TO L1640-INTERNAL-DATE.
008453*    PERFORM  9215-CONVERT-DATE
008453*        THRU 9215-CONVERT-DATE-X.
008453*    MOVE WS-EXTERNAL-DATE      TO MIR-CPREQ-TST-DT-T (WS-LINE).
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
008453     MOVE L1640-EXTERNAL-DATE   TO MIR-CPREQ-TST-DT-T (WS-LINE).

           MOVE RREQT-CPREQ-FOLWUP-DT TO L1640-INTERNAL-DATE.
008453*    PERFORM  9215-CONVERT-DATE
008453*        THRU 9215-CONVERT-DATE-X.
008453*    MOVE WS-EXTERNAL-DATE   TO MIR-CPREQ-FOLWUP-DT-T (WS-LINE).
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
008453     MOVE L1640-EXTERNAL-DATE  TO MIR-CPREQ-FOLWUP-DT-T (WS-LINE).

           MOVE RREQT-CPREQ-VALID-DT  TO L1640-INTERNAL-DATE.
008453*    PERFORM  9215-CONVERT-DATE
008453*        THRU 9215-CONVERT-DATE-X.
008453*    MOVE WS-EXTERNAL-DATE     TO MIR-CPREQ-VALID-DT-T (WS-LINE).
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
008453     MOVE L1640-EXTERNAL-DATE   TO MIR-CPREQ-VALID-DT-T (WS-LINE).

       9210-MOVE-RECORD-TO-SCREEN-1-X.
           EXIT.

008453*9215-CONVERT-DATE.
008453*
008453*    PERFORM  1640-2000-INTERNAL-TO-EXT
008453*        THRU 1640-2000-INTERNAL-TO-EXT-X.
008453*
008453*    MOVE L1640-EXTERNAL-DATE           TO WS-EXTERNAL-DATE.

008453*9215-CONVERT-DATE-X.
008453*    EXIT.
      /
      ****************************************************************
      *  RECORD TO SCREEN 2:                                         *
      *     SHIFT DATA FROM RECORD BUFFER TO THE SCREEN DISPLAY      *
      *     IN PREPARATION FOR CREATE, MAINTAIN OR DELETE            *
      ****************************************************************
       9220-MOVE-RECORD-TO-SCREEN-2.

           MOVE RREQT-CPREQ-STAT-CD   TO MIR-CPREQ-STAT-CD.
           MOVE RREQT-USER-ID         TO MIR-USER-ID.
           MOVE RREQT-CPREQ-DESGNT-ID TO MIR-CPREQ-DESGNT-ID.
           MOVE RREQT-CPREQ-TST-RSLT-CD
                                      TO MIR-CPREQ-TST-RSLT-CD.
           MOVE RREQT-CPREQ-PD-IND    TO MIR-CPREQ-PD-IND.
           MOVE RREQT-CPREQ-NEW-RSLT-IND
                                      TO MIR-CPREQ-NEW-RSLT-IND.
           MOVE 'N'                   TO MIR-DV-REVW-REQIR-IND.
020874*    MOVE RREQT-CPREQ-FOLWUP-NUM   TO WS-PIC-Z.
020874*    MOVE WS-PIC-Z              TO MIR-CPREQ-FOLWUP-NUM.
020874     MOVE RREQT-CPREQ-FOLWUP-NUM  TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CPREQ-FOLWUP-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CPREQ-FOLWUP-NUM.

           MOVE RREQT-CPREQ-CREAT-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CPREQ-CREAT-DT.

           MOVE RREQT-CPREQ-TST-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CPREQ-TST-DT.

           MOVE RREQT-CPREQ-EFF-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CPREQ-EFF-DT.

           MOVE RREQT-CPREQ-FOLWUP-DT TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CPREQ-FOLWUP-DT.

           MOVE RREQT-CPREQ-VALID-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CPREQ-VALID-DT.

      ***  REQUIREMENT DESCRIPTION.
           IF NOT WS-RTAB-AVAILABLE
               PERFORM 5310-FETCH-RTAB
                  THRU 5310-FETCH-RTAB-X
           END-IF.

           MOVE RREQT-REQIR-ID        TO  WEDIT-ETBL-VALU-ID.
           MOVE SPACES                TO  REDIT-ETBL-DESC-TXT.
           PERFORM REQT-2000-DESC
              THRU REQT-2000-DESC-X.


010645     MOVE RREQT-REQIR-ID        TO WRTAB-REQIR-ID.
010645
010645     PERFORM  RTAB-1000-READ
010645         THRU RTAB-1000-READ-X.
010645
010645     IF  NOT WRTAB-IO-OK
010645         MOVE SPACES            TO MIR-REQIR-TYP-CD
010645     ELSE
010645         MOVE RRTAB-REQIR-TYP-CD   TO MIR-REQIR-TYP-CD
010645     END-IF.
010645
      ***  TEST DESCRIPTION.
           IF  RREQT-CPREQ-TST-RSLT-CD = SPACES
               CONTINUE
           ELSE
               MOVE RREQT-CPREQ-TST-RSLT-CD
                                      TO WEDIT-ETBL-VALU-ID
               PERFORM  RESL-2000-DESC
                   THRU RESL-2000-DESC-X

               IF  WEDIT-IO-OK
                   CONTINUE
               ELSE
                   MOVE 'XS00000037'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-2000-GET-MESSAGE
                       THRU 0260-2000-GET-MESSAGE-X
               END-IF

           END-IF.

       9220-MOVE-RECORD-TO-SCREEN-2-X.
           EXIT.
      /
      ****************************************************************
      *  DISPLAY INFORMATION DATA.
      ****************************************************************
       9230-DISPLAY-CLI-OR-POL-INFO.

           IF  WS-POL-OR-CLI-CODE = 'C'
               PERFORM  9240-DISPLAY-FOR-CLIENT
                   THRU 9240-DISPLAY-FOR-CLIENT-X
           ELSE
               PERFORM  9250-DISPLAY-FOR-POLICY
                   THRU 9250-DISPLAY-FOR-POLICY-X
           END-IF.

       9230-DISPLAY-CLI-OR-POL-INFO-X.
           EXIT.


      ****************************************************************
      *  DISPLAY FOR CLIENT:
      *  THE INFORMATIONAL FIELDS ON THE MAP ARE LOADED WITH THE
      *  APPROPRIATE DATA FROM THE CURRENT CLIENT RECORD, AND IF
      *  POSSIBLE, FROM THE FIRST PENDING POLICY FOUND FOR THIS INSURED.
      ****************************************************************
       9240-DISPLAY-FOR-CLIENT.

      ***  CLIENT NAME.

           MOVE 'NS00900052'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-2000-GET-MESSAGE
               THRU 0260-2000-GET-MESSAGE-X.

      *    FORMAT CLIENT SCREEN NAME INTO MIR-DV-CLI-NM.
           MOVE WS-CLIENT-NUMBER      TO L2437-CLI-ID.
           PERFORM  2437-1000-OBTAIN-CLI-INFO
               THRU 2437-1000-OBTAIN-CLI-INFO-X.

557698*    MOVE L2437-CLI-GIV-NM           TO L0620-CLI-GIV-NM.
557698*    MOVE L2437-CLI-SUR-NM           TO L0620-CLI-SUR-NM.
           MOVE L2437-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
557698*    MOVE L2437-CLI-CO-NM            TO L0620-CLI-CO-NM.
557698     MOVE L2437-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM.
557698     MOVE L2437-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM.
           MOVE L2437-CLI-SFX-NM      TO L0620-CLI-SFX-NM.
           MOVE L2437-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM.
557698     MOVE L2437-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           MOVE L0620-SCREEN-NAME     TO MIR-DV-INSRD-CLI-NM.

      ***  BRANCH - USE CLIENT BRANCH IF NO BETTER.

      ***  BRANCH - ATTEMPT TO FIND FIRST PENDING POLICY.
           PERFORM  0064-1000-BUILD-PARM-INFO
               THRU 0064-1000-BUILD-PARM-INFO-X.
           MOVE WS-CLIENT-NUMBER      TO L0064-CLIENT-NUMBER.
016440*    MOVE 'NEWBUS'              TO L0064-SYSTEM.
016440     MOVE WGLOB-SYS-CTL-ID      TO L0064-SYSTEM.
           PERFORM  0064-2000-CHECK-FOR-INSURED
               THRU 0064-2000-CHECK-FOR-INSURED-X.

      ***  FETCH POLICY RECORD FOR BRANCH CODE.
           IF  L0064-RETRN-OK
           AND L0064-FOUND
               MOVE L0064-REL-SYS-REF-POL-ID
                                      TO WPOL-POL-ID
               PERFORM  POL-1000-READ
                   THRU POL-1000-READ-X

               IF  WPOL-IO-NOT-FOUND
016440*            MOVE 'NEWBUS'      TO WGLOB-MSG-PARM (1)
016440*            MOVE WPOL-POL-ID   TO WGLOB-MSG-PARM (2)
016440             MOVE WPOL-POL-ID   TO WGLOB-MSG-PARM (1)
                   MOVE 'XS00000097'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE RPOL-SERV-BR-ID
                                      TO MIR-SERV-BR-ID
               END-IF

           END-IF.

       9240-DISPLAY-FOR-CLIENT-X.
           EXIT.
      /
      ****************************************************************
      *   DISPLAY FOR POLICY:
      *   THE INFORMATIONAL FIELDS ON THE MAP ARE LOADED WITH THE
      *   APPROPRIATE DATA FROM THE CURRENT POLICY RECORD, AND IF
      *   POSSIBLE, FROM THE PRIMARY OWNER'S CLIENT RECORD.
      ****************************************************************
       9250-DISPLAY-FOR-POLICY.

      ***  NAME IS OWNER.
           MOVE 'NS00900053'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-2000-GET-MESSAGE
               THRU 0260-2000-GET-MESSAGE-X.

      ***  FETCH NAME OF OWNER.
           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.
           MOVE ZERO                  TO I.
           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.
           IF  NOT L2430-RELATIONSHIP-FOUND
               MOVE L2430-CLI-ID      TO WGLOB-MSG-PARM (1)
               MOVE WS-POLICY-ID      TO WGLOB-MSG-PARM (2)
               MOVE 'NS00900054'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'NS00900055'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-2000-GET-MESSAGE
                   THRU 0260-2000-GET-MESSAGE-X
               MOVE WGLOB-MSG-TXT     TO MIR-DV-INSRD-CLI-NM
           ELSE
557668*        MOVE L2430-CLI-NM-COMPRESSED     TO MIR-DV-CLI-NM

557668         INITIALIZE L0620-INPUT-PARM-INFO
557668         IF L2430-CLI-SEX-COMPANY
010497*            MOVE L2430-CLI-CO-NM         TO L0620-CLI-CO-NM
010497             MOVE L2430-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
557668         ELSE
010497*            MOVE L2430-CLI-GIV-NM        TO L0620-CLI-GIV-NM
010497*            MOVE L2430-CLI-SUR-NM        TO L0620-CLI-SUR-NM
010497             MOVE L2430-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
010497             MOVE L2430-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM
                                      TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM
                                      TO L0620-CLI-SFX-NM
557668         END-IF
557668         MOVE L2430-CLI-SEX-CD  TO L0620-CLI-SEX-CD

557668         PERFORM  0620-1000-FORMAT-SCREEN-NAME
557668             THRU 0620-1000-FORMAT-SCREEN-NAME-X

557668         MOVE L0620-SCREEN-NAME TO MIR-DV-INSRD-CLI-NM

           END-IF.

      ***  BRANCH.
           MOVE RPOL-SERV-BR-ID       TO MIR-SERV-BR-ID.

       9250-DISPLAY-FOR-POLICY-X.
           EXIT.
      /
      ****************************************************************
      *   UPDATE SCREEN KEYS:
      *   UPDATE THE SCREEN KEYS FROM THE RECORD BUFFER FOR BROWSE-TYPE
      *   INQUIRIES FOR PAGING.
      ****************************************************************
       9260-UPDATE-SCREEN-KEYS.

           IF  MIR-CPREQ-CREAT-DT NOT = SPACES
               MOVE RREQT-CPREQ-CREAT-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CPREQ-CREAT-DT
               MOVE RREQT-REQIR-ID    TO MIR-REQIR-ID
           END-IF.

           MOVE RREQT-CPREQ-SEQ-NUM   TO WS-SEQUENCE-NO.
           MOVE WS-SEQUENCE-NO        TO MIR-CPREQ-SEQ-NUM.

       9260-UPDATE-SCREEN-KEYS-X.
           EXIT.
      /
      ****************************************************************
      *  SET REFERENCE:  MOVE DATA WHICH IDENTIFIES THE OBJECT THAT  *
      *  IS BEING WORKED ON TO THE GLOBAL AREA FOR MSIN AND MSAU     *
      *  PROCESSING.                                                 *
      ****************************************************************
       9300-SETUP-MSIN-REFERENCE.

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

           IF  MIR-POL-ID-BASE NOT = SPACES
           OR  MIR-POL-ID-SFX  NOT = SPACES
               MOVE 'P'               TO WGLOB-REF-POLICY-OR-CLIENT
               MOVE MIR-POL-ID-BASE   TO WGLOB-REF-POLICY-NUMBER
               MOVE MIR-POL-ID-SFX    TO WGLOB-REF-POLICY-SUFFIX
           ELSE

               IF  MIR-CLI-ID NOT = SPACES
                   MOVE 'C'           TO WGLOB-REF-POLICY-OR-CLIENT
                   MOVE MIR-CLI-ID    TO WGLOB-REF-CLIENT-NUMBER
               END-IF

           END-IF.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

035393     PERFORM  CITC-0000-INIT-PARM-INFO
035393         THRU CITC-0000-INIT-PARM-INFO-X.
035393
035393     PERFORM  CITU-0000-INIT-PARM-INFO
035393         THRU CITU-0000-INIT-PARM-INFO-X.
035393
026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0064-0000-INIT-PARM-INFO
025970         THRU 0064-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0095-0000-INIT-PARM-INFO
025970         THRU 0095-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0220-0000-INIT-PARM-INFO
025970         THRU 0220-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
035393     PERFORM  0319-0000-INIT-PARM-INFO
035393         THRU 0319-0000-INIT-PARM-INFO-X.
035393
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0760-0000-INIT-PARM-INFO
025970         THRU 0760-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1030-0000-INIT-PARM-INFO
025970         THRU 1030-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1090-0000-INIT-PARM-INFO
025970         THRU 1090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2222-0000-INIT-PARM-INFO
025970         THRU 2222-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  5020-0000-INIT-PARM-INFO
025970         THRU 5020-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7180-0000-INIT-PARM-INFO
025970         THRU 7180-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         FREQUENTLY-USED-INDICES.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-RTAB-READ-IND       TO TRUE.
025970     SET WS-DEFAULT-COMM-UPDATED-IND    TO TRUE.
025970     SET WS-DEFAULT-MAX-LINES           TO TRUE.
025970     SET WS-DEFAULT-NEW-RECORD-SW       TO TRUE.
025970     SET WS-DEFAULT-NO-MORE-SEQ-NO-SW   TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970     MOVE SPACES                        TO WWKDT-WORK-FIELDS.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************

028298 COPY CCPPFPCK.
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY NCPCREQT.
       COPY NCPERESL.
       COPY NCPELABC.
025970 COPY XCPS1670.
025970 COPY XCPS8090.
       COPY CCPSPGA.
016503 COPY NCPPCVGS.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY REQT
014221                        '  $VAR2' BY 'REQT'.
      /
       COPY NCPEREQT.
       COPY NCPPRFUP.
       COPY NCPPRVAL.
      /
       COPY XCPPEXIT.
       COPY XCPPINIT.
      /
      ****************************************************************
      * LINKAGE COPYBOOKS -                                          *
      ****************************************************************

035393 COPY CCPSCITC.
035393 COPY CCPLCITC.
035393
035393 COPY CCPSCITU.
035393 COPY CCPLCITU.
035393
018764*COPY CCCL0064.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL0064.
       COPY CCPS0064.

018764*COPY CCCL0289.
018764 COPY CCPL0289.
016503 COPY CCPS0289.

018764*COPY CCCL2430.
018764 COPY CCPL2430.
       COPY CCPS2430.
023520
023520 COPY CCPS5020.
023520 COPY CCPL5020.
023520
018764*COPY CCCL5400.
018764 COPY CCPL5400.
       COPY CCPS5400.

018764*COPY CCCL2222.
018764 COPY CCPL2222.
016440 COPY CCPS2222.

018764*COPY CCCL5600.
018764 COPY CCPL5600.
       COPY CCPS5600.

018764*COPY NCCL0095.
018764 COPY NCPL0095.
       COPY NCPS0095.

018764*COPY NCCL0760.
025970 COPY NCPS0760.
018764 COPY NCPL0760.

018764*COPY NCCL1030.
018764 COPY NCPL1030.
       COPY NCPS1030.

018764*COPY NCCL1090.
018764 COPY NCPL1090.
       COPY NCPS1090.

018764*COPY NCCL2437.
025970 COPY NCPS2437.
018764 COPY NCPL2437.

018764*COPY NCCL7180.
018764 COPY NCPL7180.
       COPY NCPS7180.

021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.

018764*COPY XCCL0220.
025970 COPY XCPS0220.
018764 COPY XCPL0220.
035393
035393 COPY XCPS0319.
035393 COPY XCPL0319.
035393
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
020874 COPY XCPL0290.
020874 COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1680.
       COPY XCPL1680.

      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************

       COPY CCPNEDIT.

       COPY CCPNPOL.
016503 COPY CCPUPOL.
025970 COPY CCPS0620.
557668 COPY CCPL0620.

016503 COPY CCPNCVG.

010418*COPY CCPNPCOM.
010418 COPY CCPNSCOM.

       COPY NCPAREQT.
016537*COPY NCPBREQT.
       COPY NCPNREQT.
       COPY NCPUREQT.
       COPY NCPVREQT.
       COPY NCPXREQT.

016537*COPY NCPBRQCR.
       COPY NCPVRQCR.

016503 COPY CCPBRLTP.

       COPY NCPNRTAB.

557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM0090                     **
      *****************************************************************
