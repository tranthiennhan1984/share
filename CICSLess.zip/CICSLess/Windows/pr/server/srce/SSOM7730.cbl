      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM7730.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM7730                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE RETRIEVE FUNCTION     **
      **            FOR THE UTRA TABLE                               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
021239**  6.4       FUND UNIT VALUE                                  **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM7730'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      ****************************************************************
      *  DATABASE COPYBOOKS                                          *
      ****************************************************************

      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
       COPY XCWL0290.

      ****************************************************************
      *  WORKING AREA                                                *
      ****************************************************************
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-RETRIEVE       VALUE '7730'.
           05  WS-SUB                        PIC S9(04) BINARY.
           05  WS-MAX-LIST-LINES             PIC S9(04) BINARY.
           05  WS-UTR-DEFN-RULE-ID           PIC 9(004).
           05  WS-UTR-ASIGN-EFF-DT           PIC X(010).

       01  WS-CONSTANT-AREA.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970*                                      VALUE '7730'.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '7730'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWL8090.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY SCFWUTRA.
       COPY SCFRUTRA.
       COPY CCWWLOCK.
      /
       COPY SCFWUTRD.
       COPY SCFRUTRD.

      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM7730.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE WPGWS-CRNT-PGM-ID
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *-------------
       2000-RETRIEVE.
      *-------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           MOVE WS-UTR-DEFN-RULE-ID    TO WUTRA-UTR-DEFN-RULE-ID.
           MOVE WS-UTR-ASIGN-EFF-DT    TO WUTRA-UTR-ASIGN-EFF-DT.

           PERFORM  UTRA-1000-READ-TWRK-TS
               THRU UTRA-1000-READ-TWRK-TS-X.

           IF  NOT WUTRA-IO-OK
      *MSG: @2 RECORD (@1) NOT FOUND
               MOVE WUTRA-KEY               TO WGLOB-MSG-PARM (1)
               MOVE 'UTRA'                  TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000001'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X.

       2000-RETRIEVE-X.
           EXIT.

      *----------------------------
       2100-VALIDATE-KEYS.
      *----------------------------

           PERFORM  2110-EDIT-UTR-DEFN-RULE-ID
               THRU 2110-EDIT-UTR-DEFN-RULE-ID-X.

           PERFORM  2120-EDIT-UTR-ASIGN-EFF-DT
               THRU 2120-EDIT-UTR-ASIGN-EFF-DT-X.

       2100-VALIDATE-KEYS-X.
           EXIT.

      *----------------------------
       2110-EDIT-UTR-DEFN-RULE-ID.
      *----------------------------

           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE LENGTH OF MIR-UTR-DEFN-RULE-ID
             TO L0280-LENGTH.
           MOVE ZERO                    TO L0280-PRECISION.
           MOVE MIR-UTR-DEFN-RULE-ID    TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF  L0280-OK
               MOVE L0280-OUTPUT        TO WS-UTR-DEFN-RULE-ID
           ELSE
      *MSG: INVALID RULE ID
               MOVE 'SS77300001'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2110-EDIT-UTR-DEFN-RULE-ID-X.
           EXIT.

      *----------------------------
       2120-EDIT-UTR-ASIGN-EFF-DT.
      *----------------------------

           MOVE MIR-UTR-ASIGN-EFF-DT     TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE  TO WS-UTR-ASIGN-EFF-DT
           ELSE
      *MSG: INVALID ASSIGNMENT EFFECTIVE DATE
               MOVE 'SS77300002'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2120-EDIT-UTR-ASIGN-EFF-DT-X.
           EXIT.

      *-----------------
       9000-BLANK-DATA-FIELDS.
      *-----------------

           INITIALIZE MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9200-MOVE-RECORD-TO-MIR.
      *--------------------------

           MOVE RUTRA-UTR-ASIGN-TYP-CD
             TO MIR-UTR-ASIGN-TYP-CD.

           PERFORM  9210-GET-RULE-DEFN
               THRU 9210-GET-RULE-DEFN-X.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *----------------------------
       9210-GET-RULE-DEFN.
      *----------------------------

           MOVE LOW-VALUES             TO WUTRD-KEY.

           MOVE WS-UTR-DEFN-RULE-ID    TO WUTRD-UTR-DEFN-RULE-ID.

           MOVE WUTRD-KEY              TO WUTRD-ENDBR-KEY.
           MOVE HIGH-VALUES            TO WUTRD-ENDBR-UTR-DEFN-FCT-CD.

           PERFORM  UTRD-1000-BROWSE
               THRU UTRD-1000-BROWSE-X.

           PERFORM  UTRD-2000-READ-NEXT
               THRU UTRD-2000-READ-NEXT-X.

           PERFORM
               UNTIL WS-SUB > WS-MAX-LIST-LINES
               OR NOT WUTRD-IO-OK

               ADD +1                  TO WS-SUB

               IF  WS-SUB > WS-MAX-LIST-LINES
      *MSG: INTERNAL TABLE OVERFLOW. CONTACT SYSTEM
                   MOVE 'SS77300003'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE RUTRD-UTR-DEFN-FCT-CD
                     TO MIR-UTR-DEFN-FCT-CD-T (WS-SUB)

                   MOVE RUTRD-UTR-DEFN-FCT-QTY
                     TO L0290-INPUT-V00
                   MOVE ZERO           TO L0290-PRECISION
                   MOVE LENGTH OF MIR-UTR-DEFN-FCT-QTY-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN
                   PERFORM  0290-2000-FORMAT-FOR-MIR
                       THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA
                     TO MIR-UTR-DEFN-FCT-QTY-T (WS-SUB)

                   PERFORM  UTRD-2000-READ-NEXT
                       THRU UTRD-2000-READ-NEXT-X
               END-IF

           END-PERFORM.

           PERFORM  UTRD-3000-END-BROWSE
               THRU UTRD-3000-END-BROWSE-X.

       9210-GET-RULE-DEFN-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

           COMPUTE WS-MAX-LIST-LINES = LENGTH OF MIR-UTR-DEFN-FCT-CD-G
                             / LENGTH OF MIR-UTR-DEFN-FCT-CD-T (1).

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

025970     SET WS-TWRK-KEY-DEFAULT     TO TRUE.
025970
       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  UTRA
                                '$VAR2'   BY 'UTRA'.
       COPY XCPL8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
025970 COPY XCPS8090.
       COPY XCPS0290.
       COPY XCPL0290.

       COPY XCPL0260.

025970 COPY XCPS0280.
       COPY XCPL0280.

025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY SCPNUTRA.
       COPY SCPUUTRA.

       COPY SCPBUTRD.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM SSOM7730                        **
      *****************************************************************
