      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3284.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3284                                         **
      **  REMARKS:  PAAR - POLICY ACTIVITY RELATIONSHIP TABLE LIST   **
      **            THIS MODULE LISTS ENTRIES IN THE PAAR TABLE      **
      **            FOR A SPECIFIED POLICY                           **
      **                                                             **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020460**  6.4       DTCC/IPS CONNECTIVITY                            **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
030054**  7.0       PHST SEQUENCE NUMBER EXPANSION                   **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3284'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                  PIC X(04).
               88  WS-BUS-FCN-LIST            VALUE '3284'.
025970     05  WS-CONSTANT-AREA.
               10  WS-MAX-BR-CTR              PIC S9(4).
025970             88  WS-MAX-BR-CTR-DEFAULT  VALUE +100.
030054*        10  WS-PCHST-SEQ-NUM-MAX       PIC S9(03) COMP-3.
030054*            88  WS-PCHST-SEQ-NUM-MAX-DEFAULT
030054*                                       VALUE +999.
           05  WS-WORK-AREA.
025970*        10  WS-SUB                     PIC S9(4)  COMP.
025970         10  WS-SUB                     PIC S9(4)  BINARY.
025970*        10  WS-MAX-BR-CTR              PIC S9(4).
               10  WS-KEY.
                   15  WS-POL-ID              PIC X(10).
                   15  WS-PAAFLD-GR-TS        PIC X(26).
                   15  WS-PCHST-EFF-IDT-NUM   PIC X(07).
030054*            15  WS-PCHST-SEQ-NUM       PIC S9(03) COMP-3.
030054             15  WS-PCHST-SEQ-NUM       PIC S9(05) COMP-3.
025970*    05  WS-PCHST-SEQ-NUM-MAX           PIC S9(03) COMP-3.


      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY CCWWINDX.
030054 COPY XCWWCNST.
       COPY XCWWWKDT.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFWPAAR.
       COPY CCFRPAAR.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
       COPY CCWL2430.
028298 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL1640.
       COPY XCWL1646.
       COPY XCWL1660.
       COPY XCWL0290.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3284.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.
023514
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

023514*    PERFORM  9990-INIT-WORKING-STORAGE
023514*        THRU 9990-INIT-WORKING-STORAGE-X.
023514*
           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  3500-PROCESS-LIST
                        THRU 3500-PROCESS-LIST-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM3284'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------------
       3500-PROCESS-LIST.
      *------------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           IF  MIR-POL-ID  = SPACES
      *MSG:    POLICY ID IS REQUIRED
               MOVE 'CS32840001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 3500-PROCESS-LIST-X
           ELSE
               MOVE MIR-POL-ID           TO WS-POL-ID
           END-IF.

           MOVE MIR-POL-ID               TO WPOL-POL-ID.
           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
      *MSG:    POLICY ID DOES NOT EXIST
               MOVE 'XS00000070'             TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-ID               TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR        TO TRUE
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           MOVE MIR-PAAFLD-GR-TS         TO WS-PAAFLD-GR-TS.

           IF  MIR-PAAFLD-GR-TS = SPACES
               MOVE WWKDT-HIGH-TS        TO WS-PAAFLD-GR-TS
           ELSE
               PERFORM  1646-1000-BUILD-PARM-INFO
                   THRU 1646-1000-BUILD-PARM-INFO-X
               MOVE MIR-PAAFLD-GR-TS      TO L1646-TIMESTAMP
               PERFORM  1646-1000-EDIT-TIMESTAMP
                   THRU 1646-1000-EDIT-TIMESTAMP-X
               IF  L1646-EDIT-FAILED
                   SET WGLOB-RETURN-ERROR TO  TRUE
                   MOVE 'CS32840002'      TO  WGLOB-MSG-REF-INFO
      * MSG: INVALID TIMESTAMP
                   PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU  0260-1000-GENERATE-MESSAGE-X
                   GO TO 3500-PROCESS-LIST-X
              END-IF
           END-IF.

           IF  MIR-PCHST-EFF-DT = WWKDT-ZERO-DT
           OR  MIR-PCHST-EFF-DT = SPACES
               MOVE 999999              TO WS-PCHST-EFF-IDT-NUM
           ELSE
               PERFORM  3520-INVERTED-DATE
                   THRU 3520-INVERTED-DATE-X
               IF  WGLOB-RETURN-ERROR
                    GO TO 3500-PROCESS-LIST-X
               END-IF
           END-IF.

           IF  MIR-PCHST-SEQ-NUM = ZEROS
           OR  MIR-PCHST-SEQ-NUM = SPACES
030054*        MOVE 999                 TO WS-PCHST-SEQ-NUM
030054         MOVE WCNST-MAX-PCHST-SEQ-NUM-N
030054                                  TO WS-PCHST-SEQ-NUM
           ELSE
               MOVE ZERO              TO L0280-PRECISION
030054*        MOVE 3                 TO L0280-LENGTH
030054*        MOVE 3                 TO L0280-INPUT-SIZE
030054         MOVE LENGTH OF MIR-PCHST-SEQ-NUM
030054                                TO L0280-LENGTH
030054         MOVE LENGTH OF MIR-PCHST-SEQ-NUM
030054                                TO L0280-INPUT-SIZE
               MOVE MIR-PCHST-SEQ-NUM TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   MOVE L0280-OUTPUT      TO WS-PCHST-SEQ-NUM
               ELSE
                   MOVE 'CS32840004'      TO WGLOB-MSG-REF-INFO
      * MSG: ' SEQUENCE NUMBER MUST BE NUMERIC
                   PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU  0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR  TO  TRUE
                   GO TO 3500-PROCESS-LIST-X
               END-IF
           END-IF.

030054*    COMPUTE WS-PCHST-SEQ-NUM = WS-PCHST-SEQ-NUM-MAX
030054     COMPUTE WS-PCHST-SEQ-NUM = WCNST-MAX-PCHST-SEQ-NUM-N
                                    - WS-PCHST-SEQ-NUM.

           PERFORM  3600-BROWSE-REC
               THRU 3600-BROWSE-REC-X.

           PERFORM  9250-MOVE-OTHER-TO-SCREEN
               THRU 9250-MOVE-OTHER-TO-SCREEN-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *---------------------------
       3520-INVERTED-DATE.
      *---------------------------

           MOVE MIR-PCHST-EFF-DT    TO L1640-INTERNAL-DATE
           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-RETRN-OK
               MOVE L1640-INTERNAL-DATE        TO L1660-INTERNAL-DATE
               MOVE L1640-INTERNAL-DATE  TO L1660-INTERNAL-DATE
               PERFORM  1660-2000-CONVERT-INT-TO-INV
                   THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE  TO WS-PCHST-EFF-IDT-NUM
           ELSE
      * MSG:   INVALID POLICY CHANGE HISTORY DATE - @1
               MOVE 'CS32840003'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-PCHST-EFF-DT     TO WGLOB-MSG-PARM (01)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 3520-INVERTED-DATE-X
           END-IF.

       3520-INVERTED-DATE-X.
           EXIT.
      /
      *-------------------
       3600-BROWSE-REC.
      *-------------------

           MOVE HIGH-VALUES           TO WPAAR-KEY.
           MOVE LOW-VALUES            TO WPAAR-ENDBR-KEY.

           MOVE WS-POL-ID             TO WPAAR-POL-ID.
           MOVE WS-PAAFLD-GR-TS       TO WPAAR-PAAFLD-GR-TS.
           MOVE WS-PCHST-EFF-IDT-NUM  TO WPAAR-PCHST-EFF-IDT-NUM.
           MOVE WS-PCHST-SEQ-NUM      TO WPAAR-PCHST-SEQ-NUM.

           MOVE WPAAR-KEY             TO WPAAR-ENDBR-KEY.
           MOVE WWKDT-LOW-TS          TO WPAAR-ENDBR-PAAFLD-GR-TS.
           MOVE ZEROS                 TO WPAAR-ENDBR-PCHST-EFF-IDT-NUM.
           MOVE ZEROS                 TO WPAAR-ENDBR-PCHST-SEQ-NUM.

           PERFORM  PAAR-1000-BROWSE-PREV
               THRU PAAR-1000-BROWSE-PREV-X.

           PERFORM  PAAR-2000-READ-PREV
               THRU PAAR-2000-READ-PREV-X.

           PERFORM  3650-DISPLAY-RECORD
               THRU 3650-DISPLAY-RECORD-X
               VARYING WS-SUB FROM 1 BY 1
                 UNTIL WS-SUB > WS-MAX-BR-CTR
                 OR    NOT WPAAR-IO-OK.

           IF  NOT WPAAR-IO-EOF
      *MSG: TO VIEW MORE DATA SELECT MORE
               MOVE 'XS00000014'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RPAAR-POL-ID        TO MIR-POL-ID
               MOVE RPAAR-PAAFLD-GR-TS
                                        TO MIR-PAAFLD-GR-TS
               MOVE RPAAR-PCHST-EFF-IDT-NUM  TO L1660-INVERTED-DATE
               PERFORM  1660-3000-CONVERT-INV-TO-INT
                   THRU 1660-3000-CONVERT-INV-TO-INT-X
               MOVE L1660-INVERTED-DATE      TO L1640-INTERNAL-DATE
               PERFORM  1640-8000-INTERNAL-TO-MIR
                   THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE      TO MIR-PCHST-EFF-DT

030054*        COMPUTE L0290-INPUT-V00   = WS-PCHST-SEQ-NUM-MAX
030054         COMPUTE L0290-INPUT-V00   = WCNST-MAX-PCHST-SEQ-NUM-N
                                         - RPAAR-PCHST-SEQ-NUM
               MOVE 0                        TO L0290-PRECISION
               MOVE LENGTH OF MIR-PCHST-SEQ-NUM
                                           TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-PCHST-SEQ-NUM
               SET WGLOB-MORE-DATA-EXISTS    TO TRUE
           ELSE
               IF  MIR-PAAFLD-GR-TS-T (1) > SPACES
                   MOVE MIR-PAAFLD-GR-TS-T (1)
                                     TO MIR-PAAFLD-GR-TS
                   MOVE MIR-PCHST-EFF-DT-T (1)
                                     TO MIR-PCHST-EFF-DT
                   MOVE MIR-PCHST-SEQ-NUM-T (1)
                                     TO MIR-PCHST-SEQ-NUM
      *MSG: END OF FILE REACHED
                   MOVE 'XS00000025'    TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      *MSG: NO RECORD FOUND FOR DISPLAY
                   MOVE 'XS00000034'    TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           PERFORM  PAAR-3000-END-BROWSE-PREV
               THRU PAAR-3000-END-BROWSE-PREV-X.

       3600-BROWSE-REC-X.
           EXIT.
      /
      *--------------------
       3650-DISPLAY-RECORD.
      *--------------------

           MOVE RPAAR-PAAFLD-GR-TS
                              TO MIR-PAAFLD-GR-TS-T       (WS-SUB).
           MOVE RPAAR-PCHST-EFF-IDT-NUM    TO L1660-INVERTED-DATE.
           PERFORM  1660-3000-CONVERT-INV-TO-INT
               THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE       TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO MIR-PCHST-EFF-DT-T (WS-SUB).

030054*    COMPUTE L0290-INPUT-V00     = WS-PCHST-SEQ-NUM-MAX
030054     COMPUTE L0290-INPUT-V00     = WCNST-MAX-PCHST-SEQ-NUM-N
                                       - RPAAR-PCHST-SEQ-NUM.
           MOVE 0                          TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PCHST-SEQ-NUM
                                           TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA          TO MIR-PCHST-SEQ-NUM-T
                                              (WS-SUB).

           PERFORM PAAR-2000-READ-PREV
              THRU PAAR-2000-READ-PREV-X.

       3650-DISPLAY-RECORD-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACE                   TO MIR-PAAFLD-GR-TS-G.
           MOVE SPACE                   TO MIR-PCHST-EFF-DT-G.
           MOVE SPACE                   TO MIR-PCHST-SEQ-NUM-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9250-MOVE-OTHER-TO-SCREEN.
      *--------------------------

           MOVE RPOL-SBSDRY-CO-ID        TO MIR-SBSDRY-CO-ID.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           MOVE L2430-CLI-NM-COMPRESSED  TO MIR-DV-OWN-CLI-NM.

       9250-MOVE-OTHER-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1646-0000-INIT-PARM-INFO
025970         THRU 1646-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     INITIALIZE WWKDT-WORK-FIELDS.
           INITIALIZE  WS-WORK-AREA.
025970     SET  WS-MAX-BR-CTR-DEFAULT   TO TRUE.
030054*    SET  WS-PCHST-SEQ-NUM-MAX-DEFAULT TO TRUE.
           SET  MIR-RETRN-OK            TO TRUE.
           MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
025970*    MOVE +100                    TO WS-MAX-BR-CTR.
025970*    MOVE 999                     TO WS-PCHST-SEQ-NUM-MAX.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
       COPY CCPS2430.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL2430.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
      /
       COPY XCPS1646.
       COPY XCPL1646.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPVPAAR.
      /
       COPY CCPNPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM3284                     *
      ****************************************************************
