      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7322.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7322                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE UPDATE FUNCTION       **
      **            FOR THE PDBG TABLE                               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020475**  6.4       DEATH BENEFIT GUARANTEES AND RIDERS              **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7322'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
      /
       01  WS-WORKING-STORAGE.
           05  WS-CONSTANT-FIELDS.
025970*        10  WS-TWRK-KEY                     PIC X(04)
025970*                                            VALUE '7320'.

025970         10  WS-TWRK-KEY                     PIC X(04).
025970             88 WS-TWRK-KEY-DEFAULT          VALUE '7320'.
           05  WS-WORK-FIELDS.
               10  WS-BUS-FCN-ID                   PIC X(04).
                   88  WS-BUS-FCN-UPDATE           VALUE '7322'.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWLOCK.
       COPY XCWEBLCH.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWPH.
       COPY CCFRPH.
      /
       COPY CCFWPDBG.
       COPY CCFRPDBG.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWL0280.
       COPY XCWL8090.
       COPY XCWL8960.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7322.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------


           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
025999*             MOVE 'XS00000000'         TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE WPGWS-CRNT-PGM-ID    TO WGLOB-MSG-PARM (2)
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-UPDATE.
      *------------

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  5100-LOCK-PDBG-RECORD
               THRU 5100-LOCK-PDBG-RECORD-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  8000-EDIT-DATA-FIELDS
               THRU 8000-EDIT-DATA-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW NOT = ZERO
               PERFORM PDBG-3000-UNLOCK
                  THRU PDBG-3000-UNLOCK-X
               PERFORM PH-3000-UNLOCK
                  THRU PH-3000-UNLOCK-X
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  5200-UPDATE-PDBG
               THRU 5200-UPDATE-PDBG-X.

       2000-UPDATE-X.
           EXIT.
      /

      *----------------------
       5100-LOCK-PDBG-RECORD.
      *----------------------

           MOVE WPDBG-PLAN-ID          TO WPH-PLAN-ID.
           PERFORM PH-2000-UPDATE-TWRK-TS
              THRU PH-2000-UPDATE-TWRK-TS-X.

           IF  WPH-IO-NOT-FOUND
      *MSG: 'RECORD (@1) NOT FOUND'
               MOVE WPH-KEY            TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 5100-LOCK-PDBG-RECORD-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
      *  NOT COMPLETE
               MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
               MOVE 'PH'                  TO WGLOB-MSG-PARM (01)
               MOVE WPH-KEY               TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 5100-LOCK-PDBG-RECORD-X
           END-IF


           PERFORM  PDBG-1000-READ-FOR-UPDATE
               THRU PDBG-1000-READ-FOR-UPDATE-X

           IF  NOT WPDBG-IO-OK
               PERFORM PH-3000-UNLOCK
                  THRU PH-3000-UNLOCK-X
      *MSG:    RECORD (@1) LOST IN DELETE
               MOVE WPDBG-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 5100-LOCK-PDBG-RECORD-X
           END-IF.

           PERFORM  9350-SETUP-AUDIT-INFO
               THRU 9350-SETUP-AUDIT-INFO-X.

       5100-LOCK-PDBG-RECORD-X.
           EXIT.


      *------------------
       5200-UPDATE-PDBG.
      *------------------

           PERFORM  PDBG-2000-REWRITE
               THRU PDBG-2000-REWRITE-X.

           PERFORM  PH-2000-REWRITE
               THRU PH-2000-REWRITE-X.

           PERFORM  9350-SETUP-AUDIT-INFO
               THRU 9350-SETUP-AUDIT-INFO-X.

           PERFORM  PH-1000-READ-TWRK-TS
               THRU PH-1000-READ-TWRK-TS-X.

       5200-UPDATE-PDBG-X.
           EXIT.



      *---------------
       7000-BUILD-KEYS.
      *---------------

           MOVE LOW-VALUES            TO WPDBG-KEY.
           MOVE MIR-PLAN-ID           TO WPDBG-PLAN-ID.
           MOVE MIR-LOC-GR-ID         TO WPDBG-LOC-GR-ID.
           MOVE MIR-PLAN-DBG-TYP-CD   TO WPDBG-PLAN-DBG-TYP-CD.

       7000-BUILD-KEYS-X.
           EXIT.


      *----------------------------
       8000-EDIT-DATA-FIELDS.
      *----------------------------

           PERFORM  8110-EDIT-DBG-BASIC-CD
               THRU 8110-EDIT-DBG-BASIC-CD-X.

           PERFORM  8120-EDIT-DBG-LOCK-QTY
               THRU 8120-EDIT-DBG-LOCK-QTY-X.

           PERFORM  8130-EDIT-DBG-LOCK-CD
               THRU 8130-EDIT-DBG-LOCK-CD-X.

           PERFORM  8140-EDIT-DBG-RESET-DUR
               THRU 8140-EDIT-DBG-RESET-DUR-X.

           PERFORM  8150-EDIT-DBG-GUAR-DUR
               THRU 8150-EDIT-DBG-GUAR-DUR-X.

           PERFORM  8170-EDIT-DBG-MAX-CD
               THRU 8170-EDIT-DBG-MAX-CD-X.

           PERFORM  8180-EDIT-DBG-MAX-AGE
               THRU 8180-EDIT-DBG-MAX-AGE-X.

           PERFORM  8190-EDIT-DBG-PREM-FCT
               THRU 8190-EDIT-DBG-PREM-FCT-X.

           PERFORM  8200-EDIT-DBG-LOAN-IND
               THRU 8200-EDIT-DBG-LOAN-IND-X.

           PERFORM  8210-EDIT-DBG-FCT-CD
               THRU 8210-EDIT-DBG-FCT-CD-X.

       8000-EDIT-DATA-FIELDS-X.
           EXIT.


      *-----------------------
       8110-EDIT-DBG-BASIC-CD.
      *-----------------------

           IF  MIR-PLAN-DBG-BASIC-CD = RPDBG-PLAN-DBG-BASIC-CD
               GO TO 8110-EDIT-DBG-BASIC-CD-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'PLAN-DBG-BASIC-CD'       TO L8960-AV-TBL-CD.
           MOVE MIR-PLAN-DBG-BASIC-CD     TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID BASIC PLAN OPTION TYPE
               MOVE 'CS73220001'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8110-EDIT-DBG-BASIC-CD-X
           END-IF.

           MOVE MIR-PLAN-DBG-BASIC-CD  TO RPDBG-PLAN-DBG-BASIC-CD

           IF  NOT RPDBG-PLAN-DBG-TYP-BASIC-PLAN
           AND NOT RPDBG-PLAN-DBG-BASIC-NONE
      *MSG: BASIC PLAN OPTION NOT APPLICABLE FOR THIS GUARANTEE TYPE
               MOVE 'CS73220002'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


       8110-EDIT-DBG-BASIC-CD-X.
           EXIT.


      *-----------------------
       8120-EDIT-DBG-LOCK-QTY.
      *-----------------------

           MOVE MIR-PLAN-DBG-LOCK-QTY           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-PLAN-DBG-LOCK-QTY TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE                TO L0280-LENGTH.
           MOVE ZERO                            TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED         TO TRUE.
           SET L0280-SPACES-PERMITTED           TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               PERFORM  8122-EDIT-LOCK-QTY-RESET
                   THRU 8122-EDIT-LOCK-QTY-RESET-X
           ELSE
      *MSG: INVALID MAXIMUM LOCK-IN COUNT
               MOVE 'CS73220003'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8120-EDIT-DBG-LOCK-QTY-X.
           EXIT.

      *---------------------------
       8122-EDIT-LOCK-QTY-RESET.
      *---------------------------

           IF  RPDBG-PLAN-DBG-TYP-RESET
           AND L0280-OUTPUT-V00 = ZERO
      *MSG MAXIMUM NUMBER OF LOCK-INS MUST BE > 0 FOR RESET/LOCK OPTION
               MOVE 'CS73220009'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE L0280-OUTPUT-V00   TO RPDBG-PLAN-DBG-LOCK-QTY.

       8122-EDIT-LOCK-QTY-RESET-X.
           EXIT.

      *----------------------
       8130-EDIT-DBG-LOCK-CD.
      *----------------------

           IF  MIR-PLAN-DBG-LOCK-CD = RPDBG-PLAN-DBG-LOCK-CD
               GO TO 8130-EDIT-DBG-LOCK-CD-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'PLAN-DBG-LOCK-CD'        TO L8960-AV-TBL-CD.
           MOVE MIR-PLAN-DBG-LOCK-CD      TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID MAXIMUM PERIOD CODE
               MOVE 'CS73220004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8130-EDIT-DBG-LOCK-CD-X
           END-IF.


           MOVE MIR-PLAN-DBG-LOCK-CD  TO RPDBG-PLAN-DBG-LOCK-CD.


           IF  RPDBG-PLAN-DBG-TYP-RESET
           AND RPDBG-PLAN-DBG-LOCK-NONE
      *MSG MAXIMUM PERIOD CODE HAS TO BE ENTERED FOR DEATH BENEFIT
      *    GUARANTEE TYPE = RESET/LOCK-IN OPTION.
               MOVE 'CS73220017'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8130-EDIT-DBG-LOCK-CD-X
           END-IF.


           IF  NOT RPDBG-PLAN-DBG-TYP-RESET
           AND NOT RPDBG-PLAN-DBG-LOCK-NONE
      *MSG MAXIMUM PERIOD CODE CAN'T BE ENTERED FOR DEATH BENEFIT
      *    GUARANTEE TYPE OTHER THAN RESET/LOCK-IN OPTION.
               MOVE 'CS73220018'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


       8130-EDIT-DBG-LOCK-CD-X.
           EXIT.


      *-----------------------
       8140-EDIT-DBG-RESET-DUR.
      *-----------------------

           MOVE MIR-PLAN-DBG-RESET-DUR          TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-PLAN-DBG-RESET-DUR TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE                TO L0280-LENGTH.
           MOVE ZERO                            TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED         TO TRUE.
           SET L0280-SPACES-PERMITTED           TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG: INVALID RESET FREQUENCY
               MOVE 'CS73220005'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8140-EDIT-DBG-RESET-DUR-X
           END-IF.

           MOVE L0280-OUTPUT-V00        TO RPDBG-PLAN-DBG-RESET-DUR.

           IF (RPDBG-PLAN-DBG-TYP-RESET
           OR RPDBG-PLAN-DBG-TYP-ANNV-VALU
           OR RPDBG-PLAN-DBG-TYP-MAV)
           AND L0280-OUTPUT-V00 NOT > ZERO
      *MSG: RESET FREQUENCY MUST BE GREATER THAN 00 FOR THE DEATH
      *     BENEFIT GUARANTEE TYPE
                 MOVE 'CS73220006'            TO WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


       8140-EDIT-DBG-RESET-DUR-X.
           EXIT.


      *-----------------------
       8150-EDIT-DBG-GUAR-DUR.
      *-----------------------

           MOVE MIR-PLAN-DBG-GUAR-DUR           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-PLAN-DBG-GUAR-DUR TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE                TO L0280-LENGTH.
           MOVE ZERO                            TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED         TO TRUE.
           SET L0280-SPACES-PERMITTED           TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG: INVALID GUARANTEE TIMEFRAME
               MOVE 'CS73220007'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8150-EDIT-DBG-GUAR-DUR-X
           END-IF.

           MOVE L0280-OUTPUT-V00        TO RPDBG-PLAN-DBG-GUAR-DUR.

           IF (RPDBG-PLAN-DBG-TYP-RESET
           OR  RPDBG-PLAN-DBG-TYP-ANNV-VALU
           OR  RPDBG-PLAN-DBG-TYP-MAV)
           AND L0280-OUTPUT-V00 NOT > ZERO
      *MSG: GUARANTEE TIMEFRAME MUST BE GREATER THAN 00 FOR THE DEATH
      *     BENEFIT GUARANTEE TYPE
               MOVE 'CS73220008'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


       8150-EDIT-DBG-GUAR-DUR-X.
           EXIT.



      *--------------------
       8170-EDIT-DBG-MAX-CD.
      *--------------------

           IF  MIR-PLAN-DBG-MAX-CD = RPDBG-PLAN-DBG-MAX-CD
               GO TO 8170-EDIT-DBG-MAX-CD-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'PLAN-DBG-MAX-CD'         TO L8960-AV-TBL-CD.
           MOVE MIR-PLAN-DBG-MAX-CD       TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID PREMIUM ROLLUP MAXIMUM CODE
               MOVE 'CS73220010'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8170-EDIT-DBG-MAX-CD-X
           END-IF.

           MOVE MIR-PLAN-DBG-MAX-CD  TO RPDBG-PLAN-DBG-MAX-CD

           IF  RPDBG-PLAN-DBG-TYP-ROLU
           AND RPDBG-PLAN-DBG-MAX-NONE
      *MSG ROLL-UP MAXIMUM CODE HAS TO BE ENTERED FOR DEATH BENEFIT
      *    GUARANTEE TYPE = PREMIUM ROLL-UP
               MOVE 'CS73220019'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8170-EDIT-DBG-MAX-CD-X
           END-IF.


           IF  NOT RPDBG-PLAN-DBG-TYP-ROLU
           AND NOT RPDBG-PLAN-DBG-MAX-NONE
      *MSG ROLL-UP MAXIMUM CODE CAN'T BE ENTERED FOR DEATH BENEFIT
      *    GUARANTEE TYPE OTHER THAN PREMIUM ROLL-UP
               MOVE 'CS73220020'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8170-EDIT-DBG-MAX-CD-X.
           EXIT.


      *----------------------
       8180-EDIT-DBG-MAX-AGE.
      *----------------------

           MOVE MIR-PLAN-DBG-MAX-AGE            TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-PLAN-DBG-MAX-AGE  TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE                TO L0280-LENGTH.
           MOVE ZERO                            TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED         TO TRUE.
           SET L0280-SPACES-PERMITTED           TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG: INVALID PREMIUM ROLLUP MAXIMUM AGE
               MOVE 'CS73220011'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8180-EDIT-DBG-MAX-AGE-X
           END-IF.

           MOVE L0280-OUTPUT-V00        TO RPDBG-PLAN-DBG-MAX-AGE.

           IF  RPDBG-PLAN-DBG-TYP-ROLU
           AND RPDBG-PLAN-DBG-MAX-TO-AGE
           AND L0280-OUTPUT-V00 NOT > ZERO
      *MSG: PREMIUM ROLLUP MAXIMUM AGE MUST BE GREATER THAN 00 FOR DEATH
      *     BENEFIT GUARANTEE TYPE = PREMIUM ROLL-UP
               MOVE 'CS73220012'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


       8180-EDIT-DBG-MAX-AGE-X.
           EXIT.


      *-----------------------
       8190-EDIT-DBG-PREM-FCT.
      *-----------------------

           MOVE MIR-PLAN-DBG-PREM-FCT           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-PLAN-DBG-PREM-FCT TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           MOVE 2                               TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED         TO TRUE.
           SET L0280-SPACES-PERMITTED           TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG: INVALID ROLLUP MAXIMUM PREMIUM MULTIPLE
               MOVE 'CS73220013'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8190-EDIT-DBG-PREM-FCT-X
           END-IF.

           MOVE L0280-OUTPUT-V02        TO RPDBG-PLAN-DBG-PREM-FCT.

           IF  RPDBG-PLAN-DBG-TYP-ROLU
           AND RPDBG-PLAN-DBG-MAX-MULT-NPREM
           AND L0280-OUTPUT-V00 NOT > ZERO
      *MSG: ROLLUP MAXIMUM PREMIUM MULTIPLE MUST BE GREATER THAN 00 FOR
      *     DEATH BENEFIT GUARANTEE TYPE = PREMIUM ROLL-UP
               MOVE 'CS73220014'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8190-EDIT-DBG-PREM-FCT-X.
           EXIT.


      *-----------------------
       8200-EDIT-DBG-LOAN-IND.
      *-----------------------

           IF  MIR-PLAN-DBG-LOAN-IND = RPDBG-PLAN-DBG-LOAN-IND
               GO TO 8200-EDIT-DBG-LOAN-IND-X
           END-IF.

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'PLAN-DBG-LOAN-IND'       TO L8960-AV-TBL-CD.
           MOVE MIR-PLAN-DBG-LOAN-IND     TO L8960-AV-CD.
           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.
           IF  NOT L8960-RETRN-OK
      *MSG:  INVALID LOAN INCLUDE INDICATOR
               MOVE 'CS73220015'     TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE MIR-PLAN-DBG-LOAN-IND  TO RPDBG-PLAN-DBG-LOAN-IND
           END-IF.

       8200-EDIT-DBG-LOAN-IND-X.
           EXIT.


      *--------------------
       8210-EDIT-DBG-FCT-CD.
      *--------------------

           IF  MIR-PLAN-DBG-FCT-CD = EBLCH-BLANK-FIELD-CHAR
           OR  MIR-PLAN-DBG-FCT-CD = SPACE
      *MSG:  INVALID PLAN UNIT TYPE FACTOR CODE
               MOVE 'CS73220016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8210-EDIT-DBG-FCT-CD-X
           END-IF.

           MOVE MIR-PLAN-DBG-FCT-CD   TO WEDIT-ETBL-VALU-ID.

           PERFORM  UVFT-1000-EDIT
               THRU UVFT-1000-EDIT-X.

           IF  WEDIT-IO-OK
               MOVE MIR-PLAN-DBG-FCT-CD TO RPDBG-PLAN-DBG-FCT-CD
           ELSE
      *MSG:  INVALID PLAN UNIT TYPE FACTOR CODE
               MOVE 'CS73220016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8210-EDIT-DBG-FCT-CD-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES              TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE  TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------
       9350-SETUP-AUDIT-INFO.
      *----------------------

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM  PDBG-1000-CALL-AUDIT
                   THRU PDBG-1000-CALL-AUDIT-X
           END-IF.

       9350-SETUP-AUDIT-INFO-X.
           EXIT.

      *-------------------------
       9990-INIT-WORKING-STORAGE.
      *-------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORK-FIELDS.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-TWRK-KEY-DEFAULT      TO TRUE.
025970           
025970     MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPEUVFT.
       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  PH
                                '$VAR2'   BY 'PH'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL8090.
       COPY XCPS8960.
       COPY XCPL8960.
       COPY CCPLPDBG.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNEDIT.
       COPY CCPNPH.
       COPY CCPUPH.
       COPY CCPUPDBG.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM7322
      *****************************************************************
