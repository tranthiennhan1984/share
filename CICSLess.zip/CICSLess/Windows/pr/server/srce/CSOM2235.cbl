      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2235.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2235                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE CLIENT INQUIRY LIST   **
      **            FUNCTION FOR THE CLNM TABLE - MATCH EQUAL        **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015510**  6.0       CLIENT ENHANCEMENTS                              **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016548**  6.2       CHANGE COMP TO BINARY                            **
016103**  6.3       JAPANESE SEARCH ENHANCEMENTS (6.1.2J)            **
018732**  6.3       CLIENT RETRIEVAL ENHANCEMENTS                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019154**  6.3       USE KANJI FOR PRIMARY ADDRESS                    **
020462**  6.4       ISO DATE STANDARDIZATION                         **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023118**  6.5       CODE CLEAN-UP AND STANDARDIZATION                **
023434**  6.5       EXPAND ADDRESS LINE                              **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2235'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

018764*COPY XCWLPTR.
014590*COPY XCWL0030.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-CLI-INQ-EQUAL VALUE '2235'.
016548*    05  WS-SUB                       PIC S9(4) VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4) VALUE ZERO BINARY.
025970         88 WS-SUB-DEFAULT            VALUE ZERO.
016548*    05  WS-MAX-LIST-LINES            PIC S9(4) VALUE 10   COMP.
016548     05  WS-MAX-LIST-LINES            PIC S9(4) VALUE 10   BINARY.
025970         88 WS-MAX-LIST-LINES-DEFAULT            VALUE 10.
           05  WS-INT-CLI-BTH-DT            PIC X(10).
           05  WS-MIR-CLI-SEX-CD            PIC X(01).
               88  WS-MIR-CLI-SEX-VALID     VALUE ' ' 'M' 'F' 'C'.
           05  WS-MATCH-IND                 PIC X(01).
               88  WS-MATCH-NO              VALUE 'N'.
               88  WS-MATCH                 VALUE 'Y'.
016103     05  WS-PHONETIC-SUR-NAME         PIC X(25).
016103     05  WS-PHONETIC-GIV-NAME         PIC X(25).
020478     05  WS-CLI-PREV-NM-IND           PIC X(01).
020478         88  WS-CLI-PREV-NM-NO        VALUE 'N'.
020478         88  WS-CLI-PREV-NM-YES       VALUE 'Y'.
020478     05  WS-CLI-PREV-ADDR-IND         PIC X(01).
020478         88  WS-CLI-PREV-ADDR-NO      VALUE 'N'.
020478         88  WS-CLI-PREV-ADDR-YES     VALUE 'Y'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWEBLCH.
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWCLI.
       COPY CCFRCLI.
      /
020478*COPY CCFWCLIA.
020478*COPY CCFRCLIA.
      /
       COPY CCFWCLID.
      /
016103 COPY CCFWCLNO.
       COPY CCFWCLNN.
       COPY CCFWCLNM.
       COPY CCFRCLNM.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
016103 COPY CCWL2810.
       COPY CCWL0620.
       COPY XCWLDTLK.
       COPY XCWL1640.
018732 COPY CCWL2435.
020478 COPY CCWL2440.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2235.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

023118     PERFORM  9990-INIT-WORKING-STORAGE
023118         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CLI-INQ-EQUAL
                    PERFORM  2000-CLI-INQ-EQUAL
                        THRU 2000-CLI-INQ-EQUAL-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2235'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *-------------------
       2000-CLI-INQ-EQUAL.
      *-------------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.
      *
      *  EDIT THE DATA ENTERED
      *
           PERFORM  8000-EDITS
               THRU 8000-EDITS-X.

           IF  WGLOB-MSG-ERROR-SW = ZERO
               CONTINUE
           ELSE
               SET MIR-RETRN-EDIT-ERROR
                 TO TRUE
               GO TO 2000-CLI-INQ-EQUAL-X
           END-IF.

016103*    IF  MIR-DV-SRCH-GR-KATAKANA
018732     IF  MIR-CLI-INDV-GR-KATAKANA
016103         PERFORM  2005-CLI-INQ-EQUAL-KATAKANA
016103             THRU 2005-CLI-INQ-EQUAL-KATAKANA-X
016103         GO TO 2000-CLI-INQ-EQUAL-X
016103     END-IF.
      *
      *  BUILD THE LIST BASED ON THE MATCH CRITERIA
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  CLNN-1000-BROWSE
               THRU CLNN-1000-BROWSE-X.

           PERFORM  CLNN-2000-READ-NEXT
               THRU CLNN-2000-READ-NEXT-X.

           IF  WCLNN-IO-EOF
               PERFORM  CLNN-3000-END-BROWSE
                   THRU CLNN-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-CLI-INQ-EQUAL-X
           END-IF.

           MOVE ZERO
              TO WS-SUB.

           PERFORM  2010-BROWSE-CLNN
               THRU 2010-BROWSE-CLNN-X
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WCLNN-IO-EOF.

           IF  WCLNN-IO-EOF
               CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS
                 TO TRUE
               MOVE RCLNM-CLI-INDV-SUR-NM
                 TO MIR-CLI-INDV-SUR-NM
               MOVE RCLNM-CLI-INDV-GIV-NM
                 TO MIR-CLI-INDV-GIV-NM
               MOVE RCLNM-CLI-ID
                 TO MIR-CLI-ID
           END-IF.

018732*MSG 'NO MATCH RECORD TO DISPLAY'
018732     IF WS-SUB = ZERO
018732        MOVE 'XS00000034'         TO WGLOB-MSG-REF-INFO
018732        PERFORM  0260-1000-GENERATE-MESSAGE
018732            THRU 0260-1000-GENERATE-MESSAGE-X
018732        SET MIR-RETRN-RQST-FAILED TO TRUE
018732     END-IF.

           PERFORM  CLNN-3000-END-BROWSE
               THRU CLNN-3000-END-BROWSE-X.

       2000-CLI-INQ-EQUAL-X.
           EXIT.


016103*---------------------------
016103 2005-CLI-INQ-EQUAL-KATAKANA.
016103*---------------------------
016103*
016103*  BUILD THE LIST BASED ON THE MATCH CRITERIA
016103*
016103     PERFORM  7005-BUILD-KEYS
016103         THRU 7005-BUILD-KEYS-X.
016103
016103     PERFORM  CLNO-1000-BROWSE
016103         THRU CLNO-1000-BROWSE-X.
016103
016103     PERFORM  CLNO-2000-READ-NEXT
016103         THRU CLNO-2000-READ-NEXT-X.
016103
016103     IF  WCLNO-IO-EOF
016103         PERFORM  CLNO-3000-END-BROWSE
016103             THRU CLNO-3000-END-BROWSE-X
016103*MSG: 'NO RECORDS FOUND TO DISPLAY'
016103         MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
016103         PERFORM  0260-1000-GENERATE-MESSAGE
016103             THRU 0260-1000-GENERATE-MESSAGE-X
016103         SET MIR-RETRN-RQST-FAILED
016103           TO TRUE
016103         GO TO 2005-CLI-INQ-EQUAL-KATAKANA-X
016103     END-IF.
016103
016103     MOVE ZERO
016103        TO WS-SUB.
016103
016103     PERFORM  2015-BROWSE-CLNO
016103         THRU 2015-BROWSE-CLNO-X
016103         UNTIL   WS-SUB > WS-MAX-LIST-LINES
016103         OR      WCLNO-IO-EOF.
016103
016103     IF  WCLNO-IO-EOF
016103         CONTINUE
016103     ELSE
016103         SET WGLOB-MORE-DATA-EXISTS
016103           TO TRUE
016103         MOVE RCLNM-CLI-INDV-SUR-NM
016103           TO MIR-CLI-INDV-SUR-NM
016103         MOVE RCLNM-CLI-INDV-GIV-NM
016103           TO MIR-CLI-INDV-GIV-NM
016103         MOVE RCLNM-CLI-ID
016103           TO MIR-CLI-ID
016103     END-IF.
016103
016103     PERFORM  CLNO-3000-END-BROWSE
016103         THRU CLNO-3000-END-BROWSE-X.
016103
016103 2005-CLI-INQ-EQUAL-KATAKANA-X.
016103     EXIT.

      *-----------------
       2010-BROWSE-CLNN.
      *-----------------
      *
      *  DISPLAY ROWS MATCHING THE ENTERED CRITERIA
      *
           PERFORM  2100-MATCH-CRITERIA
               THRU 2100-MATCH-CRITERIA-X.

           IF  WS-MATCH
               ADD  1
                  TO WS-SUB

               IF  WS-SUB > WS-MAX-LIST-LINES
016103             MOVE RCLNM-CLI-ID     TO MIR-CLI-ID
                   GO TO 2010-BROWSE-CLNN-X
               END-IF

               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           PERFORM  CLNN-2000-READ-NEXT
               THRU CLNN-2000-READ-NEXT-X.

       2010-BROWSE-CLNN-X.
           EXIT.

016103*-----------------
016103 2015-BROWSE-CLNO.
016103*-----------------
016103*
016103*  DISPLAY ROWS MATCHING THE ENTERED CRITERIA
016103*
016103     PERFORM  2100-MATCH-CRITERIA
016103         THRU 2100-MATCH-CRITERIA-X.
016103
016103     IF  WS-MATCH
016103         ADD  1         TO WS-SUB
016103
016103         IF  WS-SUB > WS-MAX-LIST-LINES
016103             MOVE RCLNM-CLI-ID     TO MIR-CLI-ID
016103             GO TO 2015-BROWSE-CLNO-X
016103         END-IF
016103
016103         PERFORM  9200-MOVE-RECORD-TO-SCREEN
016103             THRU 9200-MOVE-RECORD-TO-SCREEN-X
016103     END-IF.
016103
016103     PERFORM  CLNO-2000-READ-NEXT
016103         THRU CLNO-2000-READ-NEXT-X.
016103
016103 2015-BROWSE-CLNO-X.
016103     EXIT.

      *--------------------
       2100-MATCH-CRITERIA.
      *--------------------

           SET  WS-MATCH
              TO TRUE.

020478* CHECK IF IT IS A CURRENT NAME
020478     PERFORM  2435-1000-BUILD-PARM-INFO
020478         THRU 2435-1000-BUILD-PARM-INFO-X.
020478
020478     MOVE RCLNM-CLI-ID        TO L2435-CLI-ID.
020478
020478     PERFORM  2435-2000-CRNT-CLI-NAME
020478         THRU 2435-2000-CRNT-CLI-NAME-X.
020478
020478     IF  L2435-CLI-INDV-EFF-DT NOT = RCLNM-CLI-INDV-EFF-DT
020478         SET  WS-MATCH-NO   TO TRUE
020478         GO TO 2100-MATCH-CRITERIA-X
020478     END-IF.
020478
016103*    IF  MIR-CLI-INDV-SUR-NM NOT = RCLNM-CLI-INDV-SUR-NM
016103*        SET  WS-MATCH-NO
016103*          TO TRUE
016103*        GO TO 2100-MATCH-CRITERIA-X
016103*    END-IF.
016103*
016103*    IF  MIR-CLI-INDV-GIV-NM NOT = RCLNM-CLI-INDV-GIV-NM
016103*        SET  WS-MATCH-NO
016103*          TO TRUE
016103*        GO TO 2100-MATCH-CRITERIA-X
016103*    END-IF.
016103*
016103     EVALUATE TRUE
016103
016103*        WHEN MIR-DV-SRCH-GR-KATAKANA
018732         WHEN MIR-CLI-INDV-GR-KATAKANA
016103              PERFORM  2120-MATCH-CRITERIA-PHONETIC
016103                  THRU 2120-MATCH-CRITERIA-PHONETIC-X
016103
016103         WHEN OTHER
016103              PERFORM  2110-MATCH-CRITERIA-NAME
016103                  THRU 2110-MATCH-CRITERIA-NAME-X
016103
016103     END-EVALUATE.

           MOVE LOW-VALUES              TO WCLID-KEY.
           MOVE RCLNM-CLI-ID            TO WCLID-CLI-ID.
           MOVE WS-MIR-CLI-SEX-CD       TO WCLID-ENDBR-CLI-SEX-CD.

           IF  WS-INT-CLI-BTH-DT = SPACES
               MOVE WWKDT-LOW-DT        TO WCLID-CLI-BTH-DT
           ELSE
               MOVE WS-INT-CLI-BTH-DT   TO WCLID-CLI-BTH-DT
           END-IF.

           MOVE WCLID-KEY               TO WCLID-ENDBR-KEY.
           MOVE HIGH-VALUES             TO WCLID-ENDBR-CLI-SEX-CD.
           MOVE WWKDT-HIGH-DT           TO WCLID-ENDBR-CLI-BTH-DT.

           PERFORM  CLID-4000-BROWSE-INDEX
               THRU CLID-4000-BROWSE-INDEX-X.

           IF  NOT WCLID-IO-OK
               SET  WS-MATCH-NO
                 TO TRUE
               GO TO 2100-MATCH-CRITERIA-X
           END-IF.

           PERFORM  CLID-5000-READ-NEXT-INDEX
               THRU CLID-5000-READ-NEXT-INDEX-X.

           IF  NOT WCLID-IO-OK
               SET  WS-MATCH-NO
                 TO TRUE
           END-IF.

           PERFORM  CLID-6000-END-BROWSE-INDEX
               THRU CLID-6000-END-BROWSE-INDEX-X.

           IF  WS-MATCH-NO
               GO TO 2100-MATCH-CRITERIA-X
           END-IF.

           IF  WS-INT-CLI-BTH-DT NOT = SPACES
           AND WS-INT-CLI-BTH-DT NOT = RCLI-CLI-BTH-DT
               SET  WS-MATCH-NO
                 TO TRUE
               GO TO 2100-MATCH-CRITERIA-X
           END-IF.

           IF  WS-MIR-CLI-SEX-CD NOT = SPACES
           AND WS-MIR-CLI-SEX-CD NOT = RCLI-CLI-SEX-CD
               SET  WS-MATCH-NO
                 TO TRUE
               GO TO 2100-MATCH-CRITERIA-X
           END-IF.

       2100-MATCH-CRITERIA-X.
           EXIT.
      /
016103*-------------------------
016103 2110-MATCH-CRITERIA-NAME.
016103*-------------------------
016103
016103     IF  MIR-CLI-INDV-SUR-NM NOT = RCLNM-CLI-INDV-SUR-NM
016103         SET  WS-MATCH-NO
016103           TO TRUE
016103         GO TO 2110-MATCH-CRITERIA-NAME-X
016103     END-IF.
016103
016103     IF  MIR-CLI-INDV-GIV-NM NOT = RCLNM-CLI-INDV-GIV-NM
016103         SET  WS-MATCH-NO
016103           TO TRUE
016103         GO TO 2110-MATCH-CRITERIA-NAME-X
016103     END-IF.
016103
016103 2110-MATCH-CRITERIA-NAME-X.
016103     EXIT.
016103
016103*----------------------------
016103 2120-MATCH-CRITERIA-PHONETIC.
016103*----------------------------
016103
016103     IF  WS-PHONETIC-GIV-NAME NOT = RCLNM-GIV-NM-PHNT-TXT
016103         SET  WS-MATCH-NO
016103           TO TRUE
016103         GO TO 2120-MATCH-CRITERIA-PHONETIC-X
016103     END-IF.
016103
016103 2120-MATCH-CRITERIA-PHONETIC-X.
016103     EXIT.
      /
      /
020478*-------------------
020478 2200-CHECK-PREV-IND.
020478*-------------------
020478
020478     PERFORM  2435-1000-BUILD-PARM-INFO
020478         THRU 2435-1000-BUILD-PARM-INFO-X.
020478
020478     MOVE RCLNM-CLI-ID                 TO L2435-CLI-ID.
020478
020478     PERFORM  2435-3000-PREV-CLI-NAME
020478         THRU 2435-3000-PREV-CLI-NAME-X.
020478
020478     IF  L2435-RETRN-OK
020478         SET WS-CLI-PREV-NM-YES        TO TRUE
020478     ELSE
020478         SET WS-CLI-PREV-NM-NO         TO TRUE
020478     END-IF.
020478
020478
020478     PERFORM  2210-PREV-ADDR-IND
020478         THRU 2210-PREV-ADDR-IND-X.
020478
020478
020478 2200-CHECK-PREV-IND-X.
020478     EXIT.
020478/
020478*---------------------
020478 2210-PREV-ADDR-IND.
020478*---------------------
020478
020478     PERFORM  2440-0000-INIT-PARM-INFO
020478         THRU 2440-0000-INIT-PARM-INFO-X.
020478
020478     MOVE RCLNM-CLI-ID                  TO L2440-CLI-ID.
020478     SET L2440-CLI-ADDR-TYP-PRIM-ADDR   TO TRUE.
020478     MOVE 1                          TO L2440-PREV-ADDR-VERSION.
020478
020478     PERFORM  2440-4000-PREVIOUS-ADDRESS
020478         THRU 2440-4000-PREVIOUS-ADDRESS-X.
020478
020478     IF  L2440-RETRN-OK
020478         SET WS-CLI-PREV-ADDR-YES       TO TRUE
020478     ELSE
020478         SET WS-CLI-PREV-ADDR-NO        TO TRUE
020478     END-IF.
020478
020478 2210-PREV-ADDR-IND-X.
020478     EXIT.
020478/

      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES               TO WCLNN-KEY.

018732*    EVALUATE TRUE

016103*        WHEN WGLOB-COUNTRY-JAPAN
018732*        WHEN MIR-DV-SRCH-GR-KANJI
016103*             SET  WCLNN-CLI-INDV-GR-KATAKANA
018732*             SET  WCLNN-CLI-INDV-GR-KANJI
018732*               TO TRUE

016103*        WHEN OTHER
018732*        WHEN MIR-DV-SRCH-GR-ALPHA
018732*             SET  WCLNN-CLI-INDV-GR-ALPHA
018732*               TO TRUE

018732*    END-EVALUATE.
018732     MOVE MIR-CLI-INDV-GR-CD       TO WCLNN-CLI-INDV-GR-CD.
020478*    SET  WCLNN-CLI-INDV-NM-TYP-CRNT  TO TRUE.
           MOVE MIR-CLI-INDV-SUR-NM      TO WCLNN-CLI-INDV-SUR-NM.
           MOVE MIR-CLI-INDV-GIV-NM      TO WCLNN-CLI-INDV-GIV-NM.
           MOVE MIR-CLI-ID               TO WCLNN-CLI-ID.
020478     MOVE WWKDT-LOW-DT             TO WCLNN-CLI-INDV-EFF-DT.

           MOVE WCLNN-KEY                TO WCLNN-ENDBR-KEY.
           MOVE HIGH-VALUES              TO WCLNN-ENDBR-CLI-ID.
020478     MOVE WWKDT-HIGH-DT            TO WCLNN-ENDBR-CLI-INDV-EFF-DT.

       7000-BUILD-KEYS-X.
           EXIT.

016103*-----------------
016103 7005-BUILD-KEYS.
016103*-----------------
016103
016103     PERFORM  2810-1000-BUILD-PARM-INFO
016103         THRU 2810-1000-BUILD-PARM-INFO-X.
016103
016103     SET L2810-SRCH-GR-KATAKANA    TO TRUE.
016103
016103     MOVE MIR-CLI-INDV-GIV-NM     TO L2810-INPUT-NAME.
016103
016103     PERFORM  2810-2000-PHONETIC-ENCODE
016103         THRU 2810-2000-PHONETIC-ENCODE-X
016103
016103     MOVE L2810-PHONETIC-NAME     TO WS-PHONETIC-GIV-NAME.
016103
016103     MOVE MIR-CLI-INDV-SUR-NM     TO L2810-INPUT-NAME.
016103
016103     PERFORM  2810-2000-PHONETIC-ENCODE
016103         THRU 2810-2000-PHONETIC-ENCODE-X.
016103
016103     MOVE L2810-PHONETIC-NAME      TO WS-PHONETIC-SUR-NAME.
016103
016103     MOVE LOW-VALUES               TO WCLNO-KEY.
016103
016103     SET  WCLNO-CLI-INDV-GR-KATAKANA  TO TRUE.
020478*    SET  WCLNO-CLI-INDV-NM-TYP-CRNT  TO TRUE.
016103     MOVE WS-PHONETIC-SUR-NAME  TO WCLNO-SUR-NM-PHNT-TXT.
016103     MOVE WS-PHONETIC-GIV-NAME  TO WCLNO-GIV-NM-PHNT-TXT.
016103     MOVE MIR-CLI-ID            TO WCLNO-CLI-ID.
020478     MOVE WWKDT-LOW-DT          TO WCLNO-CLI-INDV-EFF-DT.
016103     MOVE WCLNO-KEY             TO WCLNO-ENDBR-KEY.
016103     MOVE HIGH-VALUES           TO WCLNO-ENDBR-CLI-ID.
020478     MOVE WWKDT-HIGH-DT         TO WCLNO-ENDBR-CLI-INDV-EFF-DT.
016103
016103 7005-BUILD-KEYS-X.
016103     EXIT.

      /
      *-----------
       8000-EDITS.
      *-----------

           PERFORM  8010-EDIT-INDV-NM
               THRU 8010-EDIT-INDV-NM-X.

           PERFORM  8020-EDIT-BTH-DT
               THRU 8020-EDIT-BTH-DT-X.

           PERFORM  8030-EDIT-SEX-CD
               THRU 8030-EDIT-SEX-CD-X.
018732*    IF NOT WGLOB-COUNTRY-JAPAN
018732*        SET MIR-DV-SRCH-GR-ALPHA     TO TRUE
018732*    ELSE
018732*        IF  MIR-DV-SRCH-GR-ALPHA
018732*            SET MIR-DV-SRCH-GR-KANJI TO TRUE
018732*        END-IF
018732*    END-IF.

       8000-EDITS-X.
           EXIT.


      *-----------------
       8010-EDIT-INDV-NM.
      *-----------------

           IF  MIR-CLI-INDV-SUR-NM = SPACES
           OR  MIR-CLI-INDV-GIV-NM = SPACES
      *MSG: MUST ENTER LAST NAME AND FIRST NAME
               MOVE 'CS22350001'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8010-EDIT-INDV-NM-X.
           EXIT.


      *-----------------
       8020-EDIT-BTH-DT.
      *-----------------

           IF  MIR-CLI-BTH-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CLI-BTH-DT
           END-IF.

           IF  MIR-CLI-BTH-DT = SPACES
               MOVE SPACES            TO WS-INT-CLI-BTH-DT
               GO TO 8020-EDIT-BTH-DT-X
           END-IF.

           MOVE MIR-CLI-BTH-DT        TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
               MOVE SPACES            TO WS-INT-CLI-BTH-DT
      *MSG: INVALID DATE OF BIRTH ENTERED
               MOVE 'CS22350002'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-CLI-BTH-DT    TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO WS-INT-CLI-BTH-DT
           END-IF.

       8020-EDIT-BTH-DT-X.
           EXIT.


      *-----------------
       8030-EDIT-SEX-CD.
      *-----------------

           IF  MIR-CLI-SEX-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-CLI-SEX-CD
           END-IF.

           MOVE MIR-CLI-SEX-CD        TO WS-MIR-CLI-SEX-CD.

           IF  NOT WS-MIR-CLI-SEX-VALID
               MOVE 'XS00000067'      TO WGLOB-MSG-REF-INFO
               MOVE 'BLANK, M, F, OR C'
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8030-EDIT-SEX-CD-X.
           EXIT.


      /

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES
             TO MIR-CLI-ID-G.
           MOVE SPACES
             TO MIR-CLI-SEX-CD-G.
           MOVE SPACES
             TO MIR-CLI-LANG-CD-G.
           MOVE SPACES
             TO MIR-CLI-BTH-DT-G.
           MOVE SPACES
             TO MIR-CLI-CNFD-IND-G.
           MOVE SPACES
             TO MIR-UNMTCH-MAIL-IND-G.
           MOVE SPACES
             TO MIR-DV-SRCH-CLI-NM-G.
           MOVE SPACES
             TO MIR-CLI-ADDR-LN-1-TXT-G.
           MOVE SPACES
             TO MIR-CLI-ADDR-LN-2-TXT-G.
           MOVE SPACES
             TO MIR-CLI-CITY-NM-TXT-G.
           MOVE SPACES
             TO MIR-CLI-PSTL-CD-G.
           MOVE SPACES
             TO MIR-CLI-TAX-ID-G.
           MOVE SPACES
015904*      TO MIR-CLI-PREV-SUR-NM-G.
015904       TO MIR-CLI-INDV-SUR-NM-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RCLNM-CLI-ID
             TO MIR-CLI-ID-T (WS-SUB).

           MOVE RCLNM-CLI-ID
             TO WCLI-CLI-ID.

           PERFORM  CLI-1000-READ
               THRU CLI-1000-READ-X.

           IF  NOT WCLI-IO-OK
               GO TO 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           MOVE RCLI-CLI-SEX-CD
             TO MIR-CLI-SEX-CD-T (WS-SUB).

           MOVE RCLI-CLI-LANG-CD
             TO MIR-CLI-LANG-CD-T (WS-SUB).

           MOVE RCLI-CLI-BTH-DT
             TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
             TO MIR-CLI-BTH-DT-T (WS-SUB).

020478*    MOVE RCLI-CLI-ID           TO WCLIA-CLI-ID.

018732*    IF  WGLOB-COUNTRY-JAPAN
019154*        SET  WCLIA-CLI-ADDR-GR-KATAKANA TO TRUE
018732*        SET  WCLIA-CLI-ADDR-GR-KANJI    TO TRUE
018732*    ELSE
018732*        SET  WCLIA-CLI-ADDR-GR-ALPHA    TO TRUE
018732*    END-IF.

020478*    MOVE MIR-CLI-INDV-GR-CD    TO WCLIA-CLI-ADDR-GR-CD.
020478*    SET  WCLIA-CLI-ADDR-TYP-PRIM-ADDR TO TRUE.
020478*
020478*    MOVE '001'                 TO WCLIA-CLI-ADDR-SEQ-NUM.
020478*    PERFORM  CLIA-1000-READ
020478*        THRU CLIA-1000-READ-X.

020478     PERFORM  2440-0000-INIT-PARM-INFO
020478         THRU 2440-0000-INIT-PARM-INFO-X.

020478     MOVE RCLI-CLI-ID           TO L2440-CLI-ID.
020478     MOVE 'PR'                  TO L2440-CLI-ADDR-TYP-CD.
020478     MOVE WGLOB-PROCESS-DATE    TO L2440-CLI-ADDR-EFF-DT.
020478     MOVE MIR-CLI-INDV-GR-CD    TO L2440-CLI-ADDR-GR-CD.
020478     PERFORM  2440-1000-PRIMARY-ADDRESS
020478         THRU 2440-1000-PRIMARY-ADDRESS-X.

018732*    IF NOT WCLIA-IO-OK
018732*        MOVE WCLI-CLI-ID       TO WGLOB-MSG-PARM (1)
018732*        MOVE 'XS00000076'      TO WGLOB-MSG-REF-INFO
018732*        PERFORM  0260-1000-GENERATE-MESSAGE
018732*            THRU 0260-1000-GENERATE-MESSAGE-X
018732*        GO TO 9200-MOVE-RECORD-TO-SCREEN-X
018732*
018732*    END-IF.

           MOVE RCLI-CLI-CNFD-IND     TO MIR-CLI-CNFD-IND-T (WS-SUB).
           MOVE RCLI-UNMTCH-MAIL-IND  TO MIR-UNMTCH-MAIL-IND-T (WS-SUB).
023434*    MOVE RCLIA-CLI-ADDR-LN-1-TXT
020478*    MOVE RCLIA-CLI-ADDR-LN-1-TXT-TXT
020478     MOVE L2440-CLI-ADDR-LN-1-TXT-TXT
                                    TO MIR-CLI-ADDR-LN-1-TXT-T (WS-SUB).
023434*    MOVE RCLIA-CLI-ADDR-LN-2-TXT
020478*    MOVE RCLIA-CLI-ADDR-LN-2-TXT-TXT
020478     MOVE L2440-CLI-ADDR-LN-2-TXT-TXT
                                    TO MIR-CLI-ADDR-LN-2-TXT-T (WS-SUB).
020478*    MOVE RCLIA-CLI-CITY-NM-TXT TO MIR-CLI-CITY-NM-TXT-T (WS-SUB).
020478     MOVE L2440-CLI-CITY-NM-TXT TO MIR-CLI-CITY-NM-TXT-T (WS-SUB).
020478*    MOVE RCLIA-CLI-PSTL-CD     TO MIR-CLI-PSTL-CD-T (WS-SUB).
020478     MOVE L2440-CLI-PSTL-CD     TO MIR-CLI-PSTL-CD-T (WS-SUB).
           MOVE RCLI-CLI-TAX-ID       TO MIR-CLI-TAX-ID-T (WS-SUB).

           MOVE RCLI-CLI-SEX-CD       TO L0620-CLI-SEX-CD.
           MOVE RCLNM-ENTR-GIV-NM     TO L0620-CLI-GIV-NM.
           MOVE RCLNM-ENTR-SUR-NM     TO L0620-CLI-SUR-NM.
           MOVE SPACES                TO L0620-CLI-CO-NM.

           PERFORM  0620-2000-FORMAT-LAST-FIRST
               THRU 0620-2000-FORMAT-LAST-FIRST-X.

           MOVE L0620-SCREEN-NAME     TO MIR-DV-SRCH-CLI-NM-T (WS-SUB).

020478*    IF  RCLI-PREV-INFO-NO-NAAD-INFO
020478*        GO TO 9200-MOVE-RECORD-TO-SCREEN-X
020478*    END-IF.

020478     PERFORM  2200-CHECK-PREV-IND
020478         THRU 2200-CHECK-PREV-IND-X.

020478     IF  WS-CLI-PREV-NM-NO
020478     AND WS-CLI-PREV-ADDR-NO
020478         GO TO 9200-MOVE-RECORD-TO-SCREEN-X
020478     END-IF.

020478*    MOVE RCLI-CLI-ID           TO WCLNM-CLI-ID.

018732*    EVALUATE TRUE

018732*        WHEN WGLOB-COUNTRY-JAPAN
018732*             SET  WCLNM-CLI-INDV-GR-KATAKANA
018732*               TO TRUE

018732*        WHEN OTHER
018732*             SET  WCLNM-CLI-INDV-GR-ALPHA
018732*               TO TRUE

018732*    END-EVALUATE.
020478*    MOVE MIR-CLI-INDV-GR-CD    TO WCLNM-CLI-INDV-GR-CD.
020478*
020478*    SET  WCLNM-CLI-INDV-NM-TYP-PREV TO TRUE.
020478*    MOVE +1                    TO WCLNM-CLI-INDV-SEQ-NUM.
020478*    PERFORM  CLNM-1000-READ
020478*        THRU CLNM-1000-READ-X.
020478*
020478*    IF  NOT WCLNM-IO-OK
018732*        MOVE 'CS22350003'      TO WGLOB-MSG-REF-INFO
018732*        PERFORM  0260-1000-GENERATE-MESSAGE
018732*            THRU 0260-1000-GENERATE-MESSAGE-X
020478*        PERFORM  2435-1000-OBTAIN-CLI-INFO
020478*            THRU 2435-1000-OBTAIN-CLI-INFO-X
020478*        MOVE L2435-CLI-SUR-NM  TO MIR-CLI-INDV-SUR-NM-T (WS-SUB)
020478*    ELSE
020478*        MOVE RCLNM-CLI-INDV-SUR-NM
015904*                               TO MIR-CLI-PREV-SUR-NM-T (WS-SUB)
020478*                               TO MIR-CLI-INDV-SUR-NM-T (WS-SUB)
020478*    END-IF.

020478     PERFORM  2435-1000-BUILD-PARM-INFO
020478         THRU 2435-1000-BUILD-PARM-INFO-X.
020478
020478     MOVE RCLNM-CLI-ID           TO  L2435-CLI-ID.
020478     MOVE RCLNM-CLI-INDV-EFF-DT  TO L2435-EFF-DT.
020478     MOVE MIR-CLI-INDV-GR-CD     TO L2435-CLI-GR-CD.
020478
020478     PERFORM  2435-3000-PREV-CLI-NAME
020478         THRU 2435-3000-PREV-CLI-NAME-X.
020478     IF  L2435-RETRN-OK
020478         MOVE L2435-CLI-SUR-NM
020478                                TO MIR-CLI-INDV-SUR-NM-T (WS-SUB)
020478     ELSE
020478         PERFORM  2435-1000-OBTAIN-CLI-INFO
020478             THRU 2435-1000-OBTAIN-CLI-INFO-X
020478         MOVE L2435-CLI-SUR-NM  TO MIR-CLI-INDV-SUR-NM-T (WS-SUB)
020478     END-IF.


       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-CLIENT
             TO TRUE.
           MOVE MIR-CLI-ID
             TO WGLOB-REF-CLIENT-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
023118*--------------------------
023118 9990-INIT-WORKING-STORAGE.
023118*--------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023118
025970*    CONTINUE.
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2440-0000-INIT-PARM-INFO
025970         THRU 2440-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  2810-0000-INIT-PARM-INFO
025970         THRU 2810-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-SUB-DEFAULT TO TRUE.
025970     SET WS-MAX-LIST-LINES-DEFAULT TO TRUE.
023118
023118 9990-INIT-WORKING-STORAGE-X.
023118     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
016103 COPY CCPS2810.
018764*COPY CCCL2810.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL2810.
025970 COPY CCPS0620.
       COPY CCPL0620.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS1640.
       COPY XCPL1640.
021930*COPY CCPS2435.
018764*COPY CCCL2435.
020478 COPY CCPS2435.
018764 COPY CCPL2435.
020478 COPY CCPS2440.
020478 COPY CCPL2440.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCLI.
020478*COPY CCPNCLIA.
       COPY CCPBCLID.
       COPY CCPNCLNM.
       COPY CCPBCLNN.
016103 COPY CCPBCLNO.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2235                     **
      *****************************************************************
