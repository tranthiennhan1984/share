      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2812.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2812                                         **
      **  REMARKS:  UPDATE PROCESS DRIVER FOR THE SPECIFIC           **
      **            ROLLOVER DESTINATION INSTRUCTIONS                **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023112**  6.5       CASH FLOW DESTINATION INSTRUCTIONS               **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2812'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-CONSTANT-AREA.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '2810'.
025970     05  WS-MAX-LINES                 PIC S9(03) COMP-3.
025970         88  WS-MAX-LINES-DEFAULT     VALUE 10.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '2810'.
025970*    05  WS-MAX-LINES                 PIC S9(03) COMP-3
025970*                                     VALUE 10.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-UPDATE        VALUE '2812'.
           05  WS-SUB                       PIC S9(03) COMP-3.
           05  WS-SEND-RENEWAL-MSG-SW       PIC X(01).
               88  WS-SEND-RENEWAL-MSG      VALUE 'Y'.
           05  WS-DEP-TERM-SW               PIC X(01).
               88  WS-DEP-TERM-VALID        VALUE 'Y'.
               88  WS-DEP-TERM-NOT-VALID    VALUE 'N'.

           05  WS-DEST-CVG-NUM              PIC 9(02).
           05  WS-DEST-CVG-NUM-R            REDEFINES
               WS-DEST-CVG-NUM              PIC X(02).
           05  WS-CVG-NUM                   PIC 9(02).
           05  WS-CF-EFF-DT                 PIC X(10).
           05  WS-CF-SEQ-NUM                PIC S9(03) COMP-3.
           05  WS-POL-PAYO-NUM              PIC S9(05) COMP-3.
           05  WS-POL-PAYO-AMT              PIC S9(13)V9(02)
                                            COMP-3.
           05  WS-TOTAL-DEP-AMT             PIC S9(13)V9(02)
                                            COMP-3.
           05  WS-HIGHEST-ALLOC-NUM         PIC S9(03) COMP-3.
           05  WS-EDIT-AREA                 OCCURS 10.
               10  WS-EDIT-SW               PIC X(01).
                   88  WS-EDIT-THIS-LINE    VALUE 'Y'.
                   88  WS-NO-EDIT-THIS-LINE VALUE 'N'.
               10  WS-CDI-ALLOC-AMT         PIC S9(13)V9(02)
                                            COMP-3.
               10  WS-CDI-GUAR-INT-RT       PIC S9(03)V9(04)
                                            COMP-3.
               10  WS-DPOS-TRM.
                   15  WS-DPOS-TRM-MO-DUR   PIC 9(03).
                   15  WS-DPOS-TRM-DY-DUR   PIC 9(03).
           05  WS-HOLD-COVNO                PIC 9(02).
           05  WS-HOLD-COVNO-R              REDEFINES
               WS-HOLD-COVNO                PIC X(02).



       COPY XCWLCOMM REPLACING '$VAR1' BY '2810'.
           15  LCOMM-OLD-CDSI               OCCURS 10.
               20  LCOMM-CDI-ALLOC-AMT      PIC S9(13)V9(02)
                                            COMP-3.
               20  LCOMM-DPOS-TRM-MO-DUR    PIC X(03).
               20  LCOMM-DPOS-TRM-DY-DUR    PIC X(03).
               20  LCOMM-CDI-ALLOC-NUM      PIC S9(03)
                                            COMP-3.



      /
      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY CCWWCVGS.
       COPY CCWWINDX.
       COPY CCWWLOCK.
026057 COPY CCWWIHSD.
      /
       COPY XCWEBLCH.
      /
       COPY XCWWCVGM.
       COPY XCWWWKDT.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFRCDSI.
       COPY CCFWCDSI.
      /
       COPY CCFRCFLW.
       COPY CCFWCFLW.
      /
       COPY CCFRCVG.
       COPY CCFWCVG.
      /
       COPY CCFRPH.
       COPY CCFWPH.
      /
       COPY CCFRPOL.
       COPY CCFWPOL.
      /
       COPY CCFRPOLP.
       COPY CCFWPOLP.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
       COPY CCWLPGA.
020478 COPY CCWL2626.
       COPY CCWL5400.
       COPY CCWL6530.
      /
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
       COPY XCWL8090.
       COPY XCWL8960.
       COPY XCWLDTLK.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2812.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

025970*    MOVE MIR-BUS-FCN-ID     TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM 2000-PROCESS-UPDATE
                       THRU 2000-PROCESS-UPDATE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2812'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *--------------------
       2000-PROCESS-UPDATE.
      *--------------------

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-PROCESS-UPDATE-X
           END-IF.

           INITIALIZE LCOMM-WORK-AREA.

           PERFORM  COMM-1000-RETRIEVE-TWRK
               THRU COMM-1000-RETRIEVE-TWRK-X.

           PERFORM  COMM-3000-DELETE-TWRK
               THRU COMM-3000-DELETE-TWRK-X.

           PERFORM  2300-READ-POLP
               THRU 2300-READ-POLP-X.

           IF  WGLOB-RETURN-ERROR
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  3000-EDIT-SCREEN-DATA
               THRU 3000-EDIT-SCREEN-DATA-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LINES.

           IF  WGLOB-RETURN-ERROR
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  3300-CHECK-DEPOSIT-CHANGE
               THRU 3300-CHECK-DEPOSIT-CHANGE-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LINES.

           PERFORM  3600-DEP-AMT-TOTAL-EDIT
               THRU 3600-DEP-AMT-TOTAL-EDIT-X.

           IF  WGLOB-RETURN-ERROR
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  3700-DETERMINE-MAX-ALLOC
               THRU 3700-DETERMINE-MAX-ALLOC-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LINES.

           PERFORM  3800-UPDATE-CDSI
               THRU 3800-UPDATE-CDSI-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LINES.

           PERFORM  3900-UPDATE-POLP
               THRU 3900-UPDATE-POLP-X.

           IF  WGLOB-RETURN-ERROR
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X
           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X

           IF  WS-SEND-RENEWAL-MSG
      * MSG: VALUES CHANGED - A NEW RENEWAL LETTER MAY BE APPROPRIATE
               MOVE 'CS28120001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  COMM-2000-WRITE-TWRK
               THRU COMM-2000-WRITE-TWRK-X.

       2000-PROCESS-UPDATE-X.
           EXIT.
      /
      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------

           MOVE MIR-POL-ID-BASE        TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX         TO WPOL-POL-ID-SFX.

           PERFORM  POL-2000-UPDATE-TWRK-TS
               THRU POL-2000-UPDATE-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: POLICY NOT ON FILE
               MOVE 'CS28120002'       TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
      *  NOT COMPLETE
               MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
               MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
               MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF

           IF WS-HOLD-COVNO             > RPOL-POL-CVG-REC-CTR-N
      * MSG:  COVNO (@1) NOT FOUND
               MOVE 'CS28120036'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-CVG-NUM        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           IF  NOT WCVGS-CVG-CF-TYP-GIA (WS-CVG-NUM)
           AND NOT WCVGS-CVG-CF-TYP-EIA (WS-CVG-NUM)
      *MSG: UPDATE IS ONLY ALLOWED FOR GIA AND EIA COVERAGE
               MOVE 'CS28120003'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-CF-EFF-DT           TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-3000-CHK-IHSD-INSTR
026057         THRU IHSD-3000-CHK-IHSD-INSTR-X.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057         SET WGLOB-RETURN-ERROR  TO TRUE
026057         GO TO 2100-VALIDATE-KEYS-X
026057     END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-POL-XFER-UPDATE   TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
           OR  L5400-XFER-ACCS-RESTRICTED
               SET WGLOB-RETURN-ERROR  TO TRUE
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           MOVE MIR-POL-ID             TO WCFLW-POL-ID.
           MOVE WS-CVG-NUM             TO WCFLW-CVG-NUM-N.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG-NUM)
                                       TO WCFLW-CF-TYP-CD.
           MOVE WS-CF-EFF-DT           TO WCFLW-CF-EFF-DT.
           MOVE WS-CF-SEQ-NUM          TO WCFLW-CF-SEQ-NUM-N.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

           IF  WCFLW-IO-NOT-FOUND
      *MSG: NO CASH FLOW FOUND
               MOVE 'CS28120004'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

           PERFORM  2200-READ-NEXT-CFLW
               THRU 2200-READ-NEXT-CFLW-X
               UNTIL NOT WCFLW-IO-OK
               OR    RCFLW-NXT-CF-DT  = WWKDT-ZERO-DT.

       2100-VALIDATE-KEYS-X.
           EXIT.

      /
      *---------------------
       2200-READ-NEXT-CFLW.
      *---------------------

           MOVE RCFLW-NXT-CF-DT        TO WCFLW-CF-EFF-DT.
           MOVE RCFLW-NXT-CF-SEQ-NUM-N TO WCFLW-CF-SEQ-NUM-N.
           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

       2200-READ-NEXT-CFLW-X.
           EXIT.
      /
      *---------------
       2300-READ-POLP.
      *---------------

           MOVE RPOL-POL-ID            TO WPOLP-POL-ID.
           MOVE RCFLW-CF-ROLOVR-PAYO-NUM
                                       TO WPOLP-POL-PAYO-NUM.

           PERFORM  POLP-1000-READ
               THRU POLP-1000-READ-X.
               
           COMPUTE WS-POL-PAYO-NUM     =  100000 - WPOLP-POL-PAYO-NUM.     

           IF  NOT WPOLP-IO-OK
      *MSG : PAYOUT RECORD DOES NOT EXIST FOR POLICY(@1) PAYOUT(@2)
               MOVE WPOLP-POL-ID       TO WGLOB-MSG-PARM (1)
               MOVE WS-POL-PAYO-NUM    TO WGLOB-MSG-PARM (2)
               MOVE 'CS28120005'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2300-READ-POLP-X
           END-IF.

           IF  NOT RPOLP-POL-PAYO-TYP-ROLOVR-PAYO
      *MSG : PAYOUT RECORD TYPE FOR POL(@1) PAYOUT(@2) IS NOT ROLLOVER
               MOVE WPOLP-POL-ID       TO WGLOB-MSG-PARM (1)
               MOVE WS-POL-PAYO-NUM    TO WGLOB-MSG-PARM (2)
               MOVE 'CS28120006'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2300-READ-POLP-X
           END-IF.

           IF  NOT RPOLP-POL-PAYO-STAT-ERRORS
           AND NOT RPOLP-POL-PAYO-STAT-ROLOVR
      *MSG : RE POLICY (@1), PAYOUT (@2): ONLY ROLLOVER DESTINATION 
      *      INSTRUCTIONS WITH STATUS ACTIVE ROLLOVER PAYOUT CAN BE
      *      UPDATED
               MOVE WPOLP-POL-ID       TO WGLOB-MSG-PARM (1)
               MOVE WS-POL-PAYO-NUM    TO WGLOB-MSG-PARM (2)
               MOVE 'CS28120007'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2300-READ-POLP-X
           END-IF.

       2300-READ-POLP-X.
           EXIT.

      /
      *----------------------
       3000-EDIT-SCREEN-DATA.
      *----------------------

           SET WS-EDIT-THIS-LINE (WS-SUB)
                                       TO TRUE.
           SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE
           SET L0280-SPACES-PERMITTED
                                       TO TRUE
           MOVE 2                      TO L0280-PRECISION
           MOVE LENGTH OF MIR-CDI-ALLOC-AMT-T (WS-SUB)
                                       TO L0280-INPUT-SIZE
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3
           MOVE MIR-CDI-ALLOC-AMT-T (WS-SUB)
                                       TO L0280-INPUT-DATA
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X
           IF  L0280-RETRN-OK
               MOVE L0280-OUTPUT-V02   TO WS-CDI-ALLOC-AMT
                                          (WS-SUB)
           ELSE
               MOVE ZERO               TO WS-CDI-ALLOC-AMT
                                          (WS-SUB)
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE
           SET L0280-SPACES-PERMITTED
                                       TO TRUE
           MOVE 4                      TO L0280-PRECISION
           MOVE LENGTH OF MIR-CDI-GUAR-INT-RT-T (WS-SUB)
                                       TO L0280-INPUT-SIZE
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 5
           MOVE MIR-CDI-GUAR-INT-RT-T (WS-SUB)
                                       TO L0280-INPUT-DATA
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X
           IF  L0280-RETRN-OK
               MOVE L0280-OUTPUT-V04   TO WS-CDI-GUAR-INT-RT
                                          (WS-SUB)
           ELSE
               MOVE ZERO               TO WS-CDI-GUAR-INT-RT
                                          (WS-SUB)
           END-IF.

           IF  MIR-DEST-CVG-NUM-T (WS-SUB) = SPACES
           AND MIR-DPOS-TRM-MO-DUR-T (WS-SUB) = ZERO
           AND MIR-DPOS-TRM-DY-DUR-T (WS-SUB) = ZERO
           AND WS-CDI-ALLOC-AMT (WS-SUB) = ZERO
           AND WS-CDI-GUAR-INT-RT (WS-SUB) = ZERO
               SET WS-NO-EDIT-THIS-LINE (WS-SUB)
                                       TO TRUE
               GO TO 3000-EDIT-SCREEN-DATA-X
           END-IF.

           IF  MIR-DEST-CVG-NUM-T (WS-SUB) = EBLCH-BLANK-FIELD-GROUP
               SET WS-NO-EDIT-THIS-LINE (WS-SUB)
                                       TO TRUE
               GO TO 3000-EDIT-SCREEN-DATA-X
           END-IF.

           PERFORM  3100-EDIT-DEST-CVG
               THRU 3100-EDIT-DEST-CVG-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 3000-EDIT-SCREEN-DATA-X
           END-IF.

           PERFORM  3110-EDIT-DEP-MTH
               THRU 3110-EDIT-DEP-MTH-X.

           PERFORM  3120-EDIT-DEP-DAY
               THRU 3120-EDIT-DEP-DAY-X.

           PERFORM  3130-EDIT-DEP-TERM
               THRU 3130-EDIT-DEP-TERM-X.

           PERFORM  3140-EDIT-AMOUNT
               THRU 3140-EDIT-AMOUNT-X.

           PERFORM  3150-EDIT-INT-RATE
               THRU 3150-EDIT-INT-RATE-X.

       3000-EDIT-SCREEN-DATA-X.
           EXIT.
      /
      *-------------------
       3100-EDIT-DEST-CVG.
      *-------------------

           IF MIR-DEST-CVG-NUM-T (WS-SUB) =  ZEROES
           OR MIR-DEST-CVG-NUM-T (WS-SUB) =  SPACES
      * MSG: DESTINATION COVERAGE NUMBER HAS TO CONTAIN A VALID VALUE
               MOVE 'CS28120008'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 3100-EDIT-DEST-CVG-X
           END-IF.

           MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                       TO WS-DEST-CVG-NUM-R.
           IF WS-DEST-CVG-NUM-R NOT NUMERIC
           OR WS-DEST-CVG-NUM  < 1
           OR WS-DEST-CVG-NUM  > WCVGM-MAX-WCVGS-NUM
      * MSG: DESTINATION COVERAGE NUMBER MUST BE 2 DIGITS FROM 01-@1
               MOVE 'CS28120009'       TO WGLOB-MSG-REF-INFO
               MOVE WCVGM-MAX-WCVGS-NUM
                                       TO  WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 3100-EDIT-DEST-CVG-X
           END-IF.

           IF WS-DEST-CVG-NUM  > RPOL-POL-CVG-REC-CTR-N
      * MSG: DESTINATION COVERAGE NUMBER (@1) DOES NOT EXIST
               MOVE 'CS28120010'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                       TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 3100-EDIT-DEST-CVG-X
           END-IF.

           IF  NOT WCVGS-CVG-STAT-IN-FORCE (WS-DEST-CVG-NUM)
           AND NOT WCVGS-CVG-STAT-PENDING (WS-DEST-CVG-NUM)
      * MSG: DESTINATION COVERAGE (@1) MUST BE INFORCE OR PENDING
               MOVE 'CS28120011'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                       TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 3100-EDIT-DEST-CVG-X
           END-IF.

           IF  NOT WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-DEST-CVG-NUM)
           AND NOT WCVGS-CVG-INS-TYP-FPA (WS-DEST-CVG-NUM)
      * MSG:  DESTINATION COVERAGE (@1) MUST BE TYPE
      *       ANNUITY
               MOVE 'CS28120012'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                       TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 3100-EDIT-DEST-CVG-X
           END-IF.
      *
      *  READ PLAN HEADER FOR THIS COVERAGE FOR USE IN FOLLOWING EDITS
      *

           MOVE WS-DEST-CVG-NUM        TO I.
           PERFORM  PLIN-1000-PLAN-HEADER-IN
               THRU PLIN-1000-PLAN-HEADER-IN-X.
           IF  NOT WPH-IO-OK
      * MSG:  PLAN NOT FOUND
               MOVE 'CS28120013'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 3100-EDIT-DEST-CVG-X
           END-IF.

       3100-EDIT-DEST-CVG-X.
           EXIT.
      /
      *------------------
       3110-EDIT-DEP-MTH.
      *------------------

           SET  WS-DEP-TERM-VALID      TO TRUE.

           IF  MIR-DPOS-TRM-MO-DUR-T (WS-SUB) =  EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROES             TO MIR-DPOS-TRM-MO-DUR-T
                                          (WS-SUB)
               GO TO 3110-EDIT-DEP-MTH-X
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE.
           MOVE ZERO                   TO L0280-PRECISION.
           MOVE LENGTH OF MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
                                       TO L0280-LENGTH.
           MOVE MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
                                       TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT       TO L0290-INPUT-V00
               MOVE ZERO               TO L0290-PRECISION
               MOVE LENGTH OF MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                  THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA  TO MIR-DPOS-TRM-MO-DUR-T
                                          (WS-SUB)
           ELSE
      * MSG: DEPOSIT TERM MUST BE VALID NUMERIC
               MOVE 'CS28120014'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               SET WS-DEP-TERM-NOT-VALID
                                       TO TRUE

           END-IF.

       3110-EDIT-DEP-MTH-X.
           EXIT.
      /
      *-------------------
       3120-EDIT-DEP-DAY.
      *-------------------

           IF  MIR-DPOS-TRM-DY-DUR-T (WS-SUB) =  EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS              TO MIR-DPOS-TRM-DY-DUR-T
                                          (WS-SUB)
               GO TO 3120-EDIT-DEP-DAY-X
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE.
           MOVE ZERO                   TO L0280-PRECISION.
           MOVE LENGTH OF MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
                                       TO L0280-LENGTH.
           MOVE MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
                                       TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT       TO L0290-INPUT-V00
               MOVE ZERO               TO L0290-PRECISION
               MOVE LENGTH OF MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA  TO MIR-DPOS-TRM-DY-DUR-T
                                          (WS-SUB)
           ELSE
      * MSG: DEPOSIT TERM MUST BE VALID NUMERIC
               MOVE 'CS28120015'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-DEP-TERM-NOT-VALID
                                       TO TRUE
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

       3120-EDIT-DEP-DAY-X.
           EXIT.
      /
      *---------------------
       3130-EDIT-DEP-TERM.
      *---------------------

           IF  WS-DEP-TERM-NOT-VALID
               GO TO 3130-EDIT-DEP-TERM-X
           END-IF.

           MOVE MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
                                       TO WS-DPOS-TRM-DY-DUR
                                          (WS-SUB).
           MOVE MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
                                       TO WS-DPOS-TRM-MO-DUR
                                          (WS-SUB).

           IF  WS-DPOS-TRM (WS-SUB) = ZERO
      * MSG:  DEPOSIT TERM HAS BEEN DEFAULTED FROM COVERAGE (@1)
               MOVE 'CS28120016'       TO WGLOB-MSG-REF-INFO
               MOVE WS-DEST-CVG-NUM    TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WCVGS-DPOS-TRM-MO-DUR (WS-DEST-CVG-NUM)
                                       TO L0290-INPUT-V00
               MOVE ZERO               TO L0290-PRECISION
               MOVE LENGTH OF MIR-DPOS-TRM-MO-DUR-T (WS-DEST-CVG-NUM)
                                       TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA  TO MIR-DPOS-TRM-MO-DUR-T
                                          (WS-SUB)
               MOVE WCVGS-DPOS-TRM-DY-DUR (WS-DEST-CVG-NUM)
                                       TO L0290-INPUT-V00
               MOVE ZERO               TO L0290-PRECISION
               MOVE LENGTH OF MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA  TO MIR-DPOS-TRM-DY-DUR-T
                                          (WS-SUB)
               MOVE MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
                                       TO WS-DPOS-TRM-DY-DUR
                                          (WS-SUB)
               MOVE MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
                                       TO WS-DPOS-TRM-MO-DUR
                                          (WS-SUB)
           END-IF.

           IF  WS-DPOS-TRM (WS-SUB) > RPH-MAX-ROLOVR-DUR-INFO
      * MSG: DEP TERM FOR DEST-COV (@1) OUTSIDE PLAN RANGE
               MOVE 'CS28120017'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                       TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
                   GO TO 3130-EDIT-DEP-TERM-X
               END-IF
           END-IF.

           IF  WS-DPOS-TRM (WS-SUB) < RPH-MIN-ROLOVR-DUR-INFO
      * MSG: DEP TERM FOR DEST-COV (@1) OUTSIDE PLAN RANGE
               MOVE 'CS28120017'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                       TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
                   GO TO 3130-EDIT-DEP-TERM-X
               END-IF
           END-IF.

           IF  WS-DPOS-TRM-MO-DUR (WS-SUB) > ZERO
           AND WS-DPOS-TRM-DY-DUR (WS-SUB) > 30
               MOVE 'CS28120019'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           IF  WGLOB-GOOD-RETURN
      * SET INDICATOR FOR RENEWAL LETTER MSG
               SET WS-SEND-RENEWAL-MSG TO TRUE
           END-IF.

       3130-EDIT-DEP-TERM-X.
           EXIT.
      /
      *------------------
       3140-EDIT-AMOUNT.
      *------------------

           IF  MIR-CDI-ALLOC-AMT-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROES             TO MIR-CDI-ALLOC-AMT-T (WS-SUB)
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE.
           MOVE 2                      TO L0280-PRECISION.
           MOVE LENGTH OF MIR-CDI-ALLOC-AMT-T(WS-SUB)
                                       TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           MOVE MIR-CDI-ALLOC-AMT-T (WS-SUB)
                                       TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                       TO L0290-INPUT-V02
               MOVE 2                  TO L0290-PRECISION
               MOVE LENGTH OF MIR-CDI-ALLOC-AMT-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA  TO MIR-CDI-ALLOC-AMT-T
                                          (WS-SUB)
           ELSE
      * MSG: ALLOCATION AMOUNT MUST BE A VALID NUMERIC
               MOVE 'CS28120020'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 3140-EDIT-AMOUNT-X
           END-IF.

           MOVE L0280-OUTPUT-DOLLAR    TO WS-CDI-ALLOC-AMT
                                          (WS-SUB).

           IF  WS-CDI-ALLOC-AMT (WS-SUB) NOT > ZERO
      * MSG:  ALLOCATION AMOUNT MUST BE GREATER THAN ZERO
               MOVE 'CS28120021'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 3140-EDIT-AMOUNT-X
           END-IF.

           IF  WS-CDI-ALLOC-AMT (WS-SUB) < RPH-DIR-DPOS-MIN-AMT
      *MSG: PROJECTED ROLL AMT FOR DEST CVG (@1) IS LESS THAN
      *     PLAN MIN
               MOVE 'CS28120022'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                       TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
                   GO TO 3140-EDIT-AMOUNT-X
               END-IF
           END-IF.

           IF  WGLOB-GOOD-RETURN
               SET WS-SEND-RENEWAL-MSG TO TRUE
           END-IF.

           ADD WS-CDI-ALLOC-AMT (WS-SUB)
                                       TO WS-TOTAL-DEP-AMT.

       3140-EDIT-AMOUNT-X.
           EXIT.

      *--------------------
       3150-EDIT-INT-RATE.
      *--------------------

           IF  MIR-CDI-GUAR-INT-RT-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROS              TO MIR-CDI-GUAR-INT-RT-T
                                          (WS-SUB)
               GO TO 3150-EDIT-INT-RATE-X
           END-IF.

           SET  L0280-SIGN-NOT-PERMITTED
                                       TO TRUE.
           MOVE 4                      TO L0280-PRECISION.
           COMPUTE L0280-LENGTH = LENGTH OF MIR-CDI-GUAR-INT-RT-T
                                  (WS-SUB) - 5
           MOVE MIR-CDI-GUAR-INT-RT-T (WS-SUB)
                                       TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF  L0280-OK
               MOVE L0280-OUTPUT-V04   TO L0290-INPUT-V04
               MOVE 4                  TO L0290-PRECISION
               MOVE LENGTH OF MIR-CDI-GUAR-INT-RT-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA  TO MIR-CDI-GUAR-INT-RT-T
                                          (WS-SUB)
           ELSE
      * MSG:  GUARANTEED INT RATE MUST BE VALID NUMERIC
               MOVE 'CS28120023'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 3150-EDIT-INT-RATE-X
           END-IF.

           MOVE L0280-OUTPUT-V04       TO WS-CDI-GUAR-INT-RT
                                          (WS-SUB).

           IF  WS-CDI-GUAR-INT-RT (WS-SUB)   > ZERO
           AND (WCVGS-CVG-CF-TYP-DIA (WS-DEST-CVG-NUM)
           OR   WCVGS-CVG-CF-TYP-EQUITY (WS-DEST-CVG-NUM)
           OR   WCVGS-CVG-CF-TYP-EIA (WS-DEST-CVG-NUM)
           OR   WCVGS-CVG-CF-TYP-OMNM (WS-DEST-CVG-NUM))
      * MSG: GUARANTEED INT RATE MUST BE ZERO FOR CF TYPE NOT GIA OR EIA
               MOVE 'CS28120024'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               MOVE ZEROES             TO WS-CDI-GUAR-INT-RT
                                          (WS-SUB)
               GO TO 3150-EDIT-INT-RATE-X
           END-IF.

           IF NOT RPH-PLAN-ROLOVR-GUAR-INT-RT
           AND WS-CDI-GUAR-INT-RT (WS-SUB) > ZERO

               MOVE ZERO               TO L0290-INPUT-V04
               MOVE 4                  TO L0290-PRECISION
               MOVE LENGTH OF MIR-CDI-GUAR-INT-RT-T (WS-SUB)
                                       TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA  TO MIR-CDI-GUAR-INT-RT-T
                                          (WS-SUB)

               MOVE ZEROES             TO WS-CDI-GUAR-INT-RT (WS-SUB)
      * MSG:  GUARANTEED INT RATE MUST BE ZERO. PLAN DOES NOT SUPPORT
      *       GUARANTEED INT RATES
               MOVE 'CS28120025'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 3150-EDIT-INT-RATE-X
           END-IF.

           IF WGLOB-GOOD-RETURN
               SET WS-SEND-RENEWAL-MSG    TO TRUE
           END-IF.

       3150-EDIT-INT-RATE-X.
           EXIT.

      /
      *--------------------------
       3300-CHECK-DEPOSIT-CHANGE.
      *--------------------------

           IF  WS-NO-EDIT-THIS-LINE (WS-SUB)
               GO TO 3300-CHECK-DEPOSIT-CHANGE-X
           END-IF.

           IF  WS-CDI-ALLOC-AMT (WS-SUB)  NOT = LCOMM-CDI-ALLOC-AMT
                                               (WS-SUB)
           OR  WS-DPOS-TRM-MO-DUR (WS-SUB)  NOT =
                                                LCOMM-DPOS-TRM-MO-DUR
                                                (WS-SUB)
           OR  WS-DPOS-TRM-DY-DUR (WS-SUB)  NOT =
                                                LCOMM-DPOS-TRM-DY-DUR
                                                (WS-SUB)

      * MSG:  DEPOSIT AMT OR TERM CHG FOR (@1) - GTD RATE MAY
      * NEED CHANGE (INFORMATIONAL ONLY)
               MOVE 'CS28120026'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3300-CHECK-DEPOSIT-CHANGE-X.
           EXIT.
      /

      *-------------------------
       3600-DEP-AMT-TOTAL-EDIT.
      *-------------------------

      *  CALCULATE ROLL AMOUNT (POL-PAYO-AMT)
      *
           PERFORM  3620-CALC-ROLL-AMOUNT
               THRU 3620-CALC-ROLL-AMOUNT-X.

           MOVE WS-POL-PAYO-AMT        TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-PAYO-AMT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-PAYO-AMT.

           IF WS-TOTAL-DEP-AMT NOT = WS-POL-PAYO-AMT
      * MSG: SUM OF ALLOCATION AMOUNTS MUST EQUAL TOTAL ROLLOVER AMT
               MOVE 'CS28120027'       TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

       3600-DEP-AMT-TOTAL-EDIT-X.
           EXIT.

      *----------------------
       3620-CALC-ROLL-AMOUNT.
      *----------------------

           MOVE RPOLP-POL-PAYO-AMT     TO WS-POL-PAYO-AMT.

           PERFORM  6530-1000-BUILD-PARM-INFO
               THRU 6530-1000-BUILD-PARM-INFO-X.

           MOVE RPOLP-POL-PAYO-EFF-DT  TO L6530-EFF-DT.
           MOVE RCFLW-CF-EFF-DT        TO L6530-CF-DT.
           MOVE RCFLW-CF-SEQ-NUM-N     TO L6530-CF-SEQ-NUM.
           MOVE WS-CVG-NUM             TO L6530-CVG.
           SET L6530-CALC-MKTVAL-ADJ-NOT-REQD
                                       TO TRUE.

           PERFORM  6530-3000-CALC-ACUM-VALU-CF
               THRU 6530-3000-CALC-ACUM-VALU-CF-X.

           IF  L6530-RETRN-OK
               IF  WCVGS-CVG-INT-PAYO-CREDIT-ACCT (WS-CVG-NUM)
                   MOVE L6530-CF-ACUM-VALU-AMT
                                       TO WS-POL-PAYO-AMT
               ELSE
                   MOVE RCFLW-CF-FND-BAL-AMT
                                       TO WS-POL-PAYO-AMT
               END-IF
               IF  RCFLW-CF-TYP-EIA
               OR  RCFLW-CF-TYP-GIA
                   IF  L6530-CF-ACUM-MCV-AMT
                                       >  WS-POL-PAYO-AMT
                     MOVE L6530-CF-ACUM-MCV-AMT
                                       TO WS-POL-PAYO-AMT
                   END-IF
               END-IF
           END-IF.


       3620-CALC-ROLL-AMOUNT-X.
           EXIT.

      *--------------------------
       3700-DETERMINE-MAX-ALLOC.
      *--------------------------

           IF  LCOMM-CDI-ALLOC-NUM (WS-SUB) > WS-HIGHEST-ALLOC-NUM
               MOVE LCOMM-CDI-ALLOC-NUM (WS-SUB)
                                       TO WS-HIGHEST-ALLOC-NUM
           END-IF.

       3700-DETERMINE-MAX-ALLOC-X.
           EXIT.

      *------------------
       3800-UPDATE-CDSI.
      *------------------

           IF  MIR-DEST-CVG-NUM-T (WS-SUB) = EBLCH-BLANK-FIELD-GROUP
               MOVE RPOL-POL-ID        TO WCDSI-POL-ID
               SET  WCDSI-CDI-TYP-ROLOVR-PAYO
                                       TO TRUE
               MOVE RPOLP-POL-PAYO-NUM TO WCDSI-POL-PAYO-NUM

               MOVE RPOLP-POL-PAYO-EFF-DT
                                       TO L1660-INTERNAL-DATE
               PERFORM  1660-2000-CONVERT-INT-TO-INV
                   THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE
                                       TO WCDSI-CDI-EFF-IDT-NUM-N
               MOVE 001                TO WCDSI-CDI-SEQ-NUM
               MOVE LCOMM-CDI-ALLOC-NUM (WS-SUB)
                                       TO WCDSI-CDI-ALLOC-NUM
               PERFORM  CDSI-1000-READ-FOR-UPDATE
                   THRU CDSI-1000-READ-FOR-UPDATE-X
               IF  WCDSI-IO-OK
                   PERFORM  CDSI-1000-DELETE
                       THRU CDSI-1000-DELETE-X
                   MOVE SPACES        TO MIR-DEST-CVG-NUM-T (WS-SUB)
                   MOVE SPACES        TO MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
                   MOVE SPACES        TO MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
                   MOVE SPACES        TO MIR-CDI-ALLOC-AMT-T (WS-SUB)
                   MOVE SPACES        TO MIR-CDI-GUAR-INT-RT-T (WS-SUB)
               END-IF
               GO TO 3800-UPDATE-CDSI-X
           END-IF.

           IF  NOT WS-EDIT-THIS-LINE (WS-SUB)
               GO TO 3800-UPDATE-CDSI-X
           END-IF.

           IF  LCOMM-CDI-ALLOC-NUM (WS-SUB) NOT > ZERO
               ADD 1 TO WS-HIGHEST-ALLOC-NUM
               MOVE WS-HIGHEST-ALLOC-NUM
                                       TO WCDSI-CDI-ALLOC-NUM
           ELSE
               MOVE LCOMM-CDI-ALLOC-NUM (WS-SUB)
                                       TO WCDSI-CDI-ALLOC-NUM
           END-IF.

           MOVE RPOL-POL-ID        TO WCDSI-POL-ID
           SET  WCDSI-CDI-TYP-ROLOVR-PAYO
                                       TO TRUE
           MOVE RPOLP-POL-PAYO-NUM TO WCDSI-POL-PAYO-NUM

           MOVE RPOLP-POL-PAYO-EFF-DT
                                       TO L1660-INTERNAL-DATE
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X
           MOVE L1660-INVERTED-DATE
                                       TO WCDSI-CDI-EFF-IDT-NUM-N
           MOVE 001                    TO WCDSI-CDI-SEQ-NUM

           PERFORM  CDSI-1000-READ-FOR-UPDATE
               THRU CDSI-1000-READ-FOR-UPDATE-X.

           IF  WCDSI-IO-OK
               PERFORM  3810-SETUP-CDSI-RECORD
                   THRU 3810-SETUP-CDSI-RECORD-X
               PERFORM  CDSI-2000-REWRITE
                   THRU CDSI-2000-REWRITE-X
           ELSE
               PERFORM  CDSI-1000-CREATE
                   THRU CDSI-1000-CREATE-X
               PERFORM  3810-SETUP-CDSI-RECORD
                   THRU 3810-SETUP-CDSI-RECORD-X
               PERFORM  CDSI-1000-WRITE
                   THRU CDSI-1000-WRITE-X
           END-IF.

       3800-UPDATE-CDSI-X.
           EXIT.

      *------------------------
       3810-SETUP-CDSI-RECORD.
      *------------------------

            MOVE MIR-DEST-CVG-NUM-T (WS-SUB)
                                       TO RCDSI-DEST-CVG-NUM.
            MOVE RPOLP-POL-PAYO-EFF-DT
                                       TO RCDSI-CDI-EFF-DT.
            MOVE WS-CDI-GUAR-INT-RT (WS-SUB)
                                       TO RCDSI-CDI-GUAR-INT-RT.
            MOVE 'A'                   TO RCDSI-CDI-ALLOC-CD.
            MOVE WS-CDI-ALLOC-AMT (WS-SUB)
                                       TO RCDSI-CDI-ALLOC-AMT.
            MOVE WS-DPOS-TRM-MO-DUR (WS-SUB)
                                       TO RCDSI-DPOS-TRM-MO-DUR.
            MOVE WS-DPOS-TRM-DY-DUR (WS-SUB)
                                       TO RCDSI-DPOS-TRM-DY-DUR.
            MOVE SPACES                TO RCDSI-DEST-POL-ID.
            MOVE SPACES                TO RCDSI-DEST-FND-ID.

       3810-SETUP-CDSI-RECORD-X.
           EXIT.

      *------------------
       3900-UPDATE-POLP.
      *------------------

           PERFORM  POLP-1000-READ-FOR-UPDATE
               THRU POLP-1000-READ-FOR-UPDATE-X.

           IF  NOT WPOLP-IO-OK
      * MSG:   POLP RECORD NOT FOUND TO REWRITE
               MOVE 'CS28120028'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 3900-UPDATE-POLP-X
           END-IF.

           IF  RPOLP-POL-PAYO-STAT-ERRORS
               SET RPOLP-POL-PAYO-STAT-ROLOVR
                                       TO TRUE
           END-IF.
           MOVE WS-POL-PAYO-AMT        TO RPOLP-POL-PAYO-AMT.
           MOVE RPOLP-POL-PAYO-STAT-CD TO MIR-POL-PAYO-STAT-CD.

           PERFORM  POLP-2000-REWRITE
               THRU POLP-2000-REWRITE-X.

       3900-UPDATE-POLP-X.
           EXIT.

      *----------------
       7000-BUILD-KEYS.
      *----------------

           IF  MIR-POL-ID = SPACE
      *MSG: THE POLICY ID MUST BE ENTERED
               MOVE 'CS28120029'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

           IF  MIR-CVG-NUM = SPACE
      *MSG: THE COVERAGE NUMBER MUST BE ENTERED
               MOVE 'CS28120030'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           ELSE
               SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE
               SET L0280-SPACES-PERMITTED
                                       TO TRUE
               MOVE ZERO               TO L0280-PRECISION
               MOVE LENGTH OF MIR-CVG-NUM
                                       TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
               MOVE MIR-CVG-NUM        TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-RETRN-OK
               AND L0280-OUTPUT-V00 > ZERO
                   MOVE L0280-OUTPUT-V00
                                       TO WS-CVG-NUM
               ELSE
      *MSG: COVERAGE NUMBER IS INVALID
                   MOVE 'CS28120031'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF
           END-IF.

           MOVE MIR-CVG-NUM            TO WS-HOLD-COVNO-R.

           IF WS-HOLD-COVNO             > WCVGM-MAX-WCVGS-NUM
      * MSG:  COVERAGE NUMBER MUST BE 2 DIGITS BETWEEN 01 AND 20
               MOVE 'CS28120037'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-CVG-NUM        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 7000-BUILD-KEYS-X
           END-IF.

           IF  MIR-CF-EFF-DT = SPACE
      *MSG: THE CASH FLOW EFFECTIVE DATE MUST BE ENTERED
               MOVE 'CS28120032'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           ELSE
               MOVE MIR-CF-EFF-DT      TO L1640-EXTERNAL-DATE
               PERFORM  1640-7000-MIR-TO-INT
                   THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-RETRN-OK
                   MOVE L1640-INTERNAL-DATE
                                       TO WS-CF-EFF-DT
               ELSE
      *MSG: CASH FLOW EFFECTIVE DATE IS INVALID
                   MOVE 'CS28120033'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF
           END-IF.

           IF  MIR-CF-SEQ-NUM = SPACE
      *MSG: THE CASH FLOW SEQUENCE NUMBER MUST BE ENTERED
               MOVE 'CS28120034'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           ELSE
               SET L0280-SIGN-NOT-PERMITTED TO TRUE
               SET L0280-SPACES-PERMITTED   TO TRUE
               MOVE ZERO               TO L0280-PRECISION
               MOVE LENGTH OF MIR-CF-SEQ-NUM
                                       TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
               MOVE MIR-CF-SEQ-NUM     TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-RETRN-OK
                   MOVE L0280-OUTPUT-V00
                                       TO WS-CF-SEQ-NUM
               ELSE
      *MSG: CASH FLOW SEQUENCE NUMBER IS INVALID
                   MOVE 'CS28120035'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR
                                       TO TRUE
               END-IF
           END-IF.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6530-0000-INIT-PARM-INFO
025970         THRU 6530-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORK-AREA.

025970     PERFORM  COMM-1000-INITIALIZE
025970         THRU COMM-1000-INITIALIZE-X.
025970*
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.     
025970     SET WS-TWRK-KEY-DEFAULT      TO TRUE.
025970     SET WS-MAX-LINES-DEFAULT     TO TRUE.
025970     MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
025970     SET MIR-RETRN-OK             TO TRUE.

           MOVE ZERO                    TO WS-TOTAL-DEP-AMT.
           MOVE ZERO                    TO WS-HIGHEST-ALLOC-NUM.

           PERFORM
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LINES
                   SET WS-NO-EDIT-THIS-LINE (WS-SUB)
                                        TO TRUE
                   MOVE ZERO            TO WS-CDI-ALLOC-AMT (WS-SUB)
                   MOVE ZERO            TO WS-CDI-GUAR-INT-RT (WS-SUB)
                   MOVE ZERO            TO WS-DPOS-TRM (WS-SUB)
           END-PERFORM.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
026057 COPY CCPPIHSD.
       COPY CCPPPLIN.
      /
       COPY NCPPCVGS.
      /
       COPY XCPPCOMM.
025970 COPY XCPS1670.
025970 COPY XCPSCOMM.
      /
       COPY XCPPEXIT.
      /
       COPY XCPPINIT.
      /
020478 COPY CCPPFPCK.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
       COPY CCPSPGA.
      /
020478 COPY CCPS2626.
020478 COPY CCPL2626.
020478/
       COPY CCPS5400.
       COPY CCPL5400.
      /
       COPY CCPS6530.
       COPY CCPL6530.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPL0290.
       COPY XCPS0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
       COPY XCPS8090.
       COPY XCPL8090.
      /
       COPY XCPS8960.
       COPY XCPL8960.
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
      /
       COPY CCPACDSI.
       COPY CCPCCDSI.
       COPY CCPUCDSI.
       COPY CCPXCDSI.
      /
       COPY CCPNCFLW.
      /
       COPY CCPNCVG.
      /
       COPY CCPNPH.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
       COPY CCPNPOLP.
       COPY CCPUPOLP.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM2812                     *
      ****************************************************************
