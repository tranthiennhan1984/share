      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM0600.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM0600                                         **
      **  REMARKS:  UWWK: PROCESS BROWSE OR MAINTAIN ACTIVITIES ON   **
      **            THE UNDERWRITER WORKLOAD TABLE.                  **
      **            THE UWWK TRANSACTION CAN BE USED TO DISPLAY A    **
      **            RECORD FOR EACH CLIENT ASSIGNED TO AN            **
      **            UNDERWRITER. IT CAN ALSO BE USED TO ADD, DELETE  **
      **            OR MAINTAIN THOSE RECORDS. AS PART OF THE        **
      **            MAINTAIN FUNCTION, THE UNDERWRITER CAN ALSO      **
      **            REASSIGN A CLIENT TO ANOTHER UNDERWRITER OR      **
      **            INITIATE A RETRY OF CLEAR CASE PROCESSING.       **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
554141**  5.5       DO NOT TRANSLATE LINK-ISS-IND                    **
557406**  5.5       REPLACE HARDCODED UWWK HOLD AREA                 **
557698**  5.5       MIXED-CASE SUPPORT                               **
557708**  5.5       CICS ABEND PROCESSING                            **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
008445**  5.5.2     GENERATE MIR FROM TECH ARCH DATA BASE            **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
012745**  5.6       SET LTPI-MAP-SCREEN-NO TO 1 WHEN FOUND TO        **
012745**            BE BLANKS                                        **
012624**  6.0       GLOBAL SECURITY                                  **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL LOCKING                                  **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016387**  6.2       REMOVAL OF CLIENT CONSOLIDATION                  **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016537**  6.2       CODE CLEAN UP                                    **
015782**  6.3       INCREASE NUMBER OF OCCURES ON UWWK               **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019982**  6.3       PCR FOR IIAB PLATFORM                            **
020462**  6.4       ISO DATE STANDARDIZATION                         **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0600'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.


       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'UWWK'.
           05  WS-POLICY-NO.
               10  WS-POLICY-BASE           PIC X(09)  VALUE SPACES.
               10  WS-POLICY-SFX            PIC X(01)  VALUE SPACES.
           05  WS-SAVE-POLICY-NO            PIC X(10)  VALUE SPACES.
           05  WS-KEY-POLICY                PIC X(10)  VALUE SPACES.
           05  WS-KEY-CLIENT-NUMBER         PIC X(10)  VALUE SPACES.
           05  WS-KEY-SYSTEM                PIC X(08)  VALUE SPACES.
           05  WS-CRSR-CLINO                PIC X(10)  VALUE SPACES.
           05  WS-USER-ID                   PIC X(08)  VALUE SPACES.
           05  WS-TEMP-USERID               PIC X(08)  VALUE SPACES.
557406*    05  WS-HOLD-UWWK-RECORD          PIC X(100) VALUE SPACES.
016440*    05  WS-PENDING-SW                PIC X(01)  VALUE 'N'.
016440     05  WS-PENDING-SW                PIC X(01).
               88  WS-PENDING                          VALUE 'Y'.
016440         88  WS-NO-PENDING                       VALUE 'N'.
           05  WS-POLICY-IND                PIC X(01).
               88  WS-POLICY-FOUND                     VALUE 'Y'.
               88  WS-NO-POLICY                        VALUE 'N'.
           05  WS-DATA-EDITS                PIC X(01)  VALUE SPACES.
               88  WS-DATA-EDITS-OK                    VALUE 'Y'.
           05  WS-CROSS-EDITS               PIC X(01)  VALUE SPACES.
               88  WS-CROSS-EDITS-OK                   VALUE 'Y'.
           05  WS-VALIDATE-CONTROL          PIC X(01)  VALUE SPACES.
               88  WS-INVALID-CONTROL                  VALUE 'Y'.
           05  WS-USERID-ENTRY              PIC X(01)  VALUE SPACES.
               88  WS-USERID-ENTERED                   VALUE 'Y'.
           05  WS-ACCESS-DENIED-SW          PIC X(01)  VALUE SPACES.
               88  WS-ACCESS-DENIED                    VALUE 'Y'.
           05  WS-RL-BROWSE-SW              PIC X(01)  VALUE SPACES.
               88  WS-RL-BROWSE                        VALUE 'Y'.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE
                   '0600' '0601' '0602' '0603' '0604'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '0600'.
               88  WS-BUS-FCN-CREATE        VALUE '0601'.
               88  WS-BUS-FCN-UPDATE        VALUE '0602'.
               88  WS-BUS-FCN-DELETE        VALUE '0603'.
               88  WS-BUS-FCN-LIST          VALUE '0604'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '0600'.
           05  WS-FCN-CD                    PIC X(02).
               88  WS-FCN-VALID             VALUE 'CC' 'RR' 'RA'.
               88  WS-FCN-CLEAR-CASE        VALUE 'CC'.
               88  WS-FCN-REASSIGN-ASSIST   VALUE 'RA'.
               88  WS-FCN-REASSIGN-REPLACE  VALUE 'RR'.
           05  WS-FIRST-NAME.
               10  WS-FIRST-NAME-LETTER     PIC X(01).
               10  WS-FIRST-NAME-REST       PIC X(24).
           05  WS-LAST-NAME.
               10  WS-LAST-NAME-PART        PIC X(10).
               10  WS-LAST-NAME-REST        PIC X(15).
           05  HOLD-RUN-ID                  PIC X(1)   VALUE SPACE.
           05  WS-NUM-9-LEN9                PIC 9(09)  VALUE ZEROS.
025970*    05  WS-PIC-DATE                  PIC X(10)
025970*                                     VALUE '0000-00-00'.
025970     05  WS-PIC-DATE                  PIC X(10).
025970         88  WS-DEFAULT-PIC-DATE      VALUE '0000-00-00'.
025970*    05  WS-LINE                      PIC S9(03) COMP-3
025970*                                     VALUE +1.
025970     05  WS-LINE                      PIC S9(03) COMP-3.
025970         88  WS-DEFAULT-LINE          VALUE +1.
025970*    05  WS-SUB                       PIC S9(03) COMP-3
025970*                                     VALUE +1.
025970     05  WS-SUB                       PIC S9(03) COMP-3.
025970         88  WS-DEFAULT-SUB           VALUE +1.
025970*    05  WS-CRSR                      PIC S9(03) COMP-3
025970*                                     VALUE +1.
025970     05  WS-CRSR                      PIC S9(03) COMP-3.
025970         88  WS-DEFAULT-CRSR          VALUE +1.
025970*    05  WS-CLINO-CTR                 PIC S9(03) COMP-3
025970*                                     VALUE +1.
025970     05  WS-CLINO-CTR                 PIC S9(03) COMP-3.
025970         88  WS-DEFAULT-CLINO-CTR     VALUE +1.
015782*    05  WS-NUMBER-OF-DISPLAY-LINES   PIC S9(03) COMP-3
015782*                                     VALUE +12.
025970*    05  WS-NUMBER-OF-DISPLAY-LINES   PIC S9(03) COMP-3
025970*                                     VALUE +100.
015782*    05  WS-DISPLAY-LINES-PLUS-ONE    PIC S9(03) COMP-3
015782*                                     VALUE +13.
025970*    05  WS-DISPLAY-LINES-PLUS-ONE    PIC S9(03) COMP-3
025970*                                     VALUE +101.
557756*    05  WS-SCREEN-LANG-USED          PIC S9(4) COMP.

557756*    05  WS-TRANSACTION.
557756*        10  FILLER             PIC X(08) VALUE 'UWKORRCS'.
557756*        10  WS-TRANS-ENGLISH         PIC X(04) VALUE 'UWKO'.
557756*        10  WS-TRANS-FRENCH          PIC X(04) VALUE 'RRCS'.
557756*        10  WS-TRANS-SPANISH         PIC X(04) VALUE 'RPCS'.
557756*    05  WS-TRANSACTIONS REDEFINES WS-TRANSACTION.
557756*        10  WS-TRANSACTION-BY-LANG  OCCURS 3  PIC X(04).
025970*    05  WS-FORMAT-DRIVER             PIC X(08)
025970*                                     VALUE 'NFE0580 '.
       01  WS-SWITCHES.
           05  WS-POLICY-TO-DISPLAY-SW      PIC X(01) VALUE SPACES.
               88  WS-NO-POLICY-TO-DISPLAY            VALUE 'N'.
               88  WS-POLICY-TO-DISPLAY               VALUE 'Y'.
      /
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-DEFAULT-TRANS-NAME               VALUE 'UWWK'.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                 VALUE '0600'.
025970     05  WS-NUMBER-OF-DISPLAY-LINES   PIC S9(03) COMP-3.
025970         88  WS-DEFAULT-NO-OF-DISPLAY-LINES      VALUE +100.
025970     05  WS-DISPLAY-LINES-PLUS-ONE    PIC S9(03) COMP-3.
025970         88  WS-DEFAULT-DISPLAY-LINES-PLUS1      VALUE +101.
      /
016537*COPY XCWWWKDT.
       COPY XCWEBLCH.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
014221 COPY CCWWLOCK.
      /
       COPY CCFRRL.
       COPY CCFWRL.
      /
       COPY NCFWUWWK.
       COPY NCFRUWWK.
557406 COPY NCFHUWWK.
      /
028298 COPY CCWL2626.
       COPY XCWL0220.
       COPY XCWLDTLK.
       COPY XCWL1640.
014221 COPY XCWL8090.
      /
       COPY NCWL2437.
       COPY CCWL5400.
       COPY CCWL5600.
       COPY CCWL0620.
      /
016440 COPY CCWL2222.
      /
       COPY NCWL0760.
       COPY NCWL1110.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0600.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

019982     INITIALIZE          L2222-PARM-INFO.

           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

025970*    SET  MIR-RETRN-OK          TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

      *  BUILD GENERAL PARM AREA
           PERFORM PGA-1000-BUILD-PARMS
              THRU PGA-1000-BUILD-PARMS-X.

      *  FUNCTIONS OTHER THAN BROWSE MAY ONLY BE PERFORMED BY A USER
      *  ON THEIR OWN WORKLOAD RECORDS OR BY AN ADMINISTRATOR, AND
      *  THE POLICY NUMBER SHOULD NOT BE ENTERED
           IF NOT WS-BUS-FCN-LIST
               MOVE SPACES            TO MIR-POL-ID
               PERFORM 3500-VALIDATE-ACCESS
                  THRU 3500-VALIDATE-ACCESS-X
               IF WS-ACCESS-DENIED
                  PERFORM 9100-BLANK-DATA-FIELDS
                     THRU 9100-BLANK-DATA-FIELDS-X
                  MOVE '1'            TO WGLOB-RETURN-CODE
                  GO TO 2000-PROCESS-REQUEST-X
               END-IF
           END-IF.

      * CHECK BUSINESS FUNCTION ID FOR FUNCTION REQUESTED

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM 3000-PROCESS-LIST
                       THRU 3000-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM 4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 4500-PROCESS-RETRIEVE
                       THRU 4500-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM 5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM 6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID  TO WGLOB-MSG-PARM (1)
                    MOVE 'NSOM0600'      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------------
       3000-PROCESS-LIST.
      *------------------

      * INQUIRY PROCESSING:
      * THIS ROUTINE WILL DISPLAY INFORMATION ON THE UWWKI MAP.
      * THIS FIRST MUST INTERROGATE THE CURSOR POSITION TO
      * DETERMINE IF THE USER WISHES TO TRANSFER TO THE UWDE SCREEN. IF
      * THE CURSOR POSITION IS BELOW THE ENTER FIELD THEN THE USER WILL
      * BE TRANSFERED TO THE UWDE SCREEN. IF NOT THE ROUTINE WILL
      * DISPLAY THE APPROPRIATE RECORDS.
      *
      *  PROGRAM WILL NOW TRANSFER TO THE UWKO SCREEN, INSTEAD OF UWDE

557756*    EVALUATE TRUE
557756*        WHEN WGLOB-USER-LANG-ENGLISH
557756*            MOVE 1                    TO WS-SCREEN-LANG-USED
557756*        WHEN WGLOB-USER-LANG-FRENCH
557756*            MOVE 2                    TO WS-SCREEN-LANG-USED
557756*        WHEN WGLOB-USER-LANG-SPANISH
557756*            MOVE 3                    TO WS-SCREEN-LANG-USED
557756*        WHEN OTHER
557756*            MOVE 1                    TO WS-SCREEN-LANG-USED
557756*    END-EVALUATE.

      *   DISPLAY THE DATA ON THE SCREEN.
           PERFORM 3010-DISPLAY-RECORDS
              THRU 3010-DISPLAY-RECORDS-X.

       3000-PROCESS-LIST-X.
           EXIT.
      /
      *---------------------
       3010-DISPLAY-RECORDS.
      *---------------------

      *-------------------------------------------------------------
      *THIS ROUTINE WILL BUILD THE BROWSE  SCREEN WITH INFORMATION
      *FROM THE UWWK, NAL AND POLICY FILES. A SEAPARATE LINE WILL BE
      *FORMATTED FOR EACH POLICY THAT THE CLIENT IS AN INSURED.
      *-------------------------------------------------------------

           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.

      ***  A USERID MUST BE ENTERED. IF A KEY FIELD IS BLANK ALL
      ***  KEY FIELDS THAT FOLLOW WILL BE SET TO BLANK.
           IF MIR-USER-ID = SPACES
      *MSG: USER ID MUST BE ENTERED
               MOVE 'NS06000025'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE SPACES            TO MIR-CLI-ID
               MOVE SPACES            TO MIR-POL-ID
               GO TO 3010-DISPLAY-RECORDS-X
           ELSE
               MOVE 'Y'               TO WS-USERID-ENTRY
           END-IF.

           IF MIR-CLI-ID = SPACES
               MOVE SPACES            TO MIR-POL-ID
           END-IF.


           PERFORM 7100-BUILD-UWWK-KEY
              THRU 7100-BUILD-UWWK-KEY-X.

           MOVE HIGH-VALUES           TO WUWWK-ENDBR-KEY.
           IF WS-USERID-ENTERED
               MOVE MIR-USER-ID       TO WUWWK-ENDBR-USER-ID
           END-IF.

           PERFORM  UWWK-1000-BROWSE
               THRU UWWK-1000-BROWSE-X.

           IF WUWWK-IO-OK
               PERFORM UWWK-2000-READ-NEXT
                  THRU UWWK-2000-READ-NEXT-X
           ELSE
      *MSG: NO UNDERWRITER WORKLOAD RECORDS FOUND TO DISPLAY
               MOVE 'NS06000002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3010-DISPLAY-RECORDS-X
           END-IF.

           IF  WS-USERID-ENTERED
           AND RUWWK-USER-ID NOT = MIR-USER-ID
      *MSG: NO UNDERWRITER WORKLOAD RECORDS FOUND TO DISPLAY
               MOVE 'NS06000002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  UWWK-3000-END-BROWSE
                   THRU UWWK-3000-END-BROWSE-X
               GO TO 3010-DISPLAY-RECORDS-X
           ELSE
               MOVE RUWWK-USER-ID     TO WUWWK-ENDBR-USER-ID
           END-IF.

           MOVE SPACES                TO WS-KEY-POLICY.
           MOVE SPACES                TO WS-KEY-CLIENT-NUMBER.

           IF WUWWK-IO-OK
               MOVE +1                TO WS-LINE
               PERFORM 3050-READ-UWWK-FILE
                  THRU 3050-READ-UWWK-FILE-X
                 UNTIL (WUWWK-IO-EOF)
                    OR (WS-LINE > WS-DISPLAY-LINES-PLUS-ONE)
           END-IF.

      ***  COMPLETION MESSAGE
           IF WUWWK-IO-EOF
           AND  WS-KEY-POLICY = SPACES
      *MSG: ** END OF LIST **
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE WS-KEY-CLIENT-NUMBER
                                      TO MIR-CLI-ID
               MOVE WS-KEY-POLICY     TO MIR-POL-ID
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
      *MSG: ** TO VIEW MORE DATA PRESS ENTER **
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
           END-IF.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  UWWK-3000-END-BROWSE
               THRU UWWK-3000-END-BROWSE-X.

       3010-DISPLAY-RECORDS-X.
           EXIT.
      /
      *--------------------
       3050-READ-UWWK-FILE.
      *--------------------

      *THIS ROUTINE WILL READ THE UWWK FROM THE START BROWSE, READ THE
      *NAL FILE WITH THE CLIENT NUMBER FORM THE UWWK RECORD, IT WILL
      *ALSO DO A START BROWSE ON THE RELATIONSHIP FILE.

           IF WS-LINE > WS-DISPLAY-LINES-PLUS-ONE
               GO TO 3050-READ-UWWK-FILE-X
           END-IF.

           MOVE 'NEWBUS'              TO WS-KEY-SYSTEM.
           MOVE RUWWK-CLI-ID          TO WS-KEY-CLIENT-NUMBER.

           IF WS-LINE < WS-DISPLAY-LINES-PLUS-ONE
               PERFORM  3055-MOVE-VALUES
                   THRU 3055-MOVE-VALUES-X
           END-IF.

           MOVE SPACES                TO WS-SAVE-POLICY-NO.

016440*    MOVE 'NEWBUS'              TO WRL-REL-SYS-ID.
016440     MOVE WGLOB-SYS-CTL-ID      TO WRL-REL-SYS-ID.
           MOVE RUWWK-CLI-ID          TO WRL-CLI-ID.
           MOVE 'I'                   TO WRL-REL-TYP-CD.
           IF WS-POLICY-NO = SPACES
               MOVE SPACES            TO WRL-REL-SYS-REF-ID
           ELSE
               MOVE WS-POLICY-NO      TO WRL-REL-SYS-REF-POL-ID
               MOVE ZEROS             TO WRL-REL-SYS-REF-CVG-NUM
           END-IF.

           MOVE HIGH-VALUES           TO WRL-ENDBR-KEY.
016440*    MOVE 'NEWBUS'              TO WRL-ENDBR-REL-SYS-ID.
016440     MOVE WGLOB-SYS-CTL-ID      TO WRL-ENDBR-REL-SYS-ID.
           MOVE RUWWK-CLI-ID          TO WRL-ENDBR-CLI-ID.

      ***  BLANK OUT POLICY NUMBER AFTER FIRST BROWSE SO IT WILL NOT
      ***  BE USED FOR READS FOR THE NEXT USER.
           MOVE SPACES                TO WS-POLICY-NO.

           MOVE 'N'                   TO WS-RL-BROWSE-SW.
           PERFORM RL-1000-BROWSE
              THRU RL-1000-BROWSE-X.
           IF WRL-IO-OK
               MOVE 'Y'               TO WS-RL-BROWSE-SW
               PERFORM RL-2000-READ-NEXT
                  THRU RL-2000-READ-NEXT-X
           END-IF.

      *    READ ALL THE RELATIONSHIP RECORDS FOR THE CLIENT.
           IF WRL-IO-OK
               PERFORM 3052-RELA-PROCESS
                   THRU 3052-RELA-PROCESS-X
           ELSE
               ADD +1 TO WS-LINE
           END-IF.

           IF WS-RL-BROWSE
               PERFORM RL-3000-END-BROWSE
                  THRU RL-3000-END-BROWSE-X
           END-IF.

           PERFORM  UWWK-2000-READ-NEXT
               THRU UWWK-2000-READ-NEXT-X.

       3050-READ-UWWK-FILE-X.
           EXIT.
      /
      *------------------
       3052-RELA-PROCESS.
      *------------------

           MOVE 'N'                   TO WS-POLICY-TO-DISPLAY-SW.

           PERFORM  3060-READ-RELA-POL
              THRU  3060-READ-RELA-POL-X
              UNTIL (WRL-IO-EOF)
                 OR (WS-LINE > WS-DISPLAY-LINES-PLUS-ONE).

           IF WS-NO-POLICY-TO-DISPLAY
      *MSG: NO INSURED ATTACHED TO POLICY @1
               MOVE 'NS06000029'      TO WGLOB-MSG-REF-INFO
               MOVE RPOL-POL-ID       TO WGLOB-MSG-PARM (1)
               ADD +1 TO WS-LINE
           END-IF.

       3052-RELA-PROCESS-X.
           EXIT.
      /
      *-----------------
       3055-MOVE-VALUES.
      *-----------------

      *  THIS ROUTINE ASSIGNS THE RECORD VALUES TO THE MIR FIELDS AND
      *  THE NAL FILE IS READ FOR THE CLIENT INFORMATION

           IF WS-LINE = 1
               MOVE RUWWK-CLI-ID      TO MIR-CLI-ID
           END-IF.

           MOVE RUWWK-CLI-ID          TO MIR-CLI-ID-T (WS-LINE).
           MOVE RUWWK-UW-CASE-PRTY-CD
                                     TO MIR-UW-CASE-PRTY-CD-T (WS-LINE).
           MOVE RUWWK-UW-CASE-REASN-CD
                                    TO MIR-UW-CASE-REASN-CD-T (WS-LINE).

           PERFORM 5600-1000-BUILD-PARM-INFO
              THRU 5600-1000-BUILD-PARM-INFO-X.
           MOVE RUWWK-CLI-ID          TO L5600-CLI-ID.
           SET L5600-CCAS-MSG-NOT-REQD     TO TRUE.
016387*    SET L5600-CNSLDT-MSG-NOT-REQD   TO TRUE.
           PERFORM 5600-1000-CLI-CHK
              THRU 5600-1000-CLI-CHK-X.
           IF L5600-RETRN-CLI-NOT-FOUND
               MOVE L5600-CLI-ID      TO WGLOB-MSG-PARM (1)
      *MSG: UNABLE TO READ BIOP RECORD; @1-KEY FROM WORKLOAD FILE
               MOVE 'NS06000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3055-MOVE-VALUES-X
           END-IF.

           IF L5600-CNFD-ACCS-RESTRICTED
              GO TO 3055-MOVE-VALUES-X
           END-IF.

           MOVE RUWWK-CLI-ID          TO L2437-CLI-ID.
           PERFORM 2437-1000-OBTAIN-CLI-INFO
              THRU 2437-1000-OBTAIN-CLI-INFO-X.
           IF NOT L2437-RETRN-OK
              MOVE '1'                TO WGLOB-RETURN-CODE
              GO TO 3055-MOVE-VALUES-X
           END-IF.

557698*    MOVE L2437-CLI-SUR-NM           TO WS-LAST-NAME.
557698     MOVE L2437-CLI-ENTR-SUR-NM TO WS-LAST-NAME.
015904*    MOVE WS-LAST-NAME-PART     TO MIR-CLI-SUR-NM-T (WS-LINE).
015904     MOVE WS-LAST-NAME-PART     TO MIR-CLI-INDV-SUR-NM-T
015904            (WS-LINE).
           MOVE L2437-CLI-GIV-NM      TO WS-FIRST-NAME.
015904*    MOVE WS-FIRST-NAME-LETTER  TO MIR-CLI-GIV-NM-T (WS-LINE).
015904     MOVE WS-FIRST-NAME-LETTER  TO MIR-CLI-INDV-GIV-NM-T
015904            (WS-LINE).
           MOVE L2437-PREV-UWG-ACTV-DT           TO L1640-INTERNAL-DATE.

020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE TO MIR-PREV-UWG-ACTV-DT-T (WS-LINE).

       3055-MOVE-VALUES-X.
           EXIT.
      /
      *-------------------
       3060-READ-RELA-POL.
      *-------------------

      *THIS ROUTINE WILL READ THE RELATIONSHIP FILE FROM THE POSITION OF
      *THE START BROWSE, USE THE POLICY NUMBER FROM THE RELA REC TO READ
      *THE POLICY RECORD.

           PERFORM 3070-PROCESS-POLICY
              THRU 3070-PROCESS-POLICY-X.

           PERFORM RL-2000-READ-NEXT
              THRU RL-2000-READ-NEXT-X.

       3060-READ-RELA-POL-X.
           EXIT.
      /
      *--------------------
       3070-PROCESS-POLICY.
      *--------------------

           IF RRL-REL-TYP-CD  NOT = 'I'
           OR RRL-REL-SYS-REF-POL-ID = WS-SAVE-POLICY-NO
               GO TO 3070-PROCESS-POLICY-X
           END-IF.

           MOVE RRL-REL-SYS-REF-POL-ID                   TO WPOL-POL-ID.
           PERFORM POL-1000-READ
              THRU POL-1000-READ-X.
           IF NOT WPOL-IO-OK
      *MSG: CANNOT READ POLICY (@1) WITH RELATIONSHIP KEY - CALL SYSTEMS
               MOVE 'NS06000005'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 99                TO WS-LINE
               GO TO 3070-PROCESS-POLICY-X
           END-IF.

           MOVE RPOL-POL-ID           TO WS-SAVE-POLICY-NO.

016440* WHEN THE POLICY IS IN FORCE, CALL SUB-ROUTINE TO DETERMINE
016440* IF ANY PENDING COVERAGES EXIST TO PERMIT CLEAR-CASING ON
016440* PENDING COVERAGES

016440     IF RPOL-POL-STAT-IN-FORCE
016440        PERFORM 2222-1000-BUILD-PARM-INFO
016440           THRU 2222-1000-BUILD-PARM-INFO-X
016440        MOVE RPOL-POL-ID        TO L2222-POL-ID
016440        PERFORM 2222-1000-FIND-PEND-CVG
016440           THRU 2222-1000-FIND-PEND-CVG-X
016440     END-IF.

           IF RPOL-POL-STAT-REJECTED
016440*    OR RPOL-POL-STAT-IN-FORCE
016440     OR (RPOL-POL-STAT-IN-FORCE
016440     AND L2222-INFORCE-POL-INFORCE-CVG)
               GO TO 3070-PROCESS-POLICY-X
           END-IF.

           MOVE 'Y'                   TO WS-POLICY-TO-DISPLAY-SW.

           PERFORM  5400-1000-BUILD-PARM-INFO
              THRU  5400-1000-BUILD-PARM-INFO-X.

012624*    SET L5400-CTL-MSG-NOT-REQD      TO TRUE.
           SET L5400-STAT-MSG-NOT-REQD     TO TRUE.
012624*    MOVE WGLOB-APPL-ID         TO L5400-SYS-APPL-CTL-CD.

016440     IF WS-BUS-FCN-CREATE
016440     OR WS-BUS-FCN-UPDATE
016440     OR WS-BUS-FCN-DELETE
016440        SET L5400-POL-XFER-UPDATE    TO TRUE
016440     END-IF.

           PERFORM 5400-1000-POL-CHK
              THRU 5400-1000-POL-CHK-X.

           IF L5400-RETRN-INVALID-REQUEST
           OR L5400-CNFD-ACCS-RESTRICTED
           OR L5400-BRCH-ACCS-RESTRICTED
016440     OR L5400-XFER-ACCS-RESTRICTED
              MOVE '1'                TO WGLOB-RETURN-CODE
              GO TO 3070-PROCESS-POLICY-X
           END-IF.

           IF WS-LINE = 1
               MOVE RPOL-POL-ID       TO MIR-POL-ID
           END-IF.

           IF WS-LINE > WS-NUMBER-OF-DISPLAY-LINES
               MOVE RPOL-POL-ID       TO WS-KEY-POLICY
               ADD +1 TO WS-LINE
               GO TO 3070-PROCESS-POLICY-X
           END-IF.

           MOVE RPOL-POL-ID-BASE      TO MIR-POL-ID-BASE-T (WS-LINE).
           MOVE RPOL-POL-ID-SFX       TO MIR-POL-ID-SFX-T (WS-LINE).
           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD-T (WS-LINE).
           MOVE RPOL-SERV-BR-ID       TO MIR-SERV-BR-ID-T (WS-LINE).

554141*    IF RPOL-LINK-POL-ISS-IND = 'Y'
554141*        MOVE 'L'             TO MIR-LINK-POL-ISS-IND-T (WS-LINE)
554141*    ELSE
554141*        MOVE SPACE           TO MIR-LINK-POL-ISS-IND-T (WS-LINE)
554141*    END-IF.
554141     MOVE RPOL-LINK-POL-ISS-IND
                                    TO MIR-LINK-POL-ISS-IND-T (WS-LINE).

           IF RPOL-POL-OPTL-CD      = 'N'
               MOVE SPACE             TO MIR-POL-OPTL-CD-T (WS-LINE)
           ELSE
               MOVE RPOL-POL-OPTL-CD  TO MIR-POL-OPTL-CD-T (WS-LINE)
           END-IF.

           ADD +1 TO WS-LINE.

       3070-PROCESS-POLICY-X.
           EXIT.
      /
      *---------------------
       3500-VALIDATE-ACCESS.
      *---------------------

      *THIS ROUTINE WILL DETERMINE IF A USER HAS ACCESS TO THE
      *WORKLOAD RECORD OF ANOTHER USER. THIS ACCESS IS DETERMINED BY
      *THE MESSAGE CLASS OF THE USER.

           IF MIR-USER-ID = WGLOB-USER-ID
               GO TO 3500-VALIDATE-ACCESS-X
           END-IF.

      *MSG: ACCESS TO ANOTHER USER'S WORKLOAD DENIED
           MOVE 'NS06000028'          TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.
           IF WGLOB-MSG-SEVRTY-FATAL
               MOVE 'Y'               TO WS-ACCESS-DENIED-SW
           ELSE
               MOVE 'N'               TO WS-ACCESS-DENIED-SW
           END-IF.

       3500-VALIDATE-ACCESS-X.
           EXIT.
      /
      *--------------------
       4000-PROCESS-CREATE.
      *--------------------

      *  CREATE PROCESSING: TWO PASSES REQUIRED
      *      CHECK FOR RECORD.  IF NOT FOUND CREATE RECORD AND
      *      ALLOW USER TO MODIFY UNDER MAINTAIN PROCESSING

           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.

      *  BUILD KEY USING CONTROL FIELDS.
           PERFORM 7100-BUILD-UWWK-KEY
              THRU 7100-BUILD-UWWK-KEY-X.

      *  VALID CONTROL FIELDS MUST HAVE BEEN ENTERED.
           PERFORM 7000-VALIDATE-CTL-FIELDS
              THRU 7000-VALIDATE-CTL-FIELDS-X.
           IF  WS-INVALID-CONTROL
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

      *  CHECK RECORD EXISTENCE.
           PERFORM  UWWK-1000-READ
               THRU UWWK-1000-READ-X.
           IF WUWWK-IO-OK
      *MSG: RECORD (@1) ALREADY EXISTS
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               MOVE WUWWK-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

      *  CREATE NEW RECORD.
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.
           PERFORM UWWK-1000-CREATE
              THRU UWWK-1000-CREATE-X.
           PERFORM UWWK-1000-WRITE
              THRU UWWK-1000-WRITE-X.

014221     PERFORM UWWK-1000-READ-TWRK-TS
014221        THRU UWWK-1000-READ-TWRK-TS-X.

           MOVE +1                    TO WS-LINE.
           MOVE 'UWWKS'               TO L0760-DAL-ACTIVITY.
           MOVE 'MADD'                TO L0760-DAL-ACTION.
           PERFORM 5600-UPDATE-DALG
              THRU 5600-UPDATE-DALG-X.
           MOVE RUWWK-USER-ID         TO WS-USER-ID.
           MOVE SPACES                TO WS-FCN-CD.
           PERFORM 5550-UPDATE-NAL
              THRU 5550-UPDATE-NAL-X.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *----------------------
       4500-PROCESS-RETRIEVE.
      *----------------------

           PERFORM 7100-BUILD-UWWK-KEY
              THRU 7100-BUILD-UWWK-KEY-X.

           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.

014221*    PERFORM UWWK-1000-READ
014221*       THRU UWWK-1000-READ-X.

014221     PERFORM UWWK-1000-READ-TWRK-TS
014221        THRU UWWK-1000-READ-TWRK-TS-X.

           IF WUWWK-IO-NOT-FOUND
      *MSG: WORKLOAD RECORD (@1) NOT FOUND
               MOVE 'NS06000006'      TO WGLOB-MSG-REF-INFO
               MOVE WUWWK-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4500-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       4500-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------

      *****************************************************************
      *  MAINTAIN PROCESSING:
      *       GET RECORD, EDIT DATA FIELDS AND UPDATE RECORD.
      *       FIELDS WITH ERRORS ARE NOT UPDATED.
      *****************************************************************

           PERFORM  7100-BUILD-UWWK-KEY
               THRU 7100-BUILD-UWWK-KEY-X.

014221*    PERFORM  UWWK-1000-READ-FOR-UPDATE
014221*        THRU UWWK-1000-READ-FOR-UPDATE-X.

014221     PERFORM  UWWK-2000-UPDATE-TWRK-TS
014221         THRU UWWK-2000-UPDATE-TWRK-TS-X.

           IF WUWWK-IO-NOT-FOUND
      *MSG: LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WUWWK-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'UWWK'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WUWWK-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

557698*
557698*   RETRIEVE CLIENT NAME
557698*
557698     MOVE RUWWK-CLI-ID          TO L2437-CLI-ID.
557698     PERFORM 2437-1000-OBTAIN-CLI-INFO
557698        THRU 2437-1000-OBTAIN-CLI-INFO-X.
557698     IF L2437-RETRN-CLI-NOT-FOUND
557698*MSG: UNABLE TO READ BIOP RECORD; @1-KEY FROM WORKLOAD FILE
557698*MSG: - CALL SYSTEMS
557698         MOVE 'NS06000003'      TO WGLOB-MSG-REF-INFO
557698         MOVE L2437-WCLI-KEY    TO WGLOB-MSG-PARM (1)
557698         PERFORM  0260-1000-GENERATE-MESSAGE
557698             THRU 0260-1000-GENERATE-MESSAGE-X
557698         MOVE SPACES            TO MIR-DV-OWN-CLI-NM
557698     ELSE
557698         MOVE L2437-CLI-SEX-CD  TO L0620-CLI-SEX-CD
557698         MOVE L2437-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
557698         MOVE L2437-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
557698         MOVE L2437-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
013578         MOVE L2437-CLI-MID-INIT-NM
013578                                TO L0620-CLI-MID-INIT-NM
013578         MOVE L2437-CLI-SFX-NM  TO L0620-CLI-SFX-NM
557698         PERFORM 0620-1000-FORMAT-SCREEN-NAME
557698            THRU 0620-1000-FORMAT-SCREEN-NAME-X
557698         IF L0620-RETRN-OK
557698            MOVE L0620-SCREEN-NAME
                                      TO MIR-DV-OWN-CLI-NM
557698         ELSE
557698            MOVE SPACES         TO MIR-DV-OWN-CLI-NM
557698         END-IF
557698     END-IF.


           PERFORM 7500-EDIT-DATA-FIELDS
              THRU 7500-EDIT-DATA-FIELDS-X.

      *   IF ALL EDITS WERE OK THEN UPDATE THE UWWK RECORD AND THE
      *   NAL RECORD IF REQUIRED. OTHERWISE ONLY UPDATE THE UWWK RECORD.
      *   USE THE ORIGINAL KEY IN CASE A NEW USERID WAS ENTERED.

           IF  WS-DATA-EDITS-OK
           AND WS-CROSS-EDITS-OK
               PERFORM 5500-UPDATE-RECORDS
                  THRU 5500-UPDATE-RECORDS-X
           ELSE
               MOVE WUWWK-KEY         TO RUWWK-KEY
               PERFORM UWWK-2000-REWRITE
                  THRU UWWK-2000-REWRITE-X
014221         PERFORM UWWK-1000-READ-TWRK-TS
014221            THRU UWWK-1000-READ-TWRK-TS-X
           END-IF.


           IF  WS-DATA-EDITS-OK
           AND WS-CROSS-EDITS-OK
      *MSG:  MAINTENANCE COMPLETED - CONTINUE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:  RECORD UPDATED
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *--------------------
       5500-UPDATE-RECORDS.
      *--------------------

      *DEPENDING ON WHAT DATA WAS MAINTAINED ON THE UWWK SCREEN THIS
      *ROUTINE WILL UPDATE THE NAL, DAL AND UWWK FILES.

           IF  MIR-DV-UW-CASE-FCN-CD = SPACES
           AND MIR-DV-UW-CASE-USER-ID = SPACES
               PERFORM UWWK-2000-REWRITE
                  THRU UWWK-2000-REWRITE-X
014221         PERFORM UWWK-1000-READ-TWRK-TS
014221            THRU UWWK-1000-READ-TWRK-TS-X
               GO TO 5500-UPDATE-RECORDS-X
           END-IF.

           IF WS-FCN-REASSIGN-ASSIST
           OR WS-FCN-REASSIGN-REPLACE
557406*        MOVE RUWWK-REC-INFO TO WS-HOLD-UWWK-RECORD
557406         MOVE RUWWK-REC-INFO    TO HUWWK-REC-INFO
               PERFORM UWWK-1000-DELETE
                  THRU UWWK-1000-DELETE-X
               MOVE MIR-DV-UW-CASE-USER-ID   TO WUWWK-USER-ID
               PERFORM  UWWK-1000-READ
                   THRU UWWK-1000-READ-X
               IF  NOT WUWWK-IO-OK
557406*            MOVE WS-HOLD-UWWK-RECORD TO RUWWK-REC-INFO
557406             MOVE HUWWK-REC-INFO                 TO RUWWK-REC-INFO
                   PERFORM UWWK-1000-WRITE
                      THRU UWWK-1000-WRITE-X
               END-IF
           END-IF.

           IF WS-FCN-REASSIGN-ASSIST
           OR WS-FCN-REASSIGN-REPLACE
               MOVE SPACES            TO MIR-DV-UW-CASE-USER-ID
               MOVE RUWWK-USER-ID     TO WS-USER-ID
               MOVE RUWWK-CLI-ID      TO L2437-CLI-ID
               PERFORM 5550-UPDATE-NAL
                  THRU 5550-UPDATE-NAL-X
               MOVE 'UWINT'           TO L0760-DAL-ACTIVITY
               MOVE 'ASGN'            TO L0760-DAL-ACTION
               PERFORM 5600-UPDATE-DALG
                  THRU 5600-UPDATE-DALG-X
               GO TO 5500-UPDATE-RECORDS-X
           END-IF.

016440*BEFORE CALLING THE CLEAR CASE PROCESSING
016440*DETERMINE IF PROCESSING IS TO BE PERFORMED AT A POLICY
016440*OR COVERAGE LEVEL

016440     IF WS-PENDING
016440     AND L2222-INFORCE-POL-PEND-CVG
016440        SET  L1110-INFORCE-POL-PEND-CVG TO TRUE
016440        MOVE L2222-PEND-CVG-RECV-DT     TO L1110-PEND-CVG-RECV-DT
016440     END-IF.

           IF MIR-DV-UW-CASE-FCN-CD NOT = SPACES
               PERFORM UWWK-2000-REWRITE
                  THRU UWWK-2000-REWRITE-X
014221         PERFORM UWWK-1000-READ-TWRK-TS
014221            THRU UWWK-1000-READ-TWRK-TS-X
               MOVE 'CLDEC'           TO L0760-DAL-ACTIVITY
               IF MIR-DV-UW-CASE-FCN-CD = 'WS'
                   MOVE 'WS'          TO L0760-DAL-ACTION
                   PERFORM 5600-UPDATE-DALG
                      THRU 5600-UPDATE-DALG-X
      *  TRANSFER TO WORK STATION 501501
               ELSE
                   EVALUATE TRUE
016440*                WHEN WS-POLICY-FOUND
016440                 WHEN WS-PENDING
      *  SEND THE CLIENT FOR CLEAR CASE PROCESSING.
                          MOVE 'RECC' TO L0760-DAL-ACTION
                          PERFORM 5600-UPDATE-DALG
                             THRU 5600-UPDATE-DALG-X
                          PERFORM 5510-INIT-CC-PARMS
                             THRU 5510-INIT-CC-PARMS-X
                          VARYING WS-SUB FROM 1 BY 1
                            UNTIL WS-SUB > L1110-ARRAY-MAX
                          MOVE MIR-CLI-ID
                                      TO L1110-CLI-ID (1)
                          SET L1110-UWG-PRCES-ALL (1) TO TRUE

                          PERFORM 1110-1000-START-CLEAR-CASE
                             THRU 1110-1000-START-CLEAR-CASE-X
                       WHEN OTHER
                          GO TO 5500-UPDATE-RECORDS-X
                   END-EVALUATE
               END-IF
           END-IF.

           MOVE SPACES                TO MIR-DV-UW-CASE-FCN-CD.

       5500-UPDATE-RECORDS-X.
           EXIT.
      /
      *-------------------
       5510-INIT-CC-PARMS.
      *-------------------

      *INITIALIZE CLEAR CASE PARAMETER ARRAY.

           MOVE SPACES                TO L1110-CLI-ID (WS-SUB).
           MOVE SPACES                TO L1110-UWG-PRCES-CD (WS-SUB).

       5510-INIT-CC-PARMS-X.
           EXIT.
      /
      *----------------
       5550-UPDATE-NAL.
      *----------------

      *  THIS ROUTINE WILL UPDATE THE NAL RECORD WITH THE USER-ID THAT
      *  WAS MAINTAINED ON THE UWWK SCREEN AND UPDATE THE FIELD
      *  CLIENT-LAST-ACTIVITY-DATE WITH THE SYSTEM DATE.

           PERFORM 2437-1000-OBTAIN-CLI-INFO
              THRU 2437-1000-OBTAIN-CLI-INFO-X.
           IF NOT L2437-RETRN-OK
      *MSG: UNABLE TO READ BIOP RECORD; @1-KEY FROM WORKLOAD FILE
               MOVE 'NS06000003'      TO WGLOB-MSG-REF-INFO
               MOVE L2437-CLI-ID      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WGLOB-RETURN-CODE
               GO TO 5550-UPDATE-NAL-X
           END-IF.

           MOVE WUWWK-CLI-ID          TO L2437-CLI-ID.
           MOVE WGLOB-SYSTEM-DATE-INT TO L2437-PREV-UWG-ACTV-DT.
           IF WS-FCN-REASSIGN-ASSIST
              MOVE WS-USER-ID         TO L2437-CLI-UW-USER-2-ID
           ELSE
              MOVE WS-USER-ID         TO L2437-CLI-UW-USER-1-ID
              MOVE SPACES             TO L2437-CLI-UW-USER-2-ID
           END-IF.

           IF L2437-CLI-UW-USER-1-ID = L2437-CLI-UW-USER-2-ID
              MOVE SPACES             TO L2437-CLI-UW-USER-2-ID
           END-IF.
           SET L2437-PREV-UWG-ACTV-DT-UPDT   TO TRUE.
           SET L2437-CLI-UW-USER-1-ID-UPDT   TO TRUE.
           SET L2437-CLI-UW-USER-2-ID-UPDT   TO TRUE.
           PERFORM 2437-2000-UPDT-CLI-INFO
              THRU 2437-2000-UPDT-CLI-INFO-X.
           IF NOT L2437-RETRN-OK
              MOVE '1'                TO WGLOB-RETURN-CODE
              GO TO 5550-UPDATE-NAL-X
           END-IF.

       5550-UPDATE-NAL-X.
           EXIT.
      /
      *-----------------
       5600-UPDATE-DALG.
      *-----------------

      *  THIS ROUTINE WILL BUILB THE COMMON FIELDS THAT ARE NEEDED FOR
      *  RECORDS THAT ARE WRITTEN TO DAIRY ACTIVITY LOG.

           MOVE 'C'                   TO L0760-POL-OR-CLI-TYPE.
           MOVE WUWWK-CLI-ID          TO L0760-POL-OR-CLI-ID.
           MOVE ZEROS                 TO L0760-CVG-NUM-N.
           MOVE SPACES                TO L0760-MESSAGE-NUMBER.

           PERFORM 0760-1000-PROCESS-DAL-ENTRY
              THRU 0760-1000-PROCESS-DAL-ENTRY-X.

           IF NOT L0760-RETRN-OK
              MOVE '1'                TO WGLOB-RETURN-CODE
           END-IF.

       5600-UPDATE-DALG-X.
           EXIT.
      /
      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

           PERFORM  7100-BUILD-UWWK-KEY
               THRU 7100-BUILD-UWWK-KEY-X.
014221*    PERFORM  UWWK-1000-READ-FOR-UPDATE
014221*        THRU UWWK-1000-READ-FOR-UPDATE-X.
014221     PERFORM  UWWK-2000-UPDATE-TWRK-TS
014221         THRU UWWK-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'UWWK'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WUWWK-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF WUWWK-IO-NOT-FOUND
      *MSG: RECORD (@1) LOST IN DELETE - CONTACT SYSTEMS
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WUWWK-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           ELSE
               PERFORM  6110-CHECK-FOR-PENDING-POL
                   THRU 6110-CHECK-FOR-PENDING-POL-X
               IF WS-PENDING
      *MSG: CLIENT HAS ONE OR MORE PENDING POLICIES - RECORD NOT
      *MSG: DELETED
                   MOVE 'NS06000004'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 6000-PROCESS-DELETE-X
               ELSE
      *MSG: DELETE COMPLETED - CONTINUE
                   MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
                   PERFORM  UWWK-1000-DELETE
                       THRU UWWK-1000-DELETE-X
                   MOVE 'UWWKS'           TO L0760-DAL-ACTIVITY
                   MOVE 'MDEL'            TO L0760-DAL-ACTION
                   PERFORM 5600-UPDATE-DALG
                      THRU 5600-UPDATE-DALG-X
                   MOVE SPACES            TO WS-USER-ID
                   MOVE SPACES            TO WS-FCN-CD
                   MOVE RUWWK-CLI-ID      TO L2437-CLI-ID
                   PERFORM  5550-UPDATE-NAL
                       THRU 5550-UPDATE-NAL-X
               END-IF
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *---------------------------
       6110-CHECK-FOR-PENDING-POL.
      *---------------------------

      * IF THE CLIENT HAS ANY PENDING POLICIES WE WILL NOT DELETE
      * THE RECORD FROM THE U/W'S WORKLOAD

016440*    MOVE 'NEWBUS'              TO WRL-REL-SYS-ID.
016440     MOVE WGLOB-SYS-CTL-ID      TO WRL-REL-SYS-ID.
           MOVE RUWWK-CLI-ID          TO WRL-CLI-ID.
           MOVE 'I'                   TO WRL-REL-TYP-CD.
           IF WS-POLICY-NO = SPACES
               MOVE SPACES            TO WRL-REL-SYS-REF-ID
           ELSE
               MOVE WS-POLICY-NO      TO WRL-REL-SYS-REF-POL-ID
               MOVE ZEROS             TO WRL-REL-SYS-REF-CVG-NUM
           END-IF.

           MOVE HIGH-VALUES           TO WRL-ENDBR-KEY.
016440*    MOVE 'NEWBUS'              TO WRL-ENDBR-REL-SYS-ID.
016440     MOVE WGLOB-SYS-CTL-ID      TO WRL-ENDBR-REL-SYS-ID.
           MOVE RUWWK-CLI-ID          TO WRL-ENDBR-CLI-ID.

      ***  BLANK OUT POLICY NUMBER AFTER FIRST BROWSE SO IT WILL NOT
      ***  BE USED FOR READS FOR THE NEXT USER.
           MOVE SPACES                TO WS-POLICY-NO.

           PERFORM RL-1000-BROWSE
              THRU RL-1000-BROWSE-X.
           IF WRL-IO-OK
               PERFORM  RL-2000-READ-NEXT
                   THRU RL-2000-READ-NEXT-X
           ELSE
      *MSG: CLIENT(@1) HAS NO PENDING POLICY RELATIONSHIPS
               MOVE 'NS06000007'      TO WGLOB-MSG-REF-INFO
               MOVE WRL-CLI-ID        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6110-CHECK-FOR-PENDING-POL-X
           END-IF.

           IF WRL-IO-OK
               PERFORM  6120-READ-RELA-POL
                  THRU  6120-READ-RELA-POL-X
                 UNTIL  WRL-IO-EOF
           END-IF.

           PERFORM  RL-3000-END-BROWSE
               THRU RL-3000-END-BROWSE-X.

       6110-CHECK-FOR-PENDING-POL-X.
           EXIT.
      /
      *-------------------
       6120-READ-RELA-POL.
      *-------------------

      *THIS ROUTINE WILL READ THE RELATIONSHIP FILE FROM THE POSITION OF
      *THE START BROWSE, USE THE POLICY NUMBER FROM THE RELA REC TO READ
      *THE POLICY RECORD.

           PERFORM  6130-PROCESS-POLICY
               THRU 6130-PROCESS-POLICY-X.

           PERFORM RL-2000-READ-NEXT
              THRU RL-2000-READ-NEXT-X.

       6120-READ-RELA-POL-X.
           EXIT.
      /
      *--------------------
       6130-PROCESS-POLICY.
      *--------------------

           IF RRL-REL-TYP-CD  NOT = 'I'
               GO TO 6130-PROCESS-POLICY-X
           END-IF.

           MOVE RRL-REL-SYS-REF-POL-ID                   TO WPOL-POL-ID.
           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.
           IF NOT WPOL-IO-OK
      *MSG: CANNOT READ POLICY (@1) WITH RELATIONSHIP KEY - CALL
      *MSG: SYSTEMS
               MOVE 'NS06000005'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6130-PROCESS-POLICY-X
           END-IF.

016440* IF POLICY IS IN FORCE, CALL SUB-ROUTINE TO BROWSE FOR PENDING
016440* COVERAGES

           IF RPOL-POL-STAT-PENDING
               MOVE 'Y'               TO WS-PENDING-SW
016440     ELSE
016440        PERFORM 2222-1000-BUILD-PARM-INFO
016440           THRU 2222-1000-BUILD-PARM-INFO-X
016440        MOVE RPOL-POL-ID        TO L2222-POL-ID
016440        PERFORM 2222-1000-FIND-PEND-CVG
016440           THRU 2222-1000-FIND-PEND-CVG-X
016440        IF L2222-INFORCE-POL-PEND-CVG
016440           SET WS-PENDING       TO TRUE
016440        END-IF
           END-IF.

       6130-PROCESS-POLICY-X.
           EXIT.
      /
      *-------------------------
       7000-VALIDATE-CTL-FIELDS.
      *-------------------------

           MOVE 'N'                   TO WS-VALIDATE-CONTROL.

      *  THE CONTROL FIELDS CANNOT BE SPACES.
           IF MIR-USER-ID = SPACES
      *MSG: USERID MUST BE ENTERED
               MOVE 'NS06000009'      TO WGLOB-MSG-REF-INFO
               MOVE 'Y'               TO WS-VALIDATE-CONTROL
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF MIR-CLI-ID = SPACES
      *MSG: CLIENT NUMBER MUST BE ENTERED
               MOVE 'NS06000010'      TO WGLOB-MSG-REF-INFO
               MOVE 'Y'               TO WS-VALIDATE-CONTROL
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-VALIDATE-CTL-FIELDS-X
           END-IF.

           PERFORM 5600-1000-BUILD-PARM-INFO
              THRU 5600-1000-BUILD-PARM-INFO-X.
           MOVE MIR-CLI-ID            TO L5600-CLI-ID.
016387*    SET L5600-CNSLDT-MSG-NOT-REQD   TO TRUE.
           PERFORM 5600-1000-CLI-CHK
              THRU 5600-1000-CLI-CHK-X.
           IF L5600-RETRN-CLI-NOT-FOUND
              SET WS-INVALID-CONTROL       TO TRUE
               GO TO 7000-VALIDATE-CTL-FIELDS-X
           END-IF.
           IF L5600-CNFD-ACCS-RESTRICTED
              SET WS-INVALID-CONTROL       TO TRUE
              GO TO 7000-VALIDATE-CTL-FIELDS-X
           END-IF.
           IF L5600-CCAS-ACCS-RESTRICTED
              SET WS-INVALID-CONTROL       TO TRUE
              GO TO 7000-VALIDATE-CTL-FIELDS-X
           END-IF.

           MOVE L5600-CLI-ID          TO L2437-CLI-ID.
           PERFORM 2437-1000-OBTAIN-CLI-INFO
              THRU 2437-1000-OBTAIN-CLI-INFO-X.
           IF NOT L2437-RETRN-OK
              MOVE '1'                TO WGLOB-RETURN-CODE
              GO TO 7000-VALIDATE-CTL-FIELDS-X
           END-IF.
           IF L2437-CLI-UW-USER-2-ID NOT = SPACES
              MOVE L2437-CLI-UW-USER-2-ID
                                      TO WS-TEMP-USERID
           ELSE
              MOVE L2437-CLI-UW-USER-1-ID
                                      TO WS-TEMP-USERID
           END-IF.

           IF WS-TEMP-USERID NOT = SPACES
               IF WS-TEMP-USERID NOT = MIR-USER-ID
      *MSG:  CLIENT ALREADY ASSIGNED TO @1
                   MOVE 'NS06000013'  TO WGLOB-MSG-REF-INFO
                   MOVE WS-TEMP-USERID             TO WGLOB-MSG-PARM (1)
                   MOVE 'Y'           TO WS-VALIDATE-CONTROL
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       7000-VALIDATE-CTL-FIELDS-X.
           EXIT.
      /
      *--------------------
       7100-BUILD-UWWK-KEY.
      *--------------------

      *****************************************************************
      *  BUILD UWWK KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
      *****************************************************************
           MOVE MIR-USER-ID           TO WUWWK-USER-ID.
           MOVE MIR-CLI-ID            TO WUWWK-CLI-ID.

           IF WS-BUS-FCN-LIST
              MOVE MIR-POL-ID-BASE    TO WS-POLICY-BASE
              MOVE MIR-POL-ID-SFX     TO WS-POLICY-SFX
           ELSE
              MOVE SPACES             TO WS-POLICY-NO
           END-IF.

       7100-BUILD-UWWK-KEY-X.
           EXIT.
      /
      *----------------------
       7500-EDIT-DATA-FIELDS.
      *----------------------

      *****************************************************************
      *  EDIT DATA FIELDS ACCORDING TO THE DATA DICTIONARY
      *****************************************************************

           MOVE 'Y'                   TO WS-DATA-EDITS.
           MOVE 'Y'                   TO WS-CROSS-EDITS.

           PERFORM  7510-EDIT-PRIORITY
               THRU 7510-EDIT-PRIORITY-X.

           PERFORM  7520-EDIT-REASON
               THRU 7520-EDIT-REASON-X.

           PERFORM  7530-EDIT-NEW-INITIALS
               THRU 7530-EDIT-NEW-INITIALS-X.

           PERFORM  7540-EDIT-FUNCTION
               THRU 7540-EDIT-FUNCTION-X.

           PERFORM 5600-1000-BUILD-PARM-INFO
              THRU 5600-1000-BUILD-PARM-INFO-X.
           MOVE MIR-CLI-ID            TO L5600-CLI-ID.
016387*    SET L5600-CNSLDT-MSG-NOT-REQD   TO TRUE.
           SET L5600-CNFD-MSG-NOT-REQD     TO TRUE.
           PERFORM 5600-1000-CLI-CHK
              THRU 5600-1000-CLI-CHK-X.
           IF L5600-RETRN-CLI-NOT-FOUND
           OR L5600-CCAS-ACCS-RESTRICTED
              MOVE 'N'                TO WS-DATA-EDITS
              GO TO 7500-EDIT-DATA-FIELDS-X
           END-IF.

      *   CROSS EDITS IF ABOVE EDITS ARE VALID.
           IF MIR-UW-CASE-PRTY-CD NOT = SPACES
               IF MIR-UW-CASE-REASN-CD = SPACES AND
                   RUWWK-UW-CASE-REASN-CD = SPACES
      *MSG: MUST ENTER REASON CODE FOR PRIORITY CHANGE
                   MOVE 'NS06000014'  TO WGLOB-MSG-REF-INFO
                   MOVE 'N'           TO WS-CROSS-EDITS
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF MIR-UW-CASE-REASN-CD NOT = SPACES
               IF MIR-UW-CASE-PRTY-CD = SPACES
               AND RUWWK-UW-CASE-PRTY-CD = SPACES
      *MSG: MUST ENTER PRIORITY FOR REASON CODE
                   MOVE 'NS06000015'  TO WGLOB-MSG-REF-INFO
                   MOVE 'N'           TO WS-CROSS-EDITS
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *  WHEN A NEW USERID IS ENTERED, THE FUNCTION MUST BE RR OR RA
           IF MIR-DV-UW-CASE-USER-ID NOT = SPACES
               IF WS-FCN-REASSIGN-ASSIST
               OR WS-FCN-REASSIGN-REPLACE
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
      *MSG: RE-ASSIGN FUNCTION MUST BE 'RR' OR 'RA'
                   MOVE 'NS06000016'  TO WGLOB-MSG-REF-INFO
                   MOVE 'N'           TO WS-CROSS-EDITS
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *  WHEN A NEW USERID IS ENTERED, THE FUNCTION MUST BE RR OR RA
           IF WS-FCN-REASSIGN-ASSIST
           OR WS-FCN-REASSIGN-REPLACE
               IF MIR-DV-UW-CASE-USER-ID = SPACES
      *MSG: RE-ASSIGN REQUESTED - USER ID MUST BE ENTERED
                   MOVE 'NS06000027'  TO WGLOB-MSG-REF-INFO
                   MOVE 'N'           TO WS-CROSS-EDITS
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      *  NEW USER INITIALS MUST BE DIFFERENT FROM CURRENT USER.
           IF MIR-DV-UW-CASE-USER-ID = MIR-USER-ID
               MOVE SPACES            TO MIR-DV-UW-CASE-FCN-CD
      *MSG: NEW U/W INITIALS SHOULD NOT EQUAL CURRENT INITIALS
               MOVE 'NS06000024'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DV-UW-CASE-USER-ID  TO WGLOB-MSG-PARM (1)
               MOVE 'N'               TO WS-CROSS-EDITS
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7500-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      *-------------------
       7510-EDIT-PRIORITY.
      *-------------------

      *****************************************************************
      *  UW-PRIORITY: VALIDATED AGAINST EDIT TABLE
      *****************************************************************

           IF MIR-UW-CASE-PRTY-CD = SPACES
               MOVE RUWWK-UW-CASE-PRTY-CD
                                      TO MIR-UW-CASE-PRTY-CD
           ELSE
               IF MIR-UW-CASE-PRTY-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-UW-CASE-PRTY-CD
               END-IF
           END-IF.

      *  VALIDATE UWPTY2 AGAINST EDIT TABLE.
           MOVE 'UWPTY'               TO WEDIT-ETBL-TYP-ID.
           MOVE MIR-UW-CASE-PRTY-CD   TO WEDIT-ETBL-VALU-ID.
           MOVE WGLOB-EDIT-LANG       TO WEDIT-ETBL-LANG-CD.
           PERFORM EDIT-1000-READ
              THRU EDIT-1000-READ-X.
           IF WEDIT-IO-OK
               MOVE MIR-UW-CASE-PRTY-CD
                                      TO RUWWK-UW-CASE-PRTY-CD
           ELSE
      *MSG: PRIORITY CODE MUST BE IN EDIT TYEP 'UWPTY'
               MOVE 'NS06000017'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-UW-CASE-PRTY-CD
                                      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
           END-IF.

       7510-EDIT-PRIORITY-X.
           EXIT.
      /
      *-----------------
       7520-EDIT-REASON.
      *-----------------

      *****************************************************************
      *  UW-REASON-CODE: VALIDATED AGAINST EDIT TABLE
      *****************************************************************

           IF MIR-UW-CASE-REASN-CD = SPACES
               MOVE RUWWK-UW-CASE-REASN-CD
                                      TO MIR-UW-CASE-REASN-CD
           ELSE
               IF MIR-UW-CASE-REASN-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-UW-CASE-REASN-CD
               END-IF
           END-IF.

      *  VALIDATE UWREA2 AGAINST EDIT TABLE.
           MOVE 'UWRSN'               TO WEDIT-ETBL-TYP-ID.
           MOVE MIR-UW-CASE-REASN-CD  TO WEDIT-ETBL-VALU-ID.
           MOVE WGLOB-EDIT-LANG       TO WEDIT-ETBL-LANG-CD.
           PERFORM EDIT-1000-READ
              THRU EDIT-1000-READ-X.
           IF WEDIT-IO-OK
               MOVE MIR-UW-CASE-REASN-CD
                                      TO RUWWK-UW-CASE-REASN-CD
           ELSE
      *MSG: REASON CODE MUST BE IN EDIT TYPE 'UWRSN'
               MOVE 'NS06000018'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-UW-CASE-REASN-CD
                                      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
           END-IF.

       7520-EDIT-REASON-X.
           EXIT.
      /
      *-----------------------
       7530-EDIT-NEW-INITIALS.
      *-----------------------

      *****************************************************************
      *  UW-NEW-INITIALS: VALIDATED AGAINST USER PROFILE
      *****************************************************************

           IF MIR-DV-UW-CASE-USER-ID = SPACES
               GO TO 7530-EDIT-NEW-INITIALS-X
           ELSE
               IF MIR-DV-UW-CASE-USER-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-DV-UW-CASE-USER-ID
               END-IF
           END-IF.

      *  VALIDATE USRI201 AGAINST USER PROFILE TABLE.
           MOVE MIR-DV-UW-CASE-USER-ID TO L0220-USER-ID.
           MOVE WGLOB-COMPANY-CODE    TO L0220-COMPANY-CODE.
012624*    MOVE SPACES                TO L0220-APPL-ID.

           PERFORM  0220-1000-VERIFY-USER-ID
               THRU 0220-1000-VERIFY-USER-ID-X.

           IF L0220-NO-SUCH-USER
      *MSG: NEW INITIALS MUST BE VALID USER ID
               MOVE 'NS06000019'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DV-UW-CASE-USER-ID  TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
           END-IF.

       7530-EDIT-NEW-INITIALS-X.
           EXIT.
      /
      *-------------------
       7540-EDIT-FUNCTION.
      *-------------------

      *****************************************************************
      *  FUNCTION: MUST BE 'CC',  'RR', 'RA'
      *****************************************************************

           IF MIR-DV-UW-CASE-FCN-CD = SPACES
               GO TO 7540-EDIT-FUNCTION-X
           ELSE
               IF MIR-DV-UW-CASE-FCN-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-DV-UW-CASE-FCN-CD
               END-IF
           END-IF.

      *  VALIDATE UWFCN AGAINST USER PROFILE TABLE.
           MOVE MIR-DV-UW-CASE-FCN-CD TO WS-FCN-CD.
           IF WS-FCN-VALID
               CONTINUE
           ELSE
      *MSG: FUNCTION CODE MUST BE 'RR', 'RA', 'CC' OR BLANK
               MOVE 'NS06000020'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DV-UW-CASE-FCN-CD  TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
               GO TO 7540-EDIT-FUNCTION-X
           END-IF.

           IF WS-FCN-CLEAR-CASE
               PERFORM  7541-CHECK-FOR-POLICY
                   THRU 7541-CHECK-FOR-POLICY-X
016440*        IF WS-NO-POLICY
016440         IF WS-NO-PENDING
      *MSG: CLIENT NOT INSURED ON ANY POLICIES. CANNOT CLEAR CASE
                   MOVE 'NS06000026'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-DATA-EDITS
                   GO TO 7540-EDIT-FUNCTION-X
               END-IF
           END-IF.

       7540-EDIT-FUNCTION-X.
           EXIT.
      /
      *----------------------
       7541-CHECK-FOR-POLICY.
      *----------------------

           MOVE 'N'                   TO WS-POLICY-IND.
           MOVE SPACES                TO WRL-KEY.
016440*    MOVE 'NEWBUS'              TO WRL-REL-SYS-ID.
016440     MOVE WGLOB-SYS-CTL-ID      TO WRL-REL-SYS-ID.
           MOVE MIR-CLI-ID            TO WRL-CLI-ID.

           MOVE HIGH-VALUES           TO WRL-ENDBR-KEY.
016440*    MOVE 'NEWBUS'              TO WRL-ENDBR-REL-SYS-ID.
016440     MOVE WGLOB-SYS-CTL-ID      TO WRL-ENDBR-REL-SYS-ID.
           MOVE MIR-CLI-ID            TO WRL-ENDBR-CLI-ID.

           PERFORM RL-1000-BROWSE
              THRU RL-1000-BROWSE-X.
           IF WRL-IO-OK
               PERFORM RL-2000-READ-NEXT
                  THRU RL-2000-READ-NEXT-X
           ELSE
               GO TO 7541-CHECK-FOR-POLICY-X
           END-IF.

           PERFORM  7542-CHECK-NEXT-REL
               THRU 7542-CHECK-NEXT-REL-X
               UNTIL WRL-IO-EOF
016440*        OR    WS-POLICY-FOUND.
016440         OR    WS-PENDING.

           PERFORM RL-3000-END-BROWSE
              THRU RL-3000-END-BROWSE-X.

       7541-CHECK-FOR-POLICY-X.
           EXIT.
      /
      *--------------------
       7542-CHECK-NEXT-REL.
      *--------------------

016440* FOR PENDING COVERAGE PROCESSING, NEED TO FIRST RETRIEVE
016440* THE POLICY STATUS FOR AN INSURED CLIENT.


016440*    IF  RRL-REL-TYP-CD  = 'I'
016440*        MOVE 'Y'               TO WS-POLICY-IND
016440*    END-IF.

016440     MOVE 'N'                   TO WS-PENDING-SW.

016440     PERFORM 6130-PROCESS-POLICY
016440        THRU 6130-PROCESS-POLICY-X.

           PERFORM RL-2000-READ-NEXT
              THRU RL-2000-READ-NEXT-X.

       7542-CHECK-NEXT-REL-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************

           IF WS-BUS-FCN-LIST
               PERFORM 9110-BLANK-DISPLAY-LINES
                   THRU 9110-BLANK-DISPLAY-LINES-X
                   VARYING WS-LINE FROM 1 BY 1
                   UNTIL (WS-LINE > WS-NUMBER-OF-DISPLAY-LINES)
           ELSE
               MOVE SPACES            TO MIR-DV-OWN-CLI-NM
               MOVE SPACES            TO MIR-UW-CASE-PRTY-CD
               MOVE SPACES            TO MIR-UW-CASE-REASN-CD
               MOVE SPACES            TO MIR-DV-UW-CASE-USER-ID
               MOVE SPACES            TO MIR-DV-UW-CASE-FCN-CD
           END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *-------------------------
       9110-BLANK-DISPLAY-LINES.
      *-------------------------

      *****************************************************************
      *  SET EACH DISPLAY LINE TO BLANKS
      *****************************************************************

           MOVE SPACES                TO MIR-CLI-ID-T (WS-LINE).
015904*    MOVE SPACES                TO MIR-CLI-GIV-NM-T (WS-LINE).
015904     MOVE SPACES                TO MIR-CLI-INDV-GIV-NM-T
015904            (WS-LINE).
015904*    MOVE SPACES                TO MIR-CLI-SUR-NM-T (WS-LINE).
015904     MOVE SPACES                TO MIR-CLI-INDV-SUR-NM-T
015904            (WS-LINE).
           MOVE SPACES                TO MIR-POL-ID-BASE-T (WS-LINE).
           MOVE SPACES                TO MIR-POL-ID-SFX-T (WS-LINE).
           MOVE SPACES                TO MIR-POL-CSTAT-CD-T (WS-LINE).
           MOVE SPACES                TO MIR-POL-OPTL-CD-T (WS-LINE).
           MOVE SPACES              TO MIR-LINK-POL-ISS-IND-T (WS-LINE).
           MOVE SPACES                TO MIR-SERV-BR-ID-T (WS-LINE).
           MOVE SPACES              TO MIR-PREV-UWG-ACTV-DT-T (WS-LINE).
           MOVE SPACES               TO MIR-UW-CASE-PRTY-CD-T (WS-LINE).
           MOVE SPACES              TO MIR-UW-CASE-REASN-CD-T (WS-LINE).

       9110-BLANK-DISPLAY-LINES-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************

           MOVE RUWWK-USER-ID         TO MIR-USER-ID.
           MOVE RUWWK-CLI-ID          TO MIR-CLI-ID.
           MOVE SPACES                TO MIR-POL-ID.
           MOVE RUWWK-UW-CASE-PRTY-CD TO MIR-UW-CASE-PRTY-CD.
           MOVE RUWWK-UW-CASE-REASN-CD TO MIR-UW-CASE-REASN-CD.
           MOVE SPACES                TO MIR-DV-UW-CASE-USER-ID.
           MOVE SPACES                TO MIR-DV-UW-CASE-FCN-CD.
           MOVE RUWWK-CLI-ID          TO L2437-CLI-ID.
           PERFORM 2437-1000-OBTAIN-CLI-INFO
              THRU 2437-1000-OBTAIN-CLI-INFO-X.
           IF L2437-RETRN-CLI-NOT-FOUND
      *MSG: UNABLE TO READ BIOP RECORD; @1-KEY FROM WORKLOAD FILE
               MOVE 'NS06000003'      TO WGLOB-MSG-REF-INFO
               MOVE L2437-WCLI-KEY    TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

557698*    MOVE L2437-CLI-GIV-NM       TO L0620-CLI-GIV-NM.
557698*    MOVE L2437-CLI-SUR-NM       TO L0620-CLI-SUR-NM.
           MOVE L2437-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
557698*    MOVE L2437-CLI-CO-NM        TO L0620-CLI-CO-NM .
557698     MOVE L2437-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM.
557698     MOVE L2437-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM.
557698     MOVE L2437-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM.
013578     MOVE L2437-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM.
013578     MOVE L2437-CLI-SFX-NM      TO L0620-CLI-SFX-NM.
           PERFORM 0620-1000-FORMAT-SCREEN-NAME
              THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           IF NOT L0620-RETRN-OK
              MOVE '1'                TO WGLOB-RETURN-CODE
              GO TO 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           MOVE L0620-SCREEN-NAME     TO MIR-DV-OWN-CLI-NM.

           ADD +1 TO WS-LINE.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0220-0000-INIT-PARM-INFO
025970         THRU 0220-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0760-0000-INIT-PARM-INFO
025970         THRU 0760-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1110-0000-INIT-PARM-INFO
025970         THRU 1110-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2222-0000-INIT-PARM-INFO
025970         THRU 2222-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WS-SWITCHES.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TRANS-NAME          TO TRUE.
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-PIC-DATE            TO TRUE.
025970     SET WS-DEFAULT-LINE                TO TRUE.
025970     SET WS-DEFAULT-SUB                 TO TRUE.
025970     SET WS-DEFAULT-CRSR                TO TRUE.
025970     SET WS-DEFAULT-CLINO-CTR           TO TRUE.
025970     SET WS-DEFAULT-NO-OF-DISPLAY-LINES TO TRUE.
025970     SET WS-DEFAULT-DISPLAY-LINES-PLUS1 TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

025970 COPY NCPS1110.
025970 COPY XCPS8090.
       COPY CCPS5400.
018764*COPY CCCL5400.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL5400.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY UWWK
014221                         '$VAR2' BY 'UWWK'.
      /
       COPY CCPS5600.
018764*COPY CCCL5600.
018764 COPY CCPL5600.
      /
016440 COPY CCPS2222.
018764*COPY CCCL2222.
018764 COPY CCPL2222.
016440/
018764*COPY NCCL2437.
025970 COPY NCPS2437.
018764 COPY NCPL2437.
      /
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
       COPY CCPSPGA.
      /
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS                                 *
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
      *****************************************************************
      *  LINKS TO EXTERNAL MODULES
      *****************************************************************
018764*COPY XCCL8090.
018764 COPY XCPL8090.
018764*COPY XCCL0220.
025970 COPY XCPS0220.
018764 COPY XCPL0220.
018764*COPY NCCL0760.
025970 COPY NCPS0760.
018764 COPY NCPL0760.
018764*COPY NCCL1110.
018764 COPY NCPL1110.
025970 COPY CCPS0620.
       COPY CCPL0620.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNEDIT.
      /
       COPY CCPNPOL.
      /
       COPY NCPAUWWK.
      /
       COPY NCPBUWWK.
      /
       COPY NCPCUWWK.
      /
       COPY NCPNUWWK.
      /
       COPY NCPUUWWK.
      /
       COPY NCPXUWWK.
      /
      *****************************************************************
      *  INGENIUM FILE I/O PROCESS MODULES
      *****************************************************************
      /
       COPY CCPBRL.
557756*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM0600                     **
      *****************************************************************
