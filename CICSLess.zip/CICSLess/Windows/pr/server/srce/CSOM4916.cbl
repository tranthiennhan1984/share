      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4916.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4916                                         **
      **  REMARKS:  EDIT TABLE RETRIEVE PROCESS DRIVER FOR INITIAL   **
      **            LOAD OF ALL EDIT TABLE VALUES.                   **
      **                                                             **
      **            THE STREAM FORMAT IS AS FOLLOWS:                 **
      **             KEY SEPARATOR                                   **
      **             COMPANY                                         **
      **             FIELD SEPARATOR                                 **
      **             LANGUAGE                                        **
      **             FIELD SEPARATOR                                 **
      **             TABLE TYPE ID                                   **
      **             DATA SEPARATOR                                  **
      **             DESCRIPTION                                     **
      **             FIELD SEPARATOR                                 **
      **             TABLE VALUE                                     **
      **             RECORD SEPARATOR                                **
      **                                                             **
      **             DESCRIPTION AND TABLE VALUE WILL REPEAT UNTIL   **
      **             ALL MEMBERS OF THE SUBSET ARE INCLUDED.         **
      **                                                             **
      **             THE NEXT TABLE BEGINS AGAIN WITH THE KEY        **
      **             SEPARATOR AND CONTINUES UNTIL THE DATA AREA IS  **
      **             FULL.                                           **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE  DESCRIPTION                                       **
      **                                                             **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019474**  6.3       PATHFINDER 1.3 UPGRADE                           **
019506**  6.3.1     PATHFINDER 2.0 UPGRADE                           **
023212**  6.4       CACHE BUILD INDEX POINTER FIX                    **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4916'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      /
       COPY SQLCA.
018764*COPY XCWLPTR.

      /
025970 01  WS-CONSTANT-AREA.
025970     05  WS-ENGLISH             PIC X(01)  VALUE 'E'.
025970         88  WS-ENGLISH-DEFAULT            VALUE 'E'.
025970
       01  WS-PGM-WORK-AREA.
           05  WS-IDX                 PIC S9(04) BINARY VALUE 0.
           05  WS-TOTAL-RECORD-CNT    PIC S9(04) BINARY VALUE 0.
           05  WS-TOTAL-TABLE-CNT     PIC S9(04) BINARY VALUE 0.
           05  WS-CRNT-TABLE-REC-CNT  PIC S9(04) BINARY VALUE 0.
           05  WS-DISPLAY-X-4.
               10  WS-DISPLAY-9-4     PIC 9(04).
           05  WS-BUS-FCN-ID          PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '4916'.
               88  WS-BUS-FCN-LIST          VALUE '4916'.
           05  WS-STREAM-FULL-IND     PIC X(01).
               88 WS-STREAM-FULL      VALUE 'Y'.
               88 WS-STREAM-NOT-FULL  VALUE 'N'.

           05  WS-RECORD-SEP-IDX      PIC S9(04) BINARY VALUE 0.
           05  WS-TABLE-SEP-IDX       PIC S9(04) BINARY VALUE 0.

025970*    05  WS-ENGLISH             PIC X(01)  VALUE 'E'.

      *  PARAMETER VALUES FOR COMPRESSION UTILITY
           05  WS-TRIM-DATA-LEN       PIC S9(04) BINARY VALUE 0.
           05  WS-NON-TRIM-DATA       PIC X(80).
           05  WS-TRIM-DATA           PIC X(81).
           05  WS-TRIM-DELIMITER      PIC X(1).
               88  WS-TRIM-KEY-SEP    VALUE ''.
               88  WS-TRIM-DATA-SEP   VALUE ''.
               88  WS-TRIM-FIELD-SEP  VALUE ''.
               88  WS-TRIM-RECORD-SEP VALUE ''.

           05  WS-LAST-KEY.
               10  WS-LAST-CO-ID                     PIC X(02).
               10  WS-LAST-ETBL-LANG-CD              PIC X(01).
               10  WS-LAST-ETBL-TYP-ID               PIC X(30).

           05  WS-CURRENT-KEY.
               10  WS-CURRENT-CO-ID                  PIC X(02).
               10  WS-CURRENT-ETBL-LANG-CD           PIC X(01).
               10  WS-CURRENT-ETBL-TYP-ID            PIC X(30).

       COPY CCFREDIT.
       COPY CCFWEDID.

       COPY XCFRXTAB.
       COPY XCFWXTAB.
      /
       LINKAGE SECTION.

CVMQ71 COPY XCWWDFH.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM4916.
      *
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *
      *-------------
       0000-MAINLINE.
      *-------------
      *
026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.
      *
           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.
      *
026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.
      *
       0000-MAINLINE-X.
           EXIT.
      *
      /
      *--------------------
       2000-PROCESS-REQUEST.
      *--------------------
      *
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
025970*    SET MIR-RETRN-OK           TO TRUE.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  3000-PROCESS-LIST
                        THRU 3000-PROCESS-LIST-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST TO TRUE
                    GO TO 2000-PROCESS-REQUEST-X
           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.

      /
      *-----------------
       3000-PROCESS-LIST.
      *-----------------

           MOVE +1                    TO WS-TOTAL-TABLE-CNT.
           MOVE +1                    TO WS-IDX.
           MOVE SPACES                TO MIR-OUTPUT-AREA.
           SET WS-STREAM-NOT-FULL     TO TRUE.
      *  RETRIEVE COMPANY CODES

           MOVE LOW-VALUES            TO WXTAB-KEY.
           MOVE 'COMP'                TO WXTAB-ETBL-TYP-ID.
           IF MIR-CO-ID > SPACES
               MOVE MIR-CO-ID         TO WXTAB-ETBL-VALU-ID
           END-IF.
           MOVE WS-ENGLISH            TO WXTAB-ETBL-LANG-CD.
           MOVE WXTAB-KEY             TO WXTAB-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WXTAB-ENDBR-ETBL-VALU-ID.

           PERFORM  XTAB-1000-BROWSE
               THRU XTAB-1000-BROWSE-X.

           PERFORM  XTAB-2000-READ-NEXT
               THRU XTAB-2000-READ-NEXT-X.

           PERFORM  3100-PROCESS-ONE-COMPANY
               THRU 3100-PROCESS-ONE-COMPANY-X
              UNTIL WXTAB-IO-EOF
                 OR WS-STREAM-FULL.

           PERFORM  XTAB-3000-END-BROWSE
               THRU XTAB-3000-END-BROWSE-X.
019506
019506     MOVE WS-TRIM-DELIMITER
019506       TO MIR-DV-CHAR-DELIM-INFO (WS-RECORD-SEP-IDX:).
019506
019506     IF  WS-CRNT-TABLE-REC-CNT < 1
019506         MOVE WS-TRIM-DELIMITER
019506           TO MIR-DV-CHAR-DELIM-INFO (WS-TABLE-SEP-IDX:)
019506     END-IF.

       3000-PROCESS-LIST-X.
           EXIT.

      *------------------------
       3100-PROCESS-ONE-COMPANY.
      *------------------------

           MOVE RXTAB-ETBL-VALU-ID      TO WGLOB-COMPANY-CODE.
           MOVE RXTAB-ETBL-VALU-ID      TO MIR-CO-ID.

           MOVE LOW-VALUES              TO WEDID-KEY.
           MOVE MIR-CO-ID               TO WEDID-CO-ID.
           MOVE MIR-ETBL-LANG-CD        TO WEDID-ETBL-LANG-CD.
           MOVE MIR-ETBL-TYP-ID         TO WEDID-ETBL-TYP-ID.
           MOVE MIR-ETBL-DESC-TXT       TO WEDID-ETBL-DESC-TXT.
           MOVE MIR-ETBL-VALU-ID        TO WEDID-ETBL-VALU-ID.

           MOVE HIGH-VALUES             TO WEDID-ENDBR-KEY.
           SET  WS-STREAM-NOT-FULL      TO TRUE.

           PERFORM  EDID-1000-TBL-BROWSE
               THRU EDID-1000-TBL-BROWSE-X.

           PERFORM  EDID-2000-TBL-READ-NEXT
               THRU EDID-2000-TBL-READ-NEXT-X.

           IF WEDID-IO-OK
               MOVE WEDID-CO-ID         TO WS-CURRENT-CO-ID
               MOVE WEDID-ETBL-LANG-CD  TO WS-CURRENT-ETBL-LANG-CD
               MOVE WEDID-ETBL-TYP-ID   TO WS-CURRENT-ETBL-TYP-ID
               MOVE WS-CURRENT-KEY      TO WS-LAST-KEY
               PERFORM  3110-NEW-KEY
                   THRU 3110-NEW-KEY-X
               MOVE WS-TOTAL-TABLE-CNT  TO WS-DISPLAY-9-4
019474         MOVE WS-DISPLAY-X-4      TO MIR-DV-TOT-TBL-QTY
           END-IF.

           PERFORM
               UNTIL WEDID-IO-EOF
                  OR WS-STREAM-FULL

               MOVE WEDID-CO-ID         TO WS-CURRENT-CO-ID
               MOVE WEDID-ETBL-LANG-CD  TO WS-CURRENT-ETBL-LANG-CD
               MOVE WEDID-ETBL-TYP-ID   TO WS-CURRENT-ETBL-TYP-ID
               IF WS-CURRENT-KEY NOT = WS-LAST-KEY
                   MOVE WS-CURRENT-KEY  TO WS-LAST-KEY
                   PERFORM  3110-NEW-KEY
                       THRU 3110-NEW-KEY-X
                   IF WS-STREAM-NOT-FULL
                       ADD 1            TO WS-TOTAL-TABLE-CNT
                       MOVE WS-TOTAL-TABLE-CNT TO WS-DISPLAY-9-4
019474                 MOVE WS-DISPLAY-X-4 TO MIR-DV-TOT-TBL-QTY
                   END-IF
               END-IF

               PERFORM  3120-ADD-RECORD
                   THRU 3120-ADD-RECORD-X

               IF  WS-STREAM-NOT-FULL
                   PERFORM  EDID-2000-TBL-READ-NEXT
                       THRU EDID-2000-TBL-READ-NEXT-X
               END-IF

           END-PERFORM.


           IF  NOT WEDID-IO-EOF
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               MOVE REDIT-ETBL-DESC-TXT   TO MIR-ETBL-DESC-TXT
               MOVE REDIT-ETBL-VALU-ID    TO MIR-ETBL-VALU-ID
               MOVE REDIT-ETBL-LANG-CD    TO MIR-ETBL-LANG-CD
               MOVE REDIT-CO-ID           TO MIR-CO-ID
               MOVE REDIT-ETBL-TYP-ID     TO MIR-ETBL-TYP-ID
           END-IF.

           PERFORM  EDID-3000-TBL-END-BROWSE
               THRU EDID-3000-TBL-END-BROWSE-X.

           IF  WS-STREAM-NOT-FULL
               MOVE SPACES                TO RXTAB-ETBL-LANG-CD
               PERFORM  XTAB-2000-READ-NEXT
                   THRU XTAB-2000-READ-NEXT-X
                  UNTIL RXTAB-ETBL-LANG-CD = WS-ENGLISH
                     OR WXTAB-IO-EOF
               MOVE SPACES                TO MIR-CO-ID
               MOVE SPACES                TO MIR-ETBL-LANG-CD
               MOVE SPACES                TO MIR-ETBL-TYP-ID
               MOVE SPACES                TO MIR-ETBL-DESC-TXT
               MOVE SPACES                TO MIR-ETBL-VALU-ID
019506*    ELSE
019506*        IF  WS-CRNT-TABLE-REC-CNT < 1
019506*            MOVE SPACES
019506*                   TO MIR-DV-CHAR-DELIM-INFO (WS-TABLE-SEP-IDX:)
019506*        ELSE
019506*            MOVE SPACES
019506*                   TO MIR-DV-CHAR-DELIM-INFO (WS-RECORD-SEP-IDX:)
019506*        END-IF
           END-IF.

       3100-PROCESS-ONE-COMPANY-X.
           EXIT.

      *------------
       3110-NEW-KEY.
      *------------

           MOVE ZERO                      TO WS-CRNT-TABLE-REC-CNT.
           MOVE WS-IDX                    TO WS-RECORD-SEP-IDX.
           MOVE WS-IDX                    TO WS-TABLE-SEP-IDX.
           SET  WS-TRIM-KEY-SEP           TO TRUE.
           MOVE REDIT-CO-ID               TO WS-NON-TRIM-DATA.
           MOVE LENGTH OF REDIT-CO-ID     TO WS-TRIM-DATA-LEN.
           PERFORM  9000-TRIM
               THRU 9000-TRIM-X.
019474     IF ((WS-IDX + WS-TRIM-DATA-LEN)
019474                               < LENGTH OF MIR-DV-CHAR-DELIM-INFO)
019474         MOVE WS-TRIM-DATA     TO MIR-DV-CHAR-DELIM-INFO (WS-IDX:)
               ADD  WS-TRIM-DATA-LEN      TO WS-IDX
           ELSE
               SET WS-STREAM-FULL         TO TRUE
               GO TO 3110-NEW-KEY-X
           END-IF.

           SET  WS-TRIM-FIELD-SEP         TO TRUE.
           MOVE REDIT-ETBL-LANG-CD        TO WS-NON-TRIM-DATA.
           MOVE LENGTH OF REDIT-ETBL-LANG-CD TO WS-TRIM-DATA-LEN.
           PERFORM  9000-TRIM
               THRU 9000-TRIM-X.
019474     IF ((WS-IDX + WS-TRIM-DATA-LEN)
019474                               < LENGTH OF MIR-DV-CHAR-DELIM-INFO)
019474         MOVE WS-TRIM-DATA     TO MIR-DV-CHAR-DELIM-INFO (WS-IDX:)
               ADD  WS-TRIM-DATA-LEN      TO WS-IDX
           ELSE
               SET WS-STREAM-FULL         TO TRUE
               GO TO 3110-NEW-KEY-X
           END-IF.

           MOVE REDIT-ETBL-TYP-ID         TO WS-NON-TRIM-DATA.
           MOVE LENGTH OF REDIT-ETBL-TYP-ID TO WS-TRIM-DATA-LEN.
           SET  WS-TRIM-FIELD-SEP         TO TRUE.
           PERFORM  9000-TRIM
               THRU 9000-TRIM-X.
019474     IF ((WS-IDX + WS-TRIM-DATA-LEN)
019474                               < LENGTH OF MIR-DV-CHAR-DELIM-INFO)
019474         MOVE WS-TRIM-DATA     TO MIR-DV-CHAR-DELIM-INFO (WS-IDX:)
               ADD  WS-TRIM-DATA-LEN      TO WS-IDX
           ELSE
               SET WS-STREAM-FULL         TO TRUE
               GO TO 3110-NEW-KEY-X
           END-IF.

           SET WS-TRIM-DATA-SEP           TO TRUE.

       3110-NEW-KEY-X.
           EXIT.

      *---------------
       3120-ADD-RECORD.
      *---------------

           MOVE WS-IDX                    TO WS-RECORD-SEP-IDX.
           MOVE REDIT-ETBL-VALU-ID        TO WS-NON-TRIM-DATA.
           MOVE LENGTH OF REDIT-ETBL-VALU-ID TO WS-TRIM-DATA-LEN.
           PERFORM  9000-TRIM
               THRU 9000-TRIM-X.
019474     IF ((WS-IDX + WS-TRIM-DATA-LEN)
019474                               < LENGTH OF MIR-DV-CHAR-DELIM-INFO)
019474         MOVE WS-TRIM-DATA     TO MIR-DV-CHAR-DELIM-INFO (WS-IDX:)
               ADD  WS-TRIM-DATA-LEN      TO WS-IDX
               SET  WS-TRIM-FIELD-SEP     TO TRUE
           ELSE
               SET WS-STREAM-FULL         TO TRUE
               GO TO 3120-ADD-RECORD-X
           END-IF.

           MOVE REDIT-ETBL-DESC-TXT       TO WS-NON-TRIM-DATA.
           MOVE LENGTH OF REDIT-ETBL-DESC-TXT TO WS-TRIM-DATA-LEN.
           PERFORM  9000-TRIM
               THRU 9000-TRIM-X.
019474     IF ((WS-IDX + WS-TRIM-DATA-LEN)
019474                               < LENGTH OF MIR-DV-CHAR-DELIM-INFO)
019474         MOVE WS-TRIM-DATA     TO MIR-DV-CHAR-DELIM-INFO (WS-IDX:)
               ADD  WS-TRIM-DATA-LEN      TO WS-IDX
               SET  WS-TRIM-RECORD-SEP    TO TRUE
           ELSE
               SET WS-STREAM-FULL         TO TRUE
               GO TO 3120-ADD-RECORD-X
           END-IF.

           ADD +1                         TO WS-CRNT-TABLE-REC-CNT.
           ADD +1                         TO WS-TOTAL-RECORD-CNT.
           MOVE WS-TOTAL-RECORD-CNT       TO WS-DISPLAY-9-4.
019474     MOVE WS-DISPLAY-X-4            TO MIR-DV-TOT-REC-QTY.
023212     MOVE WS-IDX                    TO WS-RECORD-SEP-IDX.

       3120-ADD-RECORD-X.
           EXIT.

      *---------
       9000-TRIM.
      *---------

           PERFORM
               VARYING WS-TRIM-DATA-LEN
                  FROM WS-TRIM-DATA-LEN BY -1
                 UNTIL WS-TRIM-DATA-LEN = 1
                    OR WS-NON-TRIM-DATA (WS-TRIM-DATA-LEN:1) NOT = SPACE
018763              CONTINUE
           END-PERFORM.

           MOVE WS-TRIM-DELIMITER         TO WS-TRIM-DATA.
           MOVE WS-NON-TRIM-DATA          TO WS-TRIM-DATA(2:).
           ADD +1                         TO WS-TRIM-DATA-LEN.


       9000-TRIM-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970     SET  WS-ENGLISH-DEFAULT          TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *
      *****************************************************
      * PROCESSING COPYBOOKS                              *
      *****************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      *****************************************************
      * FILE I/O PROCESS MODULES                          *
      *****************************************************
      /
       COPY CCPTEDID.
       COPY XCPBXTAB.
      /
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      ******************************************************************
      *                END OF PROGRAM CSOM4916                         *
      ******************************************************************

