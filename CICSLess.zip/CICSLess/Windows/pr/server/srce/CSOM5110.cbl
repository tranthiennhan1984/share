      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM5110.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5110                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE RETRIEVE FUNCTION     **
      **            FOR THE CLIB TABLE                               **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020478**  6.6       FUTURE DATED TRANSACTION                         **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5110'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-RETRIEVE       VALUE '5110'.
           05  WS-EFF-DT                     PIC X(10).
           05  WS-BNK-ACCT-NUM               PIC 9(03).
           05  WS-BNK-ACCT-NUM-N REDEFINES
               WS-BNK-ACCT-NUM.
               10  WS-BNK-ACCT-NUM-1-2       PIC 9(02).
               10  WS-BNK-ACCT-NUM-3         PIC 9(01).
036742     05  WS-CLI-BNK-GEN-ID             PIC 9(10).

       01  WS-CONSTANT-FIELDS.
           05  WS-TWRK-KEY                   PIC X(04).
               88  WS-TWRK-KEY-DEFAULT       VALUE '5110'.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWLOCK.
036742 COPY XCWWCNST.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRCLI.
       COPY CCFWCLI.

       COPY CCFRCLIB.
       COPY CCFWCLIB.
      /
       COPY CCFRBNKA.
       COPY CCFWBNKA.
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY CCWL2435.
       COPY XCWL8090.
      /
       COPY XCWLDTLK.
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM5110.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------


           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM5110'          TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'        TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                                             TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *-------------
       2000-RETRIEVE.
      *-------------


      * INITIALIZE THE MIR OUTPUT FIELDS

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

      *
      * EDIT INPUT EFFECTIVE DATE
      *
           PERFORM  2100-VALIDATE-EFF-DT
               THRU 2100-VALIDATE-EFF-DT-X.

036742     PERFORM  2200-VALIDATE-GEN-ID
036742         THRU 2200-VALIDATE-GEN-ID-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED     TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           MOVE MIR-CLI-ID       TO  WCLI-CLI-ID.
           PERFORM  CLI-1000-READ-TWRK-TS
               THRU CLI-1000-READ-TWRK-TS-X.
           IF NOT WCLI-IO-OK
      *MSG: CLIENT RECORD (@1) NOT FOUND
               MOVE WCLI-CLI-ID        TO WGLOB-MSG-PARM (1)
               MOVE 'CLI'              TO WGLOB-MSG-PARM (2)
               MOVE 'CS51100002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

      * RETRIEVE CLIENT BANK INFORMATION

           PERFORM  CLIB-1000-READ
               THRU CLIB-1000-READ-X.

           IF  NOT WCLIB-IO-OK
      *MSG: CLIENT BANK RECORD (@1) NOT FOUND
               MOVE WCLIB-KEY                TO WGLOB-MSG-PARM (1)
               MOVE 'CS51100003'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED     TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

      * RETRIEVE CLIENT NAME FROM CLIENT NAME TABLE


           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID                   TO L2435-CLI-ID.
           MOVE WGLOB-PROCESS-DATE           TO L2435-EFF-DT.

           PERFORM  2435-2000-CRNT-CLI-NAME
               THRU 2435-2000-CRNT-CLI-NAME-X.

           IF  NOT L2435-RETRN-OK
      * CLIENT NAME FOR (@1) NOT FOUND
               MOVE L2435-CLI-ID             TO WGLOB-MSG-PARM (1)
               MOVE 'CS51100004'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED     TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

      * RETRIEVE BANK ACCOUNT INFORMATION OF THE CLIENT

           MOVE MIR-BNK-ID                  TO WBNKA-BNK-ID.
           MOVE MIR-BNK-BR-ID               TO WBNKA-BNK-BR-ID.
           MOVE MIR-BNK-ACCT-ID             TO WBNKA-BNK-ACCT-ID.

           PERFORM  BNKA-1000-READ
               THRU BNKA-1000-READ-X.

           IF  NOT WBNKA-IO-OK
      *MSG: BANK ACCOUNT RECORD (@1) DOES NOT EXIST
               MOVE 'CS51100005'            TO WGLOB-MSG-REF-INFO
               MOVE WBNKA-KEY               TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO  2000-RETRIEVE-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X.


       2000-RETRIEVE-X.
           EXIT.

      /
      *--------------------
       2100-VALIDATE-EFF-DT.
      *--------------------

           MOVE MIR-CLI-BNK-ACCT-DT          TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      *MSG : INVALID EFFECTIVE DATE
               MOVE 'CS51100001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2100-VALIDATE-EFF-DT-X
           ELSE
               MOVE L1640-INTERNAL-DATE  TO WS-EFF-DT
           END-IF.

       2100-VALIDATE-EFF-DT-X.
           EXIT.
036742/
036742*--------------------
036742 2200-VALIDATE-GEN-ID.
036742*--------------------
036742
036742     IF  MIR-CLI-BNK-GEN-ID = SPACES
036742         MOVE  ZEROS                   TO WS-CLI-BNK-GEN-ID
036742         GO TO 2200-VALIDATE-GEN-ID-X
036742     END-IF.
036742
036742     SET L0280-SIGN-PERMITTED   TO TRUE.
036742     MOVE 0                     TO L0280-PRECISION.
036742     MOVE LENGTH OF MIR-CLI-BNK-GEN-ID
036742                                TO L0280-INPUT-SIZE.
036742     MOVE L0280-INPUT-SIZE      TO L0280-LENGTH
036742     MOVE MIR-CLI-BNK-GEN-ID    TO L0280-INPUT-DATA.
036742
036742     PERFORM  0280-1000-NUMERIC-EDIT
036742         THRU 0280-1000-NUMERIC-EDIT-X.
036742
036742     IF  NOT L0280-OK
036742     OR  L0280-OUTPUT < ZERO
036742     OR  L0280-OUTPUT > WCNST-MAX-CLI-BNK-GEN-ID-N
036742*MSG: INVALID GEN ID
036742         MOVE 'CS51100006'    TO WGLOB-MSG-REF-INFO
036742         PERFORM  0260-1000-GENERATE-MESSAGE
036742             THRU 0260-1000-GENERATE-MESSAGE-X
036742         GO TO 2200-VALIDATE-GEN-ID-X
036742     ELSE
036742         MOVE L0280-OUTPUT    TO WS-CLI-BNK-GEN-ID
036742     END-IF.
036742
036742 2200-VALIDATE-GEN-ID-X.
036742     EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE MIR-CLI-ID                   TO WCLIB-CLI-ID.
           MOVE MIR-BNK-ID                   TO WCLIB-BNK-ID.
           MOVE MIR-BNK-BR-ID                TO WCLIB-BNK-BR-ID.
           MOVE MIR-BNK-ACCT-ID              TO WCLIB-BNK-ACCT-ID.
           MOVE WS-EFF-DT                    TO WCLIB-CLI-BNK-ACCT-DT.
           MOVE MIR-CLI-BNK-ACCT-TS          TO WCLIB-CLI-BNK-ACCT-TS.
036742     MOVE WS-CLI-BNK-GEN-ID            TO WCLIB-CLI-BNK-GEN-ID.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                       TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9200-MOVE-RECORD-TO-MIR.
      *--------------------------

      * FILL CLIENT BANK INFO.


           MOVE RCLIB-CLI-BNK-ACCT-NUM       TO WS-BNK-ACCT-NUM.
           MOVE WS-BNK-ACCT-NUM-3            TO MIR-CLI-BNK-ACCT-NUM.

           MOVE RCLIB-CLBACHNG-REASN-CD      TO MIR-CLBACHNG-REASN-CD.

           MOVE RCLIB-CLI-BNK-ACCT-CD        TO MIR-CLI-BNK-ACCT-CD.

      * FILL CLIENT NAME

           IF  L2435-CLI-GR-KANJI
               MOVE L2435-CLI-KJ-NM-COMPRESSED
                                             TO MIR-DV-CLI-NM
           ELSE
               MOVE L2435-CLI-NM-COMPRESSED  TO MIR-DV-CLI-NM
           END-IF.

      * FILL BANK ACCOUNT INFORMATION

           MOVE RBNKA-BNK-ACCT-MICR-IND      TO MIR-BNK-ACCT-MICR-IND.
           MOVE RBNKA-BNK-ACCT-HLDR-NM       TO MIR-BNK-ACCT-HLDR-NM.
           MOVE RBNKA-BNK-ACCT-TYP-CD        TO MIR-BNK-ACCT-TYP-CD.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                       TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE           TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-CLIENT             TO TRUE.
           MOVE MIR-CLI-ID                   TO WGLOB-REF-CLIENT-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

           PERFORM  2435-0000-INIT-PARM-INFO
               THRU 2435-0000-INIT-PARM-INFO-X.

028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           INITIALIZE  WLOCK-TWRK-TIMESTAMP-INFO.

           INITIALIZE  WLOCK-TWRK-OTHER-INFO.

           SET  WS-TWRK-KEY-DEFAULT           TO TRUE.

           MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFCCK.
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY CCPPTWTS REPLACING ==:VAR1:== BY CLI
                               '$VAR2' BY 'CLI'.

       COPY XCPPEXIT.

       COPY XCPPINIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPS8090.
       COPY CCPS2435.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL2435.
      /
       COPY XCPL0260.
       COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL0290.
       COPY XCPS1640.
       COPY XCPL1640.
       COPY XCPS0290.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCLIB.
       COPY CCPNCLI.
       COPY CCPUCLI.
       COPY CCPNBNKA.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM CSOM5110                        **
      *****************************************************************
