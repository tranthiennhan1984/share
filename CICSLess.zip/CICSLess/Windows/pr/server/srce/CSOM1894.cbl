      *************************  
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM1894.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM1894                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE AGENT POLICY RELATIONSHIP (AGRP)         **
      **            AND AGENT COVERAGE RELATIONSHIP (AGRC) TABLES    **
      **                                                             **
      **  DOMAIN :  AG                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
028786**  6.7       EXTERNAL AGENCY INTEGRATION - COMPENSATION CALC. **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM1894'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                     PIC X(04).
               88  WS-BUS-FCN-LIST                   VALUE '1894'.
           05  WS-SUB                            PIC S9(04) BINARY.
           05  WS-MAX-LIST-LINES                 PIC S9(04) BINARY.
           05  WS-AGT-REL-LVL-CD                 PIC X(01).
               88  WS-AGT-REL-LVL-NONE               VALUE 'N'.
               88  WS-AGT-REL-LVL-CVG                VALUE 'C'.
               88  WS-AGT-REL-LVL-POL                VALUE 'P'.
               88  WS-AGT-REL-LVL-VALID              VALUE 'C' 'P'.
           05  WS-AGT-REL-IO-STATUS              PIC 9(01).
               88  WS-AGT-REL-IO-OK                  VALUE 0.
               88  WS-AGT-REL-IO-TS-MISMATCH         VALUE 6.   
               88  WS-AGT-REL-IO-NOT-FOUND           VALUE 7.
               88  WS-AGT-REL-IO-EOF                 VALUE 8.
               88  WS-AGT-REL-IO-ERROR               VALUE 9.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWEBLCH.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRAGRC.
       COPY CCFWAGRC.
       
       COPY CCFRAGRP.
       COPY CCFWAGRP.
       
       COPY XCFRDMAD.
       COPY XCFWDMAD.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM1894.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
           PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME         
               THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           SET  MIR-RETRN-OK                  TO TRUE.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM1894'           TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------
       2000-LIST.
      *----------

           MOVE SPACES                     TO MIR-OUTPUT-AREA.

           IF  MIR-AGT-ID = SPACES
           OR  MIR-AGT-ID = EBLCH-BLANK-FIELD-CHAR
      *MSG:  AGENT ID CANNOT BE BLANK. RE-ENTER.
               MOVE 'CS18940001'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR      TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED   TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           EVALUATE TRUE
           
               WHEN WS-AGT-REL-LVL-POL
                    PERFORM  AGRP-1000-BROWSE
                        THRU AGRP-1000-BROWSE-X
                    PERFORM  AGRP-2000-READ-NEXT
                        THRU AGRP-2000-READ-NEXT-X
                    IF  NOT WAGRP-IO-OK
                        PERFORM  AGRP-3000-END-BROWSE
                            THRU AGRP-3000-END-BROWSE-X
      *MSG:  NO RECORDS FOUND TO DISPLAY.
                        MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
                        PERFORM  0260-1000-GENERATE-MESSAGE
                            THRU 0260-1000-GENERATE-MESSAGE-X
                        SET MIR-RETRN-RQST-FAILED 
                                           TO TRUE
                        GO TO 2000-LIST-X
                    END-IF
                    MOVE WAGRP-IO-STATUS   TO WS-AGT-REL-IO-STATUS
               
               WHEN WS-AGT-REL-LVL-CVG
                    PERFORM  AGRC-1000-BROWSE
                        THRU AGRC-1000-BROWSE-X
                    PERFORM  AGRC-2000-READ-NEXT
                        THRU AGRC-2000-READ-NEXT-X
                    IF  NOT WAGRC-IO-OK
                        PERFORM  AGRC-3000-END-BROWSE
                            THRU AGRC-3000-END-BROWSE-X
      *MSG:  NO RECORDS FOUND TO DISPLAY.
                        MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
                        PERFORM  0260-1000-GENERATE-MESSAGE
                            THRU 0260-1000-GENERATE-MESSAGE-X
                        SET MIR-RETRN-RQST-FAILED 
                                           TO TRUE
                        GO TO 2000-LIST-X
                    END-IF
                    MOVE WAGRC-IO-STATUS   TO WS-AGT-REL-IO-STATUS
                    
           END-EVALUATE.

      *  SET THE NUMBER OF LIST LINES USING MIR FIELD OCCURENCES

           COMPUTE WS-MAX-LIST-LINES
                 = LENGTH OF MIR-POL-ID-BASE-G
                 / LENGTH OF MIR-POL-ID-BASE-T (1).

           PERFORM  2010-BUILD-LIST-SCREEN
               THRU 2010-BUILD-LIST-SCREEN-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      NOT WS-AGT-REL-IO-OK

           IF  WS-AGT-REL-IO-EOF
      *MSG:  END OF LIST
               MOVE 'XS00000015'              TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS     TO TRUE
      *MSG:  TO VIEW MORE DATA, SELECT 'MORE'.
               MOVE 'XS00000014'              TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WS-AGT-REL-LVL-POL
                   MOVE RAGRP-AGT-ID          TO MIR-AGT-ID
                   MOVE RAGRP-POL-ID          TO MIR-POL-ID
                   MOVE RAGRP-AGT-PREL-TYP-CD TO MIR-AGT-PREL-TYP-CD
               ELSE
                   MOVE RAGRC-AGT-ID          TO MIR-AGT-ID
                   MOVE RAGRC-POL-ID          TO MIR-POL-ID
                   MOVE RAGRC-CVG-NUM         TO MIR-CVG-NUM
                   MOVE RAGRC-AGT-CREL-TYP-CD TO MIR-AGT-CREL-TYP-CD
               END-IF
           END-IF.

           IF  WS-AGT-REL-LVL-POL
               PERFORM  AGRP-3000-END-BROWSE
                   THRU AGRP-3000-END-BROWSE-X
           ELSE
               PERFORM  AGRC-3000-END-BROWSE
                   THRU AGRC-3000-END-BROWSE-X
           END-IF.

       2000-LIST-X.
           EXIT.
      /
      *-----------------------
       2010-BUILD-LIST-SCREEN.
      *-----------------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           IF  WS-AGT-REL-LVL-POL
               PERFORM  AGRP-2000-READ-NEXT
                   THRU AGRP-2000-READ-NEXT-X
               MOVE WAGRP-IO-STATUS          TO WS-AGT-REL-IO-STATUS
           ELSE
               PERFORM  AGRC-2000-READ-NEXT
                   THRU AGRC-2000-READ-NEXT-X
               MOVE WAGRC-IO-STATUS          TO WS-AGT-REL-IO-STATUS
           END-IF.

       2010-BUILD-LIST-SCREEN-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           IF  MIR-DV-AGT-REL-LVL-CD = SPACES
           OR  MIR-DV-AGT-REL-LVL-CD = EBLCH-BLANK-FIELD-CHAR
      *MSG:  AGENT/POLICY OR AGENT/COVERAGE RELATIONSHIP LEVEL MUST BE
      *      SELECTED.
               MOVE 'CS18940002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-BUILD-KEYS-X
           END-IF.

           MOVE MIR-DV-AGT-REL-LVL-CD  TO WS-AGT-REL-LVL-CD.
           
           IF  NOT WS-AGT-REL-LVL-VALID
      *MSG:  INVALID AGENT RELATIONSHIP LEVEL SELECTED.
               MOVE 'CS18940003'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-BUILD-KEYS-X
           END-IF.
           
           IF  WS-AGT-REL-LVL-POL
               PERFORM  7100-BUILD-AGT-POL-REL-KEYS
                   THRU 7100-BUILD-AGT-POL-REL-KEYS-X
           ELSE
               PERFORM  7200-BUILD-AGT-CVG-REL-KEYS
                   THRU 7200-BUILD-AGT-CVG-REL-KEYS-X
           END-IF.
           
       7000-BUILD-KEYS-X.
           EXIT.
      /
      *----------------------------
       7100-BUILD-AGT-POL-REL-KEYS.
      *----------------------------
       
           MOVE LOW-VALUES               TO WAGRP-KEY.
           MOVE MIR-AGT-ID               TO WAGRP-AGT-ID.
           MOVE HIGH-VALUES              TO WAGRP-ENDBR-KEY.
           MOVE MIR-AGT-ID               TO WAGRP-ENDBR-AGT-ID.

           IF  MIR-POL-ID = SPACES
           OR  MIR-POL-ID = EBLCH-BLANK-FIELD-CHAR
               GO TO 7100-BUILD-AGT-POL-REL-KEYS-X
           ELSE
               MOVE MIR-POL-ID           TO WAGRP-POL-ID
           END-IF.

           IF  MIR-AGT-PREL-TYP-CD = SPACES
           OR  MIR-AGT-PREL-TYP-CD = EBLCH-BLANK-FIELD-CHAR
               GO TO 7100-BUILD-AGT-POL-REL-KEYS-X
           ELSE
      * RELATIONSHIP TYPE IS A HIDDEN VALUE FOR SCROLLING PURPOSES.
      * IT IS THEREFORE NOT USED FOR THE ENDBROWSE KEY
               MOVE MIR-AGT-PREL-TYP-CD  TO WAGRP-AGT-PREL-TYP-CD
           END-IF.

       7100-BUILD-AGT-POL-REL-KEYS-X.
           EXIT.
      /
      *----------------------------
       7200-BUILD-AGT-CVG-REL-KEYS.
      *----------------------------
       
           MOVE LOW-VALUES               TO WAGRC-KEY.
           MOVE MIR-AGT-ID               TO WAGRC-AGT-ID.
           MOVE HIGH-VALUES              TO WAGRC-ENDBR-KEY.
           MOVE MIR-AGT-ID               TO WAGRC-ENDBR-AGT-ID.

           IF  MIR-POL-ID = SPACES
           OR  MIR-POL-ID = EBLCH-BLANK-FIELD-CHAR
               GO TO 7200-BUILD-AGT-CVG-REL-KEYS-X
           ELSE
               MOVE MIR-POL-ID           TO WAGRC-POL-ID
           END-IF.

           IF  MIR-CVG-NUM = SPACES
           OR  MIR-CVG-NUM = EBLCH-BLANK-FIELD-CHAR
               GO TO 7200-BUILD-AGT-CVG-REL-KEYS-X
           ELSE
      * COVERAGE NUMBER IS A HIDDEN VALUE FOR SCROLLING PURPOSES
      * IT IS THEREFORE NOT USED FOR THE ENDBROWSE KEY
               MOVE MIR-CVG-NUM          TO WAGRC-CVG-NUM
           END-IF.

           IF  MIR-AGT-CREL-TYP-CD = SPACES
           OR  MIR-AGT-CREL-TYP-CD = EBLCH-BLANK-FIELD-CHAR
               GO TO 7200-BUILD-AGT-CVG-REL-KEYS-X
           ELSE
      * RELATIONSHIP TYPE IS A HIDDEN VALUE FOR SCROLLING PURPOSES.
      * IT IS THEREFORE NOT USED FOR THE ENDBROWSE KEY
               MOVE MIR-AGT-CREL-TYP-CD  TO WAGRC-AGT-CREL-TYP-CD
           END-IF.

       7200-BUILD-AGT-CVG-REL-KEYS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           IF  WS-AGT-REL-LVL-POL
               MOVE RAGRP-POL-ID-BASE  TO MIR-POL-ID-BASE-T (WS-SUB)
               MOVE RAGRP-POL-ID-SFX   TO MIR-POL-ID-SFX-T (WS-SUB)
               MOVE SPACES             TO MIR-CVG-NUM-T (WS-SUB)
               MOVE RAGRP-AGT-PREL-TYP-CD 
                                       TO MIR-AGT-PREL-TYP-CD-T (WS-SUB)
           ELSE
               MOVE RAGRC-POL-ID-BASE  TO MIR-POL-ID-BASE-T (WS-SUB)
               MOVE RAGRC-POL-ID-SFX   TO MIR-POL-ID-SFX-T (WS-SUB)
               MOVE RAGRC-CVG-NUM      TO MIR-CVG-NUM-T (WS-SUB)
               MOVE RAGRC-AGT-CREL-TYP-CD 
                                       TO MIR-AGT-CREL-TYP-CD-T (WS-SUB)
           END-IF.

      * GET AGENT RELATIONSHIP DESCRIPTION
      
           IF  WS-AGT-REL-LVL-POL
               MOVE MIR-AGT-PREL-TYP-CD-T (WS-SUB)
                                         TO WDMAD-DM-AV-CD
               MOVE 'AGT-PREL-TYP-CD'    TO WDMAD-DM-AV-TBL-CD
           ELSE
               MOVE MIR-AGT-CREL-TYP-CD-T (WS-SUB)
                                         TO WDMAD-DM-AV-CD
               MOVE 'AGT-CREL-TYP-CD'    TO WDMAD-DM-AV-TBL-CD
           END-IF.
           
           MOVE WGLOB-USER-LANG          TO WDMAD-DM-AV-DESC-LANG-CD.

           PERFORM  DMAD-1000-READ
               THRU DMAD-1000-READ-X.

           IF  WDMAD-IO-OK
               MOVE RDMAD-DM-AV-DESC-TXT TO MIR-REL-DESC-TXT-T (WS-SUB)
           ELSE
      *MSG:  UNKNOWN
               MOVE 'XS00000223'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-2000-GET-MESSAGE
                   THRU 0260-2000-GET-MESSAGE-X
               MOVE WGLOB-MSG-TXT      TO MIR-REL-DESC-TXT-T (WS-SUB)
           END-IF.

           IF  WS-AGT-REL-LVL-POL
               MOVE RAGRP-PREV-UPDT-TS TO L1640-INTERNAL-DATE
           ELSE
               MOVE RAGRC-PREV-UPDT-TS TO L1640-INTERNAL-DATE
           END-IF.
           
           PERFORM 1640-8000-INTERNAL-TO-MIR
              THRU 1640-8000-INTERNAL-TO-MIR-X.
               
           MOVE L1640-EXTERNAL-DATE  TO MIR-DV-PREV-UPDT-DT-T (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
           PERFORM  TIMR-0000-INIT-PARM-INFO    
               THRU TIMR-0000-INIT-PARM-INFO-X.
               
           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.
    
           INITIALIZE WS-WORKING-STORAGE.
           
           SET  WS-AGT-REL-LVL-NONE        TO TRUE.
           SET  WS-AGT-REL-IO-ERROR        TO TRUE.
           MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
           
       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
       COPY XCPSTIMR.
       COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
       
       COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBAGRC.
       COPY CCPBAGRP.
       
       COPY XCPNDMAD.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM1894                      *
      *****************************************************************
