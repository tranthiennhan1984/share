      *------------------------
       IDENTIFICATION DIVISION.
      *------------------------

       PROGRAM-ID. CSOM5224.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5224                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE CLCR TABLE                               **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016395**  6.2       NEW                                              **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *---------------------
       ENVIRONMENT DIVISION.
      *---------------------

      *--------------
       DATA DIVISION.
      *--------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5224'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-DETAILS                 PIC S9(02).
025970         88  WS-MAX-DETAILS-DEFAULT     VALUE +50.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                  PIC X(04).
               88  WS-BUS-FCN-LIST            VALUE '5224'.
           05  WS-IF-VALIDATE-OK              PIC X(01).
               88  WS-VALIDATE-OK             VALUE 'Y'.
               88  WS-VALIDATE-FAILED         VALUE 'N'.
           05  WS-IF-CLIENT-HAS-ANY-POLICIES  PIC X(01).
               88  WS-CLIENT-POLICIES-YES     VALUE 'Y'.
               88  WS-CLIENT-POLICIES-NO      VALUE 'N'.
           05  WS-POLICY-SWITCH               PIC X(01).
               88  WS-POLICIES-FOUND          VALUE 'Y'.
               88  WS-NO-POLICIES-FOUND       VALUE 'N'.
025970*    05  WS-MAX-DETAILS                 PIC S9(02) VALUE 50.
           05  WS-CLI-CRC-ACCT                PIC  9(01).
           05  I                              PIC 9(04).
           05  WS-POL-ID.
               10 WS-POL-ID-BASE              PIC X(09).
               10 WS-POL-ID-SFX               PIC X(01).
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
       COPY CCWL0068.
       COPY XCWL0290.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWCLCR.
       COPY CCFRCLCR.
       COPY CCFWCRCD.
       COPY CCFRCRCD.
       COPY CCFRRL.
       COPY CCFWRL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
       COPY XCWLDTLK.
       COPY XCWL1640.
018764*COPY XCWLPTR.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      *
       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM5224.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM5224'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2100-GET-CRCD-DATA
               THRU 2100-GET-CRCD-DATA-X.

           IF  WS-VALIDATE-FAILED
               GO TO 2000-LIST-X
           END-IF.

           SET WS-CLIENT-POLICIES-NO TO TRUE.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  CLCR-1000-BROWSE
               THRU CLCR-1000-BROWSE-X.

           PERFORM  CLCR-2000-READ-NEXT
               THRU CLCR-2000-READ-NEXT-X.

           IF  WCLCR-IO-EOF
               PERFORM  CLCR-3000-END-BROWSE
                   THRU CLCR-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           MOVE 0 TO I.
           PERFORM  2010-BROWSE-CLCR
               THRU 2010-BROWSE-CLCR-X
               UNTIL I > WS-MAX-DETAILS
               OR WCLCR-IO-EOF.

           IF  WCLCR-IO-EOF
               MOVE 'XS00000015' TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
               MOVE 'XS00000014' TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  CLCR-3000-END-BROWSE
               THRU CLCR-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.
      /
      *-----------------
       2010-BROWSE-CLCR.
      *-----------------

           IF  RCLCR-CLI-CRC-NUM NOT NUMERIC
               MOVE ZEROES              TO WS-CLI-CRC-ACCT
           ELSE
               MOVE RCLCR-CLI-CRC-NUM   TO WS-CLI-CRC-ACCT
           END-IF.

      ***** FIRST BROWSE RELA TO LOCATE POLICIES WHICH MIGHT BE RELATED
      ***** TO THIS CREDIT CARD.

           SET WS-CLIENT-POLICIES-NO TO TRUE.
           MOVE LOW-VALUES           TO WRL-KEY.
           MOVE WGLOB-SYS-CTL-ID     TO WRL-REL-SYS-ID.
           MOVE RCLCR-CLI-ID         TO WRL-CLI-ID.
           MOVE WRL-KEY              TO WRL-ENDBR-KEY.
           MOVE HIGH-VALUES          TO WRL-ENDBR-REL-SYS-ID.
           MOVE HIGH-VALUES          TO WRL-ENDBR-REL-SYS-REF-ID.
           MOVE HIGH-VALUES          TO WRL-ENDBR-REL-TYP-CD.

           PERFORM  RL-1000-BROWSE
               THRU RL-1000-BROWSE-X.
           IF  WRL-IO-OK
               PERFORM  RL-2000-READ-NEXT
                   THRU RL-2000-READ-NEXT-X
               IF  NOT WRL-IO-OK
                   PERFORM  RL-3000-END-BROWSE
                       THRU RL-3000-END-BROWSE-X
               ELSE
                   PERFORM  2200-SEARCH-POLICIES
                       THRU 2200-SEARCH-POLICIES-X
                       UNTIL WRL-IO-EOF
                       OR    I > WS-MAX-DETAILS
                   PERFORM  RL-3000-END-BROWSE
                       THRU RL-3000-END-BROWSE-X
               END-IF
           END-IF.

           IF  I > WS-MAX-DETAILS
               GO TO 2010-BROWSE-CLCR-X
           END-IF.

           IF  WS-CLIENT-POLICIES-NO
               ADD 1 TO I
               IF  I > WS-MAX-DETAILS
                   GO TO 2010-BROWSE-CLCR-X
               ELSE
                   MOVE RCLCR-CLI-ID    TO MIR-CLI-ID-T (I)
                   MOVE WS-CLI-CRC-ACCT TO MIR-CLI-CRC-NUM-T (I)
               END-IF
           END-IF.

           PERFORM  CLCR-2000-READ-NEXT
               THRU CLCR-2000-READ-NEXT-X.

       2010-BROWSE-CLCR-X.
           EXIT.
      /
      *-------------------
       2100-GET-CRCD-DATA.
      *-------------------

           MOVE LOW-VALUES             TO WCRCD-KEY.
           MOVE MIR-CRC-TYP-CD         TO WCRCD-CRC-TYP-CD.
           MOVE MIR-CRC-ID             TO WCRCD-CRC-ID.

           PERFORM  CRCD-1000-READ
               THRU CRCD-1000-READ-X.

           IF  WCRCD-IO-OK
               CONTINUE
           ELSE
               MOVE 'N'                TO WS-IF-VALIDATE-OK
      *MSG:CREDIT CARD RECORD NOT FOUND IN CRCD FILE
               MOVE 'CS52240001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2100-GET-CRCD-DATA-X
           END-IF.

           IF  RCRCD-CRC-XPRY-YR NOT = ZERO
020874*        MOVE RCRCD-CRC-XPRY-YR         TO L0290-INPUT-NUMBER
020874         MOVE RCRCD-CRC-XPRY-YR         TO L0290-INPUT-V00
               SET L0290-SIGN-SUPPRESS        TO TRUE
               SET L0290-SIGN-FLOAT           TO TRUE
               MOVE 0                         TO L0290-PRECISION
               MOVE LENGTH OF MIR-CRC-XPRY-YR TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
              MOVE L0290-OUTPUT-DATA         TO MIR-CRC-XPRY-YR
           END-IF.

           IF  RCRCD-CRC-XPRY-MO NOT = ZERO
020874*        MOVE RCRCD-CRC-XPRY-MO         TO L0290-INPUT-NUMBER
020874         MOVE RCRCD-CRC-XPRY-MO         TO L0290-INPUT-V00
               SET L0290-SIGN-SUPPRESS        TO TRUE
               SET L0290-SIGN-FLOAT           TO TRUE
               MOVE 0                         TO L0290-PRECISION
               MOVE LENGTH OF MIR-CRC-XPRY-MO TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA         TO MIR-CRC-XPRY-MO
           END-IF.

           MOVE RCRCD-CRC-HLDR-NM                 TO MIR-CRC-HLDR-NM.

       2100-GET-CRCD-DATA-X.
           EXIT.
      /
      *---------------------
       2200-SEARCH-POLICIES.
      *---------------------

           SET WS-NO-POLICIES-FOUND        TO TRUE.

           IF  RRL-REL-SYS-ID = WGLOB-SYS-CTL-ID
               PERFORM  2210-CHECK-POLC-POL
                   THRU 2210-CHECK-POLC-POL-X
           END-IF.

           IF  WS-POLICIES-FOUND
               ADD 1 TO I
               IF I > WS-MAX-DETAILS
                  GO TO 2200-SEARCH-POLICIES-X
               ELSE
                  PERFORM  2220-DISPLAY-POLICY-INFO
                      THRU 2220-DISPLAY-POLICY-INFO-X
               END-IF
           END-IF.

           PERFORM  RL-2000-READ-NEXT
               THRU RL-2000-READ-NEXT-X.

       2200-SEARCH-POLICIES-X.
           EXIT.
      /
      *--------------------
       2210-CHECK-POLC-POL.
      *--------------------

      ************************************************************
      ****** IF IT IS NOT A CREDIT CARD PAYOR RELATIONSHIP, EXIT.
      ************************************************************

           IF  NOT RRL-REL-TYP-PAYOR
               GO TO 2210-CHECK-POLC-POL-X
           END-IF.

      *
      ** IF THE POLICY IS NOT USING THIS CREDIT CARD ACCOUNT, EXIT
      *

           PERFORM  0068-1000-BUILD-PARM-INFO
               THRU 0068-1000-BUILD-PARM-INFO-X.

           MOVE RRL-CLI-ID              TO L0068-CLI-ID.
           MOVE RRL-REL-SYS-REF-POL-ID  TO L0068-POL-ID.
           MOVE WS-CLI-CRC-ACCT         TO L0068-POL-CLI-REL-SUB-CD.

           PERFORM  0068-1000-FIND-POL-USING-BNK
               THRU 0068-1000-FIND-POL-USING-BNK-X.

           IF  L0068-RETRN-OK
               CONTINUE
           ELSE
               GO TO 2210-CHECK-POLC-POL-X
           END-IF.

           IF  L0068-POL-BILL-TYP-CRC
               CONTINUE
           ELSE
               GO TO 2210-CHECK-POLC-POL-X
           END-IF.

           SET WS-POLICIES-FOUND         TO TRUE.

       2210-CHECK-POLC-POL-X.
           EXIT.
      /
      *-------------------------
       2220-DISPLAY-POLICY-INFO.
      *-------------------------

      ****** WHETHER SCROLLING FORWARD OR BACKWARD, SHOW THE LINES ON
      ****** THE SCREEN IN THE ORDER THEY ARE READ.

           SET WS-CLIENT-POLICIES-YES    TO TRUE.

           MOVE L0068-CLI-ID             TO MIR-CLI-ID-T (I).
           MOVE L0068-POL-ID             TO WS-POL-ID.
           MOVE WS-POL-ID-BASE           TO MIR-POL-ID-BASE-T (I).
           MOVE WS-POL-ID-SFX            TO MIR-POL-ID-SFX-T (I).
           MOVE L0068-POL-CLI-REL-SUB-CD TO MIR-CLI-CRC-NUM-T (I).
           MOVE L0068-POL-CSTAT-CD       TO MIR-POL-CSTAT-CD-T (I).
           MOVE L0068-POL-PD-TO-DT-NUM   TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO MIR-POL-PD-TO-DT-NUM-T (I).
           MOVE L0068-POL-PMT-DRW-DY     TO MIR-POL-PMT-DRW-DY-T (I).
018763*    IF  L0068-POL-FPUL
018763     IF L0068-POL-PREM-NTCNTRCT-ADDL
018763     OR L0068-POL-PREM-TCNTRCT-ADDL
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             (L0068-POL-MPREM-AMT + L0068-POL-SNDRY-AMT) * 100
020874         COMPUTE L0290-INPUT-V02 =
020874              (L0068-POL-MPREM-AMT + L0068-POL-SNDRY-AMT)
           ELSE
018763*        IF (L0068-POL-INS-TYP-FLEXIBLE
018763*        OR  L0068-POL-INS-TYP-ANNUITY
018763*        OR  L0068-POL-INS-TYP-SEG-FUND
018763*        OR  L0068-POL-INS-TYP-RRIF
018763*        OR  L0068-POL-INS-TYP-ISWL)
018763         IF L0068-POL-PREM-NTRADL-FLEX
020874*            COMPUTE L0290-INPUT-NUMBER =
020874*                    L0068-POL-SNDRY-AMT * 100
020874             MOVE L0068-POL-SNDRY-AMT TO L0290-INPUT-V02
               ELSE
020874*            COMPUTE L0290-INPUT-NUMBER =
020874*                    L0068-POL-MPREM-AMT  * 100
020874             MOVE L0068-POL-MPREM-AMT TO L0290-INPUT-V02
               END-IF
           END-IF.

           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-MPREM-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X.
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-POL-MPREM-AMT-T (I).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*             L0068-POL-LOAN-REPAY-AMT * 100.
020874     MOVE L0068-POL-LOAN-REPAY-AMT TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-LOAN-REPAY-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X.
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-POL-LOAN-REPAY-AMT-T (I).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            L0068-POL-PREM-SUSP-AMT  * 100.
020874     MOVE L0068-POL-PREM-SUSP-AMT TO L0290-INPUT-V02.
           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-PREM-SUSP-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY    TO TRUE.
           SET  L0290-SIGN-FLOAT      TO TRUE.
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X.
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-POL-PREM-SUSP-AMT-T (I).

       2220-DISPLAY-POLICY-INFO-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WCLCR-KEY.
           MOVE MIR-CRC-TYP-CD         TO WCLCR-CRC-TYP-CD.
           MOVE MIR-CRC-ID             TO WCLCR-CRC-ID.
           MOVE WCLCR-KEY              TO WCLCR-ENDBR-KEY.
           MOVE HIGH-VALUES            TO WCLCR-ENDBR-CLI-ID.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                 TO MIR-CRC-XPRY-YR.
           MOVE SPACES                 TO MIR-CRC-XPRY-MO.
           MOVE SPACES                 TO MIR-CRC-HLDR-NM.
           MOVE SPACES                 TO MIR-CLI-ID-G.
           MOVE SPACES                 TO MIR-CLI-CRC-NUM-G.
           MOVE SPACES                 TO MIR-POL-PMT-DRW-DY-G.
           MOVE SPACES                 TO MIR-POL-PD-TO-DT-NUM-G.
           MOVE SPACES                 TO MIR-POL-ID-BASE-G.
           MOVE SPACES                 TO MIR-POL-ID-SFX-G.
           MOVE SPACES                 TO MIR-POL-CSTAT-CD-G.
           MOVE SPACES                 TO MIR-POL-MPREM-AMT-G.
           MOVE SPACES                 TO MIR-POL-LOAN-REPAY-AMT-G.
           MOVE SPACES                 TO MIR-POL-PREM-SUSP-AMT-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970     PERFORM  0068-0000-INIT-PARM-INFO
025970         THRU 0068-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
023514     CONTINUE.
025970*    CONTINUE.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-MAX-DETAILS-DEFAULT  TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY CCPS0068.
018764*COPY CCCL0068.
018764 COPY CCPL0068.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
       COPY XCPL0290.
       COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCRCD.
       COPY CCPBCLCR.
       COPY CCPBRL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM5224                      *
      *****************************************************************
