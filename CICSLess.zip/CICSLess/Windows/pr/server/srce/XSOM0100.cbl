      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSOM0100.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  XSOM0100                                         **
      **  REMARKS:  THIS MODULE ALLOWS 'BROWSE', 'INQUIRE',          **
      **            'MAINTAIN', AND 'DELETE' ON THE USEC TABLE.      **
      **            THE USER COUNT ON THE USCL RECORDS IS MAINTAINED **
      **            AS THE USER IS ADDED TO OR REMOVED FROM THE      **
      **            SECURITY CLASSES.                                **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CHANGE TO STANDARD                               **
557698**  5.5       CHANGES TO SUPPORT MIX-CASE                      **
557708**  5.5       NEW CICS ABEND PROCESSING                        **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTIING                    **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSOM0100'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +10  COMP.
025970*016548     05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +10
025970*016548                                      BINARY.
           05  WS-USCL-COUNT-FLAG           PIC X(01).
               88  WS-USCL-COUNT-UPDATED               VALUE 'Y'.

           05  WS-BUS-FCN-ID            PIC X(04).
               88  WS-BUS-FCN-RETRIEVE  VALUE '1910'.
               88  WS-BUS-FCN-CREATE    VALUE '1911'.
               88  WS-BUS-FCN-UPDATE    VALUE '1912'.
               88  WS-BUS-FCN-DELETE    VALUE '1913'.
               88  WS-BUS-FCN-LIST      VALUE '1914'.
025970*    05  WS-TERK-KEY                  PIC X(04) VALUE '1910'.
           05  WS-HOLD-PASSWORD.
               10  WS-PASSW-CHAR  OCCURS 8  PIC X(01).
016548*    05  WS-PASSW-LENGTH              PIC S9(4)  COMP.
016548     05  WS-PASSW-LENGTH              PIC S9(4)  BINARY.
016548*    05  WS-PASSW-SUB                 PIC S9(4)  COMP.
016548     05  WS-PASSW-SUB                 PIC S9(4)  BINARY.

025970 01  WS-CONSTANTS.
025970     05  WS-MAX-BROWSE-LINES             PIC S9(4) BINARY.
025970         88  WS-MAX-BROWSE-LINES-DEFAULT VALUE +10.

025970     05  WS-TERK-KEY                  PIC X(04).
025970         88  WS-TERK-KEY-DEFAULT      VALUE '1910'.
      /
       COPY XCWEBLCH.
016537*COPY XCWWWKDT.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
       COPY XCFWUSEC.
       COPY XCFRUSEC.
      /
       COPY XCFWUSCL.
       COPY XCFRUSCL.
      /
       COPY XCFWPRTR.
       COPY XCFRPRTR.
      /
       COPY XCFWXTAB.
       COPY XCFRXTAB.
      /
014221 COPY CCWWLOCK.
      /
       COPY XCWWPASS.
      /
016537*COPY XCWW0005.
557698 COPY XCWL0005.
      /
       COPY XCWL0280.
      /
       COPY XCWL0290.
014221 COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      /
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY XCWM0100.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM ABND-1000-HANDLE-ABEND
026070*       THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM INIT-1000-INITIALIZE
              THRU INIT-1000-INITIALIZE-X.

           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X.

           PERFORM EXIT-1000-FINALIZE
              THRU EXIT-1000-FINALIZE-X.


026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

025970*     SET  MIR-RETRN-OK       TO TRUE.
025970*     MOVE MIR-BUS-FCN-ID     TO WS-BUS-FCN-ID.
025970*

008455     PERFORM 0290-1000-BUILD-PARM-INFO
008455        THRU 0290-1000-BUILD-PARM-INFO-X.
           PERFORM 9300-SETUP-MSIN-REFERENCE
              THRU 9300-SETUP-MSIN-REFERENCE-X.


      *    PROCESS SCREEN FUNCTIONS
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2100-PROCESS-RETRIEVE
                        THRU 2100-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2500-PROCESS-LIST
                        THRU 2500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2200-PROCESS-CREATE
                        THRU 2200-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2300-PROCESS-UPDATE
                        THRU 2300-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  2400-PROCESS-DELETE
                        THRU 2400-PROCESS-DELETE-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.


       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *---------------------
       2100-PROCESS-RETRIEVE.
      *---------------------

           MOVE MIR-USER-ID           TO WUSEC-USER-ID.
014221*    PERFORM USEC-1000-READ
014221*       THRU USEC-1000-READ-X.

014221     PERFORM USEC-1000-READ-TWRK-TS
014221        THRU USEC-1000-READ-TWRK-TS-X.

           IF WUSEC-IO-OK
               PERFORM 9200-MOVE-RECORD-TO-SCREEN
                  THRU 9200-MOVE-RECORD-TO-SCREEN-X

           ELSE
               PERFORM 9100-BLANK-DATA-FIELDS
                  THRU 9100-BLANK-DATA-FIELDS-X

               MOVE WUSEC-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2100-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *--------------------
       2200-PROCESS-CREATE.
      *--------------------

           MOVE MIR-USER-ID           TO WUSEC-USER-ID.
           PERFORM USEC-1000-READ
              THRU USEC-1000-READ-X.

           IF WUSEC-IO-OK
               PERFORM 9200-MOVE-RECORD-TO-SCREEN
                  THRU 9200-MOVE-RECORD-TO-SCREEN-X

               MOVE WUSEC-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X

               GO TO 2200-PROCESS-CREATE-X
557660     END-IF.

           PERFORM 2210-CREATE-EDITS
              THRU 2210-CREATE-EDITS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2200-PROCESS-CREATE-X
557660     END-IF.

           MOVE MIR-USER-ID           TO WUSEC-USER-ID.
           PERFORM  USEC-1000-CREATE
               THRU USEC-1000-CREATE-X.

           PERFORM  USEC-1000-WRITE
               THRU USEC-1000-WRITE-X.

014221     PERFORM USEC-1000-READ-TWRK-TS
014221        THRU USEC-1000-READ-TWRK-TS-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       2200-PROCESS-CREATE-X.
           EXIT.
      /
      *------------------
       2210-CREATE-EDITS.
      *------------------

           IF MIR-USER-ID = SPACES
               MOVE 'XS01000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2210-CREATE-EDITS-X.
           EXIT.
      /
      *--------------------
       2300-PROCESS-UPDATE.
      *--------------------

           MOVE MIR-USER-ID           TO WUSEC-USER-ID.
014221*    PERFORM USEC-1000-READ-FOR-UPDATE
014221*       THRU USEC-1000-READ-FOR-UPDATE-X.

014221     PERFORM USEC-2000-UPDATE-TWRK-TS
014221        THRU USEC-2000-UPDATE-TWRK-TS-X.

           IF WUSEC-IO-NOT-FOUND
              PERFORM 9100-BLANK-DATA-FIELDS
                 THRU 9100-BLANK-DATA-FIELDS-X

              MOVE WUSEC-KEY          TO WGLOB-MSG-PARM (1)
              MOVE 'XS00000006'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X

              GO TO 2300-PROCESS-UPDATE-X
557660     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'USEC'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WUSEC-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 2300-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  2330-UPDATE-EDITS
               THRU 2330-UPDATE-EDITS-X.

           PERFORM USEC-2000-REWRITE
              THRU USEC-2000-REWRITE-X.

014221     PERFORM USEC-1000-READ-TWRK-TS
014221        THRU USEC-1000-READ-TWRK-TS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
              MOVE 'XS00000008'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X

           ELSE
              MOVE 'XS00000007'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X

557660     END-IF.

       2300-PROCESS-UPDATE-X.
           EXIT.
      /
      *------------------
       2330-UPDATE-EDITS.
      *------------------

           IF MIR-USER-LANG-CD = SPACES
              MOVE RUSEC-USER-LANG-CD TO MIR-USER-LANG-CD
557660     END-IF.

           PERFORM 2331-EDIT-USER-LANG
              THRU 2331-EDIT-USER-LANG-X.

           IF MIR-PRTR-ID = SPACES
              MOVE RUSEC-PRTR-ID      TO MIR-PRTR-ID
557660     END-IF.

           PERFORM 2332-EDIT-PRINTER-DEST
              THRU 2332-EDIT-PRINTER-DEST-X.

           IF MIR-BR-ID = SPACES
              MOVE RUSEC-BR-ID        TO MIR-BR-ID
557660     END-IF.

           PERFORM 2333-EDIT-BRANCH-CODE
              THRU 2333-EDIT-BRANCH-CODE-X.

           IF MIR-USER-PSWD-XPRY-DUR NOT = SPACES
              PERFORM 2335-EDIT-PASSWORD-EXPIRY
                 THRU 2335-EDIT-PASSWORD-EXPIRY-X

           ELSE
020874*       MOVE RUSEC-USER-PSWD-XPRY-DUR
020874*                               TO L0290-INPUT-NUMBER
020874        MOVE RUSEC-USER-PSWD-XPRY-DUR
020874                                TO L0290-INPUT-V00
              MOVE 'N'                TO L0290-SIGN-IND
008455*       MOVE +4                        TO L0290-LENGTH
              MOVE ZERO               TO L0290-PRECISION
008455        MOVE +4                 TO L0290-MAX-OUT-LEN
008455        SET L0290-DCML-SUPPRESS        TO TRUE
020874*       PERFORM 0290-1000-NUMERIC-FORMAT
020874*          THRU 0290-1000-NUMERIC-FORMAT-X
020874        PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU 0290-2000-FORMAT-FOR-MIR-X

              MOVE L0290-OUTPUT-DATA  TO MIR-USER-PSWD-XPRY-DUR
557660     END-IF.

           IF MIR-SECUR-CLAS-ID = SPACES
              MOVE RUSEC-SECUR-CLAS-ID              TO MIR-SECUR-CLAS-ID
557660     END-IF.

           PERFORM 2336-EDIT-SECURITY-CLASS
              THRU 2336-EDIT-SECURITY-CLASS-X.

           IF  MIR-USER-PSWD-TXT NOT = SPACES
013578     AND MIR-USER-PSWD-TXT NOT = RUSEC-USER-PSWD-TXT
              PERFORM 2337-EDIT-PASSWORD
                 THRU 2337-EDIT-PASSWORD-X

           ELSE
              MOVE RUSEC-USER-PSWD-TXT              TO MIR-USER-PSWD-TXT
557660     END-IF.

           IF MIR-DEPT-ID NOT = SPACES
              PERFORM 2338-EDIT-DEPARTMENT
                 THRU 2338-EDIT-DEPARTMENT-X

           ELSE
              MOVE RUSEC-DEPT-ID      TO MIR-DEPT-ID
557660     END-IF.

           IF MIR-USER-RPT-DSTRB-CD NOT = SPACES
              PERFORM 2339-EDIT-DISTRIBUTION
                 THRU 2339-EDIT-DISTRIBUTION-X

           ELSE
              MOVE RUSEC-USER-RPT-DSTRB-CD
                                      TO MIR-USER-RPT-DSTRB-CD
557660     END-IF.

       2330-UPDATE-EDITS-X.
           EXIT.
      /
      *--------------------
       2331-EDIT-USER-LANG.
      *--------------------

           IF MIR-USER-LANG-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-USER-LANG-CD
557660     END-IF.

           MOVE MIR-USER-LANG-CD      TO WXTAB-ETBL-VALU-ID.
           PERFORM LANG-1000-EDIT-USER-LANGUAGE
              THRU LANG-1000-EDIT-USER-LANGUAGE-X.

           IF WXTAB-IO-OK
               MOVE MIR-USER-LANG-CD  TO RUSEC-USER-LANG-CD

           ELSE
               MOVE 'XS01000001'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2331-EDIT-USER-LANG-X.
           EXIT.
      /
      *-----------------------
       2332-EDIT-PRINTER-DEST.
      *-----------------------

           IF MIR-PRTR-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-PRTR-ID
557660     END-IF.

           MOVE MIR-PRTR-ID           TO WPRTR-PRTR-ID.
           PERFORM PRTR-1000-READ
              THRU PRTR-1000-READ-X.

           IF WPRTR-IO-OK
               MOVE MIR-PRTR-ID       TO RUSEC-PRTR-ID
           ELSE
               MOVE 'XS01000002'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2332-EDIT-PRINTER-DEST-X.
           EXIT.
      /
      *----------------------
       2333-EDIT-BRANCH-CODE.
      *----------------------

           IF MIR-BR-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-BR-ID
557660     END-IF.

           MOVE MIR-BR-ID             TO WXTAB-ETBL-VALU-ID.
           PERFORM BRCH-1000-EDIT-BRANCH-CODE
              THRU BRCH-1000-EDIT-BRANCH-CODE-X.

           IF WXTAB-IO-OK
               MOVE MIR-BR-ID         TO RUSEC-BR-ID
           ELSE
               MOVE 'XS01000003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2333-EDIT-BRANCH-CODE-X.
           EXIT.
      /
      *--------------------------
       2335-EDIT-PASSWORD-EXPIRY.
      *--------------------------

           IF MIR-USER-PSWD-XPRY-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE ZERO              TO MIR-USER-PSWD-XPRY-DUR
557660     END-IF.

           MOVE MIR-USER-PSWD-XPRY-DUR              TO L0280-INPUT-DATA.
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE +4                    TO L0280-LENGTH.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE 'Y'                   TO L0280-SPACE-PERMITTED-IND.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO RUSEC-USER-PSWD-XPRY-DUR
020874*        MOVE RUSEC-USER-PSWD-XPRY-DUR
020874*                               TO L0290-INPUT-NUMBER
020874         MOVE RUSEC-USER-PSWD-XPRY-DUR
020874                                TO L0290-INPUT-V00
               MOVE 'N'               TO L0290-SIGN-IND
008455*        MOVE +4                TO L0290-LENGTH
               MOVE ZERO              TO L0290-PRECISION
008455         MOVE +4                TO L0290-MAX-OUT-LEN
008455         SET L0290-DCML-SUPPRESS TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-USER-PSWD-XPRY-DUR
           ELSE
               MOVE 'XS01000005'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2335-EDIT-PASSWORD-EXPIRY-X.
           EXIT.
      /
      *-------------------------
       2336-EDIT-SECURITY-CLASS.
      *-------------------------

           IF MIR-SECUR-CLAS-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-SECUR-CLAS-ID
557660     END-IF.

           MOVE MIR-SECUR-CLAS-ID     TO WUSCL-SECUR-CLAS-ID.
           PERFORM USCL-1000-READ
              THRU USCL-1000-READ-X.

           IF WUSCL-IO-OK
               IF RUSEC-SECUR-CLAS-ID  NOT = SPACE
                   MOVE RUSEC-SECUR-CLAS-ID
                                      TO WUSCL-SECUR-CLAS-ID
                   PERFORM USCL-1000-READ
                      THRU USCL-1000-READ-X

                   IF WUSCL-IO-OK
                       PERFORM 2340-UPDATE-USCL-COUNTS
                          THRU 2340-UPDATE-USCL-COUNTS-X

                       MOVE MIR-SECUR-CLAS-ID
                                      TO RUSEC-SECUR-CLAS-ID
                   ELSE
                       MOVE 'XS01000007'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM 0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
557660             END-IF

               ELSE
                   PERFORM 2340-UPDATE-USCL-COUNTS
                      THRU 2340-UPDATE-USCL-COUNTS-X

                   MOVE MIR-SECUR-CLAS-ID
                                      TO RUSEC-SECUR-CLAS-ID
557660         END-IF
           ELSE
               MOVE 'XS01000006'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2336-EDIT-SECURITY-CLASS-X.
           EXIT.
      /
      *-------------------
       2337-EDIT-PASSWORD.
      *-------------------

           IF MIR-USER-PSWD-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE             TO MIR-USER-PSWD-TXT
557660     END-IF.

           MOVE MIR-USER-PSWD-TXT     TO WPASS-PASSWORD.
           PERFORM PASS-1000-EDIT-PASSWORD
              THRU PASS-1000-EDIT-PASSWORD-X.


      ****
      **** SET TO SYSTEM DATE BEFORE THE SIGN ON PASSWORD CHANGE IS
      **** IMPLEMENTED
      ****
           IF NOT WPASS-PASSWORD-IN-ERROR
013578*        MOVE WWKDT-ZERO-DT     TO RUSEC-USER-PSWD-CHNG-DT
013578         MOVE WGLOB-SYSTEM-DATE-INT TO RUSEC-USER-PSWD-CHNG-DT
               MOVE MIR-USER-PSWD-TXT TO RUSEC-USER-PSWD-TXT
557660     END-IF.

       2337-EDIT-PASSWORD-X.
           EXIT.
      /
      *---------------------
       2338-EDIT-DEPARTMENT.
      *---------------------

           IF MIR-DEPT-ID = EBLCH-BLANK-FIELD-CHAR
              MOVE SPACE              TO MIR-DEPT-ID
557660     END-IF.

           MOVE MIR-DEPT-ID           TO WXTAB-ETBL-VALU-ID.
           PERFORM DEPT-1000-EDIT-DEPT-CD
              THRU DEPT-1000-EDIT-DEPT-CD-X.

           IF WXTAB-IO-OK
               MOVE MIR-DEPT-ID       TO RUSEC-DEPT-ID
           ELSE
               MOVE 'XS01000009'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2338-EDIT-DEPARTMENT-X.
           EXIT.
      /
      *-----------------------
       2339-EDIT-DISTRIBUTION.
      *-----------------------

           IF MIR-USER-RPT-DSTRB-CD = EBLCH-BLANK-FIELD-CHAR
              MOVE SPACE              TO MIR-USER-RPT-DSTRB-CD
557660     END-IF.

           MOVE MIR-USER-RPT-DSTRB-CD TO WXTAB-ETBL-VALU-ID.
           PERFORM DIST-1000-EDIT-DIST-CD
              THRU DIST-1000-EDIT-DIST-CD-X.

           IF WXTAB-IO-OK
               MOVE MIR-USER-RPT-DSTRB-CD
                                      TO RUSEC-USER-RPT-DSTRB-CD
           ELSE
               MOVE 'XS01000010'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2339-EDIT-DISTRIBUTION-X.
           EXIT.
      /
      *------------------------
       2340-UPDATE-USCL-COUNTS.
      *------------------------

           IF MIR-SECUR-CLAS-ID = RUSEC-SECUR-CLAS-ID
              GO TO 2340-UPDATE-USCL-COUNTS-X
557660     END-IF.

           MOVE MIR-SECUR-CLAS-ID     TO WUSCL-SECUR-CLAS-ID.
           PERFORM USCL-1000-READ-FOR-UPDATE
              THRU USCL-1000-READ-FOR-UPDATE-X.

           IF WUSCL-IO-OK
               ADD +1                 TO RUSCL-SECUR-USER-CTR
               PERFORM USCL-2000-REWRITE
                  THRU USCL-2000-REWRITE-X

           ELSE
               MOVE WUSCL-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               GO TO 2340-UPDATE-USCL-COUNTS-X
557660     END-IF.

           IF RUSEC-SECUR-CLAS-ID  = SPACES
               GO TO 2340-UPDATE-USCL-COUNTS-X
557660     END-IF.

           MOVE RUSEC-SECUR-CLAS-ID   TO WUSCL-SECUR-CLAS-ID.
           PERFORM USCL-1000-READ-FOR-UPDATE
              THRU USCL-1000-READ-FOR-UPDATE-X.

           IF WUSCL-IO-OK
               ADD -1                 TO RUSCL-SECUR-USER-CTR
               PERFORM USCL-2000-REWRITE
                  THRU USCL-2000-REWRITE-X

           ELSE
               MOVE WUSCL-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2340-UPDATE-USCL-COUNTS-X.
           EXIT.
      /
      *--------------------
       2400-PROCESS-DELETE.
      *--------------------

           MOVE MIR-USER-ID           TO WUSEC-USER-ID.
014221*    PERFORM  USEC-1000-READ-FOR-UPDATE
014221*        THRU USEC-1000-READ-FOR-UPDATE-X.

014221     PERFORM USEC-2000-UPDATE-TWRK-TS
014221        THRU USEC-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'USEC'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WUSEC-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 2400-PROCESS-DELETE-X
014221     END-IF.
           
           IF WUSEC-IO-OK
              PERFORM 2440-UPDATE-USCL-COUNT
                 THRU 2440-UPDATE-USCL-COUNT-X

              IF WS-USCL-COUNT-UPDATED
                 PERFORM  USEC-1000-DELETE
                     THRU USEC-1000-DELETE-X

                 MOVE 'XS00000011'    TO WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X

557660        END-IF
557660***     ELSE
557660***        NEXT SENTENCE
           ELSE
              MOVE WUSEC-KEY          TO WGLOB-MSG-PARM (1)
              MOVE 'XS00000010'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.


       2400-PROCESS-DELETE-X.
           EXIT.
      /
      *-----------------------
       2440-UPDATE-USCL-COUNT.
      *-----------------------

           MOVE SPACES                TO WS-USCL-COUNT-FLAG.

           IF RUSEC-SECUR-CLAS-ID  NOT > SPACE
              MOVE 'Y'                TO WS-USCL-COUNT-FLAG
              GO TO 2440-UPDATE-USCL-COUNT-X
557660     END-IF.

           MOVE RUSEC-SECUR-CLAS-ID   TO WUSCL-SECUR-CLAS-ID.
           PERFORM USCL-1000-READ-FOR-UPDATE
              THRU USCL-1000-READ-FOR-UPDATE-X.

           IF WUSCL-IO-OK
               ADD -1                 TO RUSCL-SECUR-USER-CTR
               MOVE 'Y'               TO WS-USCL-COUNT-FLAG
               PERFORM USCL-2000-REWRITE
                  THRU USCL-2000-REWRITE-X

           ELSE
               MOVE WUSCL-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS01000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       2440-UPDATE-USCL-COUNT-X.
           EXIT.
      /
      *------------------
       2500-PROCESS-LIST.
      *------------------


           MOVE SPACES                TO MIR-USER-ID-G.
           MOVE SPACES                TO MIR-USER-LANG-CD-G.
           MOVE SPACES                TO MIR-SECUR-CLAS-ID-G.
           MOVE SPACES                TO MIR-USER-PSWD-XPRY-DUR-G.
           MOVE SPACES                TO MIR-USER-PSWD-TXT-G.
           MOVE SPACES                TO MIR-DEPT-ID-G.
           MOVE SPACES                TO MIR-BR-ID-G.
           MOVE SPACES                TO MIR-PRTR-ID-G.

           MOVE LOW-VALUES            TO WUSEC-KEY.
           MOVE HIGH-VALUES           TO WUSEC-ENDBR-KEY.
           MOVE MIR-USER-ID           TO WUSEC-USER-ID.

           PERFORM USEC-1000-BROWSE
              THRU USEC-1000-BROWSE-X.

           IF WUSEC-IO-EOF
              MOVE 'XS00000034'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X

              GO TO 2500-PROCESS-LIST-X
           ELSE
              PERFORM  USEC-2000-READ-NEXT
                  THRU USEC-2000-READ-NEXT-X

              IF WUSEC-IO-EOF
                 MOVE 'XS00000025'    TO WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X

                 GO TO 2500-PROCESS-LIST-X
557660        END-IF
557660     END-IF.

557660     PERFORM  2510-PROCESS-LIST-READ
557660        THRU  2510-PROCESS-LIST-READ-X VARYING WS-SUB FROM +1
                    BY +1 UNTIL WS-SUB > WS-MAX-BROWSE-LINES OR
                    WUSEC-IO-EOF.

           IF WUSEC-IO-EOF
              MOVE 'XS00000025'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X

           ELSE
              MOVE 'XS00000014'       TO WGLOB-MSG-REF-INFO
              SET WGLOB-MORE-DATA-EXISTS TO TRUE
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           PERFORM  USEC-3000-END-BROWSE
               THRU USEC-3000-END-BROWSE-X.

       2500-PROCESS-LIST-X.
           EXIT.
      /
      *-------------------------
       2510-PROCESS-LIST-READ.
      *-------------------------

           MOVE RUSEC-USER-ID         TO MIR-USER-ID-T  (WS-SUB).
           MOVE RUSEC-USER-LANG-CD    TO MIR-USER-LANG-CD-T  (WS-SUB).
           MOVE RUSEC-SECUR-CLAS-ID   TO MIR-SECUR-CLAS-ID-T (WS-SUB).
020874*    MOVE RUSEC-USER-PSWD-XPRY-DUR
020874*                               TO L0290-INPUT-NUMBER.
020874     MOVE RUSEC-USER-PSWD-XPRY-DUR
020874                                TO L0290-INPUT-V00.
           MOVE 'N'                   TO L0290-SIGN-IND.
008455*    MOVE +4                    TO L0290-LENGTH.
           MOVE ZERO                  TO L0290-PRECISION.
008455     MOVE +4                    TO L0290-MAX-OUT-LEN.
008455     SET L0290-DCML-SUPPRESS    TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.


           MOVE L0290-OUTPUT-DATA  TO MIR-USER-PSWD-XPRY-DUR-T (WS-SUB).
           MOVE RUSEC-USER-PSWD-TXT   TO MIR-USER-PSWD-TXT-T (WS-SUB).
           MOVE RUSEC-DEPT-ID         TO MIR-DEPT-ID-T (WS-SUB).
           MOVE RUSEC-BR-ID           TO MIR-BR-ID-T  (WS-SUB).
           MOVE RUSEC-PRTR-ID         TO MIR-PRTR-ID-T (WS-SUB).

           PERFORM  USEC-2000-READ-NEXT
               THRU USEC-2000-READ-NEXT-X.

           IF WS-SUB = WS-MAX-BROWSE-LINES
              IF WUSEC-IO-OK
                 MOVE RUSEC-USER-ID   TO MIR-USER-ID
557660        END-IF
557660     END-IF.

       2510-PROCESS-LIST-READ-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-IO-AREA.
           MOVE WUSEC-USER-ID         TO MIR-USER-ID.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RUSEC-USER-ID         TO MIR-USER-ID.
           MOVE RUSEC-USER-LANG-CD    TO MIR-USER-LANG-CD.
           MOVE RUSEC-PRTR-ID         TO MIR-PRTR-ID.
           MOVE RUSEC-SECUR-CLAS-ID   TO MIR-SECUR-CLAS-ID.
           MOVE RUSEC-BR-ID           TO MIR-BR-ID.
           MOVE RUSEC-DEPT-ID         TO MIR-DEPT-ID.
           MOVE RUSEC-USER-RPT-DSTRB-CD
                                      TO MIR-USER-RPT-DSTRB-CD.
020874*    MOVE RUSEC-USER-PSWD-XPRY-DUR
020874*                               TO L0290-INPUT-NUMBER.
020874     MOVE RUSEC-USER-PSWD-XPRY-DUR
020874                                TO L0290-INPUT-V00.
           MOVE 'N'                   TO L0290-SIGN-IND.
008455*    MOVE +4                    TO L0290-LENGTH.
           MOVE ZERO                  TO L0290-PRECISION.
008455     MOVE +4                    TO L0290-MAX-OUT-LEN.
008455     SET L0290-DCML-SUPPRESS    TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA     TO MIR-USER-PSWD-XPRY-DUR.
           MOVE RUSEC-USER-PSWD-TXT   TO MIR-USER-PSWD-TXT.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.

025970     PERFORM  0005-0000-INIT-PARM-INFO
025970         THRU 0005-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WPASS-WORK-AREA.
025970     SET  WPASS-MAX-LENGTH-DEFAULT  TO TRUE.
025970     SET  MIR-RETRN-OK       TO TRUE.
025970     MOVE MIR-BUS-FCN-ID     TO WS-BUS-FCN-ID.

025970     SET  WS-MAX-BROWSE-LINES-DEFAULT TO TRUE.
025970     SET  WS-TERK-KEY-DEFAULT         TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.

       COPY XCPPEXIT.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY USEC
014221                         '$VAR2' BY 'USEC'.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
       COPY XCPEBRCH.
      /
       COPY XCPEDEPT.
      /
       COPY XCPEDIST.
      /
       COPY XCPELANG.
      /
       COPY XCPPPASS.
      /
016537*COPY XCPS0005.
557698 COPY XCPL0005.
      /
025970 COPY XCPS0005.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
008455 COPY XCPS0290.
       COPY XCPL0290.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
014660*COPY XCPPMEXT.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY XCPBUSEC.
      /
       COPY XCPNUSEC.
      /
       COPY XCPUUSEC.
      /
       COPY XCPAUSEC.
      /
       COPY XCPCUSEC.
      /
       COPY XCPXUSEC.
      /
       COPY XCPNUSCL.
      /
       COPY XCPUUSCL.
      /
       COPY XCPNPRTR.
      /
       COPY XCPNXTAB.

      *****************************************************************
      **                   END OF PROGRAM XSOM0100                   **
      *****************************************************************
