      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM2050.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM2050                                         **
      **  REMARKS:  WS-ENTER-CODE-MAINTAIN LABORATORY REQUIREMENTS   **
      **            TEST TABLE.                                      **
      **                                                             **
      **            THIS PROGRAM WILL MAINTAIN THE LABORATORY        **
      **            REQUIREMENT TEST TABLE WHICH WILL DEFINE WHICH   **
      **            TESTS COMPRISE PARTICULAR LABORATORY             **
      **            REQUIREMENTS.                                    **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP/STANDARDIZATION, MOVE BROWSE        **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
006002**  6.0       SELECTION BOX AND CODE TRANSLATION               **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018633**  6.4       TWRK CLEANUP                                     **
017619**  6.4       REMOVE TWRK KEYWORD                              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM2050'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
       COPY XCWL8090.

       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-ATTACH        VALUE '2051'.
               88  WS-BUS-FCN-REMOVE        VALUE '2053'.
               88  WS-BUS-FCN-LIST          VALUE '2054'.
           05  WS-CONTROL-ERROR             PIC X(01).
               88  SW-CONTROL-ERROR         VALUE 'Y'.
           05  WS-EDIT-SCROLL-CODE          PIC X(01).
               88  WS-VALID-SCROLL-CODE     VALUE 'D' 'U'.
           05  WS-MOVE-NEXT-COMPLETE        PIC X(01).
               88 SW-MOVE-NEXT-COMPLETE     VALUE 'Y'.
               88 SW-MOVE-NEXT-NOT-COMPLETE VALUE 'N'.
           05  WS-MOVE-PREV-COMPLETE        PIC X(01).
               88 SW-MOVE-PREV-COMPLETE     VALUE 'Y'.
               88 SW-MOVE-PREV-NOT-COMPLETE VALUE 'N'.
           05  WS-LRTT-PAGE-CHANGED         PIC X(01).
               88 SW-LRTT-PAGE-CHANGED      VALUE 'Y'.
               88 SW-LRTT-PAGE-NOT-CHANGED  VALUE 'N'.
           05  WS-DATA-EDITS                PIC X(01).
               88  WS-DATA-EDITS-OK         VALUE 'Y'.
               88  WS-DATA-EDITS-FAILED     VALUE 'N'.
           05  INSERT-ARRAY-INDICATOR       PIC X(01).
               88  INSERT-ARRAY             VALUE 'Y'.
           05  ADD-ARRAY-INDICATOR          PIC X(01).
               88  ADD-TO-END               VALUE 'Y'.
           05  WS-LRTT-KEY.
               10  WS-RQCOD                 PIC X(05).
               10  WS-LBCOD                 PIC X(03).
               10  WS-CTYRC                 PIC X(02).
025970*    05  WS-OK                        PIC X(01)  VALUE 'Y'.
025970     05  WS-OK                        PIC X(01).
025970         88  WS-DEFAULT-OK-SW                    VALUE 'Y'.
025970*    05  WS-FAILED                    PIC X(01)  VALUE 'N'.
025970     05  WS-FAILED                    PIC X(01).
025970         88  WS-DEFAULT-FAILED-SW                VALUE 'N'.
016548*    05  WS-MAX-ENTRIES               PIC S9(04)  COMP
025970*    05  WS-MAX-ENTRIES               PIC S9(04)  BINARY
025970*                                     VALUE +30.
016548*    05  WS-DISPLAY-LINES             PIC S9(04)  COMP
025970*    05  WS-DISPLAY-LINES             PIC S9(04)  BINARY
025970*                                     VALUE +30.
016548*    05  WS-LINE                      PIC S9(04)  COMP.
016548     05  WS-LINE                      PIC S9(04)  BINARY.
016548*    05  WS-INDEX                     PIC S9(04)  COMP.
016548     05  WS-INDEX                     PIC S9(04)  BINARY.
016548*    05  WS-LINE-SUB                  PIC S9(04)  COMP.
016548     05  WS-LINE-SUB                  PIC S9(04)  BINARY.
016548*    05  WS-ARRAY-SUB                 PIC S9(04)  COMP.
016548     05  WS-ARRAY-SUB                 PIC S9(04)  BINARY.
016548*    05  WS-ENTRIES-SUB               PIC S9(04)  COMP.
016548     05  WS-ENTRIES-SUB               PIC S9(04)  BINARY.
016548*    05  WS-INSERT-SUB                PIC S9(04)  COMP.
016548     05  WS-INSERT-SUB                PIC S9(04)  BINARY.

017619*    05  WS-DELETE-TWRK               PIC X(17).
017619*        88 WS-DELETE-TWRK-ON         VALUE
017619*           'DELETE_TWRK'.
      /
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-ENTRIES               PIC S9(04)  BINARY.
025970         88  WS-DEFAULT-MAX-ENTRIES               VALUE +30.
025970     05  WS-DISPLAY-LINES             PIC S9(04)  BINARY.
025970         88  WS-DEFAULT-DISPLAY-LINES             VALUE +30.
      /
      *-------------------
      * TWRK AREA
      *--------------------
018633*01  WS-TWRK-KEY                  PIC X(04) VALUE '2054'.
018633*01  WS-TWRK-AREA.
018633*    05  WS-DISPLAY-START                 PIC 9(03).
018633*    05  WS-SEQUENCE-NUMBER               PIC X(03).
018633*    05  WS-KEY.
018633*        10 ALL                           PIC X(02).
018633*        10 WS-TWRK-LRTT-KEY.
018633*           20 WS-REQ-CODE                PIC X(05).
018633*           20 WS-LAB-CODE                PIC X(03).
018633*           20 WS-REGION                  PIC X(02).
018633*    05  WS-NEXT-KEY.
018633*        10 WS-NEXT-COMPANY-CODE          PIC X(02).
018633*        10 WS-NEXT-LRTT-KEY.
018633*           20 WS-NEXT-REQ-CODE           PIC X(05).
018633*           20 WS-NEXT-LAB-CODE           PIC X(03).
018633*           20 WS-NEXT-REGION             PIC X(02).
018633*    05  WS-LAB-TEST-NUMBER               PIC X(04).
      *    05  WS-PAGE                          PIC X(01).
      *    05  FILLER                           PIC X(229).
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '2054'.
018633     15  LCOMM-DISPLAY-START              PIC 9(03).
018633     15  LCOMM-SEQUENCE-NUMBER            PIC X(03).
018633     15  LCOMM-THIS-KEY.
018633         20 LCOMM-COMPANY-CODE            PIC X(02).
018633         20 LCOMM-TWRK-LRTT-KEY.
018633            25 LCOMM-REQ-CODE             PIC X(05).
018633            25 LCOMM-LAB-CODE             PIC X(03).
018633            25 LCOMM-REGION               PIC X(02).
018633     15  LCOMM-NEXT-KEY.
018633         20 LCOMM-NEXT-COMPANY-CODE       PIC X(02).
018633         20 LCOMM-NEXT-LRTT-KEY.
018633            25 LCOMM-NEXT-REQ-CODE        PIC X(05).
018633            25 LCOMM-NEXT-LAB-CODE        PIC X(03).
018633            25 LCOMM-NEXT-REGION          PIC X(02).
018633     15  LCOMM-LAB-TEST-NUMBER            PIC X(04).
      *
016537*COPY XCWEBLCH.
      /
016537*COPY XCWTATRB.
      /
       COPY CCFREDIT.
       COPY CCFWEDIT.
      /
       COPY XCFRCTLC.
       COPY XCFWCTLC.
      /
       COPY NCFWLRTT.
      /
       COPY NCFRLRTT.
      /
       COPY NCFWRTAB.
      /
       COPY NCFRRTAB.
      /
014221 COPY CCWWLOCK.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      /
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM2050.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.


      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.
018633
018633     PERFORM  COMM-1000-INITIALIZE
018633         THRU COMM-1000-INITIALIZE-X.
018633
           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.
      *

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *****************************************************************
      *  PERFORM SECURITY PROCESSING AND INVOKE MODULES TO
      *      PROCESS USER REQUEST
      *****************************************************************
       2000-PROCESS-REQUEST.
      *
      *   INITIALIZE VARIABLES NEEDED FOR THIS TRANSACTION.
      *
           PERFORM  2100-INITIALIZE
               THRU 2100-INITIALIZE-X.
      *
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *    MOVE ENTER CODE TO A WORK FIELD.
      *
025970*    MOVE  MIR-BUS-FCN-ID         TO  WS-BUS-FCN-ID.

      *
      *   VALIDATE THE CONTROL FIELDS ENTERED.
      *

           PERFORM 2200-VALIDATE-CONTROL-FIELDS
               THRU 2200-VALIDATE-CONTROL-FIELDS-X.


           IF SW-CONTROL-ERROR
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.
      /
      *
      *    PROCESS SCREEN FUNCTIONS
      *
           IF  WS-BUS-FCN-ATTACH
               PERFORM 4000-PROCESS-CREATE
                  THRU 4000-PROCESS-CREATE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.
      *
           IF  WS-BUS-FCN-LIST
               PERFORM 3500-PROCESS-LIST
                  THRU 3500-PROCESS-LIST-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.
      *
           IF  WS-BUS-FCN-REMOVE
               PERFORM 6000-PROCESS-DELETE
                  THRU 6000-PROCESS-DELETE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.
      *
       2000-PROCESS-REQUEST-X.
           EXIT.
      *
       2100-INITIALIZE.
      *
018633*    MOVE  SPACES           TO  WS-TWRK-AREA.
018633*    MOVE  ZEROES           TO  WS-DISPLAY-START.
      *
           MOVE SPACES                TO  WS-LRTT-KEY.
           MOVE MIR-REQIR-ID          TO  WS-RQCOD.
           MOVE MIR-LAB-ID            TO  WS-LBCOD.
           MOVE MIR-REQIR-LTST-RGN-CD TO  WS-CTYRC.
      *
           MOVE   'N'                 TO    WS-CONTROL-ERROR.
           MOVE   'N'                 TO    WS-MOVE-PREV-COMPLETE.
           MOVE   'N'                 TO    WS-MOVE-NEXT-COMPLETE.
      *
       2100-INITIALIZE-X.
           EXIT.
      /
      *-----------------------------
       2200-VALIDATE-CONTROL-FIELDS.
      *-----------------------------

      * GET THE KEYWORD FROM DELETE FLOW OF BF2054LIST.F

017619*    MOVE  MIR-LTST-ID TO WS-DELETE-TWRK.

017619*    IF  WS-DELETE-TWRK-ON
017619*        PERFORM  9900-DELETE-TWRK
017619*            THRU 9900-DELETE-TWRK-X

017619*        MOVE SPACES  TO  MIR-LTST-ID
017619*    END-IF.

           IF  WS-BUS-FCN-LIST
018633*        PERFORM  9700-RETRIEVE-TWRK
018633*            THRU 9700-RETRIEVE-TWRK-X
018633         PERFORM  COMM-1000-RETRIEVE-TWRK
018633             THRU COMM-1000-RETRIEVE-TWRK-X

018633*        IF L8090-RETRN-OK
018633*           MOVE L8090-AREA-INFO-TEXT    TO WS-TWRK-AREA
018633*        END-IF
018633*
018633*        PERFORM  9900-DELETE-TWRK
018633*            THRU 9900-DELETE-TWRK-X
018633         PERFORM  COMM-3000-DELETE-TWRK
018633             THRU COMM-3000-DELETE-TWRK-X
           END-IF.

      *  CHECK FOR CHANGE BY USER IN LRTT KEY
      *  MUST CHANGE KEY FIELDS OR LAB TEST NUMBER
      *
018633*    IF WS-LRTT-KEY            NOT = WS-TWRK-LRTT-KEY
018633*        MOVE WS-LRTT-KEY       TO   WS-TWRK-LRTT-KEY
018633*        MOVE MIR-LTST-ID       TO   WS-LAB-TEST-NUMBER
018633*        MOVE SPACES            TO   WS-NEXT-LRTT-KEY
018633     IF WS-LRTT-KEY            NOT = LCOMM-TWRK-LRTT-KEY
018633         MOVE WS-LRTT-KEY       TO   LCOMM-TWRK-LRTT-KEY
018633         MOVE MIR-LTST-ID       TO   LCOMM-LAB-TEST-NUMBER
018633         MOVE SPACES            TO   LCOMM-NEXT-LRTT-KEY
               GO TO 2200-VALIDATE-CONTROL-FIELDS-X
           ELSE
018633*        IF MIR-LTST-ID    NOT = WS-LAB-TEST-NUMBER
018633         IF MIR-LTST-ID    NOT = LCOMM-LAB-TEST-NUMBER
                   MOVE MIR-LTST-ID
018633*                               TO   WS-LAB-TEST-NUMBER
018633*            MOVE SPACES    TO   WS-NEXT-LRTT-KEY
018633                                TO   LCOMM-LAB-TEST-NUMBER
018633             MOVE SPACES    TO   LCOMM-NEXT-LRTT-KEY
                   GO TO 2200-VALIDATE-CONTROL-FIELDS-X
557660         END-IF
557660     END-IF.


018633*    IF (WS-NEXT-LRTT-KEY NOT = SPACES)
018633*    AND (WS-NEXT-LRTT-KEY NOT = WS-TWRK-LRTT-KEY)
018633*        MOVE WS-NEXT-REQ-CODE
018633     IF (LCOMM-NEXT-LRTT-KEY NOT = SPACES)
018633     AND (LCOMM-NEXT-LRTT-KEY NOT = LCOMM-TWRK-LRTT-KEY)
018633         MOVE LCOMM-NEXT-REQ-CODE
                                      TO  MIR-REQIR-ID
018633*        MOVE WS-NEXT-LAB-CODE
018633         MOVE LCOMM-NEXT-LAB-CODE
                                      TO  MIR-LAB-ID
018633*        MOVE WS-NEXT-REGION TO  MIR-REQIR-LTST-RGN-CD
018633         MOVE LCOMM-NEXT-REGION TO MIR-REQIR-LTST-RGN-CD
               MOVE SPACES            TO  MIR-LTST-ID
018633*        MOVE WS-NEXT-LRTT-KEY
018633*                               TO  WS-TWRK-LRTT-KEY
018633         MOVE LCOMM-NEXT-LRTT-KEY
018633                                TO  LCOMM-TWRK-LRTT-KEY

018633*        MOVE SPACES            TO  WS-NEXT-LRTT-KEY
018633         MOVE SPACES            TO  LCOMM-NEXT-LRTT-KEY
557660     END-IF.
      *
       2200-VALIDATE-CONTROL-FIELDS-X.
           EXIT.
      /
      *
      *   INQUIRY - NEXT LRTT-RECORD PROCESSING
      *   SET UP BROWSE KEYS, BEGIN BROWSE AND LOAD
      *   ARRAY INFORMATION UNTIL END OF ARRAY INFO
      *   OR SCREEN IS FULL.
      *
       3100-NEXT-LRTT.
      *
           MOVE HIGH-VALUES           TO  WLRTT-ENDBR-KEY.
      *
      *    POSITION AT AND READ FIRST RECORD.
      *    MSG: END OF FILE REACHED
      *
           PERFORM  LRTT-1000-BROWSE
               THRU LRTT-1000-BROWSE-X.
           IF  WLRTT-IO-OK
               PERFORM  LRTT-2000-READ-NEXT
                   THRU LRTT-2000-READ-NEXT-X
               IF WLRTT-IO-EOF
      *MSG:        NO RECORDS FOUND TO DISPLAY
                   MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3100-NEXT-LRTT-X
               ELSE
                   PERFORM  3300-INQUIRY-KEY-INFO
                       THRU 3300-INQUIRY-KEY-INFO-X
               END-IF
           ELSE
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO  3100-NEXT-LRTT-X
           END-IF.
      *
      *    LOAD SCREEN DATA ARRAY.
      *
           PERFORM  3110-NEXT-ARRAY-START
               THRU 3110-NEXT-ARRAY-START-X.
      *
      *   LAB TEST NUMBER DOES NOT EXIST ON TABLE AND
      *   END OF ARRAY HAS BEEN REACHED.
      *   READ NEXT RECORD TO SET UP WS LRTT NEXT KEY.
      *
           IF (MIR-LTST-ID NOT = SPACES)
           AND (WS-ARRAY-SUB > RLRTT-REQIR-TST-QTY)
               PERFORM  LRTT-2000-READ-NEXT
                   THRU LRTT-2000-READ-NEXT-X
               IF WLRTT-IO-OK
018633*            MOVE RLRTT-KEY     TO WS-NEXT-KEY
018633             MOVE RLRTT-KEY     TO LCOMM-NEXT-KEY
                   MOVE RLRTT-KEY     TO WGLOB-MSG-PARM (1)
                   MOVE 'NS20500013'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   PERFORM  LRTT-3000-END-BROWSE
                       THRU LRTT-3000-END-BROWSE-X
                   GO TO 3100-NEXT-LRTT-X
              ELSE
                   MOVE 'XS00000025' TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'NS20500016'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
018633*            MOVE SPACES          TO  WS-NEXT-KEY
018633*            MOVE WS-TWRK-LRTT-KEY  TO  WS-NEXT-LRTT-KEY
018633*            MOVE SPACES          TO  WS-KEY
018633             MOVE SPACES          TO  LCOMM-NEXT-KEY
018633             MOVE LCOMM-TWRK-LRTT-KEY TO LCOMM-NEXT-LRTT-KEY
018633             MOVE SPACES          TO  LCOMM-THIS-KEY
                   PERFORM  LRTT-3000-END-BROWSE
                       THRU LRTT-3000-END-BROWSE-X
                   GO TO 3100-NEXT-LRTT-X
557660         END-IF
557660     END-IF.
      *
           PERFORM  3120-MOVE-NEXT-ARRAY
               THRU 3120-MOVE-NEXT-ARRAY-X.
      *
      *  COMPLETION MESSAGES
      *  PAGING DOWN:
      *  1-INQUIRE COMPLETED - CONTINUE
      *  2-TO VIEW MORE DATA PRESS ENTER
      *  PAGING UP:
      *  1-INQUIRE COMPLETED - CONTINUE
      *    HIT ENTER TO VIEW PREVIOUS RECORD
      *  2-INQUIRE COMPLETED - CONTINUE
      *    END OF FILE, HIT ENTER TO SCROLL DOWN TO NEXT RECORD
      *  3-TO VIEW MORE DATA PRESS ENTER
      *
           IF  (WS-ARRAY-SUB >  WS-MAX-ENTRIES)
           OR  (RLRTT-TST-LTST-ID (WS-ARRAY-SUB)  =  SPACES)
               MOVE  SPACES           TO MIR-LTST-ID
018633*        MOVE  SPACES           TO WS-LAB-TEST-NUMBER
018633         MOVE  SPACES           TO LCOMM-LAB-TEST-NUMBER
           ELSE
                   MOVE RLRTT-TST-LTST-ID (WS-ARRAY-SUB)
                                                TO MIR-LTST-ID
                   MOVE RLRTT-TST-LTST-ID (WS-ARRAY-SUB)
018633*                                         TO WS-LAB-TEST-NUMBER
018633                                          TO LCOMM-LAB-TEST-NUMBER
                   SET WGLOB-MORE-DATA-EXISTS   TO TRUE
                   MOVE 'XS00000014'            TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.


      *
      *    PERFORM READ NEXT TO SET UP TWRK NEXT KEY.
      *
            IF  (WS-ARRAY-SUB  >  WS-MAX-ENTRIES)
            OR  (RLRTT-TST-LTST-ID (WS-ARRAY-SUB)  =  SPACES)

               PERFORM  LRTT-2000-READ-NEXT
                   THRU LRTT-2000-READ-NEXT-X

               IF WLRTT-IO-OK
018633*            MOVE RLRTT-KEY      TO WS-NEXT-KEY
018633             MOVE RLRTT-KEY      TO LCOMM-NEXT-KEY
                   MOVE RLRTT-KEY      TO WGLOB-MSG-PARM (1)
                   MOVE 'NS20500013'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
018633*            MOVE SPACES            TO  WS-NEXT-KEY
018633*            MOVE WS-TWRK-LRTT-KEY  TO  WS-NEXT-LRTT-KEY
018633*            MOVE SPACES          TO  WS-KEY
018633             MOVE SPACES            TO  LCOMM-NEXT-KEY
018633             MOVE LCOMM-TWRK-LRTT-KEY TO LCOMM-NEXT-LRTT-KEY
018633             MOVE SPACES          TO  LCOMM-THIS-KEY
                   MOVE 'XS00000025' TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'NS20500016'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF

557660      END-IF.


      *
      *    END THE BROWSE.
      *
           PERFORM  LRTT-3000-END-BROWSE
               THRU LRTT-3000-END-BROWSE-X.
      *
       3100-NEXT-LRTT-X.
           EXIT.
      /
      *****************************************************************
      *  GET ARRAY START - GIVEN THE START OF THE LAST DISPLAY AND THE
      *  SCROLL COMMAND, DETERMINE THE NEW START POSITION FOR DISPLAY
      *  OF THE VARIABLE INFORMATION.
      *****************************************************************
       3110-NEXT-ARRAY-START.
      *
      *  WHEN FIRST TIME IN TRANSACTION, OR LRTT KEY HAS CHANGED,
      *  DISPLAY FROM THE START OF THE ARRAY.
      *
018633*    IF (WS-DISPLAY-START = ZEROES
018633     IF (LCOMM-DISPLAY-START = ZEROES
557660     AND MIR-LTST-ID = SPACES)
           OR (MIR-LTST-ID = SPACES)
               MOVE +1                TO WS-ARRAY-SUB
018633*        MOVE WS-ARRAY-SUB      TO WS-DISPLAY-START
018633*        MOVE MIR-LTST-ID TO WS-LAB-TEST-NUMBER
018633         MOVE WS-ARRAY-SUB      TO LCOMM-DISPLAY-START
018633         MOVE MIR-LTST-ID TO LCOMM-LAB-TEST-NUMBER
               GO TO 3110-NEXT-ARRAY-START-X
557660     END-IF.
      *
           IF  (MIR-LTST-ID NOT = SPACES)

               PERFORM  3115-CALL-READ-NEXT
                   THRU 3115-CALL-READ-NEXT-X

               IF  WS-ARRAY-SUB    >  RLRTT-REQIR-TST-QTY
                   GO TO 3110-NEXT-ARRAY-START-X
               END-IF

557660     END-IF.
      *
      /
      *
      *  DETERMINE DISPLAY START FROM SCROLL COMMAND
      *  WHEN SCROLLING FORWARD, DON'T DISPLAY A BLANK SCREEN
      *
               ADD  WS-DISPLAY-LINES    TO   WS-ARRAY-SUB
               IF WS-ARRAY-SUB     >  RLRTT-REQIR-TST-QTY
                   SUBTRACT  WS-DISPLAY-LINES FROM WS-ARRAY-SUB
               ELSE
018633*            MOVE WS-DISPLAY-START
018633             MOVE LCOMM-DISPLAY-START
                                      TO  WS-ARRAY-SUB
557660         END-IF.
      *
      *  WHEN SCROLLING BACKWARD, CHECK FOR A VALID START INDEX
      *  AND DISPLAY MESSAGE WHEN AT BEGINNING OF FILE.
      *
      *
       3110-NEXT-ARRAY-START-X.
           EXIT.
      *--------------------
       3115-CALL-READ-NEXT.
      *---------------------

018633*    MOVE ZEROES            TO WS-DISPLAY-START.
018633     MOVE ZEROES            TO LCOMM-DISPLAY-START.
           MOVE +1                TO WS-ARRAY-SUB.

           PERFORM  4220-READ-NEXT-ARRAY
               THRU 4220-READ-NEXT-ARRAY-X
              UNTIL WS-ARRAY-SUB > RLRTT-REQIR-TST-QTY
              OR    MIR-LTST-ID = RLRTT-TST-LTST-ID (WS-ARRAY-SUB).

           IF  WS-ARRAY-SUB    >  RLRTT-REQIR-TST-QTY

               MOVE 'NS20500012'  TO WGLOB-MSG-REF-INFO
               MOVE WLRTT-KEY     TO WGLOB-MSG-PARM (1)
               MOVE RLRTT-TST-LTST-ID (WS-ARRAY-SUB)
                                      TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE

               IF  MIR-LTST-ID = RLRTT-TST-LTST-ID (WS-ARRAY-SUB)
018633*            MOVE WS-ARRAY-SUB TO  WS-DISPLAY-START
018633*            MOVE MIR-LTST-ID  TO  WS-LAB-TEST-NUMBER
018633             MOVE WS-ARRAY-SUB TO  LCOMM-DISPLAY-START
018633             MOVE MIR-LTST-ID  TO  LCOMM-LAB-TEST-NUMBER
557660         END-IF

557660     END-IF.
      *
       3115-CALL-READ-NEXT-X.
           EXIT.
      /
      *
      *****************************************************************
      *  MOVE ARRAY DATA - MOVE DATA ARRAY INFORMATION TO THE SCREEN
      *  ON READ NEXT (MIR-DV-SCROLL-TXT = 'D')
      *  NOTE :  WS-ARRAY-SUB    IS THE POSITION IN FILE
      *          WS-LINE         IS THE POSITION ON THE SCREEN
      *****************************************************************
       3120-MOVE-NEXT-ARRAY.
      *
           MOVE  +1                   TO  WS-LINE.
           PERFORM  9200-MOVE-NEXT-TO-SCREEN
               THRU 9200-MOVE-NEXT-TO-SCREEN-X
               UNTIL WS-LINE  >  WS-DISPLAY-LINES
               OR WS-ARRAY-SUB > RLRTT-REQIR-TST-QTY.
      *
       3120-MOVE-NEXT-ARRAY-X.
           EXIT.
      /
       3300-INQUIRY-KEY-INFO.
      *
      *  SET UP MIR VALUES FOR RECORD FOUND ON BROWSE
      *  AND TO BE DISPLAYED ON THE SCREEN.
      *
           MOVE RLRTT-REQIR-ID        TO MIR-REQIR-ID.
           MOVE RLRTT-LAB-ID          TO MIR-LAB-ID.
           MOVE RLRTT-REQIR-LTST-RGN-CD
                                      TO MIR-REQIR-LTST-RGN-CD.
      *
      *  SET UP WS-TWRK-LRTT-KEY VALUES FOR RECORD FOUND ON BROWSE
      *  AND TO BE DISPLAYED ON THE SCREEN.
      *
018633*    MOVE RLRTT-KEY             TO WS-KEY.
018633     MOVE RLRTT-KEY             TO LCOMM-THIS-KEY.
      *
       3300-INQUIRY-KEY-INFO-X.
           EXIT.
      /
      *****************************************************************
      *  INQUIRY PROCESSING: SETUP BROWSE KEYS, BEGIN BROWSE, AND
      *  LOAD DATA UNTIL END-OF-FILE OR SCREEN IS FULL.
      *****************************************************************
       3500-PROCESS-LIST.
      *


           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      *
      *    SETUP BROWSE KEY LIMITS
      *
           PERFORM  7100-BUILD-LRTT-KEY
               THRU 7100-BUILD-LRTT-KEY-X.
      *
      *   DEPENDING ON KEY TO LRTT FILE BEING CHANGED
      *   AND PAGE SCROLLING INDICATOR BEING CHANGED
      *   AND MIR-DV-SCROLL-TXT CODE; READ PREVIOUS OR READ
      *   NEXT LRTT RECORD INFORMATION.
      *

           PERFORM  3100-NEXT-LRTT
               THRU 3100-NEXT-LRTT-X.

018633*    MOVE WS-TWRK-AREA          TO L8090-AREA-INFO-TEXT.
018633*
018633*    PERFORM  9800-WRITE-TWRK
018633*        THRU 9800-WRITE-TWRK-X.
018633     PERFORM  COMM-2000-WRITE-TWRK
018633         THRU COMM-2000-WRITE-TWRK-X.



      *
       3500-PROCESS-LIST-X.
           EXIT.
      /
      *****************************************************************
      *  CREATE PROCESSING:
      *      CHECK FOR RECORD.  IF NOT FOUND CREATE RECORD
      *      IF FOUND  MAINTAIN THE RECORD
      *****************************************************************
       4000-PROCESS-CREATE.
      *
      *
018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.


           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
      *
      *    VALID CONTROL FIELDS MUST HAVE BEEN ENTERED.
      *
           PERFORM  7500-EDIT-KEY-FIELDS
               THRU 7500-EDIT-KEY-FIELDS-X.
           IF  WS-DATA-EDITS-FAILED
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.
      *
      *    BUILD CONTROL FIELDS.
      *
           PERFORM  7100-BUILD-LRTT-KEY
               THRU 7100-BUILD-LRTT-KEY-X.
      *
      *    CHECK RECORD EXISTENCE
      *    MSG: RECORD (@1) ALREADY EXISTS
      *
014221*    PERFORM  LRTT-1000-READ
014221*        THRU LRTT-1000-READ-X.
014221     PERFORM  LRTT-1000-READ-TWRK-TS
014221         THRU LRTT-1000-READ-TWRK-TS-X.

           IF  WLRTT-IO-OK
               IF  RLRTT-REQIR-TST-QTY NOT = WS-MAX-ENTRIES
                  MOVE +00            TO  WS-ARRAY-SUB
                  PERFORM 4200-CREATE-ARRAY
                      THRU 4200-CREATE-ARRAY-X
               ELSE
                  MOVE 'NS20500019'   TO WGLOB-MSG-REF-INFO
                  MOVE WLRTT-KEY      TO WGLOB-MSG-PARM (1)
                  MOVE RLRTT-TST-LTST-ID (WS-ARRAY-SUB)
                                      TO
                       WGLOB-MSG-PARM (2)
                  PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                  GO TO 4000-PROCESS-CREATE-X
557660        END-IF
           ELSE
               IF  WLRTT-IO-NOT-FOUND
                   PERFORM  4100-CREATE-NEW-RECORD
                       THRU 4100-CREATE-NEW-RECORD-X
557660         END-IF
557660     END-IF.
      *

013578     MOVE  RLRTT-TST-LTST-ID (WS-ARRAY-SUB) TO  MIR-LTST-ID.

013578*    MOVE  +1                   TO  WS-LINE.
013578*    PERFORM  9200-MOVE-NEXT-TO-SCREEN
013578*        THRU 9200-MOVE-NEXT-TO-SCREEN-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *
       4100-CREATE-NEW-RECORD.
      *
      *    CREATE NEW RECORD.
      *
           PERFORM  LRTT-1000-CREATE
               THRU LRTT-1000-CREATE-X.
      *
           MOVE +01                   TO  RLRTT-REQIR-TST-QTY.
           MOVE +01                   TO  WS-ARRAY-SUB.
           MOVE MIR-LTST-ID
                               TO  RLRTT-TST-LTST-ID (WS-ARRAY-SUB).
      *
           PERFORM  LRTT-1000-WRITE
               THRU LRTT-1000-WRITE-X.

014221     PERFORM  LRTT-1000-READ-TWRK-TS
014221         THRU LRTT-1000-READ-TWRK-TS-X.
      *
      *    MSG: RECORD CREATED - CONTINUE
      *
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
       4100-CREATE-NEW-RECORD-X.
           EXIT.
      /
      *
       4200-CREATE-ARRAY.
      *
      *    MSG: UPDATE COMPLETED
      *
           ADD +01            TO  WS-ARRAY-SUB.
           MOVE 'N'                   TO  INSERT-ARRAY-INDICATOR.
           MOVE 'N'                   TO  ADD-ARRAY-INDICATOR.
      *
      *    TEST NUMBER TO BE ADDED EQUAL TO FIRST TEST ENTRY
      *
           IF MIR-LTST-ID  =  RLRTT-TST-LTST-ID (WS-ARRAY-SUB)
               MOVE 'NS20500007'      TO WGLOB-MSG-REF-INFO
               MOVE WLRTT-KEY         TO WGLOB-MSG-PARM (1)
               MOVE RLRTT-TST-LTST-ID     (WS-ARRAY-SUB)
                                      TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4200-CREATE-ARRAY-X
557660     END-IF.
      *
      *    TEST NUMBER TO BE ADDED LESS THAN FIRST TEST ENTRY
      *
           IF MIR-LTST-ID < RLRTT-TST-LTST-ID (WS-ARRAY-SUB)
               MOVE 'Y'               TO  INSERT-ARRAY-INDICATOR
               MOVE RLRTT-REQIR-TST-QTY
                                      TO  WS-ENTRIES-SUB
               PERFORM  4210-INSERT-ARRAY
                   THRU 4210-INSERT-ARRAY-X
                   UNTIL WS-ENTRIES-SUB = ZERO
               PERFORM  4215-ADD-ARRAY
                   THRU 4215-ADD-ARRAY-X
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4200-CREATE-ARRAY-X
557660     END-IF.
      *
      *  - TEST NUMBER TO BE ADDED GREATER THAN FIRST TEST ENTRY
      *  - TEST NUMBER GREATER THAN LAST TEST ENTRY - ADD TEST TO END
      *  - TEST NUMBER LESS THAN LAST TEST ENTRY - READ THRU TO MAKE
      *     SURE TEST ENTRY DOES NOT ALREADY EXIST.
      *
           IF MIR-LTST-ID > RLRTT-TST-LTST-ID     (WS-ARRAY-SUB)
               MOVE RLRTT-REQIR-TST-QTY
                                      TO  WS-ENTRIES-SUB
               IF MIR-LTST-ID >
                                    RLRTT-TST-LTST-ID (WS-ENTRIES-SUB)
                   MOVE 'Y'           TO  ADD-ARRAY-INDICATOR
                   MOVE RLRTT-REQIR-TST-QTY
                                      TO WS-ARRAY-SUB
                   ADD +01  TO  WS-ARRAY-SUB
                   PERFORM 4215-ADD-ARRAY
                       THRU 4215-ADD-ARRAY-X
                   MOVE 'XS00000008'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   PERFORM  4205-READ-NEXT-OR-INSERT
                       THRU 4205-READ-NEXT-OR-INSERT-X
557660         END-IF
557660     END-IF.
      *
       4200-CREATE-ARRAY-X.
           EXIT.
      /
      *-------------------------
       4205-READ-NEXT-OR-INSERT.
      *-------------------------

           MOVE 'Y'                  TO  INSERT-ARRAY-INDICATOR.
           MOVE RLRTT-REQIR-TST-QTY  TO  WS-ENTRIES-SUB.

           PERFORM  4220-READ-NEXT-ARRAY
               THRU 4220-READ-NEXT-ARRAY-X
              UNTIL (MIR-LTST-ID < RLRTT-TST-LTST-ID (WS-ARRAY-SUB))
                 OR (MIR-LTST-ID = RLRTT-TST-LTST-ID (WS-ARRAY-SUB)).

           IF  (MIR-LTST-ID =  RLRTT-TST-LTST-ID (WS-ARRAY-SUB))
               MOVE 'NS20500007'  TO WGLOB-MSG-REF-INFO
               MOVE WLRTT-KEY     TO WGLOB-MSG-PARM (1)
               MOVE RLRTT-TST-LTST-ID (WS-ARRAY-SUB)
                                  TO WGLOB-MSG-PARM (2)
               MOVE 'N'           TO INSERT-ARRAY-INDICATOR
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  4210-INSERT-ARRAY
                   THRU 4210-INSERT-ARRAY-X
                  UNTIL WS-ENTRIES-SUB < WS-ARRAY-SUB

               PERFORM  4215-ADD-ARRAY
                   THRU 4215-ADD-ARRAY-X

               MOVE 'XS00000008'  TO WGLOB-MSG-REF-INFO

               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

557660     END-IF.

       4205-READ-NEXT-OR-INSERT-X.
           EXIT.
      /
      *
       4210-INSERT-ARRAY.
      *
           MOVE WS-ENTRIES-SUB        TO  WS-INSERT-SUB.
           ADD  +01             TO  WS-INSERT-SUB.

014221*    PERFORM  LRTT-1000-READ-FOR-UPDATE
014221*        THRU LRTT-1000-READ-FOR-UPDATE-X.

014221     PERFORM  LRTT-2000-UPDATE-TWRK-TS
014221         THRU LRTT-2000-UPDATE-TWRK-TS-X.

014221     IF MIR-RETRN-TS-MISMATCH
014221*MSG:     TIMESTAMP MISMATCH - PROCESS NOT COMPLETE
014221        MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221        MOVE 'LRTT'                       TO WGLOB-MSG-PARM (01)
014221        MOVE WLRTT-KEY                    TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        PERFORM LRTT-3000-UNLOCK
014221           THRU LRTT-3000-UNLOCK-X
014221        GO TO 4210-INSERT-ARRAY-X
014221     END-IF.


           MOVE RLRTT-TST-LTST-ID     (WS-ENTRIES-SUB)
                               TO RLRTT-TST-LTST-ID (WS-INSERT-SUB).

           PERFORM  LRTT-2000-REWRITE
               THRU LRTT-2000-REWRITE-X.

014221     PERFORM  LRTT-1000-READ-TWRK-TS
014221         THRU LRTT-1000-READ-TWRK-TS-X.

           SUBTRACT +01 FROM  WS-ENTRIES-SUB.
      *
       4210-INSERT-ARRAY-X.
           EXIT.
      *
      *
      *
       4215-ADD-ARRAY.
      *
014221*    PERFORM  LRTT-1000-READ-FOR-UPDATE
014221*        THRU LRTT-1000-READ-FOR-UPDATE-X.

014221     PERFORM  LRTT-2000-UPDATE-TWRK-TS
014221         THRU LRTT-2000-UPDATE-TWRK-TS-X.

014221     IF MIR-RETRN-TS-MISMATCH
014221*MSG:     TIMESTAMP MISMATCH - PROCESS NOT COMPLETE
014221        MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221        MOVE 'LRTT'                       TO WGLOB-MSG-PARM (01)
014221        MOVE WLRTT-KEY                    TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        PERFORM LRTT-3000-UNLOCK
014221           THRU LRTT-3000-UNLOCK-X
014221        GO TO 4215-ADD-ARRAY-X
014221     END-IF.

           MOVE MIR-LTST-ID
                               TO  RLRTT-TST-LTST-ID (WS-ARRAY-SUB).

           IF ADD-TO-END
               MOVE  WS-ARRAY-SUB     TO  RLRTT-REQIR-TST-QTY
           ELSE
               IF INSERT-ARRAY
                   MOVE  RLRTT-REQIR-TST-QTY
                                         TO  WS-INSERT-SUB
                   ADD   +01             TO  WS-INSERT-SUB
                   MOVE  WS-INSERT-SUB   TO  RLRTT-REQIR-TST-QTY
               ELSE
                   MOVE +01              TO  RLRTT-REQIR-TST-QTY
557660         END-IF
557660     END-IF.

           PERFORM  LRTT-2000-REWRITE
               THRU LRTT-2000-REWRITE-X.

014221     PERFORM  LRTT-1000-READ-TWRK-TS
014221         THRU LRTT-1000-READ-TWRK-TS-X.


           MOVE  'N'                  TO  INSERT-ARRAY-INDICATOR.
           MOVE  'N'                  TO  ADD-ARRAY-INDICATOR.
      *
       4215-ADD-ARRAY-X.
           EXIT.
      /
      *
       4220-READ-NEXT-ARRAY.
      *
           ADD +01  TO  WS-ARRAY-SUB.
      *
       4220-READ-NEXT-ARRAY-X.
           EXIT.
      *
      *
      *
       4230-READ-PREV-ARRAY.
      *
           ADD -01  TO  WS-ARRAY-SUB.
      *
       4230-READ-PREV-ARRAY-X.
           EXIT.
      *
      /
      *****************************************************************
      *  DELETE PROCESSING:
      *****************************************************************
       6000-PROCESS-DELETE.
      *

013578*    PERFORM  9700-RETRIEVE-TWRK
013578*        THRU 9700-RETRIEVE-TWRK-X.

013578*    IF  L8090-RETRN-OK
013578*        MOVE L8090-AREA-INFO-TEXT TO WS-TWRK-AREA
013578*    END-IF.

018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.


           PERFORM  7100-BUILD-LRTT-KEY
               THRU 7100-BUILD-LRTT-KEY-X.
014221*    PERFORM  LRTT-1000-READ-FOR-UPDATE
014221*        THRU LRTT-1000-READ-FOR-UPDATE-X.
014221     PERFORM  LRTT-2000-UPDATE-TWRK-TS
014221         THRU LRTT-2000-UPDATE-TWRK-TS-X.

014221     IF MIR-RETRN-TS-MISMATCH
014221*MSG:     TIMESTAMP MISMATCH - PROCESS NOT COMPLETE
014221        MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221        MOVE 'LRTT'                       TO WGLOB-MSG-PARM (01)
014221        MOVE WLRTT-KEY                    TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        MOVE SPACES                       TO MIR-REQIR-ID
014221        PERFORM 9100-BLANK-DATA-FIELDS
014221           THRU 9100-BLANK-DATA-FIELDS-X
014221        PERFORM LRTT-3000-UNLOCK
014221           THRU LRTT-3000-UNLOCK-X
014221        GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

      *
      *    MSG: RECORD (@1) LOST IN DELETE - CONTACT SYSTEMS
      *     OR: DELETE COMPLETED - CONTINUE
      *
           IF  WLRTT-IO-NOT-FOUND
               MOVE  'XS00000010'     TO WGLOB-MSG-REF-INFO
               MOVE  WLRTT-KEY        TO  WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF RLRTT-REQIR-TST-QTY = +01
                   MOVE 'XS00000011'  TO WGLOB-MSG-REF-INFO
                   PERFORM LRTT-1000-DELETE
                       THRU LRTT-1000-DELETE-X
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   PERFORM  6210-DELETE-ARRAY
                       THRU 6210-DELETE-ARRAY-X
557660         END-IF
557660     END-IF.
      *

013578* BLANK OUT THE TEST ID FIELD

013578     MOVE  SPACES   TO  MIR-REQIR-ID.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
      *
      *
      *
       6000-PROCESS-DELETE-X.
           EXIT.
      /
       6210-DELETE-ARRAY.
      *
           MOVE +1                    TO  WS-ARRAY-SUB.
           PERFORM 4220-READ-NEXT-ARRAY
               THRU 4220-READ-NEXT-ARRAY-X
               UNTIL WS-ARRAY-SUB > RLRTT-REQIR-TST-QTY
                  OR MIR-LTST-ID =
                     RLRTT-TST-LTST-ID (WS-ARRAY-SUB).
      *
           IF WS-ARRAY-SUB > RLRTT-REQIR-TST-QTY
               MOVE 'NS20500008'      TO WGLOB-MSG-REF-INFO
               MOVE WLRTT-KEY         TO WGLOB-MSG-PARM (1)
               MOVE RLRTT-TST-LTST-ID     (WS-ARRAY-SUB)
                                      TO WGLOB-MSG-PARM (2)
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF WS-ARRAY-SUB = RLRTT-REQIR-TST-QTY
                  PERFORM  6220-MOVE-SPACES-TO-ARRAY
                      THRU 6220-MOVE-SPACES-TO-ARRAY-X
               ELSE
                   PERFORM  6220-MOVE-SPACES-TO-ARRAY
                       THRU 6220-MOVE-SPACES-TO-ARRAY-X
                   MOVE RLRTT-REQIR-TST-QTY
                                      TO  WS-ENTRIES-SUB
                   ADD +01                  TO  WS-ENTRIES-SUB
                   MOVE WS-ARRAY-SUB  TO  WS-INSERT-SUB
                   ADD +01                  TO  WS-INSERT-SUB
014221*            PERFORM  LRTT-1000-READ-FOR-UPDATE
014221*                THRU LRTT-1000-READ-FOR-UPDATE-X
014221             PERFORM  LRTT-2000-UPDATE-TWRK-TS
014221                 THRU LRTT-2000-UPDATE-TWRK-TS-X
014221             IF MIR-RETRN-TS-MISMATCH
014221*MSG:     TIMESTAMP MISMATCH - PROCESS NOT COMPLETE
014221                 MOVE 'XS00000303'    TO WGLOB-MSG-REF-INFO
014221                 MOVE 'LRTT'          TO WGLOB-MSG-PARM (01)
014221                 MOVE WLRTT-KEY       TO WGLOB-MSG-PARM (02)
014221                 PERFORM  0260-1000-GENERATE-MESSAGE
014221                     THRU 0260-1000-GENERATE-MESSAGE-X
014221                 PERFORM LRTT-3000-UNLOCK
014221                    THRU LRTT-3000-UNLOCK-X
014221                 GO TO 6210-DELETE-ARRAY-X
014221             END-IF
                   PERFORM  6230-MOVE-ARRAY-UP
                       THRU 6230-MOVE-ARRAY-UP-X
                       UNTIL WS-INSERT-SUB > WS-ENTRIES-SUB
                   PERFORM  LRTT-2000-REWRITE
                       THRU LRTT-2000-REWRITE-X
014221             PERFORM  LRTT-1000-READ-TWRK-TS
014221                 THRU LRTT-1000-READ-TWRK-TS-X
                   MOVE 'NS20500010'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.
      *
       6210-DELETE-ARRAY-X.
           EXIT.
      /
      *
       6220-MOVE-SPACES-TO-ARRAY.
      *
           MOVE 'NS20500009'          TO WGLOB-MSG-REF-INFO.
           MOVE WLRTT-KEY             TO WGLOB-MSG-PARM (1).
           MOVE RLRTT-TST-LTST-ID     (WS-ARRAY-SUB)
                                      TO WGLOB-MSG-PARM (2).
      *
           MOVE RLRTT-REQIR-TST-QTY   TO   WS-ENTRIES-SUB.
           SUBTRACT +01            FROM  WS-ENTRIES-SUB.
           MOVE WS-ENTRIES-SUB    TO    RLRTT-REQIR-TST-QTY.
           MOVE SPACES            TO RLRTT-TST-LTST-ID (WS-ARRAY-SUB).
      *
           PERFORM  LRTT-2000-REWRITE
               THRU LRTT-2000-REWRITE-X.
      *
014221     PERFORM  LRTT-1000-READ-TWRK-TS
014221         THRU LRTT-1000-READ-TWRK-TS-X.

      *
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
       6220-MOVE-SPACES-TO-ARRAY-X.
           EXIT.
      *
       6230-MOVE-ARRAY-UP.
      *
           MOVE RLRTT-TST-LTST-ID (WS-INSERT-SUB) TO
                           RLRTT-TST-LTST-ID (WS-ARRAY-SUB).
           MOVE SPACES         TO RLRTT-TST-LTST-ID (WS-INSERT-SUB).
      *
           ADD +01   TO  WS-INSERT-SUB.
           ADD +01   TO  WS-ARRAY-SUB.
      *
       6230-MOVE-ARRAY-UP-X.
           EXIT.
      /
      *****************************************************************
      *  BUILD LRTT KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
      *****************************************************************
       7100-BUILD-LRTT-KEY.
      *
           MOVE MIR-REQIR-ID          TO WLRTT-REQIR-ID.
           MOVE MIR-LAB-ID            TO WLRTT-LAB-ID.
           MOVE MIR-REQIR-LTST-RGN-CD TO WLRTT-REQIR-LTST-RGN-CD.
      *
       7100-BUILD-LRTT-KEY-X.
           EXIT.
      *
      *****************************************************************
      *  EDIT CONTROL FIELDS: ALL KEY FIELDS MUT BE EDITED FOR VALID
      *  VALUES BEFORE A CREATE WILL BE ALLOWED.
      *****************************************************************
       7500-EDIT-KEY-FIELDS.
      *
           MOVE  WS-OK                TO  WS-DATA-EDITS.
      *
           PERFORM 7510-EDIT-REQ-CODE
              THRU 7510-EDIT-REQ-CODE-X.
      *
           PERFORM 7520-EDIT-LAB-CODE
              THRU 7520-EDIT-LAB-CODE-X.
      *
           PERFORM 7530-EDIT-REGION
              THRU 7530-EDIT-REGION-X.
      *
           PERFORM 7540-EDIT-LAB-TEST-NO
              THRU 7540-EDIT-LAB-TEST-NO-X.
      *
       7500-EDIT-KEY-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT REQUIREMENT CODE
      *****************************************************************
       7510-EDIT-REQ-CODE.
      *
      *  SET UP KEY FOR READ
      *
           PERFORM  7515-BUILD-RTAB-KEY
               THRU 7515-BUILD-RTAB-KEY-X.
      *
           PERFORM RTAB-1000-READ
              THRU RTAB-1000-READ-X.
      *
           IF WRTAB-IO-NOT-FOUND
               MOVE 'NS20500002'      TO WGLOB-MSG-REF-INFO
               MOVE WRTAB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE  WS-FAILED        TO  WS-DATA-EDITS
           ELSE
               IF WS-BUS-FCN-ATTACH
557660         AND RRTAB-LAB-ID = SPACES
                   MOVE 'NS20500018'  TO WGLOB-MSG-REF-INFO
                   MOVE WRTAB-KEY     TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE  WS-FAILED    TO  WS-DATA-EDITS
557660         END-IF
557660     END-IF.
      *
       7510-EDIT-REQ-CODE-X.
           EXIT.
      *
      *****************************************************************
      *  BUILD RTAB KEY: VALIDATE REQUIREMENT CODE ENTERED EXISTS ON
      *  RTAB.
      *****************************************************************
      *
       7515-BUILD-RTAB-KEY.
      *
           MOVE MIR-REQIR-ID          TO WRTAB-REQIR-ID.
      *
       7515-BUILD-RTAB-KEY-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT LAB CODE
      *****************************************************************
       7520-EDIT-LAB-CODE.
      *
           MOVE MIR-LAB-ID            TO  WEDIT-ETBL-VALU-ID.
           PERFORM  LABC-1000-EDIT-LAB-CODE
               THRU LABC-1000-EDIT-LAB-CODE-X.
      *
           IF NOT WEDIT-IO-OK
               MOVE  'NS20500003'     TO  WGLOB-MSG-REF-INFO
               MOVE WEDIT-ETBL-TYP-ID TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE  WS-FAILED        TO  WS-DATA-EDITS
557660     END-IF.
      *
       7520-EDIT-LAB-CODE-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT REGION (LOCATION CODE)
      *****************************************************************
       7530-EDIT-REGION.
      *
           IF  MIR-REQIR-LTST-RGN-CD  =  SPACES
               GO TO  7530-EDIT-REGION-X
557660     END-IF.
      *
006002     MOVE MIR-REQIR-LTST-RGN-CD TO  WCTLC-CTRY-LOC-CD.
006002     MOVE WGLOB-COUNTRY-CODE    TO  WCTLC-CTRY-CD.
006002     MOVE WGLOB-COMPANY-CODE    TO  WCTLC-CO-ID.
006002     SET  WCTLC-CTRY-LOC-TYP-CURRENT TO TRUE.

006002*    PERFORM  CLOC-1000-EDIT-CURR-LOCATION
006002*        THRU CLOC-1000-EDIT-CURR-LOCATION-X.

006002     PERFORM  CTLC-1000-READ
006002         THRU CTLC-1000-READ-X.


006002*    IF NOT WEDIT-IO-OK
006002     IF  NOT WCTLC-IO-OK
               MOVE  'NS20500004'         TO  WGLOB-MSG-REF-INFO
006002*        MOVE WEDIT-ETBL-TYP-ID TO WGLOB-MSG-PARM (1)
006002         MOVE MIR-REQIR-LTST-RGN-CD TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE  WS-FAILED            TO  WS-DATA-EDITS
557660     END-IF.
      *
       7530-EDIT-REGION-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT LAB TEST NUMBER
      *****************************************************************
       7540-EDIT-LAB-TEST-NO.
      *
           IF  MIR-LTST-ID  =  SPACES
               IF  (WS-BUS-FCN-ATTACH)
557660         OR  (WS-BUS-FCN-REMOVE)
                   MOVE  'NS20500005' TO  WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE  WS-FAILED    TO  WS-DATA-EDITS
                   GO TO 7540-EDIT-LAB-TEST-NO-X
               ELSE
                   GO TO 7540-EDIT-LAB-TEST-NO-X
557660         END-IF
557660     END-IF.
      *
           MOVE MIR-LTST-ID     TO  WEDIT-ETBL-VALU-ID.
           PERFORM  TSTN-1000-EDIT-TEST-NUMBER
               THRU TSTN-1000-EDIT-TEST-NUMBER-X.
      *
           IF NOT WEDIT-IO-OK
               MOVE  'NS20500006'     TO  WGLOB-MSG-REF-INFO
               MOVE WEDIT-ETBL-TYP-ID TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE  WS-FAILED        TO  WS-DATA-EDITS
557660     END-IF.
      *
       7540-EDIT-LAB-TEST-NO-X.
           EXIT.
      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
       9100-BLANK-DATA-FIELDS.
      *
      *    BLANK OUT DATA ON GIVEN SCREEN
      *
           PERFORM  9110-BLANK-DATA-FIELDS-1
               THRU 9110-BLANK-DATA-FIELDS-1-X.
      *
       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES ON SCREEN 1
      *****************************************************************
       9110-BLANK-DATA-FIELDS-1.
      *
      *    MOVE  SPACES               TO  MIR-TST-LTST-ID-G.
           MOVE  SPACES               TO  MIR-LTST-ID-G.
       9110-BLANK-DATA-FIELDS-1-X.
           EXIT.
      *
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
       9200-MOVE-NEXT-TO-SCREEN.
      *
      *    MOVE DATA FOR GIVEN SCREEN
      *
           PERFORM  9210-MOVE-RECORD-TO-SCREEN-1
               THRU 9210-MOVE-RECORD-TO-SCREEN-1-X.
      *
           ADD  +1  TO  WS-LINE.
           ADD  +1  TO  WS-ARRAY-SUB.
      *
       9200-MOVE-NEXT-TO-SCREEN-X.
           EXIT.
      *
      *****************************************************************
      *  MOVE FILE VALUES TO SCREEN 1
      *****************************************************************
       9210-MOVE-RECORD-TO-SCREEN-1.
      *
           MOVE  RLRTT-TST-LTST-ID     (WS-ARRAY-SUB)
                                      TO  MIR-LTST-ID-T (WS-LINE).

013578*    PERFORM 9215-MOVE-EDIT-TABLE-DESC
013578*        THRU 9215-MOVE-EDIT-TABLE-DESC-X.

      *
       9210-MOVE-RECORD-TO-SCREEN-1-X.
           EXIT.
      *
      *9215-MOVE-EDIT-TABLE-DESC.
      *
      *   PICK UP LAB TEST NUMBER DESCRIPTION FROM THE 'TSTNO'
      *   EDIT TABLE, AND MOVE TO MIR RECORD FOR DISPLAY.
      *
      *    MOVE  RLRTT-TST-LTST-ID     (WS-ARRAY-SUB)
      *                               TO WEDIT-ETBL-VALU-ID.
      *
      *
      *    IF WEDIT-IO-OK
      *        MOVE  REDIT-ETBL-DESC-TXT
      *                               TO  MIR-TST-1-LTST-ID-T (WS-LINE)
557660*    END-IF.
      *
      *9215-MOVE-EDIT-TABLE-DESC-X.
      *    EXIT.
      *
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
       9220-MOVE-PREV-TO-SCREEN.
      *
      *    MOVE DATA FOR GIVEN SCREEN
      *
           PERFORM  9210-MOVE-RECORD-TO-SCREEN-1
               THRU 9210-MOVE-RECORD-TO-SCREEN-1-X.
      *
           ADD  -1  TO  WS-LINE.
           ADD  -1  TO  WS-ARRAY-SUB.
      *
       9220-MOVE-PREV-TO-SCREEN-X.
           EXIT.
      *
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
       9300-SETUP-MSIN-REFERENCE.
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
      *
       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
023514     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
023514
023514     SET WS-DEFAULT-OK-SW               TO TRUE.
023514     SET WS-DEFAULT-FAILED-SW           TO TRUE.
023514     SET WS-DEFAULT-MAX-ENTRIES         TO TRUE.
023514     SET WS-DEFAULT-DISPLAY-LINES       TO TRUE.
025970
025970     MOVE  MIR-BUS-FCN-ID               TO  WS-BUS-FCN-ID.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

018633*-------------------
018633*9500-BUILD-TWRK-KEY.
018633*-------------------
018633*
018633*    SET L8090-USAGE-COMM TO TRUE.
018633*    MOVE WS-TWRK-KEY TO L8090-BUS-FCN-ID.
018633*    MOVE ZEROS TO L8090-TEMP-WRK-SEQ-NUM.
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9700-RETRIEVE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-2000-RETRIEVE-TWRK
018633*        THRU 8090-2000-RETRIEVE-TWRK-X.
018633*
018633*9700-RETRIEVE-TWRK-X.
018633*    EXIT.
018633*
018633*
018633*-----------------
018633*9800-WRITE-TWRK.
018633*-----------------
018633*
018633*    PERFORM 9500-BUILD-TWRK-KEY
018633*       THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    MOVE 300           TO L8090-AREA-LEN.
018633*
018633*    PERFORM 8090-1000-WRITE-TWRK
018633*       THRU 8090-1000-WRITE-TWRK-X.
018633*
018633*
018633*9800-WRITE-TWRK-X.
018633*    EXIT.
018633*
018633*-------------------
018633*9900-DELETE-TWRK.
018633*-------------------
018633*
018633*    PERFORM  9500-BUILD-TWRK-KEY
018633*        THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM  8090-3000-DELETE-TWRK
018633*        THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
018633*
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
      *
006002*COPY CCPECLOC.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY LRTT
014221                          '$VAR2' BY 'LRTT'.
      /
       COPY XCPPEXIT.
      /
       COPY XCPPINIT.
      /
018633 COPY XCPSCOMM.
018633 COPY XCPPCOMM.
018633
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS                                 *
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018633 COPY XCPS8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES - MESSAGES
      *****************************************************************
       COPY NCPELABC.
      /
       COPY NCPETSTN.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY NCPALRTT.
      /
       COPY NCPBLRTT.
      /
       COPY CCPNEDIT.
      /
       COPY NCPNLRTT.
      /
       COPY NCPNRTAB.
      /
       COPY NCPULRTT.
      /
016537*COPY NCPVLRTT.
      /
       COPY NCPXLRTT.
      /
       COPY NCPCLRTT.
      /
006002 COPY XCPNCTLC.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *
      *****************************************************************
      **                 END OF PROGRAM NSOM2050                     **
      *****************************************************************
