      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM0360.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM0360                                         **
      **  REMARKS:  UWMX - MAINTAIN UNDERWRITING MATRIX TABLE        **
      **            THIS PROGRAM IS USED TO CREATE, MODIFY, OR REVIEW**
      **            THE UNDERWRITING TESTS TO BE PERFORMED ON A      **
      **            CLIENT AS PART OF THE CLEAR CASE TESTING PROCESS.**
      **            THE TESTS WILL BE DIVIDED INTO SIMPLE AND COMPLEX**
      **            TESTS.  SIMPLE TESTS INVOLVE CHECKING THE        **
      **            RESPONSE TO INDIVIDUAL APPLICATION QUESTIONS FOR **
      **            UNACCEPTABLE VALUES.  COMPLEX TESTS INVOLVE      **
      **            COMPARING A NUMBER OF RELATED RESPONSES OR       **
      **            SEARCHING FOR OTHER INFORMATION THAT DOES NOT    **
      **            ACTUALLY APPEAR ON THE APPLICATION.              **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       DATA ARCHITECTURE MODIFICATIONS                  **
557660**  5.5       CODE CLEANUP/STANDARDIZATION                     **
557698**  5.5       MODIFICATIONS TO SUPPORT MIXED-CASE DATA         **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
008445**  5.5.2     GENERATE MIR FROM TECH ARCH DATA BASE            **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010418**  5.6       MULTI-COMPANY                                    **
010645**  5.6       VARIATIONS BY LOCATION - UW AND NB               **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
013597**  6.2       NORMALIZE UWMX                                   **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017692**  6.2       PCR - DATE RANGE TEST                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
017087**  6.4       CHANGE FIELD NAMES FROM GRP TO GR ABBREVIATION   **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************


       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0360'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.


       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'UWMX'.
025970*    05  WS-KEY-MATCH                 PIC X(01)  VALUE 'Y'.
025970     05  WS-KEY-MATCH                 PIC X(01).
025970         88  WS-DEFAULT-KEY-MATCH                VALUE 'Y'.
               88  WS-INVALID-KEY-MATCH                VALUE 'N'.
           05  WS-DATA-EDITS                PIC X(01).
               88  WS-DATA-EDITS-OK                    VALUE 'Y'.
           05  WS-CROSS-EDITS               PIC X(01).
               88  WS-CROSS-EDITS-OK                   VALUE 'Y'.
010645         88  WS-CROSS-EDITS-NOT-OK               VALUE 'N'.
           05  WS-VALIDATE-CONTROL          PIC X(01)  VALUE SPACES.
               88  WS-INVALID-CONTROL                  VALUE 'Y'.
           05  WS-VALIDATE-CODES            PIC X(01)  VALUE SPACES.
               88  WS-VALID-CODES                      VALUE 'Y'.
           05  WS-VALIDATE-FLD-NAME         PIC X(01)  VALUE SPACES.
               88  WS-VALID-FLD-NAME                   VALUE 'Y'.
           05  WS-VALIDATE-FORM             PIC X(01)  VALUE SPACES.
               88  WS-VALID-FORM                       VALUE 'Y'.
010645     05  WS-VALIDATE-LOC-GR           PIC X(01)  VALUE SPACES.
010645         88  WS-VALID-LOC-GR                     VALUE 'Y'.
010418     05  WS-VALIDATE-SBSDRY-CO-ID     PIC X(01)  VALUE SPACES.
010418         88  WS-VALID-SBSDRY-CO-ID               VALUE 'Y'.
           05  WS-SW-SUBSET                 PIC X(01)  VALUE SPACES.
               88  WS-SW-SUBSET-SET                    VALUE 'Y'.
           05  WS-END-DUP-LOOP              PIC X(01)  VALUE SPACES.
               88  WS-DUP-LOOP-END                     VALUE 'Y'.
010645         88  WS-NOT-DUP-LOOP-END                 VALUE 'N'.
025970*    05  WS-SOURCE.
025970*        10  WS-SOURCE-TEXT           PIC X(04)  VALUE 'NCCC'.
025970*        10  WS-SOURCE-SUFFIX         PIC X(01)  VALUE SPACES.
025970*        10  WS-SOURCE-TYPE           PIC X(01)  VALUE SPACES.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-ID-VALID      VALUE '0360' '0361' '0362'
                                                  '0363' '0364'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '0360'.
               88  WS-BUS-FCN-CREATE        VALUE '0361'.
               88  WS-BUS-FCN-UPDATE        VALUE '0362'.
               88  WS-BUS-FCN-DELETE        VALUE '0363'.
               88  WS-BUS-FCN-LIST          VALUE '0364'.
           05  WS-NUM-99                    PIC 9(02)  VALUE ZEROS.
           05  WS-NUM-999                   PIC 9(03)  VALUE ZEROS.
           05  WS-NUM-999-RED               REDEFINES  WS-NUM-999.
               10  WS-NUM-PART1             PIC 9(01).
               10  WS-NUM-PART2             PIC 9(02).
           05  WS-AGE-999                   PIC 9(03)  VALUE ZEROS.
           05  WS-AGE-999-RED               REDEFINES  WS-AGE-999.
               10  WS-AGE-PART1             PIC 9(01).
               10  WS-AGE-PART2             PIC 9(02).
           05  WS-NUM-9999                  PIC 9(04)  VALUE ZEROS.
           05  WS-NUM-9-LEN5                PIC 9(05)  VALUE ZEROS.
008455*    05  WS-NUM-9-LEN9                PIC 9(09)  VALUE ZEROS.
           05  WS-SAVE-ACTION               PIC X      VALUE SPACES.
               88  WS-VALID-ACTION          VALUE 'P' 'F' 'S'.
           05  WS-SAVE-TEST-TYPE            PIC X      VALUE SPACES.
               88  WS-VALID-TEST-TYPE       VALUE 'C' 'D' 'L' 'N' 'Y'.
               88  WS-TEST-TYPE-COMPLEX     VALUE 'C'.
               88  WS-TEST-TYPE-YESNO       VALUE 'Y'.
               88  WS-TEST-TYPE-NUMERIC     VALUE 'N'.
               88  WS-TEST-TYPE-LIST        VALUE 'L'.
               88  WS-TEST-TYPE-DATE        VALUE 'D'.
           05  WS-TEST-INCEX-CD             PIC X      VALUE SPACES.
               88  WS-VALID-INCEX-CD        VALUE 'I' 'A' 'E'.
010645     05  WS-TEST-FINCEX-CD            PIC X      VALUE SPACES.
010645         88  WS-VALID-FINCEX-CD       VALUE 'I' 'A' 'E'.
010645         88  WS-FINCEX-CD-A           VALUE 'A'.
010645     05  WS-TEST-LINCEX-CD            PIC X      VALUE SPACES.
010645         88  WS-VALID-LINCEX-CD       VALUE 'I' 'A' 'E'.
010645         88  WS-LINCEX-CD-A           VALUE 'A'.
010645     05  WS-TEST-SINCEX-CD            PIC X      VALUE SPACES.
010645         88  WS-VALID-SINCEX-CD       VALUE 'I' 'A' 'E'.
010645         88  WS-SINCEX-CD-A           VALUE 'A'.
           05  WS-SAVE-DATE-TYPE            PIC X      VALUE SPACES.
               88  WS-VALID-DATE-TYPE       VALUE 'S' 'R'.
           05  WS-SAVE-DATE-YMD             PIC X      VALUE SPACES.
               88  WS-VALID-DATE-YMD        VALUE 'Y' 'M' 'D'.
           05  WS-RQCD-MSG-EXISTS           PIC X      VALUE SPACES.
               88  WS-NO-RQCD-MSG           VALUE 'N'.
010645         88  WS-RQCD-MSG-DOES-EXIST   VALUE 'Y'.
           05  WS-HOLD-AGE                  PIC X(02).
           05  WS-WORK-AGE                  REDEFINES WS-HOLD-AGE.
               10  WS-WORK-AGE-NUM          PIC 9(02).
           05  WS-RQCD-REPEATS-X.
               10  WS-RQCD-REPEATS          PIC X(05)
                                            OCCURS 6 TIMES.
025970*    05  WS-RQCD                      PIC S9(03) COMP-3
025970*                                     VALUE +1.
025970     05  WS-RQCD                      PIC S9(03) COMP-3.
025970         88  WS-DEFAULT-RQCD          VALUE +1.
025970*    05  WS-MAX-RQCD                  PIC S9(03) COMP-3
025970*                                      VALUE +6.
025970*    05  WS-RQCD-OUT                  PIC S9(03) COMP-3
025970*                                     VALUE +1.
025970     05  WS-RQCD-OUT                  PIC S9(03) COMP-3.
025970         88  WS-DEFAULT-RQCD-OUT      VALUE +1.
025970*    05  WS-RQCD-MSG                  PIC S9(03) COMP-3
025970*                                     VALUE +1.
025970     05  WS-RQCD-MSG                  PIC S9(03) COMP-3.
025970         88  WS-DEFAULT-RQCD-MSG      VALUE +1.
025970*    05  WS-RQCD-RPT                  PIC S9(03) COMP-3
025970*                                     VALUE +1.
025970     05  WS-RQCD-RPT                  PIC S9(03) COMP-3.
025970         88  WS-DEFAULT-RQCD-RPT      VALUE +1.
016548*    05  WS-UWMF-SUB                  PIC S9(04) COMP.
016548     05  WS-UWMF-SUB                  PIC S9(04) BINARY.
016548*    05  WS-MAX-UWMF                  PIC S9(04) COMP
025970*    05  WS-MAX-UWMF                  PIC S9(04) BINARY
025970*                                     VALUE +10.
016548*    05  WS-LCGP-SUB                  PIC S9(04) COMP.
016548     05  WS-LCGP-SUB                  PIC S9(04) BINARY.
016548*    05  WS-MAX-LCGP                  PIC S9(04) COMP
025970*    05  WS-MAX-LCGP                  PIC S9(04) BINARY
025970*                                     VALUE +12.
016548*    05  WS-SBCO-SUB                  PIC S9(04) COMP.
016548     05  WS-SBCO-SUB                  PIC S9(04) BINARY.
016548*    05  WS-MAX-SBCO                  PIC S9(04) COMP
025970*    05  WS-MAX-SBCO                  PIC S9(04) BINARY
025970*                                     VALUE +10.
016548*    05  WS-MAX-SCREEN-LINES          PIC S9(04) COMP   VALUE +12.
025970*    05  WS-MAX-SCREEN-LINES          PIC S9(04)
025970*                                     BINARY   VALUE +12.
016548*    05  WS-LINE                      PIC S9(04) COMP.
016548     05  WS-LINE                      PIC S9(04) BINARY.
010645*    05  WS-FORM-TYPE                 PIC X(10).
010645*    05  WS-FORM-TYPE-RED             REDEFINES WS-FORM-TYPE.
010645*        10  WS-FORM-TYP01            PIC X(01).
010645*        10  WS-FORM-TYP02            PIC X(01).
010645*        10  WS-FORM-TYP03            PIC X(01).
010645*        10  WS-FORM-TYP04            PIC X(01).
010645*        10  WS-FORM-TYP05            PIC X(01).
010645*        10  WS-FORM-TYP06            PIC X(01).
010645*        10  WS-FORM-TYP07            PIC X(01).
010645*        10  WS-FORM-TYP08            PIC X(01).
010645*        10  WS-FORM-TYP09            PIC X(01).
010645*        10  WS-FORM-TYP10            PIC X(01).
010645*    05  WS-ERR-FORM-TYPE             PIC X(10).
010645*    05  WS-ERR-FORM                  REDEFINES WS-ERR-FORM-TYPE.
010645*        10  WS-ERR-TYP01             PIC X(01).
010645*        10  WS-ERR-TYP02             PIC X(01).
010645*        10  WS-ERR-TYP03             PIC X(01).
010645*        10  WS-ERR-TYP04             PIC X(01).
010645*        10  WS-ERR-TYP05             PIC X(01).
010645*        10  WS-ERR-TYP06             PIC X(01).
010645*        10  WS-ERR-TYP07             PIC X(01).
010645*        10  WS-ERR-TYP08             PIC X(01).
010645*        10  WS-ERR-TYP09             PIC X(01).
010645*        10  WS-ERR-TYP10             PIC X(01).
010418     05  WS-SBSDRY-CO-CNT             PIC 9(02) VALUE ZERO.
010418     05  WS-ERR-SBSDRY-CO-ID          PIC X(01).
013578*
013578     05  WS-TABULAR-INFO.
013578         10  WS-APPFORM-INFO.
013578             15  WS-APP-FORM-TYP      OCCURS 10
013578                                      PIC X(01).
013578         10  WS-REQIR-INFO.
013578             15  WS-REQIR-ID          OCCURS 6
013578                                      PIC X(05).
013578         10  WS-LOCGR-INFO.
013578             15  WS-LOC-GR-CD         OCCURS 12
013578                                      PIC X(03).
013578         10  WS-SBSDRY-CO-INFO.
013578             15  WS-SBSDRY-CO-ID      OCCURS 10
013578                                      PIC X(02).
013578
025970/
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-DEFAULT-TRANS-NAME               VALUE 'UWMX'.
025970     05  WS-SOURCE.
025970         10  WS-SOURCE-TEXT           PIC X(04).
025970             88  WS-DEFAULT-SOURCE-TEXT          VALUE 'NCCC'.
025970         10  WS-SOURCE-SUFFIX         PIC X(01).
025970             88  WS-DEFAULT-SOURCE-SUFFIX        VALUE SPACES.
025970         10  WS-SOURCE-TYPE           PIC X(01).
025970             88  WS-DEFAULT-SOURCE-TYPE          VALUE SPACES.
025970     05  WS-MAX-RQCD                  PIC S9(03) COMP-3.
025970         88  WS-DEFAULT-MAX-RQCD                 VALUE +6.
025970     05  WS-MAX-UWMF                  PIC S9(04) BINARY.
025970         88  WS-DEFAULT-MAX-UWMF                 VALUE +10.
025970     05  WS-MAX-LCGP                  PIC S9(04) BINARY.
025970         88  WS-DEFAULT-MAX-LCGP                 VALUE +12.
025970     05  WS-MAX-SBCO                  PIC S9(04) BINARY.
025970         88  WS-DEFAULT-MAX-SBCO                 VALUE +10.
025970     05  WS-MAX-SCREEN-LINES          PIC S9(04).
025970         88  WS-DEFAULT-MAX-SCREEN-LINES         VALUE +12.
025970/
       COPY XCWEBLCH.
014221 COPY CCWWLOCK.
      *
       COPY CCFWEDIT.
       COPY CCFREDIT.
      *
       COPY NCFWDFLD.
       COPY NCFRDFLD.
      *
       COPY NCFWRTAB.
       COPY NCFRRTAB.
      *
       COPY NCFWUWMX.
       COPY NCFRUWMX.
      *
013578*COPY CCFWAFTT.
013578*COPY CCFRAFTT.
      *
010645 COPY NCFRUWMF.
010645 COPY NCFWUWMF.
010645*
010645 COPY NCFRUWML.
010645 COPY NCFWUWML.
010645*
010645 COPY NCFRUWMR.
010645 COPY NCFWUWMR.
010645*
010418 COPY NCFRUWMS.
010418 COPY NCFWUWMS.
010418*
010418 COPY CCFRSCOM.
010418 COPY CCFWSCOM.
010418*
557698 COPY XCWL0005.
557698*
       COPY XCWL0280.
008455 COPY XCWL0290.
014221 COPY XCWL8090.
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0360.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------
      *****************************************************************
      *  PERFORM SECURITY PROCESSING AND INVOKE MODULES TO
      *      PROCESS USER REQUEST
      *****************************************************************

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.

           IF WS-BUS-FCN-CREATE
               PERFORM 4000-CREATE
                  THRU 4000-CREATE-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.
      *
      ***  NUMERIC KEY FIELDS SHOULD BE VALIDATED FOR ALL OTHER
      ***  FUNCTIONS.
      *
           PERFORM 7200-CHECK-NUMERIC-KEYS
              THRU 7200-CHECK-NUMERIC-KEYS-X.

           IF WS-INVALID-CONTROL
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF WS-BUS-FCN-RETRIEVE
               PERFORM 3000-RETRIEVE
                  THRU 3000-RETRIEVE-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF WS-BUS-FCN-LIST
               PERFORM 3500-LIST
                  THRU 3500-LIST-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF WS-BUS-FCN-UPDATE
               PERFORM 5000-UPDATE
                  THRU 5000-UPDATE-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF WS-BUS-FCN-DELETE
               PERFORM 6000-DELETE
                  THRU 6000-DELETE-X
           END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *-------------
       3000-RETRIEVE.
      *-------------
      *****************************************************************
      *  INQUIRY PROCESSING: SETUP BROWSE KEYS, BEGIN BROWSE, AND
      *  LOAD DATA UNTIL END-OF-FILE OR SCREEN IS FULL.
      *****************************************************************

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           MOVE LOW-VALUES            TO WUWMX-KEY.
           MOVE HIGH-VALUES           TO WUWMX-ENDBR-KEY.

           PERFORM  7100-BUILD-UWMX-KEY
               THRU 7100-BUILD-UWMX-KEY-X.
      *
      ***  BROWSE THE UWMX FILE AND READ THE RECORD.
      ***  IF THE KEY HAS NOT CHANGED SCROLL FORWARD TO THE NEXT RECORD.
      *
           PERFORM  UWMX-1000-BROWSE
               THRU UWMX-1000-BROWSE-X.

           IF NOT WUWMX-IO-OK
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-RETRIEVE-X
557660     END-IF.

           PERFORM  UWMX-2000-READ-NEXT
               THRU UWMX-2000-READ-NEXT-X.

           IF NOT WUWMX-IO-OK
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  UWMX-3000-END-BROWSE
                   THRU UWMX-3000-END-BROWSE-X
               GO TO 3000-RETRIEVE-X
557660     END-IF.

557659     MOVE RUWMX-CCAS-TST-ID     TO MIR-CCAS-TST-ID.
557659     MOVE RUWMX-CCAS-TST-SUBSET-ID TO MIR-CCAS-TST-SUBSET-ID.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  UWMX-3000-END-BROWSE
               THRU UWMX-3000-END-BROWSE-X.


014221     MOVE RUWMX-KEY            TO WUWMX-KEY.
014221     PERFORM  UWMX-1000-READ-TWRK-TS
014221         THRU UWMX-1000-READ-TWRK-TS-X.

       3000-RETRIEVE-X.
           EXIT.
      *
      *------------
       3500-LIST.
      *------------
      *****************************************************************
      *  BROWSE PROCESSING: SETUP BROWSE KEYS, BEGIN BROWSE, AND
      *  LOAD DATA UNTIL END-OF-FILE OR SCREEN IS FULL.
      *****************************************************************

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           MOVE LOW-VALUES            TO WUWMX-KEY.
           MOVE HIGH-VALUES           TO WUWMX-ENDBR-KEY.

           PERFORM  7100-BUILD-UWMX-KEY
               THRU 7100-BUILD-UWMX-KEY-X.

           PERFORM  UWMX-1000-BROWSE
               THRU UWMX-1000-BROWSE-X.

           IF NOT WUWMX-IO-OK
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-LIST-X
557660     END-IF.

            PERFORM  UWMX-2000-READ-NEXT
                THRU UWMX-2000-READ-NEXT-X.

           IF NOT WUWMX-IO-OK
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  UWMX-3000-END-BROWSE
                   THRU UWMX-3000-END-BROWSE-X
               GO TO 3500-LIST-X
557660     END-IF.

557659*    MOVE RUWMX-CCAS-TST-NUM       TO MIR-CCAS-TST-ID.
557659*    MOVE RUWMX-CCAS-TST-SFX       TO MIR-CCAS-TST-SUBSET-ID.
557659     MOVE RUWMX-CCAS-TST-ID     TO MIR-CCAS-TST-ID.
557659     MOVE RUWMX-CCAS-TST-SUBSET-ID
                                      TO MIR-CCAS-TST-SUBSET-ID.

            PERFORM  3510-DISPLAY-RECORD
                THRU 3510-DISPLAY-RECORD-X
                VARYING WS-LINE FROM 1 BY 1
                UNTIL WS-LINE > WS-MAX-SCREEN-LINES
                   OR NOT WUWMX-IO-OK.

           IF WUWMX-IO-OK
      *MSG:    (I) TO VIEW MORE DATA, PRESS ENTER
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
557659*        MOVE RUWMX-CCAS-TST-NUM    TO MIR-CCAS-TST-ID
557659*        MOVE RUWMX-CCAS-TST-SFX    TO MIR-CCAS-TST-SUBSET-ID
557659         MOVE RUWMX-CCAS-TST-ID TO MIR-CCAS-TST-ID
557659         MOVE RUWMX-CCAS-TST-SUBSET-ID
557659                                TO MIR-CCAS-TST-SUBSET-ID
           ELSE
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  UWMX-3000-END-BROWSE
               THRU UWMX-3000-END-BROWSE-X.

       3500-LIST-X.
           EXIT.
      *
      *--------------------
       3510-DISPLAY-RECORD.
      *--------------------
      *****************************************************************
      *  DISPLAY RECORD PROCESSING:
      *      MOVE RECORD TO SCREEN
      *      READ NEXT RECORD
      *****************************************************************

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  UWMX-2000-READ-NEXT
               THRU UWMX-2000-READ-NEXT-X.

       3510-DISPLAY-RECORD-X.
           EXIT.
      *
      *------------
       4000-CREATE.
      *------------
      *****************************************************************
      *  CREATE PROCESSING: TWO PASSES REQUIRED
      *      CHECK FOR RECORD.  IF NOT FOUND CREATE RECORD AND
      *      ALLOW USER TO MODIFY UNDER MAINTAIN PROCESSING
      *****************************************************************

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
      *
      ***  VALID CONTROL FIELDS MUST HAVE BEEN ENTERED.
      *
           PERFORM  7000-VALIDATE-CTL-FIELDS
               THRU 7000-VALIDATE-CTL-FIELDS-X.

           IF  WS-INVALID-CONTROL
               GO TO 4000-CREATE-X
557660     END-IF.

      *
      ***  BUILD CONTROL FIELDS.
      *
           PERFORM  7100-BUILD-UWMX-KEY
               THRU 7100-BUILD-UWMX-KEY-X.

      *
      ***  CHECK RECORD EXISTENCE.
      *
           PERFORM  UWMX-1000-READ
               THRU UWMX-1000-READ-X.

           IF WUWMX-IO-OK
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               MOVE WUWMX-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-CREATE-X
557660     END-IF.
      *
      ***  CREATE NEW RECORD.
      *
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  UWMX-1000-CREATE
               THRU UWMX-1000-CREATE-X.

           PERFORM  UWMX-1000-WRITE
               THRU UWMX-1000-WRITE-X.

014221     PERFORM  UWMX-1000-READ-TWRK-TS
014221         THRU UWMX-1000-READ-TWRK-TS-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-CREATE-X.
           EXIT.
      *
      *--------------
       5000-UPDATE.
      *--------------
      *
           PERFORM  7100-BUILD-UWMX-KEY
               THRU 7100-BUILD-UWMX-KEY-X.
014221*    PERFORM  UWMX-1000-READ-FOR-UPDATE
014221*        THRU UWMX-1000-READ-FOR-UPDATE-X.

014221     PERFORM  UWMX-2000-UPDATE-TWRK-TS
014221         THRU UWMX-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'UWMX'                TO WGLOB-MSG-PARM (01)
014221        MOVE WUWMX-KEY             TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 5000-UPDATE-X
014221     END-IF.

           IF WUWMX-IO-NOT-FOUND
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WUWMX-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-UPDATE-X
557660     END-IF.

013578     PERFORM  8100-GET-FORM-TYPES
013578         THRU 8100-GET-FORM-TYPES-X.
013578     PERFORM  8200-GET-RQMNT-CODES
013578         THRU 8200-GET-RQMNT-CODES-X.
013578     PERFORM  8300-GET-LOC-GR-CODES
013578         THRU 8300-GET-LOC-GR-CODES-X.
013578     PERFORM  8400-GET-SBSDRY-INFO
013578         THRU 8400-GET-SBSDRY-INFO-X.
           PERFORM  7500-EDIT-DATA-FIELDS
               THRU 7500-EDIT-DATA-FIELDS-X.

           PERFORM  7600-CROSS-EDITS
               THRU 7600-CROSS-EDITS-X.

           PERFORM  UWMX-2000-REWRITE
               THRU UWMX-2000-REWRITE-X.

014221     PERFORM  UWMX-1000-READ-TWRK-TS
014221         THRU UWMX-1000-READ-TWRK-TS-X.

      *
      ***  A SEPARATE INDICATOR IS USED FOR CROSS EDITS SO WE KNOW IF
      ***  THE POSITION HAS ALREADY BEEN SET.
      *
           IF WS-DATA-EDITS-OK
557660     AND WS-CROSS-EDITS-OK
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
      *
      ***  THIS LINE WILL BE USED TO POP THE STACK.
      *
           ELSE
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       5000-UPDATE-X.
           EXIT.
      *
      *------------
       6000-DELETE.
      *------------
      *
           PERFORM  7100-BUILD-UWMX-KEY
               THRU 7100-BUILD-UWMX-KEY-X.

014221*    PERFORM  UWMX-1000-READ-FOR-UPDATE
014221*        THRU UWMX-1000-READ-FOR-UPDATE-X.

014221     PERFORM  UWMX-2000-UPDATE-TWRK-TS
014221         THRU UWMX-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'UWMX'                TO WGLOB-MSG-PARM (01)
014221        MOVE WUWMX-KEY             TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 6000-DELETE-X
014221     END-IF.

           IF WUWMX-IO-NOT-FOUND
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WUWMX-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           ELSE
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  UWMX-1000-DELETE
                   THRU UWMX-1000-DELETE-X
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       6000-DELETE-X.
           EXIT.
      *
      *-------------------------
       7000-VALIDATE-CTL-FIELDS.
      *-------------------------
      *****************************************************************
      *  EDIT ADMIN SYSTEM FIELD AGAINST ETAB
      *****************************************************************

           MOVE 'N'                   TO WS-VALIDATE-CONTROL.

      *
      ***  VALIDATE CONTROL FIELDS.
      *
           PERFORM 7010-VALIDATE-TEST-NUMBER
              THRU 7010-VALIDATE-TEST-NUMBER-X.

           PERFORM 7020-VALIDATE-SUFFIX
              THRU 7020-VALIDATE-SUFFIX-X.

       7000-VALIDATE-CTL-FIELDS-X.
           EXIT.
      *
      *--------------------------
       7010-VALIDATE-TEST-NUMBER.
      *--------------------------
      *****************************************************************
      *  EDIT CONTROL FIELDS (TEST NUMBER)
      *****************************************************************

      *
      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE '4'                   TO L0280-LENGTH.
           MOVE '4'                   TO L0280-INPUT-SIZE.

      *
      ***  PERFORM NUMERIC CHECK AND FORMAT ON TEST NUMBER.
      *
           MOVE MIR-CCAS-TST-ID       TO L0280-INPUT-DATA.

           PERFORM 7800-NUMERIC-EDIT
              THRU 7800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-9999
               MOVE WS-NUM-9999       TO MIR-CCAS-TST-ID
           ELSE
               MOVE 'NS03600002'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VALIDATE-CONTROL
557660     END-IF.

       7010-VALIDATE-TEST-NUMBER-X.
           EXIT.

      *
      *---------------------
       7020-VALIDATE-SUFFIX.
      *---------------------
      *****************************************************************
      *  EDIT CONTROL FIELDS: SUFFIX
      *****************************************************************

           IF MIR-CCAS-TST-SUBSET-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CCAS-TST-SUBSET-ID
557660     END-IF.

      *
      ***  SUFFIX MUST BE ALPHABETIC OR A BLANK.
      *
557698     PERFORM  0005-1000-BUILD-PARM-INFO
557698         THRU 0005-1000-BUILD-PARM-INFO-X.
557698     MOVE MIR-CCAS-TST-SUBSET-ID            TO L0005-INPUT-STRING.
557698     PERFORM  0005-2000-CONVERT-NO-ACCENTS
557698         THRU 0005-2000-CONVERT-NO-ACCENTS-X.
557698*    IF MIR-CCAS-TST-SUBSET-ID NOT ALPHABETIC
557698     IF L0005-RETRN-OK
557698       IF L0005-OUTPUT-STRING NOT ALPHABETIC
               MOVE 'NS03600003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VALIDATE-CONTROL
557698       END-IF
557698     ELSE
557698       IF MIR-CCAS-TST-SUBSET-ID NOT ALPHABETIC
557698         MOVE 'NS03600003'      TO WGLOB-MSG-REF-INFO
557698         PERFORM 0260-1000-GENERATE-MESSAGE
557698            THRU 0260-1000-GENERATE-MESSAGE-X
557698         MOVE 'Y'               TO WS-VALIDATE-CONTROL
557698       END-IF
557660     END-IF.

       7020-VALIDATE-SUFFIX-X.
           EXIT.


      *--------------------
       7100-BUILD-UWMX-KEY.
      *--------------------
      *****************************************************************
      *  BUILD UWMX KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
      *****************************************************************

557659*    MOVE MIR-CCAS-TST-ID        TO WUWMX-CCAS-TST-NUM.
557659*    MOVE MIR-CCAS-TST-SUBSET-ID        TO WUWMX-CCAS-TST-SFX.
557659     MOVE MIR-CCAS-TST-ID       TO WUWMX-CCAS-TST-ID.
557659     MOVE MIR-CCAS-TST-SUBSET-ID      TO WUWMX-CCAS-TST-SUBSET-ID.

       7100-BUILD-UWMX-KEY-X.
           EXIT.
      *

      *------------------------
       7200-CHECK-NUMERIC-KEYS.
      *------------------------
      *****************************************************************
      *  FORMAT NUMERIC KEY FIELDS: TEST NUMBER.
      *****************************************************************

           MOVE 'N'                   TO WS-VALIDATE-CONTROL.

           PERFORM 7010-VALIDATE-TEST-NUMBER
              THRU 7010-VALIDATE-TEST-NUMBER-X.

       7200-CHECK-NUMERIC-KEYS-X.
           EXIT.
      *
      *----------------------
       7500-EDIT-DATA-FIELDS.
      *----------------------
      *****************************************************************
      *  EDIT DATA FIELDS ACCORDING TO THE DATA DICTIONARY
      *****************************************************************

           MOVE 'Y'                   TO WS-DATA-EDITS.

           PERFORM  7502-EDIT-TEST-NAME
               THRU 7502-EDIT-TEST-NAME-X.

557660     PERFORM  7503-EDIT-TEST-TYPE
557660         THRU 7503-EDIT-TEST-TYPE-X.

      *
      ***  SET THE ERROR MESSAGE SOURCE NUMBER.
      *
           IF RUWMX-CCAS-TST-TYP-COMPLEX
               MOVE SPACES            TO RUWMX-UNANSWR-MSG-REF-ID
               MOVE SPACES            TO RUWMX-FAIL-MSG-REF-ID
               MOVE SPACES            TO RUWMX-MSG-REF-NUM
               MOVE SPACES            TO MIR-MSG-REF-NUM
               MOVE SPACES            TO MIR-MSG-REF-NUM
               MOVE SPACES            TO MIR-UNANSWR-MSG-REF-ID
               MOVE SPACES            TO MIR-FAIL-MSG-REF-ID
           ELSE
557659*        MOVE RUWMX-CCAS-TST-NUM TO RUWMX-MSG-REF-NUM
557659*        MOVE RUWMX-CCAS-TST-NUM TO MIR-MSG-REF-NUM
557659*        MOVE RUWMX-CCAS-TST-NUM TO MIR-MSG-REF-NUM
557659         MOVE RUWMX-CCAS-TST-ID TO RUWMX-MSG-REF-NUM
557659         MOVE RUWMX-CCAS-TST-ID TO MIR-MSG-REF-NUM
557659         MOVE RUWMX-CCAS-TST-ID TO MIR-MSG-REF-NUM
557659*        IF RUWMX-CCAS-TST-SFX = SPACES
557659         IF RUWMX-CCAS-TST-SUBSET-ID = SPACES
                   MOVE 'NCCC@U'      TO RUWMX-UNANSWR-MSG-REF-ID
                   MOVE 'NCCC@F'      TO RUWMX-FAIL-MSG-REF-ID
                   MOVE 'NCCC@U'      TO MIR-UNANSWR-MSG-REF-ID
                   MOVE 'NCCC@F'      TO MIR-FAIL-MSG-REF-ID
               ELSE
557659*            MOVE RUWMX-CCAS-TST-SFX TO WS-SOURCE-SUFFIX
557659             MOVE RUWMX-CCAS-TST-SUBSET-ID
557659                                TO WS-SOURCE-SUFFIX
                   MOVE 'U'           TO WS-SOURCE-TYPE
                   MOVE WS-SOURCE     TO RUWMX-UNANSWR-MSG-REF-ID
                   MOVE WS-SOURCE     TO MIR-UNANSWR-MSG-REF-ID
                   MOVE 'F'           TO WS-SOURCE-TYPE
                   MOVE WS-SOURCE     TO RUWMX-FAIL-MSG-REF-ID
                   MOVE WS-SOURCE     TO MIR-FAIL-MSG-REF-ID
557660         END-IF
557660     END-IF.

557660     PERFORM  7504-EDIT-INCEX-FORM-CD
557660        THRU  7504-EDIT-INCEX-FORM-CD-X.

557660     PERFORM  7505-EDIT-INCEX-AGE-CD
557660        THRU  7505-EDIT-INCEX-AGE-CD-X.

010645     PERFORM  7515-EDIT-INCEX-LOC-GR-CD
010645        THRU  7515-EDIT-INCEX-LOC-GR-CD-X.
010645
010418     PERFORM  7516-EDIT-INCEX-SBSDRY-CD
010418        THRU  7516-EDIT-INCEX-SBSDRY-CD-X.
010418
           PERFORM  7506-EDIT-FORM-TYPE
               THRU 7506-EDIT-FORM-TYPE-X.

010645     PERFORM  7507-EDIT-LOC-GR-CD
010645         THRU 7507-EDIT-LOC-GR-CD-X.

010418     PERFORM  7517-EDIT-SBSDRY-CD
010418         THRU 7517-EDIT-SBSDRY-CD-X.

           PERFORM  7508-EDIT-AGE-RANGES
               THRU 7508-EDIT-AGE-RANGES-X.

010645*
010645***  TWO COUNTERS ARE USED FOR REQUIREMENT CODES TO ENSURE
010645***  BLANK CODES ARE NOT IMBEDDED IN THE LIST.
010645*
010645*    MOVE 'Y'             TO WS-VALIDATE-CODES.
010645*
010645*    PERFORM  7512-EDIT-FAILURE-RQMNT
010645*        THRU 7512-EDIT-FAILURE-RQMNT-X
010645*        VARYING WS-RQCD FROM 1 BY 1
010645*        UNTIL (WS-RQCD > WS-MAX-RQCD).
010645*
010645*
010645***  IF ANY REQUIREMENT CODES WERE BLANKED OUT WE MUST SHIFT
010645***  THE CODES. THIS IS ONLY DONE IF THERE WERE NO EDIT ERRORS
010645***  ON THE REQUIREMENT CODES.
010645*
010645*    IF WS-VALID-CODES
010645*        MOVE SPACES      TO RUWMX-FAIL-REQIR-INFO
010645*        MOVE +1          TO WS-RQCD-OUT
010645*        PERFORM 7551-SHIFT-REC-RQMNT-CODES
010645*            THRU 7551-SHIFT-REC-RQMNT-CODES-X
010645*            VARYING WS-RQCD FROM 1 BY 1
010645*            UNTIL (WS-RQCD > WS-MAX-RQCD)
010645*        MOVE SPACES      TO MIR-REQIR-ID-TABLE
010645*        PERFORM 7552-UPDATE-MIR-RQMNT-CODES
010645*            THRU 7552-UPDATE-MIR-RQMNT-CODES-X
010645*            VARYING WS-RQCD FROM 1 BY 1
010645*            UNTIL (WS-RQCD > WS-MAX-RQCD)
010645*    END-IF.

010645*
010645***  THE REQUIREMENT CODES CANNOT BE REPEATED.
010645*
010645     PERFORM  7570-DUPLICATE-CODES
010645         THRU 7570-DUPLICATE-CODES-X
010645         VARYING WS-RQCD FROM 1 BY 1
010645         UNTIL (WS-RQCD > WS-MAX-RQCD).

010645     PERFORM  7512-EDIT-FAILURE-RQMNT
010645         THRU 7512-EDIT-FAILURE-RQMNT-X.
      *
      ***  ALL REMAINING FIELDS ARE FOR SIMPLE TESTS ONLY.
      *
           IF RUWMX-CCAS-TST-TYP-COMPLEX
               PERFORM 7602-VALIDATE-COMPLEX-INPUT
                  THRU 7602-VALIDATE-COMPLEX-INPUT-X
               GO TO 7500-EDIT-DATA-FIELDS-X
557660     END-IF.

           MOVE 'Y'                   TO WS-VALIDATE-FLD-NAME.

557660     PERFORM  7513-EDIT-FIELD-NAME
557660         THRU 7513-EDIT-FIELD-NAME-X.

           PERFORM  7514-EDIT-UNANSWD-RESP
               THRU 7514-EDIT-UNANSWD-RESP-X.

      *
      ***  INPUT IS ONLY ALLOWED IN SOME FIELDS DEPENDING ON TEST TYPE.
      *

           MOVE MIR-CCAS-TST-TYP-CD   TO WS-SAVE-TEST-TYPE.
      *
      ***  EDIT INPUT FOR THE YESNO TEST.
      *
           IF WS-TEST-TYPE-YESNO
               PERFORM  7520-EDIT-YESNO-YES
                   THRU 7520-EDIT-YESNO-YES-X
               PERFORM  7522-EDIT-YESNO-NO
                   THRU 7522-EDIT-YESNO-NO-X
557660     END-IF.

      *
      ***  EDIT INPUT FOR THE NUMERIC RANGE TEST.
      *
           IF WS-TEST-TYPE-NUMERIC
               PERFORM  7524-EDIT-NUM-MIN
                   THRU 7524-EDIT-NUM-MIN-X
               PERFORM  7526-EDIT-NUM-MAX
                   THRU 7526-EDIT-NUM-MAX-X
               PERFORM  7528-EDIT-NUM-IN-RANGE
                   THRU 7528-EDIT-NUM-IN-RANGE-X
               PERFORM  7530-EDIT-NUM-OUT-RANGE
                   THRU 7530-EDIT-NUM-OUT-RANGE-X
557660     END-IF.

      *
      ***  EDIT INPUT FOR THE LIST LOOKUP TEST.
      *
           IF WS-TEST-TYPE-LIST
               PERFORM  7532-EDIT-LIST-TYPE
                   THRU 7532-EDIT-LIST-TYPE-X
               PERFORM  7534-EDIT-LIST-FND
                   THRU 7534-EDIT-LIST-FND-X
               PERFORM  7536-EDIT-LIST-NOT-FND
                   THRU 7536-EDIT-LIST-NOT-FND-X
557660     END-IF.

      *
      ***  EDIT INPUT FOR THE DATE RANGE TEST.
      *
           IF WS-TEST-TYPE-DATE
               PERFORM  7538-EDIT-DATE-TYPE
                   THRU 7538-EDIT-DATE-TYPE-X
               PERFORM  7540-EDIT-DATE-YMD
                   THRU 7540-EDIT-DATE-YMD-X
               PERFORM  7542-EDIT-DATE-CUTOFF
                   THRU 7542-EDIT-DATE-CUTOFF-X
               PERFORM  7544-EDIT-DATE-IN-RANGE
                   THRU 7544-EDIT-DATE-IN-RANGE-X
               PERFORM  7546-EDIT-DATE-OUT-RANGE
                   THRU 7546-EDIT-DATE-OUT-RANGE-X
557660     END-IF.

       7500-EDIT-DATA-FIELDS-X.
           EXIT.

      *
      *--------------------
       7502-EDIT-TEST-NAME.
      *--------------------
      *****************************************************************
      *  TEST NAME: CANNOT BE BLANK.
      *****************************************************************

           IF MIR-CCAS-TST-NM = SPACES
               MOVE RUWMX-CCAS-TST-NM TO MIR-CCAS-TST-NM
           ELSE
               IF MIR-CCAS-TST-NM = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CCAS-TST-NM
557660         END-IF
557660     END-IF.

           IF MIR-CCAS-TST-NM NOT = SPACES
               MOVE MIR-CCAS-TST-NM   TO RUWMX-CCAS-TST-NM
           ELSE
               MOVE 'NS03600004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7502-EDIT-TEST-NAME-X.
           EXIT.

      *
      *--------------------
557660 7503-EDIT-TEST-TYPE.
      *--------------------
      *****************************************************************
      *  TEST TYPE: CANNOT BE BLANK.
      *****************************************************************

           IF MIR-CCAS-TST-TYP-CD = SPACES
               MOVE RUWMX-CCAS-TST-TYP-CD
                                      TO MIR-CCAS-TST-TYP-CD
           ELSE
               IF MIR-CCAS-TST-TYP-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CCAS-TST-TYP-CD
557660         END-IF
557660     END-IF.

      *
      ***  IF THE TEST TYPE CHANGES THE COMMON AREA SHOULD BE RESET TO
      ***  DEFAULTS THAT CORRESPOND TO THE NEW TEST TYPE.
      *
           MOVE MIR-CCAS-TST-TYP-CD   TO WS-SAVE-TEST-TYPE.
           IF WS-VALID-TEST-TYPE AND
              MIR-CCAS-TST-TYP-CD NOT = RUWMX-CCAS-TST-TYP-CD
               PERFORM 7560-RESET-DEFAULTS
                   THRU 7560-RESET-DEFAULTS-X
557660     END-IF.

           IF WS-VALID-TEST-TYPE
               MOVE MIR-CCAS-TST-TYP-CD
                                      TO RUWMX-CCAS-TST-TYP-CD
           ELSE
               MOVE 'NS03600005'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

557660 7503-EDIT-TEST-TYPE-X.
           EXIT.

      *
      *------------------------
557660 7504-EDIT-INCEX-FORM-CD.
      *------------------------
      *************************************************
      * INCLUDE/EXCLUDE FORM: CODE MUST BE VALID
      *************************************************

           IF MIR-CCAS-TST-FORM-CD = SPACES
               MOVE RUWMX-CCAS-TST-FORM-CD
                                      TO MIR-CCAS-TST-FORM-CD
           ELSE
               IF MIR-CCAS-TST-FORM-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CCAS-TST-FORM-CD
557660         END-IF
557660     END-IF.

           MOVE MIR-CCAS-TST-FORM-CD  TO WS-TEST-INCEX-CD.

           IF WS-VALID-INCEX-CD
               MOVE MIR-CCAS-TST-FORM-CD
                                      TO RUWMX-CCAS-TST-FORM-CD
           ELSE
               MOVE 'N'               TO WS-DATA-EDITS
               MOVE 'NS03600048'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

557660 7504-EDIT-INCEX-FORM-CD-X.
           EXIT.
      *

      *-----------------------
557660 7505-EDIT-INCEX-AGE-CD.
      *-----------------------
      *************************************************
      * INCLUDE/EXCLUDE AGE:  CODE MUST BE VALID
      *************************************************
           IF MIR-CCAS-TST-AGE-CD = SPACES
               MOVE RUWMX-CCAS-TST-AGE-CD
                                      TO MIR-CCAS-TST-AGE-CD
           ELSE
               IF MIR-CCAS-TST-AGE-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CCAS-TST-AGE-CD
557660         END-IF
557660     END-IF.

           MOVE MIR-CCAS-TST-AGE-CD   TO WS-TEST-INCEX-CD.

           IF WS-VALID-INCEX-CD
               MOVE MIR-CCAS-TST-AGE-CD
                                      TO RUWMX-CCAS-TST-AGE-CD
           ELSE
               MOVE 'N'               TO WS-DATA-EDITS
               MOVE 'NS03600048'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

557660 7505-EDIT-INCEX-AGE-CD-X.
           EXIT.
      *
      *--------------------
       7506-EDIT-FORM-TYPE.
      *--------------------
      *****************************************************************
      *  FORM TYPE: MUST BE VALIDATED AGAINST AFTT
      *****************************************************************

           MOVE 'Y'                   TO WS-VALIDATE-FORM.
010645*    MOVE SPACES                TO WS-ERR-FORM-TYPE.

010645*    IF MIR-FRMTYP = SPACES
010645*        MOVE RUWMX-APP-FORM-TYP-INFO TO MIR-FRMTYP
010645*        GO TO 7506-EDIT-FORM-TYPE-X
010645*    ELSE
010645*        MOVE MIR-FRMTYP              TO WS-FORM-TYPE
010645*    END-IF.
010645*
010645*    IF WS-FORM-TYP01 = EBLCH-BLANK-FIELD-CHAR
010645*        MOVE SPACES                  TO WS-FORM-TYP01
010645*    END-IF.
010645*
010645*    IF WS-FORM-TYP02 = EBLCH-BLANK-FIELD-CHAR
010645*        MOVE SPACES                  TO WS-FORM-TYP02
010645*    END-IF.
010645*
010645*    IF WS-FORM-TYP03 = EBLCH-BLANK-FIELD-CHAR
010645*        MOVE SPACES                  TO WS-FORM-TYP03
010645*    END-IF.
010645*
010645*    IF WS-FORM-TYP04 = EBLCH-BLANK-FIELD-CHAR
010645*        MOVE SPACES                  TO WS-FORM-TYP04
010645*    END-IF.
010645*
010645*    IF WS-FORM-TYP05 = EBLCH-BLANK-FIELD-CHAR
010645*        MOVE SPACES                  TO WS-FORM-TYP05
010645*    END-IF.
010645*
010645*    IF WS-FORM-TYP06 = EBLCH-BLANK-FIELD-CHAR
010645*        MOVE SPACES                  TO WS-FORM-TYP06
010645*    END-IF.
010645*
010645*    IF WS-FORM-TYP07 = EBLCH-BLANK-FIELD-CHAR
010645*        MOVE SPACES                  TO WS-FORM-TYP07
010645*    END-IF.
010645*
010645*    IF WS-FORM-TYP08 = EBLCH-BLANK-FIELD-CHAR
010645*        MOVE SPACES                  TO WS-FORM-TYP08
010645*    END-IF.
010645*
010645*    IF WS-FORM-TYP09 = EBLCH-BLANK-FIELD-CHAR
010645*        MOVE SPACES                  TO WS-FORM-TYP09
010645*    END-IF.
010645*
010645*    IF WS-FORM-TYP10 = EBLCH-BLANK-FIELD-CHAR
010645*        MOVE SPACES                  TO WS-FORM-TYP10
010645*    END-IF.
010645*
010645*        IF WS-FORM-TYP01 NOT = SPACES
010645*            MOVE WS-FORM-TYP01   TO WAFTT-APP-FORM-TYP-ID
010645*            MOVE WGLOB-USER-LANG TO WAFTT-APP-FORM-LANG-CD
010645*            PERFORM  AFTT-1000-READ
010645*               THRU  AFTT-1000-READ-X
010645*            IF NOT WAFTT-IO-OK
010645*                MOVE 'N'           TO WS-VALIDATE-FORM
010645*                MOVE WS-FORM-TYP01 TO WS-ERR-TYP01
010645*            END-IF
010645*        END-IF.
010645*
010645*        IF WS-FORM-TYP02 NOT = SPACES
010645*            MOVE WS-FORM-TYP02   TO WAFTT-APP-FORM-TYP-ID
010645*            MOVE WGLOB-USER-LANG TO WAFTT-APP-FORM-LANG-CD
010645*            PERFORM  AFTT-1000-READ
010645*               THRU  AFTT-1000-READ-X
010645*            IF NOT WAFTT-IO-OK
010645*                MOVE 'N'           TO WS-VALIDATE-FORM
010645*                MOVE WS-FORM-TYP02 TO WS-ERR-TYP02
010645*            END-IF
010645*        END-IF.
010645*
010645*        IF WS-FORM-TYP03 NOT = SPACES
010645*            MOVE WS-FORM-TYP03   TO WAFTT-APP-FORM-TYP-ID
010645*            MOVE WGLOB-USER-LANG TO WAFTT-APP-FORM-LANG-CD
010645*            PERFORM  AFTT-1000-READ
010645*               THRU  AFTT-1000-READ-X
010645*            IF NOT WAFTT-IO-OK
010645*                MOVE 'N'           TO WS-VALIDATE-FORM
010645*                MOVE WS-FORM-TYP03 TO WS-ERR-TYP03
010645*            END-IF
010645*        END-IF.
010645*
010645*        IF WS-FORM-TYP04 NOT = SPACES
010645*            MOVE WS-FORM-TYP04   TO WAFTT-APP-FORM-TYP-ID
010645*            MOVE WGLOB-USER-LANG TO WAFTT-APP-FORM-LANG-CD
010645*            PERFORM  AFTT-1000-READ
010645*               THRU  AFTT-1000-READ-X
010645*            IF NOT WAFTT-IO-OK
010645*                MOVE 'N'              TO WS-VALIDATE-FORM
010645*                MOVE WS-FORM-TYP04    TO WS-ERR-TYP04
010645*            END-IF
010645*        END-IF.
010645*
010645*        IF WS-FORM-TYP05 NOT = SPACES
010645*            MOVE WS-FORM-TYP05   TO WAFTT-APP-FORM-TYP-ID
010645*            MOVE WGLOB-USER-LANG TO WAFTT-APP-FORM-LANG-CD
010645*            PERFORM  AFTT-1000-READ
010645*               THRU  AFTT-1000-READ-X
010645*            IF NOT WAFTT-IO-OK
010645*                MOVE 'N'           TO WS-VALIDATE-FORM
010645*                MOVE WS-FORM-TYP05 TO WS-ERR-TYP05
010645*            END-IF
010645*        END-IF.
010645*
010645*        IF WS-FORM-TYP06 NOT = SPACES
010645*            MOVE WS-FORM-TYP06   TO WAFTT-APP-FORM-TYP-ID
010645*            MOVE WGLOB-USER-LANG TO WAFTT-APP-FORM-LANG-CD
010645*            PERFORM  AFTT-1000-READ
010645*               THRU  AFTT-1000-READ-X
010645*            IF NOT WAFTT-IO-OK
010645*                MOVE 'N'           TO WS-VALIDATE-FORM
010645*                MOVE WS-FORM-TYP06 TO WS-ERR-TYP06
010645*            END-IF
010645*        END-IF.
010645*
010645*        IF WS-FORM-TYP07 NOT = SPACES
010645*            MOVE WS-FORM-TYP07   TO WAFTT-APP-FORM-TYP-ID
010645*            MOVE WGLOB-USER-LANG TO WAFTT-APP-FORM-LANG-CD
010645*            PERFORM  AFTT-1000-READ
010645*               THRU  AFTT-1000-READ-X
010645*            IF NOT WAFTT-IO-OK
010645*                MOVE 'N'           TO WS-VALIDATE-FORM
010645*                MOVE WS-FORM-TYP07 TO WS-ERR-TYP07
010645*            END-IF
010645*        END-IF.
010645*
010645*        IF WS-FORM-TYP08 NOT = SPACES
010645*            MOVE WS-FORM-TYP08   TO WAFTT-APP-FORM-TYP-ID
010645*            MOVE WGLOB-USER-LANG TO WAFTT-APP-FORM-LANG-CD
010645*            PERFORM  AFTT-1000-READ
010645*               THRU  AFTT-1000-READ-X
010645*            IF NOT WAFTT-IO-OK
010645*                MOVE 'N'           TO WS-VALIDATE-FORM
010645*                MOVE WS-FORM-TYP08 TO WS-ERR-TYP08
010645*            END-IF
010645*        END-IF.
010645*
010645*        IF WS-FORM-TYP09 NOT = SPACES
010645*            MOVE WS-FORM-TYP09   TO WAFTT-APP-FORM-TYP-ID
010645*            MOVE WGLOB-USER-LANG TO WAFTT-APP-FORM-LANG-CD
010645*            PERFORM  AFTT-1000-READ
010645*               THRU  AFTT-1000-READ-X
010645*            IF NOT WAFTT-IO-OK
010645*                MOVE 'N'           TO WS-VALIDATE-FORM
010645*                MOVE WS-FORM-TYP09 TO WS-ERR-TYP09
010645*            END-IF
010645*        END-IF.
010645*
010645*        IF WS-FORM-TYP10 NOT = SPACES
010645*            MOVE WS-FORM-TYP10   TO WAFTT-APP-FORM-TYP-ID
010645*            MOVE WGLOB-USER-LANG TO WAFTT-APP-FORM-LANG-CD
010645*            PERFORM  AFTT-1000-READ
010645*               THRU  AFTT-1000-READ-X
010645*            IF NOT WAFTT-IO-OK
010645*                MOVE 'N'           TO WS-VALIDATE-FORM
010645*                MOVE WS-FORM-TYP10 TO WS-ERR-TYP10
010645*            END-IF
010645*        END-IF.
010645*
010645*        IF NOT WS-VALID-FORM
010645*            MOVE 'N'                TO WS-DATA-EDITS
010645*            MOVE 'NS03600006'       TO WGLOB-MSG-REF-INFO
010645*            MOVE WS-ERR-FORM-TYPE   TO WGLOB-MSG-PARM (1)
010645*            PERFORM  0260-1000-GENERATE-MESSAGE
010645*                THRU  0260-1000-GENERATE-MESSAGE-X
010645*        END-IF.
010645*
010645*         IF WS-VALID-FORM
010645*             MOVE WS-FORM-TYPE      TO MIR-FRMTYP
010645*             MOVE MIR-FRMTYP        TO RUWMX-APP-FORM-TYP-INFO
010645*         END-IF.

010645* IF INCLUDE\EXCLUDE CODE = A(ALL) THEN CLEAR/DELETE LIST
010645
010645     MOVE MIR-CCAS-TST-FORM-CD  TO WS-TEST-FINCEX-CD.
010645     IF WS-FINCEX-CD-A
010645        MOVE WS-APPFORM-INFO TO MIR-APP-FORM-TYP-ID-G
010645
010645        PERFORM
010645            VARYING  WS-UWMF-SUB FROM 1 BY 1
010645              UNTIL (WS-UWMF-SUB > WS-MAX-UWMF)
010645            IF  WS-APP-FORM-TYP (WS-UWMF-SUB) = SPACES
010645                CONTINUE
010645            ELSE
010645                MOVE WS-APP-FORM-TYP (WS-UWMF-SUB)
010645                                TO WUWMF-APP-FORM-TYP-ID
010645                PERFORM  7555-DELETE-MIR-FORM-TYPES
010645                    THRU 7555-DELETE-MIR-FORM-TYPES-X
010645                MOVE SPACES    TO WS-APP-FORM-TYP (WS-UWMF-SUB)
010645            END-IF
010645        END-PERFORM
010645
010645        MOVE WS-APPFORM-INFO TO MIR-APP-FORM-TYP-ID-G
010645        GO TO 7506-EDIT-FORM-TYPE-X
010645
010645     END-IF.
010645
010645     IF MIR-APP-FORM-TYP-ID-G = SPACES
010645         MOVE WS-APPFORM-INFO      TO MIR-APP-FORM-TYP-ID-G
010645         GO TO 7506-EDIT-FORM-TYPE-X
010645     END-IF.
010645
010645     PERFORM
010645         VARYING  WS-UWMF-SUB FROM 1 BY 1
010645           UNTIL (WS-UWMF-SUB > WS-MAX-UWMF)
010645         IF  MIR-APP-FORM-TYP-ID-T (WS-UWMF-SUB) = SPACES
010645             MOVE WS-APP-FORM-TYP (WS-UWMF-SUB)
010645                            TO MIR-APP-FORM-TYP-ID-T (WS-UWMF-SUB)
010645         ELSE
010645             IF MIR-APP-FORM-TYP-ID-T (WS-UWMF-SUB) =
010645                                           EBLCH-BLANK-FIELD-CHAR
010645             OR MIR-APP-FORM-TYP-ID-T (WS-UWMF-SUB) NOT =
010645                               WS-APP-FORM-TYP   (WS-UWMF-SUB)
010645                 MOVE WS-APP-FORM-TYP (WS-UWMF-SUB)
010645                                TO WUWMF-APP-FORM-TYP-ID
010645                 PERFORM 7555-DELETE-MIR-FORM-TYPES
010645                    THRU 7555-DELETE-MIR-FORM-TYPES-X
010645                 MOVE SPACES   TO WS-APP-FORM-TYP (WS-UWMF-SUB)
010645             END-IF
010645         END-IF
010645     END-PERFORM.
010645
010645     PERFORM
010645         VARYING WS-UWMF-SUB FROM 1 BY 1
010645           UNTIL WS-UWMF-SUB > WS-MAX-UWMF
010645         IF  MIR-APP-FORM-TYP-ID-T (WS-UWMF-SUB) =
                                                  EBLCH-BLANK-FIELD-CHAR
010645             MOVE SPACES    TO MIR-APP-FORM-TYP-ID-T (WS-UWMF-SUB)
010645         END-IF
010645
010645         IF  MIR-APP-FORM-TYP-ID-T (WS-UWMF-SUB) NOT = SPACES
010645         AND MIR-APP-FORM-TYP-ID-T (WS-UWMF-SUB) NOT =
010645                               WS-APP-FORM-TYP (WS-UWMF-SUB)
013578***          MOVE LOW-VALUES    TO  WAFTT-KEY
013578***          MOVE MIR-APP-FORM-TYP-ID-T (WS-UWMF-SUB)
013578***                             TO WAFTT-APP-FORM-TYP-ID
013578***          MOVE WGLOB-USER-LANG
013578***                             TO WAFTT-APP-FORM-LANG-CD
013578***          MOVE HIGH-VALUES   TO  WAFTT-ENDBR-KEY
013578***          MOVE MIR-APP-FORM-TYP-ID-T  (WS-UWMF-SUB)
013578***                             TO WAFTT-ENDBR-APP-FORM-TYP-ID
013578***          MOVE WGLOB-USER-LANG
013578***                             TO WAFTT-ENDBR-APP-FORM-LANG-CD
013578***          PERFORM  AFTT-1000-BROWSE
013578***             THRU  AFTT-1000-BROWSE-X
013578***          PERFORM  AFTT-2000-READ-NEXT
013578***             THRU  AFTT-2000-READ-NEXT-X
013578***          IF  WAFTT-IO-OK
013578             MOVE MIR-APP-FORM-TYP-ID-T (WS-UWMF-SUB) TO
013578                            WEDIT-ETBL-VALU-ID
013578             PERFORM AFTT-1000-EDIT
013578                THRU AFTT-1000-EDIT-X
013578             IF WEDIT-IO-OK
010645                 PERFORM 7556-INSERT-MIR-FORM-TYPE
010645                    THRU 7556-INSERT-MIR-FORM-TYPE-X
010645             ELSE
010645                 MOVE 'N'       TO WS-VALIDATE-FORM
010645                 MOVE 'N'       TO WS-DATA-EDITS
010645*MSG: NS03600006 - INVALID FORM TYPE CODE @1
010645                 MOVE 'NS03600006'
                                      TO WGLOB-MSG-REF-INFO
010645                 MOVE MIR-APP-FORM-TYP-ID-T (WS-UWMF-SUB)
010645                                TO WGLOB-MSG-PARM (1)
010645                 PERFORM   0260-1000-GENERATE-MESSAGE
010645                     THRU  0260-1000-GENERATE-MESSAGE-X
010645             END-IF
013578***          PERFORM  AFTT-3000-END-BROWSE
013578***             THRU  AFTT-3000-END-BROWSE-X
010645         END-IF
010645     END-PERFORM.
010645
010645* IF ALL OF THE FORM TYPES ARE VALID, REFRESH THE COMMAREA
010645* FROM THE UPDATED TABLE
010645*
010645     IF WS-VALID-FORM
010645         PERFORM  8100-GET-FORM-TYPES
010645             THRU 8100-GET-FORM-TYPES-X
013578         MOVE WS-APPFORM-INFO      TO MIR-APP-FORM-TYP-ID-G
010645     END-IF.
010645
       7506-EDIT-FORM-TYPE-X.
           EXIT.

      *
010645*--------------------
010645 7507-EDIT-LOC-GR-CD.
010645*--------------------
010645*****************************************************************
010645*  LOC GRP CODE: MUST BE VALIDATED AGAINST EDIT TABLE
010645*****************************************************************
010645
010645* IF INCLUDE\EXCLUDE CODE = A(ALL) THEN CLEAR/DELETE LIST
010645
017087*    MOVE MIR-LOC-GRP-PRCES-CD  TO WS-TEST-LINCEX-CD.
017087     MOVE MIR-LOC-GR-PRCES-CD   TO WS-TEST-LINCEX-CD.
010645     IF WS-LINCEX-CD-A
010645        MOVE WS-LOCGR-INFO   TO MIR-LOC-GR-ID-G
010645
010645        PERFORM
010645            VARYING  WS-LCGP-SUB FROM 1 BY 1
010645              UNTIL (WS-LCGP-SUB > WS-MAX-LCGP)
010645            IF  WS-LOC-GR-CD (WS-LCGP-SUB) = SPACES
010645                CONTINUE
010645            ELSE
010645                MOVE WS-LOC-GR-CD (WS-LCGP-SUB)
010645                                TO WUWML-LOC-GR-ID
010645                PERFORM  7553-DELETE-MIR-LCGP-CODES
010645                    THRU 7553-DELETE-MIR-LCGP-CODES-X
010645                MOVE SPACES     TO WS-LOC-GR-CD (WS-LCGP-SUB)
010645            END-IF
010645        END-PERFORM
010645
010645        MOVE WS-LOCGR-INFO   TO MIR-LOC-GR-ID-G
010645        GO TO 7507-EDIT-LOC-GR-CD-X
010645
010645     END-IF.
010645
010645     MOVE 'Y'                   TO WS-VALIDATE-LOC-GR.
010645
010645     IF MIR-LOC-GR-ID-G = SPACES
010645         MOVE WS-LOCGR-INFO  TO MIR-LOC-GR-ID-G
010645         GO TO 7507-EDIT-LOC-GR-CD-X
010645     END-IF.
010645
010645     PERFORM
010645         VARYING  WS-LCGP-SUB FROM 1 BY 1
010645           UNTIL (WS-LCGP-SUB > WS-MAX-LCGP)
010645         IF  MIR-LOC-GR-ID-T (WS-LCGP-SUB) = SPACES
010645             MOVE WS-LOC-GR-CD         (WS-LCGP-SUB)
010645                                TO MIR-LOC-GR-ID-T (WS-LCGP-SUB)
010645         ELSE
010645             IF MIR-LOC-GR-ID-T (WS-LCGP-SUB) =
010645                                        EBLCH-BLANK-FIELD-CHAR
010645             OR MIR-LOC-GR-ID-T (WS-LCGP-SUB) NOT =
010645                               WS-LOC-GR-CD   (WS-LCGP-SUB)
010645                 MOVE WS-LOC-GR-CD (WS-LCGP-SUB)
010645                                TO WUWML-LOC-GR-ID
010645                 PERFORM  7553-DELETE-MIR-LCGP-CODES
010645                     THRU 7553-DELETE-MIR-LCGP-CODES-X
010645                 MOVE SPACES    TO WS-LOC-GR-CD (WS-LCGP-SUB)
010645             END-IF
010645         END-IF
010645     END-PERFORM.
010645
010645     PERFORM
010645         VARYING  WS-LCGP-SUB FROM 1 BY 1
010645           UNTIL (WS-LCGP-SUB > WS-MAX-LCGP)
010645         IF MIR-LOC-GR-ID-T (WS-LCGP-SUB) = EBLCH-BLANK-FIELD-CHAR
010645             MOVE SPACES        TO MIR-LOC-GR-ID-T (WS-LCGP-SUB)
010645         END-IF
010645
010645         IF  MIR-LOC-GR-ID-T (WS-LCGP-SUB) NOT = SPACES
010645         AND MIR-LOC-GR-ID-T (WS-LCGP-SUB) NOT =
010645                               WS-LOC-GR-CD (WS-LCGP-SUB)
010645
010645             MOVE MIR-LOC-GR-ID-T (WS-LCGP-SUB)
                                      TO
010645                                       WEDIT-ETBL-VALU-ID
010645             PERFORM  LCGP-1000-EDIT-LCGP-LOCATION
010645                 THRU LCGP-1000-EDIT-LCGP-LOCATION-X
010645             IF  WEDIT-IO-OK
010645                 PERFORM  7554-INSERT-MIR-LCGP-CODE
010645                     THRU 7554-INSERT-MIR-LCGP-CODE-X
010645             ELSE
010645                 MOVE 'N'       TO WS-VALIDATE-LOC-GR
010645                 MOVE 'N'       TO WS-DATA-EDITS
010645*MSG: NS03600049 - INVALID LOCATION GROUP CODE @1
010645                 MOVE 'NS03600049'
                                      TO WGLOB-MSG-REF-INFO
010645                 MOVE MIR-LOC-GR-ID-T (WS-LCGP-SUB)
010645                                TO WGLOB-MSG-PARM (1)
010645                 PERFORM  0260-1000-GENERATE-MESSAGE
010645                     THRU 0260-1000-GENERATE-MESSAGE-X
010645             END-IF
010645         END-IF
010645     END-PERFORM.
010645
010645* IF ALL OF THE LOC GR CODES ARE VALID, REFRESH THE COMMAREA
010645* FROM THE UPDATED TABLE
010645*
010645     IF WS-VALID-LOC-GR
010645         PERFORM  8300-GET-LOC-GR-CODES
010645             THRU 8300-GET-LOC-GR-CODES-X
013578         MOVE WS-LOCGR-INFO  TO MIR-LOC-GR-ID-G
010645     END-IF.
010645
010645 7507-EDIT-LOC-GR-CD-X.
010645     EXIT.
010645*
      *---------------------
       7508-EDIT-AGE-RANGES.
      *---------------------
      *****************************************************************
      * EDIT AGE RANGE:
      * LOW AGE/HIGH AGE MUST BE NUMERIC IN RANGE 01 - 99
      *****************************************************************

557660     PERFORM  7509-EDIT-LOW-AGE
557660         THRU 7509-EDIT-LOW-AGE-X.

557660     PERFORM  7510-EDIT-HIGH-AGE
557660         THRU 7510-EDIT-HIGH-AGE-X.

           IF WS-DATA-EDITS-OK
557660         PERFORM  7511-CROSS-EDIT-AGES
557660             THRU 7511-CROSS-EDIT-AGES-X
557660     END-IF.

       7508-EDIT-AGE-RANGES-X.
           EXIT.

      *------------------
557660 7509-EDIT-LOW-AGE.
      *------------------

           IF MIR-CCAS-TST-LOW-AGE = SPACES
               MOVE RUWMX-CCAS-TST-LOW-AGE
                                      TO WS-NUM-999
               MOVE WS-NUM-PART2      TO MIR-CCAS-TST-LOW-AGE
557660         GO TO 7509-EDIT-LOW-AGE-X
           ELSE
               IF MIR-CCAS-TST-LOW-AGE = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO WS-NUM-999
                   MOVE WS-NUM-PART2  TO MIR-CCAS-TST-LOW-AGE
557660         END-IF
557660     END-IF.

      *
      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE '2'                   TO L0280-LENGTH.
           MOVE '2'                   TO L0280-INPUT-SIZE.

      *
      ***  PERFORM NUMERIC EDIT.
      *
           MOVE MIR-CCAS-TST-LOW-AGE  TO L0280-INPUT-DATA.

           PERFORM 7800-NUMERIC-EDIT
              THRU 7800-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-99
               MOVE WS-NUM-99         TO MIR-CCAS-TST-LOW-AGE
               MOVE WS-NUM-99         TO RUWMX-CCAS-TST-LOW-AGE
           ELSE
               MOVE 'NS03600007'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

557660 7509-EDIT-LOW-AGE-X.
           EXIT.

      *-------------------
557660 7510-EDIT-HIGH-AGE.
      *-------------------

           IF MIR-CCAS-TST-HIGH-AGE = SPACES
               MOVE RUWMX-CCAS-TST-HIGH-AGE
                                      TO WS-NUM-999
               MOVE WS-NUM-PART2      TO MIR-CCAS-TST-HIGH-AGE
557660         GO TO 7510-EDIT-HIGH-AGE-X
           ELSE
               IF MIR-CCAS-TST-HIGH-AGE = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO WS-NUM-999
                   MOVE WS-NUM-PART2  TO MIR-CCAS-TST-HIGH-AGE
557660         END-IF
557660     END-IF.

      *
      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE '2'                   TO L0280-LENGTH.
           MOVE '2'                   TO L0280-INPUT-SIZE.

      *
      ***  PERFORM NUMERIC EDIT.
      *
           MOVE MIR-CCAS-TST-HIGH-AGE TO L0280-INPUT-DATA.

           PERFORM 7800-NUMERIC-EDIT
              THRU 7800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-99
               MOVE WS-NUM-99         TO MIR-CCAS-TST-HIGH-AGE
               MOVE WS-NUM-99         TO RUWMX-CCAS-TST-HIGH-AGE
           ELSE
               MOVE 'NS03600007'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

557660 7510-EDIT-HIGH-AGE-X.
           EXIT.

      *---------------------
557660 7511-CROSS-EDIT-AGES.
      *---------------------

           MOVE MIR-CCAS-TST-LOW-AGE  TO WS-HOLD-AGE.

           IF WS-WORK-AGE-NUM < 00
               MOVE 'N'               TO WS-DATA-EDITS
               MOVE 'NS03600007'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660         GO TO 7511-CROSS-EDIT-AGES-X
557660     END-IF.

           MOVE MIR-CCAS-TST-HIGH-AGE TO WS-HOLD-AGE.
           IF WS-WORK-AGE-NUM  > 99
               MOVE 'N'               TO WS-DATA-EDITS
               MOVE 'NS03600007'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660         GO TO 7511-CROSS-EDIT-AGES-X
557660     END-IF.

           MOVE MIR-CCAS-TST-LOW-AGE  TO WS-HOLD-AGE.
           MOVE WS-WORK-AGE-NUM       TO WS-NUM-PART2.
           MOVE MIR-CCAS-TST-HIGH-AGE TO WS-HOLD-AGE.
           MOVE WS-WORK-AGE-NUM       TO WS-AGE-PART2.

           IF WS-NUM-PART2 > WS-AGE-PART2
               MOVE 'N'               TO WS-DATA-EDITS
               MOVE 'NS03600008'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660         GO TO 7511-CROSS-EDIT-AGES-X
557660     END-IF.

           IF WS-AGE-PART2 < WS-NUM-PART2
               MOVE 'N'               TO WS-DATA-EDITS
               MOVE 'NS03600008'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
557660         GO TO 7511-CROSS-EDIT-AGES-X
557660     END-IF.

            MOVE MIR-CCAS-TST-LOW-AGE TO WS-HOLD-AGE.
            MOVE WS-WORK-AGE-NUM      TO RUWMX-CCAS-TST-LOW-AGE
            MOVE MIR-CCAS-TST-HIGH-AGE                   TO WS-HOLD-AGE.
            MOVE WS-WORK-AGE-NUM      TO RUWMX-CCAS-TST-HIGH-AGE.

557660 7511-CROSS-EDIT-AGES-X.
           EXIT.
      *
      *------------------------
557660 7512-EDIT-FAILURE-RQMNT.
      *------------------------
      *****************************************************************
      *  REQUIREMENT CODE: USER DEFINED FIELDS THAT SHOULD EXIST ON
      *                    THE EDIT TABLE.
      *****************************************************************

      *
      ***  A BLANK (BLANK-FIELD-CHAR) REQUIREMENT CODE IS ACCEPTABLE
      ***  SO IT IS NOT EDITED.
      *
010645*    IF MIR-REQIR-ID-T (WS-RQCD) = SPACES
010645*        MOVE RUWMX-REQIR-ID         (WS-RQCD)
010645*                              TO MIR-REQIR-ID-T (WS-RQCD)
010645*        GO TO 7512-EDIT-FAILURE-RQMNT-X
010645*    ELSE
010645*        IF MIR-REQIR-ID-T (WS-RQCD) = EBLCH-BLANK-FIELD-CHAR
010645*            MOVE SPACES       TO MIR-REQIR-ID-T (WS-RQCD)
010645*            MOVE SPACES       TO RUWMX-REQIR-ID(WS-RQCD)
010645*            GO TO 7512-EDIT-FAILURE-RQMNT-X
010645*        END-IF
010645*    END-IF.
010645*
010645*
010645***  DETERMINE IF THE REQUIREMENT CODE EXISTS.
010645*
010645*    MOVE MIR-REQIR-ID-T (WS-RQCD) TO WRTAB-REQIR-ID.
010645*
010645*    PERFORM RTAB-1000-READ
010645*       THRU RTAB-1000-READ-X.
010645*
010645*    IF WRTAB-IO-OK
010645*        MOVE MIR-REQIR-ID-T (WS-RQCD)
010645*            TO RUWMX-REQIR-ID(WS-RQCD)
010645*    ELSE
010645*        MOVE 'XS00000114'         TO WGLOB-MSG-REF-INFO
010645*        MOVE WRTAB-KEY            TO WGLOB-MSG-PARM (1)
010645*        PERFORM 0260-1000-GENERATE-MESSAGE
010645*           THRU 0260-1000-GENERATE-MESSAGE-X
010645*        MOVE 'N'                  TO WS-DATA-EDITS
010645*        MOVE 'N'                  TO WS-VALIDATE-CODES
010645*    END-IF.

010645     MOVE 'Y'                   TO WS-VALIDATE-CODES.
010645
010645     IF MIR-REQIR-ID-G = SPACES
010645         MOVE WS-REQIR-INFO  TO MIR-REQIR-ID-G
010645         GO TO 7512-EDIT-FAILURE-RQMNT-X
010645     END-IF.
010645
010645     PERFORM
010645         VARYING  WS-RQCD FROM 1 BY 1
010645           UNTIL (WS-RQCD > WS-MAX-RQCD)
010645         IF  MIR-REQIR-ID-T (WS-RQCD) = SPACES
010645             MOVE WS-REQIR-ID         (WS-RQCD)
010645                                TO MIR-REQIR-ID-T (WS-RQCD)
010645         ELSE
010645             IF MIR-REQIR-ID-T (WS-RQCD) = EBLCH-BLANK-FIELD-CHAR
010645             OR MIR-REQIR-ID-T (WS-RQCD) NOT =
010645                               WS-REQIR-ID   (WS-RQCD)
010645                 MOVE WS-REQIR-ID (WS-RQCD)
010645                                TO WUWMR-REQIR-ID
010645                 PERFORM  7551-DELETE-MIR-RQMNT-CODES
010645                     THRU 7551-DELETE-MIR-RQMNT-CODES-X
010645                 MOVE SPACES    TO WS-REQIR-ID (WS-RQCD)
010645             END-IF
010645         END-IF
010645     END-PERFORM.
010645
010645     PERFORM
010645         VARYING  WS-RQCD FROM 1 BY 1
010645           UNTIL (WS-RQCD > WS-MAX-RQCD)
010645
010645         IF  MIR-REQIR-ID-T (WS-RQCD) = EBLCH-BLANK-FIELD-CHAR
010645             MOVE SPACES        TO MIR-REQIR-ID-T (WS-RQCD)
010645         END-IF
010645
010645         IF  MIR-REQIR-ID-T (WS-RQCD) NOT = SPACES
010645         AND MIR-REQIR-ID-T (WS-RQCD) NOT =
010645                               WS-REQIR-ID   (WS-RQCD)
010645             MOVE MIR-REQIR-ID-T (WS-RQCD)
                                      TO WRTAB-REQIR-ID
010645             PERFORM RTAB-1000-READ
010645                THRU RTAB-1000-READ-X
010645             IF WRTAB-IO-OK
010645                 PERFORM  7552-INSERT-MIR-RQMNT-CODE
010645                     THRU 7552-INSERT-MIR-RQMNT-CODE-X
010645             ELSE
010645*MSG: XS00000114 - INVALID FAILURE REQUIREMENT ID @1
010645                 MOVE 'XS00000114'
                                      TO WGLOB-MSG-REF-INFO
010645                 MOVE WRTAB-KEY TO WGLOB-MSG-PARM (1)
010645                 PERFORM  0260-1000-GENERATE-MESSAGE
010645                     THRU 0260-1000-GENERATE-MESSAGE-X
010645                 MOVE 'N'       TO WS-DATA-EDITS
010645                 MOVE 'N'       TO WS-VALIDATE-CODES
010645             END-IF
010645         END-IF
010645     END-PERFORM.
010645
010645* IF ALL OF THE REQIR CODES ARE VALID, REFRESH THE COMMAREA
010645* FROM THE UPDATED TABLE
010645
010645     IF WS-VALID-CODES
010645         PERFORM  8200-GET-RQMNT-CODES
010645             THRU 8200-GET-RQMNT-CODES-X
013578         MOVE WS-REQIR-INFO  TO MIR-REQIR-ID-G
010645     END-IF.
010645
557660 7512-EDIT-FAILURE-RQMNT-X.
           EXIT.
      *
      *---------------------
557660 7513-EDIT-FIELD-NAME.
      *---------------------
      *****************************************************************
      *  FIELD NAME: PRIMARY KEY TO THE DFLD FILE.
      *****************************************************************

           IF MIR-FLD-ID = SPACES
               MOVE RUWMX-FLD-ID      TO MIR-FLD-ID
           ELSE
               IF MIR-FLD-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-FLD-ID
557660         END-IF
557660     END-IF.

      *
      ***  PERFORM KEY EDIT.
      *
           MOVE MIR-FLD-ID            TO WDFLD-FLD-ID.

           PERFORM DFLD-1000-READ
              THRU DFLD-1000-READ-X.

           IF WDFLD-IO-OK
               MOVE MIR-FLD-ID        TO RUWMX-FLD-ID
           ELSE
               MOVE 'N'               TO WS-VALIDATE-FLD-NAME
               MOVE 'NS03600009'      TO WGLOB-MSG-REF-INFO
               MOVE WDFLD-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

557660 7513-EDIT-FIELD-NAME-X.
           EXIT.

      *
      *-----------------------
       7514-EDIT-UNANSWD-RESP.
      *-----------------------
      *****************************************************************
      *  UNANSWERED-RESPONSE: CAN BE F(FAIL), P(PASS), S(SUBSET).
      *****************************************************************

           IF MIR-UNANSWR-ACT-CD = SPACES
               MOVE RUWMX-UNANSWR-ACT-CD
                                      TO MIR-UNANSWR-ACT-CD
           ELSE
               IF MIR-UNANSWR-ACT-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-UNANSWR-ACT-CD
557660         END-IF
557660     END-IF.

           MOVE MIR-UNANSWR-ACT-CD    TO WS-SAVE-ACTION.

           IF WS-VALID-ACTION
               MOVE MIR-UNANSWR-ACT-CD           TO RUWMX-UNANSWR-ACT-CD
           ELSE
               MOVE 'NS03600010'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7514-EDIT-UNANSWD-RESP-X.
           EXIT.

      *
010645*-------------------------
010645 7515-EDIT-INCEX-LOC-GR-CD.
010645*-------------------------
010645
010645*****************************************************
010645* INCLUDE/EXCLUDE LOCATION GROUP: CODE MUST BE VALID
010645*****************************************************
010645
017087*    IF  MIR-LOC-GRP-PRCES-CD = SPACES
017087*        MOVE RUWMX-LOC-GRP-PRCES-CD
017087*                               TO MIR-LOC-GRP-PRCES-CD
017087     IF  MIR-LOC-GR-PRCES-CD = SPACES
017087         MOVE RUWMX-LOC-GR-PRCES-CD
017087                                TO MIR-LOC-GR-PRCES-CD
010645     ELSE
017087*       IF MIR-LOC-GRP-PRCES-CD = EBLCH-BLANK-FIELD-CHAR
017087*          MOVE SPACE           TO MIR-LOC-GRP-PRCES-CD
017087        IF MIR-LOC-GR-PRCES-CD = EBLCH-BLANK-FIELD-CHAR
017087           MOVE SPACE           TO MIR-LOC-GR-PRCES-CD
010645        END-IF
010645     END-IF.
010645
017087*    IF MIR-LOC-GRP-PRCES-CD = SPACE
017087*       MOVE 'A'                TO MIR-LOC-GRP-PRCES-CD
017087     IF MIR-LOC-GR-PRCES-CD = SPACE
017087        MOVE 'A'                TO MIR-LOC-GR-PRCES-CD
010645     END-IF.
010645
017087*    MOVE MIR-LOC-GRP-PRCES-CD  TO WS-TEST-INCEX-CD.
017087     MOVE MIR-LOC-GR-PRCES-CD   TO WS-TEST-INCEX-CD.
010645
010645     IF  WS-VALID-INCEX-CD
017087*         MOVE MIR-LOC-GRP-PRCES-CD
017087*                               TO RUWMX-LOC-GRP-PRCES-CD
017087          MOVE MIR-LOC-GR-PRCES-CD
017087                                TO RUWMX-LOC-GR-PRCES-CD
010645     ELSE
010645         MOVE 'N'               TO WS-DATA-EDITS
010645         MOVE 'NS03600048'      TO WGLOB-MSG-REF-INFO
010645         PERFORM  0260-1000-GENERATE-MESSAGE
010645             THRU 0260-1000-GENERATE-MESSAGE-X
010645     END-IF.
010645
010645 7515-EDIT-INCEX-LOC-GR-CD-X.
010645     EXIT.
010418*
010418*-------------------------
010418 7516-EDIT-INCEX-SBSDRY-CD.
010418*-------------------------
010418
010418*************************************************
010418* INCLUDE/EXCLUDE SUB COMPANY: CODE MUST BE VALID
010418*************************************************
010418
010418     IF  MIR-SBSDRY-CO-PRCES-CD = SPACES
010418         MOVE RUWMX-SBSDRY-CO-PRCES-CD
                                      TO MIR-SBSDRY-CO-PRCES-CD
010418     ELSE
010418         IF MIR-SBSDRY-CO-PRCES-CD = EBLCH-BLANK-FIELD-CHAR
010418            MOVE SPACE          TO MIR-SBSDRY-CO-PRCES-CD
010418         END-IF
010418     END-IF.
010418
010418     IF MIR-SBSDRY-CO-PRCES-CD = SPACE
010418         MOVE 'A'               TO MIR-SBSDRY-CO-PRCES-CD
010418     END-IF.
010418
010418     MOVE MIR-SBSDRY-CO-PRCES-CD              TO WS-TEST-INCEX-CD.
010418
010418     IF  WS-VALID-INCEX-CD
010418          MOVE MIR-SBSDRY-CO-PRCES-CD
                                      TO RUWMX-SBSDRY-CO-PRCES-CD
010418     ELSE
010418         MOVE 'N'               TO WS-DATA-EDITS
010418         MOVE 'NS03600048'      TO WGLOB-MSG-REF-INFO
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418     END-IF.
010418
010418 7516-EDIT-INCEX-SBSDRY-CD-X.
010418     EXIT.
010418*
010418*--------------------
010418 7517-EDIT-SBSDRY-CD.
010418*--------------------
010418*****************************************************************
010418*  SUB CO ID: MUST BE VALIDATED AGAINST SCOM TABLE
010418*****************************************************************
010418
010645* IF INCLUDE\EXCLUDE CODE = A(ALL) THEN CLEAR/DELETE LIST
010645
010645     MOVE MIR-SBSDRY-CO-PRCES-CD             TO WS-TEST-SINCEX-CD.
010645     IF WS-SINCEX-CD-A
010645        MOVE WS-SBSDRY-CO-INFO
                                      TO MIR-SBSDRY-CO-ID-G
010645
010645        PERFORM
010645            VARYING  WS-SBCO-SUB FROM 1 BY 1
010645              UNTIL (WS-SBCO-SUB > WS-MAX-SBCO)
010645            IF  WS-SBSDRY-CO-ID (WS-SBCO-SUB) = SPACES
010645                CONTINUE
010645            ELSE
010645                MOVE WS-SBSDRY-CO-ID (WS-SBCO-SUB)
010645                                TO WUWMS-SBSDRY-CO-ID
010418                PERFORM  7557-DELETE-MIR-SBSDRY-CDS
010418                    THRU 7557-DELETE-MIR-SBSDRY-CDS-X
010645                MOVE SPACES    TO WS-SBSDRY-CO-ID (WS-SBCO-SUB)
010645            END-IF
010645        END-PERFORM
010645
010645        MOVE WS-SBSDRY-CO-INFO
                                      TO MIR-SBSDRY-CO-ID-G
010645        GO TO 7517-EDIT-SBSDRY-CD-X
010645
010645     END-IF.
010645
010418     MOVE 'Y'                   TO WS-VALIDATE-SBSDRY-CO-ID.
010418
010418     IF MIR-SBSDRY-CO-ID-G = SPACES
010418         MOVE WS-SBSDRY-CO-INFO
                                      TO MIR-SBSDRY-CO-ID-G
010418         GO TO 7517-EDIT-SBSDRY-CD-X
010418     END-IF.
010418
010418     PERFORM
010645         VARYING WS-SBCO-SUB FROM 1 BY 1
010418           UNTIL WS-SBCO-SUB > WS-MAX-SBCO
010418         IF  MIR-SBSDRY-CO-ID-T (WS-SBCO-SUB) = SPACES
010418             MOVE WS-SBSDRY-CO-ID (WS-SBCO-SUB)
010418                               TO MIR-SBSDRY-CO-ID-T (WS-SBCO-SUB)
010418         ELSE
010418             IF MIR-SBSDRY-CO-ID-T (WS-SBCO-SUB) =
010418                                        EBLCH-BLANK-FIELD-CHAR
010418             OR MIR-SBSDRY-CO-ID-T (WS-SBCO-SUB) NOT =
010418                               WS-SBSDRY-CO-ID   (WS-SBCO-SUB)
010418                 MOVE WS-SBSDRY-CO-ID (WS-SBCO-SUB)
010418                                TO WUWMS-SBSDRY-CO-ID
010418                 PERFORM  7557-DELETE-MIR-SBSDRY-CDS
010418                     THRU 7557-DELETE-MIR-SBSDRY-CDS-X
010418                 MOVE SPACES   TO WS-SBSDRY-CO-ID (WS-SBCO-SUB)
010418             END-IF
010418         END-IF
010418     END-PERFORM.
010418
010418     PERFORM
010418         VARYING  WS-SBCO-SUB FROM 1 BY 1
010418           UNTIL (WS-SBCO-SUB > WS-MAX-SBCO)
010418         IF MIR-SBSDRY-CO-ID-T (WS-SBCO-SUB) =
                                        EBLCH-BLANK-FIELD-CHAR
010418             MOVE SPACES       TO MIR-SBSDRY-CO-ID-T (WS-SBCO-SUB)
010418         END-IF
010418
010418         IF  MIR-SBSDRY-CO-ID-T (WS-SBCO-SUB) NOT = SPACES
010418         AND MIR-SBSDRY-CO-ID-T (WS-SBCO-SUB) NOT =
010418                               WS-SBSDRY-CO-ID (WS-SBCO-SUB)
010418
010418             MOVE MIR-SBSDRY-CO-ID-T (WS-SBCO-SUB)
                                      TO
010418                                       WSCOM-SBSDRY-CO-ID
010418             PERFORM  SCOM-1000-READ
010418                 THRU SCOM-1000-READ-X
010418             IF  WSCOM-IO-OK
010418                 PERFORM  7558-INSERT-MIR-SBSDRY-CO-ID
010418                     THRU 7558-INSERT-MIR-SBSDRY-CO-ID-X
010418             ELSE
010418                 MOVE 'N'       TO WS-VALIDATE-SBSDRY-CO-ID
010418                 MOVE 'N'       TO WS-DATA-EDITS
010418*MSG: NS03600054 - INVALID SUBSIDIARY COMPANY ID @1
010418                 MOVE 'NS03600052'
                                      TO WGLOB-MSG-REF-INFO
010418                 MOVE MIR-SBSDRY-CO-ID-T (WS-SBCO-SUB)
010418                                TO WGLOB-MSG-PARM (1)
010418                 PERFORM  0260-1000-GENERATE-MESSAGE
010418                     THRU 0260-1000-GENERATE-MESSAGE-X
010418             END-IF
010418         END-IF
010418     END-PERFORM.
010418
010418* IF ALL OF THE SUB CO IDS ARE VALID, REFRESH THE COMMAREA
010418* FROM THE UPDATED TABLE
010418*
010418     IF WS-VALID-SBSDRY-CO-ID
010418         PERFORM  8400-GET-SBSDRY-INFO
010418             THRU 8400-GET-SBSDRY-INFO-X
013578         MOVE WS-SBSDRY-CO-INFO TO MIR-SBSDRY-CO-ID-G
010418     END-IF.
010418
010418 7517-EDIT-SBSDRY-CD-X.
010418     EXIT.
010418*

      *--------------------
       7520-EDIT-YESNO-YES.
      *--------------------
      *****************************************************************
      *  YESNO TEST IF YES: CAN BE F(FAIL), P(PASS), S(SUBSET).
      *****************************************************************

013597*    IF MIR-DV-ANSWR-YES-ACT-CD = SPACES
013597*        MOVE RUWMX-ANSWR-YES-ACT-CD
013597*                               TO MIR-DV-ANSWR-YES-ACT-CD
013597*    ELSE
013597*        IF MIR-DV-ANSWR-YES-ACT-CD = EBLCH-BLANK-FIELD-CHAR
013597*            MOVE SPACES        TO MIR-DV-ANSWR-YES-ACT-CD
013597     IF MIR-ANSWR-YES-ACT-CD = SPACES
013597         MOVE RUWMX-ANSWR-YES-ACT-CD
013597                                TO MIR-ANSWR-YES-ACT-CD
013597     ELSE
013597         IF MIR-ANSWR-YES-ACT-CD = EBLCH-BLANK-FIELD-CHAR
013597             MOVE SPACES        TO MIR-ANSWR-YES-ACT-CD
557660         END-IF
557660     END-IF.

013597*    MOVE MIR-DV-ANSWR-YES-ACT-CD   TO WS-SAVE-ACTION.
013597     MOVE MIR-ANSWR-YES-ACT-CD      TO WS-SAVE-ACTION.

           IF WS-VALID-ACTION
013597*        MOVE MIR-DV-ANSWR-YES-ACT-CD
013597         MOVE MIR-ANSWR-YES-ACT-CD
                                      TO RUWMX-ANSWR-YES-ACT-CD
           ELSE
               MOVE 'NS03600013'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7520-EDIT-YESNO-YES-X.
           EXIT.

      *-------------------
       7522-EDIT-YESNO-NO.
      *-------------------
      *****************************************************************
      *  YESNO TEST IF NO: CAN BE F(FAIL), P(PASS), S(SUBSET).
      *****************************************************************

013597*    IF MIR-DV-ANSWR-NO-ACT-CD = SPACES
013597*        MOVE RUWMX-ANSWR-NO-ACT-CD
013597*                               TO MIR-DV-ANSWR-NO-ACT-CD
013597*    ELSE
013597*        IF MIR-DV-ANSWR-NO-ACT-CD = EBLCH-BLANK-FIELD-CHAR
013597*            MOVE SPACES        TO MIR-DV-ANSWR-NO-ACT-CD
013597     IF MIR-ANSWR-NO-ACT-CD = SPACES
013597         MOVE RUWMX-ANSWR-NO-ACT-CD
013597                                TO MIR-ANSWR-NO-ACT-CD
013597     ELSE
013597         IF MIR-ANSWR-NO-ACT-CD = EBLCH-BLANK-FIELD-CHAR
013597             MOVE SPACES        TO MIR-ANSWR-NO-ACT-CD
557660         END-IF
557660     END-IF.

013597*    MOVE MIR-DV-ANSWR-NO-ACT-CD   TO WS-SAVE-ACTION.
013597     MOVE MIR-ANSWR-NO-ACT-CD      TO WS-SAVE-ACTION.
           IF WS-VALID-ACTION
013597*        MOVE MIR-DV-ANSWR-NO-ACT-CD
013597         MOVE MIR-ANSWR-NO-ACT-CD
                                      TO RUWMX-ANSWR-NO-ACT-CD
           ELSE
               MOVE 'NS03600014'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7522-EDIT-YESNO-NO-X.
           EXIT.

      *
      *------------------
       7524-EDIT-NUM-MIN.
      *------------------
      *****************************************************************
      *  NUMERIC RANGE MINIMUM: NUMERIC FROM 0(9)-9(9).
      *****************************************************************

013597*    IF MIR-DV-TST-NUM-MIN-AMT = SPACES
013597     IF MIR-NUM-MIN-AMT = SPACES
008455*        MOVE RUWMX-TST-NUM-MIN-AMT  TO WS-NUM-9-LEN9
008455*        MOVE WS-NUM-9-LEN9          TO MIR-DV-TST-NUM-MIN-AMT
013597*        MOVE RUWMX-TST-NUM-MIN-AMT
013597         MOVE RUWMX-NUM-MIN-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
008455         PERFORM  7900-FORMAT-NOMIN
008455             THRU 7900-FORMAT-NOMIN-X
           ELSE
013597*        IF MIR-DV-TST-NUM-MIN-AMT = EBLCH-BLANK-FIELD-CHAR
013597         IF MIR-NUM-MIN-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS              TO WS-NUM-9-LEN9
008455*            MOVE WS-NUM-9-LEN9      TO MIR-DV-TST-NUM-MIN-AMT
013597*            MOVE ZEROS         TO MIR-DV-TST-NUM-MIN-AMT
013597             MOVE ZEROS         TO MIR-NUM-MIN-AMT
557660         END-IF
557660     END-IF.

      *
      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '0'                   TO L0280-PRECISION.
008455*    MOVE '9'            TO L0280-LENGTH.
008455*    MOVE '9'            TO L0280-INPUT-SIZE.
013597*    MOVE LENGTH OF MIR-DV-TST-NUM-MIN-AMT
013597     MOVE LENGTH OF MIR-NUM-MIN-AMT
008455                                TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.

      *
      ***  PERFORM NUMERIC EDIT ON WEIGHT.
      *
013597*    MOVE MIR-DV-TST-NUM-MIN-AMT              TO L0280-INPUT-DATA.
013597     MOVE MIR-NUM-MIN-AMT                     TO L0280-INPUT-DATA.

           PERFORM 7800-NUMERIC-EDIT
              THRU 7800-NUMERIC-EDIT-X.

           IF L0280-OK
008455*        MOVE L0280-OUTPUT         TO WS-NUM-9-LEN9
008455*        MOVE WS-NUM-9-LEN9        TO MIR-DV-TST-NUM-MIN-AMT
008455*        MOVE MIR-DV-TST-NUM-MIN-AMT      TO RUWMX-TST-NUM-MIN-AMT
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
008455         PERFORM  7900-FORMAT-NOMIN
008455             THRU 7900-FORMAT-NOMIN-X
013597*        MOVE L0280-OUTPUT      TO RUWMX-TST-NUM-MIN-AMT
013597         MOVE L0280-OUTPUT      TO RUWMX-NUM-MIN-AMT
           ELSE
               MOVE 'NS03600015'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7524-EDIT-NUM-MIN-X.
           EXIT.

      *
      *------------------
       7526-EDIT-NUM-MAX.
      *------------------
      *****************************************************************
      *  NUMERIC RANGE MAXIMUM: NUMERIC FROM 0(9)-9(9).
      *****************************************************************

013597*    IF MIR-DV-TST-NUM-MAX-AMT = SPACES
013597     IF MIR-NUM-MAX-AMT = SPACES
008455*        MOVE RUWMX-TST-NUM-MAX-AMT   TO WS-NUM-9-LEN9
008455*        MOVE WS-NUM-9-LEN9           TO MIR-DV-TST-NUM-MAX-AMT
013597*        MOVE RUWMX-TST-NUM-MAX-AMT
013597         MOVE RUWMX-NUM-MAX-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
008455         PERFORM  7902-FORMAT-NUMAX
008455             THRU 7902-FORMAT-NUMAX-X
           ELSE
013597*        IF MIR-DV-TST-NUM-MAX-AMT = EBLCH-BLANK-FIELD-CHAR
013597         IF MIR-NUM-MAX-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE ZEROS               TO WS-NUM-9-LEN9
008455*            MOVE WS-NUM-9-LEN9       TO MIR-DV-TST-NUM-MAX-AMT
013597*            MOVE ZEROS         TO MIR-DV-TST-NUM-MAX-AMT
013597             MOVE ZEROS         TO MIR-NUM-MAX-AMT
557660         END-IF
557660     END-IF.

      *
      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '0'                   TO L0280-PRECISION.
008455*    MOVE '9'            TO L0280-LENGTH.
008455*    MOVE '9'            TO L0280-INPUT-SIZE.
013597*    MOVE LENGTH OF MIR-DV-TST-NUM-MAX-AMT
013597     MOVE LENGTH OF MIR-NUM-MAX-AMT
008455                                TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.

      *
      ***  PERFORM NUMERIC EDIT ON WEIGHT.
      *
013597*    MOVE MIR-DV-TST-NUM-MAX-AMT              TO L0280-INPUT-DATA.
013597     MOVE MIR-NUM-MAX-AMT              TO L0280-INPUT-DATA.

           PERFORM 7800-NUMERIC-EDIT
              THRU 7800-NUMERIC-EDIT-X.

           IF L0280-OK
008455*        MOVE L0280-OUTPUT         TO WS-NUM-9-LEN9
008455*        MOVE WS-NUM-9-LEN9        TO MIR-DV-TST-NUM-MAX-AMT
008455*        MOVE MIR-DV-TST-NUM-MAX-AMT      TO RUWMX-TST-NUM-MAX-AMT
020874*        MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
008455         PERFORM  7902-FORMAT-NUMAX
008455             THRU 7902-FORMAT-NUMAX-X
013597*        MOVE L0280-OUTPUT      TO RUWMX-TST-NUM-MAX-AMT
013597         MOVE L0280-OUTPUT      TO RUWMX-NUM-MAX-AMT
           ELSE
               MOVE 'NS03600016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7526-EDIT-NUM-MAX-X.
           EXIT.

      *
      *-----------------------
       7528-EDIT-NUM-IN-RANGE.
      *-----------------------
      *****************************************************************
      *  ACTION IF IN NUMERIC RANGE: CAN BE F(FAIL),P(PASS),S(SUBSET).
      *****************************************************************

013597*    IF MIR-DV-IN-RNG-ACT-CD = SPACES
013597*        MOVE RUWMX-NUM-IN-RNG-ACT-CD
013597*                               TO MIR-DV-IN-RNG-ACT-CD
013597*    ELSE
013597*        IF MIR-DV-IN-RNG-ACT-CD = EBLCH-BLANK-FIELD-CHAR
013597*            MOVE SPACES        TO MIR-DV-IN-RNG-ACT-CD
013597     IF MIR-NUM-IN-RNG-ACT-CD = SPACES
013597         MOVE RUWMX-NUM-IN-RNG-ACT-CD
013597                                TO MIR-NUM-IN-RNG-ACT-CD
013597     ELSE
013597         IF MIR-NUM-IN-RNG-ACT-CD = EBLCH-BLANK-FIELD-CHAR
013597             MOVE SPACES        TO MIR-NUM-IN-RNG-ACT-CD
557660         END-IF
557660     END-IF.

013597*    MOVE MIR-DV-IN-RNG-ACT-CD  TO WS-SAVE-ACTION.
013597     MOVE MIR-NUM-IN-RNG-ACT-CD  TO WS-SAVE-ACTION.

           IF WS-VALID-ACTION
013597*        MOVE MIR-DV-IN-RNG-ACT-CD
013597         MOVE MIR-NUM-IN-RNG-ACT-CD
                                      TO RUWMX-NUM-IN-RNG-ACT-CD
           ELSE
               MOVE 'NS03600017'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7528-EDIT-NUM-IN-RANGE-X.
           EXIT.

      *
      *------------------------
       7530-EDIT-NUM-OUT-RANGE.
      *------------------------
      *****************************************************************
      *  ACTION OUT OF NUMERIC RANGE: CAN BE F(FAIL),P(PASS),S(SUBSET).
      *****************************************************************

013597*    IF MIR-DV-OUT-RNG-ACT-CD = SPACES
013597*        MOVE RUWMX-NUM-OUT-RNG-ACT-CD
013597*                               TO MIR-DV-OUT-RNG-ACT-CD
013597*    ELSE
013597*        IF MIR-DV-OUT-RNG-ACT-CD = EBLCH-BLANK-FIELD-CHAR
013597*            MOVE SPACES        TO MIR-DV-OUT-RNG-ACT-CD
013597     IF MIR-NUM-OUT-RNG-ACT-CD = SPACES
013597         MOVE RUWMX-NUM-OUT-RNG-ACT-CD
013597                                TO MIR-NUM-OUT-RNG-ACT-CD
013597     ELSE
013597         IF MIR-NUM-OUT-RNG-ACT-CD = EBLCH-BLANK-FIELD-CHAR
013597             MOVE SPACES        TO MIR-NUM-OUT-RNG-ACT-CD
557660         END-IF
557660     END-IF.

013597*    MOVE MIR-DV-OUT-RNG-ACT-CD TO WS-SAVE-ACTION.
013597     MOVE MIR-NUM-OUT-RNG-ACT-CD TO WS-SAVE-ACTION.

           IF WS-VALID-ACTION
013597*        MOVE MIR-DV-OUT-RNG-ACT-CD
013597         MOVE MIR-NUM-OUT-RNG-ACT-CD
                                      TO RUWMX-NUM-OUT-RNG-ACT-CD
           ELSE
               MOVE 'NS03600018'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7530-EDIT-NUM-OUT-RANGE-X.
           EXIT.

      *
      *--------------------
       7532-EDIT-LIST-TYPE.
      *--------------------
      *****************************************************************
      *  EDIT TYPE: USED AS KEY TO EDIT TABLE.
      *****************************************************************

013597*    IF MIR-DV-TST-ETBL-TYP-ID = SPACES
013597*        MOVE RUWMX-TST-ETBL-TYP-ID
013597*                               TO MIR-DV-TST-ETBL-TYP-ID
013597*    ELSE
013597*        IF MIR-DV-TST-ETBL-TYP-ID = EBLCH-BLANK-FIELD-CHAR
013597*            MOVE SPACES        TO MIR-DV-TST-ETBL-TYP-ID
013597*        END-IF
013597*    END-IF.

013597     IF MIR-LIST-ETBL-TYP-ID = SPACES
013597         MOVE RUWMX-LIST-ETBL-TYP-ID
013597                                TO MIR-LIST-ETBL-TYP-ID
013597     ELSE
013597         IF MIR-LIST-ETBL-TYP-ID = EBLCH-BLANK-FIELD-CHAR
013597             MOVE SPACES        TO MIR-LIST-ETBL-TYP-ID
013597         END-IF
013597     END-IF.

      *
      ***  PERFORM KEY EDIT ON LIST TYPE. THE TYPE MUST EXIST AS A TABLE
      ***  TYPE ON THE EDIT TABLE.
      *
013597*    MOVE MIR-DV-TST-ETBL-TYP-ID             TO WEDIT-ETBL-TYP-ID.
013597     MOVE MIR-LIST-ETBL-TYP-ID             TO WEDIT-ETBL-TYP-ID.
           MOVE LOW-VALUES            TO WEDIT-ETBL-VALU-ID.
           MOVE LOW-VALUES            TO WEDIT-ETBL-LANG-CD.
           MOVE HIGH-VALUES           TO WEDIT-ENDBR-KEY.
013597*    MOVE MIR-DV-TST-ETBL-TYP-ID       TO WEDIT-ENDBR-ETBL-TYP-ID.
013597     MOVE MIR-LIST-ETBL-TYP-ID       TO WEDIT-ENDBR-ETBL-TYP-ID.

           PERFORM EDIT-1000-BROWSE
              THRU EDIT-1000-BROWSE-X.

           IF WEDIT-IO-OK
               PERFORM EDIT-2000-READ-NEXT
                   THRU EDIT-2000-READ-NEXT-X
557660     END-IF.

           IF WEDIT-IO-OK
013597*        MOVE MIR-DV-TST-ETBL-TYP-ID
013597*                               TO RUWMX-TST-ETBL-TYP-ID
013597         MOVE MIR-LIST-ETBL-TYP-ID
013597                                TO RUWMX-LIST-ETBL-TYP-ID
           ELSE
               MOVE 'NS03600019'      TO WGLOB-MSG-REF-INFO
013597*        MOVE MIR-DV-TST-ETBL-TYP-ID
013597         MOVE MIR-LIST-ETBL-TYP-ID
                                      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7532-EDIT-LIST-TYPE-X.
           EXIT.

      *
      *-------------------
       7534-EDIT-LIST-FND.
      *-------------------
      *****************************************************************
      *  ACTION IF LIST FOUND: CAN BE F(FAIL), P(PASS), S(SUBSET).
      *****************************************************************

013597*    IF MIR-DV-FIND-ACT-CD = SPACES
013597*        MOVE RUWMX-LIST-FIND-ACT-CD
013597*                               TO MIR-DV-FIND-ACT-CD
013597*    ELSE
013597*        IF MIR-DV-FIND-ACT-CD = EBLCH-BLANK-FIELD-CHAR
013597*            MOVE SPACES        TO MIR-DV-FIND-ACT-CD
013597     IF MIR-LIST-FIND-ACT-CD = SPACES
013597         MOVE RUWMX-LIST-FIND-ACT-CD
013597                                TO MIR-LIST-FIND-ACT-CD
013597     ELSE
013597         IF MIR-LIST-FIND-ACT-CD = EBLCH-BLANK-FIELD-CHAR
013597             MOVE SPACES        TO MIR-LIST-FIND-ACT-CD
557660         END-IF
557660     END-IF.

013597*    MOVE MIR-DV-FIND-ACT-CD    TO WS-SAVE-ACTION.
013597     MOVE MIR-LIST-FIND-ACT-CD    TO WS-SAVE-ACTION.

           IF WS-VALID-ACTION
013597*        MOVE MIR-DV-FIND-ACT-CD         TO RUWMX-LIST-FIND-ACT-CD
013597         MOVE MIR-LIST-FIND-ACT-CD       TO RUWMX-LIST-FIND-ACT-CD
           ELSE
               MOVE 'NS03600020'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7534-EDIT-LIST-FND-X.
           EXIT.

      *-----------------------
       7536-EDIT-LIST-NOT-FND.
      *-----------------------
      *****************************************************************
      *  ACTION IF LIST NOT FOUND: CAN BE F(FAIL), P(PASS), S(SUBSET).
      *****************************************************************

013597*    IF MIR-DV-NFIND-ACT-CD = SPACES
013597*        MOVE RUWMX-LIST-NFIND-ACT-CD
013597*                               TO MIR-DV-NFIND-ACT-CD
013597*    ELSE
013597*        IF MIR-DV-NFIND-ACT-CD = EBLCH-BLANK-FIELD-CHAR
013597*            MOVE SPACES        TO MIR-DV-NFIND-ACT-CD
013597     IF MIR-LIST-NFIND-ACT-CD = SPACES
013597         MOVE RUWMX-LIST-NFIND-ACT-CD
013597                                TO MIR-LIST-NFIND-ACT-CD
013597     ELSE
013597         IF MIR-LIST-NFIND-ACT-CD = EBLCH-BLANK-FIELD-CHAR
013597             MOVE SPACES        TO MIR-LIST-NFIND-ACT-CD
557660         END-IF
557660     END-IF.

013597*    MOVE MIR-DV-NFIND-ACT-CD   TO WS-SAVE-ACTION.
013597     MOVE MIR-LIST-NFIND-ACT-CD   TO WS-SAVE-ACTION.

           IF WS-VALID-ACTION
013597*        MOVE MIR-DV-NFIND-ACT-CD
013597         MOVE MIR-LIST-NFIND-ACT-CD
                                      TO RUWMX-LIST-NFIND-ACT-CD
           ELSE
               MOVE 'NS03600021'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7536-EDIT-LIST-NOT-FND-X.
           EXIT.

      *
      *--------------------
       7538-EDIT-DATE-TYPE.
      *--------------------
      *****************************************************************
      *  TEST DATE TYPE: CAN BE S OR R.
      *****************************************************************

013597*    IF MIR-DV-APP-DT-TYP-CD = SPACES
013597*        MOVE RUWMX-APP-DT-TYP-CD
013597*                               TO MIR-DV-APP-DT-TYP-CD
013597*    ELSE
013597*        IF MIR-DV-APP-DT-TYP-CD = EBLCH-BLANK-FIELD-CHAR
013597*            MOVE SPACES        TO MIR-DV-APP-DT-TYP-CD
013597*        END-IF
013597*    END-IF.

013597     IF MIR-CCAS-TST-DT-TYP-CD = SPACES
013597         MOVE RUWMX-CCAS-TST-DT-TYP-CD
013597                                TO MIR-CCAS-TST-DT-TYP-CD
013597     ELSE
013597         IF MIR-CCAS-TST-DT-TYP-CD = EBLCH-BLANK-FIELD-CHAR
013597             MOVE SPACES        TO MIR-CCAS-TST-DT-TYP-CD
013597         END-IF
013597     END-IF.

013597*    MOVE MIR-DV-APP-DT-TYP-CD  TO WS-SAVE-DATE-TYPE.
013597     MOVE MIR-CCAS-TST-DT-TYP-CD  TO WS-SAVE-DATE-TYPE.

           IF WS-VALID-DATE-TYPE
013597*        MOVE MIR-DV-APP-DT-TYP-CD
013597*                               TO RUWMX-APP-DT-TYP-CD
013597         MOVE MIR-CCAS-TST-DT-TYP-CD
013597                                TO RUWMX-CCAS-TST-DT-TYP-CD
           ELSE
               MOVE 'NS03600022'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7538-EDIT-DATE-TYPE-X.
           EXIT.

      *
      *-------------------
       7540-EDIT-DATE-YMD.
      *-------------------
      *****************************************************************
      *  TEST DATE YR/MTH/DAY INDICATOR: CAN BE Y(YR), M(MTH), D(DAY)
      *****************************************************************

013597*    IF MIR-DV-TST-DT-DUR-CD = SPACES
013597*        MOVE RUWMX-CCAS-TST-DT-DUR-CD
013597*                               TO MIR-DV-TST-DT-DUR-CD
013597*    ELSE
013597*        IF MIR-DV-TST-DT-DUR-CD = EBLCH-BLANK-FIELD-CHAR
013597*            MOVE SPACES        TO MIR-DV-TST-DT-DUR-CD
013597     IF MIR-CCAS-TST-DT-DUR-CD = SPACES
013597         MOVE RUWMX-CCAS-TST-DT-DUR-CD
013597                                TO MIR-CCAS-TST-DT-DUR-CD
013597     ELSE
013597         IF MIR-CCAS-TST-DT-DUR-CD = EBLCH-BLANK-FIELD-CHAR
013597             MOVE SPACES        TO MIR-CCAS-TST-DT-DUR-CD
557660         END-IF
557660     END-IF.

013597*    MOVE MIR-DV-TST-DT-DUR-CD  TO WS-SAVE-DATE-YMD.
013597     MOVE MIR-CCAS-TST-DT-DUR-CD  TO WS-SAVE-DATE-YMD.

           IF WS-VALID-DATE-YMD
013597*        MOVE MIR-DV-TST-DT-DUR-CD
013597         MOVE MIR-CCAS-TST-DT-DUR-CD
                                      TO RUWMX-CCAS-TST-DT-DUR-CD
           ELSE
               MOVE 'NS03600023'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7540-EDIT-DATE-YMD-X.
           EXIT.

      *
      *----------------------
       7542-EDIT-DATE-CUTOFF.
      *----------------------
      *****************************************************************
      *  TEST DATE CUTOFF: MUST BE NUMERIC
      *****************************************************************

013597*    IF MIR-DV-TST-DT-CUT-DUR = SPACES
013597     IF MIR-CCAS-TST-DT-DUR = SPACES
013597*        MOVE RUWMX-CCAS-TST-DT-CUT-DUR
013597         MOVE RUWMX-CCAS-TST-DT-DUR
                                      TO WS-NUM-999
013597*        MOVE WS-NUM-999        TO MIR-DV-TST-DT-CUT-DUR
013597         MOVE WS-NUM-999        TO MIR-CCAS-TST-DT-DUR
           ELSE
013597*        IF MIR-DV-TST-DT-CUT-DUR = EBLCH-BLANK-FIELD-CHAR
013597         IF MIR-CCAS-TST-DT-DUR = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO WS-NUM-999
013597*            MOVE WS-NUM-999    TO MIR-DV-TST-DT-CUT-DUR
013597             MOVE WS-NUM-999    TO MIR-CCAS-TST-DT-DUR
557660         END-IF
557660     END-IF.

      *
      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE '3'                   TO L0280-LENGTH.
           MOVE '3'                   TO L0280-INPUT-SIZE.

      *
      ***  PERFORM NUMERIC EDIT ON WEIGHT.
      *
013597*    MOVE MIR-DV-TST-DT-CUT-DUR TO L0280-INPUT-DATA.
013597     MOVE MIR-CCAS-TST-DT-DUR TO L0280-INPUT-DATA.

           PERFORM 7800-NUMERIC-EDIT
              THRU 7800-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-999
013597*        MOVE WS-NUM-999        TO MIR-DV-TST-DT-CUT-DUR
013597*        MOVE MIR-DV-TST-DT-CUT-DUR
013597*                               TO RUWMX-CCAS-TST-DT-CUT-DUR
013597         MOVE MIR-CCAS-TST-DT-DUR
013597                                TO RUWMX-CCAS-TST-DT-DUR
           ELSE
               MOVE 'NS03600024'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7542-EDIT-DATE-CUTOFF-X.
           EXIT.

      *
      *------------------------
       7544-EDIT-DATE-IN-RANGE.
      *------------------------
      *****************************************************************
      *  ACTION IF IN DATE RANGE: CAN BE F(FAIL),P(PASS),S(SUBSET).
      *****************************************************************

013597*    IF MIR-DV-IN-RNG-ACT-CD-2 = SPACES
013597*        MOVE RUWMX-DT-IN-RNG-ACT-CD
013597*                               TO MIR-DV-IN-RNG-ACT-CD-2
013597*    ELSE
013597*        IF MIR-DV-IN-RNG-ACT-CD-2 = EBLCH-BLANK-FIELD-CHAR
013597*            MOVE SPACES        TO MIR-DV-IN-RNG-ACT-CD-2
013597*        END-IF
013597*    END-IF.

013597     IF MIR-DT-IN-RNG-ACT-CD   = SPACES
013597         MOVE RUWMX-DT-IN-RNG-ACT-CD
013597                                TO MIR-DT-IN-RNG-ACT-CD
013597     ELSE
013597         IF MIR-DT-IN-RNG-ACT-CD   = EBLCH-BLANK-FIELD-CHAR
013597             MOVE SPACES        TO MIR-DT-IN-RNG-ACT-CD
013597         END-IF
013597     END-IF.

013597*    MOVE MIR-DV-IN-RNG-ACT-CD-2 TO WS-SAVE-ACTION.
013597     MOVE MIR-DT-IN-RNG-ACT-CD   TO WS-SAVE-ACTION.

           IF WS-VALID-ACTION
013597*        MOVE MIR-DV-IN-RNG-ACT-CD-2
013597         MOVE MIR-DT-IN-RNG-ACT-CD
                                      TO RUWMX-DT-IN-RNG-ACT-CD
           ELSE
               MOVE 'NS03600025'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7544-EDIT-DATE-IN-RANGE-X.
           EXIT.

      *
      *-------------------------
       7546-EDIT-DATE-OUT-RANGE.
      *-------------------------
      *****************************************************************
      *  ACTION OUT OF DATE RANGE: CAN BE F(FAIL),P(PASS),S(SUBSET).
      *****************************************************************

013597*    IF MIR-DV-OUT-RNG-ACT-CD = SPACES
013597*        MOVE RUWMX-DT-OUT-RNG-ACT-CD
013597*                               TO MIR-DV-OUT-RNG-ACT-CD
013597*    ELSE
013597*        IF MIR-DV-OUT-RNG-ACT-CD = EBLCH-BLANK-FIELD-CHAR
013597*            MOVE SPACES        TO MIR-DV-OUT-RNG-ACT-CD
017692*    IF MIR-NUM-OUT-RNG-ACT-CD = SPACES
017692*        MOVE RUWMX-DT-OUT-RNG-ACT-CD
017692*                               TO MIR-NUM-OUT-RNG-ACT-CD
017692*    ELSE
017692*        IF MIR-NUM-OUT-RNG-ACT-CD = EBLCH-BLANK-FIELD-CHAR
017692*            MOVE SPACES        TO MIR-NUM-OUT-RNG-ACT-CD
017692*        END-IF
017692*    END-IF.

013597*    MOVE MIR-DV-OUT-RNG-ACT-CD TO WS-SAVE-ACTION.
017692*    MOVE MIR-NUM-OUT-RNG-ACT-CD TO WS-SAVE-ACTION.

017692     IF MIR-DT-OUT-RNG-ACT-CD = SPACES
017692         MOVE RUWMX-DT-OUT-RNG-ACT-CD
017692                                TO MIR-DT-OUT-RNG-ACT-CD
017692     ELSE
017692         IF MIR-DT-OUT-RNG-ACT-CD = EBLCH-BLANK-FIELD-CHAR
017692             MOVE SPACES        TO MIR-DT-OUT-RNG-ACT-CD
017692         END-IF
017692     END-IF.

017692     MOVE MIR-DT-OUT-RNG-ACT-CD TO WS-SAVE-ACTION.

           IF WS-VALID-ACTION
013597*         MOVE MIR-DV-OUT-RNG-ACT-CD
017692*         MOVE MIR-NUM-OUT-RNG-ACT-CD
017692          MOVE MIR-DT-OUT-RNG-ACT-CD
                                      TO RUWMX-DT-OUT-RNG-ACT-CD
           ELSE
               MOVE 'NS03600026'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.

       7546-EDIT-DATE-OUT-RANGE-X.
           EXIT.
      *
010645*---------------------------
010645*7551-SHIFT-REC-RQMNT-CODES.
010645*---------------------------
010645*****************************************************************
010645*  SHIFT REQUIREMENT CODES ON RECORD: WHEN BLANK CODE ENTERED.
010645*****************************************************************
010645*
010645*
010645***  MOVE ALL NON BLANK MIR CODES TO THE RECORD TO REMOVE ANY
010645***  IMBEDDED BLANK CODES.
010645*
010645*    IF MIR-REQIR-ID-T (WS-RQCD) = SPACES
010645*        NEXT SENTENCE
010645*    ELSE
010645*        MOVE  MIR-REQIR-ID-T (WS-RQCD)
010645*           TO RUWMX-REQIR-ID         (WS-RQCD-OUT)
010645*        ADD +1 TO WS-RQCD-OUT
010645*    END-IF.
010645*
010645*7551-SHIFT-REC-RQMNT-CODES-X.
010645*    EXIT.
010645*----------------------------
010645 7551-DELETE-MIR-RQMNT-CODES.
010645*----------------------------
010645*****************************************************************
010645*  UPDATE MIR REQUIREMENT CODES TO REFLECT RECORD.
010645*****************************************************************
010645
010645     MOVE RUWMX-CCAS-TST-ID     TO WUWMR-CCAS-TST-ID.
010645     MOVE RUWMX-CCAS-TST-SUBSET-ID
                                      TO WUWMR-CCAS-TST-SUBSET-ID.
010645
010645     PERFORM  UWMR-1000-READ-FOR-UPDATE
010645         THRU UWMR-1000-READ-FOR-UPDATE-X.
010645
010645     IF WUWMR-IO-OK
010645         PERFORM  UWMR-1000-DELETE
010645             THRU UWMR-1000-DELETE-X
010645     END-IF.
010645
010645 7551-DELETE-MIR-RQMNT-CODES-X.
010645     EXIT.

      *
010645*----------------------------
010645*7552-UPDATE-MIR-RQMNT-CODES.
010645*----------------------------
010645*  UPDATE MIR REQUIREMENT CODES TO REFLECT RECORD.
010645*****************************************************************
010645*
010645*    MOVE  RUWMX-REQIR-ID         (WS-RQCD)
010645*       TO MIR-REQIR-ID-T (WS-RQCD).
010645*
010645*7552-UPDATE-MIR-RQMNT-CODES-X.
010645*    EXIT.
010645*---------------------------
010645 7552-INSERT-MIR-RQMNT-CODE.
010645*---------------------------
010645*****************************************************************
010645*  INSERT MIR REQUIREMENT CODE TO REFLECT RECORD.
010645*****************************************************************
010645
010645     MOVE RUWMX-CCAS-TST-ID     TO WUWMR-CCAS-TST-ID.
010645     MOVE RUWMX-CCAS-TST-SUBSET-ID
                                      TO WUWMR-CCAS-TST-SUBSET-ID.
010645     MOVE MIR-REQIR-ID-T (WS-RQCD)
                                      TO WUWMR-REQIR-ID.
010645
010645     PERFORM  UWMR-1000-READ
010645         THRU UWMR-1000-READ-X.
010645
010645     IF  WUWMR-IO-OK
010645*MSG: NS03600029 - DUPLICATE FAILURE REQUIREMENT ID @1
010645         MOVE 'NS03600029'      TO WGLOB-MSG-REF-INFO
010645         MOVE WRTAB-KEY         TO WGLOB-MSG-PARM (1)
010645         PERFORM  0260-1000-GENERATE-MESSAGE
010645             THRU 0260-1000-GENERATE-MESSAGE-X
010645         MOVE 'N'               TO WS-DATA-EDITS
010645         MOVE 'N'               TO WS-VALIDATE-CODES
010645     ELSE
010645         PERFORM  UWMR-1000-WRITE
010645             THRU UWMR-1000-WRITE-X
010645     END-IF.
010645
010645 7552-INSERT-MIR-RQMNT-CODE-X.
010645     EXIT.
      *
010645*---------------------------
010645 7553-DELETE-MIR-LCGP-CODES.
010645*---------------------------
010645*****************************************************************
010645*  DELETE MIR LOCATION GROUP CODES TO REFLECT RECORD.
010645*****************************************************************
010645
010645     MOVE RUWMX-CCAS-TST-ID     TO WUWML-CCAS-TST-ID.
010645     MOVE RUWMX-CCAS-TST-SUBSET-ID
                                      TO WUWML-CCAS-TST-SUBSET-ID.
010645
010645     PERFORM  UWML-1000-READ-FOR-UPDATE
010645         THRU UWML-1000-READ-FOR-UPDATE-X.
010645
010645     IF WUWML-IO-OK
010645         PERFORM  UWML-1000-DELETE
010645             THRU UWML-1000-DELETE-X
010645     END-IF.
010645
010645 7553-DELETE-MIR-LCGP-CODES-X.
010645     EXIT.
010645*
010645*--------------------------
010645 7554-INSERT-MIR-LCGP-CODE.
010645*--------------------------
010645*****************************************************************
010645*  INSERT MIR LOCATION GROUP CODE TO REFLECT RECORD.
010645*****************************************************************
010645
010645     MOVE RUWMX-CCAS-TST-ID     TO WUWML-CCAS-TST-ID.
010645     MOVE RUWMX-CCAS-TST-SUBSET-ID
                                      TO WUWML-CCAS-TST-SUBSET-ID.
010645     MOVE MIR-LOC-GR-ID-T (WS-LCGP-SUB)
                                      TO WUWML-LOC-GR-ID.
010645
010645     PERFORM  UWML-1000-READ
010645         THRU UWML-1000-READ-X.
010645
010645     IF  WUWML-IO-OK
010645         MOVE 'N'               TO WS-VALIDATE-LOC-GR
010645         MOVE 'N'               TO WS-DATA-EDITS
010645*MSG: NS03600051 - DUPLICATE LOCATION GROUP CODE @1
010645         MOVE 'NS03600051'      TO WGLOB-MSG-REF-INFO
010645         MOVE MIR-LOC-GR-ID-T (WS-LCGP-SUB)
010645                                TO WGLOB-MSG-PARM (1)
010645         PERFORM  0260-1000-GENERATE-MESSAGE
010645             THRU 0260-1000-GENERATE-MESSAGE-X
010645     ELSE
010645         PERFORM  UWML-1000-WRITE
010645             THRU UWML-1000-WRITE-X
010645         MOVE MIR-LOC-GR-ID-T (WS-LCGP-SUB)
010645                                TO WS-LOC-GR-CD
010645                                       (WS-LCGP-SUB)
010645     END-IF.
010645
010645 7554-INSERT-MIR-LCGP-CODE-X.
010645     EXIT.
010645*
010645*---------------------------
010645 7555-DELETE-MIR-FORM-TYPES.
010645*---------------------------
010645*****************************************************************
010645*  DELETE MIR APPLICATION FORM TYPES TO REFLECT RECORD.
010645*****************************************************************
010645
010645     MOVE RUWMX-CCAS-TST-ID     TO WUWMF-CCAS-TST-ID.
010645     MOVE RUWMX-CCAS-TST-SUBSET-ID
                                      TO WUWMF-CCAS-TST-SUBSET-ID.
010645
010645     PERFORM  UWMF-1000-READ-FOR-UPDATE
010645         THRU UWMF-1000-READ-FOR-UPDATE-X.
010645
010645     IF WUWMF-IO-OK
010645         PERFORM UWMF-1000-DELETE
010645            THRU UWMF-1000-DELETE-X
010645     END-IF.
010645
010645 7555-DELETE-MIR-FORM-TYPES-X.
010645     EXIT.
010645*
010645*--------------------------
010645 7556-INSERT-MIR-FORM-TYPE.
010645*--------------------------
010645*****************************************************************
010645*  INSERT MIR APPLICATION FORM TYPE TO REFLECT RECORD.
010645*****************************************************************
010645
010645     MOVE RUWMX-CCAS-TST-ID     TO WUWMF-CCAS-TST-ID.
010645     MOVE RUWMX-CCAS-TST-SUBSET-ID
                                      TO WUWMF-CCAS-TST-SUBSET-ID.
010645     MOVE MIR-APP-FORM-TYP-ID-T (WS-UWMF-SUB)
                                      TO WUWMF-APP-FORM-TYP-ID.
010645
010645     PERFORM  UWMF-1000-READ
010645         THRU UWMF-1000-READ-X.
010645
010645     IF  WUWMF-IO-OK
010645         MOVE 'N'               TO WS-VALIDATE-FORM
010645         MOVE 'N'               TO WS-DATA-EDITS
010645*MSG: NS03600050 - DUPLICATE FORM TYPE CODE @1
010645         MOVE 'NS03600050'      TO WGLOB-MSG-REF-INFO
010645         MOVE MIR-APP-FORM-TYP-ID-T (WS-UWMF-SUB)
010645                                TO WGLOB-MSG-PARM (1)
010645         PERFORM  0260-1000-GENERATE-MESSAGE
010645             THRU 0260-1000-GENERATE-MESSAGE-X
010645     ELSE
010645         PERFORM  UWMF-1000-WRITE
010645             THRU UWMF-1000-WRITE-X
010645         MOVE MIR-APP-FORM-TYP-ID-T (WS-UWMF-SUB)
010645                                TO WS-APP-FORM-TYP
010645                                       (WS-UWMF-SUB)
010645     END-IF.
010645
010645 7556-INSERT-MIR-FORM-TYPE-X.
010645     EXIT.
010645*
010645*------------------------------
010418 7557-DELETE-MIR-SBSDRY-CDS.
010418*------------------------------
010418*****************************************************************
010418*  DELETE MIR SUBSIDIARY COMPANY IDS TO REFLECT RECORD.
010418*****************************************************************
010418
010418     MOVE RUWMX-CCAS-TST-ID     TO WUWMS-CCAS-TST-ID.
010418     MOVE RUWMX-CCAS-TST-SUBSET-ID
                                      TO WUWMS-CCAS-TST-SUBSET-ID.
010418
010418     PERFORM  UWMS-1000-READ-FOR-UPDATE
010418         THRU UWMS-1000-READ-FOR-UPDATE-X.
010418
010418     IF WUWMS-IO-OK
010418         PERFORM UWMS-1000-DELETE
010418            THRU UWMS-1000-DELETE-X
010418     END-IF.
010418
010418 7557-DELETE-MIR-SBSDRY-CDS-X.
010418     EXIT.
010418*
010645*-----------------------------
010418 7558-INSERT-MIR-SBSDRY-CO-ID.
010418*-----------------------------
010418*****************************************************************
010418*  INSERT MIR SUBSIDIARY COMPANY ID TO REFLECT RECORD.
010418*****************************************************************
010418
010418     MOVE RUWMX-CCAS-TST-ID     TO WUWMS-CCAS-TST-ID.
010418     MOVE RUWMX-CCAS-TST-SUBSET-ID
                                      TO WUWMS-CCAS-TST-SUBSET-ID.
010418     MOVE MIR-SBSDRY-CO-ID-T (WS-SBCO-SUB)
                                      TO WUWMS-SBSDRY-CO-ID.
010418
010418     PERFORM  UWMS-1000-READ
010418         THRU UWMS-1000-READ-X.
010418
010418     IF  WUWMS-IO-OK
010418         MOVE 'N'               TO WS-VALIDATE-SBSDRY-CO-ID
010418         MOVE 'N'               TO WS-DATA-EDITS
010418*MSG: NS03600053 - DUPLICATE SUBSIDIARY COMPANY ID @1
010418         MOVE 'NS03600053'      TO WGLOB-MSG-REF-INFO
010418         MOVE MIR-SBSDRY-CO-ID-T (WS-SBCO-SUB)
010418                                TO WGLOB-MSG-PARM (1)
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418     ELSE
010418         PERFORM  UWMS-1000-WRITE
010418             THRU UWMS-1000-WRITE-X
010418         MOVE MIR-SBSDRY-CO-ID-T (WS-SBCO-SUB)
010418                                TO WS-SBSDRY-CO-ID
010418                                       (WS-SBCO-SUB)
010418     END-IF.
010418
010418 7558-INSERT-MIR-SBSDRY-CO-ID-X.
010418     EXIT.
010418*
      *--------------------
       7560-RESET-DEFAULTS.
      *--------------------
      *****************************************************************
      *  RESET COMMON AREA DEFAULTS.
      *****************************************************************

013597*    MOVE SPACES                TO RUWMX-CCAS-TST-DTL-INFO.
013597     INITIALIZE RUWMX-CCAS-TST-DTL-INFO.

           IF  WS-TEST-TYPE-NUMERIC
013597*        MOVE ZEROS             TO RUWMX-TST-NUM-MIN-AMT
013597*        MOVE ZEROS             TO RUWMX-TST-NUM-MAX-AMT
013597         MOVE ZEROS             TO RUWMX-NUM-MIN-AMT
013597         MOVE ZEROS             TO RUWMX-NUM-MAX-AMT
557660     END-IF.

           IF  WS-TEST-TYPE-DATE
013597*        MOVE ZEROS             TO RUWMX-CCAS-TST-DT-CUT-DUR
013597         MOVE ZEROS             TO RUWMX-CCAS-TST-DT-DUR
557660     END-IF.

       7560-RESET-DEFAULTS-X.
           EXIT.
      *
010645*---------------------
010645 7570-DUPLICATE-CODES.
010645*---------------------
010645*****************************************************************
010645*  REQUIREMENT CODES CANNOT BE REPEATED.
010645*****************************************************************
010645
010645*
010645***  DO NOT COMPARE BLANK CODES.
010645*
010645     IF MIR-REQIR-ID-T (WS-RQCD) = SPACES
010645         GO TO 7570-DUPLICATE-CODES-X
010645     END-IF.
010645
010645*
010645***  COMPARE THE CURRENT CODE AGAINST ALL THE REQUIREMENT CODES.
010645*
010645     SET WS-NOT-DUP-LOOP-END TO TRUE.
010645
010645     PERFORM  7571-DUPLICATE-CODES-CHECK
010645         THRU 7571-DUPLICATE-CODES-CHECK-X
010645         VARYING WS-RQCD-OUT FROM 1 BY 1
010645         UNTIL (WS-RQCD-OUT > WS-MAX-RQCD OR
010645                WS-DUP-LOOP-END).
010645
010645 7570-DUPLICATE-CODES-X.
010645     EXIT.
      *
010645*---------------------------
010645 7571-DUPLICATE-CODES-CHECK.
010645*---------------------------
010645*****************************************************************
010645*  REQUIREMENT CODES CANNOT BE REPEATED.
010645*****************************************************************
010645
010645*
010645***  COMPARE THE CURRENT CODE TO ALL OTHER CODES.  IF A DUPLICATE
010645***  IS FOUND, SEE IF IT HAS ALREADY BEEN REPORTED.  IF NOT,
010645***  CREATE A MESSAGE.
010645*
010645     IF  (WS-RQCD NOT = WS-RQCD-OUT)
010645     AND (MIR-REQIR-ID-T (WS-RQCD) =
010645          MIR-REQIR-ID-T (WS-RQCD-OUT))
010645          SET WS-NO-RQCD-MSG TO TRUE
010645          PERFORM  7572-DUPLICATE-CODES-MSGS
010645              THRU 7572-DUPLICATE-CODES-MSGS-X
010645              VARYING WS-RQCD-MSG FROM 1 BY 1
010645              UNTIL  (WS-RQCD-MSG > WS-MAX-RQCD)
010645          IF WS-NO-RQCD-MSG
010645             MOVE MIR-REQIR-ID-T (WS-RQCD)
010645                                TO WS-RQCD-REPEATS (WS-RQCD-RPT)
010645             ADD +1               TO WS-RQCD-RPT
010645             SET WS-CROSS-EDITS-NOT-OK TO TRUE
010645             SET WS-DUP-LOOP-END TO TRUE
010645             MOVE 'NS03600029'  TO WGLOB-MSG-REF-INFO
010645             MOVE MIR-REQIR-ID-T (WS-RQCD)
010645                                TO WGLOB-MSG-PARM (1)
010645             PERFORM  0260-1000-GENERATE-MESSAGE
010645                 THRU 0260-1000-GENERATE-MESSAGE-X
010645          END-IF
010645     END-IF.
010645
010645 7571-DUPLICATE-CODES-CHECK-X.
010645     EXIT.
      *
010645*--------------------------
010645 7572-DUPLICATE-CODES-MSGS.
010645*--------------------------
010645*****************************************************************
010645*  REQUIREMENT CODES THAT ARE REPEATED MORE THAN ONCE SHOULD NOT
010645*  PRODUCE MULTIPLE MESSAGES.
010645*****************************************************************
010645
010645*
010645***  COMPARE THE CURRENT CODE TO THE OTHER CODES THAT HAVE
010645***  ALREADY BEEN GENERATED.
010645*
010645     IF MIR-REQIR-ID-T (WS-RQCD) =
010645        WS-RQCD-REPEATS (WS-RQCD-MSG)
010645         SET WS-RQCD-MSG-DOES-EXIST TO TRUE
010645     END-IF.
010645
010645 7572-DUPLICATE-CODES-MSGS-X.
010645     EXIT.
      *
      *-----------------
       7600-CROSS-EDITS.
      *-----------------
      *****************************************************************
      *  PERFORM ALL REQUIRED CROSS EDITS.
      *****************************************************************

010645*    MOVE 'Y'       TO WS-CROSS-EDITS.
010645     SET WS-CROSS-EDITS-OK TO TRUE.

      *
      ***  A TEST RESULT OF 'S' (SUBSET) IS NOT ALLOWED FOR SUBSET
      ***  TESTS.
      *
557659*    IF RUWMX-CCAS-TST-SFX NOT = SPACES
557659     IF RUWMX-CCAS-TST-SUBSET-ID NOT = SPACES
               PERFORM 7615-SUBSET-RESULT-CHECK
                   THRU 7615-SUBSET-RESULT-CHECK-X
557660     END-IF.

010645*
010645***  THE REQUIREMENT CODES CANNOT BE REPEATED.
010645*
010645*    PERFORM 7620-DUPLICATE-CODES
010645*        THRU 7620-DUPLICATE-CODES-X
010645*        VARYING WS-RQCD FROM 1 BY 1
010645*        UNTIL (WS-RQCD > WS-MAX-RQCD).

      *
      ***  THE NUMERIC RANGE MUST ALSO BE CROSS-EDITED.
      *
           IF WS-TEST-TYPE-NUMERIC
               PERFORM 7601-VALIDATE-NUM-RANGE
                   THRU 7601-VALIDATE-NUM-RANGE-X
557660     END-IF.

      *
      ***  THE FIELD NAME IS CROSS-EDITED WITH THE TEST TYPE.
      *
           IF WS-VALID-FLD-NAME
               PERFORM 7610-VALIDATE-FLD-NAME-TYPE
                   THRU 7610-VALIDATE-FLD-NAME-TYPE-X
557660     END-IF.
      *
      ***  INPUT IS ONLY ALLOWED IN SOME FIELDS DEPENDING ON TEST TYPE.
      *
           IF WS-TEST-TYPE-YESNO
               PERFORM 7603-VALIDATE-YESNO-INPUT
                   THRU 7603-VALIDATE-YESNO-INPUT-X
557660     END-IF.

           IF WS-TEST-TYPE-NUMERIC
               PERFORM 7604-VALIDATE-NUMERIC-INPUT
                   THRU 7604-VALIDATE-NUMERIC-INPUT-X
557660     END-IF.

           IF WS-TEST-TYPE-LIST
               PERFORM 7606-VALIDATE-LIST-INPUT
                   THRU 7606-VALIDATE-LIST-INPUT-X
557660     END-IF.

           IF WS-TEST-TYPE-DATE
               PERFORM 7608-VALIDATE-DATE-INPUT
                   THRU 7608-VALIDATE-DATE-INPUT-X
557660     END-IF.

       7600-CROSS-EDITS-X.
           EXIT.

      *
      *------------------------
       7601-VALIDATE-NUM-RANGE.
      *------------------------
      *****************************************************************
      *  YESNO TEST INPUT: VALUES FOR OTHER TESTS MUST BE BLANK.
      *****************************************************************

      *
      ***  MAXIMUM CANNOT BE GREATER THAN MINIMUM.
      *
013597*    IF RUWMX-TST-NUM-MIN-AMT > RUWMX-TST-NUM-MAX-AMT
013597     IF RUWMX-NUM-MIN-AMT > RUWMX-NUM-MAX-AMT
               MOVE 'NS03600027'      TO WGLOB-MSG-REF-INFO
010645*        MOVE 'N'          TO WS-CROSS-EDITS
010645         SET WS-CROSS-EDITS-NOT-OK TO TRUE
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       7601-VALIDATE-NUM-RANGE-X.
           EXIT.

      *
      *----------------------------
       7602-VALIDATE-COMPLEX-INPUT.
      *----------------------------
      *****************************************************************
      *  COMPLEX TEST INPUT: VALUES FOR OTHER TESTS MUST BE BLANK.
      *****************************************************************

           PERFORM 7708-NO-SIMPLE-INPUT
              THRU 7708-NO-SIMPLE-INPUT-X.

           PERFORM 7700-NO-YESNO-INPUT
              THRU 7700-NO-YESNO-INPUT-X.

           PERFORM 7702-NO-NUMERIC-INPUT
              THRU 7702-NO-NUMERIC-INPUT-X.

           PERFORM 7704-NO-LIST-INPUT
              THRU 7704-NO-LIST-INPUT-X.

           PERFORM 7706-NO-DATE-INPUT
              THRU 7706-NO-DATE-INPUT-X.

       7602-VALIDATE-COMPLEX-INPUT-X.
           EXIT.

      *
      *--------------------------
       7603-VALIDATE-YESNO-INPUT.
      *--------------------------
      *****************************************************************
      *  YESNO TEST INPUT: VALUES FOR OTHER TESTS MUST BE BLANK.
      *****************************************************************

           PERFORM 7702-NO-NUMERIC-INPUT
              THRU 7702-NO-NUMERIC-INPUT-X.

           PERFORM 7704-NO-LIST-INPUT
              THRU 7704-NO-LIST-INPUT-X.

           PERFORM 7706-NO-DATE-INPUT
              THRU 7706-NO-DATE-INPUT-X.

       7603-VALIDATE-YESNO-INPUT-X.
           EXIT.

      *
      *----------------------------
       7604-VALIDATE-NUMERIC-INPUT.
      *----------------------------
      *****************************************************************
      *  NUMERIC TEST INPUT: VALUES FOR OTHER TESTS MUST BE BLANK.
      *****************************************************************

           PERFORM 7700-NO-YESNO-INPUT
              THRU 7700-NO-YESNO-INPUT-X.

           PERFORM 7704-NO-LIST-INPUT
              THRU 7704-NO-LIST-INPUT-X.

           PERFORM 7706-NO-DATE-INPUT
              THRU 7706-NO-DATE-INPUT-X.

       7604-VALIDATE-NUMERIC-INPUT-X.
           EXIT.

      *
      *-------------------------
       7606-VALIDATE-LIST-INPUT.
      *-------------------------
      *****************************************************************
      *  LIST TEST INPUT: VALUES FOR OTHER TESTS MUST BE BLANK.
      *****************************************************************

           PERFORM 7700-NO-YESNO-INPUT
              THRU 7700-NO-YESNO-INPUT-X.

           PERFORM 7702-NO-NUMERIC-INPUT
              THRU 7702-NO-NUMERIC-INPUT-X.

           PERFORM 7706-NO-DATE-INPUT
              THRU 7706-NO-DATE-INPUT-X.

       7606-VALIDATE-LIST-INPUT-X.
           EXIT.

      *
      *-------------------------
       7608-VALIDATE-DATE-INPUT.
      *-------------------------
      *****************************************************************
      *  DATE TEST INPUT: VALUES FOR OTHER TESTS MUST BE BLANK.
      *****************************************************************

           PERFORM 7700-NO-YESNO-INPUT
              THRU 7700-NO-YESNO-INPUT-X.

           PERFORM 7702-NO-NUMERIC-INPUT
              THRU 7702-NO-NUMERIC-INPUT-X.

           PERFORM 7704-NO-LIST-INPUT
              THRU 7704-NO-LIST-INPUT-X.

       7608-VALIDATE-DATE-INPUT-X.
           EXIT.
      *
      *----------------------------
       7610-VALIDATE-FLD-NAME-TYPE.
      *----------------------------
      *****************************************************************
      *  FIELD NAME FROM DFLD TABLE MUST CORRESPOND TO THE TEST TYPE
      *  BEING CREATED.
      *****************************************************************

      *
      ***  THE DEFINITION FIELD TYPE ON THE DFLD TABLE MUST
      ***  CORRESPOND TO THE TEST TYPE.
      *
           IF  (RDFLD-FLD-TYP-YES-NO
557660     AND WS-TEST-TYPE-YESNO)
           OR  (RDFLD-FLD-TYP-CHARACTER
557660     AND WS-TEST-TYPE-LIST)
           OR  (RDFLD-FLD-TYP-DATE
557660     AND WS-TEST-TYPE-DATE)
           OR  (RDFLD-FLD-TYP-NUMERIC
557660     AND WS-TEST-TYPE-NUMERIC)
           OR  (RDFLD-FLD-TYP-SIGNED-NUM
557660     AND WS-TEST-TYPE-NUMERIC)
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'NS03600043'      TO WGLOB-MSG-REF-INFO
010645*        MOVE 'N'          TO WS-CROSS-EDITS
010645         SET WS-CROSS-EDITS-NOT-OK TO TRUE
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       7610-VALIDATE-FLD-NAME-TYPE-X.
           EXIT.
      *
      *-------------------------
       7615-SUBSET-RESULT-CHECK.
      *-------------------------
      *****************************************************************
      *  A TEST RESULT OF 'S' (SUBSET) IS NOT ALLOWED FOR SUBSET TESTS.
      *****************************************************************

      *
      ***  THE DEFINITION FIELD TYPE ON THE DFLD TABLE MUST
      ***  CORRESPOND TO THE TEST TYPE.
      *
           MOVE 'N'                   TO WS-SW-SUBSET.

           IF RUWMX-UNANSWR-ACT-CD = 'S'
               MOVE 'Y'               TO WS-SW-SUBSET
557660     END-IF.

           IF WS-TEST-TYPE-YESNO
               IF RUWMX-ANSWR-YES-ACT-CD = 'S'
               OR RUWMX-ANSWR-NO-ACT-CD = 'S'
                   MOVE 'Y'           TO WS-SW-SUBSET
557660         END-IF
557660     END-IF.

           IF WS-TEST-TYPE-NUMERIC
               IF RUWMX-NUM-IN-RNG-ACT-CD = 'S'
               OR RUWMX-NUM-OUT-RNG-ACT-CD = 'S'
                   MOVE 'Y'           TO WS-SW-SUBSET
557660         END-IF
557660     END-IF.

           IF WS-TEST-TYPE-LIST
               IF RUWMX-LIST-FIND-ACT-CD = 'S'
               OR RUWMX-LIST-NFIND-ACT-CD = 'S'
                   MOVE 'Y'           TO WS-SW-SUBSET
557660         END-IF
557660     END-IF.

           IF WS-TEST-TYPE-DATE
               IF RUWMX-DT-IN-RNG-ACT-CD = 'S'
               OR RUWMX-DT-OUT-RNG-ACT-CD = 'S'
                   MOVE 'Y'           TO WS-SW-SUBSET
557660         END-IF
557660     END-IF.

           IF WS-SW-SUBSET-SET
               MOVE 'NS03600047'      TO WGLOB-MSG-REF-INFO
010645*        MOVE 'N'          TO WS-CROSS-EDITS
010645         SET WS-CROSS-EDITS-NOT-OK TO TRUE
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       7615-SUBSET-RESULT-CHECK-X.
           EXIT.

      *
010645*---------------------
010645*7620-DUPLICATE-CODES.
010645*---------------------
010645*****************************************************************
010645*  REQUIREMENT CODES CANNOT BE REPEATED.
010645*****************************************************************
010645*
010645*
010645***  DO NOT COMPARE BLANK CODES.
010645*
010645*    IF RUWMX-REQIR-ID         (WS-RQCD) = SPACES
010645*        GO TO 7620-DUPLICATE-CODES-X
010645*    END-IF.
010645*
010645*
010645***  COMPARE THE CURRENT CODE AGAINST ALL THE REQUIREMENT
010645***  CODES.
010645*
010645*    MOVE 'N'                 TO WS-END-DUP-LOOP.
010645*
010645*    PERFORM 7630-DUPLICATE-CODES-CHECK
010645*       THRU 7630-DUPLICATE-CODES-CHECK-X
010645*       VARYING WS-RQCD-OUT FROM 1 BY 1
010645*       UNTIL (WS-RQCD-OUT > WS-MAX-RQCD OR
010645*              WS-DUP-LOOP-END).
010645*
010645*7620-DUPLICATE-CODES-X.
010645*    EXIT.
010645*
010645*---------------------------
010645*7630-DUPLICATE-CODES-CHECK.
010645*---------------------------
010645*****************************************************************
010645*  REQUIREMENT CODES CANNOT BE REPEATED.
010645*****************************************************************
010645*
010645*
010645***  COMPARE THE CURRENT CODE TO ALL OTHER CODES. IF A DUPLICATE
010645***  IS FOUND, SEE IF IT HAS ALREADY BEEN REPORTED. IF NOT
010645***  CREATE A MESSAGE.
010645*
010645*    IF WS-RQCD NOT = WS-RQCD-OUT
010645*        IF RUWMX-REQIR-ID         (WS-RQCD) =
010645*           RUWMX-REQIR-ID         (WS-RQCD-OUT)
010645*            MOVE 'N'        TO WS-RQCD-MSG-EXISTS
010645*            PERFORM 7640-DUPLICATE-CODES-MSGS
010645*                THRU 7640-DUPLICATE-CODES-MSGS-X
010645*                VARYING WS-RQCD-MSG FROM 1 BY 1
010645*                UNTIL (WS-RQCD-MSG > WS-MAX-RQCD)
010645*            IF WS-NO-RQCD-MSG
010645*                MOVE RUWMX-REQIR-ID         (WS-RQCD)
010645*                            TO WS-RQCD-REPEATS (WS-RQCD-RPT)
010645*                ADD +1               TO WS-RQCD-RPT
010645*                MOVE 'N'             TO WS-CROSS-EDITS
010645*                MOVE 'Y'             TO WS-END-DUP-LOOP
010645*                MOVE 'NS03600029'    TO WGLOB-MSG-REF-INFO
010645*                MOVE RUWMX-REQIR-ID         (WS-RQCD)
010645*                                     TO WGLOB-MSG-PARM (1)
010645*                PERFORM 0260-1000-GENERATE-MESSAGE
010645*                    THRU 0260-1000-GENERATE-MESSAGE-X
010645*            END-IF
010645*        END-IF
010645*    END-IF.
010645*
010645*7630-DUPLICATE-CODES-CHECK-X.
010645*    EXIT.
010645*
010645*--------------------------
010645*7640-DUPLICATE-CODES-MSGS.
010645*--------------------------
010645*****************************************************************
010645*  REQUIREMENT CODES THAT ARE REPEATED MORE THAN ONCE SHOULD
010645*  NOT PRODUCE MULTIPLE MESSAGES.
010645*****************************************************************
010645*
010645*
010645***  COMPARE THE CURRENT CODE TO THE OTHER CODES THAT HAVE
010645***  ALREADY GENERATED.
010645*
010645*    IF RUWMX-REQIR-ID         (WS-RQCD) =
010645*       WS-RQCD-REPEATS (WS-RQCD-MSG)
010645*        MOVE 'Y'       TO WS-RQCD-MSG-EXISTS
010645*    END-IF.
010645*
010645*7640-DUPLICATE-CODES-MSGS-X.
010645*    EXIT.
      *
      *--------------------
       7700-NO-YESNO-INPUT.
      *--------------------
      *****************************************************************
      *  YESNO TEST: FIELDS SHOULD BE BLANK.
      *****************************************************************

      *
      ***  IF-YES AND IF-NO ACTIONS MUST BE BLANK.
      *
013597*    IF MIR-DV-ANSWR-YES-ACT-CD NOT = SPACES
013597     IF MIR-ANSWR-YES-ACT-CD NOT = SPACES
               MOVE 'NS03600028'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

013597*    IF MIR-DV-ANSWR-NO-ACT-CD NOT = SPACES
013597     IF MIR-ANSWR-NO-ACT-CD NOT = SPACES
               MOVE 'NS03600030'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       7700-NO-YESNO-INPUT-X.
           EXIT.
      *
      *----------------------
       7702-NO-NUMERIC-INPUT.
      *----------------------
      *****************************************************************
      *  NUMERIC TEST INPUT: VALUES FOR OTHER TESTS MUST BE BLANK.
      *****************************************************************

      *
      ***  NUMERIC MIN AND MAX MUST BE ZEROS.
      *
008455     MOVE 'N'                   TO L0280-SIGN-IND.
008455     MOVE '0'                   TO L0280-PRECISION.
013597*    MOVE LENGTH OF MIR-DV-TST-NUM-MIN-AMT
013597     MOVE LENGTH OF MIR-NUM-MIN-AMT
008455                                TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
013597*    MOVE MIR-DV-TST-NUM-MIN-AMT              TO L0280-INPUT-DATA.
013597     MOVE MIR-NUM-MIN-AMT                 TO L0280-INPUT-DATA.
008455     PERFORM 7800-NUMERIC-EDIT
008455        THRU 7800-NUMERIC-EDIT-X.

008455     IF L0280-OUTPUT NOT = 0
008455     OR NOT L0280-OK
008455*    IF MIR-DV-TST-NUM-MIN-AMT NOT = ZEROS
               MOVE 'NS03600031'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

008455     MOVE 'N'                   TO L0280-SIGN-IND.
008455     MOVE '0'                   TO L0280-PRECISION.
013597*    MOVE LENGTH OF MIR-DV-TST-NUM-MAX-AMT
013597     MOVE LENGTH OF MIR-NUM-MAX-AMT
008455                                TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE.
013597*    MOVE MIR-DV-TST-NUM-MAX-AMT              TO L0280-INPUT-DATA.
013597     MOVE MIR-NUM-MAX-AMT              TO L0280-INPUT-DATA.
008455     PERFORM 7800-NUMERIC-EDIT
008455        THRU 7800-NUMERIC-EDIT-X.

008455     IF L0280-OUTPUT NOT = 0
008455     OR NOT L0280-OK
008455*    IF MIR-DV-TST-NUM-MAX-AMT NOT = ZEROS
               MOVE 'NS03600032'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

      *
      ***  IF-IN AND IF-OUT VALUES MUST BE BLANK.
      *
013597*    IF MIR-DV-IN-RNG-ACT-CD NOT = SPACES
013597     IF MIR-NUM-IN-RNG-ACT-CD NOT = SPACES
               MOVE 'NS03600033'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

013597*    IF MIR-DV-OUT-RNG-ACT-CD NOT = SPACES
013597     IF MIR-NUM-OUT-RNG-ACT-CD NOT = SPACES
               MOVE 'NS03600034'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       7702-NO-NUMERIC-INPUT-X.
           EXIT.

      *
      *-------------------
       7704-NO-LIST-INPUT.
      *-------------------
      *****************************************************************
      *  LIST TEST: INPUT NOT ALLOWED.
      *****************************************************************

      *
      ***  EDIT TYPE,IF-FOUND AND NOT-FOUND VALUES MUST BE BLANK.
      *
013597*    IF MIR-DV-TST-ETBL-TYP-ID NOT = SPACES
013597     IF MIR-LIST-ETBL-TYP-ID NOT = SPACES
               MOVE 'NS03600035'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

013597*    IF MIR-DV-FIND-ACT-CD NOT = SPACES
013597     IF MIR-LIST-FIND-ACT-CD NOT = SPACES
               MOVE 'NS03600036'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

013597*    IF MIR-DV-NFIND-ACT-CD NOT = SPACES
013597     IF MIR-LIST-NFIND-ACT-CD NOT = SPACES
               MOVE 'NS03600037'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       7704-NO-LIST-INPUT-X.
           EXIT.

      *
      *-------------------
       7706-NO-DATE-INPUT.
      *-------------------
      *****************************************************************
      *  DATE TEST: INPUT NOT ALLOWED.
      *****************************************************************

      *
      ***  TYPE, YMD, CUTOFF, IF-IN AND IF-OUT VALUES MUST BE BLANK.
      *
013597*    IF MIR-DV-APP-DT-TYP-CD NOT = SPACES
013597     IF MIR-CCAS-TST-DT-TYP-CD NOT = SPACES
               MOVE 'NS03600038'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

013597*    IF MIR-DV-TST-DT-DUR-CD NOT = SPACES
013597     IF MIR-CCAS-TST-DT-DUR-CD NOT = SPACES
               MOVE 'NS03600039'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

013597*    IF MIR-DV-TST-DT-CUT-DUR NOT = ZEROS
013597     IF MIR-CCAS-TST-DT-DUR NOT = ZEROS
               MOVE 'NS03600040'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

013597*    IF MIR-DV-IN-RNG-ACT-CD-2 NOT = SPACES
013597     IF MIR-DT-IN-RNG-ACT-CD   NOT = SPACES
               MOVE 'NS03600041'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

013597*    IF MIR-DV-OUT-RNG-ACT-CD-2 NOT = SPACES
013597     IF MIR-DT-OUT-RNG-ACT-CD   NOT = SPACES
               MOVE 'NS03600042'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       7706-NO-DATE-INPUT-X.
           EXIT.

      *
      *---------------------
       7708-NO-SIMPLE-INPUT.
      *---------------------
      *****************************************************************
      *  SIMPLE TEST: SOME FIELDS NOT ALLOWED ON COMPLEX TESTS.
      *****************************************************************

      *
      ***  TYPE, YMD, CUTOFF, IF-IN AND IF-OUT VALUES MUST BE BLANK.
      *
           IF MIR-FLD-ID NOT = SPACES
               MOVE 'NS03600045'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           IF MIR-UNANSWR-ACT-CD NOT = SPACES
               MOVE 'NS03600046'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       7708-NO-SIMPLE-INPUT-X.
           EXIT.

      *
      *------------------
       7800-NUMERIC-EDIT.
      *------------------

           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               GO TO 7800-NUMERIC-EDIT-X
557660     END-IF.

           IF L0280-ARGS-INVALID
               MOVE 'XS00000020'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7800-NUMERIC-EDIT-X
557660     END-IF.

       7800-NUMERIC-EDIT-X.
           EXIT.
      *
008455*------------------
008455 7900-FORMAT-NOMIN.
008455*------------------
008455     MOVE 0                     TO L0290-PRECISION.
013597*    MOVE LENGTH OF MIR-DV-TST-NUM-MIN-AMT
013597     MOVE LENGTH OF MIR-NUM-MIN-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
013597*    MOVE L0290-OUTPUT-DATA     TO MIR-DV-TST-NUM-MIN-AMT.
013597     MOVE L0290-OUTPUT-DATA     TO MIR-NUM-MIN-AMT.
008455 7900-FORMAT-NOMIN-X.
008455     EXIT.
008455*
008455*------------------
008455 7902-FORMAT-NUMAX.
008455*------------------
008455     MOVE 0                     TO L0290-PRECISION.
013597*    MOVE LENGTH OF MIR-DV-TST-NUM-MAX-AMT
013597     MOVE LENGTH OF MIR-NUM-MAX-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
013597*    MOVE L0290-OUTPUT-DATA     TO MIR-DV-TST-NUM-MAX-AMT.
013597     MOVE L0290-OUTPUT-DATA     TO MIR-NUM-MAX-AMT.
008455 7902-FORMAT-NUMAX-X.
008455     EXIT.
      *
010645*--------------------
010645 8100-GET-FORM-TYPES.
010645*--------------------
010645*****************************************************************
010645*  BUILD UWMF KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
010645*****************************************************************
010645
010645     MOVE LOW-VALUES            TO WUWMF-KEY.
010645     MOVE HIGH-VALUES           TO WUWMF-ENDBR-KEY.
010645     MOVE RUWMX-CCAS-TST-ID     TO WUWMF-CCAS-TST-ID.
010645     MOVE RUWMX-CCAS-TST-SUBSET-ID
                                      TO WUWMF-CCAS-TST-SUBSET-ID.
010645     MOVE RUWMX-CCAS-TST-ID     TO WUWMF-ENDBR-CCAS-TST-ID.
010645     MOVE RUWMX-CCAS-TST-SUBSET-ID
010645                                TO WUWMF-ENDBR-CCAS-TST-SUBSET-ID.
010645
010645***  BROWSE THE UWMF FILE AND READ THE RECORD.
010645***  IF THE KEY HAS NOT CHANGED SCROLL FORWARD TO THE NEXT RECORD.
010645*
010645     PERFORM  UWMF-1000-BROWSE
010645         THRU UWMF-1000-BROWSE-X.
010645
010645     MOVE SPACES                TO WS-APPFORM-INFO.
010645
010645     PERFORM  UWMF-2000-READ-NEXT
010645         THRU UWMF-2000-READ-NEXT-X.
010645     PERFORM
010645         VARYING WS-UWMF-SUB FROM 1 BY 1
010645           UNTIL WUWMF-IO-EOF
010645              OR WS-UWMF-SUB > WS-MAX-UWMF
010645         MOVE RUWMF-APP-FORM-TYP-ID
                                      TO
010645                          WS-APP-FORM-TYP (WS-UWMF-SUB)
010645         PERFORM  UWMF-2000-READ-NEXT
010645             THRU UWMF-2000-READ-NEXT-X
010645     END-PERFORM.
013578***  MOVE WS-APPFORM-INFO    TO MIR-APP-FORM-TYP-ID-G.
010645
010645     PERFORM  UWMF-3000-END-BROWSE
010645         THRU UWMF-3000-END-BROWSE-X.
010645
010645 8100-GET-FORM-TYPES-X.
010645     EXIT.
010645*
010645*---------------------
010645 8200-GET-RQMNT-CODES.
010645*---------------------
010645*****************************************************************
010645*  BUILD UWMR KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
010645*****************************************************************
010645
010645     MOVE LOW-VALUES            TO WUWMR-KEY.
010645     MOVE HIGH-VALUES           TO WUWMR-ENDBR-KEY.
010645     MOVE RUWMX-CCAS-TST-ID     TO WUWMR-CCAS-TST-ID.
010645     MOVE RUWMX-CCAS-TST-SUBSET-ID
                                      TO WUWMR-CCAS-TST-SUBSET-ID.
010645     MOVE RUWMX-CCAS-TST-ID
010645                                TO WUWMR-ENDBR-CCAS-TST-ID.
010645     MOVE RUWMX-CCAS-TST-SUBSET-ID
010645                                TO WUWMR-ENDBR-CCAS-TST-SUBSET-ID.
010645
010645***  BROWSE THE UWMR FILE AND READ THE RECORD.
010645***  IF THE KEY HAS NOT CHANGED SCROLL FORWARD TO THE NEXT RECORD.
010645*
010645     PERFORM  UWMR-1000-BROWSE
010645         THRU UWMR-1000-BROWSE-X.
010645
010645     MOVE SPACES                TO WS-REQIR-INFO.
010645
010645     PERFORM  UWMR-2000-READ-NEXT
010645         THRU UWMR-2000-READ-NEXT-X.
010645
010645     PERFORM
010645         VARYING WS-RQCD FROM 1 BY 1
010645           UNTIL WUWMR-IO-EOF
010645              OR WS-RQCD > WS-MAX-RQCD
010645         MOVE RUWMR-REQIR-ID    TO
010645                          WS-REQIR-ID (WS-RQCD)
010645         PERFORM  UWMR-2000-READ-NEXT
010645             THRU UWMR-2000-READ-NEXT-X
010645     END-PERFORM
013578***  MOVE WS-REQIR-INFO      TO MIR-REQIR-ID-G.
010645
010645     PERFORM  UWMR-3000-END-BROWSE
010645         THRU UWMR-3000-END-BROWSE-X.
010645
010645 8200-GET-RQMNT-CODES-X.
010645     EXIT.
010645*
010645*---------------------
010645 8300-GET-LOC-GR-CODES.
010645*---------------------
010645*****************************************************************
010645*  BUILD UWML KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
010645*****************************************************************
010645
010645     MOVE LOW-VALUES            TO WUWML-KEY.
010645     MOVE HIGH-VALUES           TO WUWML-ENDBR-KEY.
010645     MOVE RUWMX-CCAS-TST-ID     TO WUWML-CCAS-TST-ID.
010645     MOVE RUWMX-CCAS-TST-SUBSET-ID
                                      TO WUWML-CCAS-TST-SUBSET-ID.
010645     MOVE RUWMX-CCAS-TST-ID
010645                                TO WUWML-ENDBR-CCAS-TST-ID.
010645     MOVE RUWMX-CCAS-TST-SUBSET-ID
010645                                TO WUWML-ENDBR-CCAS-TST-SUBSET-ID.
010645
010645***  BROWSE THE UWML FILE AND READ THE RECORD.
010645***  IF THE KEY HAS NOT CHANGED SCROLL FORWARD TO THE NEXT RECORD.
010645*
010645     PERFORM  UWML-1000-BROWSE
010645         THRU UWML-1000-BROWSE-X.
010645
010645     MOVE SPACES                TO WS-LOCGR-INFO.
010645
010645     PERFORM  UWML-2000-READ-NEXT
010645         THRU UWML-2000-READ-NEXT-X.
010645
010645     PERFORM
010645         VARYING WS-LCGP-SUB FROM 1 BY 1
010645           UNTIL WUWML-IO-EOF
010645              OR WS-LCGP-SUB > WS-MAX-LCGP
010645         MOVE RUWML-LOC-GR-ID   TO
010645                          WS-LOC-GR-CD (WS-LCGP-SUB)
010645         PERFORM  UWML-2000-READ-NEXT
010645             THRU UWML-2000-READ-NEXT-X
010645     END-PERFORM.
013578***  MOVE WS-LOCGR-INFO      TO MIR-LOC-GR-ID-G.
010645
010645     PERFORM  UWML-3000-END-BROWSE
010645         THRU UWML-3000-END-BROWSE-X.
010645
010645 8300-GET-LOC-GR-CODES-X.
010645     EXIT.
010645*
010418*---------------------
010418 8400-GET-SBSDRY-INFO.
010418*---------------------
010418
010418     MOVE MIR-CCAS-TST-ID       TO WUWMS-CCAS-TST-ID.
010418     MOVE MIR-CCAS-TST-SUBSET-ID      TO WUWMS-CCAS-TST-SUBSET-ID.
010418     MOVE MIR-CCAS-TST-ID       TO WUWMS-ENDBR-CCAS-TST-ID.
010418     MOVE MIR-CCAS-TST-SUBSET-ID
                                      TO WUWMS-ENDBR-CCAS-TST-SUBSET-ID.
010418     MOVE LOW-VALUES            TO WUWMS-SBSDRY-CO-ID.
010418     MOVE HIGH-VALUES           TO WUWMS-ENDBR-SBSDRY-CO-ID.
010418
010418***  BROWSE THE UWMS FILE AND READ THE RECORD.
010418***  IF THE KEY HAS NOT CHANGED SCROLL FORWARD TO THE NEXT RECORD.
010418*
010418     PERFORM  UWMS-1000-BROWSE
010418         THRU UWMS-1000-BROWSE-X.
010418
010418     MOVE SPACES                TO WS-SBSDRY-CO-INFO.
010418
010418     PERFORM  UWMS-2000-READ-NEXT
010418         THRU UWMS-2000-READ-NEXT-X.
010418
010418     PERFORM
010418         VARYING WS-SBCO-SUB FROM 1 BY 1
010418           UNTIL WUWMS-IO-EOF
010418              OR WS-SBCO-SUB > WS-MAX-SBCO
010418         IF  NOT WUWMS-IO-OK
010418             PERFORM  UWMS-3000-END-BROWSE
010418                 THRU UWMS-3000-END-BROWSE-X
010418             GO TO 8400-GET-SBSDRY-INFO-X
010418         ELSE
010418             MOVE RUWMS-SBSDRY-CO-ID
010418                               TO WS-SBSDRY-CO-ID (WS-SBCO-SUB)
010418             PERFORM  UWMS-2000-READ-NEXT
010418                 THRU UWMS-2000-READ-NEXT-X
010418         END-IF
010418     END-PERFORM.
013578***  MOVE WS-SBSDRY-CO-INFO  TO MIR-SBSDRY-CO-ID-G.
010418
010418     PERFORM  UWMS-3000-END-BROWSE
010418         THRU UWMS-3000-END-BROWSE-X.
010418
010418 8400-GET-SBSDRY-INFO-X.
010418     EXIT.
010418*
010418*--------------------
010418 8500-BUILD-UWMS-KEY.
010418*--------------------
010418*****************************************************************
010418*  BUILD UWMS KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
010418*****************************************************************
010418
010418     MOVE MIR-CCAS-TST-ID       TO WUWMS-CCAS-TST-ID.
010418     MOVE MIR-CCAS-TST-SUBSET-ID      TO WUWMS-CCAS-TST-SUBSET-ID.
010418     MOVE MIR-SBSDRY-CO-ID-T (WS-SBSDRY-CO-CNT)
                                      TO WUWMS-SBSDRY-CO-ID.
010418
010418 8500-BUILD-UWMS-KEY-X.
010418     EXIT.
010418*
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************

           IF NOT WS-BUS-FCN-LIST
               PERFORM 9110-BLANK-SCREEN-1
                   THRU 9110-BLANK-SCREEN-1-X
           ELSE
               PERFORM 9120-BLANK-SCREEN-2
                   THRU 9120-BLANK-SCREEN-2-X
557660     END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *--------------------
       9110-BLANK-SCREEN-1.
      *--------------------
      *****************************************************************
      *  SET EACH NON-KEY FIELD ON SCREEN 1 TO SPACES
      *****************************************************************

           MOVE SPACES                TO MIR-CCAS-TST-NM.
           MOVE SPACES                TO MIR-CCAS-TST-TYP-CD.
           MOVE SPACES                TO MIR-CCAS-TST-FORM-CD.
010645*    MOVE SPACES              TO MIR-FRMTYP.
010645     MOVE SPACES                TO MIR-APP-FORM-TYP-ID-G.
           MOVE SPACES                TO MIR-REQIR-ID-G.
017087*    MOVE SPACES                TO MIR-LOC-GRP-PRCES-CD.
017087     MOVE SPACES                TO MIR-LOC-GR-PRCES-CD.
010645     MOVE SPACES                TO MIR-LOC-GR-ID-G.
010418     MOVE SPACES                TO MIR-SBSDRY-CO-PRCES-CD.
010418     MOVE SPACES                TO MIR-SBSDRY-CO-ID-G.

           MOVE SPACES                TO MIR-FLD-ID.
           MOVE SPACES                TO MIR-CCAS-TST-AGE-CD.
           MOVE SPACES                TO MIR-CCAS-TST-LOW-AGE.
           MOVE SPACES                TO MIR-CCAS-TST-HIGH-AGE.
           MOVE SPACES                TO MIR-UNANSWR-ACT-CD.
           MOVE SPACES                TO MIR-UNANSWR-MSG-REF-ID.
           MOVE SPACES                TO MIR-MSG-REF-NUM.
           MOVE SPACES                TO MIR-FAIL-MSG-REF-ID.
           MOVE SPACES                TO MIR-MSG-REF-NUM.
013597*    MOVE SPACES                TO MIR-DV-ANSWR-YES-ACT-CD.
013597     MOVE SPACES                TO MIR-ANSWR-YES-ACT-CD.
013597*    MOVE SPACES                TO MIR-DV-TST-NUM-MIN-AMT.
013597     MOVE SPACES                TO MIR-NUM-MIN-AMT.
013597*    MOVE SPACES                TO MIR-DV-TST-ETBL-TYP-ID.
013597     MOVE SPACES                TO MIR-LIST-ETBL-TYP-ID.
013597*    MOVE SPACES                TO MIR-DV-APP-DT-TYP-CD.
013597     MOVE SPACES                TO MIR-CCAS-TST-DT-TYP-CD.
013597*    MOVE SPACES                TO MIR-DV-ANSWR-NO-ACT-CD.
013597     MOVE SPACES                TO MIR-ANSWR-NO-ACT-CD.
013597*    MOVE SPACES                TO MIR-DV-TST-NUM-MAX-AMT.
013597     MOVE SPACES                TO MIR-NUM-MAX-AMT.
013597*    MOVE SPACES                TO MIR-DV-IN-RNG-ACT-CD-2.
013597     MOVE SPACES                TO MIR-DT-IN-RNG-ACT-CD.
013597*    MOVE SPACES                TO MIR-DV-TST-DT-DUR-CD.
013597     MOVE SPACES                TO MIR-CCAS-TST-DT-DUR-CD.
013597*    MOVE SPACES                TO MIR-DV-IN-RNG-ACT-CD.
013597     MOVE SPACES                TO MIR-NUM-IN-RNG-ACT-CD.
013597*    MOVE SPACES                TO MIR-DV-NFIND-ACT-CD.
013597     MOVE SPACES                TO MIR-LIST-NFIND-ACT-CD.
013597*    MOVE SPACES                TO MIR-DV-TST-DT-CUT-DUR.
013597     MOVE SPACES                TO MIR-CCAS-TST-DT-DUR.
013597*    MOVE SPACES                TO MIR-DV-OUT-RNG-ACT-CD-2.
013597     MOVE SPACES                TO MIR-DT-OUT-RNG-ACT-CD.
013597*    MOVE SPACES                TO MIR-DV-IN-RNG-ACT-CD.
013597     MOVE SPACES                TO MIR-NUM-IN-RNG-ACT-CD.
013597*    MOVE SPACES                TO MIR-DV-OUT-RNG-ACT-CD.
013597     MOVE SPACES                TO MIR-NUM-OUT-RNG-ACT-CD.

       9110-BLANK-SCREEN-1-X.
           EXIT.
      *
      *--------------------
       9120-BLANK-SCREEN-2.
      *--------------------
      *****************************************************************
      *  SET EACH NON-KEY FIELD ON SCREEN 2 TO SPACES
      *****************************************************************

           MOVE SPACES                TO MIR-CCAS-TST-ID-G.
           MOVE SPACES                TO MIR-CCAS-TST-SUBSET-ID-G.
           MOVE SPACES                TO MIR-FLD-ID-G.
           MOVE SPACES                TO MIR-CCAS-TST-NM-G.

       9120-BLANK-SCREEN-2-X.
           EXIT.
      *
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************

           IF NOT WS-BUS-FCN-LIST
               PERFORM 9210-MOVE-RECORD-TO-SCREEN-1
                   THRU 9210-MOVE-RECORD-TO-SCREEN-1-X
           ELSE
               PERFORM 9220-MOVE-RECORD-TO-SCREEN-2
                   THRU 9220-MOVE-RECORD-TO-SCREEN-2-X
557660     END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      *
      *-----------------------------
       9210-MOVE-RECORD-TO-SCREEN-1.
      *-----------------------------
      *****************************************************************
      *  MOVE FILE VALUES TO SCREEN 1
      *****************************************************************

           MOVE RUWMX-CCAS-TST-NM     TO MIR-CCAS-TST-NM.
           MOVE RUWMX-FLD-ID          TO MIR-FLD-ID.
           MOVE RUWMX-CCAS-TST-FORM-CD          TO MIR-CCAS-TST-FORM-CD.
           MOVE RUWMX-CCAS-TST-AGE-CD TO MIR-CCAS-TST-AGE-CD.
017087*    MOVE RUWMX-LOC-GRP-PRCES-CD          TO MIR-LOC-GRP-PRCES-CD.
017087     MOVE RUWMX-LOC-GR-PRCES-CD           TO MIR-LOC-GR-PRCES-CD.
010418     MOVE RUWMX-SBSDRY-CO-PRCES-CD
                                      TO MIR-SBSDRY-CO-PRCES-CD.
010645*    MOVE RUWMX-APP-FORM-TYP-INFO    TO MIR-FRMTYP.
010645     PERFORM  8100-GET-FORM-TYPES
010645         THRU 8100-GET-FORM-TYPES-X.
013578     MOVE WS-APPFORM-INFO       TO MIR-APP-FORM-TYP-ID-G.
           MOVE RUWMX-CCAS-TST-LOW-AGE                    TO WS-NUM-999.
           MOVE WS-NUM-PART2          TO MIR-CCAS-TST-LOW-AGE.
           MOVE RUWMX-CCAS-TST-HIGH-AGE
                                      TO WS-NUM-999.
           MOVE WS-NUM-PART2          TO MIR-CCAS-TST-HIGH-AGE.
           MOVE RUWMX-UNANSWR-ACT-CD  TO MIR-UNANSWR-ACT-CD.
           MOVE RUWMX-UNANSWR-MSG-REF-ID
                                     TO MIR-UNANSWR-MSG-REF-ID.
           MOVE RUWMX-FAIL-MSG-REF-ID TO MIR-FAIL-MSG-REF-ID.
           MOVE RUWMX-MSG-REF-NUM     TO MIR-MSG-REF-NUM.
           MOVE RUWMX-MSG-REF-NUM     TO MIR-MSG-REF-NUM.
010645*    MOVE RUWMX-FAIL-REQIR-INFO      TO MIR-REQIR-ID-G.
010645     PERFORM  8200-GET-RQMNT-CODES
010645         THRU 8200-GET-RQMNT-CODES-X.
013578     MOVE WS-REQIR-INFO         TO MIR-REQIR-ID-G.
010645     PERFORM  8300-GET-LOC-GR-CODES
010645         THRU 8300-GET-LOC-GR-CODES-X.
013578     MOVE WS-LOCGR-INFO         TO MIR-LOC-GR-ID-G.
010418     PERFORM  8400-GET-SBSDRY-INFO
010418         THRU 8400-GET-SBSDRY-INFO-X.
013578     MOVE WS-SBSDRY-CO-INFO     TO MIR-SBSDRY-CO-ID-G.
           MOVE RUWMX-CCAS-TST-TYP-CD TO MIR-CCAS-TST-TYP-CD.
           MOVE RUWMX-CCAS-TST-TYP-CD TO WS-SAVE-TEST-TYPE.

           IF  WS-TEST-TYPE-YESNO
               MOVE RUWMX-ANSWR-YES-ACT-CD
013597*                               TO MIR-DV-ANSWR-YES-ACT-CD
013597                                TO MIR-ANSWR-YES-ACT-CD
               MOVE RUWMX-ANSWR-NO-ACT-CD
013597*                               TO MIR-DV-ANSWR-NO-ACT-CD
013597                                TO MIR-ANSWR-NO-ACT-CD
           ELSE
013597*        MOVE SPACES            TO MIR-DV-ANSWR-YES-ACT-CD
013597*        MOVE SPACES            TO MIR-DV-ANSWR-NO-ACT-CD
013597         MOVE SPACES            TO MIR-ANSWR-YES-ACT-CD
013597         MOVE SPACES            TO MIR-ANSWR-NO-ACT-CD
557660     END-IF.

           IF  WS-TEST-TYPE-NUMERIC
008455*        MOVE RUWMX-TST-NUM-MIN-AMT  TO WS-NUM-9-LEN9
008455*        MOVE WS-NUM-9-LEN9          TO MIR-DV-TST-NUM-MIN-AMT
008455*        MOVE RUWMX-TST-NUM-MAX-AMT  TO WS-NUM-9-LEN9
008455*        MOVE WS-NUM-9-LEN9          TO MIR-DV-TST-NUM-MAX-AMT
013597*        MOVE RUWMX-TST-NUM-MIN-AMT
013597         MOVE RUWMX-NUM-MIN-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
008455         PERFORM  7900-FORMAT-NOMIN
008455             THRU 7900-FORMAT-NOMIN-X
013597*        MOVE RUWMX-TST-NUM-MAX-AMT
013597         MOVE RUWMX-NUM-MAX-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
008455         PERFORM  7902-FORMAT-NUMAX
008455             THRU 7902-FORMAT-NUMAX-X
               MOVE RUWMX-NUM-IN-RNG-ACT-CD
013597*                               TO MIR-DV-IN-RNG-ACT-CD
013597                                TO MIR-NUM-IN-RNG-ACT-CD
               MOVE RUWMX-NUM-OUT-RNG-ACT-CD
013597*                               TO MIR-DV-OUT-RNG-ACT-CD
013597                                TO MIR-NUM-OUT-RNG-ACT-CD
           ELSE
008455*        MOVE ZEROS                  TO WS-NUM-9-LEN9
008455*        MOVE WS-NUM-9-LEN9          TO MIR-DV-TST-NUM-MIN-AMT
008455*        MOVE ZEROS                  TO WS-NUM-9-LEN9
008455*        MOVE WS-NUM-9-LEN9          TO MIR-DV-TST-NUM-MAX-AMT
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE 0                 TO L0290-INPUT-V00
008455         PERFORM  7900-FORMAT-NOMIN
008455             THRU 7900-FORMAT-NOMIN-X
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE 0                 TO L0290-INPUT-V00
008455         PERFORM  7902-FORMAT-NUMAX
008455             THRU 7902-FORMAT-NUMAX-X
013597*        MOVE SPACES            TO MIR-DV-IN-RNG-ACT-CD
013597*        MOVE SPACES            TO MIR-DV-OUT-RNG-ACT-CD
013597         MOVE SPACES            TO MIR-NUM-IN-RNG-ACT-CD
013597         MOVE SPACES            TO MIR-NUM-OUT-RNG-ACT-CD
557660     END-IF.

           IF  WS-TEST-TYPE-LIST
013597*        MOVE RUWMX-TST-ETBL-TYP-ID
013597*                               TO MIR-DV-TST-ETBL-TYP-ID
013597         MOVE RUWMX-LIST-ETBL-TYP-ID
013597                                TO MIR-LIST-ETBL-TYP-ID
               MOVE RUWMX-LIST-FIND-ACT-CD
013597*                               TO MIR-DV-FIND-ACT-CD
013597                                TO MIR-LIST-FIND-ACT-CD
               MOVE RUWMX-LIST-NFIND-ACT-CD
013597*                               TO MIR-DV-NFIND-ACT-CD
013597                                TO MIR-LIST-NFIND-ACT-CD
           ELSE
013597*        MOVE SPACES            TO MIR-DV-TST-ETBL-TYP-ID
013597         MOVE SPACES            TO MIR-LIST-ETBL-TYP-ID
013597*        MOVE SPACES            TO MIR-DV-FIND-ACT-CD
013597         MOVE SPACES            TO MIR-LIST-FIND-ACT-CD
013597*        MOVE SPACES            TO MIR-DV-NFIND-ACT-CD
013597         MOVE SPACES            TO MIR-LIST-NFIND-ACT-CD
557660     END-IF.

           IF  WS-TEST-TYPE-DATE
013597*        MOVE RUWMX-APP-DT-TYP-CD
013597*                               TO MIR-DV-APP-DT-TYP-CD
013597         MOVE RUWMX-CCAS-TST-DT-TYP-CD
013597                                TO MIR-CCAS-TST-DT-TYP-CD
               MOVE RUWMX-CCAS-TST-DT-DUR-CD
013597*                               TO MIR-DV-TST-DT-DUR-CD
013597                                TO MIR-CCAS-TST-DT-DUR-CD
013597*        MOVE RUWMX-CCAS-TST-DT-CUT-DUR
013597         MOVE RUWMX-CCAS-TST-DT-DUR
                                      TO WS-NUM-999
013597*        MOVE WS-NUM-999        TO MIR-DV-TST-DT-CUT-DUR
013597         MOVE WS-NUM-999        TO MIR-CCAS-TST-DT-DUR
               MOVE RUWMX-DT-IN-RNG-ACT-CD
013597*                               TO MIR-DV-IN-RNG-ACT-CD-2
013597                                TO MIR-DT-IN-RNG-ACT-CD
               MOVE RUWMX-DT-OUT-RNG-ACT-CD
013597*                               TO MIR-DV-OUT-RNG-ACT-CD-2
013597                                TO MIR-DT-OUT-RNG-ACT-CD
           ELSE
013597*        MOVE SPACES            TO MIR-DV-APP-DT-TYP-CD
013597         MOVE SPACES            TO MIR-CCAS-TST-DT-TYP-CD
013597*        MOVE SPACES            TO MIR-DV-TST-DT-DUR-CD
013597         MOVE SPACES            TO MIR-CCAS-TST-DT-DUR-CD
               MOVE ZEROS             TO WS-NUM-999
013597*        MOVE WS-NUM-999        TO MIR-DV-TST-DT-CUT-DUR
013597         MOVE WS-NUM-999        TO MIR-CCAS-TST-DT-DUR
013597*        MOVE SPACES            TO MIR-DV-IN-RNG-ACT-CD-2
013597*        MOVE SPACES            TO MIR-DV-OUT-RNG-ACT-CD-2
013597         MOVE SPACES            TO MIR-DT-IN-RNG-ACT-CD
013597         MOVE SPACES            TO MIR-DT-OUT-RNG-ACT-CD
557660     END-IF.

       9210-MOVE-RECORD-TO-SCREEN-1-X.
           EXIT.
      *
      *-----------------------------
       9220-MOVE-RECORD-TO-SCREEN-2.
      *-----------------------------
      *****************************************************************
      *  MOVE FILE VALUES TO SCREEN 2
      *****************************************************************

557659*    MOVE RUWMX-CCAS-TST-NUM    TO MIR-CCAS-TST-ID-T (WS-LINE).
557659*   MOVE RUWMX-CCAS-TST-SFX TO MIR-CCAS-TST-SUBSET-ID-T (WS-LINE).
557659     MOVE RUWMX-CCAS-TST-ID     TO MIR-CCAS-TST-ID-T (WS-LINE).
557659     MOVE RUWMX-CCAS-TST-SUBSET-ID
                                  TO MIR-CCAS-TST-SUBSET-ID-T (WS-LINE).
           MOVE RUWMX-CCAS-TST-NM     TO MIR-CCAS-TST-NM-T (WS-LINE).
           MOVE RUWMX-FLD-ID          TO MIR-FLD-ID-T (WS-LINE).

       9220-MOVE-RECORD-TO-SCREEN-2-X.
           EXIT.
      *
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0005-0000-INIT-PARM-INFO
025970         THRU 0005-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TRANS-NAME          TO TRUE.
025970     SET WS-DEFAULT-KEY-MATCH           TO TRUE.
025970     SET WS-DEFAULT-SOURCE-TEXT         TO TRUE.
025970     SET WS-DEFAULT-SOURCE-SUFFIX       TO TRUE.
025970     SET WS-DEFAULT-SOURCE-TYPE         TO TRUE.
025970     SET WS-DEFAULT-MAX-SCREEN-LINES    TO TRUE.
025970     SET WS-DEFAULT-RQCD                TO TRUE.
025970     SET WS-DEFAULT-MAX-RQCD            TO TRUE.
025970     SET WS-DEFAULT-RQCD-OUT            TO TRUE.
025970     SET WS-DEFAULT-RQCD-MSG            TO TRUE.
025970     SET WS-DEFAULT-RQCD-RPT            TO TRUE.
025970     SET WS-DEFAULT-MAX-UWMF            TO TRUE.
025970     SET WS-DEFAULT-MAX-LCGP            TO TRUE.
025970     SET WS-DEFAULT-MAX-SBCO            TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
010645 COPY CCPELCGP.
010645*
013578 COPY CCPEAFTT.
013578*
       COPY XCPPEXIT.
      *
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY UWMX
014221                         '$VAR2' BY 'UWMX'.
      *
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
      *
       COPY XCPPINIT.
      *
014660*COPY XCPPMEXT.
      *
557698 COPY XCPS0005.
557698*
557698 COPY XCPL0005.
557698*
008455 COPY XCPS0290.
008455 COPY XCPL0290.
008455*
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS                                 *
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
      *
       COPY CCPBEDIT.
010645 COPY CCPNEDIT.
      *
013578*COPY CCPBAFTT.
013578*COPY CCPNAFTT.
      *
       COPY NCPAUWMX.
       COPY NCPBUWMX.
       COPY NCPCUWMX.
       COPY NCPNUWMX.
       COPY NCPUUWMX.
       COPY NCPXUWMX.
      *
010645 COPY NCPAUWMF.
010645 COPY NCPBUWMF.
010645 COPY NCPNUWMF.
010645 COPY NCPUUWMF.
010645 COPY NCPXUWMF.
010645*
010645 COPY NCPAUWML.
010645 COPY NCPBUWML.
010645 COPY NCPNUWML.
010645 COPY NCPUUWML.
010645 COPY NCPXUWML.
010645*
010645 COPY NCPAUWMR.
010645 COPY NCPBUWMR.
016537*COPY NCPGUWMR.
010645 COPY NCPNUWMR.
010645 COPY NCPUUWMR.
010645 COPY NCPXUWMR.
010645*
010418 COPY NCPAUWMS.
010418 COPY NCPBUWMS.
016537*COPY NCPCUWMS.
010418 COPY NCPNUWMS.
010418 COPY NCPUUWMS.
010418 COPY NCPXUWMS.
010418*
016537*COPY CCPBSCOM.
010418 COPY CCPNSCOM.
010418*
       COPY NCPNDFLD.
      *
       COPY NCPNRTAB.
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM NSOM0360                     **
      *****************************************************************
