      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3281.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3281                                         **
      **  REMARKS:  PAAR - POLICY ACTIVITY AUDIT RELATIONSHIP TABLE  **
      **            THIS MODULE CREATES AN ENTRY IN THE PAAR TABLE   **
      **  DOMAIN :  PR                                               **
      **                                                             **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020460**  6.4       DTCC/IPS CONNECTIVITY                            **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
030054**  7.0       PHST SEQUENCE NUMBER EXPANSION                   **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3281'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

025970 01  WS-CONSTANT-AREA.
025970     05  WS-TWRK-KEY                  PIC X(04)
025970                                      VALUE '3280'.
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '3280'.
030054*    05  WS-SEQ-NUM-MAX               PIC 9(03).
030054*        88  WS-SEQ-NUM-MAX-DEFAULT   VALUE 999.
025970
       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-CREATE        VALUE '3281'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '3280'.

           05  WS-WORK-AREA.
               10  WS-PCHST-EFF-IDT-NUM     PIC X(07).
030054*        10  WS-PIC-999               PIC 9(03).
030054         10  WS-PCHST-SEQ-NUM         PIC S9(05) COMP-3.
               10  WS-POLICY-IND            PIC X(01).
                   88  WS-PENDING-POLICY    VALUE 'P'.
                   88  WS-INFORCE-POLICY    VALUE 'I'.
025970*    05  WS-SEQ-NUM-MAX               PIC 9(03).

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY CCWWLOCK.
030054 COPY XCWWCNST.
       COPY XCWWWKDT.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFRPAAF.
       COPY CCFWPAAF.
      /
       COPY CCFRPAAR.
       COPY CCFWPAAR.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCFWPHST.
       COPY CCFRPHST.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
028298 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL8090.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************
       COPY XCWL1640.
       COPY XCWL1646.
       COPY XCWL1660.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3281.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.
023514
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

023514*    PERFORM  9990-INIT-WORKING-STORAGE
023514*        THRU 9990-INIT-WORKING-STORAGE-X.
023514*
           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM 4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM3281'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *--------------------
       4000-PROCESS-CREATE.
      *---------------------

           PERFORM 4200-CREATE-EDITS
              THRU 4200-CREATE-EDITS-X.

           IF  WGLOB-RETURN-ERROR
           OR  WS-PENDING-POLICY
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  PAAR-1000-CREATE
               THRU PAAR-1000-CREATE-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  PAAR-1000-WRITE
               THRU PAAR-1000-WRITE-X.

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM PAAR-1000-CALL-AUDIT
                  THRU PAAR-1000-CALL-AUDIT-X
           END-IF.

           MOVE MIR-POL-ID              TO WPOL-POL-ID.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG:    POLICY @1 NOT FOUND
               MOVE 'XS00000070'         TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID          TO WGLOB-MSG-PARM (01)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
           END-IF.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *-----------------------
       4200-CREATE-EDITS.
      *-----------------------

           MOVE MIR-POL-ID               TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
      *MSG:    POLICY ID @1 MUST BE VALID
               MOVE 'CS32810001'         TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID          TO WGLOB-MSG-PARM (01)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 4200-CREATE-EDITS-X
           END-IF.

           IF  RPOL-POL-STAT-BEFORE-SETL
      *MSG INFORMATIONAL : PENDING POLICY, PAAR NOT CREATED
               MOVE 'CS32810002'               TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-PENDING-POLICY           TO TRUE
               GO TO 4200-CREATE-EDITS-X
           END-IF.

           IF  MIR-PAAFLD-GR-TS = SPACES
           OR  MIR-PAAFLD-GR-TS = WWKDT-ZERO-DT
      *MSG:    TIMESTAMP IS MANDATORY FIELD
               MOVE 'CS32810003'               TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 4200-CREATE-EDITS-X
           ELSE
               PERFORM  1646-1000-BUILD-PARM-INFO
                   THRU 1646-1000-BUILD-PARM-INFO-X
               MOVE MIR-PAAFLD-GR-TS           TO L1646-TIMESTAMP
               PERFORM  1646-1000-EDIT-TIMESTAMP
                   THRU 1646-1000-EDIT-TIMESTAMP-X
               IF  L1646-EDIT-FAILED
                   SET WGLOB-RETURN-ERROR TO  TRUE
      * MSG: INVALID TIMESTAMP
                   MOVE 'CS32810004'      TO  WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU  0260-1000-GENERATE-MESSAGE-X
                   GO TO 4200-CREATE-EDITS-X
              END-IF
           END-IF.

           MOVE MIR-PCHST-EFF-DT         TO L1640-EXTERNAL-DATE.
           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-RETRN-OK
               MOVE L1640-INTERNAL-DATE  TO L1660-INTERNAL-DATE
               PERFORM  1660-2000-CONVERT-INT-TO-INV
                   THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE  TO WS-PCHST-EFF-IDT-NUM
           ELSE
      * MSG:   INVALID POLICY CHANGE HISTORY DATE - @1
               MOVE 'CS32810005'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-PCHST-EFF-DT     TO WGLOB-MSG-PARM (01)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 4200-CREATE-EDITS-X
           END-IF.

           MOVE ZERO                        TO L0280-PRECISION.
030054*    MOVE 3                           TO L0280-LENGTH.
030054*    MOVE 3                           TO L0280-INPUT-SIZE.
030054     MOVE LENGTH OF MIR-PCHST-SEQ-NUM TO L0280-LENGTH.
030054     MOVE L0280-LENGTH                TO L0280-INPUT-SIZE.
           MOVE MIR-PCHST-SEQ-NUM           TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
030054*        COMPUTE WS-PIC-999     =  WS-SEQ-NUM-MAX
030054         COMPUTE WS-PCHST-SEQ-NUM  =  WCNST-MAX-PCHST-SEQ-NUM-N
                                         -  L0280-OUTPUT
           ELSE
               MOVE 'CS32810006'      TO WGLOB-MSG-REF-INFO
      * MSG: ' SEQUENCE NUMBER MUST BE NUMERIC
               PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU  0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO  TRUE
               GO TO 4200-CREATE-EDITS-X
           END-IF.

           MOVE MIR-POL-ID            TO WPAAF-POL-ID.
           MOVE MIR-PAAFLD-GR-TS      TO WPAAF-PAAFLD-GR-TS.
           MOVE 000                   TO WPAAF-PAAFLD-SEQ-NUM.
           MOVE WPAAF-KEY             TO WPAAF-ENDBR-KEY.
           MOVE 999                   TO WPAAF-ENDBR-PAAFLD-SEQ-NUM.

           PERFORM  PAAF-1000-BROWSE
               THRU PAAF-1000-BROWSE-X.

           PERFORM  PAAF-2000-READ-NEXT
               THRU PAAF-2000-READ-NEXT-X.

           IF  WPAAF-IO-OK
               PERFORM  PAAF-3000-END-BROWSE
                   THRU PAAF-3000-END-BROWSE-X
           ELSE
      *MSG: RECORD @1 CANNOT FIND IN PAAR RECORD
               MOVE 'CS32810009'      TO WGLOB-MSG-REF-INFO
               MOVE WPAAF-KEY         TO WGLOB-MSG-PARM (01)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO  TRUE
               PERFORM  PAAF-3000-END-BROWSE
                   THRU PAAF-3000-END-BROWSE-X
               GO TO 4200-CREATE-EDITS-X
           END-IF.

           MOVE MIR-POL-ID            TO WPAAR-POL-ID.
           MOVE MIR-PAAFLD-GR-TS      TO WPAAR-PAAFLD-GR-TS.
           MOVE WS-PCHST-EFF-IDT-NUM  TO WPAAR-PCHST-EFF-IDT-NUM.
030054*    MOVE WS-PIC-999            TO WPAAR-PCHST-SEQ-NUM.
030054     MOVE WS-PCHST-SEQ-NUM      TO WPAAR-PCHST-SEQ-NUM.

           PERFORM  PAAR-1000-READ
               THRU PAAR-1000-READ-X.

           IF  WPAAR-IO-OK
      *MSG: RECORD @1 HAS AREADY EXISTED IN PAAR TABLE
               MOVE 'CS32810007'      TO WGLOB-MSG-REF-INFO
               MOVE WPAAR-KEY         TO WGLOB-MSG-PARM (01)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO  TRUE
               GO TO 4200-CREATE-EDITS-X
           END-IF.

           MOVE MIR-POL-ID            TO WPHST-POL-ID.
           MOVE WS-PCHST-EFF-IDT-NUM  TO WPHST-PCHST-EFF-IDT-NUM.
030054*    MOVE WS-PIC-999            TO WPHST-PCHST-SEQ-NUM.
030054     MOVE WS-PCHST-SEQ-NUM      TO WPHST-PCHST-SEQ-NUM.

           PERFORM  PHST-1000-READ
               THRU PHST-1000-READ-X.

           IF  NOT WPHST-IO-OK
      *MSG:  POLICY CHANGE HISTROY RECORD @1 NOT EXISTED
               MOVE 'CS32810008'      TO WGLOB-MSG-REF-INFO
               MOVE WPHST-KEY         TO WGLOB-MSG-PARM (01)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO  TRUE
               GO TO 4200-CREATE-EDITS-X
           END-IF.

       4200-CREATE-EDITS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1646-0000-INIT-PARM-INFO
025970         THRU 1646-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WWKDT-WORK-FIELDS.
           INITIALIZE  WS-WORK-AREA.
025970     SET  WS-TWRK-KEY-DEFAULT     TO TRUE.
           SET MIR-RETRN-OK             TO TRUE.
030054*    SET WS-SEQ-NUM-MAX-DEFAULT   TO TRUE.
           MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
           MOVE SPACE                   TO WS-POLICY-IND.
025970*    MOVE 999                     TO WS-SEQ-NUM-MAX.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPLPAAR.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPL8090.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
      /
       COPY XCPS1646.
       COPY XCPL1646.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
       COPY CCPBPAAF.
      /
       COPY CCPAPAAR.
       COPY CCPCPAAR.
       COPY CCPNPAAR.
      /
       COPY CCPNPHST.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM3281                     *
      ****************************************************************
