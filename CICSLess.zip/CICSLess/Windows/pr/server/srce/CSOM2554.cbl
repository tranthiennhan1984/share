      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2554.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2554                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE PRTX TABLE IN REVERSE ORDER              **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016457**  6.2       NEW                                              **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2554'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       COPY CCWWINDX.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                           PIC X(04).
               88  WS-BUS-FCN-LIST                     VALUE '2554'.
           05  WS-SUB                                  PIC S9(4) BINARY.
025970*    05  WS-MAX-LIST-LINES                       PIC S9(4) BINARY
025970*                                                VALUE +100.
            05  WS-TRNXT-PRCES-DT                      PIC X(10).
036742      05  WS-TRNXT-GEN-ID                        PIC 9(10).
036742      05  WS-TRNXT-PRCES-TIME                    PIC X(08).
036742*     05  WS-DV-TRNXT-DT                         PIC X(10).
036742*     05  WS-TRNXT-TS                            PIC X(26).
            05  WS-LIST-TOP-IDX                        PIC 9(03) BINARY
                                                       VALUE ZERO.
            05  WS-INT-TIME.
                10  WS-INT-TIME-HR                     PIC X(02).
                10  WS-INT-TIME-MI                     PIC X(02).
                10  WS-INT-TIME-SE                     PIC X(02).
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LIST-LINES                       PIC S9(4) BINARY.
025970         88 WS-MAX-LIST-LINES-DEFAULT            VALUE +100.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
036742 COPY XCWWCNST.
       COPY XCWWWKDT.
       COPY XCWWTIME.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
023447*COPY NCFRPRTX.
023447*COPY NCFWPRTY.
023447 COPY XCFRPRTX.
023447 COPY XCFWPRTY.
      /
025970 COPY CCFRPOL.
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
018764*COPY XCWLPTR.
021930*COPY XCWL0290.
036742 COPY XCWL0280.
023447 COPY XCWL0290.
       COPY XCWL1640.
       COPY CCWL2430.
       COPY CCWL2435.
021930*COPY CCWL0620.
       COPY XCWL8090.
      /
       COPY XCWLCOMM REPLACING '$VAR1' BY '2554'.
           15  LCOMM-HI-KEY.
               20  LCOMM-HI-USER-ID                    PIC X(08).
               20  LCOMM-HI-TRNXT-PRCES-DT             PIC X(10).
036742*        20  LCOMM-HI-TRNXT-TS                   PIC X(26).
036742         20  LCOMM-HI-TRNXT-GEN-ID               PIC S9(10).
036742         20  LCOMM-HI-TRNXT-PRCES-TIME           PIC X(08).
           15  LCOMM-LO-KEY.
               20  LCOMM-LO-USER-ID                    PIC X(08).
               20  LCOMM-LO-TRNXT-PRCES-DT             PIC X(10).
036742*        20  LCOMM-LO-TRNXT-TS                   PIC X(26).
036742         20  LCOMM-LO-TRNXT-GEN-ID               PIC S9(10).
036742         20  LCOMM-LO-TRNXT-PRCES-TIME           PIC X(08).

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2554.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  COMM-1000-INITIALIZE
               THRU COMM-1000-INITIALIZE-X.
036742
036742     PERFORM  9992-INIT-LOCAL-COMM
036742         THRU 9992-INIT-LOCAL-COMM-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2554'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  2100-EDIT-INPUT
               THRU 2100-EDIT-INPUT-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  7100-START-BROSWE
               THRU 7100-START-BROSWE-X.

021930*    PERFORM  0290-1000-BUILD-PARM-INFO
021930*        THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  7200-FILL-LIST
               THRU 7200-FILL-LIST-X.

           PERFORM  7300-END-BROWSE
               THRU 7300-END-BROWSE-X.

           IF  WS-LIST-TOP-IDX > +1
               PERFORM  8000-SHIFT-LIST-TO-TOP
                   THRU 8000-SHIFT-LIST-TO-TOP-X
           END-IF.

           PERFORM  2300-SET-UP-MIR-KEY
               THRU 2300-SET-UP-MIR-KEY-X.

           PERFORM  COMM-3000-DELETE-TWRK
               THRU COMM-3000-DELETE-TWRK-X.
           PERFORM  COMM-2000-WRITE-TWRK
               THRU COMM-2000-WRITE-TWRK-X.


       2000-LIST-X.
           EXIT.

      *----------------
       2100-EDIT-INPUT.
      *----------------

           EVALUATE TRUE

               WHEN MIR-DV-BCKWRD-SCROLL
                    PERFORM  COMM-1000-RETRIEVE-TWRK
                        THRU COMM-1000-RETRIEVE-TWRK-X
                    IF  LCOMM-RETRN-OK
                        GO TO 2100-EDIT-INPUT-X
                    ELSE
                        SET MIR-DV-REFRESH-SCROLL TO TRUE
                    END-IF

           END-EVALUATE.

           PERFORM  2110-EDIT-USER-ID
               THRU 2110-EDIT-USER-ID-X.

           PERFORM  2120-EDIT-TRNXT-PRCES-DT
               THRU 2120-EDIT-TRNXT-PRCES-DT-X.

036742*    PERFORM  2130-EDIT-DV-TRNXT-DT
036742*        THRU 2130-EDIT-DV-TRNXT-DT-X.

036742*    PERFORM  2140-EDIT-DV-TRNXT-TIME
036742*        THRU 2140-EDIT-DV-TRNXT-TIME-X.
036742     PERFORM  2140-EDIT-TRNXT-TIME
036742         THRU 2140-EDIT-TRNXT-TIME-X.
036742
036742     PERFORM  2150-EDIT-GEN-ID
036742         THRU 2150-EDIT-GEN-ID-X.

       2100-EDIT-INPUT-X.
           EXIT.

      *------------------
       2110-EDIT-USER-ID.
      *------------------

           IF  MIR-USER-ID = SPACE
               MOVE WGLOB-USER-ID           TO MIR-USER-ID
           END-IF.

       2110-EDIT-USER-ID-X.
           EXIT.


      *-------------------------
       2120-EDIT-TRNXT-PRCES-DT.
      *--------------------------

           IF  MIR-TRNXT-PRCES-DT = SPACE
               MOVE WGLOB-PROCESS-DATE   TO WS-TRNXT-PRCES-DT
               MOVE WGLOB-PROCESS-DATE   TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               IF L1640-NOT-VALID
                   MOVE SPACE               TO MIR-TRNXT-PRCES-DT
               ELSE
                   MOVE L1640-EXTERNAL-DATE TO MIR-TRNXT-PRCES-DT
               END-IF
               GO TO 2120-EDIT-TRNXT-PRCES-DT-X
           END-IF.

           MOVE MIR-TRNXT-PRCES-DT       TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X
           IF  L1640-NOT-VALID
      ****MSG: INVALID PROCESS DATE
               MOVE 'CS25540001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WWKDT-ZERO-DT        TO WS-TRNXT-PRCES-DT
           ELSE
               MOVE L1640-INTERNAL-DATE  TO WS-TRNXT-PRCES-DT
           END-IF.

       2120-EDIT-TRNXT-PRCES-DT-X.
           EXIT.

      *----------------------
036742*2130-EDIT-DV-TRNXT-DT.
      *----------------------

036742*    IF  MIR-DV-TRNXT-DT = SPACE
036742*        MOVE WGLOB-SYSTEM-DATE-INT   TO WS-DV-TRNXT-DT
036742*        MOVE WGLOB-SYSTEM-DATE-INT   TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
036742*        PERFORM  1640-8000-INTERNAL-TO-MIR
036742*            THRU 1640-8000-INTERNAL-TO-MIR-X
036742*        IF L1640-NOT-VALID
036742*            MOVE SPACE               TO MIR-DV-TRNXT-DT
036742*        ELSE
036742*            MOVE L1640-EXTERNAL-DATE TO MIR-DV-TRNXT-DT
036742*        END-IF
036742*        GO TO 2130-EDIT-DV-TRNXT-DT-X
036742*    END-IF.
036742*
036742*    MOVE MIR-DV-TRNXT-DT          TO L1640-EXTERNAL-DATE
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X
036742*    PERFORM 1640-7000-MIR-TO-INT
036742*       THRU 1640-7000-MIR-TO-INT-X
036742*    IF  L1640-NOT-VALID
      ****MSG: INVALID SYSTEM DATE
036742*        MOVE 'CS25540002'         TO WGLOB-MSG-REF-INFO
036742*        PERFORM  0260-1000-GENERATE-MESSAGE
036742*            THRU 0260-1000-GENERATE-MESSAGE-X
036742*        MOVE WWKDT-ZERO-DT        TO WS-DV-TRNXT-DT
036742*    ELSE
036742*        MOVE L1640-INTERNAL-DATE  TO WS-DV-TRNXT-DT
036742*    END-IF.
036742*
036742*2130-EDIT-DV-TRNXT-DT-X.
036742*    EXIT.

      *------------------------
036742*2140-EDIT-DV-TRNXT-TIME.
036742 2140-EDIT-TRNXT-TIME.
      *------------------------

036742*    IF  MIR-DV-TRNXT-TIME = SPACE
036742     IF  MIR-TRNXT-PRCES-TIME = SPACE
               MOVE WGLOB-SYSTEM-TIME    TO WTIME-EDIT-TIME
036742*        MOVE WTIME-EDIT-HHMMSS    TO MIR-DV-TRNXT-TIME
036742         MOVE WTIME-EDIT-HHMMSS    TO MIR-TRNXT-PRCES-TIME
036742         MOVE WWKDT-ZERO-TS        TO WWKDT-INT-TS
036742         MOVE WTIME-EDIT-HH        TO WWKDT-INT-TS-HR
036742         MOVE WTIME-EDIT-MM        TO WWKDT-INT-TS-MI
036742         MOVE WTIME-EDIT-SS        TO WWKDT-INT-TS-SE
036742         MOVE WWKDT-INT-TS-HHMMSS  TO WS-TRNXT-PRCES-TIME
036742*        GO TO 2140-EDIT-DV-TRNXT-TIME-X
036742         GO TO 2140-EDIT-TRNXT-TIME-X
           END-IF.

036742*    IF  MIR-DV-TRNXT-HR > '23'
036742*    OR  MIR-DV-TRNXT-HR < '00'
036742*    OR  MIR-DV-TRNXT-MI > '59'
036742*    OR  MIR-DV-TRNXT-MI < '00'
036742*    OR  MIR-DV-TRNXT-SEC > '59'
036742*    OR  MIR-DV-TRNXT-SEC < '00'
036742     IF  MIR-TRNXT-PRCES-TIME (1:2) > '23'
036742     OR  MIR-TRNXT-PRCES-TIME (1:2) < '00'
036742     OR  MIR-TRNXT-PRCES-TIME (3:2) > '59'
036742     OR  MIR-TRNXT-PRCES-TIME (3:2) < '00'
036742     OR  MIR-TRNXT-PRCES-TIME (5:2) > '59'
036742     OR  MIR-TRNXT-PRCES-TIME (5:2) < '00'
      ****MSG: INVALID TIME
               MOVE 'CS25540003'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
036742     ELSE
036742         MOVE MIR-TRNXT-PRCES-TIME TO WTIME-EDIT-TIME
036742         MOVE WWKDT-ZERO-TS        TO WWKDT-INT-TS
036742         MOVE WTIME-EDIT-HH        TO WWKDT-INT-TS-HR
036742         MOVE WTIME-EDIT-MM        TO WWKDT-INT-TS-MI
036742         MOVE WTIME-EDIT-SS        TO WWKDT-INT-TS-SE
036742         MOVE WWKDT-INT-TS-HHMMSS  TO WS-TRNXT-PRCES-TIME
           END-IF.

036742*2140-EDIT-DV-TRNXT-TIME-X.
036742 2140-EDIT-TRNXT-TIME-X.
           EXIT.
036742
036742*-----------------
036742 2150-EDIT-GEN-ID.
036742*-----------------
036742
036742     IF  MIR-TRNXT-GEN-ID = SPACE
036742         MOVE WCNST-MAX-TRNXT-GEN-ID-N
036742                                      TO WS-TRNXT-GEN-ID
036742         GO TO 2150-EDIT-GEN-ID-X
036742     END-IF.
036742     MOVE MIR-TRNXT-GEN-ID            TO L0280-INPUT-DATA
036742     SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
036742     MOVE LENGTH OF MIR-TRNXT-GEN-ID  TO L0280-LENGTH.
036742     MOVE ZERO                        TO L0280-PRECISION.
036742     MOVE LENGTH OF MIR-TRNXT-GEN-ID  TO L0280-INPUT-SIZE.
036742     PERFORM  0280-1000-NUMERIC-EDIT
036742         THRU 0280-1000-NUMERIC-EDIT-X.
036742
036742     IF  L0280-OK
036742         MOVE L0280-OUTPUT      TO WS-TRNXT-GEN-ID
036742     ELSE
036742* MSG: 'INVALID NUMERIC FIELD'
036742         MOVE 'XS00000018'      TO WGLOB-MSG-REF-INFO
036742         PERFORM  0260-1000-GENERATE-MESSAGE
036742             THRU 0260-1000-GENERATE-MESSAGE-X
036742     END-IF.
036742
036742 2150-EDIT-GEN-ID-X.
036742     EXIT.

      *-------------------------
       2300-SET-UP-MIR-KEY.
      *-------------------------

036742*    IF  LCOMM-LO-KEY = LOW-VALUES
036742     IF  LCOMM-LO-TRNXT-PRCES-DT = WWKDT-LOW-DT
036742     AND LCOMM-LO-TRNXT-PRCES-TIME = WWKDT-LOW-TIME
036742     AND LCOMM-LO-TRNXT-GEN-ID = 0
               GO TO 2300-SET-UP-MIR-KEY-X
           END-IF.

           MOVE LCOMM-LO-USER-ID             TO WPRTY-USER-ID.
           MOVE LCOMM-LO-TRNXT-PRCES-DT      TO WPRTY-TRNXT-PRCES-DT.
036742*    MOVE LCOMM-LO-TRNXT-TS            TO WPRTY-TRNXT-TS.
036742     MOVE LCOMM-LO-TRNXT-GEN-ID        TO WPRTY-TRNXT-GEN-ID.
036742     MOVE LCOMM-LO-TRNXT-PRCES-TIME    TO WPRTY-TRNXT-PRCES-TIME.

           MOVE WPRTY-KEY                    TO WPRTY-ENDBR-KEY.
036742*    MOVE WWKDT-LOW-TS                 TO WPRTY-ENDBR-TRNXT-TS.
036742     MOVE WWKDT-LOW-TIME               TO
036742           WPRTY-ENDBR-TRNXT-PRCES-TIME.
036742     MOVE ZERO                         TO
036742           WPRTY-ENDBR-TRNXT-GEN-ID.

           PERFORM  PRTY-1000-BROWSE-PREV
               THRU PRTY-1000-BROWSE-PREV-X.

            PERFORM  PRTY-2000-READ-PREV
                THRU PRTY-2000-READ-PREV-X
                2 TIMES.

           IF  NOT WPRTY-IO-OK
               MOVE LCOMM-HI-USER-ID         TO RPRTX-USER-ID
               MOVE LCOMM-HI-TRNXT-PRCES-DT  TO RPRTX-TRNXT-PRCES-DT
036742*        MOVE LCOMM-HI-TRNXT-TS        TO RPRTX-TRNXT-TS
036742         MOVE LCOMM-HI-TRNXT-GEN-ID    TO RPRTX-TRNXT-GEN-ID
036742         MOVE LCOMM-HI-TRNXT-PRCES-TIME
036742                                       TO RPRTX-TRNXT-PRCES-TIME
           END-IF.

           PERFORM  PRTY-3000-END-BROWSE-PREV
               THRU PRTY-3000-END-BROWSE-PREV-X.

           MOVE RPRTX-USER-ID             TO MIR-USER-ID.

           MOVE RPRTX-TRNXT-PRCES-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE                 TO MIR-TRNXT-PRCES-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE   TO MIR-TRNXT-PRCES-DT
           END-IF.

036742*    MOVE RPRTX-TRNXT-TS            TO WWKDT-INT-TS.
036742*
036742*    MOVE WWKDT-INT-TS-DT           TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
036742*    PERFORM 1640-8000-INTERNAL-TO-MIR
036742*       THRU 1640-8000-INTERNAL-TO-MIR-X.
036742*    IF  L1640-NOT-VALID
036742*        MOVE SPACE                 TO MIR-DV-TRNXT-DT
036742*    ELSE
036742*        MOVE L1640-EXTERNAL-DATE   TO MIR-DV-TRNXT-DT
036742*    END-IF.
036742*
036742*    MOVE WWKDT-INT-TS-HR           TO MIR-DV-TRNXT-HR.
036742*    MOVE WWKDT-INT-TS-MI           TO MIR-DV-TRNXT-MI.
036742*    MOVE WWKDT-INT-TS-SE           TO MIR-DV-TRNXT-SEC.
036742     MOVE RPRTX-TRNXT-GEN-ID        TO L0290-INPUT-V00.
036742     MOVE ZERO                      TO L0290-PRECISION.
036742     MOVE LENGTH OF MIR-TRNXT-GEN-ID
036742                                    TO L0290-MAX-OUT-LEN.
036742     SET L0290-SIGN-POS-DISPLAY     TO TRUE
036742     PERFORM 0290-2000-FORMAT-FOR-MIR
036742        THRU 0290-2000-FORMAT-FOR-MIR-X
036742     MOVE L0290-OUTPUT-DATA         TO MIR-TRNXT-GEN-ID.
036742
036742     MOVE RPRTX-TRNXT-PRCES-TIME    TO WWKDT-INT-TS-HHMMSS.
036742     MOVE WWKDT-INT-TS-HR           TO WTIME-EDIT-HH
036742     MOVE WWKDT-INT-TS-MI           TO WTIME-EDIT-MM
036742     MOVE WWKDT-INT-TS-SE           TO WTIME-EDIT-SS
036742     MOVE WTIME-EDIT-HHMMSS         TO MIR-TRNXT-PRCES-TIME.
036742

       2300-SET-UP-MIR-KEY-X.
           EXIT.

      *----------------
       7000-BUILD-KEYS.
      *----------------

           EVALUATE TRUE

               WHEN MIR-DV-BCKWRD-SCROLL
                    PERFORM  7020-SET-READ-NEXT-KEYS
                        THRU 7020-SET-READ-NEXT-KEYS-X

               WHEN OTHER
                    MOVE MIR-USER-ID       TO WPRTY-USER-ID
                    MOVE WS-TRNXT-PRCES-DT TO WPRTY-TRNXT-PRCES-DT
036742*             MOVE WWKDT-LOW-TS      TO WWKDT-INT-TS
036742*             MOVE WS-DV-TRNXT-DT    TO WWKDT-INT-TS-DT
036742*             MOVE MIR-DV-TRNXT-HR   TO WWKDT-INT-TS-HR
036742*             MOVE MIR-DV-TRNXT-MI   TO WWKDT-INT-TS-MI
036742*             MOVE MIR-DV-TRNXT-SEC  TO WWKDT-INT-TS-SE
036742*             MOVE '999999'          TO WWKDT-INT-TS-MS
036742*             MOVE WWKDT-INT-TS      TO WPRTY-TRNXT-TS
036742              MOVE WS-TRNXT-PRCES-TIME
036742                                     TO WPRTY-TRNXT-PRCES-TIME
036742              MOVE WS-TRNXT-GEN-ID   TO WPRTY-TRNXT-GEN-ID
                    MOVE WPRTY-KEY         TO WPRTY-ENDBR-KEY
036742*             MOVE WWKDT-LOW-TS      TO WPRTY-ENDBR-TRNXT-TS
036742              MOVE WWKDT-LOW-TIME    TO
036742                   WPRTY-ENDBR-TRNXT-PRCES-TIME
036742              MOVE ZERO              TO WPRTY-ENDBR-TRNXT-GEN-ID

           END-EVALUATE.

       7000-BUILD-KEYS-X.
           EXIT.

      *-------------------------
       7020-SET-READ-NEXT-KEYS.
      *-------------------------

           MOVE LCOMM-HI-USER-ID          TO WPRTY-USER-ID.
036742     MOVE MIR-USER-ID               TO WPRTY-USER-ID.
           MOVE LCOMM-HI-TRNXT-PRCES-DT   TO WPRTY-TRNXT-PRCES-DT.
036742*    MOVE LCOMM-HI-TRNXT-TS         TO WPRTY-TRNXT-TS.
036742     MOVE LCOMM-HI-TRNXT-GEN-ID     TO WPRTY-TRNXT-GEN-ID.
036742     MOVE LCOMM-HI-TRNXT-PRCES-TIME TO WPRTY-TRNXT-PRCES-TIME.

           MOVE WPRTY-KEY              TO WPRTY-ENDBR-KEY.
036742*    MOVE WWKDT-HIGH-TS          TO WPRTY-ENDBR-TRNXT-TS.
036742     MOVE WWKDT-HIGH-TIME        TO WPRTY-ENDBR-TRNXT-PRCES-TIME.
036742     MOVE WCNST-MAX-TRNXT-GEN-ID-N
036742                                 TO WPRTY-ENDBR-TRNXT-GEN-ID.

           PERFORM  PRTY-1000-BROWSE
               THRU PRTY-1000-BROWSE-X.

           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL I > 2
               OR NOT WPRTY-IO-OK

               PERFORM  PRTY-2000-READ-NEXT
                   THRU PRTY-2000-READ-NEXT-X
               IF  WPRTY-IO-OK
                   PERFORM  7021-SET-START-KEY
                       THRU 7021-SET-START-KEY-X
               ELSE
                   MOVE LCOMM-LO-USER-ID    TO WPRTY-USER-ID
                   MOVE LCOMM-LO-TRNXT-PRCES-DT
                                            TO WPRTY-TRNXT-PRCES-DT
036742*            MOVE LCOMM-LO-TRNXT-TS   TO WPRTY-TRNXT-TS
036742             MOVE LCOMM-LO-TRNXT-GEN-ID
036742                                      TO WPRTY-TRNXT-GEN-ID
036742             MOVE LCOMM-LO-TRNXT-PRCES-TIME
036742                                      TO WPRTY-TRNXT-PRCES-TIME
               END-IF

           END-PERFORM.

           IF  NOT WPRTY-IO-OK
      *MSG: 'TOP OF LIST'
               MOVE 'XS00000245'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  PRTY-3000-END-BROWSE
               THRU PRTY-3000-END-BROWSE-X.

       7020-SET-READ-NEXT-KEYS-X.
           EXIT.

      *-------------------
       7021-SET-START-KEY.
      *-------------------

036742*    MOVE RPRTX-USER-ID            TO WPRTY-USER-ID.
           MOVE RPRTX-TRNXT-PRCES-DT     TO WPRTY-TRNXT-PRCES-DT.
036742*    MOVE RPRTX-TRNXT-TS           TO WPRTY-TRNXT-TS.
036742     MOVE RPRTX-TRNXT-GEN-ID       TO WPRTY-TRNXT-GEN-ID.
036742     MOVE RPRTX-TRNXT-PRCES-TIME   TO WPRTY-TRNXT-PRCES-TIME.


       7021-SET-START-KEY-X.
           EXIT.

      *-------------------
       7100-START-BROSWE.
      *-------------------

           EVALUATE TRUE

               WHEN MIR-DV-FORWRD-SCROLL
               WHEN MIR-DV-REFRESH-SCROLL
                    PERFORM  7110-INIT-READ-PREV
                        THRU 7110-INIT-READ-PREV-X

               WHEN MIR-DV-BCKWRD-SCROLL
                    PERFORM  7120-INIT-READ-NEXT
                        THRU 7120-INIT-READ-NEXT-X

           END-EVALUATE.

       7100-START-BROSWE-X.
           EXIT.

      *--------------------
       7110-INIT-READ-PREV.
      *--------------------

           PERFORM  PRTY-1000-BROWSE-PREV
               THRU PRTY-1000-BROWSE-PREV-X.

           PERFORM  PRTY-2000-READ-PREV
               THRU PRTY-2000-READ-PREV-X.

           IF  WPRTY-IO-EOF
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  7111-SET-TWRK-HI-KEY
                   THRU 7111-SET-TWRK-HI-KEY-X
               PERFORM  7121-SET-TWRK-LO-KEY
                   THRU 7121-SET-TWRK-LO-KEY-X
           END-IF.

       7110-INIT-READ-PREV-X.
           EXIT.

      *---------------------
       7111-SET-TWRK-HI-KEY.
      *---------------------

           MOVE RPRTX-USER-ID             TO LCOMM-HI-USER-ID.
           MOVE RPRTX-TRNXT-PRCES-DT      TO LCOMM-HI-TRNXT-PRCES-DT.
036742*    MOVE RPRTX-TRNXT-TS            TO LCOMM-HI-TRNXT-TS.
036742     MOVE RPRTX-TRNXT-GEN-ID        TO LCOMM-HI-TRNXT-GEN-ID.
036742     MOVE RPRTX-TRNXT-PRCES-TIME    TO LCOMM-HI-TRNXT-PRCES-TIME.

       7111-SET-TWRK-HI-KEY-X.
           EXIT.

      *--------------------
       7120-INIT-READ-NEXT.
      *--------------------

           PERFORM  PRTY-1000-BROWSE
               THRU PRTY-1000-BROWSE-X.

           PERFORM  PRTY-2000-READ-NEXT
               THRU PRTY-2000-READ-NEXT-X.

           IF  WPRTY-IO-EOF
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  7111-SET-TWRK-HI-KEY
                   THRU 7111-SET-TWRK-HI-KEY-X
               PERFORM  7121-SET-TWRK-LO-KEY
                   THRU 7121-SET-TWRK-LO-KEY-X
           END-IF.

       7120-INIT-READ-NEXT-X.
           EXIT.

      *---------------------
       7121-SET-TWRK-LO-KEY.
      *---------------------

           MOVE RPRTX-USER-ID             TO LCOMM-LO-USER-ID.
           MOVE RPRTX-TRNXT-PRCES-DT      TO LCOMM-LO-TRNXT-PRCES-DT.
036742*    MOVE RPRTX-TRNXT-TS            TO LCOMM-LO-TRNXT-TS.
036742     MOVE RPRTX-TRNXT-GEN-ID        TO LCOMM-LO-TRNXT-GEN-ID.
036742     MOVE RPRTX-TRNXT-PRCES-TIME    TO LCOMM-LO-TRNXT-PRCES-TIME.

       7121-SET-TWRK-LO-KEY-X.
           EXIT.

      *-----------------
       7200-FILL-LIST.
      *-----------------

           EVALUATE TRUE

               WHEN MIR-DV-FORWRD-SCROLL
               WHEN MIR-DV-REFRESH-SCROLL
                    MOVE ZERO               TO WS-SUB
                    MOVE +1                 TO WS-LIST-TOP-IDX
                    PERFORM  7210-BCKWRD-BROWSE-PRTY
                        THRU 7210-BCKWRD-BROWSE-PRTY-X
                        UNTIL   WS-SUB > WS-MAX-LIST-LINES
                        OR      WPRTY-IO-EOF

               WHEN MIR-DV-BCKWRD-SCROLL
                    COMPUTE WS-SUB = WS-MAX-LIST-LINES + 1
                    PERFORM  7220-FORWRD-BROWSE-PRTY
                        THRU 7220-FORWRD-BROWSE-PRTY-X
                        UNTIL   WS-SUB < 1
                        OR      WPRTY-IO-EOF
                   IF  WS-SUB < +1
                       MOVE +1              TO WS-LIST-TOP-IDX
                   ELSE
                       MOVE WS-SUB          TO WS-LIST-TOP-IDX
                   END-IF

           END-EVALUATE.

           IF  WPRTY-IO-EOF
               IF  MIR-DV-FORWRD-SCROLL
               OR  MIR-DV-REFRESH-SCROLL
      *MSG: 'END OF LIST'
                   MOVE 'XS00000015'    TO WGLOB-MSG-REF-INFO
               ELSE
      *MSG: 'TOP OF LIST'
                   MOVE 'XS00000245'    TO WGLOB-MSG-REF-INFO
               END-IF
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS     TO TRUE
           END-IF.

       7200-FILL-LIST-X.
           EXIT.
      /
      *-------------------------
       7210-BCKWRD-BROWSE-PRTY.
      *-------------------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  PRTY-2000-READ-PREV
               THRU PRTY-2000-READ-PREV-X.


       7210-BCKWRD-BROWSE-PRTY-X.
           EXIT.

      *-------------------------
       7220-FORWRD-BROWSE-PRTY.
      *-------------------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  PRTY-2000-READ-NEXT
               THRU PRTY-2000-READ-NEXT-X.


       7220-FORWRD-BROWSE-PRTY-X.
           EXIT.

      *------------------
       7300-END-BROWSE.
      *------------------

           EVALUATE TRUE

               WHEN MIR-DV-FORWRD-SCROLL
               WHEN MIR-DV-REFRESH-SCROLL
                    PERFORM  PRTY-3000-END-BROWSE-PREV
                        THRU PRTY-3000-END-BROWSE-PREV-X

               WHEN MIR-DV-BCKWRD-SCROLL
                    PERFORM  PRTY-3000-END-BROWSE
                        THRU PRTY-3000-END-BROWSE-X

           END-EVALUATE.

       7300-END-BROWSE-X.
           EXIT.

      *------------------------
       8000-SHIFT-LIST-TO-TOP.
      *------------------------

           MOVE +1                          TO I.

           PERFORM
               VARYING WS-SUB
               FROM WS-LIST-TOP-IDX BY 1
               UNTIL WS-SUB > WS-MAX-LIST-LINES

               PERFORM  8100-SHIFT-ROW
                   THRU 8100-SHIFT-ROW-X

               ADD +1                       TO I

           END-PERFORM.

           IF  I < WS-LIST-TOP-IDX
               MOVE WS-LIST-TOP-IDX         TO I
           END-IF.

           PERFORM
               VARYING I
               FROM I BY 1
               UNTIL I > WS-MAX-LIST-LINES

               PERFORM  8200-EMPTY-ROW
                   THRU 8200-EMPTY-ROW-X

           END-PERFORM.

      *------------------------
       8000-SHIFT-LIST-TO-TOP-X.
      *------------------------
           EXIT.

      *----------------
       8100-SHIFT-ROW.
      *----------------

           MOVE MIR-TRNXT-PRT-REASN-CD-T (WS-SUB)
           TO MIR-TRNXT-PRT-REASN-CD-T (I).

           MOVE MIR-POL-ID-BASE-T (WS-SUB)
           TO MIR-POL-ID-BASE-T (I).

           MOVE MIR-POL-ID-SFX-T (WS-SUB)
           TO MIR-POL-ID-SFX-T (I).

           MOVE MIR-DV-OWN-CLI-NM-T (WS-SUB)
           TO MIR-DV-OWN-CLI-NM-T (I).

           MOVE MIR-CVG-NUM-T (WS-SUB)
           TO MIR-CVG-NUM-T (I).

           MOVE MIR-BUS-FCN-ID-2-T (WS-SUB)
           TO MIR-BUS-FCN-ID-2-T (I).

           MOVE MIR-TRNXT-TYP-CD-T (WS-SUB)
           TO MIR-TRNXT-TYP-CD-T (I).

           MOVE MIR-DOC-ID-T (WS-SUB)
           TO MIR-DOC-ID-T (I).

           MOVE MIR-TRNXT-LANG-CD-T (WS-SUB)
           TO MIR-TRNXT-LANG-CD-T (I).

023447*    MOVE MIR-TRNXT-DOC-CPY-QTY-T (WS-SUB)
023447*    TO MIR-TRNXT-DOC-CPY-QTY-T (I).

036742*    MOVE MIR-TRNXT-TS-T (WS-SUB)
036742*    TO MIR-TRNXT-TS-T (I).
036742*
036742*    MOVE MIR-TRNXT-TS-T (WS-SUB)
036742*    TO MIR-TRNXT-TS-T (I).

036742*    MOVE MIR-DV-TRNXT-TIME-T (WS-SUB)
036742*    TO MIR-DV-TRNXT-TIME-T (I).
036742     MOVE MIR-TRNXT-PRCES-DT-T (WS-SUB)
036742     TO MIR-TRNXT-PRCES-DT-T (I).
036742     MOVE MIR-TRNXT-PRCES-TIME-T (WS-SUB)
036742     TO MIR-TRNXT-PRCES-TIME-T (I).

023447     MOVE MIR-TRNXT-PRT-STAT-CD-T (WS-SUB)
023447     TO MIR-TRNXT-PRT-STAT-CD-T (I).
023447
023447     MOVE MIR-TRNXT-PART-NUM-T (WS-SUB)
023447     TO MIR-TRNXT-PART-NUM-T (I).
023447
036742*    MOVE MIR-TRNXT-INSTC-ID-T (WS-SUB)
036742*    TO MIR-TRNXT-INSTC-ID-T (I).
036742*
036742     MOVE MIR-TRNXT-GEN-ID-T (WS-SUB)
036742     TO MIR-TRNXT-GEN-ID-T (I).

       8100-SHIFT-ROW-X.
           EXIT.

      *----------------
       8200-EMPTY-ROW.
      *----------------

           MOVE SPACE
           TO MIR-TRNXT-PRT-REASN-CD-T (I).

           MOVE SPACE
           TO MIR-POL-ID-BASE-T (I).

           MOVE SPACE
           TO MIR-POL-ID-SFX-T (I).

           MOVE SPACE
           TO MIR-DV-OWN-CLI-NM-T (I).

           MOVE SPACE
           TO MIR-CVG-NUM-T (I).

           MOVE SPACE
           TO MIR-BUS-FCN-ID-2-T (I).

           MOVE SPACE
           TO MIR-TRNXT-TYP-CD-T (I).

           MOVE SPACE
           TO MIR-DOC-ID-T (I).

           MOVE SPACE
           TO MIR-TRNXT-LANG-CD-T (I).

023447*    MOVE SPACE
023447*    TO MIR-TRNXT-DOC-CPY-QTY-T (I).

036742*    MOVE SPACE
036742*    TO MIR-TRNXT-TS-T (I).

           MOVE SPACE
036742*    TO MIR-DV-TRNXT-TIME-T (I).
036742     TO MIR-TRNXT-PRCES-TIME-T (I).
023447
023447     MOVE SPACE
023447     TO MIR-TRNXT-PRT-STAT-CD-T (I).
023447
023447     MOVE SPACE
023447     TO MIR-TRNXT-PART-NUM-T (I).
023447
036742*    MOVE SPACE
036742*    TO MIR-TRNXT-INSTC-ID-T (I).
036742
036742     MOVE SPACE
036742     TO MIR-TRNXT-GEN-ID-T (I).
036742     MOVE SPACE
036742     TO MIR-TRNXT-PRCES-DT-T (I).

       8200-EMPTY-ROW-X.
           EXIT.

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           IF  MIR-DV-FORWRD-SCROLL
           OR  MIR-DV-REFRESH-SCROLL
               ADD +1                    TO WS-SUB
           ELSE
               SUBTRACT +1               FROM WS-SUB
           END-IF.

           IF  WS-SUB > WS-MAX-LIST-LINES
           OR  WS-SUB < +1
               GO TO 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           IF  MIR-DV-FORWRD-SCROLL
           OR  MIR-DV-REFRESH-SCROLL
               PERFORM  7121-SET-TWRK-LO-KEY
                   THRU 7121-SET-TWRK-LO-KEY-X
           ELSE
               PERFORM  7111-SET-TWRK-HI-KEY
                   THRU 7111-SET-TWRK-HI-KEY-X
           END-IF.

           MOVE RPRTX-TRNXT-PRT-REASN-CD
           TO MIR-TRNXT-PRT-REASN-CD-T (WS-SUB).

           MOVE RPRTX-CVG-NUM
           TO MIR-CVG-NUM-T (WS-SUB).

           MOVE RPRTX-BUS-FCN-ID
           TO MIR-BUS-FCN-ID-2-T (WS-SUB).

           MOVE RPRTX-TRNXT-TYP-CD
           TO MIR-TRNXT-TYP-CD-T (WS-SUB).

           MOVE RPRTX-DOC-ID
           TO MIR-DOC-ID-T (WS-SUB).

           MOVE RPRTX-TRNXT-LANG-CD
           TO MIR-TRNXT-LANG-CD-T (WS-SUB).

023447*    MOVE RPRTX-TRNXT-DOC-CPY-QTY
023447*    TO MIR-TRNXT-DOC-CPY-QTY-T (WS-SUB).

036742*    MOVE RPRTX-TRNXT-TS
036742*    TO MIR-TRNXT-TS-T (WS-SUB).

036742*    MOVE RPRTX-TRNXT-TS
036742*    TO WWKDT-INT-TS.
036742*
036742*    MOVE WWKDT-INT-TS-HR
036742*    TO WS-INT-TIME-HR.
036742*    MOVE WWKDT-INT-TS-MI
036742*    TO WS-INT-TIME-MI.
036742*    MOVE WWKDT-INT-TS-SE
036742*    TO WS-INT-TIME-SE.
036742*    MOVE WS-INT-TIME
036742*    TO MIR-DV-TRNXT-TIME-T (WS-SUB).
036742     MOVE RPRTX-TRNXT-PRCES-TIME
036742                        TO WWKDT-INT-TS-HHMMSS.
036742     MOVE WWKDT-INT-TS-HR  TO WTIME-EDIT-HH
036742     MOVE WWKDT-INT-TS-MI  TO WTIME-EDIT-MM
036742     MOVE WWKDT-INT-TS-SE  TO WTIME-EDIT-SS
036742     MOVE WTIME-EDIT-HHMMSS
036742     TO MIR-TRNXT-PRCES-TIME-T (WS-SUB).

           MOVE RPRTX-POL-ID-BASE
           TO MIR-POL-ID-BASE-T (WS-SUB).

           MOVE RPRTX-POL-ID-SFX
           TO MIR-POL-ID-SFX-T (WS-SUB).

           IF  RPRTX-CLI-ID NOT = L2435-CLI-ID
               PERFORM  2435-1000-BUILD-PARM-INFO
                   THRU 2435-1000-BUILD-PARM-INFO-X
               MOVE RPRTX-CLI-ID            TO L2435-CLI-ID
               PERFORM  2435-1000-OBTAIN-CLI-INFO
                   THRU 2435-1000-OBTAIN-CLI-INFO-X
           END-IF.

           IF  L2435-RETRN-OK
           OR  L2435-RETRN-BTH-DT-INVALID
               MOVE L2435-CLI-NM-COMPRESSED
                                    TO MIR-DV-OWN-CLI-NM-T (WS-SUB)
           ELSE
               MOVE SPACE           TO MIR-DV-OWN-CLI-NM-T (WS-SUB)
           END-IF.
023447
023447     MOVE RPRTX-TRNXT-PRT-STAT-CD
023447     TO MIR-TRNXT-PRT-STAT-CD-T (WS-SUB).
023447
023447     PERFORM  0290-1000-BUILD-PARM-INFO
023447         THRU 0290-1000-BUILD-PARM-INFO-X.
023447
023447     MOVE RPRTX-TRNXT-PART-NUM  TO L0290-INPUT-V00.
023447     MOVE 0                     TO L0290-PRECISION.
023447     MOVE LENGTH OF MIR-TRNXT-PART-NUM-T (WS-SUB)
023447                                TO L0290-MAX-OUT-LEN.
023447     SET L0290-SIGN-POS-DISPLAY TO TRUE.
023447     PERFORM 0290-2000-FORMAT-FOR-MIR
023447        THRU 0290-2000-FORMAT-FOR-MIR-X.
023447     MOVE L0290-OUTPUT-DATA     TO MIR-TRNXT-PART-NUM-T (WS-SUB).
023447
036742*    MOVE RPRTX-TRNXT-INSTC-ID  TO L0290-INPUT-V00.
036742*    MOVE 0                     TO L0290-PRECISION.
036742*    MOVE LENGTH OF MIR-TRNXT-INSTC-ID-T (WS-SUB)
036742*                               TO L0290-MAX-OUT-LEN.
036742*    SET L0290-SIGN-POS-DISPLAY TO TRUE.
036742*    PERFORM 0290-2000-FORMAT-FOR-MIR
036742*       THRU 0290-2000-FORMAT-FOR-MIR-X.
036742*    MOVE L0290-OUTPUT-DATA     TO MIR-TRNXT-INSTC-ID-T (WS-SUB).

           IF  MIR-DV-OWN-CLI-NM-T (WS-SUB) NOT = SPACE
           OR  RPRTX-POL-ID = SPACE
               GO TO 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           MOVE RPRTX-POL-ID                TO L2430-POL-ID.
           MOVE ZERO                        TO L2430-CVG.
           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.
           IF  L2430-RETRN-OK
               MOVE L2430-CLI-NM-COMPRESSED
                                    TO MIR-DV-OWN-CLI-NM-T (WS-SUB)
           END-IF.

036742     MOVE RPRTX-TRNXT-GEN-ID        TO L0290-INPUT-V00.
036742     MOVE ZERO                      TO L0290-PRECISION.
036742     MOVE LENGTH OF MIR-TRNXT-GEN-ID
036742                                    TO L0290-MAX-OUT-LEN.
036742     SET L0290-SIGN-POS-DISPLAY     TO TRUE
036742     PERFORM 0290-2000-FORMAT-FOR-MIR
036742        THRU 0290-2000-FORMAT-FOR-MIR-X
036742     MOVE L0290-OUTPUT-DATA         TO MIR-TRNXT-GEN-ID-T
036742                                       (WS-SUB).
036742     MOVE RPRTX-TRNXT-PRCES-DT      TO L1640-INTERNAL-DATE.
036742     PERFORM 1640-8000-INTERNAL-TO-MIR
036742        THRU 1640-8000-INTERNAL-TO-MIR-X.
036742     MOVE L1640-EXTERNAL-DATE       TO MIR-TRNXT-PRCES-DT-T
036742                                       (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
036742     PERFORM  0280-0000-INIT-PARM-INFO
036742         THRU 0280-0000-INIT-PARM-INFO-X.
036742
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE       WS-WORKING-STORAGE.
025970     INITIALIZE       WTIME-WORK-AREAS.
025970     INITIALIZE       FREQUENTLY-USED-INDICES.
025970
025970     SET WS-MAX-LIST-LINES-DEFAULT TO TRUE.
025970
025970     MOVE SPACES TO   WWKDT-WORK-FIELDS.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
036742
036742*---------------------------
036742 9992-INIT-LOCAL-COMM.
036742*---------------------------
036742
036742     MOVE  WWKDT-LOW-DT              TO LCOMM-LO-TRNXT-PRCES-DT
036742     MOVE  WGLOB-PROCESS-DATE        TO LCOMM-HI-TRNXT-PRCES-DT.
036742     MOVE  WWKDT-LOW-TIME            TO LCOMM-LO-TRNXT-PRCES-TIME.
036742     MOVE  '23:59:59'                TO LCOMM-HI-TRNXT-PRCES-TIME.
036742     MOVE  ZEROS                     TO LCOMM-LO-TRNXT-GEN-ID.
036742     MOVE  WCNST-MAX-TRNXT-GEN-ID-N  TO LCOMM-HI-TRNXT-GEN-ID.
036742
036742 9992-INIT-LOCAL-COMM-X.
036742     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY XCPPINIT.
       COPY XCPPEXIT.

025970 COPY CCPS2430.
       COPY XCPSCOMM.
       COPY XCPPCOMM.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.

021930*COPY CCPL0620.

025970 COPY XCPS1640.
       COPY XCPL1640.
036742
036742 COPY XCPS0280.
036742 COPY XCPL0280.

021930*COPY XCPS0290.
021930*COPY XCPL0290.
023447 COPY XCPS0290.
023447 COPY XCPL0290.
      /
       COPY XCPS8090.
018763*COPY XCPL8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.

      /
       COPY CCPS2435.
018764*COPY CCCL2435.
018764 COPY CCPL2435.
      /
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
023447*COPY NCPVPRTY.
023447*COPY NCPBPRTY.
023447 COPY XCPVPRTY.
023447 COPY XCPBPRTY.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2554
      *****************************************************************
