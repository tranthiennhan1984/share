      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM1466.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM1466                                         **
      **  REMARKS:  TERMINATION - FULL SURRENDER                     **
      **            CURRENT AND FUTURE DATED TRANSACTION PROCESSING  **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020478**  6.6       FUTURE DATED TRANSACTION                         **
028262**  6.7       GLOBAL MESSAGE ERROR INDICATOR                   **
031357**  7.0       COVERAGE NUMBER EDIT ERROR                       **
026947**  7.1       PAC/CRC/DD2 SCHEDULE AT REVERSAL                 **
032623**  7.1       PHST GROUPING                                    **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

       CONFIGURATION SECTION.
      /
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM1466'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.
      *
       COPY SQLCA.
       COPY CCWWINDX.

       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                  PIC X(04).
               88  WS-BUS-FCN-VALID           VALUE '1460'
                                                    '1461'
                                                    '1466'.
               88  WS-BUS-FCN-TSURR           VALUE '1460'.
               88  WS-BUS-FCN-RSURR           VALUE '1461'.
               88  WS-BUS-FCN-FSURR           VALUE '1466'.
           05  WS-BASIC-EDIT-IND              PIC X.
               88  WS-BASIC-EDIT-FAILED       VALUE 'Y'.
           05  WS-SUB                         PIC S9(04) BINARY.
           05  DISPLAY-SUB                    PIC 99.
           05  WS-CVG-NUM                     PIC X(02).
           05  WS-CVG-NUM-N                   REDEFINES
               WS-CVG-NUM                     PIC 99.
           05  WS-EFF-DATE                    PIC X(10).
           05  SWITCHES-FOR-1466.
               10  WS-LEVEL-SW                PIC X.
                   88  PROCESSING-POLICY      VALUE 'P'.
                   88  PROCESSING-COVERAGE    VALUE 'C'.
               10  POLICY-LOCK-SW             PIC X.
                   88  POLICY-NOT-LOCKED      VALUE 'N'.
                   88  POLICY-LOCKED          VALUE 'Y'.
               10  UPDATE-SW                  PIC X.
                   88  UPDATE-NOT-REQUIRED    VALUE 'N'.
                   88  UPDATE-REQUIRED        VALUE 'Y'.
               10  DEFERRED-TRANS-SW          PIC X.
                   88  NOT-DEFERRED-TRANS     VALUE 'N'.
                   88  DEFERRED-TRANS         VALUE 'Y'.
               10  WS-REDO-SW                 PIC X(01).
                   88  WS-REDO-OK             VALUE 'Y'.
                   88  WS-REDO-NOT-OK         VALUE 'N'.
026947     05  WS-SAVE-PMT-DRW-DT             PIC X(10).
029060     05  WS-LOOP-SW                     PIC X(01).
029060         88  WS-LOOP-NOT-END            VALUE 'N'.
029060         88  WS-LOOP-END                VALUE 'Y'.
029060     05  WS-REVRS-PCHST-SEQ-NUM         PIC S9(05) COMP-3.

      ***********************************************************
      * COMMON COPYBOOKS
      ***********************************************************
       COPY XCWWWKDT.
      /
       COPY XCWLDTLK.
       COPY XCWL1640.
       COPY XCWL8090.
      /
       COPY CCWWLOCK.
      /
       COPY XCWEBLCH.
      /
036742*COPY XCWL0035.
029060/
029060 COPY CCWE0691.

      **********************************************************
      * I/O COPYBOOKS
      **********************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
       COPY CCFHPOL.
       COPY CCFWPOL.
029060/
029060 COPY CCFRPHST.
029060 COPY CCFWPHST.

           EXEC SQL INCLUDE CCFWPORQ END-EXEC.
           EXEC SQL INCLUDE CCFRPORQ END-EXEC.
      /
      ***********************************************************
      * CALLED MODULE PARAMETER INFORMATION
      ***********************************************************
       COPY CCWL0182.
       COPY CCWL0201.
       COPY CCWL0289.
       COPY CCWL0620.
       COPY CCWL1140.
       COPY CCWL1692.
029060 COPY XCWL1660.
      /
032623 COPY CCWL2408.
       COPY CCWL2430.
       COPY CCWL2626.
      /
       COPY CCWL4750.
      /
       COPY CCWL4780.
      /
       COPY CCWL5400.
       COPY FCWL8170.
      /
       COPY FCWLFUND.
      /
       COPY XCWL0280.
       COPY XCWL0290.
      /
      **********************************************************
      * INPUT PARAMETER INFORMATION
      **********************************************************
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      /
       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM1466.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-TRANSACTIONS
               THRU 1000-PROCESS-TRANSACTIONS-X.

           PERFORM  FPCK-1000-CHECK-POLICY
               THRU FPCK-1000-CHECK-POLICY-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *--------------------------
       1000-PROCESS-TRANSACTIONS.
      *--------------------------
      *

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9400-SETUP-MSIN-REFERENCE
               THRU 9400-SETUP-MSIN-REFERENCE-X.

           PERFORM  1100-TRANS-EDIT
               THRU 1100-TRANS-EDIT-X.

           PERFORM  2000-TERM-PROCESSING
               THRU 2000-TERM-PROCESSING-X.

           IF  WS-BASIC-EDIT-FAILED
           OR  NOT WS-BUS-FCN-FSURR
               MOVE 'N'        TO MIR-DV-ENBL-FTL-OVRID-IND
           ELSE
               IF  WGLOB-MSG-ERROR-SW > ZERO
                   MOVE 'Y'    TO MIR-DV-ENBL-FTL-OVRID-IND
028262             SET MIR-RETRN-ERROR-OVRID
028262                         TO TRUE
               ELSE
                   MOVE 'N'    TO MIR-DV-ENBL-FTL-OVRID-IND
               END-IF
           END-IF.

       1000-PROCESS-TRANSACTIONS-X.
           EXIT.
      /
      *----------------
       1100-TRANS-EDIT.
      *----------------

029060*    IF  MIR-LTAXWH-CALC-CD = EBLCH-BLANK-FIELD-CHAR
029060*        MOVE SPACES          TO MIR-LTAXWH-CALC-CD
029060*    END-IF.
029060
029060     IF  MIR-LTAXWH-RQST-CD = EBLCH-BLANK-FIELD-CHAR
029060         MOVE SPACES          TO MIR-LTAXWH-RQST-CD
029060     END-IF.

           MOVE MIR-DV-EFF-DT         TO L1640-EXTERNAL-DATE.
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE   TO WS-EFF-DATE.

           MOVE MIR-POL-ID            TO WPOL-POL-ID.

           IF  MIR-DV-PRCES-STATE-CD NOT = '3'
               PERFORM  POL-1000-READ-TWRK-TS
                   THRU POL-1000-READ-TWRK-TS-X
           ELSE
               PERFORM  POL-2000-UPDATE-TWRK-TS
                   THRU POL-2000-UPDATE-TWRK-TS-X
               SET POLICY-LOCKED              TO TRUE
               IF  MIR-RETRN-TS-MISMATCH
      *  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
      *  NOT COMPLETE
                   MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
                   MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
                   MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-BASIC-EDIT-FAILED   TO TRUE
                   GO TO 1100-TRANS-EDIT-X
               END-IF
           END-IF.

           IF  NOT WPOL-IO-OK
      *MSG: POLICY IS NOT FOUND ON FILE
               MOVE 'CS14660007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-BASIC-EDIT-FAILED      TO TRUE
               GO TO 1100-TRANS-EDIT-X
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-POL-XFER-UPDATE         TO TRUE.
           SET L5400-CRCY-MSG-REQD           TO TRUE.
           SET L5400-STAT-MSG-NOT-REQD       TO TRUE.

      * CHEKC THE ACCES RESTRICTION CODE

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-XFER-ACCS-RESTRICTED
           OR  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
      *MSG: SURRENDER RESTRICTED FOR POLICY (@1)
               MOVE 'CS14660015'             TO WGLOB-MSG-REF-INFO
               MOVE RPOL-POL-ID              TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-BASIC-EDIT-FAILED      TO TRUE
               GO TO 1100-TRANS-EDIT-X
           END-IF.


           MOVE MIR-CVG-NUM                  TO WS-CVG-NUM.
           IF  WS-CVG-NUM NOT NUMERIC
               MOVE ZERO                     TO WS-CVG-NUM-N
           END-IF.

           SET UPDATE-NOT-REQUIRED           TO TRUE.
           SET NOT-DEFERRED-TRANS            TO TRUE.

           PERFORM  1300-GENERAL-EDITS
               THRU 1300-GENERAL-EDITS-X.

       1100-TRANS-EDIT-X.
           EXIT.

      *-------------------------
       1300-GENERAL-EDITS.
      *-------------------------
      *
      * VERIFY POLICY ACCESS.
      *

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           IF  WS-BUS-FCN-RSURR
029060         PERFORM  1310-EDIT-PHST-SEQ-NUM
029060             THRU 1310-EDIT-PHST-SEQ-NUM-X
               GO TO 1300-GENERAL-EDITS-X
           END-IF.
           PERFORM  1692-1000-BUILD-PARM-INFO
               THRU 1692-1000-BUILD-PARM-INFO-X.

           PERFORM  1500-FILL-EDIT-DATA
               THRU 1500-FILL-EDIT-DATA-X.

           IF  WS-BUS-FCN-FSURR
               EVALUATE  TRUE

                   WHEN  MIR-DV-PRCES-STATE-CD = '2'
                       PERFORM  1692-2000-EDIT-FUTURE-SURR-1
                           THRU 1692-2000-EDIT-FUTURE-SURR-1-X
                   WHEN  MIR-DV-PRCES-STATE-CD = '3'
                       IF  MIR-DV-FTL-MSG-OVRID-IND = 'Y'
                           SET L1692-FTL-MSG-OVRID TO TRUE
                       END-IF
                       PERFORM  1692-6000-EDIT-FUTURE-SURR-3
                           THRU 1692-6000-EDIT-FUTURE-SURR-3-X
               END-EVALUATE
           ELSE
               EVALUATE  TRUE
                   WHEN  MIR-DV-PRCES-STATE-CD = '2'
                       PERFORM  1692-1000-EDIT-CURR-SURR-1
                           THRU 1692-1000-EDIT-CURR-SURR-1-X
                   WHEN  MIR-DV-PRCES-STATE-CD = '3'
                       PERFORM  1692-5000-EDIT-CURR-SURR-3
                           THRU 1692-5000-EDIT-CURR-SURR-3-X
               END-EVALUATE
           END-IF.

           IF  L1692-RETRN-EDIT-ERROR
               SET WS-BASIC-EDIT-FAILED      TO TRUE
           END-IF.

       1300-GENERAL-EDITS-X.
           EXIT.

029060*------------------------
029060 1310-EDIT-PHST-SEQ-NUM.
029060*------------------------
029060
029060     MOVE RPOL-POL-ID            TO WPHST-POL-ID.
029060     MOVE WS-EFF-DATE            TO L1660-INTERNAL-DATE.
029060
029060     PERFORM  1660-2000-CONVERT-INT-TO-INV
029060         THRU 1660-2000-CONVERT-INT-TO-INV-X.
029060
029060     MOVE L1660-INVERTED-DATE    TO WPHST-PCHST-EFF-IDT-NUM.
029060     MOVE ZERO                   TO WPHST-PCHST-SEQ-NUM.
029060     MOVE WPHST-KEY              TO WPHST-ENDBR-KEY.
029060     MOVE HIGH-VALUES            TO WPHST-ENDBR-PCHST-EFF-IDT-NUM.
029060
029060     PERFORM  PHST-1000-BROWSE
029060         THRU PHST-1000-BROWSE-X.
029060
029060     PERFORM  PHST-2000-READ-NEXT
029060         THRU PHST-2000-READ-NEXT-X.
029060
029060     SET WS-LOOP-NOT-END         TO TRUE.
029060
029060     PERFORM
029060         UNTIL NOT WPHST-IO-OK
029060         OR WS-LOOP-END
029060
029060         IF  RPHST-POL-ACTV-TYP-ID = '3003'
029060         AND RPHST-PCHST-STAT-OVERRIDE
029060         AND RPHST-PCHST-PREV-STAT-CD = SPACE
029060             SET WS-LOOP-END     TO TRUE
029060         ELSE
029060             PERFORM  PHST-2000-READ-NEXT
029060                 THRU PHST-2000-READ-NEXT-X
029060         END-IF
029060
029060     END-PERFORM.
029060
029060     PERFORM  PHST-3000-END-BROWSE
029060         THRU PHST-3000-END-BROWSE-X.
029060
029060     IF  WS-LOOP-END
029060     AND RPHST-CVG-NUM NOT = WS-CVG-NUM-N
029060     AND WS-CVG-NUM-N NOT = '00'
029060*MSG : CANNOT REINSTATE COVERAGE OUT OF SEQUENCE.  COVERAGE @1
029060*      SHOULD BE REINSTATED FIRST
029060         MOVE 'CS14660016'       TO WGLOB-MSG-REF-INFO
029060         MOVE RPHST-CVG-NUM      TO WGLOB-MSG-PARM (1)
029060         PERFORM  0260-1000-GENERATE-MESSAGE
029060             THRU 0260-1000-GENERATE-MESSAGE-X
029060         SET WGLOB-RETURN-ERROR  TO TRUE
029060         GO TO 1310-EDIT-PHST-SEQ-NUM-X
029060     END-IF.
029060
029060     MOVE RPHST-PCHST-REL-SEQ-NUM 
029060                                 TO WS-REVRS-PCHST-SEQ-NUM.
029060
029060 1310-EDIT-PHST-SEQ-NUM-X.
029060     EXIT.
029060     
      *------------------
       1500-FILL-EDIT-DATA.
      *------------------

           MOVE MIR-POL-ID                   TO L1692-POL-ID.
031357*    MOVE MIR-CVG-NUM                  TO L1692-CVG-NUM.
031357     MOVE WS-CVG-NUM                   TO L1692-CVG-NUM.
           MOVE MIR-DV-EFF-DT                TO L1692-DV-EFF-DT.
           MOVE MIR-SUPRES-CNFRM-IND         TO L1692-SUPRES-CNFRM-IND.
           MOVE MIR-DV-SELCT-PAYO-MTHD-CD
                                         TO L1692-DV-SELCT-PAYO-MTHD-CD.

           MOVE MIR-CLI-ID                   TO L1692-CLI-ID.
           MOVE MIR-CLI-BNK-ACCT-NUM         TO L1692-CLI-BNK-ACCT-NUM.
           MOVE MIR-SURR-TAX-OVRID-CD        TO L1692-SURR-TAX-OVRID-CD.
           MOVE MIR-DV-POL-TAX-ACB-AMT   TO L1692-DV-POL-TAX-ACB-AMT.
           MOVE MIR-DV-GRS-DSTRB-AMT         TO L1692-DV-GRS-DSTRB-AMT.
           MOVE MIR-DV-TAXBL-GRS-DSTRB-AMT
                                      TO L1692-DV-TAXBL-GRS-DSTRB-AMT.
029060*    MOVE MIR-FED-TAXWH-CALC-CD        TO L1692-FED-TAXWH-CALC-CD.
029060*    MOVE MIR-FED-TAXWH-RQST-AMT    TO L1692-FED-TAXWH-RQST-AMT.
029060*    MOVE MIR-FED-TAXWH-RQST-PCT    TO L1692-FED-TAXWH-RQST-PCT.
029060*    MOVE MIR-LTAXWH-CALC-CD           TO L1692-LTAXWH-CALC-CD.
029060*    MOVE MIR-LTAXWH-FLAT-AMT          TO L1692-LTAXWH-FLAT-AMT.
029060*    MOVE MIR-LTAXWH-PCT               TO L1692-LTAXWH-PCT.
029060     MOVE MIR-FTAXWH-RQST-CD           TO L1692-FTAXWH-RQST-CD.
029060     MOVE MIR-FTAXWH-RQST-AMT          TO L1692-FTAXWH-RQST-AMT.
029060     MOVE MIR-FTAXWH-RQST-PCT          TO L1692-FTAXWH-RQST-PCT.
029060     MOVE MIR-LTAXWH-RQST-CD           TO L1692-LTAXWH-RQST-CD.
029060     MOVE MIR-LTAXWH-RQST-AMT          TO L1692-LTAXWH-RQST-AMT.
029060     MOVE MIR-LTAXWH-RQST-PCT          TO L1692-LTAXWH-RQST-PCT.

       1500-FILL-EDIT-DATA-X.
           EXIT.

      *---------------------
       2000-TERM-PROCESSING.
      *---------------------

           PERFORM  2300-SET-UP-OUTPUT-MAP
               THRU 2300-SET-UP-OUTPUT-MAP-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
           OR  MIR-RETRN-TS-MISMATCH
               GO TO 2000-TERM-PROCESSING-X
           END-IF.

           IF  NOT WS-BUS-FCN-RSURR
           AND NOT L1692-RETRN-OK
               GO TO 2000-TERM-PROCESSING-X
           END-IF.


           IF  WS-CVG-NUM = ZERO
               SET PROCESSING-POLICY          TO TRUE
           ELSE
               SET PROCESSING-COVERAGE        TO TRUE
           END-IF.

           IF  WS-BUS-FCN-RSURR
               PERFORM  4000-REV-SURRENDER
                   THRU 4000-REV-SURRENDER-X
           ELSE
               PERFORM  3000-SURRENDER
                   THRU 3000-SURRENDER-X
           END-IF.

           IF  POLICY-LOCKED
               PERFORM  2100-UPDATE-POLICY
                   THRU 2100-UPDATE-POLICY-X
           END-IF.

       2000-TERM-PROCESSING-X.
           EXIT.

      *--------------------
       2100-UPDATE-POLICY.
      *--------------------

           SET POLICY-NOT-LOCKED              TO TRUE

           IF  UPDATE-REQUIRED
               PERFORM  0289-1000-INIT-PARM-INFO
                   THRU 0289-1000-INIT-PARM-INFO-X
               MOVE WS-EFF-DATE  TO L0289-LO-PAC-DT
               MOVE WS-EFF-DATE  TO L0289-LO-CRC-DT
               MOVE WS-EFF-DATE  TO L0289-LO-DD2-DT
               MOVE WS-EFF-DATE  TO L0289-PROC-EFF-DT
026947
026947*        DO NOT SCHEDULE PAC/CRC/DD2 APPLY FOR REVERSAL
026947
026947         MOVE WWKDT-ZERO-DT   TO WS-SAVE-PMT-DRW-DT
026947         IF  WS-BUS-FCN-RSURR
026947         AND RPOL-POL-PMT-DRW-DT NOT = WWKDT-ZERO-DT
026947         AND RPOL-POL-PREM-SUSP-AMT <= ZERO
026947             MOVE RPOL-POL-PMT-DRW-DT
026947                              TO WS-SAVE-PMT-DRW-DT
026947             MOVE WWKDT-ZERO-DT
026947                              TO RPOL-POL-PMT-DRW-DT
026947         END-IF
               PERFORM  0289-1000-OBTAIN-NXT-ACTV
                   THRU 0289-1000-OBTAIN-NXT-ACTV-X
               IF  L0289-RETRN-OK
                   MOVE L0289-NXT-ACTV-TYP-CD
                        TO RPOL-NXT-ACTV-TYP-CD
                   MOVE L0289-NXT-ACTV-DT
                        TO RPOL-POL-NXT-ACTV-DT
               ELSE
                   MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
                   MOVE WGLOB-PROCESS-DATE
                             TO RPOL-POL-NXT-ACTV-DT
               END-IF
026947         IF  WS-SAVE-PMT-DRW-DT NOT =  WWKDT-ZERO-DT
026947             MOVE WS-SAVE-PMT-DRW-DT
026947                              TO RPOL-POL-PMT-DRW-DT
026947         END-IF
               MOVE WGLOB-PROCESS-DATE
                                  TO RPOL-PREV-FILE-MAINT-DT
               PERFORM  POL-2000-REWRITE
                   THRU POL-2000-REWRITE-X
               PERFORM  POL-1000-READ-TWRK-TS
                   THRU POL-1000-READ-TWRK-TS-X
               PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
                   THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
           ELSE
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
           END-IF.

       2100-UPDATE-POLICY-X.
           EXIT.

      *-----------------------
       2300-SET-UP-OUTPUT-MAP.
      *-----------------------
      *
      **  THIS ROUTINE INITIALIZES THE OUTPUT MAP
      *
           MOVE ZERO                  TO WGLOB-RETURN-CODE.

      * GET OWNER'S NAME

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           MOVE MIR-POL-ID                    TO L2430-POL-ID.
           MOVE ZERO                          TO I.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF L2430-RETRN-OK
               INITIALIZE                        L0620-INPUT-PARM-INFO
               IF L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES                    TO MIR-DV-OWN-CLI-NM
           END-IF.

       2300-SET-UP-OUTPUT-MAP-X.
           EXIT.

      /
      *---------------
       3000-SURRENDER.
      *---------------

           IF  MIR-DV-PRCES-STATE-CD NOT = '3'
               PERFORM  3100-FIRSTPASS-SURR
                   THRU 3100-FIRSTPASS-SURR-X
           ELSE
               IF  WS-BUS-FCN-FSURR
                   PERFORM  3400-CONFIRM-FD-SURR
                       THRU 3400-CONFIRM-FD-SURR-X
                   GO TO 3000-SURRENDER-X
               ELSE
                   PERFORM  3300-CONFIRM-SURR
                       THRU 3300-CONFIRM-SURR-X
               END-IF
           END-IF.

           IF  WGLOB-RETURN-ERROR
               GO TO 3000-SURRENDER-X
           END-IF.

           IF  WS-BUS-FCN-FSURR
           AND MIR-DV-FTL-MSG-OVRID-IND = 'Y'
               GO TO 3000-SURRENDER-X
           END-IF.

           PERFORM  3500-FILL-OUTPUT-FIELDS
               THRU 3500-FILL-OUTPUT-FIELDS-X.

       3000-SURRENDER-X.
           EXIT.
      /
      *--------------------
       3100-FIRSTPASS-SURR.
      *--------------------


           IF  WS-BUS-FCN-FSURR
               IF  MIR-DV-FTL-MSG-OVRID-IND = 'Y'
                   SET L1692-FTL-MSG-OVRID      TO TRUE
                   PERFORM  3600-OVERRIDE-MIR
                       THRU 3600-OVERRIDE-MIR-X
               END-IF

               PERFORM  1692-4000-EDIT-FUTURE-SURR-2
                   THRU 1692-4000-EDIT-FUTURE-SURR-2-X
           ELSE
               PERFORM  1692-3000-EDIT-CURR-SURR-2
                   THRU 1692-3000-EDIT-CURR-SURR-2-X
           END-IF.

           IF  NOT L1692-RETRN-OK
               SET  WGLOB-RETURN-ERROR    TO TRUE
           END-IF.

           IF L1692-DEFER-REQUIRE
               SET DEFERRED-TRANS TO TRUE
      * MSG: FUND UNIT PRICES NOT AVAILABLE,
      *      TERMINATION WILL BE DEFERRED
               MOVE 'CS14660005' TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  WS-BUS-FCN-FSURR
      *MSG: VALUES SHOWN ARE CALCULATED AS OF THE CURRENT PROCESSING
      *     DATE
               MOVE 'CS14660010'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  PROCESSING-POLICY
               MOVE 'CS14660001'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'CS14660002'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  5700-CHECK-UNDO
               THRU 5700-CHECK-UNDO-X.

           IF  WS-BUS-FCN-FSURR
      *MSG: YOU ARE ABOUT TO SCHEDULE A FUTURE DATED WITHDRAWAL REQUEST
               MOVE 'CS14660011'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

      *MSG: ANY FINANCIAL ACTIVITIES THAT OCCUR PRIOR TO THE FUTURE
      *     DATE MAY AFFECT THE PROCESSING OF THE FUTURE DATED ACTIVITY
               MOVE 'CS14660012'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

           END-IF.


       3100-FIRSTPASS-SURR-X.
           EXIT.
      /
      *-------------------
       3300-CONFIRM-SURR.
      *--------------------

           PERFORM  1140-1000-BUILD-PARM-INFO
               THRU 1140-1000-BUILD-PARM-INFO-X.

           IF  MIR-SUPRES-CNFRM-IND = 'Y'
               SET L1140-SUPPRESS-CONFIRM TO TRUE
           END-IF.

           MOVE L1692-CVG-NUM-N           TO L1140-CVG-NUM.
           MOVE MIR-DV-SELCT-PAYO-MTHD-CD TO L1140-PAYO-MTHD-CD.
           MOVE L1692-DV-EFF-DT-R         TO L1140-EFF-DT.
           MOVE WGLOB-USER-ID         TO L1140-INIT-HOLDER.
           MOVE MIR-SURR-TAX-OVRID-CD TO L1140-SURR-FOR-TRANSFER-CD.
029060*    MOVE MIR-FED-TAXWH-CALC-CD TO L1140-FED-TAXWH-CALC-CD.
029060*    MOVE MIR-LTAXWH-CALC-CD  TO L1140-LTAXWH-CALC-CD.
           SET  L1140-LTAXWH-DISB-NONP TO TRUE.
           MOVE MIR-CLI-ID           TO L1140-CLI-ID.
           MOVE MIR-CLI-BNK-ACCT-NUM TO L1140-CLI-BNK-ACCT-NUM.

           IF PROCESSING-POLICY
               SET L1140-PRCES-LEVEL-POLICY  TO TRUE
           ELSE
               SET L1140-PRCES-LEVEL-CVG     TO TRUE
           END-IF.

           PERFORM  5000-PROCESS-START
               THRU 5000-PROCESS-START-X.

           IF  NOT WGLOB-GOOD-RETURN
           OR  WS-REDO-NOT-OK
           OR  DEFERRED-TRANS
               GO TO 3300-CONFIRM-SURR-X
           END-IF.

032623     PERFORM  2408-0000-INIT-PARM-INFO
032623         THRU 2408-0000-INIT-PARM-INFO-X.
032623     MOVE RPOL-POL-ID              TO L2408-POL-ID.
032623     MOVE L1692-DV-EFF-DT-R        TO L2408-EFF-DT.
032623     PERFORM  2408-2000-NXT-PHST-SEQ
032623         THRU 2408-2000-NXT-PHST-SEQ-X.
032623     MOVE L2408-NXT-PCHST-SEQ-NUM  TO WGLOB-PCHST-REL-SEQ-NUM.

           SET L1140-PRCES-TYP-ALL TO TRUE.
           SET L1140-REDO-WARNING  TO TRUE.

           PERFORM  1140-1000-PROCESS-SURRENDER
               THRU 1140-1000-PROCESS-SURRENDER-X.

           IF  NOT L1140-RETRN-OK
               SET WGLOB-RETURN-ERROR     TO TRUE
           END-IF.
032623     MOVE ZERO                     TO WGLOB-PCHST-REL-SEQ-NUM.

           PERFORM  5600-END-PROCESS
               THRU 5600-END-PROCESS-X.

       3300-CONFIRM-SURR-X.
           EXIT.
      /

      *----------------------
       3400-CONFIRM-FD-SURR.
      *----------------------

           PERFORM  5400-INVOKE-REDO
               THRU 5400-INVOKE-REDO-X.
      *
      *
      * CREATE FUTURE DATED INSTRUCTION
      *
           MOVE MIR-POL-ID                   TO WPORQ-POL-ID.
036742*    PERFORM  0035-5000-TIMESTAMP
036742*        THRU 0035-5000-TIMESTAMP-X.
036742*
036742*    MOVE L0035-TIMESTAMP              TO WPORQ-POL-RQST-CREAT-TS.
036742     MOVE L1692-DV-EFF-DT-R            TO WPORQ-POL-RQST-EFF-DT

           PERFORM  PORQ-1000-CREATE
               THRU PORQ-1000-CREATE-X

036742*    MOVE L1692-DV-EFF-DT-R            TO RPORQ-POL-RQST-EFF-DT
           SET RPORQ-POL-RQST-TYP-TRMN       TO TRUE.
           SET RPORQ-POL-RQST-STAT-PEND      TO TRUE.
           MOVE MIR-BUS-FCN-ID               TO RPORQ-BUS-FCN-ID.
           MOVE WGLOB-USER-ID                TO RPORQ-USER-ID.
           MOVE LENGTH OF MIR-PARM-AREA
                                     TO RPORQ-POL-RQST-MSG-INFO-LENGTH.
           MOVE MIR-PARM-AREA        TO RPORQ-POL-RQST-MSG-INFO-DATA
                                     (1:RPORQ-POL-RQST-MSG-INFO-LENGTH).
           PERFORM  PORQ-1000-WRITE
               THRU PORQ-1000-WRITE-X.

      *MSG: FUTURE DATED WITHDRAWAL REQUEST HAS BEEN SCHEDULED.  VIEW
      *     DETAILS ON FUTURE DATED POLICY ACTIVITY BUSINESS PROCESS.
           MOVE 'CS14660013'             TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           SET  UPDATE-REQUIRED           TO TRUE.

       3400-CONFIRM-FD-SURR-X.
           EXIT.

      *------------------------
       3500-FILL-OUTPUT-FIELDS.
      *------------------------

           IF  L1140-PAYO-MTHD-CHQ
           OR  L1140-PAYO-MTHD-EFT
               MOVE  L1692-DV-NET-DISB-AMT-R TO L0290-INPUT-V02
           ELSE
               MOVE RPOL-POL-OS-DISB-AMT TO L0290-INPUT-V02
           END-IF.

           MOVE 2               TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-NET-DISB-AMT
                                TO L0290-MAX-OUT-LEN
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X
           MOVE L0290-OUTPUT-DATA TO MIR-DV-NET-DISB-AMT

           MOVE L1692-DV-POL-TAX-ACB-AMT-R TO L0290-INPUT-V02
           MOVE 2                 TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-POL-TAX-ACB-AMT
                                  TO L0290-MAX-OUT-LEN
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X
           MOVE L0290-OUTPUT-DATA TO MIR-DV-POL-TAX-ACB-AMT

           MOVE L1692-DV-TAXBL-GRS-DSTRB-AMT-R TO L0290-INPUT-V02
           MOVE 2                 TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-TAXBL-GRS-DSTRB-AMT
                                  TO L0290-MAX-OUT-LEN
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X
           MOVE L0290-OUTPUT-DATA TO MIR-DV-TAXBL-GRS-DSTRB-AMT

           MOVE L1692-DV-GRS-DSTRB-AMT-R
                                  TO L0290-INPUT-V02
           MOVE 2                 TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-GRS-DSTRB-AMT
                                  TO L0290-MAX-OUT-LEN
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X
           MOVE L0290-OUTPUT-DATA TO MIR-DV-GRS-DSTRB-AMT

029060*    MOVE L1692-CDA-FED-TAXWH-AMT-R  TO L0290-INPUT-V02.
029060     MOVE L1692-FTAXWH-AMT-R       TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
029060*                                  TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-AMT TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE  L0290-OUTPUT-DATA       TO MIR-CDA-FED-TAXWH-AMT.
029060     MOVE  L0290-OUTPUT-DATA       TO MIR-FTAXWH-AMT.

029060*    MOVE L1692-CDA-LTAXWH-AMT     TO L0290-INPUT-V02.
029060     MOVE L1692-LTAXWH-AMT-R       TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-CDA-LTAXWH-AMT
029060*                                  TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-LTAXWH-AMT TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE L0290-OUTPUT-DATA        TO MIR-CDA-LTAXWH-AMT.
029060     MOVE L0290-OUTPUT-DATA        TO MIR-LTAXWH-AMT.

       3500-FILL-OUTPUT-FIELDS-X.
           EXIT.

      *------------------
       3600-OVERRIDE-MIR.
      *------------------

           MOVE ZERO             TO L0290-INPUT-V02
           MOVE 2               TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-NET-DISB-AMT
                                TO L0290-MAX-OUT-LEN
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X
           MOVE L0290-OUTPUT-DATA TO MIR-DV-NET-DISB-AMT

           MOVE ZERO              TO L0290-INPUT-V02
           MOVE 2                 TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-POL-TAX-ACB-AMT
                                  TO L0290-MAX-OUT-LEN
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X
           MOVE L0290-OUTPUT-DATA TO MIR-DV-POL-TAX-ACB-AMT

           MOVE ZERO              TO L0290-INPUT-V02
           MOVE 2                 TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-TAXBL-GRS-DSTRB-AMT
                                  TO L0290-MAX-OUT-LEN
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X
           MOVE L0290-OUTPUT-DATA TO MIR-DV-TAXBL-GRS-DSTRB-AMT

           MOVE ZERO              TO L0290-INPUT-V02
           MOVE 2                 TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-GRS-DSTRB-AMT
                                  TO L0290-MAX-OUT-LEN
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X
           MOVE L0290-OUTPUT-DATA TO MIR-DV-GRS-DSTRB-AMT

029060*    IF  MIR-FED-TAXWH-CALC-CD = 'C'
029060*    OR  MIR-FED-TAXWH-CALC-CD = 'B'
029060
029060     IF  MIR-FTAXWH-RQST-CD = 'C'
029060     OR  MIR-FTAXWH-RQST-CD = 'B'
               MOVE ZERO                 TO L0290-INPUT-V02
               MOVE 2                    TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-FED-TAXWH-RQST-AMT
029060*                                  TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-FTAXWH-RQST-AMT
029060                                   TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA    TO MIR-FED-TAXWH-RQST-AMT
029060         MOVE L0290-OUTPUT-DATA    TO MIR-FTAXWH-RQST-AMT

               MOVE ZERO                 TO L0290-INPUT-V02
               MOVE 4                    TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-FED-TAXWH-RQST-PCT
029060*                                  TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-FTAXWH-RQST-PCT
029060                                   TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA    TO MIR-FED-TAXWH-RQST-PCT
029060         MOVE L0290-OUTPUT-DATA    TO MIR-FTAXWH-RQST-PCT
           END-IF

029060*    IF  MIR-LTAXWH-CALC-CD = 'C'
029060*    OR  MIR-LTAXWH-CALC-CD = 'B'
029060
029060     IF  MIR-LTAXWH-RQST-CD = 'C'
029060     OR  MIR-LTAXWH-RQST-CD = 'B'
               MOVE ZERO                 TO L0290-INPUT-V02
               MOVE 2                    TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060*                                  TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
029060                                   TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA    TO MIR-LTAXWH-FLAT-AMT
029060         MOVE L0290-OUTPUT-DATA    TO MIR-LTAXWH-RQST-AMT

               MOVE ZERO                 TO L0290-INPUT-V02
               MOVE 4                    TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-LTAXWH-PCT
029060*                                  TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-LTAXWH-RQST-PCT
029060                                   TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA     TO MIR-LTAXWH-PCT
029060         MOVE L0290-OUTPUT-DATA     TO MIR-LTAXWH-RQST-PCT
           END-IF.

      *MSG: TAX AND DISTRIBUTION AMOUNTS CANNOT BE CALCULATED DUE TO
      *     FUTURE DATING
           MOVE 'CS14660014'             TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3600-OVERRIDE-MIR-X.
           EXIT.

      *-------------------
       4000-REV-SURRENDER.
      *-------------------

           PERFORM  1140-1000-BUILD-PARM-INFO
               THRU 1140-1000-BUILD-PARM-INFO-X.

           IF  MIR-SUPRES-CNFRM-IND = 'Y'
               SET L1140-SUPPRESS-CONFIRM TO TRUE
           END-IF.

           MOVE WS-CVG-NUM-N                TO L1140-CVG-NUM.
           MOVE MIR-DV-SELCT-PAYO-MTHD-CD   TO L1140-PAYO-MTHD-CD.
           MOVE WS-EFF-DATE                 TO L1140-EFF-DT.

           IF PROCESSING-POLICY
               SET L1140-PRCES-LEVEL-POLICY  TO TRUE
           ELSE
               SET L1140-PRCES-LEVEL-CVG     TO TRUE
           END-IF.

           IF  NOT MIR-DV-PRCES-STATE-CD = '3'
               PERFORM  4100-REV-FIRSTPASS-SURR
                   THRU 4100-REV-FIRSTPASS-SURR-X
           ELSE
               PERFORM  4300-REV-CONFIRM-SURR
                   THRU 4300-REV-CONFIRM-SURR-X
           END-IF.

       4000-REV-SURRENDER-X.
           EXIT.
      /
      *------------------------
       4100-REV-FIRSTPASS-SURR.
      *------------------------

           SET L1140-PRCES-TYP-EDIT-ONLY TO TRUE.
           SET L1140-REDO-WARNING        TO TRUE.

           PERFORM  1140-2000-REINST-SURRENDER
               THRU 1140-2000-REINST-SURRENDER-X
           IF L1140-RETRN-OK
               CONTINUE
           ELSE
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 4100-REV-FIRSTPASS-SURR-X
           END-IF.

           IF PROCESSING-POLICY
               MOVE 'CS14660003'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'CS14660004'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  5700-CHECK-UNDO
               THRU 5700-CHECK-UNDO-X.

       4100-REV-FIRSTPASS-SURR-X.
           EXIT.
      /
      *-----------------------
       4300-REV-CONFIRM-SURR.
      *-----------------------

           PERFORM  5000-PROCESS-START
               THRU 5000-PROCESS-START-X.
           IF NOT WGLOB-GOOD-RETURN
           OR WS-REDO-NOT-OK
               GO TO 4300-REV-CONFIRM-SURR-X
           END-IF.

           SET L1140-PRCES-TYP-ALL TO TRUE.
           SET L1140-REDO-WARNING  TO TRUE.
           PERFORM  1140-2000-REINST-SURRENDER
               THRU 1140-2000-REINST-SURRENDER-X.

           IF NOT L1140-RETRN-OK
               SET WGLOB-RETURN-ERROR     TO TRUE
           END-IF.

           PERFORM  5600-END-PROCESS
               THRU 5600-END-PROCESS-X.

       4300-REV-CONFIRM-SURR-X.
           EXIT.
      /
      *-------------------
       5000-PROCESS-START.
      *-------------------

      *  INVOKE REDO PROCESSING

           SET WS-REDO-OK           TO  TRUE.

           IF  NOT WS-BUS-FCN-RSURR
              IF (RPOL-POL-NXT-ACTV-DT > WWKDT-ZERO-DT
              AND RPOL-POL-NXT-ACTV-DT > WGLOB-PROCESS-DATE)
                 CONTINUE
              ELSE
                 PERFORM  5400-INVOKE-REDO
                     THRU 5400-INVOKE-REDO-X
              END-IF
           END-IF.

           IF WS-REDO-NOT-OK
              GO TO 5000-PROCESS-START-X
           END-IF.

           IF  WS-BUS-FCN-TSURR
           AND NOT-DEFERRED-TRANS
               PERFORM  5100-CHECK-FOR-DEFER
                   THRU 5100-CHECK-FOR-DEFER-X
           END-IF.

           IF NOT WGLOB-GOOD-RETURN
              GO TO 5000-PROCESS-START-X
           END-IF.

           IF  NOT WS-BUS-FCN-FSURR
               PERFORM  5500-UNDO-PROCESS
                   THRU 5500-UNDO-PROCESS-X
           END-IF.

           IF NOT WGLOB-GOOD-RETURN
               GO TO 5000-PROCESS-START-X
           END-IF.

           IF DEFERRED-TRANS
              SET UPDATE-REQUIRED     TO TRUE
              GO TO 5000-PROCESS-START-X
           END-IF.

029060     MOVE WS-REVRS-PCHST-SEQ-NUM
029060                                TO WGLOB-REVRS-PCHST-SEQ-NUM.
029060
       5000-PROCESS-START-X.
           EXIT.
      /
      /
      *---------------------
       5100-CHECK-FOR-DEFER.
      *---------------------
      *
      * CHECK FOR UNIT PRICES & DEFER IF NOT FOUND
      *
           PERFORM  0182-1000-BUILD-PARM-INFO
               THRU 0182-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DATE               TO L0182-EFF-DT.
           SET L0182-CALC-RESERVE            TO TRUE.

           IF  NOT WS-BUS-FCN-RSURR
               MOVE 'N' TO L0182-TRMNL-DIV-CALC-IND
               IF PROCESSING-COVERAGE
               AND RPOL-POL-CVG-REC-CTR-N > +1
                   SET L0182-TRMNL-BON-CALC-LVL-CVG TO TRUE
               END-IF
           END-IF.

           IF  NOT WS-BUS-FCN-RSURR
               SET L0182-CALC-IF-TERMINATED TO TRUE
           END-IF.

           PERFORM  0182-1000-CALC-CSV-POL
               THRU 0182-1000-CALC-CSV-POL-X.

           IF      L0182-RETRN-OK
           AND NOT L0182-FNDVL-CALC-APROX
               CONTINUE
           ELSE
               IF  L0182-RETRN-OK
               AND L0182-FNDVL-CALC-APROX
                   PERFORM  5110-GENERATE-DEFERRED-TERM
                       THRU 5110-GENERATE-DEFERRED-TERM-X
      * MSG: TERMINATION HAS BEEN DEFERRED
                   MOVE 'CS14660006' TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
               SET DEFERRED-TRANS        TO TRUE
           END-IF.

       5100-CHECK-FOR-DEFER-X.
           EXIT.
      /

      *---------------------------
       5110-GENERATE-DEFERRED-TERM.
      *---------------------------

           PERFORM  8170-1000-BUILD-PARM-INFO
               THRU 8170-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DATE            TO L8170-EFF-DT.
           MOVE MIR-SUPRES-CNFRM-IND   TO L8170-SUPR-CONF-IND.
           MOVE MIR-SURR-TAX-OVRID-CD  TO L8170-SURR-TAX-OVRID-CD.
           MOVE L1692-CVG-NUM-N        TO L8170-CVG-NUM.
           MOVE MIR-CLI-ID             TO L8170-CLI-ID.
           MOVE MIR-CLI-BNK-ACCT-NUM   TO L8170-CLI-BNK-ACCT-NUM.
029060*    MOVE MIR-LTAXWH-CALC-CD     TO L8170-LTAXWH-CALC-CD.

           EVALUATE TRUE

               WHEN L1140-PAYO-MTHD-CHQ
                   SET L8170-CDI-PAYO-CHQ TO TRUE

               WHEN L1140-PAYO-MTHD-EFT
                   SET L8170-CDI-PAYO-EFT TO TRUE

               WHEN OTHER
                   SET L8170-CDI-PAYO-OS-DISB TO TRUE

           END-EVALUATE.

           INITIALIZE LFUND-FND-INFO (1).
           MOVE +1                       TO LFUND-FND-CTR.
           MOVE -100.00                  TO LFUND-ALLOC-PCT (1).
           SET LFUND-ALLOC-PERCENT (1)  TO TRUE.

           SET LFUND-ACTV-SURRENDER-TERM   TO TRUE.

           PERFORM  8170-2000-DEFER-TRANSACTION
               THRU 8170-2000-DEFER-TRANSACTION-X.

           IF NOT L8170-RETRN-OK
               SET WGLOB-RETURN-ERROR        TO TRUE
           ELSE
      *MSG: TRANSACTION HAS BEEN DEFERRED
               MOVE 'CS00000260'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5110-GENERATE-DEFERRED-TERM-X.
           EXIT.
      /

      *-----------------
       5400-INVOKE-REDO.
      *-----------------

           IF  NOT RPOL-POL-STAT-IN-FORCE
               GO TO 5400-INVOKE-REDO-X
           END-IF.

      * REDO TO CURRENT DATE FOR A FUTURED DATE TRANSACATION
      *
           IF  WS-BUS-FCN-FSURR
               MOVE WGLOB-PROCESS-DATE  TO WS-EFF-DATE
           END-IF.

           PERFORM  4780-1000-BUILD-PARM-INFO
               THRU 4780-1000-BUILD-PARM-INFO-X.
           SET L4780-REDO-WARNING             TO TRUE.
           SET L4780-MSG-SUPPRESS             TO TRUE.
           MOVE WS-EFF-DATE                TO L4780-EFF-DT.
           MOVE RPOL-PREV-BTCH-PRCES-DT TO L4780-LAST-PROCESS-DATE.
           SET L4780-PRCES-INCLUSIVE          TO TRUE.

           PERFORM  4780-1000-GET-NEXT-ACT-DT
               THRU 4780-1000-GET-NEXT-ACT-DT-X.

           EVALUATE  TRUE
               WHEN L4780-RETRN-ERROR
               WHEN L4780-RETRN-INVALID-REQUEST
                    SET WS-REDO-NOT-OK           TO TRUE
                    PERFORM  POL-3000-UNLOCK
                        THRU POL-3000-UNLOCK-X
                   SET POLICY-NOT-LOCKED         TO TRUE
               WHEN  (L4780-RETRN-OK
               AND L4780-ACTIVITY-DUE
               AND L4780-REDO-ALLOW)
                   PERFORM  POL-3000-UNLOCK
                       THRU POL-3000-UNLOCK-X
                   MOVE WS-EFF-DATE      TO L0201-EFF-DT
                   SET L0201-AUTO-REDO      TO TRUE
                   PERFORM  0201-1000-AUTO-PROCESSING
                       THRU 0201-1000-AUTO-PROCESSING-X
                   PERFORM  0289-1000-INIT-PARM-INFO
                       THRU 0289-1000-INIT-PARM-INFO-X
                   MOVE WS-EFF-DATE  TO L0289-LO-PAC-DT
                   MOVE WS-EFF-DATE  TO L0289-LO-CRC-DT
                   MOVE WS-EFF-DATE  TO L0289-LO-DD2-DT
                   MOVE WS-EFF-DATE  TO L0289-PROC-EFF-DT
                   PERFORM  0289-1000-OBTAIN-NXT-ACTV
                       THRU 0289-1000-OBTAIN-NXT-ACTV-X
                   IF  L0289-RETRN-OK
                       MOVE L0289-NXT-ACTV-TYP-CD
                            TO RPOL-NXT-ACTV-TYP-CD
                       MOVE L0289-NXT-ACTV-DT
                            TO RPOL-POL-NXT-ACTV-DT
                   ELSE
                       MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
                       MOVE WGLOB-PROCESS-DATE
                                 TO RPOL-POL-NXT-ACTV-DT
                   END-IF
                   MOVE RPOL-REC-INFO             TO HPOL-REC-INFO
                   PERFORM  POL-1000-READ-FOR-UPDATE
                       THRU POL-1000-READ-FOR-UPDATE-X
                   MOVE HPOL-REC-INFO             TO RPOL-REC-INFO
                   MOVE WGLOB-PROCESS-DATE TO RPOL-PREV-FILE-MAINT-DT
                   PERFORM  POL-2000-REWRITE
                       THRU POL-2000-REWRITE-X
                   SET POLICY-NOT-LOCKED            TO TRUE
                   PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
                       THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
                   IF  L0201-RETRN-OK
                       PERFORM  POL-1000-READ-FOR-UPDATE
                           THRU POL-1000-READ-FOR-UPDATE-X
                       SET POLICY-LOCKED            TO TRUE
                       MOVE 'XS00000307'     TO  WGLOB-MSG-REF-INFO
      *MSG: 'AUTO REDO PROCESSING COMPLETED
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                   ELSE
                       SET WS-REDO-NOT-OK           TO TRUE
                       IF  NOT L0201-INCOMPLETE-DUE-ACTV
                           MOVE 'XS00000308' TO WGLOB-MSG-REF-INFO
      *MSG: PROBLEM IN AUTO REDO PROCESSING
                           PERFORM  0260-1000-GENERATE-MESSAGE
                               THRU 0260-1000-GENERATE-MESSAGE-X
                       END-IF
                   END-IF
           END-EVALUATE.

       5400-INVOKE-REDO-X.
           EXIT.

      *------------------
       5500-UNDO-PROCESS.
      *------------------

      *  UNLOCK POLICY RECORD (THIS ALLOWS FOR POLICY UPDATES
      *  IN CSLS0065 WHICH CAN BE CALLED FROM CSLS4700).
      *
           PERFORM  POL-3000-UNLOCK
               THRU POL-3000-UNLOCK-X.
           SET POLICY-NOT-LOCKED             TO TRUE.

           PERFORM  5510-BUILD-4750-INFO
               THRU 5510-BUILD-4750-INFO-X.

           PERFORM  4750-1000-UNDO-PROCESSING
               THRU 4750-1000-UNDO-PROCESSING-X.

           IF  NOT L4750-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           IF  WGLOB-RETURN-ERROR
           AND L4750-POL-UPDATE-NOT-REQD
               GO TO 5500-UNDO-PROCESS-X
           END-IF.

      *    LOCK POLICY AGAIN IN ORDER TO DO UPDATES
      *    SAVE POLICY INFO TO RESTORE AFTER READ FOR UPDATE

           MOVE  RPOL-REC-INFO        TO  HPOL-REC-INFO.
           MOVE  RPOL-KEY             TO  WPOL-KEY.

           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.
           SET POLICY-LOCKED              TO TRUE.

           MOVE HPOL-REC-INFO         TO  RPOL-REC-INFO.

           IF  L4750-POL-UPDATE-REQD
               PERFORM  POL-2000-REWRITE
                   THRU POL-2000-REWRITE-X
               PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
                   THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
               SET POLICY-NOT-LOCKED          TO TRUE

               IF  NOT WGLOB-RETURN-ERROR
                   MOVE RPOL-KEY      TO WPOL-KEY
                   PERFORM  POL-1000-READ-FOR-UPDATE
                       THRU POL-1000-READ-FOR-UPDATE-X
                   SET POLICY-LOCKED              TO TRUE
               END-IF
           END-IF.

       5500-UNDO-PROCESS-X.
           EXIT.

      *---------------------
       5510-BUILD-4750-INFO.
      *---------------------

           PERFORM  4750-1000-BUILD-PARM-INFO
               THRU 4750-1000-BUILD-PARM-INFO-X.

           SET L4750-FCN-DRVR-SECONDARY      TO TRUE.
           MOVE WS-EFF-DATE    TO L4750-EFF-DT

           MOVE MIR-DV-SELCT-PAYO-MTHD-CD    TO L4750-PAYO-MTHD-CD.

           SET L4750-PRCES-EXCLUSIVE     TO TRUE.

           SET L4750-TCNTRCT-PREM-REVRS-TRMN TO TRUE.

           IF  WS-BUS-FCN-RSURR
               IF  PROCESSING-POLICY
               OR  L4750-TCNTRCT-PREM-REVRS-TRMN
                   SET L4750-TCNTRCT-PREM-REVRS-BPSS TO TRUE
               END-IF
           END-IF.

           IF  PROCESSING-POLICY
           AND L1140-PAYO-MTHD-NOT-REQ
               SET L4750-TCNTRCT-PREM-DEST-DISB TO TRUE
           END-IF.

           IF  MIR-SUPRES-CNFRM-IND = 'Y'
               SET L4750-SUPPRESS-CONFIRM TO TRUE
           END-IF.

       5510-BUILD-4750-INFO-X.
           EXIT.
      /

      *-----------------
       5600-END-PROCESS.
      *-----------------

           IF  WGLOB-GOOD-RETURN
           AND PROCESSING-COVERAGE

      *MSG: POLICY ALLOCATIONS FOR THIS COVERAGE SHOULD BE CHECKED.
               MOVE 'CS14660009'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           SET UPDATE-REQUIRED               TO TRUE.

       5600-END-PROCESS-X.
           EXIT.

      *---------------------
       5700-CHECK-UNDO.
      *---------------------

           IF PROCESSING-COVERAGE
               MOVE MIR-CVG-NUM       TO DISPLAY-SUB
               MOVE DISPLAY-SUB       TO WGLOB-MSG-PARM (1)
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           MOVE 'CS14660008'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

      *
      * WARN IF ACTIVITIES WILL BE REVERSED
      *
           PERFORM  5510-BUILD-4750-INFO
               THRU 5510-BUILD-4750-INFO-X.

           PERFORM  4750-2000-DTRMN-UNDO-PRCES
               THRU 4750-2000-DTRMN-UNDO-PRCES-X.

           IF  NOT L4750-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

       5700-CHECK-UNDO-X.
           EXIT.

      /
      *--------------------------
       9400-SETUP-MSIN-REFERENCE.
      *--------------------------

            MOVE SPACES               TO WGLOB-MSIN-REFERENCE.
            MOVE WGLOB-COMPANY-CODE   TO WGLOB-REF-COMPANY-CODE.
            MOVE 'P'                  TO WGLOB-REF-POLICY-OR-CLIENT.
            MOVE MIR-POL-ID-BASE      TO WGLOB-REF-POLICY-NUMBER.
            MOVE MIR-POL-ID-SFX       TO WGLOB-REF-POLICY-SUFFIX.
            MOVE MIR-CVG-NUM          TO WGLOB-REF-COVERAGE-NUMBER.

       9400-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0182-0000-INIT-PARM-INFO
               THRU 0182-0000-INIT-PARM-INFO-X.

           PERFORM  0201-0000-INIT-PARM-INFO
               THRU 0201-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0289-0000-INIT-PARM-INFO
               THRU 0289-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  0620-0000-INIT-PARM-INFO
               THRU 0620-0000-INIT-PARM-INFO-X.

           PERFORM  1140-0000-INIT-PARM-INFO
               THRU 1140-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

           PERFORM  1692-0000-INIT-PARM-INFO
               THRU 1692-0000-INIT-PARM-INFO-X.

032623     PERFORM  1660-0000-INIT-PARM-INFO
032623         THRU 1660-0000-INIT-PARM-INFO-X.
032623
032623     PERFORM  2408-0000-INIT-PARM-INFO
032623         THRU 2408-0000-INIT-PARM-INFO-X.
032623
           PERFORM  2430-0000-INIT-PARM-INFO
               THRU 2430-0000-INIT-PARM-INFO-X.

           PERFORM  2626-0000-INIT-PARM-INFO
               THRU 2626-0000-INIT-PARM-INFO-X.

           PERFORM  4750-0000-INIT-PARM-INFO
               THRU 4750-0000-INIT-PARM-INFO-X.

           PERFORM  4780-0000-INIT-PARM-INFO
               THRU 4780-0000-INIT-PARM-INFO-X.

           PERFORM  5400-0000-INIT-PARM-INFO
               THRU 5400-0000-INIT-PARM-INFO-X.

           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           PERFORM  8170-0000-INIT-PARM-INFO
               THRU 8170-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-PGM-WORK-AREA.
           INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
           INITIALIZE WLOCK-TWRK-OTHER-INFO.
           MOVE SPACES                TO WWKDT-WORK-FIELDS.
           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
           SET  MIR-RETRN-OK          TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *************************
      * PROCESSING COPYBOOKS
      *************************

       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY CCPPPLIN.
       COPY CCPPFPCK.
       COPY NCPPCVGS.
       COPY NCPPCVGR.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      ************************
      * LINKAGE COPYBOOKS
      ************************
       COPY XCPS8090.
       COPY CCPSPGA.
      /
       COPY CCPL0182.
       COPY CCPS0182.
      /
       COPY CCPS0620.
       COPY CCPL0620.

       COPY CCPS0201.
       COPY CCPL0201.

       COPY CCPS0289.
       COPY CCPL0289.

       COPY CCPL1140.
       COPY CCPS1140.
       COPY CCPL1692.
       COPY CCPS1692.
      /
032623 COPY CCPL2408.
032623 COPY CCPS2408.
032623/
       COPY CCPL2430.
       COPY CCPS2430.
       COPY CCPS2626.
       COPY CCPL2626.
      /
       COPY CCPS4750.
       COPY CCPL4750.
      /
       COPY CCPS4780.
       COPY CCPL4780.
      /
       COPY CCPS5400.
       COPY CCPL5400.
      /
       COPY FCPS8170.
       COPY FCPL8170.
      /
036742*COPY XCPL0035.
       COPY XCPL0260.
       COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL0290.
       COPY XCPS0290.
       COPY XCPS1640.
       COPY XCPL1640.
       COPY XCPL8090.
029060/
029060 COPY XCPL1660.
029060 COPY XCPS1660.

      ****************************
      * FILE I/O PROCESS MODULES
      ****************************
       COPY CCPNCVG.
       COPY CCPUCVG.
      /
       COPY CCPNPH.
029060 COPY CCPBPHST.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.

       COPY CCPAPORQ.
       COPY CCPCPORQ.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY XCCPERR.
       COPY XCCP0030.
      *
      *****************************************************************
      **                 END OF PROGRAM CSOM1466                     **
      *****************************************************************
