      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM0350.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM0350                                         **
      **  REMARKS:  HWTB: MAINTAIN HEIGHT/WEIGHT TABLE.              **
      **            THIS MODULE PERFORMS THE TABLE MAINTENANCE       **
      **            FUNCTIONS FOR THE HEIGHT/WEIGHT TABLE.           **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP                                     **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
558067**  5.5       MOVE LINE UP (CONTINUATION ERROR)                **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
006002**  6.0       INCREASE THE DESCRIPTION FIELD SIZE              **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017628**  6.2       SCALE CODE VALUE RETURNS INSTEAD OF DESCRIPTION  **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
019169**  6.7       HEIGHT/WEIGTH SCALE CONVERSION                   **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

558067*COPY XCWWPGWS REPLACING '$VAR1'
558067*                     BY 'NSOM0350'.
558067 COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0350'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.


       01  WS-PGM-WORK-AREA.
025970*    05  WS-AGE-IND                   PIC X(01)  VALUE 'U'.
025970     05  WS-AGE-IND                   PIC X(01).
025970         88  WS-DEFAULT-AGE-IND                  VALUE 'U'.
               88  WS-UNDETERMINED-AGE                 VALUE 'U'.
               88  WS-ADULT                            VALUE 'A'.
               88  WS-CHILD                            VALUE 'C'.
025970*    05  WS-KEY-MATCH                 PIC X(01)  VALUE 'Y'.
025970     05  WS-KEY-MATCH                 PIC X(01).
025970         88  WS-DEFAULT-KEY-MATCH                VALUE 'Y'.
               88  WS-INVALID-KEY-MATCH                VALUE 'N'.
           05  WS-DATA-EDITS                PIC X(01)  VALUE SPACES.
               88  WS-DATA-EDITS-OK                    VALUE 'Y'.
           05  WS-CROSS-EDITS               PIC X(01)  VALUE SPACES.
               88  WS-CROSS-EDITS-OK                   VALUE 'Y'.
           05  WS-VALIDATE-CONTROL          PIC X(01)  VALUE SPACES.
               88  WS-INVALID-CONTROL                  VALUE 'Y'.
           05  WS-SEX-ENTRY                 PIC X(01)  VALUE SPACES.
               88  WS-SEX-ENTERED                      VALUE 'Y'.
           05  WS-AGE-ENTRY                 PIC X(01)  VALUE SPACES.
               88  WS-AGE-ENTERED                      VALUE 'Y'.
           05  WS-HEIGHT-ENTRY              PIC X(01)  VALUE SPACES.
               88  WS-HEIGHT-ENTERED                   VALUE 'Y'.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-ID-VALID      VALUE
                   '0350' '0351' '0352' '0353' '0354'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '0350'.
               88  WS-BUS-FCN-CREATE        VALUE '0351'.
               88  WS-BUS-FCN-UPDATE        VALUE '0352'.
               88  WS-BUS-FCN-DELETE        VALUE '0353'.
               88  WS-BUS-FCN-LIST          VALUE '0354'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '0350'.
           05  WS-NUM-999                   PIC 9(03)  VALUE ZEROS.
           05  WS-NUM-999-X                 PIC 9(03)  VALUE ZEROS.
           05  WS-SAVE-SEX                  PIC X      VALUE SPACES.
               88  WS-VALID-SEX             VALUE 'M' 'F'.
025970*    05  WS-LINE                      PIC S9(03) COMP-3
025970*                                     VALUE +1.
025970     05  WS-LINE                      PIC S9(03) COMP-3.
025970         88  WS-DEFAULT-LINE          VALUE +1.
025970*    05  WS-NUMBER-OF-DISPLAY-LINES   PIC S9(03) COMP-3
025970*                                     VALUE +11.
           05  WS-TEST-RANGE                PIC S9(18) COMP-3.
               88  WS-AGE-OK                VALUE +0 THRU +120.
               88  WS-METRIC-HGT-OK         VALUE +1  THRU +303.
               88  WS-IMPERIAL-HGT-OK       VALUE +1  THRU +119.
               88  WS-METRIC-WGT-OK         VALUE +1 THRU +453.
               88  WS-RATE-OK               VALUE +90 THRU +400.
           05  WS-LOGICAL-EOF-SW            PIC X(01)  VALUE SPACES.
               88  WS-LOGICAL-EOF                      VALUE 'Y'.
           05  WS-HOLD-ENDBR-KEY            PIC X(12)  VALUE SPACES.
           05  WS-TEMP                      PIC S9(03) COMP-3.
006002*    05  WS-SCALE-TXT                 PIC X(40)  VALUE SPACES.
017628*    05  WS-SCALE-TXT                 PIC X(80)  VALUE SPACES.
           05  WS-SCALE-CODE                PIC X(01)  VALUE SPACES.
               88  WS-SCALE-IMPERIAL        VALUE 'I'.
               88  WS-SCALE-METRIC          VALUE 'M'.
           05  WS-POUND                     PIC 9(03)  VALUE ZEROS.
           05  WS-KILO                      PIC 9(03)  VALUE ZEROS.
           05  WS-HEIGHT                    PIC 9(03)  VALUE ZEROS.
           05  WS-FEET                      PIC 9(01)  VALUE ZEROS.
           05  WS-INCH                      PIC 9(02)  VALUE ZEROS.
           05  WS-CENT                      PIC 9(03)  VALUE ZEROS.
           05  WS-WEIGHT                    PIC 9(03)  VALUE ZEROS.
016548*    05  WS-SUB                       PIC S9(04) COMP
016548     05  WS-SUB                       PIC S9(04) BINARY
                                                       VALUE ZEROS.
025970*    05  WS-MAX-BROWSE-LINES          PIC S9(03) COMP-3
025970*                                     VALUE +11.
025970/
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                VALUE '0350'.
025970     05  WS-NUMBER-OF-DISPLAY-LINES   PIC S9(03) COMP-3.
025970         88  WS-DEFAULT-NO-DISPLAY-LINES        VALUE +11.
025970     05  WS-MAX-BROWSE-LINES          PIC S9(03) COMP-3.
025970         88  WS-DEFAULT-MAX-BROWSE-LINE         VALUE +11.

016537*COPY XCWWWKDT.
       COPY XCWEBLCH.
      /
016537*COPY CCWZPCOM.
014221 COPY CCWWLOCK.
       COPY NCWL0520.
       COPY NCWL0530.
      /

       COPY NCFWHWTB.
       COPY NCFRHWTB.
      /
       COPY CCFWPCOM.
       COPY CCFRPCOM.
      /
021930*COPY CCFWEDIT.
021930*COPY CCFREDIT.
021930*
       COPY XCWL0280.
014221 COPY XCWL8090.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0350.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.


      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.
      *
026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *****************************************************************
      *  PERFORM SECURITY PROCESSING AND INVOKE MODULES TO
      *      PROCESS USER REQUEST
      *****************************************************************
      **********************
       2000-PROCESS-REQUEST.
      **********************

025970*    SET  MIR-RETRN-OK          TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           PERFORM  PCOM-1000-READ
               THRU PCOM-1000-READ-X.

017628*    IF WPCOM-IO-OK
017628*        MOVE RPCOM-CO-HWTB-SCALE-CD
017628*                               TO WS-SCALE-CODE
017628*        MOVE WS-SCALE-CODE     TO WEDIT-ETBL-VALU-ID
017628*        PERFORM  SCAL-2000-DESC
017628*            THRU SCAL-2000-DESC-X
017628*        IF WEDIT-IO-OK
017628*            MOVE REDIT-ETBL-DESC-TXT
017628*                               TO WS-SCALE-TXT
017628*        ELSE
017628*            MOVE SPACES        TO WS-SCALE-TXT
017628*        END-IF
017628*    END-IF.
017628*    MOVE WS-SCALE-TXT          TO MIR-CO-HWTB-SCALE-CD.
017628     MOVE RPCOM-CO-HWTB-SCALE-CD
017628                                TO MIR-CO-HWTB-SCALE-CD.
019169     MOVE RPCOM-CO-HWTB-SCALE-CD TO WS-SCALE-CODE.

      ***  NUMERIC KEY FIELDS MUST BE ENTERED CORRECTLY FOR THE
      ***  REMAINING FUNCTIONS EXCEPT CREATE FUNCTION.

           IF  NOT WS-BUS-FCN-CREATE
               PERFORM 7200-CHECK-NUMERIC-KEYS
                  THRU 7200-CHECK-NUMERIC-KEYS-X
               IF WS-INVALID-CONTROL
                  GO TO 2000-PROCESS-REQUEST-X
557660         END-IF
           END-IF.
      *
      *    PROCESS SCREEN FUNCTIONS
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM  3500-PROCESS-LIST
                        THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  4000-PROCESS-CREATE
                        THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  6000-PROCESS-DELETE
                        THRU 6000-PROCESS-DELETE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID  TO WGLOB-MSG-PARM (1)
                    MOVE 'NSOM0350'      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *****************************************************************
      *  INQUIRY PROCESSING: SETUP INQUIRE KEYS AND LOAD DATA
      *  THIS FUNCTION REWRITTEN FOR 5.3
      *****************************************************************
       3000-PROCESS-RETRIEVE.
      *
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
      *
      ***  FOR AN INQUIRE, SPACES IN A NUMERIC KEY ARE CHANGED TO ZEROS.
           IF MIR-RAT-STD-AGE = SPACES
               MOVE ZEROS             TO WS-NUM-999
               MOVE WS-NUM-999        TO MIR-RAT-STD-AGE
557660     END-IF.
           IF MIR-RAT-STD-HT-QTY = SPACES
               MOVE ZEROS             TO WS-NUM-999
               MOVE WS-NUM-999        TO MIR-RAT-STD-HT-QTY
557660     END-IF.
      *
      ***  VALIDATE SEX, AGE OR HEIGHT IF THEY CONTAIN VALUES.
           IF MIR-RAT-STD-SEX-CD NOT = SPACES
               MOVE 'Y'               TO WS-SEX-ENTRY
               IF MIR-RAT-STD-AGE NOT = ZEROS
                   MOVE 'Y'           TO WS-AGE-ENTRY
                   IF MIR-RAT-STD-HT-QTY NOT = ZEROS
                       MOVE 'Y'       TO WS-HEIGHT-ENTRY
557660             END-IF
557660         END-IF
557660     END-IF.
      *
      ***  SETUP INQUIRE KEY LIMITS
           PERFORM  7100-BUILD-HWTB-KEY
               THRU 7100-BUILD-HWTB-KEY-X.
      *
      ***  POSITION AT AND READ RECORD.
014221*    PERFORM  HWTB-1000-READ
014221*        THRU HWTB-1000-READ-X.

014221     PERFORM  HWTB-1000-READ-TWRK-TS
014221         THRU HWTB-1000-READ-TWRK-TS-X.

      *
      ***  LOAD SCREEN DATA.
           MOVE +1                    TO WS-LINE.
           IF WHWTB-IO-OK
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
      *MSG: '(I)  "INQUIRE COMPLETE, CONTINUE"'
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
               MOVE WHWTB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU  0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'NS03500001'      TO WGLOB-MSG-REF-INFO
               MOVE WHWTB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU  0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *****************************************************************
      *  BROWSE PROCESSING: STANDARD BROWSE ADDED FOR 5.3
      *****************************************************************
      *******************
       3500-PROCESS-LIST.
      *******************
      *
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
      *
      *
      ***  FOR AN INQUIRE, SPACES IN A NUMERIC KEY ARE CHANGED TO ZEROS.
           IF MIR-RAT-STD-AGE = SPACES
               MOVE ZEROS             TO WS-NUM-999
               MOVE WS-NUM-999        TO MIR-RAT-STD-AGE
557660     END-IF.
           IF MIR-RAT-STD-HT-QTY = SPACES
               MOVE ZEROS             TO WS-NUM-999
               MOVE WS-NUM-999        TO MIR-RAT-STD-HT-QTY
557660     END-IF.
      *
      ***  VALIDATE SEX, AGE OR HEIGHT IF THEY CONTAIN VALUES.
           IF MIR-RAT-STD-SEX-CD NOT = SPACES
               MOVE 'Y'               TO WS-SEX-ENTRY
               IF MIR-RAT-STD-AGE NOT = ZEROS
                   MOVE 'Y'           TO WS-AGE-ENTRY
                   IF MIR-RAT-STD-HT-QTY NOT = ZEROS
                       MOVE 'Y'       TO WS-HEIGHT-ENTRY
557660             END-IF
557660         END-IF
557660     END-IF.
      *
      ***  SETUP BROWSE KEY LIMITS
           PERFORM  7100-BUILD-HWTB-KEY
               THRU 7100-BUILD-HWTB-KEY-X.
           MOVE HIGH-VALUES           TO WHWTB-ENDBR-KEY.
      *
      ***  POSITION AT AND READ FIRST RECORD.
           PERFORM  HWTB-1000-BROWSE
               THRU HWTB-1000-BROWSE-X.
           IF  NOT WHWTB-IO-OK
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO  3500-PROCESS-LIST-X
557660     END-IF.

           PERFORM  HWTB-2000-READ-NEXT
               THRU HWTB-2000-READ-NEXT-X.

           IF  WHWTB-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  HWTB-3000-END-BROWSE
                   THRU HWTB-3000-END-BROWSE-X
               GO TO  3500-PROCESS-LIST-X
557660     END-IF.
      *
           MOVE +1                    TO WS-LINE.
           PERFORM  3510-PROCESS-BROWSE-READ
               THRU 3510-PROCESS-BROWSE-READ-X
               VARYING WS-SUB FROM 1 BY 1
                 UNTIL WS-SUB > WS-MAX-BROWSE-LINES
                 OR WHWTB-IO-EOF.
      *
           IF  WHWTB-IO-EOF
               MOVE MIR-RAT-STD-SEX-CD-T (1)
                                      TO MIR-RAT-STD-SEX-CD
               MOVE MIR-RAT-STD-AGE-T   (1)
                                      TO MIR-RAT-STD-AGE
               MOVE MIR-RAT-STD-HT-QTY-T (1)
                                      TO MIR-RAT-STD-HT-QTY
               MOVE MIR-RAT-STD-WGT-QTY-T (1)
                                      TO MIR-RAT-STD-WGT-QTY
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
           ELSE
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
      ***  END THE BROWSE.
           PERFORM  HWTB-3000-END-BROWSE
               THRU HWTB-3000-END-BROWSE-X.
      *
       3500-PROCESS-LIST-X.
           EXIT.
      /
      *****************************************************************
      *  BROWSE  DISPLAY PROCESSING: DISPLAY THE CURRENT RECORD ONTO
      *  THE SCREEN DATA LINE GIVEN BY WS-LINE AND RETRIEVE THE NEXT
      *  RECORD.
      *****************************************************************
      ****************************
       3510-PROCESS-BROWSE-READ.
      ****************************

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.


           PERFORM  HWTB-2000-READ-NEXT
               THRU HWTB-2000-READ-NEXT-X.

           IF WHWTB-IO-OK
               IF WS-SUB = WS-MAX-BROWSE-LINES
                   MOVE RHWTB-RAT-STD-SEX-CD
                                      TO MIR-RAT-STD-SEX-CD
                   MOVE RHWTB-RAT-STD-AGE
                                      TO MIR-RAT-STD-AGE
                   MOVE RHWTB-RAT-STD-HT-QTY
                                      TO MIR-RAT-STD-HT-QTY
                   MOVE RHWTB-RAT-STD-WGT-QTY
                                      TO MIR-RAT-STD-WGT-QTY
557660         END-IF
557660     END-IF.

       3510-PROCESS-BROWSE-READ-X.
           EXIT.
      /
      *****************************************************************
      *  CREATE PROCESSING: TWO PASSES REQUIRED
      *      CHECK FOR RECORD.  IF NOT FOUND CREATE RECORD AND
      *      ALLOW USER TO MODIFY UNDER MAINTAIN PROCESSING
      *****************************************************************
       4000-PROCESS-CREATE.
      *
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
      *
      ***  VALID CONTROL FIELDS MUST HAVE BEEN ENTERED.
           PERFORM  7000-VALIDATE-CTL-FIELDS
               THRU 7000-VALIDATE-CTL-FIELDS-X.
           IF  WS-INVALID-CONTROL
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.
      *
      ***  BUILD CONTROL FIELDS.
           PERFORM  7100-BUILD-HWTB-KEY
               THRU 7100-BUILD-HWTB-KEY-X.
      *
      ***  CHECK RECORD EXISTENCE.
           PERFORM  HWTB-1000-READ
               THRU HWTB-1000-READ-X.
           IF WHWTB-IO-OK
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               MOVE WHWTB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.
      *
      ***  CREATE NEW RECORD.
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
           PERFORM  HWTB-1000-CREATE
               THRU HWTB-1000-CREATE-X.
           PERFORM  HWTB-1000-WRITE
               THRU HWTB-1000-WRITE-X.
014221     PERFORM  HWTB-1000-READ-TWRK-TS
014221         THRU HWTB-1000-READ-TWRK-TS-X.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *****************************************************************
      *  MAINTAIN PROCESSING:
      *       GET RECORD, EDIT DATA FIELDS AND UPDATE RECORD.
      *       FIELDS WITH ERRORS ARE NOT UPDATED.
      *****************************************************************
       5000-PROCESS-UPDATE.
      *
           PERFORM  7100-BUILD-HWTB-KEY
               THRU 7100-BUILD-HWTB-KEY-X.

014221*    PERFORM  HWTB-1000-READ-FOR-UPDATE
014221*        THRU HWTB-1000-READ-FOR-UPDATE-X.

014221     PERFORM  HWTB-2000-UPDATE-TWRK-TS
014221         THRU HWTB-2000-UPDATE-TWRK-TS-X.
      *
           IF WHWTB-IO-NOT-FOUND
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WHWTB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'HWTB'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WHWTB-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

      *
           PERFORM  7500-EDIT-DATA-FIELDS
               THRU 7500-EDIT-DATA-FIELDS-X.
      *
           PERFORM  7600-CROSS-EDITS
               THRU 7600-CROSS-EDITS-X.
      *
           PERFORM  HWTB-2000-REWRITE
               THRU HWTB-2000-REWRITE-X.

014221     PERFORM  HWTB-1000-READ-TWRK-TS
014221         THRU HWTB-1000-READ-TWRK-TS-X.
      *
      ***  RESET COMMAND CODE TO INQUIRE WHEN MAINTAIN IS COMPLETE.
           IF WS-DATA-EDITS-OK
557660     AND WS-CROSS-EDITS-OK
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           ELSE
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               IF WS-DATA-EDITS-OK
                   PERFORM  9200-MOVE-RECORD-TO-SCREEN
                       THRU 9200-MOVE-RECORD-TO-SCREEN-X
               ELSE
                   PERFORM  9205-SCREEN-CONVERSIONS
                       THRU 9205-SCREEN-CONVERSIONS-X
                   MOVE WS-CENT       TO MIR-DV-RAT-STD-CM-HT
                   MOVE WS-INCH       TO MIR-DV-RAT-STD-INCH-HT
                   MOVE WS-FEET       TO MIR-DV-RAT-STD-FT-HT
                   MOVE WS-POUND      TO MIR-DV-RAT-STD-LB-WGT
                   MOVE WS-KILO       TO MIR-DV-RAT-STD-KG-WGT
557660         END-IF
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *****************************************************************
      *  DELETE PROCESSING:
      *      REMOVE RECORD
      *****************************************************************
       6000-PROCESS-DELETE.
      *
           PERFORM  7100-BUILD-HWTB-KEY
               THRU 7100-BUILD-HWTB-KEY-X.

014221*    PERFORM  HWTB-1000-READ-FOR-UPDATE
014221*        THRU HWTB-1000-READ-FOR-UPDATE-X.

014221     PERFORM  HWTB-2000-UPDATE-TWRK-TS
014221         THRU HWTB-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'HWTB'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WHWTB-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

      *
           IF WHWTB-IO-NOT-FOUND
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WHWTB-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           ELSE
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  HWTB-1000-DELETE
                   THRU HWTB-1000-DELETE-X
557660     END-IF.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
       6000-PROCESS-DELETE-X.
           EXIT.
      *
      *****************************************************************
      *  EDIT ADMIN SYSTEM FIELD AGAINST ETAB
      *****************************************************************
       7000-VALIDATE-CTL-FIELDS.
      *
           MOVE 'N'                   TO WS-VALIDATE-CONTROL.
      *
      ***  VALIDATE CONTROL FIELDS.
           PERFORM 7020-EDIT-AGE-FIELD
              THRU 7020-EDIT-AGE-FIELD-X.
           IF L0280-OK
               PERFORM 7025-VALIDATE-AGE-FIELD
                  THRU 7025-VALIDATE-AGE-FIELD-X
557660     END-IF.

           IF WS-CHILD
               PERFORM 7010-VALIDATE-SEX-FIELD
                  THRU 7010-VALIDATE-SEX-FIELD-X
557660     END-IF.

           PERFORM 7030-EDIT-HEIGHT-FIELD
              THRU 7030-EDIT-HEIGHT-FIELD-X.
           IF L0280-OK
               PERFORM 7035-VALIDATE-HEIGHT-FIELD
                  THRU 7035-VALIDATE-HEIGHT-FIELD-X
557660     END-IF.

           PERFORM 7040-EDIT-WEIGHT-FIELD
              THRU 7040-EDIT-WEIGHT-FIELD-X.
           IF L0280-OK
               PERFORM 7045-VALIDATE-WEIGHT-FIELD
                  THRU 7045-VALIDATE-WEIGHT-FIELD-X
557660     END-IF.
      *
       7000-VALIDATE-CTL-FIELDS-X.
           EXIT.
      *
      /
      *****************************************************************
      *  EDIT CONTROL FIELDS (SEX).
      *****************************************************************
       7010-VALIDATE-SEX-FIELD.
      *
      ***  VALIDATE SEX. MUST BE 'M' OR 'F'. (MALE,FEMALE)
           MOVE MIR-RAT-STD-SEX-CD    TO WS-SAVE-SEX.
           IF WS-VALID-SEX
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'NS03500002'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VALIDATE-CONTROL
557660     END-IF.
      *
       7010-VALIDATE-SEX-FIELD-X.
           EXIT.
      *
      /
      *****************************************************************
      *  EDIT CONTROL FIELDS: AGE
      *****************************************************************
       7020-EDIT-AGE-FIELD.
      *
      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE '3'                   TO L0280-LENGTH.
           MOVE '3'                   TO L0280-INPUT-SIZE.
      *
      ***  PERFORM NUMERIC EDIT ON AGE.
           MOVE 'U'                   TO WS-AGE-IND.
           MOVE MIR-RAT-STD-AGE       TO L0280-INPUT-DATA.
           PERFORM 7800-NUMERIC-EDIT
              THRU 7800-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-999
               MOVE WS-NUM-999        TO MIR-RAT-STD-AGE
               PERFORM  7021-DETERMINE-CHILD-ADULT
                   THRU 7021-DETERMINE-CHILD-ADULT-X
           ELSE
               MOVE 'NS03500003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VALIDATE-CONTROL
557660     END-IF.
      *
       7020-EDIT-AGE-FIELD-X.
           EXIT.
      *
      /
       7021-DETERMINE-CHILD-ADULT.
      *
      ***  DETERMINE IF ADULT OR CHILD ONLY IF IT IS A CREATE
           IF  WS-BUS-FCN-CREATE
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               GO TO 7021-DETERMINE-CHILD-ADULT-X
557660     END-IF.

           PERFORM  PCOM-1000-READ
               THRU PCOM-1000-READ-X.

           IF WPCOM-IO-OK
               IF L0280-OUTPUT > RPCOM-HWTB-MAX-CHILD-AGE
                   MOVE 'A'           TO WS-AGE-IND
                   IF MIR-RAT-STD-SEX-CD = SPACES
034802*                NEXT SENTENCE
034802                 CONTINUE
                   ELSE
                       MOVE SPACES    TO MIR-RAT-STD-SEX-CD
                       MOVE 'NS03500015'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM 0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
557660             END-IF
               ELSE
                   MOVE 'C'           TO WS-AGE-IND
557660         END-IF
           ELSE
               MOVE 'NS03500016'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VALIDATE-CONTROL
557660     END-IF.
      *
       7021-DETERMINE-CHILD-ADULT-X.
           EXIT.
      *
      /
      *****************************************************************
      *  EDIT CONTROL FIELDS: AGE
      *****************************************************************
       7025-VALIDATE-AGE-FIELD.
      *
      ***  CHECK NUMERIC RANGE FOR AGE.
           MOVE MIR-RAT-STD-AGE       TO WS-TEST-RANGE.
           IF WS-AGE-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'NS03500012'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VALIDATE-CONTROL
557660     END-IF.
      *
       7025-VALIDATE-AGE-FIELD-X.
           EXIT.
      *
      /
      *****************************************************************
      *  EDIT CONTROL FIELDS: HEIGHT
      *****************************************************************
       7030-EDIT-HEIGHT-FIELD.
      *
      ***  PERFORM NUMERIC EDIT ON HEIGHT.
           MOVE MIR-RAT-STD-HT-QTY    TO L0280-INPUT-DATA.
           PERFORM 7800-NUMERIC-EDIT
              THRU 7800-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-999
               MOVE WS-NUM-999        TO MIR-RAT-STD-HT-QTY
           ELSE
               MOVE 'NS03500004'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VALIDATE-CONTROL
557660     END-IF.
      *
       7030-EDIT-HEIGHT-FIELD-X.
           EXIT.
      *
      /
      *****************************************************************
      *  EDIT CONTROL FIELDS: HEIGHT
      *****************************************************************
       7035-VALIDATE-HEIGHT-FIELD.
      *
      ***  SET ERROR MESSAGE IF HEIGHT IS INVALID.
           MOVE MIR-RAT-STD-HT-QTY    TO WS-TEST-RANGE.

           IF WS-SCALE-IMPERIAL
               IF WS-IMPERIAL-HGT-OK
                   GO TO 7035-VALIDATE-HEIGHT-FIELD-X
               ELSE
                   MOVE 'NS03500017'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'Y'           TO WS-VALIDATE-CONTROL
               END-IF
           ELSE
               IF WS-SCALE-METRIC
                   IF WS-METRIC-HGT-OK
                       GO TO 7035-VALIDATE-HEIGHT-FIELD-X
                   ELSE
                       MOVE 'NS03500013'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM 0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                       MOVE 'Y'       TO WS-VALIDATE-CONTROL
                   END-IF
               END-IF
           END-IF.
      *
       7035-VALIDATE-HEIGHT-FIELD-X.
           EXIT.
      *
      /
      *****************************************************************
      *  EDIT CONTROL FIELDS: WEIGHT
      *****************************************************************
       7040-EDIT-WEIGHT-FIELD.
      *
      ***  PERFORM NUMERIC EDIT ON WEIGHT.
           MOVE MIR-RAT-STD-WGT-QTY   TO L0280-INPUT-DATA.
           PERFORM 7800-NUMERIC-EDIT
              THRU 7800-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-999
               MOVE WS-NUM-999        TO MIR-RAT-STD-WGT-QTY
           ELSE
               MOVE 'NS03500005'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VALIDATE-CONTROL
557660     END-IF.
      *
       7040-EDIT-WEIGHT-FIELD-X.
           EXIT.
      *
      /
      *****************************************************************
      *  EDIT CONTROL FIELDS: WEIGHT
      *****************************************************************
       7045-VALIDATE-WEIGHT-FIELD.
      *
      ***  SET ERROR MESSAGE FOR INVALID WEIGHT.
           MOVE MIR-RAT-STD-WGT-QTY   TO WS-TEST-RANGE.

           IF WS-SCALE-IMPERIAL
               GO TO 7045-VALIDATE-WEIGHT-FIELD-X
           ELSE
               IF WS-SCALE-METRIC
                   IF WS-METRIC-WGT-OK
034802*                NEXT SENTENCE
034802                 CONTINUE
                   ELSE
                       MOVE 'NS03500014'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM 0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                       MOVE 'Y'       TO WS-VALIDATE-CONTROL
                   END-IF
               END-IF
           END-IF.
      *
       7045-VALIDATE-WEIGHT-FIELD-X.
           EXIT.
      *
      *
      *****************************************************************
      *  BUILD HWTB KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
      *****************************************************************
       7100-BUILD-HWTB-KEY.
      *
           MOVE MIR-RAT-STD-SEX-CD    TO WHWTB-RAT-STD-SEX-CD.
           MOVE MIR-RAT-STD-AGE       TO WHWTB-RAT-STD-AGE.
           MOVE MIR-RAT-STD-HT-QTY    TO WHWTB-RAT-STD-HT-QTY.
           MOVE MIR-RAT-STD-WGT-QTY   TO WHWTB-RAT-STD-WGT-QTY.
      *
       7100-BUILD-HWTB-KEY-X.
           EXIT.
      /
      *
      *****************************************************************
      *  FORMAT NUMERIC KEYS: AGE,HEIGHT,WEIGHT
      *****************************************************************
       7200-CHECK-NUMERIC-KEYS.
      *
           MOVE 'N'                   TO WS-VALIDATE-CONTROL.
      *
           PERFORM 7020-EDIT-AGE-FIELD
              THRU 7020-EDIT-AGE-FIELD-X.
           PERFORM 7030-EDIT-HEIGHT-FIELD
              THRU 7030-EDIT-HEIGHT-FIELD-X.
           PERFORM 7040-EDIT-WEIGHT-FIELD
              THRU 7040-EDIT-WEIGHT-FIELD-X.
      *
       7200-CHECK-NUMERIC-KEYS-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT DATA FIELDS ACCORDING TO THE DATA DICTIONARY
      *****************************************************************
       7500-EDIT-DATA-FIELDS.
      *
           MOVE 'Y'                   TO WS-DATA-EDITS.
      *
           PERFORM  7510-EDIT-MIN-RATE
               THRU 7510-EDIT-MIN-RATE-X.
      *
           PERFORM  7520-EDIT-REC-RATE
               THRU 7520-EDIT-REC-RATE-X.
      *
           PERFORM  7530-EDIT-MAX-RATE
               THRU 7530-EDIT-MAX-RATE-X.
      *
       7500-EDIT-DATA-FIELDS-X.
           EXIT.
      *
      /
      *****************************************************************
      *  MINIMUM RATE: MUST BE NUMERIC.
      *****************************************************************
       7510-EDIT-MIN-RATE.
      *
           IF MIR-MIN-RAT-QTY   = SPACES
               MOVE RHWTB-MIN-RAT-QTY TO WS-NUM-999
               MOVE WS-NUM-999        TO MIR-MIN-RAT-QTY
               GO TO 7510-EDIT-MIN-RATE-X
           ELSE
               IF MIR-MIN-RAT-QTY       = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO WS-NUM-999
                   MOVE WS-NUM-999    TO MIR-MIN-RAT-QTY
557660         END-IF
557660     END-IF.
      *
      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE '3'                   TO L0280-LENGTH.
           MOVE '3'                   TO L0280-INPUT-SIZE.
      *
      ***  PERFORM NUMERIC EDIT ON RATE.
           MOVE MIR-MIN-RAT-QTY       TO L0280-INPUT-DATA.
           PERFORM 7800-NUMERIC-EDIT
              THRU 7800-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-999
               MOVE WS-NUM-999        TO MIR-MIN-RAT-QTY
               MOVE L0280-OUTPUT      TO WS-TEST-RANGE
           ELSE
               MOVE ZEROS             TO WS-TEST-RANGE
557660     END-IF.
           IF L0280-OK
557660     AND WS-RATE-OK
               MOVE MIR-MIN-RAT-QTY   TO RHWTB-MIN-RAT-QTY
           ELSE
               MOVE 'NS03500006'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.
      *
       7510-EDIT-MIN-RATE-X.
           EXIT.
      *
      /
      *****************************************************************
      *  RECOMMENDED RATE: MUST BE NUMERIC.
      *****************************************************************
       7520-EDIT-REC-RATE.
      *
           IF MIR-RECMND-RAT-QTY   = SPACES
               MOVE RHWTB-RECMND-RAT-QTY
                                      TO WS-NUM-999
               MOVE WS-NUM-999        TO MIR-RECMND-RAT-QTY
               GO TO 7520-EDIT-REC-RATE-X
           ELSE
               IF MIR-RECMND-RAT-QTY       = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO WS-NUM-999
                   MOVE WS-NUM-999    TO MIR-RECMND-RAT-QTY
557660         END-IF
557660     END-IF.
      *
      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE '3'                   TO L0280-LENGTH.
           MOVE '3'                   TO L0280-INPUT-SIZE.
      *
      ***  PERFORM NUMERIC EDIT ON RATE.
           MOVE MIR-RECMND-RAT-QTY    TO L0280-INPUT-DATA.
           PERFORM 7800-NUMERIC-EDIT
              THRU 7800-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-999
               MOVE WS-NUM-999        TO MIR-RECMND-RAT-QTY
               MOVE L0280-OUTPUT      TO WS-TEST-RANGE
           ELSE
               MOVE ZEROS             TO WS-TEST-RANGE
557660     END-IF.
           IF L0280-OK
557660     AND WS-RATE-OK
               MOVE MIR-RECMND-RAT-QTY           TO RHWTB-RECMND-RAT-QTY
           ELSE
               MOVE 'NS03500007'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.
      *
       7520-EDIT-REC-RATE-X.
           EXIT.
      *
      /
      *****************************************************************
      *  MAXIMUM RATE: MUST BE NUMERIC.
      *****************************************************************
       7530-EDIT-MAX-RATE.
      *
           IF MIR-MAX-RAT-QTY    = SPACES
               MOVE RHWTB-MAX-RAT-QTY TO WS-NUM-999
               MOVE WS-NUM-999        TO MIR-MAX-RAT-QTY
               GO TO 7530-EDIT-MAX-RATE-X
           ELSE
               IF MIR-MAX-RAT-QTY    = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO WS-NUM-999
                   MOVE WS-NUM-999    TO MIR-MAX-RAT-QTY
557660         END-IF
557660     END-IF.
      *
      ***  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE '3'                   TO L0280-LENGTH.
           MOVE '3'                   TO L0280-INPUT-SIZE.
      *
      ***  PERFORM NUMERIC EDIT ON RATE.
           MOVE MIR-MAX-RAT-QTY       TO L0280-INPUT-DATA.
           PERFORM 7800-NUMERIC-EDIT
              THRU 7800-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-999
               MOVE WS-NUM-999        TO MIR-MAX-RAT-QTY
               MOVE L0280-OUTPUT      TO WS-TEST-RANGE
           ELSE
               MOVE ZEROS             TO WS-TEST-RANGE
557660     END-IF.
           IF L0280-OK
557660     AND WS-RATE-OK
               MOVE MIR-MAX-RAT-QTY   TO RHWTB-MAX-RAT-QTY
           ELSE
               MOVE 'NS03500008'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-DATA-EDITS
557660     END-IF.
      *
       7530-EDIT-MAX-RATE-X.
           EXIT.
      *
      /
      *****************************************************************
      *  RANGE CROSS EDITS. VALUES MUST BE INCREASING.
      *****************************************************************
       7600-CROSS-EDITS.
      *
           MOVE 'Y'                   TO WS-CROSS-EDITS.
      *
           IF RHWTB-MIN-RAT-QTY      > RHWTB-RECMND-RAT-QTY
               MOVE 'N'               TO WS-CROSS-EDITS
               MOVE 'NS03500009'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
           IF RHWTB-RECMND-RAT-QTY    > RHWTB-MAX-RAT-QTY
               MOVE 'N'               TO WS-CROSS-EDITS
               MOVE 'NS03500010'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       7600-CROSS-EDITS-X.
           EXIT.
      /
       7800-NUMERIC-EDIT.
      *
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               GO TO 7800-NUMERIC-EDIT-X
557660     END-IF.
      *
           IF L0280-ARGS-INVALID
               MOVE 'XS00000020'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7800-NUMERIC-EDIT-X
557660     END-IF.
      *
       7800-NUMERIC-EDIT-X.
           EXIT.
      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
       9100-BLANK-DATA-FIELDS.
      *
           IF  WS-BUS-FCN-LIST
               MOVE SPACES            TO MIR-RAT-STD-SEX-CD-G
               MOVE SPACES            TO MIR-RAT-STD-AGE-G
               MOVE SPACES            TO MIR-RAT-STD-HT-QTY-G
               MOVE SPACES            TO MIR-DV-RAT-STD-FT-HT-G
               MOVE SPACES            TO MIR-DV-RAT-STD-INCH-HT-G
               MOVE SPACES            TO MIR-DV-RAT-STD-CM-HT-G
               MOVE SPACES            TO MIR-RAT-STD-WGT-QTY-G
               MOVE SPACES            TO MIR-DV-RAT-STD-LB-WGT-G
               MOVE SPACES            TO MIR-DV-RAT-STD-KG-WGT-G
               MOVE SPACES            TO MIR-MIN-RAT-QTY-G
               MOVE SPACES            TO MIR-RECMND-RAT-QTY-G
               MOVE SPACES            TO MIR-MAX-RAT-QTY-G
           ELSE
               PERFORM  9120-BLANK-DISPLAY-LINES
                   THRU 9120-BLANK-DISPLAY-LINES-X
557660     END-IF.
      *
       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
       9120-BLANK-DISPLAY-LINES.
      *
           MOVE SPACES                TO MIR-DV-RAT-STD-FT-HT.
           MOVE SPACES                TO MIR-DV-RAT-STD-INCH-HT.
           MOVE SPACES                TO MIR-DV-RAT-STD-CM-HT.
           MOVE SPACES                TO MIR-DV-RAT-STD-LB-WGT.
           MOVE SPACES                TO MIR-DV-RAT-STD-KG-WGT.
           MOVE SPACES                TO MIR-MIN-RAT-QTY.
           MOVE SPACES                TO MIR-RECMND-RAT-QTY.
           MOVE SPACES                TO MIR-MAX-RAT-QTY.
      *
       9120-BLANK-DISPLAY-LINES-X.
           EXIT.
      *
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN (REWRITTEN FOR 5.3)
      *****************************************************************
       9200-MOVE-RECORD-TO-SCREEN.
      ***DO CONVERSIONS FIRST

           MOVE ZEROES                TO WS-TEMP.

           PERFORM  9205-SCREEN-CONVERSIONS
               THRU 9205-SCREEN-CONVERSIONS-X.

           IF  WS-BUS-FCN-LIST
               PERFORM  9210-MOVE-RECORD-TO-SCREEN
                   THRU 9210-MOVE-RECORD-TO-SCREEN-X
           ELSE
               PERFORM  9220-MOVE-RECORD-TO-SCREEN2
                   THRU 9220-MOVE-RECORD-TO-SCREEN2-X
557660     END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

       9205-SCREEN-CONVERSIONS.
      *
           IF WS-SCALE-IMPERIAL
               MOVE RHWTB-RAT-STD-HT-QTY
                                      TO L0520-IMPERIAL-INCHES
               PERFORM 0520-3000-IN-TO-FEET
                   THRU 0520-3000-IN-TO-FEET-X
               MOVE L0520-IMPERIAL-INCHES
                                      TO WS-INCH
               MOVE L0520-IMPERIAL-FEET
                                      TO WS-FEET
               PERFORM 0520-1000-FEET-TO-CM
                   THRU 0520-1000-FEET-TO-CM-X
               COMPUTE WS-TEMP ROUNDED =   L0520-METRIC-HEIGHT2 * 1
               MOVE WS-TEMP           TO WS-CENT
           ELSE
               MOVE RHWTB-RAT-STD-HT-QTY
                                      TO L0520-METRIC-HEIGHT
               MOVE RHWTB-RAT-STD-HT-QTY
                                      TO WS-CENT
               PERFORM 0520-2000-CM-TO-FEET
                   THRU 0520-2000-CM-TO-FEET-X
               MOVE L0520-IMPERIAL-INCHES
                                      TO WS-INCH
               MOVE L0520-IMPERIAL-FEET
                                      TO WS-FEET
557660     END-IF.

           MOVE RHWTB-RAT-STD-WGT-QTY TO WS-WEIGHT.
           IF WS-SCALE-IMPERIAL
               MOVE RHWTB-RAT-STD-WGT-QTY
                                      TO L0530-IMPERIAL-WEIGHT
               MOVE RHWTB-RAT-STD-WGT-QTY
                                      TO WS-POUND
               PERFORM 0530-1000-LBS-TO-KG
                   THRU 0530-1000-LBS-TO-KG-X
               COMPUTE WS-TEMP ROUNDED = L0530-METRIC-WEIGHT2 * 1
               MOVE WS-TEMP           TO WS-KILO
           ELSE
               MOVE RHWTB-RAT-STD-WGT-QTY
                                      TO L0530-METRIC-WEIGHT
               MOVE RHWTB-RAT-STD-WGT-QTY
                                      TO WS-KILO
               PERFORM 0530-2000-KG-TO-LBS
                   THRU 0530-2000-KG-TO-LBS-X
               MOVE L0530-IMPERIAL-WEIGHT
                                      TO WS-POUND
557660     END-IF.

       9205-SCREEN-CONVERSIONS-X.
           EXIT.

      *
       9210-MOVE-RECORD-TO-SCREEN.
      *
017628*    MOVE WS-SCALE-TXT          TO MIR-CO-HWTB-SCALE-CD.
017628     MOVE RPCOM-CO-HWTB-SCALE-CD
017628                                TO MIR-CO-HWTB-SCALE-CD.
           MOVE RHWTB-RAT-STD-SEX-CD  TO MIR-RAT-STD-SEX-CD-T (WS-SUB).
           MOVE RHWTB-RAT-STD-AGE     TO MIR-RAT-STD-AGE-T (WS-SUB).
           MOVE RHWTB-RAT-STD-HT-QTY  TO WS-NUM-999.
           MOVE WS-NUM-999            TO MIR-RAT-STD-HT-QTY-T (WS-SUB).
           MOVE WS-CENT
             TO MIR-DV-RAT-STD-CM-HT-T  (WS-SUB).
           MOVE WS-INCH
             TO MIR-DV-RAT-STD-INCH-HT-T  (WS-SUB).
           MOVE WS-FEET
             TO MIR-DV-RAT-STD-FT-HT-T  (WS-SUB).
           MOVE WS-WEIGHT             TO MIR-RAT-STD-WGT-QTY-T (WS-SUB).
           MOVE WS-POUND
             TO MIR-DV-RAT-STD-LB-WGT-T (WS-SUB).
           MOVE WS-KILO
             TO MIR-DV-RAT-STD-KG-WGT-T  (WS-SUB).
           MOVE RHWTB-MIN-RAT-QTY     TO WS-NUM-999.
           MOVE WS-NUM-999            TO MIR-MIN-RAT-QTY-T  (WS-SUB).
           MOVE RHWTB-RECMND-RAT-QTY  TO WS-NUM-999.
           MOVE WS-NUM-999            TO MIR-RECMND-RAT-QTY-T  (WS-SUB).
           MOVE RHWTB-MAX-RAT-QTY     TO WS-NUM-999.
           MOVE WS-NUM-999            TO MIR-MAX-RAT-QTY-T  (WS-SUB).
      *
       9210-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

       9220-MOVE-RECORD-TO-SCREEN2.
      *
           MOVE RHWTB-RAT-STD-SEX-CD  TO MIR-RAT-STD-SEX-CD.
           MOVE RHWTB-RAT-STD-AGE     TO MIR-RAT-STD-AGE.
           MOVE RHWTB-RAT-STD-HT-QTY  TO MIR-RAT-STD-HT-QTY.
           MOVE RHWTB-RAT-STD-WGT-QTY TO MIR-RAT-STD-WGT-QTY.
017628*    MOVE WS-SCALE-TXT          TO MIR-CO-HWTB-SCALE-CD.
017628     MOVE RPCOM-CO-HWTB-SCALE-CD
017628                                TO MIR-CO-HWTB-SCALE-CD.
           MOVE WS-CENT               TO MIR-DV-RAT-STD-CM-HT.
           MOVE WS-INCH               TO MIR-DV-RAT-STD-INCH-HT.
           MOVE WS-FEET               TO MIR-DV-RAT-STD-FT-HT.
           MOVE WS-POUND              TO MIR-DV-RAT-STD-LB-WGT.
           MOVE WS-KILO               TO MIR-DV-RAT-STD-KG-WGT.
           MOVE RHWTB-MIN-RAT-QTY     TO WS-NUM-999.
           MOVE WS-NUM-999            TO MIR-MIN-RAT-QTY.
           MOVE RHWTB-RECMND-RAT-QTY  TO WS-NUM-999.
           MOVE WS-NUM-999            TO MIR-RECMND-RAT-QTY.
           MOVE RHWTB-MAX-RAT-QTY     TO WS-NUM-999.
           MOVE WS-NUM-999            TO MIR-MAX-RAT-QTY.
      *
       9220-MOVE-RECORD-TO-SCREEN2-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
       9300-SETUP-MSIN-REFERENCE.
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
      *
       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0520-0000-INIT-PARM-INFO
025970         THRU 0520-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0530-0000-INIT-PARM-INFO
025970         THRU 0530-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
023514
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-AGE-IND             TO TRUE.
025970     SET WS-DEFAULT-KEY-MATCH           TO TRUE.
025970     SET WS-DEFAULT-LINE                TO TRUE.
025970     SET WS-DEFAULT-NO-DISPLAY-LINES    TO TRUE.
025970     SET WS-DEFAULT-MAX-BROWSE-LINE     TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY XCPPEXIT.
      /
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPPINIT.
      /
021930*COPY NCPESCAL.
021930*
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY HWTB
014221                         '$VAR2' BY 'HWTB'.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS                                 *
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
025970 COPY NCPS0520.
       COPY NCPL0520.
025970 COPY NCPS0530.
       COPY NCPL0530.
      /
       COPY NCPAHWTB.
      /
       COPY NCPBHWTB.
      /
       COPY NCPNHWTB.
      /
       COPY NCPUHWTB.
      /
       COPY NCPXHWTB.
      /
       COPY CCPNPCOM.
      /
021930*COPY CCPNEDIT.
021930*
       COPY NCPCHWTB.

      *****************************************************************
      **                 END OF PROGRAM NSOM0350                     **
      *****************************************************************
