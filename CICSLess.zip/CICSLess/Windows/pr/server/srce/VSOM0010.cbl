      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. VSOM0010.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  VSOM0010                                         **
      **  REMARKS:  VLBL PROCESS DRIVER                              **
      **                                                             **
      **  DOMAIN :  AT                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557708**  5.5       HANDLING OF CICS ABENDS                          **
557918**  5.5       REPLACE NON-STANDARD MESSAGES                    **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'VSOM0010'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
      /
       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID               PIC X(04).
               88  WS-BUS-FCN-ID-VALID     VALUES
                   '1850' '1851' '1852' '1853'.
               88  WS-BUS-FCN-RETRIEVE     VALUE  '1850'.
               88  WS-BUS-FCN-CREATE       VALUE  '1851'.
               88  WS-BUS-FCN-UPDATE       VALUE  '1852'.
               88  WS-BUS-FCN-DELETE       VALUE  '1853'.
025970*    05  WS-TWRK-KEY                 PIC X(04)  VALUE '1850'.
           05  WS-ERROR-SW                 PIC 9.
               88  WS-NO-ERRORS            VALUES ARE 0.
               88  WS-ERRORS-EXIST         VALUES ARE 1.
           05  WS-KEY-EDIT-ERROR-SW        PIC 9.
               88  WS-KEY-EDIT-NO-ERRORS   VALUES ARE 0.
               88  WS-KEY-EDIT-ERRORS      VALUES ARE 1.
016548*    05  WS-INDX                     PIC S9(4)  COMP VALUE +0.
016548     05  WS-INDX                     PIC S9(4)  BINARY VALUE +0.
       01  MSGE-ERROR-MESSAGE-TABLE.
           05  FILLER                      PIC X(10) VALUE 'VS00100009'.
           05  FILLER                      PIC X(10) VALUE 'VS00100010'.
           05  FILLER                      PIC X(10) VALUE 'VS00100011'.
           05  FILLER                      PIC X(10) VALUE 'VS00100012'.
           05  FILLER                      PIC X(10) VALUE 'VS00100013'.
           05  FILLER                      PIC X(10) VALUE 'VS00100014'.
           05  FILLER                      PIC X(10) VALUE 'VS00100015'.
           05  FILLER                      PIC X(10) VALUE 'VS00100016'.
           05  FILLER                      PIC X(10) VALUE 'VS00100017'.
           05  FILLER                      PIC X(10) VALUE 'VS00100018'.
           05  FILLER                      PIC X(10) VALUE 'VS00100019'.
           05  FILLER                      PIC X(10) VALUE 'VS00100020'.
       01  MSGE-ERROR-MESSAGE-TABLE-R      REDEFINES
                                           MSGE-ERROR-MESSAGE-TABLE.
           05  MSGE-ERR-MSG                OCCURS 12 TIMES.
               10  MSGE-ERR-SOURCE         PIC X(06).
               10  MSGE-ERR-NUMBER         PIC X(04).
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                 PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT     VALUE '1850'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
016537*COPY CCFREDIT.
016537*COPY CCFWEDIT.
      /
       COPY VCFRVL.
       COPY VCFWVL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
       COPY VCWL0011.
014221 COPY XCWL8090.
      /
      *****************************************************************
      *  INPUT PARAMETER INFORMATION                                  *
      *****************************************************************
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY VCWM0010.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708

013578     INSPECT MIR-PARM-AREA REPLACING ALL '*' BY ' '.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  0200-PROCESS-REQUEST
               THRU 0200-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       0200-PROCESS-REQUEST.
      *---------------------

025970*    SET  MIR-RETRN-OK          TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  1000-PROCESS-RETRIEVE
                        THRU 1000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-PROCESS-CREATE
                        THRU 2000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  3000-PROCESS-UPDATE
                        THRU 3000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  4000-PROCESS-DELETE
                        THRU 4000-PROCESS-DELETE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID  TO WGLOB-MSG-PARM (1)
                    MOVE 'VSOM0010'      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       0200-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------
       1000-PROCESS-RETRIEVE.
      *----------------------

      *****************************************************************
      *   INQUIRY PROCESSING: RETRIEVE RECORD AND DISPLAY.
      *****************************************************************

      *
      *    SET UP VL-KEY FIELDS
      *

           MOVE MIR-VALN-LBL-ID       TO  WVL-VALN-LBL-ID.

014221*    PERFORM  VL-1000-READ
014221*        THRU VL-1000-READ-X.
014221
014221     PERFORM  VL-1000-READ-TWRK-TS
014221         THRU VL-1000-READ-TWRK-TS-X.

           IF  NOT WVL-IO-OK
      *MSG:   'RECORD @1 NOT FOUND'
557918*        MOVE 'VS00000004'            TO WGLOB-MSG-REF-INFO
557918         MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
557918         MOVE WVL-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 1000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  5000-DISPLAY-RECORDS
               THRU 5000-DISPLAY-RECORDS-X.

       1000-PROCESS-RETRIEVE-X.
           EXIT.

      /
      *--------------------
       2000-PROCESS-CREATE.
      *--------------------
      *    CREATE PROCESSING: CHECK RECORD DOES NOT EXIST, INIT NEW
      *    RECORD AND ALLOW USER TO MODIFY.

      *
      *    SET UP VL-KEY FIELDS
      *

           MOVE MIR-VALN-LBL-ID         TO  WVL-VALN-LBL-ID.

           SET WS-KEY-EDIT-NO-ERRORS    TO TRUE.

           PERFORM  6100-KEY-EDIT
               THRU 6100-KEY-EDIT-X.

           IF  WS-KEY-EDIT-ERRORS
               GO TO 2000-PROCESS-CREATE-X
           END-IF.

           PERFORM  VL-1000-READ
               THRU VL-1000-READ-X.

           IF  WVL-IO-OK
      *MSG:    'RECORD (@1) ALREADY EXISTS'
557918*        MOVE 'VS00000005'            TO WGLOB-MSG-REF-INFO
557918         MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
557918         MOVE WVL-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-PROCESS-CREATE-X
           END-IF.

           PERFORM  VL-1000-CREATE
               THRU VL-1000-CREATE-X.

           PERFORM  VL-1000-WRITE
               THRU VL-1000-WRITE-X.

014221     PERFORM  VL-1000-READ-TWRK-TS
014221         THRU VL-1000-READ-TWRK-TS-X.

           PERFORM  5000-DISPLAY-RECORDS
               THRU 5000-DISPLAY-RECORDS-X.

           PERFORM  9100-INIT-DATA-FIELDS
               THRU 9100-INIT-DATA-FIELDS-X.

      *MSG:'RECORD CREATED - CONTINUE'
557918*    MOVE 'VS00000006'                TO WGLOB-MSG-REF-INFO.
557918     MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       2000-PROCESS-CREATE-X.
           EXIT.

      /
      *--------------------
       3000-PROCESS-UPDATE.
      *--------------------
      *   MAINTAIN PROCESSING: GET RECORD, EDIT DATA FIELDS, AND UPDATE
      *   IF NO EDIT ERRORS; ELSE UNLOCK.

      *
      *    SET UP VL-KEY FIELDS
      *
           MOVE MIR-VALN-LBL-ID       TO  WVL-VALN-LBL-ID.

014221*    PERFORM  VL-1000-READ-FOR-UPDATE
014221*        THRU VL-1000-READ-FOR-UPDATE-X.
014221*
014221     PERFORM  VL-2000-UPDATE-TWRK-TS
014221         THRU VL-2000-UPDATE-TWRK-TS-X.
014221
014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221         MOVE 'VL'              TO WGLOB-MSG-PARM (01)
014221         MOVE WVL-KEY           TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 3000-PROCESS-UPDATE-X
014221     END-IF.

           IF  WVL-IO-OK
               CONTINUE
           ELSE
      *MSG:    'RECORD LOST IN MAINTAIN (@1) - CONTACT SYSTEMS'
               MOVE WVL-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  6000-EDIT-FIELDS
               THRU 6000-EDIT-FIELDS-X.
           PERFORM  VL-2000-REWRITE
               THRU VL-2000-REWRITE-X.

014221     PERFORM  VL-1000-READ-TWRK-TS
014221         THRU VL-1000-READ-TWRK-TS-X.

           IF  WGLOB-GOOD-RETURN
               IF  L0011-NO-DEFAULT-LABEL
      *MSG:        'MAINTENANCE COMPLETE - CONTINUE'
                   MOVE 'XS00000007'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      *MSG:        'RECORD UPDATED'
                   MOVE 'XS00000008'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       3000-PROCESS-UPDATE-X.
           EXIT.

      /
      *--------------------
       4000-PROCESS-DELETE.
      *--------------------

      *****************************************************************
      *   DELETE PROCESSING:
      *****************************************************************

      *
      *    SET UP VL-KEY FIELDS
      *

           MOVE MIR-VALN-LBL-ID       TO  WVL-VALN-LBL-ID.

014221*    PERFORM  VL-1000-READ-FOR-UPDATE
014221*        THRU VL-1000-READ-FOR-UPDATE-X.
014221*
014221     PERFORM  VL-2000-UPDATE-TWRK-TS
014221         THRU VL-2000-UPDATE-TWRK-TS-X.
014221
014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221         MOVE 'VL'              TO WGLOB-MSG-PARM (01)
014221         MOVE WVL-KEY           TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 4000-PROCESS-DELETE-X
014221     END-IF.

           IF  NOT WVL-IO-OK
      *MSG:    '***RECORD NOT DELETED. INVALID KEY***'
557918*        MOVE 'VS00000008'            TO WGLOB-MSG-REF-INFO
557918         MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
557918         MOVE WVL-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-DELETE-X
           END-IF.

           PERFORM  VL-1000-DELETE
               THRU VL-1000-DELETE-X.


      *MSG: 'DELETE COMPLETED - CONTINUE'
557918*    MOVE 'VS00000007'                TO WGLOB-MSG-REF-INFO
557918     MOVE 'XS00000011'          TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-PROCESS-DELETE-X.
           EXIT.

      /
      *---------------------
       5000-DISPLAY-RECORDS.
      *---------------------

      *
      * MOVE ALL RECORD FIELDS TO THE SCREEN (MIR- FIELDS)
      *
           MOVE RVL-VALN-LBL-CD (01)  TO MIR-DV-VALN-LBL-CD-T (01).
           MOVE RVL-VALN-LBL-CD (02)  TO MIR-DV-VALN-LBL-CD-T (02).
           MOVE RVL-VALN-LBL-CD (03)  TO MIR-DV-VALN-LBL-CD-T (03).
           MOVE RVL-VALN-LBL-CD (04)  TO MIR-DV-VALN-LBL-CD-T (04).
           MOVE RVL-VALN-LBL-CD (05)  TO MIR-DV-VALN-LBL-CD-T (05).
           MOVE RVL-VALN-LBL-CD (06)  TO MIR-DV-VALN-LBL-CD-T (06).
           MOVE RVL-VALN-LBL-CD (07)  TO MIR-DV-VALN-LBL-CD-T (07).
           MOVE RVL-VALN-LBL-CD (08)  TO MIR-DV-VALN-LBL-CD-T (08).
           MOVE RVL-VALN-LBL-CD (09)  TO MIR-DV-VALN-LBL-CD-T (09).
           MOVE RVL-VALN-LBL-CD (10)  TO MIR-DV-VALN-LBL-CD-T (10).
           MOVE RVL-VALN-LBL-CD (11)  TO MIR-DV-VALN-LBL-CD-T (11).
           MOVE RVL-VALN-LBL-CD (12)  TO MIR-DV-VALN-LBL-CD-T (12).

       5000-DISPLAY-RECORDS-X.
           EXIT.
      /
      /
      *-----------------
       6000-EDIT-FIELDS.
      *-----------------

           PERFORM  0011-0000-INIT-PARM-INFO
               THRU 0011-0000-INIT-PARM-INFO-X.

           MOVE MIR-DV-VALN-LBL-CD-G  TO  L0011-LVAL-TABLE.

           PERFORM  0011-1000-VLBL-EDITS
               THRU 0011-1000-VLBL-EDITS-X.

           EVALUATE TRUE

               WHEN L0011-RETRN-INVALID-REQUEST
                    MOVE +1           TO WGLOB-RETURN-CODE

               WHEN L0011-RETRN-EDIT-ERRORS
                    MOVE +1           TO WGLOB-RETURN-CODE
                    PERFORM  6020-EDIT-RETURN-SCREEN
                        THRU 6020-EDIT-RETURN-SCREEN-X

               WHEN L0011-RETRN-OK
                    PERFORM  6020-EDIT-RETURN-SCREEN
                        THRU 6020-EDIT-RETURN-SCREEN-X

            END-EVALUATE.

       6000-EDIT-FIELDS-X.
           EXIT.

      /
      *-----------------------
       6020-EDIT-RETURN-SCREEN.
      *-----------------------

           PERFORM  6025-EDIT-RETURN-FIELD
               THRU 6025-EDIT-RETURN-FIELD-X
               VARYING WS-INDX FROM 1 BY 1
                   UNTIL WS-INDX > 12.

       6020-EDIT-RETURN-SCREEN-X.
           EXIT.

      /
      *-----------------------
       6025-EDIT-RETURN-FIELD.
      *-----------------------

           IF  L0011-LVAL-T (WS-INDX)        =  HIGH-VALUES
               CONTINUE
           ELSE
               MOVE L0011-LVAL-T (WS-INDX)
                                     TO MIR-DV-VALN-LBL-CD-T (WS-INDX)
           END-IF.

       6025-EDIT-RETURN-FIELD-X.
           EXIT.
      /
      *--------------
       6100-KEY-EDIT.
      *--------------

           IF  WVL-VALN-LBL-ID = SPACES
               SET WS-KEY-EDIT-ERRORS       TO TRUE
      *MSG: 'PLEASE UPDATE THE UNINITIALIZED LABELS(S)
               MOVE 'VS00100005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

           END-IF.

       6100-KEY-EDIT-X.
           EXIT.
      /
      *----------------------
       9100-INIT-DATA-FIELDS.
      *----------------------

           MOVE  'XXXXXX'             TO MIR-DV-VALN-LBL-CD-T (01)
                                         MIR-DV-VALN-LBL-CD-T (02)
                                         MIR-DV-VALN-LBL-CD-T (03)
                                         MIR-DV-VALN-LBL-CD-T (04)
                                         MIR-DV-VALN-LBL-CD-T (05)
                                         MIR-DV-VALN-LBL-CD-T (06)
                                         MIR-DV-VALN-LBL-CD-T (07)
                                         MIR-DV-VALN-LBL-CD-T (08)
                                         MIR-DV-VALN-LBL-CD-T (09)
                                         MIR-DV-VALN-LBL-CD-T (10)
                                         MIR-DV-VALN-LBL-CD-T (11)
                                         MIR-DV-VALN-LBL-CD-T (12).

       9100-INIT-DATA-FIELDS-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0011-0000-INIT-PARM-INFO
025970         THRU 0011-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.  
025970
025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
      /
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY VL
014221                         '$VAR2' BY 'VL'.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      ****************************************************************
      * LINKAGE PROCESSING COPYBOOKS                                 *
      ****************************************************************
025970 COPY XCPS8090.
       COPY VCPS0011.
018764*COPY VCCL0011.
018764 COPY VCPL0011.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY VCPAVL.
       COPY VCPCVL.
       COPY VCPNVL.
       COPY VCPUVL.
       COPY VCPXVL.
      /
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES
      *****************************************************************
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM VSOM0010                     **
      *****************************************************************
