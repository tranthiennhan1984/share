      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2592.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2592                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE RECORD UPDATE FUNCTION  **
      **            FOR THE POLP TABLE                               **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020464**  6.4       FUND MGMT PROCESSING FOR PENDING & DEFER ACTIVITY**
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2592'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                  PIC X(04).
               88  WS-BUS-FCN-UPDATE          VALUE '2592'.
           05  WS-POL-PAYO-STAT-CD            PIC  X(01).
               88  WS-POL-PAYO-STAT-ACTV-DEFR VALUE 'D'.
               88  WS-POL-PAYO-STAT-INACTV    VALUE 'I'.
               88  WS-POL-PAYO-STAT-HIST      VALUE 'H'.
           05  I                              PIC S9(04)
                                              BINARY.
           05  WS-POL-PAYO-NUM                PIC S9(05)
                                              COMP-3.

       01  WS-CONSTANT-AREA.
           05  WS-TWRK-KEY                    PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT        VALUE '2592'.
025970*                                       VALUE '2592'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWEBLCH.
      /
028298 COPY CCWL2626.
       COPY XCWL8090.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCWWCVGS.
      /
       COPY CCFWPOLP.
       COPY CCFRPOLP.
      /
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY CCWL5400.
      /
       COPY CCWL0289.
      /
       COPY CCWLPGA.
      /
       COPY XCWL0280.
      /
       COPY XCWL0290.
      /
       COPY XCWL8960.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2592.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    INITIALIZE WS-WORKING-STORAGE.
025970*
025970*    MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2592'       TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'     TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------
       2000-UPDATE.
      *------------

           PERFORM  8010-EDIT-KEY-FIELDS
               THRU 8010-EDIT-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-UPDATE-X
           END-IF

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

      *
      *  THE RECORD MUST EXIST
      *
           PERFORM  7000-BUILD-POLP-KEYS
               THRU 7000-BUILD-POLP-KEYS-X.

           PERFORM  POLP-1000-READ-FOR-UPDATE
               THRU POLP-1000-READ-FOR-UPDATE-X

           IF  WPOLP-IO-NOT-FOUND
      *MSG: 'LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS'
               MOVE WPOLP-KEY              TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED   TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.


           PERFORM  8020-XEDIT-KEY-FIELDS
               THRU 8020-XEDIT-KEY-FIELDS-X.

      *
      *  EDIT THE DATA ENTERED
      *
           PERFORM  8030-EDIT-DATA-FIELDS
               THRU 8030-EDIT-DATA-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  POLP-3000-UNLOCK
                   THRU POLP-3000-UNLOCK-X
               SET MIR-RETRN-EDIT-ERROR     TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X.

           PERFORM  POLP-2000-REWRITE
               THRU POLP-2000-REWRITE-X.

      *
      *  UPDATE THE NEXT SCHEDULED ACTIVITY ON THE POLICY
      *

           PERFORM  6000-GET-NEXT-ACTV
               THRU 6000-GET-NEXT-ACTV-X.

      *
      *  UPDATE POLICY AND GROUP LEVEL TIMESTAMP FOR LOGICAL LOCKING
      *

           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

       2000-UPDATE-X.
           EXIT.

      /
      *--------------------------
       6000-GET-NEXT-ACTV.
      *--------------------------
      *
      * RESET NEXT ACTIVITY ON POLICY AS RESULT OF STATUS CODE CHANGE
      *

           PERFORM  POL-2000-UPDATE-TWRK-TS
               THRU POL-2000-UPDATE-TWRK-TS-X.

           IF  MIR-RETRN-TS-MISMATCH
      *  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
      *  NOT COMPLETE
              MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
              MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
              MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 6000-GET-NEXT-ACTV-X
           END-IF.

           IF  WPOL-IO-NOT-FOUND
      *MSG: 'LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS'
               MOVE WPOL-POL-ID          TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-GET-NEXT-ACTV-X
           END-IF.

           PERFORM  0289-1000-INIT-PARM-INFO
               THRU 0289-1000-INIT-PARM-INFO-X.

           MOVE WGLOB-PROCESS-DATE  TO L0289-LO-PAC-DT.
           MOVE WGLOB-PROCESS-DATE  TO L0289-LO-CRC-DT.
           MOVE WGLOB-PROCESS-DATE  TO L0289-PROC-EFF-DT.

           PERFORM  0289-1000-OBTAIN-NXT-ACTV
               THRU 0289-1000-OBTAIN-NXT-ACTV-X.

           IF L0289-RETRN-OK
               MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
               MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
           ELSE
               MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
               MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
           END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

       6000-GET-NEXT-ACTV-X.
           EXIT.

      /
      *--------------------------
       7000-BUILD-POLP-KEYS.
      *--------------------------

           MOVE MIR-POL-ID                  TO WPOLP-POL-ID.
           MOVE WS-POL-PAYO-NUM             TO WPOLP-POL-PAYO-NUM.

       7000-BUILD-POLP-KEYS-X.
           EXIT.
      /
      *--------------------------
       8010-EDIT-KEY-FIELDS.
      *--------------------------

           PERFORM  8011-EDIT-POL-ID
               THRU 8011-EDIT-POL-ID-X.

           PERFORM  8012-EDIT-POL-PAYO-NUM
               THRU 8012-EDIT-POL-PAYO-NUM-X.

       8010-EDIT-KEY-FIELDS-X.
           EXIT.
      /
      *--------------------------
       8011-EDIT-POL-ID.
      *--------------------------
      *
      * CHECK POLICY EXISTS
      *
           IF  MIR-POL-ID-BASE  = SPACES
           AND MIR-POL-ID-SFX   = SPACES
      *MSG: POLICY NUMBER IS REQUIRED
               MOVE 'CS25920001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8011-EDIT-POL-ID-X
           END-IF.

           MOVE MIR-POL-ID               TO WPOL-POL-ID.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD NOT FOUND
               MOVE 'XS00000001'         TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY             TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8011-EDIT-POL-ID-X
           END-IF.

       8011-EDIT-POL-ID-X.
           EXIT.

      /
      *--------------------------
       8012-EDIT-POL-PAYO-NUM.
      *--------------------------
      *
      *  CHECK PAYOUT NUMBER
      *

           IF  MIR-POL-PAYO-NUM = SPACES
           OR  MIR-POL-PAYO-NUM = EBLCH-BLANK-FIELD-CHAR
           OR  MIR-POL-PAYO-NUM = '00000'
      *MSG: PAYOUT NUMBER IS REQUIRED
               MOVE 'CS25920002'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8012-EDIT-POL-PAYO-NUM-X
           END-IF.

      *
      * CONVERT PAYOUT NUMBER TO DATABASE TABLE VALUE
      *
           PERFORM  9400-FORMAT-POL-PAYO-NUM
               THRU 9400-FORMAT-POL-PAYO-NUM-X.

           IF NOT L0280-OK
      *MSG: INVALID PAYOUT NUMBER
               MOVE 'CS25920003'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                TO WGLOB-MSG-ERROR-SW
               GO TO 8012-EDIT-POL-PAYO-NUM-X
           END-IF.

       8012-EDIT-POL-PAYO-NUM-X.
           EXIT.

      /
      *--------------------------
       8020-XEDIT-KEY-FIELDS.
      *--------------------------

           PERFORM  8021-XEDIT-POL-ID
               THRU 8021-XEDIT-POL-ID-X.

           PERFORM  8022-XEDIT-POL-PAYO-NUM
               THRU 8022-XEDIT-POL-PAYO-NUM-X.

       8020-XEDIT-KEY-FIELDS-X.
           EXIT.

      *--------------------------
       8021-XEDIT-POL-ID.
      *--------------------------
      *
      * CHECK POLICY CONFIDENTIAL AND SECURITY ARE SATISFIED
      *

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-STAT-MSG-NOT-REQD   TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
            END-IF.

       8021-XEDIT-POL-ID-X.
           EXIT.

      *--------------------------
       8022-XEDIT-POL-PAYO-NUM.
      *--------------------------
      *
      *  CHECK IT IS A DEFER ACTIVTY TRANSACTION USING THE SUBSET VALUE
      *

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X

           MOVE 'POL-PAYO-TYP-CD'        TO L8960-AV-TBL-CD.
           MOVE RPOLP-POL-PAYO-TYP-CD    TO L8960-AV-CD.
           MOVE 'DEF'                    TO L8960-AV-SUBSET-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X

           IF  NOT L8960-RETRN-OK
      *MSG: NOT A DEFERRED ACTIVITY, USE AUTOMATIC PAYOUT LIST
               MOVE 'CS25920004'         TO WGLOB-MSG-REF-INFO
               MOVE RPOLP-POL-PAYO-TYP-CD TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8022-XEDIT-POL-PAYO-NUM-X
            END-IF.

       8022-XEDIT-POL-PAYO-NUM-X.
           EXIT.

      /
      *-------------------------
       8030-EDIT-DATA-FIELDS.
      *-------------------------

           PERFORM  8031-EDIT-PAYO-STAT-CD
               THRU 8031-EDIT-PAYO-STAT-CD-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8030-EDIT-DATA-FIELDS-X
           END-IF.

           MOVE MIR-POL-PAYO-STAT-CD     TO RPOLP-POL-PAYO-STAT-CD.

       8030-EDIT-DATA-FIELDS-X.
           EXIT.

      /
      *-------------------------
       8031-EDIT-PAYO-STAT-CD.
      *-------------------------

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X

           MOVE 'POL-PAYO-STAT-CD'          TO L8960-AV-TBL-CD
           MOVE MIR-POL-PAYO-STAT-CD        TO L8960-AV-CD
           MOVE 'DEF'                       TO L8960-AV-SUBSET-CD

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X

           IF  NOT L8960-RETRN-OK
      *MSG INVALID STATUS; SELECT VALID STATUSES, INACTIVE OR ACTIVE
               MOVE 'CS25920005'           TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-PAYO-STAT-CD   TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                      TO WGLOB-MSG-ERROR-SW
               GO TO 8031-EDIT-PAYO-STAT-CD-X
           END-IF.

           MOVE MIR-POL-PAYO-STAT-CD     TO WS-POL-PAYO-STAT-CD.

           EVALUATE TRUE

              WHEN RPOLP-POL-PAYO-STAT-ACTV-DEFR
              WHEN RPOLP-POL-PAYO-STAT-INACTV

                    IF  WS-POL-PAYO-STAT-HIST
      *MSG INVALID STATUS(@1); SELECT VALID STATUSES, INACTIVE OR ACTIVE
                        MOVE 'CS25920005'         TO WGLOB-MSG-REF-INFO
                        MOVE MIR-POL-PAYO-STAT-CD TO WGLOB-MSG-PARM (1)
                        PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                        MOVE 1                    TO WGLOB-MSG-ERROR-SW
                       GO TO 8031-EDIT-PAYO-STAT-CD-X
                    END-IF

              WHEN RPOLP-POL-PAYO-STAT-HIST
                    IF  WS-POL-PAYO-STAT-INACTV
                    OR  WS-POL-PAYO-STAT-ACTV-DEFR
      *MSG THE DEFERRED ACTIVITY STATUS IS HISTORY; RECORD CANNOT BE
      *    UPDATED
                        MOVE 'CS25920008'         TO WGLOB-MSG-REF-INFO
                        PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                        MOVE 1                    TO WGLOB-MSG-ERROR-SW
                       GO TO 8031-EDIT-PAYO-STAT-CD-X
                    END-IF

           END-EVALUATE.

           IF  RPOLP-POL-PAYO-STAT-ACTV-DEFR
           AND WS-POL-PAYO-STAT-INACTV
      *MSG STATUS CHANGED TO 'INACTIVE', DEFERRED ACTIVITY WILL
      *    NOT BE PROCESSED
               MOVE 'CS25920006'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8031-EDIT-PAYO-STAT-CD-X
           END-IF.

           IF  RPOLP-POL-PAYO-STAT-INACTV
           AND WS-POL-PAYO-STAT-ACTV-DEFR
      *MSG STATUS CHANGED TO 'ACTIVE', DEFERRED ACTIVITY HAS BEEN
      *    RESCHEDULED
               MOVE 'CS25920007'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8031-EDIT-PAYO-STAT-CD-X
           END-IF.

       8031-EDIT-PAYO-STAT-CD-X.
           EXIT.

      /
      *-------------------------
       9000-BLANK-DATA-FIELDS.
      *-------------------------

           MOVE SPACES                   TO MIR-IO-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *--------------------------
       9200-MOVE-RECORD-TO-MIR.
      *--------------------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           MOVE RPOLP-POL-PAYO-STAT-CD   TO MIR-POL-PAYO-STAT-CD.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.

           SET  WGLOB-REF-POLICY         TO TRUE.
           MOVE MIR-POL-ID               TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.


      /
      *--------------------------
       9400-FORMAT-POL-PAYO-NUM.
      *--------------------------
      *
      * TRANSLATION IS REQUIRED TO HAVE PAYOUT NUMBER CONVERTED TO
      * A SEQUENCE NUMBER (DISPLAYED VALUE)
      * - O R -
      * A VALUE STORED IN THE DATABASE (TABLE KEY VALUE)
      *

           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE 0                    TO L0280-PRECISION.
           MOVE 5                    TO L0280-LENGTH.
           MOVE 5                    TO L0280-INPUT-SIZE.
           MOVE MIR-POL-PAYO-NUM     TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               COMPUTE  WS-POL-PAYO-NUM
                     =  100000
                     -  L0280-OUTPUT-V00
               MOVE WS-POL-PAYO-NUM  TO L0290-INPUT-NUMBER
               MOVE 0                TO L0290-PRECISION
               MOVE LENGTH OF MIR-POL-PAYO-NUM
                                     TO L0290-MAX-OUT-LEN

               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
           END-IF.

       9400-FORMAT-POL-PAYO-NUM-X.
           EXIT.


      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     SET WS-TWRK-KEY-DEFAULT          TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK                TO TRUE.


       9990-INIT-WORKING-STORAGE-X.
           EXIT.


      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
      /
       COPY NCPPCVGR.
       COPY NCPPCVGS.
      /
       COPY XCPPINIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  POL
                                '$VAR2'   BY 'POL'.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
025970 COPY XCPS8090.
       COPY CCPS5400.
       COPY CCPL5400.
      /
       COPY CCPL0289.
       COPY CCPS0289.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
       COPY XCPS8960.
       COPY XCPL8960.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
       COPY CCPNCVG.
       COPY CCPUCVG.
      /
       COPY CCPUPOLP.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM 'CSOM2592'                   **
      *****************************************************************
