      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0673.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0673                                         **
      **  REMARKS:  DIVIDEND SURRENDER ON DIVIDENDS ON DEPOSITS      **
      **            ALL RELEVANT ACCOUNT ENTRIES WILL BE GENERATED   **
      **            AS WELL AS A REQUEST FOR LETTER.                 **
      **            IF THE POLICY WAS UPDATED IN ANY WAY, A STATUS   **
      **            PRINT IS REQUESTED.                              **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023436**  6.5       UNDO/REDO OF ANNIVERSARY PROCESSING              **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
035251**  7.1       MOVE MXDX TO RH AND RT                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************
       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0673'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID           PIC X(04).
               88  WS-BUS-FCN-DIV-SURR VALUE  '0523'.
           05  WS-REDO-SW              PIC X(01).
               88  WS-REDO-OK          VALUE 'Y'.
               88  WS-REDO-NOT-OK      VALUE 'N'.

           05  WS-EDIT-AREA.
               10  FILLER              PIC X(13).
               10  WS-EFF-DATE.
                   15  WS-EFF-DATE-YR  PIC 9(04).
                   15  FILLER          PIC X(01).
                   15  WS-EFF-DATE-MO  PIC 9(02).
                   15  FILLER          PIC X(01).
                   15  WS-EFF-DATE-DY  PIC 9(02).
               10  WS-AMOUNT           PIC S9(15)V99 COMP-3.
               10  WS-SUB-CODE         PIC X.
                   88  WS-SURR-DOD     VALUE 'D'.

      /
      ***********************************************************
      * COMMON COPYBOOKS
      ***********************************************************

       COPY CCFHPOL.
      /
       COPY CCWWLOCK.
      /
       COPY XCWWWKDT.
      /
       COPY CCWWINDX.
026057 COPY CCWWIHSD.
      /
      ***************************************************************
      * I/O COPYBOOKS
      ***************************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFWPOL.
      /
       COPY CCFRPLRT.
       COPY CCFWPLRT.
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
      ***************************************************************
      * CALLED MODULE PARAMETER INFORMATION
      ***************************************************************
       COPY CCWL0186.
020478 COPY CCWL2626.
      /
       COPY CCWL0201.
      /
       COPY CCWL0289.
      /
       COPY CCWL0620.
      /
       COPY CCWL0985.
      /
       COPY CCWL1415.
      /
       COPY CCWL2430.
      /
       COPY CCWL4750.
      /
       COPY CCWL4780.
      /
       COPY CCWL5208.
      /
       COPY CCWL5400.
      /
       COPY CCWL5750.
      /
       COPY XCWLDTLK.
      /
       COPY XCWL1640.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
      /
       COPY XCWL0280.
      /
       COPY XCWL0290.
      /
       COPY XCWL8090.
      /
      ***********************************************************
      * INPUT PARAMETER INFORMATION
      ***********************************************************
      /

       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM0673.
      /

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /

      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

025970*    SET  MIR-RETRN-OK              TO TRUE.
           SET  WGLOB-GOOD-RETURN         TO TRUE.

           PERFORM  9400-SETUP-MSIN-REFERENCE
               THRU 9400-SETUP-MSIN-REFERENCE-X.
      *
      * MOVE BUSINESS FUNCTION ID TO WORK FIELD AND EVALUATE.
      *
025970*    MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
      *
      * VALIDATE BUSINESS FUNCTION
      *
           EVALUATE TRUE

               WHEN  WS-BUS-FCN-DIV-SURR
                     CONTINUE

               WHEN  OTHER
                     SET MIR-RETRN-INVALD-RQST
                                           TO TRUE
                     MOVE 'CS06730001'     TO WGLOB-MSG-REF-INFO
                     MOVE WS-BUS-FCN-ID    TO WGLOB-MSG-PARM (01)
                     PERFORM  0260-1000-GENERATE-MESSAGE
                         THRU 0260-1000-GENERATE-MESSAGE-X

           END-EVALUATE.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.
      *
      * VALIDATE THE INPUT FROM THE SCREEN.
      *
           PERFORM  1100-EDIT-INPUT-FIELDS
               THRU 1100-EDIT-INPUT-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW NOT = ZERO
               SET WGLOB-RETURN-ERROR      TO TRUE
               GO TO 1000-PROCESS-REQUEST-X
           END-IF.

      *
      *  PERFORM THE DIVIDEND PROCESSING
      *
           PERFORM  2000-PROCESS-DIV-SURR
               THRU 2000-PROCESS-DIV-SURR-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 1000-PROCESS-REQUEST-X
           END-IF.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-----------------------
       1100-EDIT-INPUT-FIELDS.
      *-----------------------
      *
      * GET OWNER'S NAME
      *
           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           MOVE MIR-POL-ID                 TO L2430-POL-ID.
           MOVE ZERO                       TO I.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  L2430-RETRN-OK
               INITIALIZE                     L0620-INPUT-PARM-INFO

               IF  L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM
                                           TO L0620-CLI-CO-NM
               ELSE
                 MOVE L2430-CLI-ENTR-GIV-NM
                                           TO L0620-CLI-GIV-NM
                 MOVE L2430-CLI-ENTR-SUR-NM
                                           TO L0620-CLI-SUR-NM
                 MOVE L2430-CLI-MID-INIT-NM
                                           TO L0620-CLI-MID-INIT-NM
                 MOVE L2430-CLI-SFX-NM     TO L0620-CLI-SFX-NM
               END-IF

               MOVE L2430-CLI-SEX-CD       TO L0620-CLI-SEX-CD

               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X

               MOVE L0620-SCREEN-NAME      TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES                 TO MIR-DV-OWN-CLI-NM
           END-IF.
      *
      * CALL XSDU0280 TO EDIT THE AMOUNT FIELD
      *
           MOVE MIR-ACCT-TRXN-AMT         TO L0280-INPUT-DATA.
           SET L0280-SIGN-NOT-PERMITTED   TO TRUE.
           MOVE +2                        TO L0280-PRECISION.
           MOVE LENGTH OF MIR-ACCT-TRXN-AMT
                                          TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
                                  L0280-PRECISION - 1.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-DOLLAR   TO WS-AMOUNT
           ELSE
      * MSG: AMOUNT IS INVALID
               MOVE 'CS0673002'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR     TO  TRUE
               MOVE ZERO                  TO WS-AMOUNT
           END-IF.

           MOVE MIR-DV-EFF-DT             TO L1640-EXTERNAL-DATE.
           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE       TO WS-EFF-DATE.

       1100-EDIT-INPUT-FIELDS-X.
           EXIT.

      /
      *----------------------
       2000-PROCESS-DIV-SURR.
      *----------------------
      *
      *  ACCESS POLICY
      *
           MOVE MIR-POL-ID-BASE            TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX             TO WPOL-POL-ID-SFX.

           IF  NOT MIR-DV-PRCES-STATE-CD = '3'
               PERFORM  POL-1000-READ-TWRK-TS
                   THRU POL-1000-READ-TWRK-TS-X
           ELSE
               PERFORM  POL-2000-UPDATE-TWRK-TS
                   THRU POL-2000-UPDATE-TWRK-TS-X

               IF  MIR-RETRN-TS-MISMATCH
      *  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
      *  NOT COMPLETE
                   MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
                   MOVE 'POL'             TO WGLOB-MSG-PARM (01)
                   MOVE WPOL-KEY          TO WGLOB-MSG-PARM (02)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 2000-PROCESS-DIV-SURR-X
               END-IF
           END-IF.

           IF  NOT WPOL-IO-OK
      * MSG:  POLICY NOT FOUND IN FILE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2000-PROCESS-DIV-SURR-X
           END-IF.

           IF RPOL-POL-SUSPENDED
      *MSG: POLICY CURRENTLY SUSPENDED - CANNOT MAINTAIN OR PROCESS
               MOVE 'XS00000240'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                  SET WGLOB-RETURN-ERROR       TO TRUE
                  GO TO 2000-PROCESS-DIV-SURR-X
               END-IF
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-EFF-DATE              TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-2000-CHK-IHSD-PROCESS
026057         THRU IHSD-2000-CHK-IHSD-PROCESS-X.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057        SET WGLOB-RETURN-ERROR       TO TRUE
026057        GO TO 2000-PROCESS-DIV-SURR-X
026057     END-IF.
      *
      * VERIFY THAT POLICY ACCESS IS ALLOWED
      *
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-CRCY-MSG-REQD      TO TRUE.

           SET L5400-POL-XFER-UPDATE    TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-XFER-ACCS-RESTRICTED
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 2000-PROCESS-DIV-SURR-X
           END-IF.

           MOVE RPOL-POL-CRCY-CD        TO MIR-POL-CRCY-CD.
           MOVE RPOL-POL-CRCY-CD        TO MIR-FND-CRCY-CD.

      *
      *  LOAD THE COVERAGES INTO THE WORK AREA
      *
           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           IF  RPOL-POL-STAT-BEFORE-SETL
      * MSG: POLICY NOT IN FORCE - CANNOT MAINTAIN OR PROCESS
               MOVE 'XS00000238'    TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WGLOB-RETURN-ERROR TO TRUE
                   GO TO 2000-PROCESS-DIV-SURR-X
               END-IF
           END-IF.

      *
      * VALIDATE CLIENTS DATE OF DEATH FIELDS
      *
           PERFORM  0985-1000-BUILD-PARM-INFO
               THRU 0985-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DATE             TO L0985-EFF-DT.

           PERFORM  0985-1000-VAL-POL-DT-OF-DTH
               THRU 0985-1000-VAL-POL-DT-OF-DTH-X.

           IF  NOT L0985-RETRN-OK
               SET WGLOB-RETURN-ERROR   TO TRUE
               GO TO 2000-PROCESS-DIV-SURR-X
           END-IF.

      *
      *  BUILD THE GENERAL PARAMETER AREA
      *
           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.
      *
      *  PROCESS THE TRANSACTION
      *
           PERFORM  3000-SURR-DIVIDEND
               THRU 3000-SURR-DIVIDEND-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-PROCESS-DIV-SURR-X
           END-IF.

       2000-PROCESS-DIV-SURR-X.
           EXIT.
      /
      *-------------------
       3000-SURR-DIVIDEND.
      *-------------------

           IF MIR-DV-PRCES-STATE-CD = '3'
              PERFORM  3400-SURR-DIVIDEND-3
                  THRU 3400-SURR-DIVIDEND-3-X
           ELSE
              PERFORM  3200-SURR-DIVIDEND-2
                  THRU 3200-SURR-DIVIDEND-2-X
           END-IF.

       3000-SURR-DIVIDEND-X.
           EXIT.
      /
      *---------------------
       3200-SURR-DIVIDEND-2.
      *---------------------

           PERFORM  3220-CHECK-DIV-RATE
               THRU 3220-CHECK-DIV-RATE-X.

           IF WGLOB-RETURN-ERROR
      * MSG: DIVIDENDS ON DEPOSIT SURRENDER  PROCESSING TERMINATED
              MOVE 'CS06730004'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 3200-SURR-DIVIDEND-2-X
           END-IF.

           PERFORM  3240-CHECK-DIV-VEST-INFO
               THRU 3240-CHECK-DIV-VEST-INFO-X.

           IF WGLOB-RETURN-ERROR
      * MSG: DIVIDENDS ON DEPOSIT SURRENDER  PROCESSING TERMINATED
              MOVE 'CS06730004'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 3200-SURR-DIVIDEND-2-X
           END-IF.

           PERFORM  8200-CHECK-OS-ACTV
               THRU 8200-CHECK-OS-ACTV-X.

      *
      * CALL FD CSLF1415 TO SURRENDER PUA
      *

           PERFORM  1415-1000-BUILD-PARM-INFO
               THRU 1415-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DATE           TO L1415-EFF-DT.
           MOVE ZEROS                 TO L1415-CVG-NUM.
           MOVE WS-AMOUNT             TO L1415-DIV-AMT.
           MOVE MIR-DV-CHQ-CREAT-IND  TO L1415-CHQ-IND.
           MOVE WS-SUB-CODE           TO L1415-SURR-DIV-TYP-CD.

           IF  MIR-DV-PRCES-STATE-CD NOT = '3'
               SET L1415-PRCES-TYP-EDIT-ONLY TO TRUE
           END-IF.

           PERFORM  1415-1000-SURR-DIV
               THRU 1415-1000-SURR-DIV-X.

           IF  NOT L1415-RETRN-OK
      * MSG: DIVIDENDS ON DEPOSIT SURRENDER  PROCESSING TERMINATED
               MOVE 'CS06730004'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 3200-SURR-DIVIDEND-2-X
           END-IF.

       3200-SURR-DIVIDEND-2-X.
           EXIT.
      /
      *-------------------
       3220-CHECK-DIV-RATE.
      *-------------------

           MOVE RPOL-POL-PAR-CVG-NUM  TO I.

           IF WCVGS-CVG-NON-PARTICIPATING (I)
           OR WCVGS-CVG-UNIT-VALU-AMT     (I) = ZERO
              GO TO 3220-CHECK-DIV-RATE-X
           END-IF.

           PERFORM  PLIN-1000-PLAN-HEADER-IN
               THRU PLIN-1000-PLAN-HEADER-IN-X.

           IF  WCVGS-CVG-STAT-PREM-PAYING (I)
               SET L0186-PLAN-RT-TYP-PPDVR TO TRUE
           ELSE
               SET L0186-PLAN-RT-TYP-PUDVR TO TRUE
           END-IF.

           PERFORM  0186-1000-BUILD-PARM-INFO
               THRU 0186-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DATE                 TO L0186-EFF-DT.
           MOVE '000'                       TO L0186-ALT-AGE-2.

035251*    IF WCVGS-PLAN-ID-BASE-3-5 (I) = 'RPU'
035251*    OR 'ETI'
035251*        MOVE WCVGS-ORIG-PLAN-ID (I)  TO L0186-PLAN-ID
035251*    END-IF.

           PERFORM 0186-3000-GET-PLRT
              THRU 0186-3000-GET-PLRT-X.

      * AS WE ARE ONLY CHECKING TO SEE IF A PLRT EXISTS FOR THE
      * 'UV' RATE TYPE, WE DO NOT PASS A AGE-DURATION TO 0186 SO
      * THE RLTB LOOKUP WILL AWLAYS FAIL BUT THE FACT THAT IT HAS TRIED
      * TO ACCESS ONE PROVES THAT THE PLRT WAS FOUND
           IF L0186-RETRN-OK
           OR L0186-RETRN-BAD-RLTB-ACCESS
034802*       NEXT SENTENCE
034802        CONTINUE
           ELSE
      *MSG: THIS PLAN @1 DOES NOT ALLOW DIVIDEND PROCESSING
              MOVE 'CS06730005'       TO WGLOB-MSG-REF-INFO
              MOVE L0186-PLAN-ID      TO WGLOB-MSG-PARM (01)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              SET WGLOB-RETURN-ERROR    TO  TRUE
           END-IF.

       3220-CHECK-DIV-RATE-X.
           EXIT.
      /
      *------------------------
       3240-CHECK-DIV-VEST-INFO.
      *------------------------

           PERFORM  5750-1000-INIT-PARM-INFO
               THRU 5750-1000-INIT-PARM-INFO-X.

           MOVE RPOL-POL-PAR-CVG-NUM    TO  L5750-CVG-NUM.
           MOVE WS-EFF-DATE             TO  L5750-EFF-DT.

           PERFORM  5750-2000-DIV-VEST
               THRU 5750-2000-DIV-VEST-X.

           IF NOT L5750-RETRN-OK
              SET WGLOB-RETURN-ERROR    TO  TRUE
           END-IF.

       3240-CHECK-DIV-VEST-INFO-X.
           EXIT.
      /
      *---------------------
       3400-SURR-DIVIDEND-3.
      *---------------------

           PERFORM  8000-REDO-UNDO
               THRU 8000-REDO-UNDO-X.

           IF WS-REDO-NOT-OK
           OR WGLOB-RETURN-ERROR
              GO TO 3400-SURR-DIVIDEND-3-X
           END-IF.

           PERFORM 3200-SURR-DIVIDEND-2
              THRU 3200-SURR-DIVIDEND-2-X.

           IF WGLOB-RETURN-ERROR
              PERFORM  POL-3000-UNLOCK
                  THRU POL-3000-UNLOCK-X
              GO TO 3400-SURR-DIVIDEND-3-X
           END-IF.

      *
      *  GENERATE STATUS PRINT
      *
           PERFORM  5208-1000-BUILD-PARM-INFO
               THRU 5208-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DATE            TO L5208-EFF-DT.

           PERFORM  5208-1000-WRITE-STATUS-PRT
               THRU 5208-1000-WRITE-STATUS-PRT-X.

           IF  NOT L5208-RETRN-OK
               SET WGLOB-RETURN-ERROR  TO TRUE
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 3400-SURR-DIVIDEND-3-X
           END-IF.
      *
      *  UPDATE POLICY AND COVERAGES
      *
           PERFORM  0289-1000-INIT-PARM-INFO
               THRU 0289-1000-INIT-PARM-INFO-X.

           MOVE WS-EFF-DATE        TO L0289-PROC-EFF-DT.
           MOVE WS-EFF-DATE        TO L0289-LO-PAC-DT.
           MOVE WS-EFF-DATE        TO L0289-LO-CRC-DT.

           PERFORM  0289-1000-OBTAIN-NXT-ACTV
               THRU 0289-1000-OBTAIN-NXT-ACTV-X.

           IF  L0289-RETRN-OK
               MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
               MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
           ELSE
               MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
               MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
           END-IF.

           IF WGLOB-RETURN-ERROR
           OR WS-REDO-NOT-OK
              PERFORM  POL-3000-UNLOCK
                  THRU POL-3000-UNLOCK-X
              GO TO 3400-SURR-DIVIDEND-3-X
           END-IF.

           MOVE WGLOB-PROCESS-DATE    TO RPOL-PREV-FILE-MAINT-DT.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

      *
      *  RESET THE INPUT FIELDS FOR PROCESSING THE NEXT POLICY
      *
           PERFORM  4000-RESET-TOPLINE
               THRU 4000-RESET-TOPLINE-X.

      * MSG: DIVIDENDS ON DEPOSIT SURRENDER  PROCESSING COMPLETED
           MOVE 'CS06730006'  TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3400-SURR-DIVIDEND-3-X.
           EXIT.
      /
      *-------------------
       4000-RESET-TOPLINE.
      *-------------------
      *
      * THIS ROUTINE RESETS THE TOPLINE TO THE MAP DEFAULT
      *
      *    MOVE '01'                  TO MIR-CVG-NUM.
           MOVE ZERO                  TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-ACCT-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-ACCT-TRXN-AMT.
           MOVE 'N'                   TO MIR-DV-CHQ-CREAT-IND.

       4000-RESET-TOPLINE-X.
           EXIT.
      /
      *
      ****************
       8000-REDO-UNDO.
      ****************

           SET WS-REDO-OK                     TO TRUE.
           IF (RPOL-POL-NXT-ACTV-DT > WWKDT-ZERO-DT
           AND RPOL-POL-NXT-ACTV-DT > WGLOB-PROCESS-DATE)
               CONTINUE
           ELSE
               PERFORM  8500-INVOKE-REDO
                   THRU 8500-INVOKE-REDO-X
           END-IF.

           IF  WS-REDO-NOT-OK
               GO TO 8000-REDO-UNDO-X
           END-IF.

           PERFORM  8600-INVOKE-UNDO
               THRU 8600-INVOKE-UNDO-X.
      *
           IF  NOT WGLOB-GOOD-RETURN
              GO TO 8000-REDO-UNDO-X
           END-IF.
      *

       8000-REDO-UNDO-X.
           EXIT.
      /
      *
      ********************
       8200-CHECK-OS-ACTV.
      ********************

           IF  NOT RPOL-POL-STAT-IN-FORCE
               GO TO 8200-CHECK-OS-ACTV-X
           END-IF.

           PERFORM  4780-1000-BUILD-PARM-INFO
               THRU 4780-1000-BUILD-PARM-INFO-X.
           MOVE WS-EFF-DATE                 TO L4780-EFF-DT.
           SET L4780-REDO-WARNING           TO TRUE.
           MOVE RPOL-PREV-BTCH-PRCES-DT     TO L4780-LAST-PROCESS-DATE.
           SET L4780-PRCES-INCLUSIVE        TO TRUE.

           PERFORM  4780-1000-GET-NEXT-ACT-DT
               THRU 4780-1000-GET-NEXT-ACT-DT-X.

       8200-CHECK-OS-ACTV-X.
           EXIT.
      /
      *
      *****************
       8500-INVOKE-REDO.
      *****************

           IF  NOT RPOL-POL-STAT-IN-FORCE
               GO TO 8500-INVOKE-REDO-X
           END-IF.

           PERFORM  4780-1000-BUILD-PARM-INFO
               THRU 4780-1000-BUILD-PARM-INFO-X.
           SET L4780-REDO-WARNING             TO TRUE.
           SET L4780-MSG-SUPPRESS             TO TRUE.
           MOVE WS-EFF-DATE                   TO L4780-EFF-DT.
           MOVE RPOL-PREV-BTCH-PRCES-DT TO L4780-LAST-PROCESS-DATE.
           SET L4780-PRCES-INCLUSIVE          TO TRUE.

           PERFORM  4780-1000-GET-NEXT-ACT-DT
               THRU 4780-1000-GET-NEXT-ACT-DT-X.

           EVALUATE  TRUE
               WHEN L4780-RETRN-ERROR
               WHEN L4780-RETRN-INVALID-REQUEST
                    SET WS-REDO-NOT-OK           TO TRUE
                    PERFORM  POL-3000-UNLOCK
                        THRU POL-3000-UNLOCK-X
               WHEN  (L4780-RETRN-OK
               AND L4780-ACTIVITY-DUE
               AND L4780-REDO-ALLOW)
                   PERFORM  POL-3000-UNLOCK
                       THRU POL-3000-UNLOCK-X
                   MOVE WS-EFF-DATE         TO L0201-EFF-DT
                   SET L0201-AUTO-REDO      TO TRUE
                   PERFORM  0201-1000-AUTO-PROCESSING
                       THRU 0201-1000-AUTO-PROCESSING-X
                   PERFORM  8720-SET-POL-NXT-ACTV
                       THRU 8720-SET-POL-NXT-ACTV-X
                   MOVE RPOL-REC-INFO           TO HPOL-REC-INFO
                   PERFORM  POL-1000-READ-FOR-UPDATE
                       THRU POL-1000-READ-FOR-UPDATE-X
                   MOVE HPOL-REC-INFO           TO RPOL-REC-INFO
                   PERFORM  POL-2000-REWRITE
                       THRU POL-2000-REWRITE-X
                       PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
                           THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
                       PERFORM  POL-1000-READ-TWRK-TS
                           THRU POL-1000-READ-TWRK-TS-X
                   IF  L0201-RETRN-OK
                       PERFORM  POL-1000-READ-FOR-UPDATE
                           THRU POL-1000-READ-FOR-UPDATE-X
                       MOVE 'XS00000307'     TO  WGLOB-MSG-REF-INFO
      *MSG: 'AUTO REDO PROCESSING COMPLETED
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                   ELSE
                       SET WS-REDO-NOT-OK           TO TRUE
                       IF  NOT L0201-INCOMPLETE-DUE-ACTV
                           MOVE 'XS00000308' TO WGLOB-MSG-REF-INFO
      *MSG: PROBLEM IN AUTO REDO PROCESSING
                           PERFORM  0260-1000-GENERATE-MESSAGE
                               THRU 0260-1000-GENERATE-MESSAGE-X
                       END-IF
                   END-IF
           END-EVALUATE.

       8500-INVOKE-REDO-X.
           EXIT.
      *
      ******************
       8600-INVOKE-UNDO.
      ******************
           PERFORM  4750-1000-BUILD-PARM-INFO
               THRU 4750-1000-BUILD-PARM-INFO-X.
           SET L4750-FCN-DRVR-SECONDARY TO TRUE.
           MOVE WS-EFF-DATE             TO L4750-EFF-DT.
           SET  L4750-PRCES-EXCLUSIVE   TO TRUE
      *
      *  UNLOCK POLICY PRIOR TO UNDO
           PERFORM  POL-3000-UNLOCK
               THRU POL-3000-UNLOCK-X.

           PERFORM  4750-1000-UNDO-PROCESSING
               THRU 4750-1000-UNDO-PROCESSING-X.

           IF  NOT L4750-RETRN-OK
               SET MIR-RETRN-EDIT-ERROR TO TRUE
               SET WGLOB-RETURN-ERROR      TO TRUE
           END-IF.

           IF  WGLOB-RETURN-ERROR
           AND L4750-POL-UPDATE-NOT-REQD
               GO TO 8600-INVOKE-UNDO-X
           END-IF.

      *  LOCK POLICY AGAIN IN ORDER TO DO UPDATES
      *  SAVE POLICY INFO TO RESTORE AFTER READ FOR UPDATE

           MOVE  RPOL-REC-INFO        TO  HPOL-REC-INFO.
           MOVE  RPOL-KEY             TO  WPOL-KEY.
           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.
           MOVE HPOL-REC-INFO         TO  RPOL-REC-INFO.

           IF  L4750-POL-UPDATE-REQD

               PERFORM  8700-UPDATE-POL-CVG
                   THRU 8700-UPDATE-POL-CVG-X

               IF  WGLOB-GOOD-RETURN
                   MOVE  RPOL-KEY     TO  WPOL-KEY
                   PERFORM  POL-1000-READ-FOR-UPDATE
                       THRU POL-1000-READ-FOR-UPDATE-X
               END-IF

           END-IF.

       8600-INVOKE-UNDO-X.
           EXIT.

      *
      *********************
       8700-UPDATE-POL-CVG.
      *********************

      *  UPDATE THE POLICY AND COVERAGES

           PERFORM  8720-SET-POL-NXT-ACTV
               THRU 8720-SET-POL-NXT-ACTV-X.
           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.
           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.
           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

       8700-UPDATE-POL-CVG-X.
           EXIT.
      *

      ************************
       8720-SET-POL-NXT-ACTV.
      ***********************

           PERFORM  0289-1000-INIT-PARM-INFO
               THRU 0289-1000-INIT-PARM-INFO-X
           MOVE WS-EFF-DATE  TO L0289-LO-PAC-DT
           MOVE WS-EFF-DATE  TO L0289-LO-CRC-DT
           MOVE WS-EFF-DATE  TO L0289-LO-DD2-DT.
           MOVE WS-EFF-DATE  TO L0289-PROC-EFF-DT
           PERFORM  0289-1000-OBTAIN-NXT-ACTV
               THRU 0289-1000-OBTAIN-NXT-ACTV-X
           IF  L0289-RETRN-OK
                MOVE L0289-NXT-ACTV-TYP-CD
                         TO RPOL-NXT-ACTV-TYP-CD
                MOVE L0289-NXT-ACTV-DT
                         TO RPOL-POL-NXT-ACTV-DT
            ELSE
                MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
                MOVE WGLOB-PROCESS-DATE
                            TO RPOL-POL-NXT-ACTV-DT
            END-IF.

       8720-SET-POL-NXT-ACTV-X.
           EXIT.
      *--------------------------
       9400-SETUP-MSIN-REFERENCE.
      *--------------------------

      *
      * MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      * TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING.
      *

            MOVE SPACES               TO WGLOB-MSIN-REFERENCE.
            MOVE WGLOB-COMPANY-CODE   TO WGLOB-REF-COMPANY-CODE.
            MOVE 'P'                  TO WGLOB-REF-POLICY-OR-CLIENT.
            MOVE MIR-POL-ID-BASE      TO WGLOB-REF-POLICY-NUMBER.
            MOVE MIR-POL-ID-SFX       TO WGLOB-REF-POLICY-SUFFIX.

       9400-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0186-0000-INIT-PARM-INFO
025970         THRU 0186-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0201-0000-INIT-PARM-INFO
025970         THRU 0201-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1415-0000-INIT-PARM-INFO
025970         THRU 1415-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4750-0000-INIT-PARM-INFO
025970         THRU 4750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4780-0000-INIT-PARM-INFO
025970         THRU 4780-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5208-0000-INIT-PARM-INFO
025970         THRU 5208-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5750-0000-INIT-PARM-INFO
025970         THRU 5750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     MOVE SPACES                TO WWKDT-WORK-FIELDS.
025970     SET  MIR-RETRN-OK          TO TRUE.
025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           IF  MIR-ACCT-TRXN-AMT = SPACES
               MOVE ZEROS              TO MIR-ACCT-TRXN-AMT
           END-IF.

           SET WS-SURR-DOD            TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      ** PROCESSING COPYBOOKS
      *****************************************************************

026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
       COPY NCPPCVGS.
      /
       COPY NCPPCVGR.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                              '$VAR2' BY 'POL'.
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
       COPY CCPPPLIN.
      /
       COPY CCPPMIDT.
      /
026057 COPY CCPPIHSD.
      *****************************************************************
      ** LINKAGE PROCESSING COPYBOOKS
      *****************************************************************

025970 COPY XCPS1670.
025970 COPY XCPS8090.
       COPY CCPSPGA.
      /
020478 COPY CCPS2626.
020478 COPY CCPL2626.
       COPY CCPL0186.
       COPY CCPS0186.
      /
       COPY CCPL0289.
       COPY CCPS0289.
      /
025970 COPY CCPS0201.
       COPY CCPL0201.
      /
025970 COPY CCPS0620.
       COPY CCPL0620.
      /
       COPY CCPS0985.
       COPY CCPL0985.
      /
       COPY CCPS1415.
       COPY CCPL1415.
      /
       COPY CCPS2430.
       COPY CCPL2430.
      /
       COPY CCPS4750.
       COPY CCPL4750.
      /
       COPY CCPS4780.
       COPY CCPL4780.
      /
       COPY CCPS5208.
       COPY CCPL5208.
      /
       COPY CCPS5400.
       COPY CCPL5400.
      /
       COPY CCPS5750.
       COPY CCPL5750.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPL0290.
       COPY XCPS0290.
      /
       COPY XCPL8090.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
      *****************************************************************
      ** FILE I/O PROCESS MODULES
      *****************************************************************

       COPY CCPNCVG.
       COPY CCPUCVG.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
       COPY CCPNPH.
      /
       COPY CCPNPLRT.
      /
      *****************************************************************
      ** ERROR HANDLING ROUTINES
      *****************************************************************

026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0673                     **
      *****************************************************************


