      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM5364.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5364                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE LTWR TABLE                               **
      **                                                             **
      **  DOMAIN :  TX                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
013693**  6.2       LOCATION TAX                                     **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5364'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-LIST-LINES            PIC S9(04) BINARY.
025970         88  WS-MAX-LIST-LINES-DEFAULT           VALUE +50.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                           PIC X(04).
               88  WS-BUS-FCN-LIST                     VALUE '5364'.
025970*    05  WS-SUB                       PIC S9(04) COMP.
025970     05  WS-SUB                       PIC S9(04) BINARY.
025970*    05  WS-MAX-LIST-LINES            PIC S9(04) COMP VALUE 50.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
021930*COPY XCWWWKDT.
021930*
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
018763*COPY XCFWDMAD.
018763*COPY XCFRDMAD.
018763*
021930*COPY CCFWEDIT.
021930*COPY CCFREDIT.
021930*
       COPY CCFWLTWR.
       COPY CCFRLTWR.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
021930*COPY XCWLDTLK.
021930*COPY XCWL0280.
       COPY XCWL0290.
021930*COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM5364.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM5364'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-LIST.
      *------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  LTWR-1000-BROWSE
               THRU LTWR-1000-BROWSE-X.

           PERFORM  LTWR-2000-READ-NEXT
               THRU LTWR-2000-READ-NEXT-X.

           IF  WLTWR-IO-EOF
               PERFORM  LTWR-3000-END-BROWSE
                   THRU LTWR-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
           END-IF.

           PERFORM  2010-BROWSE-LTWR
               THRU 2010-BROWSE-LTWR-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WLTWR-IO-EOF.

           IF  WLTWR-IO-EOF
               CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS
                 TO TRUE
               MOVE RLTWR-LOC-GR-ID
                 TO MIR-LOC-GR-ID
               MOVE RLTWR-LTAXWH-DISB-CD
                 TO MIR-LTAXWH-DISB-CD
               MOVE RLTWR-LTAXWH-FILE-CD
                 TO MIR-LTAXWH-FILE-CD
           END-IF.

           PERFORM  LTWR-3000-END-BROWSE
               THRU LTWR-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.


      *-----------------
       2010-BROWSE-LTWR.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  LTWR-2000-READ-NEXT
               THRU LTWR-2000-READ-NEXT-X.

       2010-BROWSE-LTWR-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE MIR-LOC-GR-ID            TO WLTWR-LOC-GR-ID.
           MOVE MIR-LTAXWH-DISB-CD       TO WLTWR-LTAXWH-DISB-CD.
           MOVE MIR-LTAXWH-FILE-CD       TO WLTWR-LTAXWH-FILE-CD.

           MOVE HIGH-VALUES              TO WLTWR-ENDBR-KEY.

       7000-BUILD-KEYS-X.
           EXIT.

      /

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                  TO MIR-LTAXWH-DSTRB-CD-G.
           MOVE SPACES                  TO MIR-LTAXWH-XEMP-RH-ID-G.
           MOVE SPACES                  TO MIR-LTAXWH-WTHLD-RH-ID-G.
           MOVE SPACES                  TO MIR-LTAXWH-MIN-TAX-AMT-G.
           MOVE SPACES                  TO MIR-MIN-NET-DSTRB-AMT-G.
           MOVE SPACES                  TO MIR-LOC-GR-ID-G.
           MOVE SPACES                  TO MIR-LTAXWH-DISB-CD-G.
           MOVE SPACES                  TO MIR-LTAXWH-FILE-CD-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RLTWR-LTAXWH-DSTRB-CD
                           TO MIR-LTAXWH-DSTRB-CD-T (WS-SUB).
           MOVE RLTWR-LTAXWH-XEMP-RH-ID
                           TO MIR-LTAXWH-XEMP-RH-ID-T (WS-SUB).
           MOVE RLTWR-LTAXWH-WTHLD-RH-ID
                           TO MIR-LTAXWH-WTHLD-RH-ID-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RLTWR-LTAXWH-MIN-TAX-AMT * 100.
020874     MOVE RLTWR-LTAXWH-MIN-TAX-AMT TO L0290-INPUT-V02.
           MOVE LENGTH OF MIR-LTAXWH-MIN-TAX-AMT-T (WS-SUB)
                         TO L0290-MAX-OUT-LEN.
           MOVE 2                  TO L0290-PRECISION.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
                         TO MIR-LTAXWH-MIN-TAX-AMT-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RLTWR-MIN-NET-DSTRB-AMT * 100.
020874     MOVE RLTWR-MIN-NET-DSTRB-AMT
020874                             TO L0290-INPUT-V02.
           MOVE LENGTH OF MIR-MIN-NET-DSTRB-AMT-T (WS-SUB)
                        TO L0290-MAX-OUT-LEN.
           MOVE 2                  TO L0290-PRECISION.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA  TO MIR-MIN-NET-DSTRB-AMT-T (WS-SUB).

           MOVE RLTWR-LOC-GR-ID            TO MIR-LOC-GR-ID-T (WS-SUB).
           MOVE RLTWR-LTAXWH-DISB-CD
                        TO MIR-LTAXWH-DISB-CD-T (WS-SUB).
           MOVE RLTWR-LTAXWH-FILE-CD
                        TO MIR-LTAXWH-FILE-CD-T (WS-SUB).


       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET WS-MAX-LIST-LINES-DEFAULT  TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

034783 COPY XCPPINIT.
       COPY XCPPEXIT.
021930*COPY CCPEFILE.
021930*COPY CCPELCGP.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
021930*COPY XCPL0280.
       COPY XCPL0290.
       COPY XCPS0290.
021930*COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
018763*COPY XCPBDMAD.
018763*
021930*COPY CCPNEDIT.
      /
       COPY CCPBLTWR.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM5364
      *****************************************************************
