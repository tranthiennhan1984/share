      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3280.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3280                                         **
      **  REMARKS:  PAAR - POLICY ACTIVITY RELATIONSHIP TABLE        **
      **                   RETRIEVE                                  **
      **            THIS MODULE RETRIEVES THE PAAR TABLE             **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020460**  6.4       DTCC/IPS CONNECTIVITY                            **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
030054**  7.0       PHST SEQUENCE NUMBER EXPANSION                   **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3280'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

025970 01  WS-CONSTANT-AREA.
025970     05  WS-TWRK-KEY                  PIC X(04)
025970                                      VALUE '3280'.
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '3280'.
025970
       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-RETRIEVE      VALUE '3280'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '3280'.
           05  WS-KEY.
               10  WS-POL-ID                PIC X(10).
               10  WS-PAAFLD-GR-TS          PIC X(26).
               10  WS-PCHST-EFF-IDT-NUM     PIC X(07).
030054*        10  WS-PCHST-SEQ-NUM         PIC S9(03) COMP-3.
030054         10  WS-PCHST-SEQ-NUM         PIC S9(05) COMP-3.
030054*    05  WS-PCHST-SEQ-NUM-MAX         PIC S9(03) COMP-3.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY CCWWINDX.
030054 COPY XCWWCNST.
       COPY CCWWLOCK.
       COPY XCWWWKDT.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFWPAAR.
       COPY CCFRPAAR.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
       COPY CCWL2430.
028298 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1646.
       COPY XCWL1660.
       COPY XCWL8090.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3280.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.
023514
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

023514*    PERFORM  9990-INIT-WORKING-STORAGE
023514*        THRU 9990-INIT-WORKING-STORAGE-X.
023514*
           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM3280'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------

           PERFORM  5000-EDIT-KEY
               THRU 5000-EDIT-KEY-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  6000-BUILD-KEY
               THRU 6000-BUILD-KEY-X.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: POLICY @1 DOES NOT EXIST
               MOVE 'XS00000070'         TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY             TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  PAAR-1000-READ
               THRU PAAR-1000-READ-X.

           IF  NOT WPAAR-IO-OK
      *MSG:  REOCRD NOT FOUND
               MOVE 'XS00000001'         TO WGLOB-MSG-REF-INFO
               MOVE WPAAR-KEY            TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  9250-MOVE-OTHER-TO-SCREEN
               THRU 9250-MOVE-OTHER-TO-SCREEN-X.

      *MSG:'INQUIRE COMPLETED - CONTINUE'
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO.

           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *---------------------------
       5000-EDIT-KEY.
      *---------------------------

           IF  MIR-POL-ID = SPACES
      *MSG: POLICY ID IS MANDATORY FEILD
               MOVE 'CS32800001'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR           TO TRUE
               GO TO 5000-EDIT-KEY-X
           ELSE
               MOVE  MIR-POL-ID                 TO WS-POL-ID
           END-IF.

           MOVE MIR-PAAFLD-GR-TS                TO WS-PAAFLD-GR-TS.

           IF  MIR-PAAFLD-GR-TS = SPACES
               MOVE  WWKDT-ZERO-TS              TO WS-PAAFLD-GR-TS
           ELSE
               PERFORM  1646-1000-BUILD-PARM-INFO
                   THRU 1646-1000-BUILD-PARM-INFO-X
               MOVE MIR-PAAFLD-GR-TS           TO L1646-TIMESTAMP
               PERFORM  1646-1000-EDIT-TIMESTAMP
                   THRU 1646-1000-EDIT-TIMESTAMP-X
               IF  L1646-EDIT-FAILED
                   SET WGLOB-RETURN-ERROR TO  TRUE
      * MSG: INVALID TIMESTAMP
                   MOVE 'CS32800002'      TO  WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU  0260-1000-GENERATE-MESSAGE-X
                   MOVE  WWKDT-ZERO-TS    TO WS-PAAFLD-GR-TS
                   GO TO 5000-EDIT-KEY-X
              END-IF
           END-IF.

           MOVE MIR-PCHST-EFF-DT            TO L1640-EXTERNAL-DATE.
           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-RETRN-OK
               MOVE L1640-INTERNAL-DATE     TO L1660-INTERNAL-DATE
               PERFORM  1660-2000-CONVERT-INT-TO-INV
                   THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE     TO WS-PCHST-EFF-IDT-NUM
           ELSE
      *MSG: INVALID DATE
               MOVE 'CS32800003'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU  0260-1000-GENERATE-MESSAGE-X
               MOVE  ZEROS            TO WS-PCHST-EFF-IDT-NUM
               SET WGLOB-RETURN-ERROR TO  TRUE
               GO TO 5000-EDIT-KEY-X
           END-IF.

           MOVE ZERO                        TO L0280-PRECISION.
030054*    MOVE 3                           TO L0280-LENGTH.
030054*    MOVE 3                           TO L0280-INPUT-SIZE.
030054     MOVE LENGTH OF MIR-PCHST-SEQ-NUM TO L0280-LENGTH.
030054     MOVE LENGTH OF MIR-PCHST-SEQ-NUM TO L0280-INPUT-SIZE.
           MOVE MIR-PCHST-SEQ-NUM           TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
030054*        COMPUTE WS-PCHST-SEQ-NUM = WS-PCHST-SEQ-NUM-MAX
030054         COMPUTE WS-PCHST-SEQ-NUM = WCNST-MAX-PCHST-SEQ-NUM-N
                                        - L0280-OUTPUT
           ELSE
      * MSG: ' SEQUENCE NUMBER MUST BE NUMERIC
               MOVE 'CS32800004'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU  0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO  TRUE
               GO TO 5000-EDIT-KEY-X
           END-IF.

       5000-EDIT-KEY-X.
           EXIT.
      /
      *---------------
       6000-BUILD-KEY.
      *---------------

           MOVE WS-POL-ID              TO WPOL-POL-ID.
           MOVE WS-POL-ID              TO WPAAR-POL-ID.
           MOVE WS-PAAFLD-GR-TS        TO WPAAR-PAAFLD-GR-TS.
           MOVE WS-PCHST-EFF-IDT-NUM   TO WPAAR-PCHST-EFF-IDT-NUM.
           MOVE WS-PCHST-SEQ-NUM       TO WPAAR-PCHST-SEQ-NUM.

       6000-BUILD-KEY-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RPAAR-POL-ID               TO MIR-POL-ID.
           MOVE RPAAR-PAAFLD-GR-TS         TO MIR-PAAFLD-GR-TS.
           MOVE RPAAR-PCHST-EFF-IDT-NUM    TO L1660-INVERTED-DATE.
           PERFORM  1660-3000-CONVERT-INV-TO-INT
               THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE        TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE        TO MIR-PCHST-EFF-DT.
030054*    COMPUTE L0290-INPUT-V00   = WS-PCHST-SEQ-NUM-MAX
030054     COMPUTE L0290-INPUT-V00   = WCNST-MAX-PCHST-SEQ-NUM-N
                                     - RPAAR-PCHST-SEQ-NUM.
           MOVE 0                          TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PCHST-SEQ-NUM
                                           TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA          TO MIR-PCHST-SEQ-NUM.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9250-MOVE-OTHER-TO-SCREEN.
      *--------------------------

           MOVE RPOL-SBSDRY-CO-ID        TO MIR-SBSDRY-CO-ID.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           MOVE L2430-CLI-NM-COMPRESSED  TO MIR-DV-OWN-CLI-NM.

       9250-MOVE-OTHER-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1646-0000-INIT-PARM-INFO
025970         THRU 1646-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WWKDT-WORK-FIELDS.
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     SET  WS-TWRK-KEY-DEFAULT     TO TRUE.
           SET  MIR-RETRN-OK            TO TRUE.
           MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
030054*    MOVE 999                     TO WS-PCHST-SEQ-NUM-MAX.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL2430.
025970 COPY XCPS8090.
       COPY CCPS2430.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
       COPY XCPL8090.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
       COPY XCPS1646.
       COPY XCPL1646.
      /
025970 COPY XCPS1660.
       COPY XCPL1660.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPAAR.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM3080                     *
      ****************************************************************
