      *************************
       IDENTIFICATION DIVISION.
      *************************
       
       PROGRAM-ID.  CSOM7704.
       
       COPY XCWWCRHT.
       
      *****************************************************************
      **  MEMBER :  CSOM7704                                         **
      **  REMARKS:  CNTX BY POLICY ID                                **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
013697**  6.3       ROTH IRA / EDUCATIONAL IRA                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************
       
      ***************
       DATA DIVISION.
      ***************
       
       WORKING-STORAGE SECTION.
       
025970*COPY XCWWWKDT.
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7704'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
       
       COPY SQLCA.
       COPY XCWLDTLK.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
       
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04)  VALUE SPACES.
               88  WS-BUS-FCN-LIST                     VALUE '7704'.
025970*    05  WS-MAX-SCREEN-LINES          PIC 999 VALUE 50.
           05  WS-SUB-7704                  PIC 999.
           05  WS-CLIENT-FOUND-SW           PIC X(01).
               88  WS-CLIENT-FOUND          VALUE 'Y'.
               88  WS-NO-CLIENT-FOUND       VALUE 'N'.
           05  WS-ERROR-SW                  PIC X(01).
               88  WS-ERROR-FOUND           VALUE 'Y'.
               88  WS-NO-ERRORS-FOUND       VALUE 'N'.
           05  WS-FOUND-PRIMARY-SW                PIC X(01).
               88  WS-FOUND-PRIMARY               VALUE 'Y'.
               88  WS-NO-PRIMARY-EXISTS           VALUE 'N'.
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-SCREEN-LINES                PIC 999.
025970         88  WS-MAX-SCREEN-LINES-DEFAULT    VALUE 50.                 

      ************************************************************
      * COMMON WORKING STORAGE COPYBOOKS                         *
      ************************************************************
       
       COPY CCWWINDX.
025970 COPY XCWWWKDT.
       
      ************************************************************
      * FILE I/O WORKING STORAGE COPYBOOKS                       *
      ************************************************************
        
       COPY CCFRCNTX.
       COPY CCFWCNTY.
       
       COPY CCFRPOL.
       COPY CCFWPOL.
        
       COPY CCFRPOLC.
       COPY CCFWPOLC.
        
       COPY CCWL0620.
       COPY CCWL2430.
       
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
       
       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7704.
       
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
       
      *--------------
       0000-MAINLINE.
      *--------------
       
026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
       
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.
       
           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.
       
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.
       
026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.
       
       0000-MAINLINE-X.
           EXIT.
       
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------
       
           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.
       
           MOVE SPACES                TO MIR-OUTPUT-AREA.
            
           INITIALIZE L2430-OUTPUT-PARM-INFO.
           INITIALIZE RPOL-REC-INFO.
            
           SET WS-NO-ERRORS-FOUND      TO TRUE.
       
           PERFORM  2200-INITIAL-EDITS
               THRU 2200-INITIAL-EDITS-X.
       
           IF  WS-ERROR-FOUND
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2300-COMMON-LINE-SET
               THRU 2300-COMMON-LINE-SET-X.
           
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM 3000-PROCESS-LIST
                       THRU 3000-PROCESS-LIST-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7704'   TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *------------------------
       2200-INITIAL-EDITS.
      *------------------------

           MOVE MIR-POL-ID-BASE        TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX         TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-OK
               CONTINUE
           ELSE
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    POLICY RECORD NOT FOUND (@1)
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2200-INITIAL-EDITS-X.
           EXIT.
      
      *---------------------
       2300-COMMON-LINE-SET.
      *---------------------
      
           SET  WS-NO-CLIENT-FOUND TO TRUE.
       
      * READ AND FORMAT OWNERS NAME
       
           PERFORM  2320-GET-OWNER
               THRU 2320-GET-OWNER-X.
      
           INITIALIZE L0620-INPUT-PARM-INFO.
           IF L2430-CLI-SEX-COMPANY
               MOVE L2430-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
           ELSE
               MOVE L2430-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
               MOVE L2430-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
           END-IF.
           MOVE L2430-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           
           MOVE L0620-SCREEN-NAME     TO MIR-DV-OWN-CLI-NM.
           MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.
      
       2300-COMMON-LINE-SET-X.
           EXIT.
      
      *---------------
       2320-GET-OWNER.
      *---------------

           MOVE +0                    TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  MIR-POL-ID-BASE = SPACES
                 GO TO 2320-GET-OWNER-X
           END-IF.

           IF  L2430-CLI-ID = SPACES
               PERFORM  2400-CHECK-FOR-OWNER-CLI
                   THRU 2400-CHECK-FOR-OWNER-CLI-X
           ELSE
               IF  L2430-CLI-NM-COMPRESSED = SPACES
      *MSG:        POLICY OWNER CLIENT NAME IS BLANK FOR CLIENT (@1)
                   MOVE L2430-CLI-ID  TO WGLOB-MSG-PARM (1)
                   MOVE 'CS77040001'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       2320-GET-OWNER-X.
           EXIT.
       
      *-------------------------
       2400-CHECK-FOR-OWNER-CLI.
      *-------------------------
       
      * BUILD START/END BROWSE KEY
       
           MOVE LOW-VALUES            TO  WPOLC-KEY.
           MOVE RPOL-POL-ID           TO  WPOLC-POL-ID.
           MOVE 'O'                   TO  WPOLC-POL-CLI-REL-TYP-CD.

           MOVE WPOLC-KEY             TO  WPOLC-ENDBR-KEY.
           MOVE HIGH-VALUES           TO  WPOLC-ENDBR-CLI-ID.

      *  POSITION AT THE FIRST RECORD FOR THE GIVEN RELATIONSHIP
       
           PERFORM  POLC-1000-BROWSE
               THRU POLC-1000-BROWSE-X.

           IF  WPOLC-IO-OK
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
           END-IF.

           IF  WPOLC-IO-EOF
      * NO POLICY CLIENT RECORDS FOUND      
               MOVE 'CS77040002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-3000-END-BROWSE
                   THRU POLC-3000-END-BROWSE-X
               GO TO  2400-CHECK-FOR-OWNER-CLI-X
           END-IF.

           SET  WS-NO-PRIMARY-EXISTS TO TRUE.
           PERFORM  2500-DETERMINE-IF-PRIMARY
               THRU 2500-DETERMINE-IF-PRIMARY-X
               UNTIL WPOLC-IO-EOF
               OR    WS-FOUND-PRIMARY.

           IF  WS-NO-PRIMARY-EXISTS
      * PRIMARY POLICY OWNER IS NOT FOUND      
               MOVE 'CS77040003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-3000-END-BROWSE
                   THRU POLC-3000-END-BROWSE-X
               GO TO  2400-CHECK-FOR-OWNER-CLI-X
           END-IF.

           PERFORM  2600-FIND-OWNERS-LOOP
               THRU 2600-FIND-OWNERS-LOOP-X
               UNTIL WPOLC-IO-EOF.

           PERFORM  POLC-3000-END-BROWSE
               THRU POLC-3000-END-BROWSE-X.

       2400-CHECK-FOR-OWNER-CLI-X.
           EXIT.

      *--------------------------
       2500-DETERMINE-IF-PRIMARY.
      *--------------------------

           IF  RPOLC-POL-CLI-REL-SUB-CD = 'P'
               SET WS-FOUND-PRIMARY TO TRUE
               GO TO 2500-DETERMINE-IF-PRIMARY-X
           END-IF.

           PERFORM  POLC-2000-READ-NEXT
               THRU POLC-2000-READ-NEXT-X.

       2500-DETERMINE-IF-PRIMARY-X.
           EXIT.

      *----------------------
       2600-FIND-OWNERS-LOOP.
      *----------------------

           IF  RPOLC-POL-CLI-REL-SUB-CD NOT = 'P'
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
               GO TO 2600-FIND-OWNERS-LOOP-X
           END-IF.

           MOVE +0                    TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

      * WE HAVE FOUND THE REQUIRED RECORD, READ THE CLIENT FILE
       
           MOVE  RPOLC-CLI-ID         TO  L2430-CLI-ID.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  NOT L2430-RETRN-OK
               MOVE 'XS00000058'      TO WGLOB-MSG-REF-INFO
               MOVE L2430-CLI-ID      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POLC-2000-READ-NEXT
                   THRU POLC-2000-READ-NEXT-X
           END-IF.

       2600-FIND-OWNERS-LOOP-X.
           EXIT.
      
      *------------------
       3000-PROCESS-LIST.
      *------------------

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.
                      
           PERFORM  CNTY-1000-BROWSE
               THRU CNTY-1000-BROWSE-X.
               
           PERFORM  CNTY-2000-READ-NEXT
               THRU CNTY-2000-READ-NEXT-X.

           IF  WCNTY-IO-EOF
      * NO RECORDS FOUND     
               MOVE 'CS77040004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  CNTY-3000-END-BROWSE
                   THRU CNTY-3000-END-BROWSE-X
               GO TO 3000-PROCESS-LIST-X
           END-IF.

           PERFORM  3210-BUILD-LIST-SCREEN
               THRU 3210-BUILD-LIST-SCREEN-X
               VARYING WS-SUB-7704 FROM 1 BY 1
               UNTIL   WS-SUB-7704 > WS-MAX-SCREEN-LINES
               OR WCNTY-IO-EOF.

           IF  WCNTY-IO-EOF
               MOVE 'XS00000015'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  3220-BUILD-NEXT-LIST-KEY
                   THRU 3220-BUILD-NEXT-LIST-KEY-X
           END-IF.

           PERFORM  CNTY-3000-END-BROWSE
               THRU CNTY-3000-END-BROWSE-X.

       3000-PROCESS-LIST-X.
           EXIT.

      *-----------------------
       3210-BUILD-LIST-SCREEN.
      *-----------------------

           PERFORM  3215-MOVE-CNTX-TO-LIST-ROW
               THRU 3215-MOVE-CNTX-TO-LIST-ROW-X.

           PERFORM  CNTY-2000-READ-NEXT
               THRU CNTY-2000-READ-NEXT-X.

       3210-BUILD-LIST-SCREEN-X.
             EXIT.

      *---------------------------
       3215-MOVE-CNTX-TO-LIST-ROW.
      *---------------------------
    
           MOVE RCNTX-CNTRXN-SEQ-NUM      TO 
                MIR-CNTRXN-SEQ-NUM-T(WS-SUB-7704).
    
           MOVE RCNTX-CNTRXN-TS           TO 
                MIR-CNTRXN-TS-T(WS-SUB-7704).

           MOVE RCNTX-CNTRXN-TYP-CD       TO 
                MIR-CNTRXN-TYP-CD-T(WS-SUB-7704).

           MOVE RCNTX-CNTRXN-TAX-YR       TO
                MIR-CNTRXN-TAX-YR-T(WS-SUB-7704).

020874*    COMPUTE L0290-INPUT-NUMBER = RCNTX-CNTRXN-AMT * 100.
020874     MOVE RCNTX-CNTRXN-AMT          TO L0290-INPUT-V02.
           MOVE 2                         TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CNTRXN-AMT-T (WS-SUB-7704)
                                          TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA         TO 
                MIR-CNTRXN-AMT-T (WS-SUB-7704).

           MOVE RCNTX-CNTRXN-RPT-CD       TO 
                MIR-CNTRXN-RPT-CD-T(WS-SUB-7704).

           MOVE RCNTX-CNTRXN-STAT-CD      TO 
                MIR-CNTRXN-STAT-CD-T(WS-SUB-7704).

           IF RCNTX-CNTRXN-COMNT-TXT-TXT NOT = SPACES
              MOVE 'Y'                    TO
                MIR-DV-CNTRXN-COMNT-IND-T(WS-SUB-7704)
           ELSE
              MOVE 'N'                    TO
                MIR-DV-CNTRXN-COMNT-IND-T(WS-SUB-7704)
           END-IF.
           
           MOVE RCNTX-CDA-EFF-IDT-NUM     TO L1660-INVERTED-DATE.
           
           PERFORM 1660-3000-CONVERT-INV-TO-INT
              THRU 1660-3000-CONVERT-INV-TO-INT-X.
                
           MOVE L1660-INTERNAL-DATE      TO L1640-INTERNAL-DATE.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CDA-EFF-DT-T (WS-SUB-7704).
           
           MOVE SPACES TO RCNTX-REC-INFO.

       3215-MOVE-CNTX-TO-LIST-ROW-X.
           EXIT.

      *-------------------------
       3220-BUILD-NEXT-LIST-KEY.
      *-------------------------

           MOVE RCNTX-CDA-EFF-IDT-NUM   TO L1660-INVERTED-DATE.
           
           PERFORM 1660-3000-CONVERT-INV-TO-INT
              THRU 1660-3000-CONVERT-INV-TO-INT-X.
                
           MOVE L1660-INTERNAL-DATE     TO L1640-INTERNAL-DATE.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE     TO MIR-CDA-EFF-DT.

           MOVE RCNTX-CNTRXN-SEQ-NUM    TO MIR-CNTRXN-SEQ-NUM.

           MOVE RCNTX-CNTRXN-TS         TO MIR-CNTRXN-TS.

           SET  WGLOB-MORE-DATA-EXISTS  TO TRUE.

           MOVE 'XS00000014'            TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
               
       3220-BUILD-NEXT-LIST-KEY-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE SPACES TO RCNTX-REC-INFO.

           MOVE LOW-VALUES        TO WCNTY-KEY.
           MOVE MIR-POL-ID-BASE   TO WCNTY-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX    TO WCNTY-POL-ID-SFX.

           IF  MIR-CDA-EFF-DT            = SPACES
               MOVE ZEROES               TO WCNTY-CDA-EFF-IDT-NUM
           ELSE
               MOVE MIR-CDA-EFF-DT       TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X
               MOVE L1640-INTERNAL-DATE  TO L1660-INTERNAL-DATE
               PERFORM 1660-2000-CONVERT-INT-TO-INV
                  THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE  TO WCNTY-CDA-EFF-IDT-NUM
           END-IF.
           
           IF MIR-CNTRXN-SEQ-NUM       = SPACES
              MOVE ZERO                TO WCNTY-CNTRXN-SEQ-NUM
           ELSE   
              MOVE MIR-CNTRXN-SEQ-NUM  TO WCNTY-CNTRXN-SEQ-NUM
           END-IF.
           
           IF MIR-CNTRXN-TS       = SPACES
              MOVE WWKDT-LOW-TS   TO WCNTY-CNTRXN-TS
           ELSE   
              MOVE MIR-CNTRXN-TS  TO WCNTY-CNTRXN-TS
           END-IF.
           
           MOVE HIGH-VALUES       TO WCNTY-ENDBR-KEY.
           MOVE MIR-POL-ID-BASE   TO WCNTY-ENDBR-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX    TO WCNTY-ENDBR-POL-ID-SFX.
           MOVE 9999999           TO WCNTY-ENDBR-CDA-EFF-IDT-NUM.
           MOVE WWKDT-HIGH-TS     TO WCNTY-ENDBR-CNTRXN-TS.
           MOVE 9                 TO WCNTY-ENDBR-CNTRXN-SEQ-NUM.
        
       7000-BUILD-KEYS-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970
025970     SET WS-MAX-SCREEN-LINES-DEFAULT TO TRUE.
025970
025970     MOVE SPACES                TO WWKDT-WORK-FIELDS.
025970
025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS
      *****************************************************************
        
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
       
      *****************************************************************
      *  LINKAGE COPYBOOKS
      *****************************************************************
       
       COPY XCPL0260.
       
       COPY XCPL0290.
       COPY XCPS0290.
       
025970 COPY CCPS0620.
       COPY CCPL0620.
       
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
       
       COPY CCPS2430.
       COPY CCPL2430.
        
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       
       COPY CCPBCNTY.
        
       COPY CCPNPOL.
        
       COPY CCPBPOLC.
       
      *****************************************************************
      *  ERROR PROCESSING COPYPBOOKS
      *****************************************************************
       
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
       
      *****************************************************************
      **                 END OF PROGRAM CSOM7704                     **
      *****************************************************************
