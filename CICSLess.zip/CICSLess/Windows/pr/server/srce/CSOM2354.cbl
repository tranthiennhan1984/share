      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2354.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2354                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE BROWSE FUNCTION OF      **
      **            DAIRY/ACTIVITY LOG FOR POLCIY/APPLICATION BY     **
      **            AN AUTHORIZED USER.                              **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       ORIGINAL - NEW FOR RELEASE 6.0                   **
015543**  6.0       CODE CLEANUP                                     **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
015703**  6.4       REMOVE CCWLPGA                                   **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021620**  6.4       CODE CLEAN-UP AND STANDARDIZATION                **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2354'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.
       COPY XCWWTIME.
       COPY XCWWCVGM.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID               PIC X(04).
               88  WS-BUS-POL-LIST         VALUE '2354'.

       01  WS-FCN-WORK-AREA.
           05  WS-SWITCHES.
               10  WS-KEY-FIELDS-OK-SW      PIC X(01).
                   88  WS-KEY-FIELDS-OK         VALUE 'Y'.
                   88  WS-KEY-FIELDS-NOT-OK     VALUE 'N'.
           05  WS-SUBSCRIPT.
016548*        10  WS-SUB                   PIC S9(04) COMP.
016548         10  WS-SUB                   PIC S9(04) BINARY.
016548*        10  WS-POL-INS-SUB           PIC S9(04) COMP.
016548         10  WS-POL-INS-SUB           PIC S9(04) BINARY.
           05  WS-LINE                      PIC 9(02).
025970*    05  WS-MAX-LINES                 PIC 9(02) VALUE 25.
025970*    05  WS-MAX-INSURED               PIC 9(02) VALUE 10.
           05  WS-RDALG-KEY.
               10  WS-RDALG-ID              PIC X(06).
               10  WS-RDALG-NUM             PIC X(04).
           05  WS-POL-ID.
               10  WS-POL-ID-BASE           PIC X(09).
               10  WS-POL-ID-SFX            PIC X(01).
           05  WS-SEQ-NO                    PIC X(03).
           05  WS-PIC-99                    PIC 9(02).
           05  WS-PIC-999                   PIC 9(03).
           05  WS-POLICY-BROWSE-KEY         PIC X(50).
           05  WS-FORMAT-TIME.
               10  WS-FORMAT-HH             PIC X(02).
               10  WS-FORMAT-MM             PIC X(02).
               10  WS-FORMAT-SS             PIC X(02).
           05  WS-POL-INS-TABLE.
               10  WS-POL-INFO              OCCURS 10 TIMES.
                   15  WS-POL-INS           PIC X(10).

025970 01  WS-CONSTANT-FIELDS.
025970     05  WS-MAX-LINES                  PIC 9(02).
025970         88  WS-MAX-LINES-DEFAULT      VALUE 25.
025970     05  WS-MAX-INSURED                PIC 9(02).
025970         88  WS-MAX-INSURED-DEFAULT    VALUE 10.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
016537*COPY CCWWFRMT.
016537*COPY XCWEBLCH.
       COPY XCWWWKDT.
026057 COPY CCWWIHSD.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
021930*COPY CCFWCVG.
021930*COPY CCFRCVG.
021930*
       COPY CCFWCVGC.
       COPY CCFRCVGC.
      /
       COPY NCFWDALG.
       COPY NCFRDALG.
      /
021930*COPY CCFWEDIT.
021930*COPY CCFREDIT.
021930*
015703*COPY CCWLPGA.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
       COPY CCWL5400.
       COPY XCWL0280.
020874 COPY XCWL0290.
       COPY XCWL1640.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
      /
       COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2354.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           SET MIR-RETRN-OK                  TO  TRUE.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           IF  MIR-CPEVNT-TRXN-DT NOT > SPACES
               PERFORM  1200-DEFAULT-DATE
                   THRU 1200-DEFAULT-DATE-X
           END-IF.

           MOVE SPACES                  TO  WS-FORMAT-TIME.
           MOVE MIR-CPEVNT-TRXN-TIME    TO  WS-FORMAT-TIME.

           IF  WS-FORMAT-TIME NOT > SPACES
               PERFORM  1400-DEFAULT-TIME
                   THRU 1400-DEFAULT-TIME-X
           END-IF.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           MOVE MIR-BUS-FCN-ID    TO  WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-POL-LIST
                    PERFORM  2000-PROCESS-LIST
                        THRU 2000-PROCESS-LIST-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID           TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2354'               TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST     TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------------
       1200-DEFAULT-DATE.
      *------------------

           MOVE WGLOB-SYSTEM-DATE-INT TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CPEVNT-TRXN-DT.

       1200-DEFAULT-DATE-X.
           EXIT.
      *------------------
       1400-DEFAULT-TIME.
      *------------------

           MOVE WGLOB-SYSTEM-TIME     TO WTIME-EDIT-TIME.
           MOVE WTIME-EDIT-HH         TO WS-FORMAT-HH.
           MOVE WTIME-EDIT-MM         TO WS-FORMAT-MM.
           MOVE WTIME-EDIT-SS         TO WS-FORMAT-SS.
           MOVE WS-FORMAT-TIME        TO MIR-CPEVNT-TRXN-TIME.

       1400-DEFAULT-TIME-X.
           EXIT.
      /
      *-----------------
       2000-PROCESS-LIST.
      *-----------------

           PERFORM  2200-VALIDATE-KEY-FIELDS
               THRU 2200-VALIDATE-KEY-FIELDS-X.

           IF  NOT WS-KEY-FIELDS-OK
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-LIST-X
           END-IF.

           PERFORM  4000-BUILD-RELA-DISPLAY
               THRU 4000-BUILD-RELA-DISPLAY-X.

           MOVE ZEROS                      TO  WS-LINE.
           MOVE HIGH-VALUES                TO  WDALG-KEY.
           PERFORM  7000-BUILD-DALG-BROWSE-KEY
               THRU 7000-BUILD-DALG-BROWSE-KEY-X.

           PERFORM  4200-POLICY-LIST
               THRU 4200-POLICY-LIST-X.

       2000-PROCESS-LIST-X.
           EXIT.
      /
      *--------------------
       2200-VALIDATE-KEY-FIELDS.
      *--------------------

           SET WS-KEY-FIELDS-OK             TO  TRUE.

           IF MIR-CPEVNT-SEQ-NUM = SPACES
              MOVE '999'                   TO  MIR-CPEVNT-SEQ-NUM
           END-IF.

           PERFORM  3000-EDIT-POLICY-NUM
               THRU 3000-EDIT-POLICY-NUM-X.

           PERFORM  3100-EDIT-FORMAT-DATE
               THRU 3100-EDIT-FORMAT-DATE-X.

           PERFORM  3200-EDIT-FORMAT-TIME
               THRU 3200-EDIT-FORMAT-TIME-X.

           PERFORM  3300-EDIT-SEQUENCE-NUM
               THRU 3300-EDIT-SEQUENCE-NUM-X.

       2200-VALIDATE-KEY-FIELDS-X.
           EXIT.
      /
      *---------------------
       3000-EDIT-POLICY-NUM.
      *---------------------

           IF  (MIR-CPEVNT-POL-CLI-ID-BASE = SPACES)
           AND (MIR-CPEVNT-POL-CLI-ID-SFX = SPACES)
               MOVE 'CS23540001'               TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-KEY-FIELDS-NOT-OK TO TRUE
               GO TO 3000-EDIT-POLICY-NUM-X
           END-IF.

           MOVE MIR-CPEVNT-POL-CLI-ID-BASE TO WPOL-POL-ID-BASE.
           MOVE MIR-CPEVNT-POL-CLI-ID-SFX  TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF WPOL-IO-OK
               CONTINUE
           ELSE
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-KEY-FIELDS-NOT-OK TO TRUE
               GO TO 3000-EDIT-POLICY-NUM-X
           END-IF.

      * VERIFY POLICY ACCESS

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-STAT-MSG-NOT-REQD   TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
               SET WS-KEY-FIELDS-NOT-OK TO TRUE
            END-IF.

       3000-EDIT-POLICY-NUM-X.
           EXIT.
      /
      *----------------------
       3100-EDIT-FORMAT-DATE.
      *----------------------

           MOVE MIR-CPEVNT-TRXN-DT    TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-NOT-VALID
               MOVE MIR-CPEVNT-TRXN-DT             TO WGLOB-MSG-PARM (1)
               MOVE 'CS23540002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-KEY-FIELDS-NOT-OK TO TRUE
               GO TO 3100-EDIT-FORMAT-DATE-X
           END-IF.

           IF L1640-INTERNAL-DATE > WGLOB-SYSTEM-DATE-INT
               MOVE 'CS23540003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-KEY-FIELDS-NOT-OK TO TRUE
026057         GO TO 3100-EDIT-FORMAT-DATE-X
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE L1640-INTERNAL-DATE   TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057         SET WS-KEY-FIELDS-NOT-OK TO TRUE
026057     END-IF.

       3100-EDIT-FORMAT-DATE-X.
           EXIT.
      /
      *----------------------
       3200-EDIT-FORMAT-TIME.
      *----------------------

           MOVE MIR-CPEVNT-TRXN-TIME  TO WS-FORMAT-TIME.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 6                     TO L0280-LENGTH.
           MOVE 6                     TO L0280-INPUT-SIZE.
           MOVE WS-FORMAT-TIME        TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF NOT L0280-OK
               MOVE 'CS23540004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-KEY-FIELDS-NOT-OK TO TRUE
           END-IF.

       3200-EDIT-FORMAT-TIME-X.
           EXIT.
      /
      *-----------------------
       3300-EDIT-SEQUENCE-NUM.
      *-----------------------

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE MIR-CPEVNT-SEQ-NUM    TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-SEQ-NO
           ELSE
               MOVE 'CS23540005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-KEY-FIELDS-NOT-OK TO TRUE
               GO TO 3300-EDIT-SEQUENCE-NUM-X
           END-IF.

       3300-EDIT-SEQUENCE-NUM-X.
           EXIT.
      /
      *------------------------
       4000-BUILD-RELA-DISPLAY.
      *------------------------

           MOVE SPACES                TO WS-POL-INS-TABLE.
           MOVE ZERO                  TO WS-POL-INS-SUB.

021930*    MOVE RPOL-POL-ID       TO WCVG-POL-ID.
           PERFORM  4100-READ-ALL-COV-CLIENTS
               THRU 4100-READ-ALL-COV-CLIENTS-X.

           PERFORM
               VARYING  WS-SUB FROM +1 BY +1
               UNTIL  WS-SUB > WS-MAX-INSURED
               MOVE WS-POL-INS (WS-SUB) TO MIR-INSRD-CLI-ID-T (WS-SUB)
           END-PERFORM.

       4000-BUILD-RELA-DISPLAY-X.
           EXIT.
      /
      *--------------------------
       4100-READ-ALL-COV-CLIENTS.
      *--------------------------

           MOVE LOW-VALUES            TO  WCVGC-KEY.
           MOVE RPOL-POL-ID           TO  WCVGC-POL-ID.
           MOVE ZEROS                 TO  WCVGC-CVG-NUM-N.
015904*    MOVE SPACES                TO  MIR-DV-ADDL-CLI-IND.

           MOVE WCVGC-KEY             TO  WCVGC-ENDBR-KEY.
           MOVE WCVGM-MAX-WCVGS-NUM   TO  WCVGC-ENDBR-CVG-NUM-N.
           MOVE HIGH-VALUES       TO  WCVGC-ENDBR-CVG-CLI-REL-TYP-CD.
           MOVE HIGH-VALUES           TO  WCVGC-ENDBR-INSRD-CLI-ID.

           PERFORM  CVGC-1000-BROWSE
               THRU CVGC-1000-BROWSE-X.

           IF  WCVGC-IO-OK
               PERFORM  CVGC-2000-READ-NEXT
                   THRU CVGC-2000-READ-NEXT-X
               PERFORM  4120-MOVE-INSUREDS
                   THRU 4120-MOVE-INSUREDS-X
                  UNTIL  WCVGC-IO-EOF
                     OR  (WS-POL-INS-SUB > WS-MAX-INSURED)
               PERFORM  CVGC-3000-END-BROWSE
                   THRU CVGC-3000-END-BROWSE-X
           END-IF.

       4100-READ-ALL-COV-CLIENTS-X.
           EXIT.
      /
      *-------------------
       4120-MOVE-INSUREDS.
      *-------------------

           PERFORM
               VARYING WS-SUB FROM +1 BY +1
               UNTIL  (WS-SUB > WS-POL-INS-SUB)
               OR (RCVGC-INSRD-CLI-ID  =  WS-POL-INS (WS-SUB))
015543         CONTINUE
           END-PERFORM.


           IF  WS-SUB      >  WS-POL-INS-SUB
               ADD 1       TO WS-POL-INS-SUB
               IF WS-POL-INS-SUB > WS-MAX-INSURED
015904*           MOVE '*'              TO  MIR-DV-ADDL-CLI-IND
                  GO TO 4120-MOVE-INSUREDS-X
               ELSE
                  MOVE RCVGC-INSRD-CLI-ID TO WS-POL-INS (WS-POL-INS-SUB)
               END-IF
           END-IF.

           PERFORM  CVGC-2000-READ-NEXT
               THRU CVGC-2000-READ-NEXT-X.

       4120-MOVE-INSUREDS-X.
           EXIT.
      /
      *----------------
       4200-POLICY-LIST.
      *----------------

           MOVE ZEROS                 TO WS-LINE.
           MOVE WS-POLICY-BROWSE-KEY  TO WDALG-KEY.
           MOVE WS-POLICY-BROWSE-KEY  TO RDALG-KEY.
           MOVE LOW-VALUES            TO WDALG-ENDBR-KEY.
           MOVE WWKDT-LOW-DT          TO WDALG-ENDBR-CPEVNT-TRXN-DT.
           MOVE WDALG-CPEVNT-POL-CLI-CD
                                      TO WDALG-ENDBR-CPEVNT-POL-CLI-CD.
           MOVE WDALG-CPEVNT-POL-CLI-ID
                                      TO WDALG-ENDBR-CPEVNT-POL-CLI-ID.

      ***  BEGIN BROWSE PREVIOUS
           PERFORM  DALG-1000-BROWSE-PREV
               THRU DALG-1000-BROWSE-PREV-X.

           IF WDALG-IO-OK
           PERFORM  DALG-2000-READ-PREV
               THRU DALG-2000-READ-PREV-X
           END-IF.

           IF NOT WDALG-IO-OK
           OR WDALG-IO-EOF
      *MSG:  'NO RECORDS FOUND TO DISPLAY'
              MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              PERFORM  DALG-3000-END-BROWSE-PREV
                   THRU DALG-3000-END-BROWSE-PREV-X
               GO TO 4200-POLICY-LIST-X
           END-IF.

      ***      LOAD SCREEN DATA

           PERFORM  4220-DISPLAY-RECORD
               THRU 4220-DISPLAY-RECORD-X
               UNTIL (WDALG-IO-EOF)
               OR (WS-LINE > WS-MAX-LINES).

           IF WDALG-IO-EOF
               MOVE 'XS00000015'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE RDALG-CPEVNT-TRXN-DT  TO  L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X                   
               MOVE L1640-EXTERNAL-DATE  TO  MIR-CPEVNT-TRXN-DT
               MOVE RDALG-CPEVNT-TRXN-TIME   TO WS-FORMAT-TIME
               MOVE WS-FORMAT-TIME           TO MIR-CPEVNT-TRXN-TIME
               MOVE RDALG-CPEVNT-SEQ-NUM     TO  MIR-CPEVNT-SEQ-NUM
               MOVE RDALG-CPEVNT-GR-CD       TO  MIR-CPEVNT-GR-CD
               MOVE RDALG-EVNT-ACTV-CD       TO  MIR-EVNT-ACTV-CD
               SET WGLOB-MORE-DATA-EXISTS    TO  TRUE
               MOVE 'XS00000014'             TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      ***  FINISH BROWSE PREV
           PERFORM  DALG-3000-END-BROWSE-PREV
               THRU DALG-3000-END-BROWSE-PREV-X.

       4200-POLICY-LIST-X.
           EXIT.
      /
      *-------------------
       4220-DISPLAY-RECORD.
      *-------------------

      ***  IF DALG SECURITY NOT PASSED, READ ANOTHER RECORD AND EXIT.
           IF RDALG-CPEVNT-SECUR-CD  > WGLOB-SECUR-LVL-CD
                PERFORM  DALG-2000-READ-PREV
                    THRU DALG-2000-READ-PREV-X
                GO TO 4220-DISPLAY-RECORD-X
           ELSE
               ADD  1  TO  WS-LINE
               IF WS-LINE > WS-MAX-LINES
                  GO TO 4220-DISPLAY-RECORD-X
               ELSE
                  PERFORM  4222-MOVE-REC-TO-SCREEN
                      THRU 4222-MOVE-REC-TO-SCREEN-X
               END-IF
           END-IF.

           PERFORM  DALG-2000-READ-PREV
               THRU DALG-2000-READ-PREV-X.

       4220-DISPLAY-RECORD-X.
           EXIT.
      /
      *-----------------------
       4222-MOVE-REC-TO-SCREEN.
      *-----------------------

           MOVE RDALG-CPEVNT-POL-CLI-ID
                                 TO MIR-CPEVNT-POL-CLI-ID-T (WS-LINE).
           MOVE RDALG-CPEVNT-TRXN-DT
                                 TO  L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
                                 TO  MIR-CPEVNT-TRXN-DT-T (WS-LINE).
           MOVE RDALG-CPEVNT-TRXN-TIME
                                 TO  WS-FORMAT-TIME.
           MOVE WS-FORMAT-TIME   TO  MIR-CPEVNT-TRXN-TIME-T (WS-LINE).
020874*    MOVE RDALG-CPEVNT-SEQ-NUM
020874*                          TO  WS-PIC-999.
020874*    MOVE WS-PIC-999           TO  MIR-CPEVNT-SEQ-NUM-T (WS-LINE).
020874     MOVE RDALG-CPEVNT-SEQ-NUM  TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CPEVNT-SEQ-NUM-T (WS-LINE)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CPEVNT-SEQ-NUM-T (WS-LINE).
           MOVE RDALG-CPEVNT-GR-CD   TO  MIR-CPEVNT-GR-CD-T (WS-LINE).
           MOVE RDALG-EVNT-ACTV-CD   TO  MIR-EVNT-ACTV-CD-T (WS-LINE).
           MOVE RDALG-EVNT-ACT-CD    TO  MIR-EVNT-ACT-CD-T (WS-LINE).
           MOVE RDALG-CVG-NUM        TO  MIR-CVG-NUM-T (WS-LINE).
           MOVE RDALG-CPEVNT-SRC-CD  TO  MIR-CPEVNT-SRC-CD-T (WS-LINE).
           MOVE RDALG-BUS-FCN-ID     TO  MIR-BUS-FCN-ID-T (WS-LINE).
           MOVE RDALG-USER-ID        TO  MIR-USER-ID-T (WS-LINE).
           MOVE RDALG-MSG-REF-ID     TO  WS-RDALG-ID.
           MOVE RDALG-MSG-REF-NUM    TO  WS-RDALG-NUM.
           MOVE WS-RDALG-KEY         TO  WGLOB-MSG-REF-INFO.
           MOVE RDALG-CPEVNT-PARM-1-TXT
                                     TO  WGLOB-MSG-PARM (1).
           MOVE RDALG-CPEVNT-PARM-2-TXT
                                     TO  WGLOB-MSG-PARM (2).
           MOVE RDALG-CPEVNT-PARM-3-TXT
                                     TO  WGLOB-MSG-PARM (3).
           MOVE RDALG-CPEVNT-PARM-4-TXT
                                     TO  WGLOB-MSG-PARM (4).
           PERFORM  0260-2000-GET-MESSAGE
               THRU 0260-2000-GET-MESSAGE-X.
015904*    MOVE WGLOB-MSG-TXT      TO MIR-DV-MSG-TXT-T (WS-LINE).
015904     MOVE WGLOB-MSG-TXT      TO MIR-MSG-TXT-T (WS-LINE).

       4222-MOVE-REC-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       7000-BUILD-DALG-BROWSE-KEY.
      *--------------------------
      *
      *  BUILD THE RECORD KEY FROM THE MIR FIELDS
      *

           MOVE SPACES                TO WS-POLICY-BROWSE-KEY.

           MOVE 'P'                   TO WDALG-CPEVNT-POL-CLI-CD.
           MOVE MIR-CPEVNT-POL-CLI-ID-BASE
                                      TO WS-POL-ID-BASE.
           MOVE MIR-CPEVNT-POL-CLI-ID-SFX
                                      TO WS-POL-ID-SFX.
           MOVE WS-POL-ID             TO WDALG-CPEVNT-POL-CLI-ID.
           MOVE MIR-CPEVNT-TRXN-DT    TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE   TO  WDALG-CPEVNT-TRXN-DT.
021620*    MOVE MIR-CPEVNT-GR-CD      TO  MIR-CPEVNT-GR-CD.
021620*    MOVE MIR-EVNT-ACTV-CD      TO  MIR-EVNT-ACTV-CD.
           MOVE MIR-CPEVNT-TRXN-TIME  TO  WS-FORMAT-TIME.
           MOVE WS-FORMAT-TIME        TO  WDALG-CPEVNT-TRXN-TIME.
           MOVE MIR-CPEVNT-SEQ-NUM    TO  WDALG-CPEVNT-SEQ-NUM.
           MOVE WDALG-KEY             TO  WS-POLICY-BROWSE-KEY.

       7000-BUILD-DALG-BROWSE-KEY-X.
           EXIT.
      /
      *----------------------
       9100-BLANK-DATA-FIELDS.
      *----------------------

           MOVE SPACES             TO  MIR-INSRD-CLI-ID-G.
015904*    MOVE SPACES             TO  MIR-DV-ADDL-CLI-IND.
           MOVE SPACES             TO  MIR-CPEVNT-POL-CLI-ID-G.
           MOVE SPACES             TO  MIR-CPEVNT-TRXN-DT.
           MOVE SPACES             TO  MIR-CPEVNT-TRXN-TIME-G.
           MOVE SPACES             TO  MIR-CPEVNT-SEQ-NUM-G.
           MOVE SPACES             TO  MIR-CPEVNT-GR-CD-G.
           MOVE SPACES             TO  MIR-EVNT-ACTV-CD-G.
           MOVE SPACES             TO  MIR-EVNT-ACT-CD-G.
           MOVE SPACES             TO  MIR-CVG-NUM-G.
           MOVE SPACES             TO  MIR-CPEVNT-SRC-CD-G.
           MOVE SPACES             TO  MIR-BUS-FCN-ID-G.
           MOVE SPACES             TO  MIR-USER-ID-G.
015904*    MOVE SPACES             TO  MIR-DV-MSG-TXT-G.
015904     MOVE SPACES             TO  MIR-MSG-TXT-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE       WS-WORKING-STORAGE.
025970     INITIALIZE       WS-FCN-WORK-AREA.
025970
025970     SET WS-MAX-LINES-DEFAULT        TO TRUE. 
025970     SET WS-MAX-INSURED-DEFAULT      TO TRUE. 
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
      /
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
026057 COPY CCPPIHSD.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
      /
016537*COPY NCPEACTN.
016537*COPY NCPEACTV.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS1670.
025970 COPY XCPS0280.
       COPY XCPL0280.
020874 COPY XCPL0290.
020874 COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
      /
       COPY CCPNPOL.
      /
016537*COPY CCPNCVG.
      /
       COPY CCPBCVGC.
      /
021930*COPY CCPNEDIT.
021930*
016537*COPY NCPADALG.
016537*COPY NCPBDALG.
016537*COPY NCPCDALG.
016537*COPY NCPNDALG.
016537*COPY NCPUDALG.
       COPY NCPVDALG.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2354                     **
      *****************************************************************
