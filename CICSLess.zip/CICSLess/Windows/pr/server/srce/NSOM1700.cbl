
      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM1700.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM1700                                         **
      **  REMARKS:  MIBQ: PROCESS INQUIRY ON THE MIB INFORMATION FOR **
      **            A GIVEN CLIENT ID.                               **
      **            THE MIBQ TRANSACTION DISPLAYS MIB SERACH RESULTS **
      **            FOR A GIVEN CLIENT ID AND A SEQUENCE NUMBER.     **
      **            MIB PRIMARY AND ALTERNATE INFORMATION IS         **
      **            DISPLAYED. PRIMARY INFORMATION IS THAT WHICH     **
      **            MIB WAS ABLE TO EXACTLY OR CLOSELY MATCH TO THE  **
      **            ORIGINAL SEARCH CRITERIA PROVIDED SUCH AS CLIENT **
      **            NAME AND BIRTHDATE. ALTERNATE INFORMATION MAY    **
      **            BE FURTHER MIB CODES OR ADDITIONAL DETAILS       **
      **            REGARDING POSSIBLE MATCHES.                      **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557698**  5.5       MIXED CASE SUPPORT                               **
557708**  5.5       ABEND HANDLING                                   **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016387**  6.2       REMOVE FUSE SUPPORT                              **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
015703**  6.4       REMOVE CCWLPGA                                   **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM1700'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
           05  WS-ARRAY-SUB                 PIC 9(02).
           05  WS-SCRN                      PIC 9(02).
016548*    05  WS-DISPLAY-FILE              PIC S9(04) COMP.
016548     05  WS-DISPLAY-FILE              PIC S9(04) BINARY.
025970*    05  WS-DISPLAY-MAX               PIC 9(02) VALUE 16.
           05  WS-CONTROL-ERROR-CD          PIC X.
               88  WS-CONTROL-ERROR         VALUE 'Y'.
           05  WS-CLIENT-CHANGED-CD         PIC X.
               88  WS-CLIENT-CHANGED        VALUE 'Y'.
           05  WS-CLIENT-NUMBER             PIC X(10).
           05  WS-SEQUENCE-NO               PIC 9(03).
025970*
025970 01  WS-CONSTANTS.
025970     05  WS-DISPLAY-MAX               PIC 9(02).
025970         88  WS-DEFAULT-DISPLAY-MAX             VALUE 16.
      *
016537*COPY XCWWWKDT.
      *
028298 COPY CCWL2626.
       COPY CCWL5600.
       COPY NCWL2437.
       COPY XCWL0280.
       COPY XCWL1640.
       COPY XCWLDTLK.
      *
       COPY NCFWMIBT.
       COPY NCFRMIBT.
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
015703*COPY CCWLPGA.
016537*COPY CCFRPOL.
016537*COPY CCWWCVGS.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM1700.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------


026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM EXIT-1000-FINALIZE
              THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      *
      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------

      ******************************************************************
      *   NORMAL PROCESSING: INITIALISE VARIABLES AND VALIDATE THE
      *   CONTROL FIELDS
      ******************************************************************

      *
      *  INITIALISE VARIABLES NEEDED FOR THIS TRANSACTION
      *
           PERFORM  2100-INITIALISE
               THRU 2100-INITIALISE-X.

      *
      *  VALIDATE THE CONTROL FIELDS ENTERED
      *
           PERFORM  2200-VALIDATE-CONTROL-FIELDS
               THRU 2200-VALIDATE-CONTROL-FIELDS-X.
           IF WS-CONTROL-ERROR
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

      *
      *  PROCESS INQUIRE TRANSACTION WHEN NO ERRORS IN VALIDATION
      *
           PERFORM 3000-PROCESS-RETRIEVE
              THRU 3000-PROCESS-RETRIEVE-X.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *----------------
       2100-INITIALISE.
      *----------------

      ****************************************************************
      *  INITIALISE: INITIALISE MISCELLANEOUS VARIABLES NEEDED FOR
      *  PROCESSING IN THIS TRANSACTION.
      ****************************************************************

      *  SET UP MESSAGE VARIABLES
      *
           PERFORM 9300-SETUP-MSIN-REFERENCE
              THRU 9300-SETUP-MSIN-REFERENCE-X.

       2100-INITIALISE-X.
           EXIT.
      *
      *-----------------------------
       2200-VALIDATE-CONTROL-FIELDS.
      *-----------------------------

      ****************************************************************
      *  VALIDATE CONTROL FIELDS: VALIDATE THE SEQUENCE NUMBER,
      *  CLIENT AND SCROLL VALUES ENTERED.
      ****************************************************************

           MOVE 'N'                   TO  WS-CONTROL-ERROR-CD.
           MOVE 'N'                   TO  WS-CLIENT-CHANGED-CD.

      *    VALIDATE THE CLIENT RECORD EXISTS

           PERFORM  2220-VALIDATE-CLIENT
               THRU 2220-VALIDATE-CLIENT-X.

      *    ENSURE THE SEQUENCE NUMBER IS NUMERIC

           MOVE ZEROES                TO WS-SEQUENCE-NO.
           IF MIR-CLI-MIB-SEQ-NUM NOT = SPACES
               PERFORM  2210-VALIDATE-SEQUENCE
                   THRU 2210-VALIDATE-SEQUENCE-X
           END-IF.

           IF WS-CONTROL-ERROR
               GO TO 2200-VALIDATE-CONTROL-FIELDS-X
           END-IF.

      *    DETERMINE IF THE CLIENT MIB HIT/TRY RECORD EXISTS

           PERFORM  2230-VALIDATE-MIBT-RECORD
               THRU 2230-VALIDATE-MIBT-RECORD-X.

      *
      *  WHEN THE CLIENT EXISTS, CHECK THE CONFIDENTIALITY
      *

           IF WGLOB-MSG-ERROR-SW NOT = ZEROES
               GO TO 2200-VALIDATE-CONTROL-FIELDS-X
           ELSE
               PERFORM 5600-1000-BUILD-PARM-INFO
                  THRU 5600-1000-BUILD-PARM-INFO-X
               MOVE MIR-CLI-ID        TO L5600-CLI-ID
               SET L5600-CCAS-MSG-NOT-REQD     TO TRUE
016387*        SET L5600-CNSLDT-MSG-NOT-REQD   TO TRUE
               PERFORM 5600-1000-CLI-CHK
                  THRU 5600-1000-CLI-CHK-X
               IF L5600-RETRN-CLI-NOT-FOUND
               OR L5600-CNFD-ACCS-RESTRICTED
                  SET WS-CONTROL-ERROR       TO TRUE
               END-IF
           END-IF.

       2200-VALIDATE-CONTROL-FIELDS-X.
           EXIT.
      *
      *-----------------------
       2210-VALIDATE-SEQUENCE.
      *-----------------------

           MOVE MIR-CLI-MIB-SEQ-NUM   TO L0280-INPUT-DATA.
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE 3                     TO L0280-LENGTH.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               IF (L0280-OUTPUT < ZERO)
               OR (L0280-OUTPUT = ZERO)
                   MOVE MIR-CLI-MIB-SEQ-NUM
                                      TO WGLOB-MSG-PARM (1)
      *MSG: SEQUENCE # (@1) MUST BE GREATER THAN ZERO
                   MOVE 'NS17000001'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE L0280-OUTPUT  TO WS-SEQUENCE-NO
                   GO TO 2210-VALIDATE-SEQUENCE-X
               END-IF
           ELSE
               MOVE MIR-CLI-MIB-SEQ-NUM
                                      TO WGLOB-MSG-PARM (1)
      *MSG: SEQUENCE # MUST BE NUMERIC
               MOVE 'NS17000002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE 'Y'                   TO WS-CONTROL-ERROR-CD.

       2210-VALIDATE-SEQUENCE-X.
           EXIT.
      *
      *---------------------
       2220-VALIDATE-CLIENT.
      *---------------------

           MOVE MIR-CLI-ID            TO L2437-CLI-ID.
           PERFORM 2437-1000-OBTAIN-CLI-INFO
              THRU 2437-1000-OBTAIN-CLI-INFO-X.
           IF NOT L2437-RETRN-OK
               SET WS-CONTROL-ERROR      TO TRUE
               MOVE L2437-CLI-ID      TO WGLOB-MSG-PARM (1)
      *MSG: CLIENT (@1) DOES NOT EXIST
               MOVE 'XS00000076'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2220-VALIDATE-CLIENT-X.
           EXIT.
      *
      *--------------------------
       2230-VALIDATE-MIBT-RECORD.
      *--------------------------

           PERFORM  8000-BUILD-MIBT-KEY
               THRU 8000-BUILD-MIBT-KEY-X.

           PERFORM  MIBT-1000-READ
               THRU MIBT-1000-READ-X.
           IF WMIBT-IO-NOT-FOUND
               MOVE 'Y'               TO  WS-CONTROL-ERROR-CD
               MOVE WMIBT-KEY         TO  WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
      *MSG: RECORD (@1) NOT FOUND
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2230-VALIDATE-MIBT-RECORD-X.
           EXIT.
      *
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------

      ****************************************************************
      *  INQUIRY PROCESSING: DISPLAY INFORMATION FROM THE CLIENT AND
      *  MIB HIT/TRY FILES.
      ****************************************************************-

      *
      *  DISPLAY THE CLIENT INFORMATION ON THE SCREEN
      *
           PERFORM  3100-DISPLAY-CLIENT-DATA
               THRU 3100-DISPLAY-CLIENT-DATA-X.

      *
      *  DISPLAY THE MIB HIT/TRY INFORMATION ON THE SCREEN
      *
           PERFORM  3200-DISPLAY-MIBT-DATA
               THRU 3200-DISPLAY-MIBT-DATA-X.

      *
      *  COMPLETION MESSAGE
      *

           IF  WS-DISPLAY-FILE > RMIBT-CLI-MIB-CD-QTY
               PERFORM  3300-CHECK-NEXT-SEQUENCE
                   THRU 3300-CHECK-NEXT-SEQUENCE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
      *MSG: ** TO VIEW MORE DATA PRESS ENTER **
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      *
      *--------------------------
       3100-DISPLAY-CLIENT-DATA.
      *--------------------------

      ****************************************************************-
      *  DISPLAY DATA NA: DISPLAY CLIENT INFORMATION ON THE SCREEN
      ****************************************************************-

      *  USE THE CLIENT INFORMATION RETURNED FROM NSLU2437

557698*    MOVE  L2437-CLI-SUR-NM      TO  MIR-CLI-SUR-NM.
557698*    MOVE  L2437-CLI-GIV-NM      TO  MIR-CLI-GIV-NM.
015904*    MOVE  L2437-CLI-ENTR-SUR-NM TO  MIR-CLI-SUR-NM.
015904     MOVE  L2437-CLI-ENTR-SUR-NM TO  MIR-CLI-INDV-SUR-NM.
015904*    MOVE  L2437-CLI-ENTR-GIV-NM TO  MIR-CLI-GIV-NM.
015904     MOVE  L2437-CLI-ENTR-GIV-NM TO  MIR-CLI-INDV-GIV-NM.
015904*    MOVE  L2437-CLI-MID-INIT-NM TO  MIR-CLI-MID-INIT-NM.
015904     MOVE  L2437-CLI-MID-INIT-NM TO  MIR-CLI-INDV-MID-NM.
           MOVE  L2437-CLI-SEX-CD     TO  MIR-CLI-SEX-CD.
           MOVE  L2437-CLI-BTH-DT     TO  L1640-INTERNAL-DATE.

020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE  L1640-EXTERNAL-DATE  TO  MIR-CLI-BTH-DT.

           MOVE  L2437-CLI-BTH-LOC-CD TO  MIR-CLI-BTH-LOC-CD.
           MOVE  L2437-OCCP-ID        TO  MIR-OCCP-ID.

       3100-DISPLAY-CLIENT-DATA-X.
           EXIT.
      *
      *-----------------------
       3200-DISPLAY-MIBT-DATA.
      *-----------------------

      ****************************************************************-
      *  DISPLAY DATA MIBT: DISPLAY MIB HIT/TRY INFORMATION ON THE
      *  SCREEN
      ****************************************************************-

           MOVE  RMIBT-CLI-MIB-IND-CD TO  MIR-CLI-MIB-IND-CD.
           MOVE  RMIBT-CLI-MIB-RECV-DT          TO  L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE  L1640-EXTERNAL-DATE  TO  MIR-CLI-MIB-RECV-DT.
           MOVE  RMIBT-CLI-MIB-ALIAS-IND
                                      TO MIR-CLI-MIB-ALIAS-IND.
           MOVE  RMIBT-CLI-MIB-FRST-NM          TO  MIR-CLI-MIB-FRST-NM.
           MOVE  RMIBT-CLI-MIB-SUR-NM TO  MIR-CLI-MIB-SUR-NM.
           MOVE  RMIBT-CLI-MIB-MID-NM TO  MIR-CLI-MIB-MID-NM.
           MOVE  RMIBT-CLI-MIB-BTH-DT TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE  L1640-EXTERNAL-DATE  TO  MIR-CLI-MIB-BTH-DT.
           MOVE  RMIBT-CLI-MIB-BTH-LOC-CD
                                      TO MIR-CLI-MIB-BTH-LOC-CD.

      *
      *  DISPLAY VARIABLE DATA
      *
           MOVE  +1                   TO  WS-DISPLAY-FILE.

           PERFORM  3220-MOVE-ARRAY-DATA
               THRU 3220-MOVE-ARRAY-DATA-X
               VARYING  WS-SCRN FROM  1  BY  1
               UNTIL    WS-SCRN  >  WS-DISPLAY-MAX
               OR  WS-DISPLAY-FILE > RMIBT-CLI-MIB-CD-QTY.

       3200-DISPLAY-MIBT-DATA-X.
           EXIT.
      *
      *---------------------
       3220-MOVE-ARRAY-DATA.
      *---------------------

      ****************************************************************
      *  MOVE ARRAY DATA: MOVE DATA FROM VARIABLE PART OF THE RECORD
      *  TO THE SCREEN
      *  NOTE:  WS-DISPLAY-FILE IS POSITION IN FILE
      *         WS-SCRN IS POSITION ON THE SCREEN
      ****************************************************************

           MOVE  RMIBT-CLI-MIB-LBL-CD (WS-DISPLAY-FILE)
                                      TO
                 MIR-DV-CLI-MIB-LBL-CD-T (WS-SCRN).
           MOVE  RMIBT-CLI-MIB-DTL-INFO (WS-DISPLAY-FILE)
                                      TO
                 MIR-DV-CLI-MIB-TXT-T (WS-SCRN).

           ADD  +1  TO  WS-DISPLAY-FILE.

       3220-MOVE-ARRAY-DATA-X.
           EXIT.
      *
      *-------------------------
       3300-CHECK-NEXT-SEQUENCE.
      *-------------------------

      *    IF ANOTHER RECORD EXISTS WITH A NEW SEQUENCE NUMBER
      *    FOR THIS CLIENT INFORM THE USER

           PERFORM  8000-BUILD-MIBT-KEY
               THRU 8000-BUILD-MIBT-KEY-X.
           ADD +1                TO WMIBT-CLI-MIB-SEQ-NUM-N.
           PERFORM  MIBT-1000-READ
               THRU MIBT-1000-READ-X.

           IF WMIBT-IO-NOT-FOUND
      *MSG: INQUIRE COMPLETED - CONTINUE
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
           ELSE
      *MSG: ANOTHER SEQUENCE NUMBER EXISTS FOR THIS CLIENT
               MOVE 'NS17000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
      *MSG: INQUIRE COMPLETED - CONTINUE
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  9110-BLANK-ARRAY-DATA-FIELDS
               THRU 9110-BLANK-ARRAY-DATA-FIELDS-X
               VARYING WS-ARRAY-SUB FROM WS-SCRN BY 1
               UNTIL WS-ARRAY-SUB > WS-DISPLAY-MAX.

       3300-CHECK-NEXT-SEQUENCE-X.
           EXIT.
      *
      *--------------------
       8000-BUILD-MIBT-KEY.
      *--------------------

           MOVE WGLOB-COMPANY-CODE    TO WMIBT-CO-ID.
           MOVE MIR-CLI-ID            TO WMIBT-CLI-ID.
           MOVE MIR-CLI-MIB-SEQ-NUM   TO WMIBT-CLI-MIB-SEQ-NUM.

       8000-BUILD-MIBT-KEY-X.
           EXIT.
      *
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

      ******************************************************************
      *   BLANK DATA FIELDS: SET EACH DATA (NON-KEY AND NON-CONTROL) FIE
      *   THE SCREEN TO SPACES.
      ******************************************************************

           MOVE SPACES                TO MIR-CLI-MIB-IND-CD.
           MOVE SPACES                TO MIR-CLI-MIB-RECV-DT.
           MOVE SPACES                TO MIR-CLI-MIB-ALIAS-IND.
015904*    MOVE SPACES                TO MIR-CLI-SUR-NM.
015904     MOVE SPACES                TO MIR-CLI-INDV-SUR-NM.
015904*    MOVE SPACES                TO MIR-CLI-GIV-NM.
015904     MOVE SPACES                TO MIR-CLI-INDV-GIV-NM.
015904*    MOVE SPACES                TO MIR-CLI-MID-INIT-NM.
015904     MOVE SPACES                TO MIR-CLI-INDV-MID-NM.
           MOVE SPACES                TO MIR-CLI-SEX-CD.
           MOVE SPACES                TO MIR-CLI-BTH-DT.
           MOVE SPACES                TO MIR-CLI-BTH-LOC-CD.
           MOVE SPACES                TO MIR-OCCP-ID.
           MOVE SPACES                TO MIR-CLI-MIB-SUR-NM.
           MOVE SPACES                TO MIR-CLI-MIB-FRST-NM.
           MOVE SPACES                TO MIR-CLI-MIB-MID-NM.
           MOVE SPACES                TO MIR-CLI-MIB-BTH-DT.
           MOVE SPACES                TO MIR-CLI-MIB-BTH-LOC-CD.
           PERFORM  9110-BLANK-ARRAY-DATA-FIELDS
               THRU 9110-BLANK-ARRAY-DATA-FIELDS-X
               VARYING WS-ARRAY-SUB FROM 1 BY 1
               UNTIL   WS-ARRAY-SUB > WS-DISPLAY-MAX.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *-----------------------------
       9110-BLANK-ARRAY-DATA-FIELDS.
      *-----------------------------

           MOVE SPACES       TO  MIR-DV-CLI-MIB-LBL-CD-T (WS-ARRAY-SUB).
           MOVE SPACES          TO  MIR-DV-CLI-MIB-TXT-T (WS-ARRAY-SUB).

       9110-BLANK-ARRAY-DATA-FIELDS-X.
           EXIT.
      *
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

      ****************************************************************
      *   SET REFERENCE: MOVE DATA WHICH IDENTIFIES THE OBJECT BEING
      *   BEIWORKED ON TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING.
      ****************************************************************-

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970
025970     SET WS-DEFAULT-DISPLAY-MAX         TO TRUE.
025970
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      ******************************************
      *  PROCESSING COPYBOOKS
      ******************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
      ******************************************
      *  LINKAGE COPYBOOKS
      ******************************************
       COPY CCPS5600.
018764*COPY CCCL5600.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL5600.
      *
018764*COPY NCCL2437.
025970 COPY NCPS2437.
018764 COPY NCPL2437.
      *
025970 COPY XCPS0280.
       COPY XCPL0280.
025970 COPY XCPS1640.
       COPY XCPL1640.
      *
      ***********************************************
      *  MESSAGE PROCESSING COPYBOOKS
      ***********************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
      ***********************************************
      *  FILE I/O  COPYBOOKS
      ***********************************************
       COPY NCPNMIBT.
      *
      ***********************************************
      *  ADMIN  COPYBOOKS
      ***********************************************
      *
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM NSOM1700                     **
      *****************************************************************
