      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM8334.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM8334                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE LIST FUNCTION     **
      **            FOR THE POLX TABLE                               **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
031036**  7.0       EXEMPT STATUS MANAGEMENT                         **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM8334'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                          PIC X(04).
               88  WS-BUS-FCN-LIST                    VALUE '8334'.
           05  WS-SUB                                 PIC S9(04) BINARY.
           05  WS-POL-XEMP-EFF-DT                     PIC X(10).

       01  WS-CONSTANT-AREA.
           05  WS-MAX-BROWSE-LINES                    PIC S9(4)  BINARY.
               88  WS-MAX-BROWSE-LINES-DEFAULT        VALUE +12.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRPOL.
       COPY CCFWPOL.

       COPY CCFWPOLX.
       COPY CCFRPOLX.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM8334.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM8334'           TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *----------
       2000-LIST.
      *----------

      * VALIDATE KEY

           PERFORM  8000-EDIT-KEY-INFO
               THRU 8000-EDIT-KEY-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      * DISPLAY RECORDS

           PERFORM  2100-POLX-BROWSE
               THRU 2100-POLX-BROWSE-X.

       2000-LIST-X.
           EXIT.
      /
      *-----------------
       2100-POLX-BROWSE.
      *-----------------

           MOVE HIGH-VALUES            TO WPOLX-KEY.
           MOVE RPOL-POL-ID            TO WPOLX-POL-ID.
           MOVE WWKDT-HIGH-DT          TO WPOLX-POL-XEMP-EFF-DT.

           IF  WS-POL-XEMP-EFF-DT NOT = WWKDT-ZERO-DT
               MOVE WS-POL-XEMP-EFF-DT TO WPOLX-POL-XEMP-EFF-DT
           END-IF.

           MOVE LOW-VALUES             TO WPOLX-ENDBR-KEY.
           MOVE RPOL-POL-ID            TO WPOLX-ENDBR-POL-ID.
           MOVE WWKDT-LOW-DT           TO WPOLX-ENDBR-POL-XEMP-EFF-DT.

           PERFORM  POLX-1000-BROWSE-PREV
               THRU POLX-1000-BROWSE-PREV-X.

           PERFORM  POLX-2000-READ-PREV
               THRU POLX-2000-READ-PREV-X.

           IF  WPOLX-IO-EOF
               PERFORM  POLX-3000-END-BROWSE-PREV
                   THRU POLX-3000-END-BROWSE-PREV-X
      * MSG: NO RECORD FOUND TO DISPLAY
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2100-POLX-BROWSE-X
           END-IF.

           PERFORM  2120-POLX-BROWSE-LOOP
               THRU 2120-POLX-BROWSE-LOOP-X
               VARYING WS-SUB FROM +1 BY +1
               UNTIL WS-SUB > WS-MAX-BROWSE-LINES
               OR    WPOLX-IO-EOF.

           IF  WPOLX-IO-EOF
      * MSG: END OF LIST
               MOVE 'XS00000015'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE RPOLX-POL-XEMP-EFF-DT TO L1640-INTERNAL-DATE
               PERFORM 1640-8000-INTERNAL-TO-MIR
                  THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE   TO MIR-POL-XEMP-EFF-DT
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
      *MSG:    '** TO VIEW MORE DATA PRESS ENTER **'
               MOVE 'XS00000014'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  POLX-3000-END-BROWSE-PREV
               THRU POLX-3000-END-BROWSE-PREV-X.

       2100-POLX-BROWSE-X.
           EXIT.

      *----------------------
       2120-POLX-BROWSE-LOOP.
      *----------------------

           MOVE RPOLX-POL-XEMP-STAT-CD
             TO MIR-POL-XEMP-STAT-CD-T (WS-SUB).

           MOVE RPOLX-POL-XEMP-EFF-DT
             TO MIR-POL-XEMP-EFF-DT-T (WS-SUB).

           MOVE RPOLX-FND-OPT-PREV-AMT   TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FND-OPT-PREV-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-FND-OPT-PREV-AMT-T (WS-SUB).

           MOVE RPOLX-FND-OPT-CRNT-AMT   TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FND-OPT-CRNT-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-FND-OPT-CRNT-AMT-T (WS-SUB).

           MOVE RPOLX-ESTMT-MAX-PREM-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-ESTMT-MAX-PREM-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-ESTMT-MAX-PREM-AMT-T (WS-SUB).

           MOVE RPOLX-POL-ACUM-FND-AMT   TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-ACUM-FND-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-POL-ACUM-FND-AMT-T (WS-SUB).

           MOVE RPOLX-SIDFND-CSV-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-SIDFND-CSV-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-SIDFND-CSV-AMT-T (WS-SUB).

           MOVE RPOLX-REMN-ADDL-DPOS-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-REMN-ADDL-DPOS-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-FLOAT          TO TRUE.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-REMN-ADDL-DPOS-AMT-T (WS-SUB).

           PERFORM  POLX-2000-READ-PREV
               THRU POLX-2000-READ-PREV-X.

       2120-POLX-BROWSE-LOOP-X.
           EXIT.

      *-------------------
       8000-EDIT-KEY-INFO.
      *-------------------
      *
      * VALIDATE POL NUMBER
      *
           MOVE MIR-POL-ID-BASE            TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX             TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'XS00000001'           TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID            TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8000-EDIT-KEY-INFO-X
           END-IF.
      *
      * VALIDATE EFFECTIVE DATE
      *
           IF  MIR-POL-XEMP-EFF-DT = SPACE
               MOVE WWKDT-ZERO-DT           TO WS-POL-XEMP-EFF-DT
           ELSE
               MOVE MIR-POL-XEMP-EFF-DT     TO L1640-EXTERNAL-DATE
               PERFORM  1640-7000-MIR-TO-INT
                   THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-NOT-VALID
                   MOVE 'XS00000036'        TO WGLOB-MSG-REF-INFO
                   MOVE MIR-POL-XEMP-EFF-DT TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE L1640-INTERNAL-DATE TO WS-POL-XEMP-EFF-DT
               END-IF
           END-IF.

       8000-EDIT-KEY-INFO-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-POL-XEMP-STAT-CD-G.
           MOVE SPACES                   TO MIR-FND-OPT-PREV-AMT-G.
           MOVE SPACES                   TO MIR-FND-OPT-CRNT-AMT-G.
           MOVE SPACES                   TO MIR-ESTMT-MAX-PREM-AMT-G.
           MOVE SPACES                   TO MIR-POL-ACUM-FND-AMT-G.
           MOVE SPACES                   TO MIR-SIDFND-CSV-AMT-G.
           MOVE SPACES                   TO MIR-REMN-ADDL-DPOS-AMT-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.
           MOVE MIR-POL-ID-BASE          TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX           TO WGLOB-REF-POLICY-SUFFIX.
           SET WGLOB-REF-POLICY          TO TRUE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORKING-STORAGE.
           MOVE SPACES                     TO WWKDT-WORK-FIELDS.

           SET WS-MAX-BROWSE-LINES-DEFAULT TO TRUE.
           SET MIR-RETRN-OK                TO TRUE.

           MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.

       COPY XCPS0280.
       COPY XCPL0280.

       COPY XCPS0290.
       COPY XCPL0290.

       COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.

       COPY CCPVPOLX.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM8334                     **
      *****************************************************************
