      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM3200.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM3200                                         **
      **  REMARKS:  PROCESS DRIVER FOR REPL TRANSACTION              **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
010303**  5.6       INITIAL SYSTEM DESIGN                            **
015672**  5.6A      PCR FIX                                          **
013578**  6.0       GLOBAL CHANGES                                   **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014591**  6.0       COMBINE POL-ID AND SUFFIX                        **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
014221**  6.2       LOGICAL LOCKING                                  **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018844**  6.3       REPLACEMENT PROCESSING FOR U.S. POLICIES         **
020462**  6.4       ISO DATE STANDARDIZATION                         **
021364**  6.4       DISPLAY EXTERNAL REPLACEMENT FOR APP ENTRY       **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /

       ENVIRONMENT DIVISION.

       CONFIGURATION SECTION.
      /
       DATA DIVISION.

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM3200'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.

       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  I                            PIC S9(4)  VALUE ZERO COMP.
016548     05  I                            PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12  COMP.
025970*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12
025970*                                     BINARY.
013578     05  WS-BUS-FCN-ID                PIC X(04).
013578         88  WS-BUS-FCN-ID-VALID                 VALUE
013578             '1650' '1651' '1652' '1653' '1654'.
013578         88  WS-BUS-FCN-INQUIRE                  VALUE '1650'.
013578         88  WS-BUS-FCN-CREATE                   VALUE '1651'.
013578         88  WS-BUS-FCN-MAINTAIN                 VALUE '1652'.
013578         88  WS-BUS-FCN-DELETE                   VALUE '1653'.
013578         88  WS-BUS-FCN-BROWSE                   VALUE '1654'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '1650'.
           05  WS-REPL-KEY.
               10  WS-POLICY.
                   15  WS-POLICY-ID         PIC X(09).
                   15  WS-SUFFIX            PIC X(01).
               10  WS-SEQUENCE              PIC X(03).

025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                 VALUE '1650'.
025970     05  WS-MAX-BROWSE-LINES          PIC S9(4).
025970         88  WS-DEFAULT-MAX-BR-LINES             VALUE +12.
      /
      ***************************************************************
      * COMMON AREA
      ***************************************************************
014221 COPY CCWWLOCK.
      /
      ***************************************************************
      * REPLACEMENT WORK AREA
      ***************************************************************
       COPY CCFRREPL.
       COPY CCFWREPL.
      /
      ***************************************************************
      * POLICY/ COVERAGE WORK AREA
      ***************************************************************
       COPY CCFRPOL.
       COPY CCFWPOL.

015672 COPY CCFWCVG.
015672 COPY CCFRCVG.
      /
       COPY CCWWCVGS.
      /
      ***************************************************************
      * DATE CONVERSION EDIT AREA
      ***************************************************************
       COPY XCWL1640.
       COPY XCWLDTLK.
      /
       COPY XCWEBLCH.
      /
      ***************************************************************
      * LINKAGE TO PCL SET UP MODULE
      ***************************************************************
      /
      ***************************************************************
      * LINKAGE COPYBOOKS
      ***************************************************************
      /
020478 COPY CCWL2626.
       COPY CCWLPGA.
       COPY CCWL2435.
016537*COPY CCWL0620.
       COPY CCWL5950.
016503 COPY CCWL0289.
016440 COPY CCWL5400.
014221 COPY XCWL8090.
      /
      *******************
       LINKAGE   SECTION.
      *******************

CVMQ71 COPY XCWWDFHQ.
      /
       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY NCWM3200.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      ****************
       0000-MAINLINE.
      ****************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

013578     PERFORM 2000-PROCESS-REQUEST
013578        THRU 2000-PROCESS-REQUEST-X.
013578
020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM EXIT-1000-FINALIZE
              THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
             GOBACK.


      **************************
013578 2000-PROCESS-REQUEST.
      **************************

025970*    SET MIR-RETRN-OK                 TO TRUE.
           PERFORM 9300-SETUP-MSIN-REFERENCE
              THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      *    MOVE ENTER CODE TO A WORK FIELD, AND DECIDE WHICH SCREEN TO
      *    DISPLAY.
      *
025970*    MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.

      *

016440        MOVE MIR-POL-ID            TO    WPOL-POL-ID.
014221        IF WS-BUS-FCN-INQUIRE
014221           PERFORM POL-1000-READ-TWRK-TS
014221              THRU POL-1000-READ-TWRK-TS-X
014221        ELSE
016440           PERFORM  POL-1000-READ
016440               THRU POL-1000-READ-X
014221        END-IF.

016440     IF NOT WPOL-IO-OK
016440         PERFORM  9100-BLANK-DATA-FIELDS
016440             THRU 9100-BLANK-DATA-FIELDS-X
016440*MSG:    POLICY NUMBER IS REQUIRED
016440         MOVE 'NS32000001'            TO WGLOB-MSG-REF-INFO
016440         MOVE WPOL-POL-ID             TO WGLOB-MSG-PARM (1)
016440         PERFORM 0260-1000-GENERATE-MESSAGE
016440            THRU 0260-1000-GENERATE-MESSAGE-X
016440         SET MIR-RETRN-RQST-FAILED TO TRUE
016440         GO TO 2000-PROCESS-REQUEST-X
016440     END-IF.

016440* CALL 5400 FOR POLICY TRANSFER EDITS. THE POLICY MUST BE READ
016440* FIRST.

016440     PERFORM 5400-1000-BUILD-PARM-INFO
016440        THRU 5400-1000-BUILD-PARM-INFO-X.

016440     IF WS-BUS-FCN-MAINTAIN
016440     OR WS-BUS-FCN-DELETE
016440     OR WS-BUS-FCN-CREATE
016440        SET L5400-POL-XFER-UPDATE   TO TRUE
016440     END-IF.

016440     PERFORM 5400-1000-POL-CHK
016440        THRU 5400-1000-POL-CHK-X.

016440     IF  L5400-XFER-ACCS-RESTRICTED
016440         GO TO 2000-PROCESS-REQUEST-X
016440     END-IF.

013578     IF WS-BUS-FCN-INQUIRE
013578     OR WS-BUS-FCN-MAINTAIN
013578     OR WS-BUS-FCN-DELETE
              PERFORM 2110-CHECK-REPL
                 THRU 2110-CHECK-REPL-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
013578        SET MIR-RETRN-RQST-FAILED  TO TRUE
013578        GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           EVALUATE TRUE


013578         WHEN WS-BUS-FCN-INQUIRE
013578              PERFORM 3000-PROCESS-RETRIEVE
013578                 THRU 3000-PROCESS-RETRIEVE-X
013578
013578         WHEN WS-BUS-FCN-BROWSE
013578              PERFORM 3500-PROCESS-LIST
013578                 THRU 3500-PROCESS-LIST-X
013578
013578         WHEN WS-BUS-FCN-CREATE
013578              PERFORM 4000-PROCESS-CREATE
013578                 THRU 4000-PROCESS-CREATE-X
013578
013578         WHEN WS-BUS-FCN-MAINTAIN
013578              PERFORM 5000-PROCESS-UPDATE
013578                 THRU 5000-PROCESS-UPDATE-X
013578
013578         WHEN WS-BUS-FCN-DELETE
013578              PERFORM 6000-PROCESS-DELETE
013578                 THRU 6000-PROCESS-DELETE-X

           END-EVALUATE.

013578 2000-PROCESS-REQUEST-X.
           EXIT.
      /

      *****************************************************************
      *   CHECK REPL:
      *   ENSURE THAT THE REPLACEMENT EXISTS.
      *****************************************************************
      ******************
       2110-CHECK-REPL.
      ******************

014591     MOVE MIR-POL-ID             TO WS-POLICY.
           MOVE WS-POLICY              TO WREPL-POL-ID.

           IF MIR-POL-REPL-SEQ-NUM NOT NUMERIC
      *MSG:    "SEQUENCE NUMBER (@1) NOT NUMERIC"
               MOVE MIR-POL-REPL-SEQ-NUM    TO WGLOB-MSG-PARM (1)
               MOVE 'NS32000010'            TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE MIR-POL-REPL-SEQ-NUM    TO WREPL-POL-REPL-SEQ-NUM
               PERFORM 8100-READ-REPL-INFO
                  THRU 8100-READ-REPL-INFO-X
           END-IF.

           IF  WGLOB-MSG-ERROR-SW     >  ZERO
               MOVE SPACES             TO MIR-POL-REPL-SEQ-NUM-G
018844         MOVE SPACES             TO MIR-POL-REPL-DIR-CD-G
               MOVE SPACES             TO MIR-POL-REPL-TYP-CD-G
               MOVE SPACES             TO MIR-REPL-CO-CLI-ID-G
               MOVE SPACES             TO MIR-REPL-POL-ID-G
               MOVE SPACES             TO MIR-POL-REPL-OVRID-IND-G
           END-IF.

       2110-CHECK-REPL-X.
           EXIT.
      /
      *************
013578 3000-PROCESS-RETRIEVE.
      *************

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.
      *MSG:'INQUIRE COMPLETED - CONTINUE'
           MOVE 'XS00000002'           TO WGLOB-MSG-REF-INFO
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

013578 3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      ************
013578 3500-PROCESS-LIST.
      ************

      ****************************************************************
      * EACH RECORD OF THE BROWSE SCREEN.  THIS WILL ALLOW
      * USERS TO CHOSE A RECORD(S) TO PERFORM INQUIRE,
      * MAINTAIN OR DELETE PROCESSING FOR THE PAYOUT RECORD
      * SELECTED.
      *
      *  CHECK ENTER CODE FIELDS FOR INPUT
      ****************************************************************


           MOVE SPACES                  TO MIR-POL-REPL-SEQ-NUM-G.
018844     MOVE SPACES                  TO MIR-POL-REPL-DIR-CD-G.
           MOVE SPACES                  TO MIR-POL-REPL-TYP-CD-G.
           MOVE SPACES                  TO MIR-REPL-CO-CLI-ID-G.
           MOVE SPACES                  TO MIR-REPL-POL-ID-G.
           MOVE SPACES                  TO MIR-POL-REPL-OVRID-IND-G.

           MOVE LOW-VALUES              TO WREPL-KEY.
           MOVE HIGH-VALUES             TO WREPL-ENDBR-KEY.
           MOVE ZEROS                   TO WREPL-POL-REPL-SEQ-NUM.
           MOVE 999                     TO WREPL-ENDBR-POL-REPL-SEQ-NUM.
014591     MOVE MIR-POL-ID              TO WS-POLICY.
           MOVE WS-POLICY               TO WREPL-POL-ID.
           MOVE WS-POLICY               TO WREPL-ENDBR-POL-ID.

           IF MIR-POL-REPL-SEQ-NUM GREATER SPACES
              MOVE MIR-POL-REPL-SEQ-NUM TO WS-SEQUENCE
              MOVE WS-SEQUENCE          TO WREPL-POL-REPL-SEQ-NUM
            END-IF.

           PERFORM REPL-1000-BROWSE
              THRU REPL-1000-BROWSE-X

           PERFORM REPL-2000-READ-NEXT
              THRU REPL-2000-READ-NEXT-X.

           IF NOT WREPL-IO-OK
           OR WREPL-IO-EOF
      *MSG:    'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'        TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM REPL-3000-END-BROWSE
                  THRU REPL-3000-END-BROWSE-X
013578         SET MIR-RETRN-RQST-FAILED TO TRUE
013578         GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           IF WREPL-IO-OK
      *MSG:    TO VIEW MORE DATA PRESS ENTER'
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE
               MOVE 'XS00000014'            TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:    'END OF FILE REACHED'
               MOVE 'XS00000025'            TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM REPL-3000-END-BROWSE
              THRU REPL-3000-END-BROWSE-X.

013578 3500-PROCESS-LIST-X.
           EXIT.
      /

      ************
013578 4000-PROCESS-CREATE.
      ************

           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.

014591     MOVE MIR-POL-ID           TO WS-POLICY.
           MOVE WS-POLICY            TO WPOL-POL-ID.

           PERFORM POL-2000-READ-INDEX
              THRU POL-2000-READ-INDEX-X.

           IF WPOL-IO-NOT-FOUND
      *MSG:    POLICY NUMBER IS REQUIRED
               MOVE 'NS32000001'            TO WGLOB-MSG-REF-INFO
013578         SET MIR-RETRN-RQST-FAILED TO TRUE
               MOVE WS-POLICY               TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
013578         GO TO 4000-PROCESS-CREATE-X
           END-IF.

           MOVE ZEROS                TO WREPL-POL-REPL-SEQ-NUM.
           MOVE 999                  TO WREPL-ENDBR-POL-REPL-SEQ-NUM.
014591     MOVE MIR-POL-ID           TO WS-POLICY.
           MOVE WS-POLICY            TO WREPL-POL-ID.
           MOVE WS-POLICY            TO WREPL-ENDBR-POL-ID.

      *    PERFORM ROUTINE TO GET MAX SEQUENCE NUMBER


           PERFORM REPL-2000-READ-MAX
              THRU REPL-2000-READ-MAX-X.

           EVALUATE TRUE
               WHEN WREPL-IO-OK
                    ADD +1              TO WREPL-MAX-POL-REPL-SEQ-NUM
                    MOVE WREPL-MAX-POL-REPL-SEQ-NUM
                                        TO WREPL-POL-REPL-SEQ-NUM
                    MOVE WREPL-MAX-POL-REPL-SEQ-NUM
                                        TO MIR-POL-REPL-SEQ-NUM
               WHEN WREPL-IO-NOT-FOUND
                    MOVE +1             TO WREPL-POL-REPL-SEQ-NUM
                    MOVE WREPL-POL-REPL-SEQ-NUM
                                        TO MIR-POL-REPL-SEQ-NUM
               WHEN OTHER
                    MOVE WREPL-KEY      TO WGLOB-MSG-PARM (1)
      *MSG:    READ ERROR'
                    MOVE 'XS00000046'   TO WGLOB-MSG-REF-INFO
                    PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
013578              SET MIR-RETRN-RQST-FAILED TO TRUE
013578              GO TO 4000-PROCESS-CREATE-X
           END-EVALUATE.

           PERFORM REPL-1000-READ
              THRU REPL-1000-READ-X.

           IF  WREPL-IO-OK
               MOVE WREPL-KEY               TO WGLOB-MSG-PARM (1)
      *MSG:    RECORD (@1) ALREADY EXISTS'
               MOVE 'XS00000003'            TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
013578         SET MIR-RETRN-RQST-FAILED TO TRUE
013578         GO TO 4000-PROCESS-CREATE-X
           END-IF.


      *
      ***  CREATE RECORD AND SWITCH TO MAINTAIN MODE.
      *
           PERFORM REPL-1000-CREATE
              THRU REPL-1000-CREATE-X.

           MOVE 'XS00000004'                TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM REPL-1000-WRITE
              THRU REPL-1000-WRITE-X.


           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.
013578 4000-PROCESS-CREATE-X.
           EXIT.
      /

      ***************************************************************
      *    MAINTAIN PROCESSING:                                     *
      *        FORCE = 1: USER HAS ENTERED KEY DETAILS              *
      *        FORCE = 2: USER HAS MODIFIED DATA FIELDS             *
      ***************************************************************
      /
      ************************
013578 5000-PROCESS-UPDATE.
      ************************
      *
014591     MOVE MIR-POL-ID           TO WS-POLICY.
           MOVE WS-POLICY            TO WPOL-POL-ID.

014221*    PERFORM POL-1000-READ-FOR-UPDATE
014221*       THRU POL-1000-READ-FOR-UPDATE-X.
014221     PERFORM POL-2000-UPDATE-TWRK-TS
014221        THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 5000-PROCESS-UPDATE-X
014221     END-IF

           IF NOT WPOL-IO-OK
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
      *MSG:    POLICY NUMBER IS REQUIRED
               MOVE 'NS32000001'            TO WGLOB-MSG-REF-INFO
013578         SET MIR-RETRN-RQST-FAILED TO TRUE
               MOVE WS-POLICY               TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
013578         GO TO 5000-PROCESS-UPDATE-X
           END-IF.
      *
      *   MAINTENANCE PROCESSING PART 2 INCLUDES EDITING THE
      *   DATA AND UPDATING, DELETING AND CREATING RECORDS.
      *
           MOVE MIR-POL-REPL-SEQ-NUM TO WREPL-POL-REPL-SEQ-NUM.
014591     MOVE MIR-POL-ID           TO WS-POLICY.
           MOVE WS-POLICY            TO WREPL-POL-ID.

           PERFORM REPL-1000-READ-FOR-UPDATE
              THRU REPL-1000-READ-FOR-UPDATE-X.

           IF  NOT WREPL-IO-OK
      * MSG:  'REPLACEMENT RECORD DOES NOT EXIST'
               MOVE 'NS32000002'   TO WGLOB-MSG-REF-INFO
               MOVE WREPL-KEY      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               PERFORM  REPL-3000-UNLOCK
                   THRU REPL-3000-UNLOCK-X
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
013578         SET MIR-RETRN-RQST-FAILED TO TRUE
013578         GO TO 5000-PROCESS-UPDATE-X
           END-IF.

021364*
021364*   DURING APP. ENTRY THERE IS NO FIELD FOR 'NOTIFICATION
021364*   OVERRIDE' THEREFORE MIR-POL-REPL-OVRID-IND VALUE IS
021364*   BLANK AND THE REQUIREMENT RECORD IS NOT BEING WRITTEN
021364*   ON REQT TABLE. MOVING THE VALUE FROM REPL TABLE TO THE
021364*   MIR FIELD
021364
021364     IF MIR-POL-REPL-OVRID-IND = EBLCH-BLANK-FIELD-CHAR
021364     OR MIR-POL-REPL-OVRID-IND = SPACES
021364        MOVE RREPL-POL-REPL-OVRID-IND TO MIR-POL-REPL-OVRID-IND
021364     END-IF.
021364

           PERFORM 5300-EDIT-REPL-SCREEN-DATA
              THRU 5300-EDIT-REPL-SCREEN-DATA-X.

           PERFORM REPL-2000-REWRITE
              THRU REPL-2000-REWRITE-X.

           IF WGLOB-MSG-ERROR-SW = 0
               PERFORM  5500-REQT-GENERATION
                   THRU 5500-REQT-GENERATION-X
      *MSG:    MAINTENANCE COMPLETE
               MOVE 'XS00000007'            TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

013578 5000-PROCESS-UPDATE-X.
           EXIT.

      /
      ****************************
       5300-EDIT-REPL-SCREEN-DATA.
      ****************************

           PERFORM 5310-SET-SCREEN-DATA
              THRU 5310-SET-SCREEN-DATA-X.

018844     EVALUATE TRUE
018844         WHEN MIR-POL-REPL-DIR-CD = 'I'
018844         WHEN MIR-POL-REPL-DIR-CD = 'O'
018844              MOVE MIR-POL-REPL-DIR-CD
018844                   TO RREPL-POL-REPL-DIR-CD

018844         WHEN OTHER
018844*MSG:    'REPLACEMENT DIRECTION MUST BE INBOUND OR OUTBOUND'
018844              MOVE 'NS32000011'          TO WGLOB-MSG-REF-INFO
018844              SET MIR-RETRN-EDIT-ERROR TO TRUE
018844              PERFORM 0260-1000-GENERATE-MESSAGE
018844                 THRU 0260-1000-GENERATE-MESSAGE-X
018844     END-EVALUATE.

           EVALUATE TRUE
               WHEN MIR-POL-REPL-TYP-CD = 'I'
                    IF  MIR-REPL-CO-CLI-ID = SPACES
                        MOVE MIR-POL-REPL-TYP-CD
                             TO RREPL-POL-REPL-TYP-CD
                        MOVE MIR-REPL-CO-CLI-ID
                             TO RREPL-REPL-CO-CLI-ID
                    ELSE
                        MOVE MIR-POL-REPL-TYP-CD
                             TO RREPL-POL-REPL-TYP-CD
                        PERFORM 5320-EDIT-CLI-NUM
                           THRU 5320-EDIT-CLI-NUM-X
                    END-IF

               WHEN MIR-POL-REPL-TYP-CD = 'E'
                    IF  MIR-REPL-CO-CLI-ID = SPACES
      *MSG:    'EXTERNAL REPLACEMENTS REQUIRE A REPLACED COMPANY'
                        MOVE 'NS32000009'       TO WGLOB-MSG-REF-INFO
013578                  SET MIR-RETRN-EDIT-ERROR TO TRUE
                        PERFORM 0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                    ELSE
                        MOVE MIR-POL-REPL-TYP-CD
                             TO RREPL-POL-REPL-TYP-CD
                        PERFORM 5320-EDIT-CLI-NUM
                           THRU 5320-EDIT-CLI-NUM-X
                    END-IF

               WHEN OTHER
      *MSG:    'REPLACEMENT TYPE MUST BE INTERNAL OR EXTERNAL'
                    MOVE 'NS32000004'          TO WGLOB-MSG-REF-INFO
013578              SET MIR-RETRN-EDIT-ERROR TO TRUE
                    PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
           END-EVALUATE.

      *      IF  WGLOB-MSG-ERROR-SW > ZERO
      *         GO TO 5300-EDIT-REPL-SCREEN-DATA-X
      *     END-IF.

           IF  MIR-REPL-POL-ID = SPACES
      *MSG:    'REPLACED POLICY NUMBER MUST BE ENTERED'
               MOVE 'NS32000007'            TO WGLOB-MSG-REF-INFO
013578         SET MIR-RETRN-EDIT-ERROR TO TRUE
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE MIR-REPL-POL-ID         TO RREPL-REPL-POL-ID
           END-IF.

           IF  MIR-POL-REPL-OVRID-IND = 'Y'
           OR  MIR-POL-REPL-OVRID-IND = 'N'
               MOVE MIR-POL-REPL-OVRID-IND  TO RREPL-POL-REPL-OVRID-IND
           ELSE
      *MSG:    'NOTIFICATION OVERRIDE MUST BE YES OR NO'
               MOVE 'NS32000008'            TO WGLOB-MSG-REF-INFO
013578         SET MIR-RETRN-EDIT-ERROR TO TRUE
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      * RESET STATUS TO ACTIVE AFTER ANY MAINTAIN OPERATION EXECUTED

           SET RREPL-POL-REPL-STAT-ACTIVE   TO TRUE.

           MOVE RREPL-POL-REPL-STAT-CD      TO MIR-POL-REPL-STAT-CD.

       5300-EDIT-REPL-SCREEN-DATA-X.
           EXIT.
      /
      **********************
       5310-SET-SCREEN-DATA.
      **********************

018844     IF MIR-POL-REPL-DIR-CD = EBLCH-BLANK-FIELD-CHAR
018844         MOVE SPACES                   TO MIR-POL-REPL-DIR-CD
018844     END-IF.

           IF MIR-POL-REPL-TYP-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES                   TO MIR-POL-REPL-TYP-CD
           END-IF.

           IF MIR-REPL-POL-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES                  TO MIR-REPL-POL-ID
           END-IF.

           IF MIR-POL-REPL-OVRID-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES                  TO MIR-POL-REPL-OVRID-IND
           END-IF.

           IF MIR-REPL-CO-CLI-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES                  TO MIR-REPL-CO-CLI-ID
           END-IF.


       5310-SET-SCREEN-DATA-X.
           EXIT.
      /
      *******************
       5320-EDIT-CLI-NUM.
      *******************

           PERFORM 2435-1000-BUILD-PARM-INFO
              THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE MIR-REPL-CO-CLI-ID                  TO L2435-CLI-ID.

           PERFORM 2435-1000-OBTAIN-CLI-INFO
              THRU 2435-1000-OBTAIN-CLI-INFO-X.

           IF  NOT L2435-RETRN-OK
      *MSG:    "INVALID CLIENT NUMBER"
               MOVE 'NS32000005'            TO WGLOB-MSG-REF-INFO
               MOVE MIR-REPL-CO-CLI-ID      TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
013578         SET MIR-RETRN-EDIT-ERROR TO TRUE
               GO TO 5320-EDIT-CLI-NUM-X
           ELSE
               IF  L2435-CLI-SEX-CD  NOT = 'C'
      *MSG:    "CLIENT IS NOT ESTABLISHED AS A COMPANY"
                   MOVE 'NS32000006'        TO WGLOB-MSG-REF-INFO
013578             SET MIR-RETRN-EDIT-ERROR TO TRUE
                   MOVE MIR-REPL-CO-CLI-ID  TO WGLOB-MSG-PARM (1)
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 5320-EDIT-CLI-NUM-X
               END-IF
           END-IF.

           MOVE MIR-REPL-CO-CLI-ID          TO RREPL-REPL-CO-CLI-ID.


       5320-EDIT-CLI-NUM-X.
           EXIT.

      *********************
       5500-REQT-GENERATION.
      *********************

015672     PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
015672         THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           PERFORM  5950-1000-BUILD-PARM-INFO
               THRU 5950-1000-BUILD-PARM-INFO-X.

           MOVE MIR-POL-REPL-TYP-CD       TO  L5950-POL-REPL-TYP-CD.
           PERFORM  5950-1000-ANALYZE-POL
               THRU 5950-1000-ANALYZE-POL-X.

016503     PERFORM 0289-1000-INIT-PARM-INFO
016503        THRU 0289-1000-INIT-PARM-INFO-X.

016503     PERFORM 0289-1000-OBTAIN-NXT-ACTV
016503       THRU  0289-1000-OBTAIN-NXT-ACTV-X.

016503     IF L0289-RETRN-OK
016503        MOVE L0289-NXT-ACTV-TYP-CD  TO RPOL-NXT-ACTV-TYP-CD
016503        MOVE L0289-NXT-ACTV-DT      TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503        MOVE 'RSH'                  TO RPOL-NXT-ACTV-TYP-CD
016503        MOVE WGLOB-PROCESS-DATE     TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

       5500-REQT-GENERATION-X.
           EXIT.


      *****************************************************************
      *   DELETE PROCESSING:                                          *
      *       FORCE = 1: USER HAS ENTERED KEY DETAILS.                *
      *       FORCE = 9: USER HAS VERIFIED DELETE REQUEST.            *
      *****************************************************************
      ************
      *******************
013578 6000-PROCESS-DELETE.
      *******************
      ***************************************************************
      * DELETE PROCESSING PART 2 CONSISTS OF DELETING THE
      * RECORD (BACKOUTS ARE HANDLED IN THE MAINLINE).
      *
      * BUILD REPL KEY FROM KEY AREA ON SCREEN.
      ***************************************************************

      *
014221* UPDATE POLICY TIMESTAMP FOR DELETE
      *
014221     MOVE MIR-POL-ID                  TO WPOL-POL-ID.
014221     PERFORM POL-2000-UPDATE-TWRK-TS
014221        THRU POL-2000-UPDATE-TWRK-TS-X.
014221     IF  WPOL-IO-NOT-FOUND
014221* MSG: POLICY NOT ON POLICY FILE
014221         MOVE 'XS00000070'            TO WGLOB-MSG-REF-INFO
014221         MOVE WPOL-POL-ID             TO WGLOB-MSG-PARM (01)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.
014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 6000-PROCESS-DELETE-X
014221     END-IF.


           PERFORM  8050-BUILD-REPL-KEY
               THRU 8050-BUILD-REPL-KEY-X.

           PERFORM REPL-1000-READ-FOR-UPDATE
              THRU REPL-1000-READ-FOR-UPDATE-X

           IF  WREPL-IO-OK
               PERFORM REPL-1000-DELETE
                  THRU REPL-1000-DELETE-X
               IF WREPL-IO-OK
      *MSG:       DELETE COMPLETED MESSAGE
                  MOVE 'XS00000011'         TO WGLOB-MSG-REF-INFO
               ELSE
      *MSG:       RECORD (@1) LOST IN DELETE
                  MOVE WREPL-KEY            TO WGLOB-MSG-PARM (1)
                  MOVE 'XS00000010'         TO WGLOB-MSG-REF-INFO
               END-IF
014221         PERFORM POL-2000-REWRITE
014221            THRU POL-2000-REWRITE-X
014221         PERFORM POL-1000-READ-TWRK-TS
014221            THRU POL-1000-READ-TWRK-TS-X
           ELSE
      *MSG:    RECORD (@1) LOST IN DELETE
               MOVE WREPL-KEY               TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'            TO WGLOB-MSG-REF-INFO
014221         PERFORM  POL-3000-UNLOCK
014221             THRU POL-3000-UNLOCK-X
           END-IF.

           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.

013578 6000-PROCESS-DELETE-X.
           EXIT.
      /
      ********************
       8050-BUILD-REPL-KEY.
      ********************

014591     MOVE MIR-POL-ID             TO WS-POLICY.
           MOVE WS-POLICY              TO WREPL-POL-ID.
           MOVE WS-POLICY              TO WREPL-ENDBR-POL-ID.
           MOVE MIR-POL-REPL-SEQ-NUM   TO WREPL-POL-REPL-SEQ-NUM.
           MOVE MIR-POL-REPL-SEQ-NUM   TO WREPL-ENDBR-POL-REPL-SEQ-NUM.

       8050-BUILD-REPL-KEY-X.
           EXIT.
      /
      ***********************
       8100-READ-REPL-INFO.
      ***********************

           IF  RREPL-POL-ID = WREPL-POL-ID
           AND RREPL-POL-REPL-SEQ-NUM = WREPL-POL-REPL-SEQ-NUM
               GO TO 8100-READ-REPL-INFO-X
           END-IF.

           PERFORM REPL-1000-READ
              THRU REPL-1000-READ-X.

           IF WREPL-IO-NOT-FOUND
      *MSG:    "RECORD NOT FOUND"
014591         MOVE MIR-POL-ID              TO WGLOB-MSG-PARM (1)
               MOVE MIR-POL-REPL-SEQ-NUM    TO WGLOB-MSG-PARM (3)
               MOVE 'XS00000001'            TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
013578         SET MIR-RETRN-RQST-FAILED TO TRUE
           END-IF.

       8100-READ-REPL-INFO-X.
           EXIT.
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
      ***********************
       9100-BLANK-DATA-FIELDS.
      ***********************

013578     IF  WS-BUS-FCN-BROWSE
               MOVE SPACES            TO MIR-POL-REPL-SEQ-NUM-G
018844         MOVE SPACES            TO MIR-POL-REPL-DIR-CD-G
               MOVE SPACES            TO MIR-POL-REPL-TYP-CD-G
               MOVE SPACES            TO MIR-REPL-CO-CLI-ID-G
               MOVE SPACES            TO MIR-REPL-POL-ID-G
               MOVE SPACES            TO MIR-POL-REPL-OVRID-IND-G
           ELSE
018844         MOVE SPACES            TO MIR-POL-REPL-DIR-CD
               MOVE SPACES            TO MIR-POL-REPL-TYP-CD
               MOVE SPACES            TO MIR-REPL-CO-CLI-ID
               MOVE SPACES            TO MIR-REPL-POL-ID
               MOVE SPACES            TO MIR-POL-REPL-OVRID-IND
               MOVE SPACES            TO MIR-POL-REPL-STAT-CD
               MOVE SPACES            TO MIR-POL-REPL-PRT-DT
           END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
      ***************************
       9200-MOVE-RECORD-TO-SCREEN.
      ***************************

013578     IF WS-BUS-FCN-BROWSE
               PERFORM 9210-MOVE-REPL-TO-SCRN-1
                  THRU 9210-MOVE-REPL-TO-SCRN-1-X
                VARYING I FROM 1 BY 1
                  UNTIL I > WS-MAX-BROWSE-LINES
                     OR WREPL-IO-EOF

               IF  NOT WREPL-IO-EOF
                   MOVE RREPL-POL-ID           TO WS-POLICY
014591             MOVE WS-POLICY              TO MIR-POL-ID
                   MOVE RREPL-POL-REPL-SEQ-NUM TO MIR-POL-REPL-SEQ-NUM
               END-IF

               IF  WREPL-IO-EOF
               AND MIR-POL-REPL-SEQ-NUM-T (1) NOT = SPACES
                   MOVE MIR-POL-REPL-SEQ-NUM-T (1)
                                             TO MIR-POL-REPL-SEQ-NUM
               END-IF
           ELSE
018844         MOVE RREPL-POL-REPL-DIR-CD    TO MIR-POL-REPL-DIR-CD
               MOVE RREPL-POL-REPL-TYP-CD    TO MIR-POL-REPL-TYP-CD
               MOVE RREPL-REPL-CO-CLI-ID     TO MIR-REPL-CO-CLI-ID
               MOVE RREPL-REPL-POL-ID        TO MIR-REPL-POL-ID
               MOVE RREPL-POL-REPL-OVRID-IND TO MIR-POL-REPL-OVRID-IND
               MOVE RREPL-POL-REPL-STAT-CD   TO MIR-POL-REPL-STAT-CD
               MOVE RREPL-POL-REPL-PRT-DT    TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               IF  L1640-VALID
                   MOVE L1640-EXTERNAL-DATE  TO MIR-POL-REPL-PRT-DT
               ELSE
                   MOVE SPACES               TO MIR-POL-REPL-PRT-DT
               END-IF
            END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      /
      *************************
       9210-MOVE-REPL-TO-SCRN-1.
      *************************

           MOVE RREPL-POL-REPL-SEQ-NUM   TO MIR-POL-REPL-SEQ-NUM-T (I).
018844     MOVE RREPL-POL-REPL-DIR-CD    TO MIR-POL-REPL-DIR-CD-T (I).
           MOVE RREPL-POL-REPL-TYP-CD    TO MIR-POL-REPL-TYP-CD-T (I).
           MOVE RREPL-REPL-POL-ID        TO MIR-REPL-POL-ID-T (I).
           MOVE RREPL-REPL-CO-CLI-ID     TO MIR-REPL-CO-CLI-ID-T (I).
           MOVE RREPL-POL-REPL-OVRID-IND
                TO MIR-POL-REPL-OVRID-IND-T (I).


           PERFORM REPL-2000-READ-NEXT
              THRU REPL-2000-READ-NEXT-X.

       9210-MOVE-REPL-TO-SCRN-1-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
      **************************
       9300-SETUP-MSIN-REFERENCE.
      **************************

           MOVE SPACES                      TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE          TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5950-0000-INIT-PARM-INFO
025970         THRU 5950-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-WORKING-STORAGE.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-MAX-BR-LINES        TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ******************************************************************
      *                      PROCESSING COPYBOOKS                      *
      ******************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      /
      ******************************************************************
      *                      LINK COPYBOOKS                            *
      ******************************************************************
025970 COPY XCPS8090.
       COPY CCPSPGA.

020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY XCPS1640.
       COPY XCPL1640.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
016537*COPY CCPL0620.

018764*COPY CCCL2435.
018764 COPY CCPL2435.
       COPY CCPS2435.

018764*COPY CCCL5950.
018764 COPY CCPL5950.
       COPY CCPS5950.

018764*COPY CCCL0289.
018764 COPY CCPL0289.
016503 COPY CCPS0289.

018764*COPY CCCL5400.
018764 COPY CCPL5400.
016440 COPY CCPS5400.

018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      ******************************************************************
      *                     FILE HANDLING COPYBOOKS                    *
      ******************************************************************
       COPY CCPFREPL.
       COPY CCPAREPL.
       COPY CCPNREPL.
       COPY CCPBREPL.
       COPY CCPCREPL.
       COPY CCPUREPL.
       COPY CCPXREPL.
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
015672 COPY CCPNCVG.
015672 COPY NCPPCVGS.
      ******************************************************************
      *                  END OF PROGRAM NSOM3200                       *
      ******************************************************************
