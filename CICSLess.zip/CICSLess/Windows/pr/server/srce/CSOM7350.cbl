      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7350.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7350                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE RETRIEVE FUNCTION **
      **            FOR THE PDCL AND PDCB TABLE                      **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
026055**  6.6       INTEREST ON DELAYED DEATH CLAIMS                 **
028928**  6.7       DON'T GENERATE ROUND OFF EDIT BENE CLAIM AMT = 0 **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
035251**  7.1       MOVE MXDX TO RH AND RT                           **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7350'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-RETRIEVE          VALUE '7350'.
           05  WS-PDCL-INFO.
               10  WS-PDCL-DTHCLM-SEQ-NUM       PIC S9(04) BINARY.
           05  WS-PDCB-INFO.
               10  WS-PDCB-SUB                  PIC S9(04) BINARY.
               10  WS-TOT-PDCB-REC              PIC S9(04) BINARY.
               10  WS-ROLE                      PIC S9(04) BINARY.
               10  WS-ADJ-BENE                  PIC S9(04) BINARY.
           05  WS-PDCL-DISPLAY-KEY.
               10  WS-COMPANY-ID                PIC X(02).
               10  WS-POLICY-ID                 PIC X(10).
               10  WS-SEQ-NUM                   PIC 9(04).
           05  WS-TOT-DCBNFY-PD-AMT             PIC S9(13)V9(02) COMP-3.
           05  WS-DIFF-DCBNFY-PD-AMT            PIC S9(02)V9(02) COMP-3.

       01  WS-PDCB-DCBNFY-AREA.
           05  WS-PDCB-DCBNFY-INFO              OCCURS 99 TIMES.
               10  WS-DCBNFY-CLI-ID             PIC X(10).
               10  WS-DCBNFY-PD-AMT             PIC S9(11)V9(02) COMP-3.
               10  WS-DCBNFY-PCT                PIC S9(03)V9(02) COMP-3.
               10  WS-DCBNFY-INT-PD-AMT         PIC S9(11)V9(02) COMP-3.
               10  WS-DCBNFY-PD-DT              PIC X(10).
               10  WS-DCBNFY-REVRS-DT           PIC X(10).
               10  WS-DCBNFY-PAYO-CD            PIC X(01).
               10  WS-DCBNFY-FED-CALC-CD        PIC X(01).
               10  WS-FED-TAXWH-AMT             PIC S9(11)V9(02) COMP-3.
               10  WS-DCBNFY-BPSS-IND           PIC X(01).
               10  WS-DCBNFY-STAT-CD            PIC X(01).
                   88 WS-DCBNFY-STAT-PEND       VALUE '1'.
                   88 WS-DCBNFY-STAT-TOT-PD     VALUE '2'.
                   88 WS-DCBNFY-STAT-INT-PD     VALUE '3'.
                   88 WS-DCBNFY-STAT-DTH-CLM-PD VALUE '4'.

       01  WS-CONSTANT-AREA.
           05  WS-TWRK-KEY                      PIC X(04).
               88 WS-TWRK-KEY-DEFAULT           VALUE '7350'.
           05  WS-MAX-PDCB-CTR                  PIC S9(4).
               88 WS-MAX-PDCB-CTR-DEFAULT       VALUE 99.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWLOCK.
       COPY CCWWINDX.
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRCVG.
       COPY CCFWCVG.

       COPY CCFRPOL.
       COPY CCFWPOL.

       COPY CCFRPH.
       COPY CCFWPH.

       COPY CCFWPDCL.
       COPY CCFRPDCL.

       COPY CCFWPDCB.
       COPY CCFRPDCB.

       COPY CCWWCVGS.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
028298 COPY CCWL2626.
       COPY CCWL3330.
       COPY CCWL5120.
       COPY CCWLDCIN.
       COPY CCWLPGA.

       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL0317.
       COPY XCWL1640.
       COPY XCWL8090.
       COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7350.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7350'           TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *--------------
       2000-RETRIEVE.
      *--------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

      * VALIDATE KEY INFO

           PERFORM  8000-EDIT-INFO
               THRU 8000-EDIT-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

      * GET LOCATION GROUP

            PERFORM  6000-GET-LOCATION-GROUP
                THRU 6000-GET-LOCATION-GROUP-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

      * INITIALIZE OUTPUT FIELDS

           PERFORM  8100-BLANK-DATA-FIELDS
               THRU 8100-BLANK-DATA-FIELDS-X.

           INITIALIZE WS-PDCB-DCBNFY-AREA.

      * BUILD PDCL INFORMATION

           PERFORM  2100-BUILD-PDCL-INFO
               THRU 2100-BUILD-PDCL-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  8100-BLANK-DATA-FIELDS
                   THRU 8100-BLANK-DATA-FIELDS-X
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

      * BUILD PDCB INFORMATION

           PERFORM  2200-BUILD-PDCB-INFO
               THRU 2200-BUILD-PDCB-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  8100-BLANK-DATA-FIELDS
                   THRU 8100-BLANK-DATA-FIELDS-X
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

       2000-RETRIEVE-X.
           EXIT.

      *---------------------
       2100-BUILD-PDCL-INFO.
      *---------------------

           MOVE LOW-VALUES              TO WPDCL-KEY.
           MOVE WGLOB-COMPANY-CODE      TO WPDCL-CO-ID.
           MOVE RPOL-POL-ID             TO WPDCL-POL-ID.
           MOVE WS-PDCL-DTHCLM-SEQ-NUM  TO WPDCL-DTHCLM-SEQ-NUM.

           PERFORM  PDCL-1000-READ
               THRU PDCL-1000-READ-X.

           IF  NOT WPDCL-IO-OK
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'XS00000001'          TO WGLOB-MSG-REF-INFO
               MOVE WPDCL-KEY             TO WS-PDCL-DISPLAY-KEY
               MOVE 0                     TO L0290-PRECISION
               MOVE LENGTH OF WS-SEQ-NUM  TO L0290-MAX-OUT-LEN
               MOVE WPDCL-DTHCLM-SEQ-NUM  TO L0290-INPUT-NUMBER
               PERFORM  0290-1000-NUMERIC-FORMAT
                   THRU 0290-1000-NUMERIC-FORMAT-X
               MOVE L0290-OUTPUT-DATA     TO WS-SEQ-NUM
               MOVE WS-PDCL-DISPLAY-KEY   TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2100-BUILD-PDCL-INFO-X
           END-IF.

           PERFORM  2110-MOVE-PDCL-TO-MIR
               THRU 2110-MOVE-PDCL-TO-MIR-X.

       2100-BUILD-PDCL-INFO-X.
           EXIT.

      *----------------------
       2110-MOVE-PDCL-TO-MIR.
      *----------------------

           MOVE RPDCL-CVG-NUM            TO MIR-CVG-NUM.

           MOVE RPDCL-DTHCLM-AMT         TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DTHCLM-AMT TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DTHCLM-AMT.

           MOVE RPDCL-DTHCLM-ADDL-AMT    TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DTHCLM-ADDL-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DTHCLM-ADDL-AMT.

           MOVE RPDCL-DTHCLM-INT-DT-CD   TO MIR-DTHCLM-INT-DT-CD.

           MOVE RPDCL-DTHCLM-INT-STRT-DT TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO MIR-DTHCLM-INT-STRT-DT.

           MOVE RPDCL-DTHCLM-INT-PCT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DTHCLM-INT-PCT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DTHCLM-INT-PCT.

           MOVE RPDCL-DTHCLM-STAT-CD     TO MIR-DTHCLM-STAT-CD.

           MOVE RPDCL-DTHCLM-CREAT-DT    TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO MIR-DTHCLM-CREAT-DT.

           MOVE RPDCL-DTHCLM-OVRID-IND   TO MIR-DTHCLM-OVRID-IND.

           MOVE RPDCL-DTHCLM-COMNT-INFO-TXT
                                         TO MIR-DTHCLM-COMNT-INFO.

       2110-MOVE-PDCL-TO-MIR-X.
           EXIT.

      *---------------------
       2200-BUILD-PDCB-INFO.
      *---------------------

      * INITIALIZE PX CALCULATION PARAMETERS

           PERFORM  2202-INIT-PCALC-EXIT-DCIN
               THRU 2202-INIT-PCALC-EXIT-DCIN-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2200-BUILD-PDCB-INFO-X
           END-IF.

      * BROWSE PDCB

           MOVE LOW-VALUES               TO WPDCB-KEY.
           MOVE WGLOB-COMPANY-CODE       TO WPDCB-CO-ID.
           MOVE RPOL-POL-ID              TO WPDCB-POL-ID.
           MOVE WS-PDCL-DTHCLM-SEQ-NUM   TO WPDCB-DTHCLM-SEQ-NUM.

           MOVE WPDCB-KEY                TO WPDCB-ENDBR-KEY.
           MOVE HIGH-VALUES              TO WPDCB-ENDBR-CLI-ID.

           PERFORM  PDCB-1000-BROWSE
               THRU PDCB-1000-BROWSE-X.

           PERFORM  PDCB-2000-READ-NEXT
               THRU PDCB-2000-READ-NEXT-X.

           IF  WPDCB-IO-EOF
               PERFORM  PDCB-3000-END-BROWSE
                   THRU PDCB-3000-END-BROWSE-X
      *MSG: PENDING INTEREST ON DEATH CLAIM BENEFICIARY RECORD DOES
      *     NOT EXIST.
               MOVE 'CS73500001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2200-BUILD-PDCB-INFO-X
           END-IF.

           PERFORM  2210-BROWSE-PDCB
               THRU 2210-BROWSE-PDCB-X
               VARYING WS-PDCB-SUB FROM 1 BY +1
               UNTIL   WS-PDCB-SUB > WS-MAX-PDCB-CTR
               OR      WPDCB-IO-EOF
               OR      WGLOB-MSG-ERROR-SW > ZERO.

           IF  WPDCB-IO-EOF
           OR  WGLOB-MSG-ERROR-SW > ZERO
               CONTINUE
           ELSE
      *MSG:   'BENEIFICARY RECORED EXCEEDS MAXIMUM'
               MOVE 'CS73500002'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  PDCB-3000-END-BROWSE
               THRU PDCB-3000-END-BROWSE-X.

      * CALL PRODUCTXPRESS TO CALCULATE DEATH CLAIM AMT AND INTEREST

            PERFORM  2230-PX-CALC-DCIN
                THRU 2230-PX-CALC-DCIN-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2200-BUILD-PDCB-INFO-X
           END-IF.

      * ADJUST PD ROUND OFF

           PERFORM  2240-ADJUST-PD-ROUND-OFF
               THRU 2240-ADJUST-PD-ROUND-OFF-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2200-BUILD-PDCB-INFO-X
           END-IF.

       2200-BUILD-PDCB-INFO-X.
           EXIT.

      *--------------------------
       2202-INIT-PCALC-EXIT-DCIN.
      *--------------------------

      * EXIT IF PDCL STATUS NOT = PENDING , ERROR AND PARTIALLY PAID

           IF  RPDCL-DTHCLM-STAT-PEND
           OR  RPDCL-DTHCLM-STAT-ERROR
           OR  RPDCL-DTHCLM-STAT-PARTL-PD
               CONTINUE
           ELSE
               GO TO 2202-INIT-PCALC-EXIT-DCIN-X
           END-IF.

      * EXIT IF NO INTEREST START DATE

           IF  RPDCL-DTHCLM-INT-STRT-DT = WWKDT-ZERO-DT
               MOVE RPDCL-DTHCLM-INT-STRT-DT
                 TO LDCIN-DTHCLM-INT-STRT-DT
               GO TO 2202-INIT-PCALC-EXIT-DCIN-X
           END-IF.

           PERFORM  9500-PCALC-EXIT-DCIN
               THRU 9500-PCALC-EXIT-DCIN-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2202-INIT-PCALC-EXIT-DCIN-X
           END-IF.

           PERFORM  DCIN-1000-BUILD-PARM-INFO
               THRU DCIN-1000-BUILD-PARM-INFO-X.

           MOVE RPDCL-CVG-NUM            TO LDCIN-CVG-NUM.
           MOVE RPDCL-DTHCLM-AMT         TO LDCIN-DTHCLM-AMT.
           MOVE RPDCL-DTHCLM-ADDL-AMT    TO LDCIN-DTHCLM-ADDL-AMT.
           MOVE RPDCL-DTHCLM-INT-STRT-DT TO LDCIN-DTHCLM-INT-STRT-DT.
           MOVE L3330-LOC-GR-ID          TO LDCIN-LOC-GR-ID.

       2202-INIT-PCALC-EXIT-DCIN-X.
           EXIT.

      *-----------------
       2210-BROWSE-PDCB.
      *-----------------

      * COUNT TOTAL PDCB

           ADD +1                    TO WS-TOT-PDCB-REC.

           PERFORM  2220-MOVE-PDCB-TO-MIR
               THRU 2220-MOVE-PDCB-TO-MIR-X.

           PERFORM  2222-MOVE-PDCB-TO-WS
               THRU 2222-MOVE-PDCB-TO-WS-X.

      * BUILD PX BENEFICIARY INPUT IF NOT PAID

           IF  RPDCB-DCBNFY-PD-DT = WWKDT-ZERO-DT
               CONTINUE
           ELSE
               PERFORM  PDCB-2000-READ-NEXT
                   THRU PDCB-2000-READ-NEXT-X
               GO TO 2210-BROWSE-PDCB-X
           END-IF.

      * COUNT TOTAL PX ROLES

           ADD +1                    TO LDCIN-ROLE-CTR.

           MOVE RPDCB-CLI-ID
                TO LDCIN-CLI-ID (LDCIN-ROLE-CTR).
           MOVE RPDCB-DCBNFY-PCT
                TO LDCIN-DCBNFY-PCT (LDCIN-ROLE-CTR).
           MOVE RPDCB-DCBNFY-STAT-CD
                TO LDCIN-DCBNFY-STAT-CD (LDCIN-ROLE-CTR).

      * READ NEXT PDCB

           PERFORM  PDCB-2000-READ-NEXT
               THRU PDCB-2000-READ-NEXT-X.

       2210-BROWSE-PDCB-X.
           EXIT.

      *----------------------
       2220-MOVE-PDCB-TO-MIR.
      *----------------------

           MOVE RPDCB-CLI-ID         TO MIR-CLI-ID-T (WS-PDCB-SUB).

           MOVE RPDCB-CLI-ID         TO L5120-CLI-ID.
           PERFORM  5120-1000-CLI-NAME-UPDATE
               THRU 5120-1000-CLI-NAME-UPDATE-X.
           MOVE L5120-CLI-NAME       TO MIR-DV-CLI-NM-T (WS-PDCB-SUB).

           MOVE RPDCB-DCBNFY-PCT     TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DCBNFY-PCT-T (WS-PDCB-SUB)
                                     TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DCBNFY-PCT-T (WS-PDCB-SUB).

           MOVE RPDCB-DCBNFY-PD-AMT  TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DCBNFY-PD-AMT-T (WS-PDCB-SUB)
                                     TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO
                                  MIR-DCBNFY-PD-AMT-T (WS-PDCB-SUB).

           MOVE RPDCB-DCBNFY-INT-PD-AMT
                                     TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DCBNFY-INT-PD-AMT-T (WS-PDCB-SUB)
                                     TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO
                                  MIR-DCBNFY-INT-PD-AMT-T (WS-PDCB-SUB).

           MOVE RPDCB-DCBNFY-PD-DT   TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO
                                    MIR-DCBNFY-PD-DT-T (WS-PDCB-SUB).

           MOVE RPDCB-DCBNFY-REVRS-DT TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO
                                    MIR-DCBNFY-REVRS-DT-T (WS-PDCB-SUB).

           MOVE RPDCB-DCBNFY-PAYO-CD TO
                                     MIR-DCBNFY-PAYO-CD-T (WS-PDCB-SUB).

           MOVE RPDCB-DCBNFY-FED-CALC-CD TO
                                 MIR-DCBNFY-FED-CALC-CD-T (WS-PDCB-SUB).

029060*    MOVE RPDCB-FED-TAXWH-AMT  TO L0290-INPUT-V02.
029060     MOVE RPDCB-FTAXWH-AMT     TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-AMT-T (WS-PDCB-SUB)
029060     MOVE LENGTH OF MIR-FTAXWH-AMT-T (WS-PDCB-SUB)
                                     TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO
029060*                            MIR-FED-TAXWH-AMT-T (WS-PDCB-SUB).
029060                             MIR-FTAXWH-AMT-T (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-STAT-CD TO
                                  MIR-DCBNFY-STAT-CD-T (WS-PDCB-SUB).

           MOVE RPDCB-DCBNFY-BPSS-IND TO
                                  MIR-DCBNFY-BPSS-IND-T (WS-PDCB-SUB).

       2220-MOVE-PDCB-TO-MIR-X.
           EXIT.

      *---------------------
       2222-MOVE-PDCB-TO-WS.
      *---------------------

           MOVE RPDCB-CLI-ID         TO WS-DCBNFY-CLI-ID (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-PD-AMT  TO WS-DCBNFY-PD-AMT (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-PCT     TO WS-DCBNFY-PCT (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-INT-PD-AMT
                                 TO WS-DCBNFY-INT-PD-AMT (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-PD-DT   TO WS-DCBNFY-PD-DT (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-REVRS-DT TO
                                       WS-DCBNFY-REVRS-DT (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-PAYO-CD TO WS-DCBNFY-PAYO-CD (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-FED-CALC-CD TO
                                    WS-DCBNFY-FED-CALC-CD (WS-PDCB-SUB).
029060*    MOVE RPDCB-FED-TAXWH-AMT   TO WS-FED-TAXWH-AMT (WS-PDCB-SUB).
029060     MOVE RPDCB-FTAXWH-AMT      TO WS-FED-TAXWH-AMT (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-BPSS-IND TO
                                       WS-DCBNFY-BPSS-IND (WS-PDCB-SUB).
           MOVE RPDCB-DCBNFY-STAT-CD TO WS-DCBNFY-STAT-CD (WS-PDCB-SUB).

       2222-MOVE-PDCB-TO-WS-X.
           EXIT.

      *------------------
       2230-PX-CALC-DCIN.
      *------------------

      * CALL PRODUCTXPRESS TO CALCULATE DEATH CLAIM AMT AND INTEREST
      * IF PDCL STATUS = PENDING OR ERROR OR PARTIALLY PAID

           IF  RPDCL-DTHCLM-STAT-PEND
           OR  RPDCL-DTHCLM-STAT-ERROR
           OR  RPDCL-DTHCLM-STAT-PARTL-PD
               CONTINUE
           ELSE
               GO TO 2230-PX-CALC-DCIN-X
           END-IF.

      * EXIT IF NO INTEREST START DATE

           IF  LDCIN-DTHCLM-INT-STRT-DT = WWKDT-ZERO-DT
               GO TO 2230-PX-CALC-DCIN-X
           END-IF.

           PERFORM  DCIN-1000-CALC-DCBNFY-INT
               THRU DCIN-1000-CALC-DCBNFY-INT-X.

           IF  NOT LDCIN-RETRN-OK
               GO TO 2230-PX-CALC-DCIN-X
           END-IF.

      * RETURN OUTPUTS TO MIR

           MOVE LDCIN-DTHCLM-INT-PCT       TO L0290-INPUT-V02.
           MOVE 2                          TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DTHCLM-INT-PCT
                                           TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA          TO MIR-DTHCLM-INT-PCT.

           PERFORM  2232-RETRN-PX-DCBNFY
               THRU 2232-RETRN-PX-DCBNFY-X
               VARYING WS-PDCB-SUB FROM +1 BY +1
                 UNTIL WS-PDCB-SUB > WS-TOT-PDCB-REC.

       2230-PX-CALC-DCIN-X.
           EXIT.

      *---------------------
       2232-RETRN-PX-DCBNFY.
      *---------------------

      * MATCH MIR CLIENT ID WITH LDCIN CLIENT ID

           PERFORM
               VARYING WS-ROLE FROM 1 BY +1
                 UNTIL LDCIN-CLI-ID (WS-ROLE) =
                       MIR-CLI-ID-T (WS-PDCB-SUB)
                    OR WS-ROLE > LDCIN-ROLE-CTR
                    CONTINUE
           END-PERFORM.

           IF  WS-ROLE > LDCIN-ROLE-CTR
               GO TO 2232-RETRN-PX-DCBNFY-X
           END-IF.

      * RETURN OUTPUT DEPENDS ON BENEFICIARY STATUS

           EVALUATE TRUE

                WHEN LDCIN-DCBNFY-STAT-PEND (WS-ROLE)
                     MOVE LDCIN-DCBNFY-PD-AMT (WS-ROLE)
                       TO WS-DCBNFY-PD-AMT (WS-PDCB-SUB)
                     MOVE LDCIN-DCBNFY-PD-AMT (WS-ROLE)
                                               TO L0290-INPUT-V02
                     MOVE 2                    TO L0290-PRECISION
                     MOVE LENGTH OF MIR-DCBNFY-PD-AMT-T (WS-PDCB-SUB)
                                               TO L0290-MAX-OUT-LEN
                     PERFORM  0290-2000-FORMAT-FOR-MIR
                         THRU 0290-2000-FORMAT-FOR-MIR-X
                     MOVE L0290-OUTPUT-DATA    TO
                                  MIR-DCBNFY-PD-AMT-T (WS-PDCB-SUB)

                     MOVE LDCIN-DCBNFY-INT-PD-AMT (WS-ROLE)
                       TO WS-DCBNFY-INT-PD-AMT (WS-PDCB-SUB)
                     MOVE LDCIN-DCBNFY-INT-PD-AMT (WS-ROLE)
                                               TO L0290-INPUT-V02
                     MOVE 2                    TO L0290-PRECISION
                     MOVE LENGTH OF MIR-DCBNFY-INT-PD-AMT-T
                                                     (WS-PDCB-SUB)
                                               TO L0290-MAX-OUT-LEN
                     PERFORM  0290-2000-FORMAT-FOR-MIR
                         THRU 0290-2000-FORMAT-FOR-MIR-X
                     MOVE L0290-OUTPUT-DATA    TO
                                MIR-DCBNFY-INT-PD-AMT-T (WS-PDCB-SUB)

                WHEN LDCIN-DCBNFY-STAT-INT-PD (WS-ROLE)
                     MOVE LDCIN-DCBNFY-PD-AMT (WS-ROLE)
                       TO WS-DCBNFY-PD-AMT (WS-PDCB-SUB)
                     MOVE LDCIN-DCBNFY-PD-AMT (WS-ROLE)
                                               TO L0290-INPUT-V02
                     MOVE 2                    TO L0290-PRECISION
                     MOVE LENGTH OF MIR-DCBNFY-PD-AMT-T (WS-PDCB-SUB)
                                               TO L0290-MAX-OUT-LEN
                     PERFORM  0290-2000-FORMAT-FOR-MIR
                         THRU 0290-2000-FORMAT-FOR-MIR-X
                     MOVE L0290-OUTPUT-DATA    TO
                                  MIR-DCBNFY-PD-AMT-T (WS-PDCB-SUB)

                WHEN LDCIN-DCBNFY-STAT-DTH-CLM-PD (WS-ROLE)
                     MOVE LDCIN-DCBNFY-INT-PD-AMT (WS-ROLE)
                       TO WS-DCBNFY-INT-PD-AMT (WS-PDCB-SUB)
                     MOVE LDCIN-DCBNFY-INT-PD-AMT (WS-ROLE)
                                               TO L0290-INPUT-V02
                     MOVE 2                    TO L0290-PRECISION
                     MOVE LENGTH OF MIR-DCBNFY-INT-PD-AMT-T
                                                     (WS-PDCB-SUB)
                                               TO L0290-MAX-OUT-LEN
                     PERFORM  0290-2000-FORMAT-FOR-MIR
                         THRU 0290-2000-FORMAT-FOR-MIR-X
                     MOVE L0290-OUTPUT-DATA    TO
                                MIR-DCBNFY-INT-PD-AMT-T (WS-PDCB-SUB)

           END-EVALUATE.

       2232-RETRN-PX-DCBNFY-X.
           EXIT.
      /
      *-------------------------
       2240-ADJUST-PD-ROUND-OFF.
      *-------------------------

028928* EXIT IF NO INTEREST START DATE
028928
028928     IF  LDCIN-DTHCLM-INT-STRT-DT = WWKDT-ZERO-DT
028928         GO TO 2240-ADJUST-PD-ROUND-OFF-X
028928     END-IF.

           MOVE ZERO                TO WS-TOT-DCBNFY-PD-AMT.
           MOVE ZERO                TO WS-ADJ-BENE.

           PERFORM
               VARYING WS-PDCB-SUB FROM 1 BY +1
                 UNTIL WS-PDCB-SUB > WS-TOT-PDCB-REC

                 ADD WS-DCBNFY-PD-AMT (WS-PDCB-SUB)
                  TO WS-TOT-DCBNFY-PD-AMT

                 IF  WS-DCBNFY-STAT-PEND (WS-PDCB-SUB)
                     MOVE WS-PDCB-SUB   TO WS-ADJ-BENE
                 END-IF

           END-PERFORM.

           IF  WS-ADJ-BENE = ZERO
               GO TO 2240-ADJUST-PD-ROUND-OFF-X
           END-IF.

           COMPUTE WS-DIFF-DCBNFY-PD-AMT = RPDCL-DTHCLM-AMT
                                         + RPDCL-DTHCLM-ADDL-AMT
                                         - WS-TOT-DCBNFY-PD-AMT.

           IF  WS-DIFF-DCBNFY-PD-AMT > 1.00
           OR  WS-DIFF-DCBNFY-PD-AMT < -1.00
      *MSG: SUM OF DEATH CLAIM AMOUNT NOT MATCH TOTAL BENEFICIARY CLAIM
      *     AMOUNT.
               MOVE 'CS73500006'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2240-ADJUST-PD-ROUND-OFF-X
           END-IF.

           COMPUTE WS-DCBNFY-PD-AMT (WS-ADJ-BENE) =
                          WS-DCBNFY-PD-AMT (WS-ADJ-BENE)
                        + WS-DIFF-DCBNFY-PD-AMT.

           MOVE WS-DCBNFY-PD-AMT (WS-ADJ-BENE)
                                        TO L0290-INPUT-V02.
           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DCBNFY-PD-AMT-T (WS-ADJ-BENE)
                                        TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO
                                   MIR-DCBNFY-PD-AMT-T (WS-ADJ-BENE).

       2240-ADJUST-PD-ROUND-OFF-X.
           EXIT.

      *------------------------
       6000-GET-LOCATION-GROUP.
      *------------------------

           MOVE RPOL-POL-BASE-CVG-NUM  TO  I.

           PERFORM  PLIN-1000-PLAN-HEADER-IN
               THRU PLIN-1000-PLAN-HEADER-IN-X.

           PERFORM  3330-1000-BUILD-PARM-INFO
               THRU 3330-1000-BUILD-PARM-INFO-X.

           SET L3330-LOC-GR-TYP-DCIDT   TO TRUE.

           PERFORM  3330-1000-GET-LOC-GROUP
               THRU 3330-1000-GET-LOC-GROUP-X.

           IF  NOT L3330-RETRN-OK
      * MSG: 'LOCATION GROUP NOT FOUND FOR @1,TYPE '@2' BY PGM @3'
               MOVE 'CS00000064'        TO WGLOB-MSG-REF-INFO
               MOVE RPH-LOC-GR-COLCT-ID TO WGLOB-MSG-PARM (1)
               MOVE L3330-LOC-GR-TYP-CD TO WGLOB-MSG-PARM (2)
               MOVE WPGWS-CRNT-PGM-ID   TO WGLOB-MSG-PARM (3)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6000-GET-LOCATION-GROUP-X
           END-IF.

       6000-GET-LOCATION-GROUP-X.
           EXIT.

      *---------------
       8000-EDIT-INFO.
      *---------------

      * VALIDATE KEY INFOMATION

            PERFORM  8010-EDIT-KEY-INFO
                THRU 8010-EDIT-KEY-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8000-EDIT-INFO-X
           END-IF.

      * LOAD WCVGS ARRAY

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8000-EDIT-INFO-X
           END-IF.

       8000-EDIT-INFO-X.
           EXIT.

      *-------------------
       8010-EDIT-KEY-INFO.
      *-------------------
      *
      * VALIDATE POL NUMBER
      *
           MOVE MIR-POL-ID-BASE            TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX             TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'XS00000001'           TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID            TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8010-EDIT-KEY-INFO-X
           END-IF.
      *
      * VALID PDCL SEQ NUM
      *
           SET L0280-SIGN-NOT-PERMITTED    TO TRUE.
           MOVE ZERO                       TO L0280-PRECISION.
           MOVE 4                          TO L0280-LENGTH.
           MOVE 4                          TO L0280-INPUT-SIZE.
           MOVE MIR-DTHCLM-SEQ-NUM         TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG:     'SEQUENCE NUMBER MUST BE VALID NUMERIC'
               MOVE 'CS73500004'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8010-EDIT-KEY-INFO-X
           ELSE
               MOVE L0280-OUTPUT           TO WS-PDCL-DTHCLM-SEQ-NUM
           END-IF.

       8010-EDIT-KEY-INFO-X.
           EXIT.

      *-----------------------
       8100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       8100-BLANK-DATA-FIELDS-X.
           EXIT.
      /

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.
           MOVE MIR-POL-ID-BASE          TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX           TO WGLOB-REF-POLICY-SUFFIX.
           SET WGLOB-REF-POLICY          TO TRUE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *---------------------
       9500-PCALC-EXIT-DCIN.
      *---------------------

           PERFORM  0317-1000-BUILD-PARM-INFO
               THRU 0317-1000-BUILD-PARM-INFO-X.

           SET  L0317-PCALC-EXIT-DTH-CLM-INT  TO TRUE.

           MOVE RPOL-POL-BASE-CVG-NUM   TO I.

           MOVE WCVGS-PLAN-ID (I)       TO L0317-PLAN-ID.

035251*    IF  WCVGS-PLAN-ID-BASE-3-5 (I) = 'RPU'
035251*    OR  WCVGS-PLAN-ID-BASE-3-5 (I) = 'ETI'
035251*        MOVE WCVGS-ORIG-PLAN-ID (I)
035251*                                 TO L0317-PLAN-ID
035251*    END-IF.

           PERFORM  0317-1000-GET-PCALC-EXIT-PGM
               THRU 0317-1000-GET-PCALC-EXIT-PGM-X.

           EVALUATE TRUE

               WHEN L0317-RETRN-NOT-FOUND
               WHEN L0317-RETRN-PX-DISABLE
                    GO TO 9500-PCALC-EXIT-DCIN-X

               WHEN L0317-PCALC-EXIT-STAT-INTRNL
      * MSG: INTERNAL CALCULATION DOES NOT EXIST
                    MOVE 'CS73500005'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    GO TO 9500-PCALC-EXIT-DCIN-X

               WHEN L0317-PCALC-EXIT-STAT-XTRNL
                    CONTINUE

           END-EVALUATE.

       9500-PCALC-EXIT-DCIN-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  0317-0000-INIT-PARM-INFO
               THRU 0317-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
           PERFORM  3330-0000-INIT-PARM-INFO
               THRU 3330-0000-INIT-PARM-INFO-X.

           PERFORM  5120-0000-INIT-PARM-INFO
               THRU 5120-0000-INIT-PARM-INFO-X.

           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           PERFORM  DCIN-0000-INIT-PARM-INFO
               THRU DCIN-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE WS-PDCB-DCBNFY-AREA.
           INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
           INITIALIZE WLOCK-TWRK-OTHER-INFO.
           INITIALIZE FREQUENTLY-USED-INDICES.

           SET WS-TWRK-KEY-DEFAULT      TO TRUE.
           SET WS-MAX-PDCB-CTR-DEFAULT  TO TRUE.
           SET MIR-RETRN-OK             TO TRUE.

           MOVE SPACES TO WWKDT-WORK-FIELDS.
           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
       COPY CCPPPLIN.
       COPY CCPPMIDT.
       COPY NCPPCVGS.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPS8090.
       COPY CCPS3330.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL3330.

       COPY CCPS5120.
       COPY CCPL5120.

       COPY CCPSDCIN.
       COPY CCPLDCIN.

       COPY XCPS0317.
       COPY XCPL0317.

       COPY XCPL0290.
       COPY XCPS0290.

       COPY XCPL0260.
       COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPS1640.
       COPY XCPL1640.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.

       COPY CCPNCVG.

       COPY CCPNPH.

       COPY CCPNPDCL.

       COPY CCPBPDCB.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM7350                     **
      *****************************************************************
