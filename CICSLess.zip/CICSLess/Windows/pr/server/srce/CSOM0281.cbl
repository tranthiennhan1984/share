       IDENTIFICATION DIVISION.
       PROGRAM-ID. CSOM0281.
      *****************************************************************
      **  MEMBER : CSOM0281                                          **
      **  REMARKS: GRPA -  GROUP BILLING ONLINE PROGRAM.             **
      **         THIS PROGRAM IS USED TO MODIFY THE GROUP BILLING    **
      **         FILE.  TYPICALLY THIS SYSTEM IS AUTOMATED SUCH      **
      **         NO ONLINE CHANGES NEED TO BE MADE, BUT IF THERE     **
      **         HAS TO CHANGES MADE TO THE GROUP BILLING THIS IS    **
      **         THE WAY.                                            **
      **         THE GR-FILE IS SPLIT INTO TWO LOGICAL FILES.        **
      **             1) THE HEADER FILE WHICH IS DEFINED BY          **
      **                LOW-VALUES IN THE FIRST BYTE.                **
      **                THIS RECORD CONTAINS THE TOTALS FOR THE      **
      **                GROUP, THE STATUS OF THE GROUP AND           **
      **                INFORMATION WHICH LOCATES THE MEMBERS OF     **
      **                THE GROUP
      **                                                             **
      **             2) THE DETAIL FILE WHICH IS DEFINED BY          **
      **                HIGH-VALUES IN THE FIRST BYTE.               **
      **                THERE EXISTS ONE RECORD FOR EACH POLICY      **
      **                UNDER A GROUP.  THE RECORD CONTAINS THE      **
      **                GROUP WHICH IS BELONGS TO, THE STATUS OF     **
      **                THE PARTICULAR MEMBER, THE WCLI-KEY VALUE    **
      **                OF THE POLICY PAYEE, AND THE AMOUNTS PERTINENT*
      **                TO THE GROUP.                                **
      **                                                             **
      **  DOMAIN :  BC                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURE                **
557668**  5.5       SELECTION LISTS (CLIENT SCRATCHPAD)              **
557697**  5.5       MODIFICATIONS FOR SPECIAL FREQUENCY BILLING      **
557708**  5.5       HANDLING OF CICS ABENDS                          **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
557788**  5.5       POLICY TABLE SPLIT                               **
557973**  5.5       AMOUNT FIELD SIZING FOR INT'L SUPPORT            **
008453**  5.5.2     MULTIPLE EXTERNAL DATE FORMATS                   **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
005409**  5.6       PUT WORK DATES THRU THE DATE ROUTINE TO GET      **
005409**            VALID DATE PRIOR TO MOVING TO DB2 TABLES         **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       CODE CLEAN UP                                    **
010418**  5.6       ADD NEW SUB COMPANY CODE FIELD TO GRPA           **
010418**            SCREEN & ADD LOGIC TO SUPPORT THE NEW FIELD      **
012069**  5.6       CHANGE FOR AS/400 PROCESSING                     **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL LOCKING                                  **
016387**  6.2       REMOVAL OF CLIENT CONSOLIDATION                  **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017195**  6.2       INIT COVERAGE NO BEFORE GETTING PRIMARY INSURED  **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
018243**  6.3       DISPLAY HOLD VALUES BEFORE ZEROING OUT           **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
015705**  6.4       NAME FORMATTING                                  **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025173**  6.6       ALLOW NEXT BILLING TYPE FOR FUTURE DATE UPDATE   **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      *****************************************************************
       COPY XCWWCRHT.
      /
       ENVIRONMENT DIVISION.

       DATA DIVISION.

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0281'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.
      /
      /
014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
           03  TRANSACTION-NAME   PIC X(04) VALUE 'GRPA'.
           03  NUM-ERR-LN         PIC 99    VALUE 01.
           03  ERROR-LINE-SCREEN  PIC 99    VALUE 01.
016548*    03  N8                 PIC 9999 COMP.
016548     03  N8                 PIC 9999 BINARY.
008455*    03  WORK-NUM           PIC 9(7).99.
       01  TRANSACTION-TABLE-DATA.
           03  TRAN-CODE-IDS.
013578         05  FILLER PIC X(10)  VALUE '0280  0000'.
               05  FILLER PIC X(10)  VALUE '0289  0110'.
               05  FILLER PIC X(10)  VALUE '0281  0210'.
               05  FILLER PIC X(10)  VALUE '0283  0300'.
               05  FILLER PIC X(10)  VALUE '0286  0410'.
               05  FILLER PIC X(10)  VALUE '0285  0500'.
               05  FILLER PIC X(10)  VALUE '0284  0600'.
               05  FILLER PIC X(10)  VALUE '0282  0710'.
               05  FILLER PIC X(10)  VALUE '0287  0800'.
               05  FILLER PIC X(10)  VALUE '0288  0900'.
013578*        05  FILLER PIC X(7)  VALUE 'A  0110'.
013578*        05  FILLER PIC X(7)  VALUE 'C  0210'.
013578*        05  FILLER PIC X(7)  VALUE 'D  0300'.
013578*        05  FILLER PIC X(7)  VALUE 'E  0410'.
013578*        05  FILLER PIC X(7)  VALUE 'H  0500'.
013578*        05  FILLER PIC X(7)  VALUE 'I  0600'.
013578*        05  FILLER PIC X(7)  VALUE 'M  0710'.
013578*        05  FILLER PIC X(7)  VALUE 'P  0800'.
013578*        05  FILLER PIC X(7)  VALUE 'R  0900'.
           03  TRAN-CODE-ID-R REDEFINES TRAN-CODE-IDS.
013578*        05  TRAN-CODE-ENTRY OCCURS 09 TIMES.
013578         05  TRAN-CODE-ENTRY OCCURS 10 TIMES.
013578*            07  TRAN-CODE-ID            PIC XXX.
                   07  TRAN-CODE-ID            PIC X(6).
                   07  TRAN-CODE-NUM           PIC 99.
                   07  TRAN-UPDATE-CODE        PIC 9.
                   07  TRAN-MASTER-RQRD-SW     PIC 9.
      /
       01  GRPA-MISCELLANEOUS-WORK-AREAS.
025970*    03  PAGE-LIMIT                PIC S9(4) COMP-3 VALUE +9.
557973*****03  TEMP-WORK-AREA            PIC S9(7)V99.
557973     03  TEMP-WORK-AREA            PIC S9(15)V99.
557973*****03  TEMP-WORK-AREA-TOTAL      PIC S9(7)V99.
557973     03  TEMP-WORK-AREA-TOTAL      PIC S9(15)V99 COMP-3.
           03  TEMP-TAX-AMOUNT           PIC S9(7)V99.
           03  TEMP-TAX-CREDIT           PIC S9(7)V99.
008455*    03  NUMBER-EDIT               PIC Z(6)9.99.
016548*    03  I                   PIC S9(4) COMP VALUE ZERO.
016548     03  I                   PIC S9(4) BINARY VALUE ZERO.
016548*    03  SUB                 PIC S9(4) COMP VALUE ZERO.
016548     03  SUB                 PIC S9(4) BINARY VALUE ZERO.

557973*****03  HOLD-CURR-PREM-DUE  PIC S9(07)V99 COMP-3 VALUE ZERO.
557973     03  HOLD-CURR-PREM-DUE  PIC S9(15)V99 COMP-3 VALUE ZERO.
557973*****03  HOLD-CURR-LOAN      PIC S9(07)V99 COMP-3 VALUE ZERO.
557973     03  HOLD-CURR-LOAN      PIC S9(15)V99 COMP-3 VALUE ZERO.
557973*****03  HOLD-CURR-MISC      PIC S9(07)V99 COMP-3 VALUE ZERO.
557973     03  HOLD-CURR-MISC      PIC S9(15)V99 COMP-3 VALUE ZERO.
557973*****03  HOLD-BILL-PREM-DUE  PIC S9(07)V99 COMP-3 VALUE ZERO.
557973     03  HOLD-BILL-PREM-DUE  PIC S9(15)V99 COMP-3 VALUE ZERO.
557973*****03  HOLD-BILL-LOAN      PIC S9(07)V99 COMP-3 VALUE ZERO.
557973     03  HOLD-BILL-LOAN      PIC S9(15)V99 COMP-3 VALUE ZERO.
557973*****03  HOLD-BILL-MISC      PIC S9(07)V99 COMP-3 VALUE ZERO.
557973     03  HOLD-BILL-MISC      PIC S9(15)V99 COMP-3 VALUE ZERO.
           03  TRAN-INX            PIC 99.
013578       88 RETRIEVE           VALUE 00.
             88 ADDITION           VALUE 01.
             88 CREATION           VALUE 02.
             88 DELETION           VALUE 03.
             88 EXCEPTION-REQ      VALUE 04.
             88 HEADERS            VALUE 05.
             88 INQUIRY            VALUE 06.
             88 MAINTAIN           VALUE 07.
             88 PAYMENT            VALUE 08.
             88 REVERSAL           VALUE 09.
             88 DATE-REQUIRED      VALUE 00 01 02 03 04 06 07 08 09.
016548*    03  TRAN-CODE-INXX      PIC 99    COMP VALUE 1.
025970*    03  TRAN-CODE-INXX      PIC 99    BINARY VALUE 1.
           03  UPDATE-SW           PIC X VALUE '0'.
             88  UPDATE-REQUIRED         VALUE '1'.
025970       88  UPDATE-REQUIRED-DEFAULT VALUE '0'.
           03  STORE-SW            PIC 9 VALUE  0.
           03  ERROR-SW            PIC 9 VALUE  0.
           03  TRAN-CODE-FOUND-SW  PIC X VALUE '0'.
             88  TRAN-CODE-FOUND         VALUE '1'.
025970       88  TRAN-CODE-FOUND-DEFAULT VALUE '0'.
557756*    03  PAID-DATE-MULT.
557756*        05  PAID-DATE-ENG   PIC X(25)
557756*                            VALUE '  GROUP         PAID DATE'.
557756*        05  PAID-DATE-FR    PIC X(25)
557756*                            VALUE ' GROUPE         DATE-FACT'.
557756*        05  PAID-DATE-SP    PIC X(25)
557756*                            VALUE '  CORBO        FECHA-PAGO'.

           03  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-ID-VALID      VALUE
013578              '0280' '0281' '0282' '0283' '0284'
                    '0285' '0286' '0287' '0288' '0289'.
013578         88  WS-BUS-FCN-RETRIEVE    VALUE  '0280'.
               88  WS-BUS-FCN-CREATEH     VALUE  '0281'.
               88  WS-BUS-FCN-SAVE        VALUE  '0282'.
               88  WS-BUS-FCN-DELETEH     VALUE  '0283'.
               88  WS-BUS-FCN-SEARCHI     VALUE  '0284'.
               88  WS-BUS-FCN-SEARCHG     VALUE  '0285'.
               88  WS-BUS-FCN-EXCEPT      VALUE  '0286'.
               88  WS-BUS-FCN-PAYMENT     VALUE  '0287'.
               88  WS-BUS-FCN-REVERSE     VALUE  '0288'.
               88  WS-BUS-FCN-ADD         VALUE  '0289'.
025970*    03  WS-TWRK-KEY                PIC X(04)  VALUE '0280'.
           03  HOLD-NAME-1                PIC X(10).
008453*    03  HOLD-DATE-1                PIC X(9).
008453     03  HOLD-DATE-1                PIC X(10).
           03  HOLD-POL-ID-1.
               10  HOLD-POLICY-1          PIC X(9).
               10  HOLD-SUFFIX-1          PIC X.
      /
       01  MIR-MISCELLANEOUS-SCREEN-WORK.
           03  HOLD-MAP-INFO.
               05  HOLD-GR                  PIC X(10).
010418         05  HOLD-SUBCO               PIC X(02).
               05  HOLD-POLICY.
                   07  HOLD-POLICY-NO       PIC X(09).
                   07  HOLD-POLICY-SUFFIX   PIC X(01).
               05  HOLD-PAID-DATE           PIC X(10).
008453*        05  HOLD-PAID-DATE-EXTERNAL  PIC X(9).
008453         05  HOLD-PAID-DATE-EXTERNAL  PIC X(10).
               05  HOLD-STATUS              PIC X     VALUE SPACES.
008455         05  HOLD-MPREM-X             PIC X(17).
008455         05  HOLD-MLOAN-X             PIC X(17).
008455         05  HOLD-MMISC-X             PIC X(14).
008455         05  HOLD-MPREM               PIC S9(13)V99.
008455         05  HOLD-MLOAN               PIC S9(13)V99.
008455         05  HOLD-MMISC               PIC S9(11)V99.
008455*        05  HOLD-MPREM.
008455*            07  HOLD-MPREM-1-X       PIC X(7).
008455*            07  HOLD-MPREM-1-N  REDEFINES
008455*                      HOLD-MPREM-1-X PIC 9(7).
008455*            07  HOLD-MPREM-PT      PIC X.
008455*            07  HOLD-MPREM-2-X       PIC XX.
008455*            07  HOLD-MPREM-2-N  REDEFINES
008455*                      HOLD-MPREM-2-X PIC V99.
008455*        05  HOLD-MLOAN.
008455*            07  HOLD-MLOAN-1-X       PIC X(7).
008455*            07  HOLD-MLOAN-1-N  REDEFINES
008455*                      HOLD-MLOAN-1-X PIC 9(7).
008455*            07  HOLD-MLOAN-PT      PIC X.
008455*            07  HOLD-MLOAN-2-X       PIC XX.
008455*            07  HOLD-MLOAN-2-N  REDEFINES
008455*                      HOLD-MLOAN-2-X PIC V99.
008455*        05  HOLD-MMISC.
008455*            07  HOLD-MMISC-1-X       PIC X(7).
008455*            07  HOLD-MMISC-1-N  REDEFINES
008455*                      HOLD-MMISC-1-X PIC 9(7).
008455*            07  HOLD-MMISC-PT      PIC X.
008455*            07  HOLD-MMISC-2-X       PIC XX.
008455*            07  HOLD-MMISC-2-N  REDEFINES
008455*                      HOLD-MMISC-2-X PIC V99.
           03  TRAN-CODE-HOLD     PIC X(4).
014221     03  WS-SAVE-GR-INFO    PIC X(200).

025970 01  WS-CONSTANT-FIELDS.
025970     05  PAGE-LIMIT                  PIC S9(4) COMP-3.
025970         88  PAGE-LIMIT-DEFAULT      VALUE +9.
025970     05  TRAN-CODE-INXX              PIC 99    BINARY.
025970         88  TRAN-CODE-INXX-DEFAULT  VALUE 1.
025970     05  WS-TWRK-KEY                 PIC X(04).
025970         88 WS-TWRK-KEY-DEFAULT      VALUE '0280'.
      /
      *****************************************************************
      **************  F I L E   W O R K   A R E A S  ******************
      *****************************************************************
      *
014221 COPY CCWWLOCK.
      /
020478 COPY CCWL2626.
008455 COPY XCWL0280.
008455/
008455 COPY XCWL0290.
      /
016108 COPY CCWL0985.
016108/
       COPY CCWL2430.
      /
       COPY CCWL2435.
      /
       COPY CCWL5600.
      /
016440 COPY CCWL5400.
      /
013578*COPY XCWL2490.
      /
014221 COPY XCWL8090.
      /
557668 COPY CCWL0620.
      /
557697 COPY CCWL2520.
557697/
020478 COPY CCWL2625.
557697 COPY CCWWSFBL.
557697/
       COPY XCWWWKDT.
      /
       COPY XCWLDTLK.
      /
       COPY XCWL1640.
      /
       COPY XCWL1670.
005409 COPY XCWL1680.
      /
      *****************************************************************
       01  WS-NAME.
           07  GROUP-NO     PIC X(10).
           07  FILLER       PIC X(06)  VALUE SPACES.
008453*    07  PAID-DATE    PIC X(09).
008453     07  PAID-DATE    PIC X(10).
           07  FILLER       PIC X(05)  VALUE SPACES.
      /
010418 COPY CCFWSCOM.
010418 COPY CCFRSCOM.
      /
       COPY CCFWPOL.
      /
       COPY CCFWCVG.
      /
       COPY CCFRCVG.
      /
       COPY CCFRGR.
      /
       COPY CCFWGR.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
016108 COPY CCWLPGA.

       COPY CCFRPOL.

       COPY CCWWCVGS.
      /
       LINKAGE SECTION.

CVMQ71 COPY XCWWDFH.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0281.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *****************************************************************
      *****           S T A R T    O F    P R O G R A M            ****
      *****************************************************************
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.
008455
           PERFORM  0200-PROCESS-REQUEST
               THRU 0200-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
016537     GOBACK.

       0000-MAINLINE-X.
016537*    GOBACK.
016537     EXIT.

      *--------------------------
       0200-PROCESS-REQUEST.
      *--------------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.


013578     IF  NOT WS-BUS-FCN-ID-VALID
      *MSG: INVALID FUNCTION ID - PROCESSING STOPPED
               MOVE MIR-BUS-FCN-ID           TO WGLOB-MSG-PARM (1)
               MOVE 'CSOM0281'               TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-INVALD-RQST TO TRUE
               GO TO 0200-PROCESS-REQUEST-X
557660     END-IF.

      ********************************************************
      **     ONLY MOVE INFORMATION THAT IS PERTINENT        **
      ********************************************************

           MOVE WS-BUS-FCN-ID         TO TRAN-CODE-HOLD.
           MOVE MIR-LBILL-CLI-ID      TO HOLD-GR.
010311     MOVE MIR-LBILL-CLI-ID      TO HOLD-NAME-1.
010418     MOVE MIR-SBSDRY-CO-ID      TO HOLD-SUBCO.
           MOVE MIR-LBILL-EFF-DT      TO HOLD-PAID-DATE-EXTERNAL.
010311     MOVE MIR-LBILL-EFF-DT      TO HOLD-DATE-1.
           MOVE MIR-POL-ID-BASE       TO HOLD-POLICY-NO.
           MOVE MIR-POL-ID-SFX        TO HOLD-POLICY-SUFFIX.
008455*    MOVE MIR-LBILL-POL-PREM-AMT         TO HOLD-MPREM.
008455*    MOVE MIR-LBILL-POL-LPAY-AMT       TO HOLD-MLOAN.
008455*    MOVE MIR-POL-SNDRY-AMT          TO HOLD-MMISC.


008455     MOVE MIR-LBILL-POL-PREM-AMT                  TO HOLD-MPREM-X.
008455     MOVE HOLD-MPREM-X          TO L0280-INPUT-DATA.
008455     MOVE 'N'                   TO L0280-SIGN-IND.
008455     MOVE 2                     TO L0280-PRECISION.
008455     MOVE LENGTH OF MIR-LBILL-POL-PREM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
008455     PERFORM 0280-1000-NUMERIC-EDIT
008455        THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF  L0280-OK
008455         MOVE L0280-OUTPUT-DOLLAR
008455                                TO HOLD-MPREM
008455     ELSE
008455         MOVE 0                 TO HOLD-MPREM
008455     END-IF.
008455
008455     MOVE MIR-LBILL-POL-LPAY-AMT                  TO HOLD-MLOAN-X.
008455     MOVE HOLD-MLOAN-X          TO L0280-INPUT-DATA.
008455     MOVE 'N'                   TO L0280-SIGN-IND.
008455     MOVE 2                     TO L0280-PRECISION.
008455     MOVE LENGTH OF MIR-LBILL-POL-LPAY-AMT
008455                                TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
008455     PERFORM 0280-1000-NUMERIC-EDIT
008455        THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF  L0280-OK
008455         MOVE L0280-OUTPUT-DOLLAR
008455                                TO HOLD-MLOAN
008455     ELSE
008455         MOVE 0                 TO HOLD-MLOAN
008455     END-IF.
008455
008455     MOVE MIR-POL-SNDRY-AMT     TO HOLD-MMISC-X.
008455     MOVE HOLD-MMISC-X          TO L0280-INPUT-DATA.
008455     MOVE 'N'                   TO L0280-SIGN-IND.
008455     MOVE 2                     TO L0280-PRECISION.
008455     MOVE LENGTH OF MIR-POL-SNDRY-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
008455     PERFORM 0280-1000-NUMERIC-EDIT
008455        THRU 0280-1000-NUMERIC-EDIT-X.
008455     IF  L0280-OK
008455         MOVE L0280-OUTPUT-DOLLAR
008455                                TO HOLD-MMISC
008455     ELSE
008455         MOVE 0                 TO HOLD-MMISC
008455     END-IF.

016440     MOVE HOLD-POLICY           TO WPOL-POL-ID.
016440     PERFORM  POL-1000-READ
016440         THRU POL-1000-READ-X.
016440
016440     PERFORM  5400-1000-BUILD-PARM-INFO
016440         THRU 5400-1000-BUILD-PARM-INFO-X.
016440     SET L5400-POL-XFER-UPDATE      TO TRUE.
016440     PERFORM  5400-1000-POL-CHK
016440         THRU 5400-1000-POL-CHK-X.
016440
016440*    CHECK THE ACCESS RESTRICTION CODES
016440
016440     IF  L5400-XFER-ACCS-RESTRICTED
016440         GO TO 0200-PROCESS-REQUEST-X
016440     END-IF

012069     MOVE ZERO                  TO TRAN-CODE-FOUND-SW.

           PERFORM  0210-FIND-TRAN-CODE
               THRU 0210-FIND-TRAN-CODE-X
               VARYING TRAN-CODE-INXX FROM 1 BY 1
               UNTIL   TRAN-CODE-INXX > 10
               OR      TRAN-CODE-FOUND.

           IF  TRAN-CODE-INXX     >  11
               MOVE 'CS02810045'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 0200-PROCESS-REQUEST-X
557660     END-IF.

010418     PERFORM 0205-EDIT-SUB-COMPANY-CODE
010418        THRU 0205-EDIT-SUB-COMPANY-CODE-X.

           IF DATE-REQUIRED
           OR (HOLD-PAID-DATE-EXTERNAL NOT = SPACES)
               PERFORM  0215-CHECK-PAID-DATE
                   THRU 0215-CHECK-PAID-DATE-X
           ELSE
               MOVE WWKDT-LOW-DT      TO HOLD-PAID-DATE
557660     END-IF.

016108*
016108* VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108     IF  WS-BUS-FCN-ADD
016108     OR  WS-BUS-FCN-EXCEPT
016108     OR  WS-BUS-FCN-SAVE
016108         PERFORM  0300-VAL-POL-DT-OF-DTH
016108             THRU 0300-VAL-POL-DT-OF-DTH-X
016108     END-IF.
016108
016108     IF  WS-BUS-FCN-PAYMENT
016108     OR  WS-BUS-FCN-REVERSE
016108         PERFORM  0310-VAL-CLI-DT-OF-DTH
016108             THRU 0310-VAL-CLI-DT-OF-DTH-X
016108     END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 0200-PROCESS-REQUEST-X
557660     END-IF.

           PERFORM  0220-SET-HEADER-KEY
               THRU 0220-SET-HEADER-KEY-X.

           IF  NOT HEADERS
           PERFORM  GR-1000-READ-FOR-UPDATE
               THRU GR-1000-READ-FOR-UPDATE-X
557660     END-IF.

           IF  NOT WGR-IO-OK
               IF  TRAN-CODE-HOLD NOT = '0281'
               AND TRAN-CODE-HOLD NOT = '0285'
                   MOVE 'CS02810002'  TO WGLOB-MSG-REF-INFO
                   MOVE 0             TO UPDATE-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
016537*            GO TO 0200-PROCESS-END
016537             PERFORM  0201-PROCESS-END
016537                 THRU 0201-PROCESS-END-X
016537             GO TO 0200-PROCESS-REQUEST-X
557660         END-IF
557660     END-IF.

           IF  WGR-IO-OK
           AND TRAN-CODE-HOLD     =  '0281'
               MOVE 'CS02810003'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
016537*        GO TO 0200-PROCESS-END
016537         PERFORM  0201-PROCESS-END
016537             THRU 0201-PROCESS-END-X
016537         GO TO 0200-PROCESS-REQUEST-X
557660     END-IF.

           IF  WGR-IO-OK
               IF  ADDITION
               OR  EXCEPTION-REQ
               OR  MAINTAIN
               OR  INQUIRY
013578         OR  RETRIEVE
014221         OR  DELETION
                   PERFORM  GR-3000-UNLOCK
                       THRU GR-3000-UNLOCK-X
557660         END-IF
557660     END-IF.

           IF  WS-BUS-FCN-CREATEH
           OR  WS-BUS-FCN-SEARCHG
               MOVE ZEROS             TO HOLD-CURR-PREM-DUE
               MOVE ZEROS             TO HOLD-CURR-LOAN
               MOVE ZEROS             TO HOLD-CURR-MISC
           ELSE
               MOVE RGR-TOT-CRNT-PREM-AMT
                                      TO HOLD-CURR-PREM-DUE
               MOVE RGR-TOT-CRNT-LPAY-AMT
                                      TO HOLD-CURR-LOAN
               MOVE RGR-TOT-CRNT-SNDRY-AMT
                                      TO HOLD-CURR-MISC
557660     END-IF.

           MOVE RGR-LBILL-STAT-CD     TO HOLD-STATUS.

      *
      ***  GENERATE AN ERROR MESSAGE AND NOT ALLOW:
      ***  CREATE, MAINTAIN, DELETE, ADD, EXCEPT, PAYMENT & REVERSE,
      ***  IF THE 'GROUP' (CLIENT) IS PENDING CLIENT CONSOLIDATION.
      *
           IF  INQUIRY
           OR  HEADERS
013578     OR  RETRIEVE
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               PERFORM  5600-1000-BUILD-PARM-INFO
                   THRU 5600-1000-BUILD-PARM-INFO-X
               MOVE HOLD-GR           TO L5600-CLI-ID
               PERFORM  5600-1000-CLI-CHK
                   THRU 5600-1000-CLI-CHK-X
               IF  L5600-CNFD-ACCS-RESTRICTED
016387*        OR  L5600-CNSLDT-ACCS-RESTRICTED
               OR  L5600-CCAS-ACCS-RESTRICTED
                   GO TO 0200-PROCESS-REQUEST-X
               END-IF
           END-IF.

013578     IF  RETRIEVE
013578         PERFORM  0245-PROCESS-RETRIEVE
013578             THRU 0245-PROCESS-RETRIEVE-X
013578     END-IF.

           IF  ADDITION
               PERFORM  0250-GR-ADDITION
                   THRU 0250-GR-ADDITION-X
557660     END-IF.

           IF  CREATION
               PERFORM  0255-GR-CREATION
                   THRU 0255-GR-CREATION-X
557660     END-IF.

           IF  DELETION
               PERFORM  0260-GR-DELETION
                   THRU 0260-GR-DELETION-X
557660     END-IF.

           IF  EXCEPTION-REQ
               PERFORM  0265-GR-EXCEPTION
                   THRU 0265-GR-EXCEPTION-X
557660     END-IF.

           IF  HEADERS
               PERFORM  0270-GR-HEADER-INQUIRY
                   THRU 0270-GR-HEADER-INQUIRY-X
557660     END-IF.

           IF  INQUIRY
013578*        PERFORM  0275-PROCESS-RETREVE
013578*            THRU 0275-PROCESS-RETREVE-X
               PERFORM  0275-PROCESS-LIST
                   THRU 0275-PROCESS-LIST-X
557660     END-IF.

           IF  MAINTAIN
               PERFORM  0280-PROCESS-UPDATE
                   THRU 0280-PROCESS-UPDATE-X
557660     END-IF.

           IF  PAYMENT
               PERFORM  0285-GR-PAYMENT
                   THRU 0285-GR-PAYMENT-X
557660     END-IF.

           IF  REVERSAL
               PERFORM  0290-GR-PAYMENT-REVERSAL
                   THRU 0290-GR-PAYMENT-REVERSAL-X
557660     END-IF.

016537     PERFORM  0201-PROCESS-END
016537         THRU 0201-PROCESS-END-X.
016537
016537 0200-PROCESS-REQUEST-X.
016537     EXIT.

      *-----------------
016537*0200-PROCESS-END.
016537 0201-PROCESS-END.
      *-----------------

           IF  WS-BUS-FCN-SAVE
           AND NOT UPDATE-REQUIRED
016537*         GO TO 0200-PROCESS-REQUEST-X
016537          GO TO 0201-PROCESS-END-X
557660     END-IF.

           IF  WS-BUS-FCN-CREATEH
               MOVE '0'               TO UPDATE-SW
557660     END-IF.

           IF  UPDATE-REQUIRED
               PERFORM  0220-SET-HEADER-KEY
                   THRU 0220-SET-HEADER-KEY-X
               PERFORM  GR-1000-READ-FOR-UPDATE
                   THRU GR-1000-READ-FOR-UPDATE-X
               IF  WGR-IO-OK
                   MOVE HOLD-CURR-PREM-DUE
                                      TO RGR-TOT-CRNT-PREM-AMT
                   MOVE HOLD-CURR-LOAN          TO RGR-TOT-CRNT-LPAY-AMT
                   MOVE HOLD-CURR-MISC         TO RGR-TOT-CRNT-SNDRY-AMT
                   MOVE 'I'           TO RGR-LBILL-STAT-CD
                   MOVE RGR-LBILL-STAT-CD
                                      TO HOLD-STATUS
                   PERFORM  GR-2000-REWRITE
                       THRU GR-2000-REWRITE-X
               ELSE
                   MOVE 'CS02810007'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
016537*            GO TO 0200-PROCESS-REQUEST-X
016537             GO TO 0201-PROCESS-END-X
557660         END-IF
557660     END-IF.

           IF  HEADERS
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               PERFORM  0920-DISPLAY-MAP-HEADER
                   THRU 0920-DISPLAY-MAP-HEADER-X
557660     END-IF.


016537*0200-PROCESS-REQUEST-X.
016537 0201-PROCESS-END-X.
           EXIT.
      /

010418*---------------------------
010418 0205-EDIT-SUB-COMPANY-CODE.
010418*---------------------------
010418
010418     MOVE HOLD-SUBCO            TO WSCOM-SBSDRY-CO-ID.
010418
010418     PERFORM SCOM-1000-READ
010418        THRU SCOM-1000-READ-X.
010418
010418     IF NOT WSCOM-IO-OK
010418*MSG: INVALID SUB COMPANY CODE. RE-ENTER !
010418         MOVE 'CS02810050'      TO WGLOB-MSG-REF-INFO
010418         MOVE 0                 TO UPDATE-SW
010418         PERFORM 0260-1000-GENERATE-MESSAGE
010418            THRU 0260-1000-GENERATE-MESSAGE-X
010418         GO TO 0205-EDIT-SUB-COMPANY-CODE-X
010418     END-IF.
010418
010418 0205-EDIT-SUB-COMPANY-CODE-X.
010418     EXIT.
      /

      *--------------------
       0210-FIND-TRAN-CODE.
      *--------------------

           IF  TRAN-CODE-ID (TRAN-CODE-INXX) =  TRAN-CODE-HOLD
               MOVE TRAN-CODE-NUM (TRAN-CODE-INXX)
                                      TO TRAN-INX
               MOVE TRAN-UPDATE-CODE (TRAN-CODE-INXX)
                                      TO UPDATE-SW
               MOVE '1'               TO TRAN-CODE-FOUND-SW
557660     END-IF.

       0210-FIND-TRAN-CODE-X.
           EXIT.
      /
      *
      **----------------------- MISC ROUTINES -------------------------
      *
      *---------------------
       0215-CHECK-PAID-DATE.
      *---------------------

           MOVE HOLD-PAID-DATE-EXTERNAL
                                      TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO HOLD-PAID-DATE
           ELSE
               MOVE 'CS02810001'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       0215-CHECK-PAID-DATE-X.
           EXIT.
      /
      *
      **----------------------- MISC ROUTINES -------------------------
      *
      *--------------------
       0220-SET-HEADER-KEY.
      *--------------------

           PERFORM  GR-1000-CREATE
               THRU GR-1000-CREATE-X.

           MOVE WGR-HDR-IND           TO WGR-LBILL-REC-TYP-CD.
           MOVE HOLD-GR               TO WGR-LBILL-CLI-ID.
010418     MOVE HOLD-SUBCO            TO WGR-SBSDRY-CO-ID.
           MOVE SPACES                TO WGR-POL-ID.
005409*    MOVE HOLD-PAID-DATE    TO WGR-LBILL-EFF-DT.
005409     MOVE HOLD-PAID-DATE        TO L1680-INTERNAL-1.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
005409     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
005409     MOVE L1680-INTERNAL-2      TO WGR-LBILL-EFF-DT.

       0220-SET-HEADER-KEY-X.
           EXIT.


      *--------------------
       0230-SET-DETAIL-KEY.
      *--------------------

           PERFORM  GR-1000-CREATE
               THRU GR-1000-CREATE-X.

           MOVE WGR-DET-IND           TO WGR-LBILL-REC-TYP-CD.
           MOVE HOLD-GR               TO WGR-LBILL-CLI-ID.
010418     MOVE HOLD-SUBCO            TO WGR-SBSDRY-CO-ID.
           MOVE HOLD-POLICY           TO WGR-POL-ID.
005409*    MOVE HOLD-PAID-DATE    TO WGR-LBILL-EFF-DT.
005409     MOVE HOLD-PAID-DATE        TO L1680-INTERNAL-1.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
005409     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
005409     MOVE L1680-INTERNAL-2      TO WGR-LBILL-EFF-DT.

       0230-SET-DETAIL-KEY-X.
           EXIT.

      /
      *---------------------
013578 0245-PROCESS-RETRIEVE.
      *---------------------
      *  NOTE THESE NEXT 8 LINES ARE USED TO STORE THE TOTALS
      *  SO THAT THE HEADER RECORD DOES NOT HAVE TO BE READ AGAIN
      *
           IF  WGR-IO-OK
               MOVE 1                 TO STORE-SW
               MOVE RGR-TOT-BILL-PREM-AMT
                                      TO HOLD-BILL-PREM-DUE
               MOVE RGR-TOT-BILL-LPAY-AMT
                                      TO HOLD-BILL-LOAN
               MOVE RGR-TOT-BILL-SNDRY-AMT
                                      TO HOLD-BILL-MISC
               MOVE RGR-TOT-CRNT-PREM-AMT
                                      TO HOLD-CURR-PREM-DUE
               MOVE RGR-TOT-CRNT-LPAY-AMT
                                      TO HOLD-CURR-LOAN
               MOVE RGR-TOT-CRNT-SNDRY-AMT
                                      TO HOLD-CURR-MISC
           END-IF.

           PERFORM  0230-SET-DETAIL-KEY
               THRU 0230-SET-DETAIL-KEY-X.

014221*        PERFORM  GR-1000-READ
014221*            THRU GR-1000-READ-X

014221         PERFORM  GR-1000-READ-TWRK-TS
014221             THRU GR-1000-READ-TWRK-TS-X

           IF  NOT WGR-IO-OK
               MOVE 'CS02810025'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 0245-PROCESS-RETRIEVE-X
           END-IF.

           IF  RGR-LBILL-POL-STAT-DELETED
               MOVE 'CS02810049'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 0245-PROCESS-RETRIEVE-X
           END-IF.


020874*    COMPUTE L0290-INPUT-NUMBER
020874*            = RGR-LBILL-POL-PREM-AMT * 100
020874     MOVE RGR-LBILL-POL-PREM-AMT TO L0290-INPUT-V02
           MOVE 2                      TO L0290-PRECISION
           MOVE LENGTH OF MIR-LBILL-POL-PREM-AMT
                                  TO L0290-MAX-OUT-LEN
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X
           MOVE L0290-OUTPUT-DATA TO MIR-LBILL-POL-PREM-AMT

020874*    COMPUTE L0290-INPUT-NUMBER
020874*            = RGR-LBILL-POL-LPAY-AMT * 100
020874     MOVE RGR-LBILL-POL-LPAY-AMT TO L0290-INPUT-V02
           MOVE 2                      TO L0290-PRECISION
           MOVE LENGTH OF MIR-LBILL-POL-LPAY-AMT
                                  TO L0290-MAX-OUT-LEN
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X
           MOVE L0290-OUTPUT-DATA TO MIR-LBILL-POL-LPAY-AMT

020874*    COMPUTE L0290-INPUT-NUMBER
020874*            = RGR-POL-SNDRY-AMT * 100
020874     MOVE RGR-POL-SNDRY-AMT TO L0290-INPUT-V02
           MOVE 2                 TO L0290-PRECISION
           MOVE LENGTH OF MIR-POL-SNDRY-AMT
                                  TO L0290-MAX-OUT-LEN
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X
           MOVE L0290-OUTPUT-DATA TO MIR-POL-SNDRY-AMT

           COMPUTE TEMP-WORK-AREA = RGR-LBILL-POL-PREM-AMT -
                                   RGR-POL-PREM-SUSP-AMT
           IF  TEMP-WORK-AREA < 0
               MOVE 0                 TO TEMP-WORK-AREA
           END-IF.

020874*    COMPUTE L0290-INPUT-NUMBER = TEMP-WORK-AREA * 100.
020874     MOVE TEMP-WORK-AREA        TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-LBILL-PREM-DUE-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA  TO MIR-DV-LBILL-PREM-DUE-AMT.


013578 0245-PROCESS-RETRIEVE-X.
           EXIT.

      /
      **----------------------------**
       0250-GR-ADDITION.
      **----------------------------**

           MOVE HOLD-POLICY           TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

020478     PERFORM  2625-0000-INIT-PARM-INFO
020478         THRU 2625-0000-INIT-PARM-INFO-X.
020478     PERFORM  2625-1000-BILL-CHNG-RETRIEVE
020478         THRU 2625-1000-BILL-CHNG-RETRIEVE-X.
           IF  WPOL-IO-OK
           AND NOT RPOL-POL-BILL-TYP-LIST-BILL
020478*        IF  RPOL-POL-BILL-CHNG-DT NOT = WWKDT-ZERO-DT
020478         IF  L2625-PBRQST-EFF-DT NOT = WWKDT-ZERO-DT
020478*        AND RPOL-POL-BILL-CHNG-DT <=    HOLD-PAID-DATE
020478         AND L2625-PBRQST-EFF-DT <=       HOLD-PAID-DATE
020478*        AND RPOL-POL-NXT-BILL-LIST-BILL
020478         AND L2625-PBRQST-BILL-LIST-BILL
025173             CONTINUE
025173         ELSE
                   MOVE 'CS02810046'      TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 0250-GR-ADDITION-X
025173         END-IF
557660     END-IF.

010418     IF RPOL-SBSDRY-CO-ID NOT = HOLD-SUBCO
010418*MSG:POLICY SUB COMPANY NOT SAME AS SUB COMPANY ENTER ON SCREEN
010418         MOVE 'CS02810051'      TO WGLOB-MSG-REF-INFO
010418         PERFORM 0260-1000-GENERATE-MESSAGE
010418            THRU 0260-1000-GENERATE-MESSAGE-X
010418         GO TO 0250-GR-ADDITION-X
010418     END-IF.

           PERFORM  0230-SET-DETAIL-KEY
               THRU 0230-SET-DETAIL-KEY-X.


           PERFORM  GR-1000-READ
               THRU GR-1000-READ-X.

557660     IF  WGR-IO-OK
           AND NOT RGR-LBILL-POL-STAT-DELETED
               MOVE 'CS02810009'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 0250-GR-ADDITION-X
557660     END-IF.

           IF  NOT WGR-IO-OK
               PERFORM  GR-1000-CREATE
                   THRU GR-1000-CREATE-X
557660     END-IF.

           MOVE HOLD-POLICY           TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
               MOVE 'CS02810010'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 0250-GR-ADDITION-X
557660     END-IF.

           IF  RPOL-POL-STAT-TERMINATED
               IF  RPOL-POL-STAT-LAPSED
                   MOVE 'CS02810011'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE 'CS02810012'  TO WGLOB-MSG-REF-INFO
                   MOVE 0             TO UPDATE-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE HOLD-POLICY   TO MIR-POL-ID-BASE
                   GO TO 0250-GR-ADDITION-X
557660         END-IF
557660     END-IF.

           IF  RPOL-POL-STAT-IN-FORCE
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'CS02810013'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE HOLD-POLICY-NO    TO MIR-POL-ID-BASE
               MOVE HOLD-POLICY-SUFFIX  TO MIR-POL-ID-SFX
               GO TO 0250-GR-ADDITION-X
557660     END-IF.

           MOVE RPOL-POL-ID           TO WCVG-POL-ID.
           MOVE 01                    TO WCVG-CVG-NUM-N.

           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X.

           IF  NOT WCVG-IO-OK
               MOVE 'CS02810044'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 0250-GR-ADDITION-X
557660     END-IF.


014221*    PERFORM  GR-1000-READ-FOR-UPDATE
014221*        THRU GR-1000-READ-FOR-UPDATE-X.

014221     PERFORM  GR-2000-UPDATE-TWRK-TS
014221         THRU GR-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221         MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221         MOVE 'GR'                  TO WGLOB-MSG-PARM (01)
014221         MOVE WGR-KEY               TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         MOVE 0                 TO UPDATE-SW
014221         GO TO 0250-GR-ADDITION-X
014221     END-IF.

           MOVE RCVG-CVG-INFO         TO WCVGS-CVG-INFO (1).
           MOVE RCVG-CVG-NUM          TO WCVGS-CVG-SEQ-NUM (1).

557788*    MOVE RPOL-POL-SALE-TAX-AMT TO TEMP-TAX-AMOUNT.
557788*    MOVE RPOL-SALE-TAX-CR-AMT TO TEMP-TAX-CREDIT.

557788*    IF  TEMP-TAX-CREDIT > RPOL-POL-SALE-TAX-AMT
557788*        MOVE RPOL-POL-SALE-TAX-AMT TO TEMP-TAX-CREDIT
557788*    END-IF.

557788*    COMPUTE RGR-LBILL-POL-TAX-AMT =
557788*            TEMP-TAX-AMOUNT - TEMP-TAX-CREDIT.

557697     MOVE HOLD-PAID-DATE        TO WSFBL-COMP-EFF-DT-INT.
557697     PERFORM  SFBL-1000-CHECK-IF-SF-BILL
557697         THRU SFBL-1000-CHECK-IF-SF-BILL-X.
557697
017195     MOVE ZERO                  TO I.
           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-3100-GET-PRIM-INSRD
               THRU 2430-3100-GET-PRIM-INSRD-X.

           MOVE L2430-CLI-ID          TO RGR-INSRD-CLI-ID.
           MOVE 'A'                   TO RGR-LBILL-POL-STAT-CD.
           IF RPOL-POL-PREM-NTRADL-FLEX
               MOVE ZEROES            TO RGR-LBILL-POL-PREM-AMT
557697         MOVE RPOL-POL-PREM-SUSP-AMT
                                      TO RGR-POL-PREM-SUSP-AMT
           ELSE
557788*        COMPUTE RGR-LBILL-POL-PREM-AMT
557788*          = RPOL-POL-MPREM-AMT    - RPOL-POL-SALE-TAX-AMT
557697         IF WSFBL-SF-IS-USED
557697             MOVE L2520-SFB-NXT-BILL-AMT
557697                                TO RGR-LBILL-POL-PREM-AMT
557697             MOVE ZEROS         TO RGR-POL-PREM-SUSP-AMT
557697         ELSE
557788             MOVE RPOL-POL-MPREM-AMT
                                      TO RGR-LBILL-POL-PREM-AMT
557697             MOVE RPOL-POL-PREM-SUSP-AMT
557697                                TO RGR-POL-PREM-SUSP-AMT
557697         END-IF
557660     END-IF.
557697*    MOVE RPOL-POL-PREM-SUSP-AMT      TO RGR-POL-PREM-SUSP-AMT.
           COMPUTE TEMP-WORK-AREA = RGR-LBILL-POL-PREM-AMT -
557788*                             RGR-POL-PREM-SUSP-AMT
557788*                           + RGR-LBILL-POL-TAX-AMT.
557788                              RGR-POL-PREM-SUSP-AMT.

           IF  TEMP-WORK-AREA  <  0
               MOVE 0                 TO TEMP-WORK-AREA
557660     END-IF.

           ADD TEMP-WORK-AREA        TO HOLD-CURR-PREM-DUE.
           MOVE RPOL-POL-LOAN-REPAY-AMT
                                      TO RGR-LBILL-POL-LPAY-AMT.
           ADD RPOL-POL-LOAN-REPAY-AMT TO HOLD-CURR-LOAN.
           MOVE RPOL-POL-SNDRY-AMT    TO RGR-POL-SNDRY-AMT.
           ADD RPOL-POL-SNDRY-AMT    TO HOLD-CURR-MISC.
           MOVE 1                     TO I
557697
557697     IF  WSFBL-SF-IS-USED
557697         SET RGR-LBILL-POL-SFB    TO TRUE
557697     ELSE
557697         SET RGR-LBILL-POL-SFB-NO TO TRUE
557697     END-IF.


           IF  WGR-IO-OK
               IF  NOT RGR-LBILL-POL-STAT-DELETED
                   PERFORM  GR-2000-REWRITE
                       THRU GR-2000-REWRITE-X
014221             PERFORM  GR-1000-READ-TWRK-TS
014221                 THRU GR-1000-READ-TWRK-TS-X
               ELSE
                   PERFORM  GR-3000-UNLOCK
                       THRU GR-3000-UNLOCK-X
               END-IF
           ELSE
               PERFORM  GR-1000-WRITE
                   THRU GR-1000-WRITE-X
014221         PERFORM  GR-1000-READ-TWRK-TS
014221             THRU GR-1000-READ-TWRK-TS-X
557660     END-IF.

           PERFORM  0900-DISPLAY-GR-DETAIL
               THRU 0900-DISPLAY-GR-DETAIL-X.

           MOVE 'CS02810015'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.


       0250-GR-ADDITION-X.
           EXIT.
      /
      **----------------------------**
       0255-GR-CREATION.
      **----------------------------**

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE HOLD-GR               TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.

           IF  L2435-RETRN-CLI-NOT-FOUND
               MOVE 'CS02810043'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 0255-GR-CREATION-X
557660     END-IF.

           PERFORM  0220-SET-HEADER-KEY
               THRU 0220-SET-HEADER-KEY-X.

           MOVE 'C'                   TO RGR-LBILL-STAT-CD.
           MOVE RGR-LBILL-STAT-CD     TO HOLD-STATUS.
           MOVE ZERO                  TO HOLD-CURR-PREM-DUE.
           MOVE ZERO                  TO HOLD-CURR-LOAN.
           MOVE ZERO                  TO HOLD-CURR-MISC.
           PERFORM  GR-1000-WRITE
               THRU GR-1000-WRITE-X.
           MOVE 'CS02810040'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

014221     PERFORM  GR-1000-READ-TWRK-TS
014221         THRU GR-1000-READ-TWRK-TS-X.

       0255-GR-CREATION-X.
           EXIT.
      /
      **----------------------------**
       0260-GR-DELETION.
      **----------------------------**

014221     PERFORM  GR-2000-UPDATE-TWRK-TS
014221         THRU GR-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221         MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221         MOVE 'GR'                  TO WGLOB-MSG-PARM (01)
014221         MOVE WGR-KEY               TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         MOVE 0                 TO UPDATE-SW
014221         GO TO 0260-GR-DELETION-X
014221     END-IF.

           EVALUATE TRUE

               WHEN RGR-LBILL-STAT-BALANCED
                   MOVE 'CS02810016'  TO WGLOB-MSG-REF-INFO
                   MOVE 0             TO UPDATE-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN RGR-LBILL-STAT-DELETED
                   MOVE 'CS02810017'  TO WGLOB-MSG-REF-INFO
                   MOVE 0             TO UPDATE-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN RGR-LBILL-STAT-INACTIVE
                   MOVE 'CS02810018'  TO WGLOB-MSG-REF-INFO
                   MOVE 0             TO UPDATE-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN RGR-LBILL-STAT-PAID
                   MOVE 'CS02810019'  TO WGLOB-MSG-REF-INFO
                   MOVE 0             TO UPDATE-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN RGR-LBILL-STAT-REVERSAL
                   MOVE 'CS02810020'  TO WGLOB-MSG-REF-INFO
                   MOVE 0             TO UPDATE-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

           END-EVALUATE.

           MOVE 'D'                   TO RGR-LBILL-STAT-CD.
           MOVE RGR-LBILL-STAT-CD     TO HOLD-STATUS.

           PERFORM  GR-2000-REWRITE
               THRU GR-2000-REWRITE-X.

014221     PERFORM  GR-1000-READ-TWRK-TS
014221         THRU GR-1000-READ-TWRK-TS-X.

       0260-GR-DELETION-X.
           EXIT.
      /
      **----------------------------**
       0265-GR-EXCEPTION.
      **----------------------------**

           IF  RGR-LBILL-STAT-PAID
               MOVE 'CS02810021'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 0265-GR-EXCEPTION-X
557660     END-IF.

           PERFORM  0230-SET-DETAIL-KEY
               THRU 0230-SET-DETAIL-KEY-X.
014221*    PERFORM  GR-1000-READ-FOR-UPDATE
014221*        THRU GR-1000-READ-FOR-UPDATE-X.

014221     PERFORM  GR-2000-UPDATE-TWRK-TS
014221         THRU GR-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221         MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221         MOVE 'GR'                  TO WGLOB-MSG-PARM (01)
014221         MOVE WGR-KEY               TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         MOVE 0                 TO UPDATE-SW
014221         GO TO 0265-GR-EXCEPTION-X
014221     END-IF.

           IF  NOT WGR-IO-OK
               MOVE 'CS02810022'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 0265-GR-EXCEPTION-X
557660     END-IF.

           IF  RGR-LBILL-POL-STAT-DELETED
               MOVE 'CS02810042'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  GR-3000-UNLOCK
014221             THRU GR-3000-UNLOCK-X
               GO TO 0265-GR-EXCEPTION-X
557660     END-IF.

           PERFORM  0970-SUBTRACT-FROM-HOLD-CURR
               THRU 0970-SUBTRACT-FROM-HOLD-CURR-X.

           MOVE 'D'                   TO RGR-LBILL-POL-STAT-CD.
           MOVE 1                     TO I

           PERFORM  0900-DISPLAY-GR-DETAIL
               THRU 0900-DISPLAY-GR-DETAIL-X.

           PERFORM  GR-2000-REWRITE
               THRU GR-2000-REWRITE-X.

           MOVE 'CS02810047'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       0265-GR-EXCEPTION-X.
           EXIT.
      /
      **----------------------------**
       0270-GR-HEADER-INQUIRY.
      **----------------------------**

557756*    EVALUATE TRUE
557756*        WHEN WGLOB-USER-LANG-ENGLISH
557756*            MOVE PAID-DATE-ENG TO MIR-DTTLE1
557756*        WHEN WGLOB-USER-LANG-FRENCH
557756*            MOVE PAID-DATE-FR  TO MIR-DTTLE1
557756*        WHEN WGLOB-USER-LANG-SPANISH
557756*            MOVE PAID-DATE-SP  TO MIR-DTTLE1
557756*        WHEN OTHER
557756*            MOVE PAID-DATE-ENG TO MIR-DTTLE1
557756*    END-EVALUATE.
013578*    PERFORM 2490-1000-BUILD-PARM-INFO
013578*        THRU 2490-1000-BUILD-PARM-INFO-X.
013578*    MOVE 'CSOM0281'            TO L2490-TXT-SRC-ID.
013578*    MOVE '00001'               TO L2490-TXT-SRC-REF-ID.
013578*    PERFORM 2490-1000-RETRIEVE-TEXT
013578*        THRU 2490-1000-RETRIEVE-TEXT-X.
013578*    MOVE L2490-TXT-STR-TXT     TO MIR-DTTLE1.

           PERFORM  0220-SET-HEADER-KEY
               THRU 0220-SET-HEADER-KEY-X.

           MOVE WGR-KEY               TO WGR-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WGR-ENDBR-LBILL-CLI-ID.
           MOVE WWKDT-HIGH-DT         TO WGR-ENDBR-LBILL-EFF-DT.
           MOVE HIGH-VALUES           TO WGR-ENDBR-POL-ID.

           PERFORM  GR-1000-BROWSE
               THRU GR-1000-BROWSE-X.

           IF  WGR-IO-OK
               PERFORM  0271-GR-HEADER-INQ-LOOP
                   THRU 0271-GR-HEADER-INQ-LOOP-X
               PERFORM  GR-3000-END-BROWSE
                   THRU GR-3000-END-BROWSE-X
           ELSE
               MOVE 'CS02810024'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       0270-GR-HEADER-INQUIRY-X.
           EXIT.
      /
      *------------------------
       0271-GR-HEADER-INQ-LOOP.
      *------------------------

           PERFORM  0272-GR-HEADER-INQ-LOOP2
                THRU 0272-GR-HEADER-INQ-LOOP2-X
                VARYING I FROM 1 BY 1
                UNTIL I > PAGE-LIMIT
                OR NOT WGR-IO-OK.

           IF WGLOB-MORE-DATA-EXISTS
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'CS02810037'      TO WGLOB-MSG-REF-INFO
               MOVE WGLOB-PROCESS-DATE            TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-LBILL-EFF-DT
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  9700-ZERO-MAINTAIN-FIELDS
               THRU 9700-ZERO-MAINTAIN-FIELDS-X.

           PERFORM  9710-ZERO-TOTAL-FIELDS
               THRU 9710-ZERO-TOTAL-FIELDS-X.

010418     MOVE HOLD-SUBCO            TO MIR-SBSDRY-CO-ID.
           MOVE HOLD-DATE-1           TO MIR-LBILL-EFF-DT.
           MOVE HOLD-NAME-1           TO MIR-LBILL-CLI-ID.



       0271-GR-HEADER-INQ-LOOP-X.
           EXIT.
      /
      *-------------------------
       0272-GR-HEADER-INQ-LOOP2.
      *-------------------------

           PERFORM  GR-2000-READ-NEXT
               THRU GR-2000-READ-NEXT-X.

           IF  WGR-IO-OK
           AND RGR-LBILL-REC-TYP-CD    =  WGR-HDR-IND
               PERFORM  0910-DISPLAY-GR-HEADER
                   THRU 0910-DISPLAY-GR-HEADER-X
               MOVE RGR-LBILL-CLI-ID  TO HOLD-GR
               MOVE RGR-LBILL-EFF-DT  TO HOLD-PAID-DATE
               MOVE RGR-POL-ID        TO HOLD-POLICY
               MOVE RGR-LBILL-STAT-CD TO HOLD-STATUS
               IF  I = PAGE-LIMIT
                   PERFORM  0273-GET-NEXT-KEY
                       THRU 0273-GET-NEXT-KEY-X
               END-IF
           END-IF.

       0272-GR-HEADER-INQ-LOOP2-X.
           EXIT.
      /
      **----------------------------**
       0273-GET-NEXT-KEY.
      **----------------------------**
           PERFORM  GR-2000-READ-NEXT
               THRU GR-2000-READ-NEXT-X.
           IF  WGR-IO-OK
           AND RGR-LBILL-REC-TYP-CD = WGR-HDR-IND
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               MOVE RGR-LBILL-CLI-ID  TO HOLD-NAME-1
               MOVE RGR-LBILL-EFF-DT  TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO HOLD-DATE-1
557660     END-IF.
       0273-GET-NEXT-KEY-X.
           EXIT.
      /
      **----------------------------**
013578 0275-PROCESS-LIST.
      **----------------------------**
      *  NOTE THESE NEXT 8 LINES ARE USED TO STORE THE TOTALS
      *  SO THAT THE HEADER RECORD DOES NOT HAVE TO BE READ AGAIN
      *
           IF  WGR-IO-OK
               MOVE 1                 TO STORE-SW
               MOVE RGR-TOT-BILL-PREM-AMT
                                      TO HOLD-BILL-PREM-DUE
               MOVE RGR-TOT-BILL-LPAY-AMT
                                      TO HOLD-BILL-LOAN
               MOVE RGR-TOT-BILL-SNDRY-AMT
                                      TO HOLD-BILL-MISC
               MOVE RGR-TOT-CRNT-PREM-AMT
                                      TO HOLD-CURR-PREM-DUE
               MOVE RGR-TOT-CRNT-LPAY-AMT
                                      TO HOLD-CURR-LOAN
               MOVE RGR-TOT-CRNT-SNDRY-AMT
                                      TO HOLD-CURR-MISC
557660     END-IF.

           PERFORM  0230-SET-DETAIL-KEY
               THRU 0230-SET-DETAIL-KEY-X.

           MOVE WGR-KEY               TO WGR-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WGR-ENDBR-POL-ID.

           PERFORM  GR-1000-BROWSE
               THRU GR-1000-BROWSE-X.

           IF  WGR-IO-OK
               PERFORM  0276-GR-INQUIRY-LOOP
                   THRU 0276-GR-INQUIRY-LOOP-X
               PERFORM  GR-3000-END-BROWSE
                   THRU GR-3000-END-BROWSE-X
           ELSE
               MOVE 'CS02810023'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.



013578 0275-PROCESS-LIST-X.
           EXIT.


      *---------------------
       0276-GR-INQUIRY-LOOP.
      *---------------------

           PERFORM  GR-2000-READ-NEXT
               THRU GR-2000-READ-NEXT-X.

           IF  WGR-IO-OK
               MOVE ZERO              TO I
               PERFORM  0277-GR-INQUIRY-LOOP-CONT
                   THRU 0277-GR-INQUIRY-LOOP-CONT-X
                   UNTIL I = PAGE-LIMIT
                   OR NOT WGR-IO-OK
557660     END-IF.

           ADD 1                  TO I.


           IF WGLOB-MORE-DATA-EXISTS
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               MOVE RGR-POL-ID        TO HOLD-POL-ID-1
               MOVE HOLD-POLICY-1     TO HOLD-POLICY
               MOVE HOLD-SUFFIX-1     TO HOLD-POLICY-SUFFIX
           ELSE
               MOVE 'CS00000023'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-ID-BASE-T   (1)  TO HOLD-POLICY
               MOVE MIR-POL-ID-SFX-T   (1)   TO HOLD-POLICY-SUFFIX
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

      *  NOTE THESE NEXT 7 LINES ARE USED TO PUT THE TOTALS BACK
      *  INTO PLACE SO THAT 'DISPLAY-HEADER-MAP' USES THE RIGHT VALUES

           IF  STORE-SW = 1
               MOVE HOLD-BILL-PREM-DUE          TO RGR-TOT-BILL-PREM-AMT
               MOVE HOLD-BILL-LOAN    TO RGR-TOT-BILL-LPAY-AMT
               MOVE HOLD-BILL-MISC    TO RGR-TOT-BILL-SNDRY-AMT
               MOVE HOLD-CURR-PREM-DUE          TO RGR-TOT-CRNT-PREM-AMT
               MOVE HOLD-CURR-LOAN    TO RGR-TOT-CRNT-LPAY-AMT
               MOVE HOLD-CURR-MISC    TO RGR-TOT-CRNT-SNDRY-AMT
557660     END-IF.


       0276-GR-INQUIRY-LOOP-X.
           EXIT.


      *--------------------------
       0277-GR-INQUIRY-LOOP-CONT.
      *--------------------------

           IF  WGR-IO-OK
               ADD 1                     TO I
               MOVE RGR-LBILL-CLI-ID  TO HOLD-GR
               MOVE RGR-LBILL-EFF-DT  TO HOLD-PAID-DATE
               MOVE RGR-POL-ID        TO HOLD-POLICY
               PERFORM  0900-DISPLAY-GR-DETAIL
                   THRU 0900-DISPLAY-GR-DETAIL-X
557660     END-IF.

           PERFORM  GR-2000-READ-NEXT
               THRU GR-2000-READ-NEXT-X.

           IF I = PAGE-LIMIT
           AND WGR-IO-OK
               SET  WGLOB-MORE-DATA-EXISTS TO TRUE
           END-IF.

       0277-GR-INQUIRY-LOOP-CONT-X.
           EXIT.
      /
      **----------------------------**
       0280-PROCESS-UPDATE.
      **----------------------------**

           PERFORM  0230-SET-DETAIL-KEY
               THRU 0230-SET-DETAIL-KEY-X.

016537*        PERFORM  GR-1000-READ
016537*            THRU GR-1000-READ-X

016537     PERFORM  GR-1000-READ
016537         THRU GR-1000-READ-X.

           IF  NOT WGR-IO-OK
               MOVE 'CS02810025'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 0280-PROCESS-UPDATE-X
557660     END-IF.

           IF  RGR-LBILL-POL-STAT-DELETED
               MOVE 'CS02810049'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 0280-PROCESS-UPDATE-X
557660     END-IF.

008455*        MOVE RGR-LBILL-POL-PREM-AMT  TO WORK-NUM
008455*        MOVE WORK-NUM                TO MIR-LBILL-POL-PREM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER
020874*           = RGR-LBILL-POL-PREM-AMT * 100.
020874         MOVE RGR-LBILL-POL-PREM-AMT       TO L0290-INPUT-V02.
008455         MOVE 2                 TO L0290-PRECISION.
008455         MOVE LENGTH OF MIR-LBILL-POL-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-LBILL-POL-PREM-AMT.
008455
008455*        MOVE RGR-LBILL-POL-LPAY-AMT  TO WORK-NUM
008455*        MOVE WORK-NUM                TO MIR-LBILL-POL-LPAY-AMT
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = RGR-LBILL-POL-LPAY-AMT * 100.
020874     MOVE RGR-LBILL-POL-LPAY-AMT      TO L0290-INPUT-V02.
008455     MOVE 2                            TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LBILL-POL-LPAY-AMT
                                  TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA TO MIR-LBILL-POL-LPAY-AMT.
008455
008455*        MOVE RGR-POL-SNDRY-AMT       TO WORK-NUM
008455*        MOVE WORK-NUM                TO MIR-POL-SNDRY-AMT
020874*    COMPUTE L0290-INPUT-NUMBER
020874*          = RGR-POL-SNDRY-AMT * 100.
020874     MOVE RGR-POL-SNDRY-AMT         TO L0290-INPUT-V02.
008455     MOVE 2                         TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-SNDRY-AMT
                                  TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-SNDRY-AMT.

014221*        PERFORM  GR-1000-READ-FOR-UPDATE
014221*            THRU GR-1000-READ-FOR-UPDATE-X

014221     PERFORM  GR-2000-UPDATE-TWRK-TS
014221         THRU GR-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221         MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221         MOVE 'GR'                  TO WGLOB-MSG-PARM (01)
014221         MOVE WGR-KEY               TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         MOVE 0                     TO UPDATE-SW
014221         GO TO 0280-PROCESS-UPDATE-X
014221     END-IF.

           MOVE RGR-POL-ID            TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
               MOVE 'CS02810026'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 0280-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  0950-VALIDATE-VALUES
               THRU 0950-VALIDATE-VALUES-X.

           IF  WGLOB-MSG-ERROR-SW = 1
               MOVE 1                 TO I
               PERFORM  0900-DISPLAY-GR-DETAIL
                   THRU 0900-DISPLAY-GR-DETAIL-X
014221         PERFORM  GR-3000-UNLOCK
014221             THRU GR-3000-UNLOCK-X
               GO TO 0280-PROCESS-UPDATE-X
557660     END-IF.
      *
      *    THE OLD AMOUNTS HAVE TO BE TAKEN OUT OF THE CURRENT
      *    TOTALS AND THEN THE NEW ONES THAT HAVE BEEN ENTERED
      *    ON THE SCREEN WILL BE ADDED IN
      *
           IF  NOT RGR-LBILL-POL-STAT-DELETED
               PERFORM  0970-SUBTRACT-FROM-HOLD-CURR
                   THRU 0970-SUBTRACT-FROM-HOLD-CURR-X
557660     END-IF.

008455*    COMPUTE RGR-LBILL-POL-PREM-AMT = HOLD-MPREM-1-N +
008455*         HOLD-MPREM-2-N.
008455     MOVE HOLD-MPREM            TO RGR-LBILL-POL-PREM-AMT.
      *
      *  NOTE THAT WE TAKE THE PREMIUM SUSPENSE FROM THE POLICY
557697*       FOR NON SPECIAL FREQUENCY POLICIES
      *
557697*    MOVE RPOL-POL-PREM-SUSP-AMT      TO RGR-POL-PREM-SUSP-AMT.
557697     IF  RGR-LBILL-POL-SFB
557697         MOVE ZEROS             TO RGR-POL-PREM-SUSP-AMT
557697     ELSE
557697         MOVE RPOL-POL-PREM-SUSP-AMT
                                      TO RGR-POL-PREM-SUSP-AMT
557697     END-IF.
557697
008455*    COMPUTE RGR-LBILL-POL-LPAY-AMT   =  HOLD-MLOAN-1-N +
008455*         HOLD-MLOAN-2-N.
008455     MOVE HOLD-MLOAN            TO RGR-LBILL-POL-LPAY-AMT.
008455
008455*    COMPUTE RGR-POL-SNDRY-AMT        =  HOLD-MMISC-1-N +
008455*         HOLD-MMISC-2-N.
008455     MOVE HOLD-MMISC            TO RGR-POL-SNDRY-AMT.

           IF  NOT RGR-LBILL-POL-STAT-DELETED
               PERFORM  0960-ADD-TO-HOLD-CURR
                   THRU 0960-ADD-TO-HOLD-CURR-X
557660     END-IF.

           MOVE 1                     TO I.
           MOVE 'C'                   TO RGR-LBILL-POL-STAT-CD.
           PERFORM  0900-DISPLAY-GR-DETAIL
               THRU 0900-DISPLAY-GR-DETAIL-X.

           PERFORM  GR-2000-REWRITE
               THRU GR-2000-REWRITE-X.

014221     PERFORM  GR-1000-READ-TWRK-TS
014221         THRU GR-1000-READ-TWRK-TS-X.

           PERFORM  9700-ZERO-MAINTAIN-FIELDS
               THRU 9700-ZERO-MAINTAIN-FIELDS-X.

       0280-PROCESS-UPDATE-X.
           EXIT.
      /
      **----------------------------**
       0285-GR-PAYMENT.
      **----------------------------**

           EVALUATE TRUE

               WHEN RGR-LBILL-STAT-BALANCED
                   MOVE 'CS02810027'  TO WGLOB-MSG-REF-INFO
                   MOVE 0             TO UPDATE-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN RGR-LBILL-STAT-DELETED
                   MOVE 'CS02810028'  TO WGLOB-MSG-REF-INFO
                   MOVE 0             TO UPDATE-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN RGR-LBILL-STAT-INACTIVE
                   MOVE 'CS02810029'  TO WGLOB-MSG-REF-INFO
                   MOVE 0             TO UPDATE-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN RGR-LBILL-STAT-PAID
                   MOVE 'CS02810030'  TO WGLOB-MSG-REF-INFO
                   MOVE 0             TO UPDATE-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN RGR-LBILL-STAT-REVERSAL
                   MOVE 'CS02810031'  TO WGLOB-MSG-REF-INFO
                   MOVE 0             TO UPDATE-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

           END-EVALUATE.

           MOVE 'B'                   TO RGR-LBILL-STAT-CD.
           MOVE RGR-LBILL-STAT-CD     TO HOLD-STATUS.

           PERFORM  GR-2000-REWRITE
               THRU GR-2000-REWRITE-X.

       0285-GR-PAYMENT-X.
           EXIT.
      /
      *-------------------------
       0290-GR-PAYMENT-REVERSAL.
      *-------------------------

           IF  RGR-TOT-BILL-SNDRY-AMT > 0
               MOVE 'CS02810048'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  GR-3000-UNLOCK
014221             THRU GR-3000-UNLOCK-X
               GO TO 0290-GR-PAYMENT-REVERSAL-X
557660     END-IF.

           EVALUATE TRUE

               WHEN RGR-LBILL-STAT-BALANCED
                   MOVE 'CS02810032'  TO WGLOB-MSG-REF-INFO
                   MOVE 0             TO UPDATE-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN RGR-LBILL-STAT-DELETED
                   MOVE 'CS02810033'  TO WGLOB-MSG-REF-INFO
                   MOVE 0             TO UPDATE-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN RGR-LBILL-STAT-INACTIVE
                   MOVE 'CS02810034'  TO WGLOB-MSG-REF-INFO
                   MOVE 0             TO UPDATE-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN RGR-LBILL-STAT-PAID
                   MOVE 'CS02810035'  TO WGLOB-MSG-REF-INFO
                   MOVE 0             TO UPDATE-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

               WHEN RGR-LBILL-STAT-REVERSAL
                   MOVE 'CS02810036'  TO WGLOB-MSG-REF-INFO
                   MOVE 0             TO UPDATE-SW
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X

           END-EVALUATE.

           MOVE 'R'                   TO RGR-LBILL-STAT-CD.
           MOVE RGR-LBILL-STAT-CD     TO HOLD-STATUS.

           PERFORM  GR-2000-REWRITE
               THRU GR-2000-REWRITE-X.

       0290-GR-PAYMENT-REVERSAL-X.
           EXIT.
      /
016108*-----------------------
016108 0300-VAL-POL-DT-OF-DTH.
016108*-----------------------
016108
016108     MOVE HOLD-POLICY           TO WPOL-POL-ID.
016108
016108     PERFORM  POL-1000-READ
016108         THRU POL-1000-READ-X.
016108
016108     IF  NOT WPOL-IO-OK
016108*MSG     POLICY NOT FOUND
016108         MOVE 'CS02810010'      TO WGLOB-MSG-REF-INFO
016108         PERFORM  0260-1000-GENERATE-MESSAGE
016108             THRU 0260-1000-GENERATE-MESSAGE-X
016108         GO TO 0300-VAL-POL-DT-OF-DTH-X
016108     END-IF.
016108
016108     PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
016108         THRU CVGS-1000-LOAD-CVGS-ARRAY-X.
016108
016108     IF  WGLOB-MSG-ERROR-SW > ZERO
016108         GO TO 0300-VAL-POL-DT-OF-DTH-X
016108     END-IF.
016108
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     MOVE WGLOB-PROCESS-DATE    TO L0985-EFF-DT.
016108
016108     PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108         THRU 0985-1000-VAL-POL-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108         MOVE 1                 TO WGLOB-MSG-ERROR-SW
016108     END-IF.
016108
016108 0300-VAL-POL-DT-OF-DTH-X.
016108     EXIT.
016108/
016108*-----------------------
016108 0310-VAL-CLI-DT-OF-DTH.
016108*-----------------------
016108
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     MOVE MIR-LBILL-CLI-ID      TO L0985-CLI-ID.
016108     MOVE WGLOB-PROCESS-DATE    TO L0985-EFF-DT.
016108
016108     PERFORM  0985-3000-VAL-CLI-DT-OF-DTH
016108         THRU 0985-3000-VAL-CLI-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108         MOVE 1                 TO WGLOB-MSG-ERROR-SW
016108     END-IF.
016108
016108 0310-VAL-CLI-DT-OF-DTH-X.
016108     EXIT.
016108/
      *---------------   MISC  PARAGRAPHS   ----------------*
      *-----------------------
       0900-DISPLAY-GR-DETAIL.
      *-----------------------

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE RGR-INSRD-CLI-ID      TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.

           IF  L2435-RETRN-OK
557668*        MOVE L2435-CLI-NM-COMPRESSED
557668*                               TO MIR-DV-LBILL-CLI-NM-T (I)
557668         PERFORM  0980-FORMAT-SCREEN-NAME
557668             THRU 0980-FORMAT-SCREEN-NAME-X
557668         MOVE L0620-SCREEN-NAME TO MIR-DV-OWN-CLI-NM-T (I)
           ELSE
               MOVE 'CS02810039'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           MOVE RGR-LBILL-POL-STAT-CD TO MIR-LBILL-POL-STAT-CD-T (I).
           MOVE HOLD-POLICY-NO        TO MIR-POL-ID-BASE-T (I).
           MOVE HOLD-POLICY-SUFFIX    TO MIR-POL-ID-SFX-T (I).

           IF  MAINTAIN
               MOVE RGR-LBILL-POL-PREM-AMT
                                      TO TEMP-WORK-AREA
           ELSE
               COMPUTE TEMP-WORK-AREA = RGR-LBILL-POL-PREM-AMT -
557788*          RGR-POL-PREM-SUSP-AMT + RGR-LBILL-POL-TAX-AMT
557788           RGR-POL-PREM-SUSP-AMT
557660     END-IF.

           IF  TEMP-WORK-AREA < 0
               MOVE 0                 TO TEMP-WORK-AREA
557660     END-IF.

008455*    MOVE TEMP-WORK-AREA        TO NUMBER-EDIT.
008455*    MOVE NUMBER-EDIT           TO MIR-LBILL-POL-PREM-AMT-T (I).
020874*    COMPUTE L0290-INPUT-NUMBER = TEMP-WORK-AREA * 100.
020874     MOVE TEMP-WORK-AREA            TO L0290-INPUT-V02.
008455     MOVE 2                         TO L0290-PRECISION.
013578*008455     MOVE LENGTH OF MIR-LBILL-POL-PREM-AMT-T (I)
013578*                                 TO L0290-MAX-OUT-LEN.
013578     MOVE LENGTH OF MIR-DV-LBILL-PREM-DUE-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
013578*008455 MOVE L0290-OUTPUT-DATA  TO MIR-LBILL-POL-PREM-AMT-T (I).
013578     MOVE L0290-OUTPUT-DATA  TO MIR-DV-LBILL-PREM-DUE-AMT-T (I).
008455
008455*    MOVE RGR-LBILL-POL-LPAY-AMT TO NUMBER-EDIT.
008455*    MOVE NUMBER-EDIT           TO MIR-LBILL-POL-LPAY-AMT-T (I).
020874*    COMPUTE L0290-INPUT-NUMBER = RGR-LBILL-POL-LPAY-AMT * 100.
020874     MOVE RGR-LBILL-POL-LPAY-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                         TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LBILL-POL-LPAY-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-LBILL-POL-LPAY-AMT-T (I).
008455
008455*    MOVE RGR-POL-SNDRY-AMT     TO NUMBER-EDIT.
008455*    MOVE NUMBER-EDIT           TO MIR-POL-SNDRY-AMT-T (I).
020874*    COMPUTE L0290-INPUT-NUMBER = RGR-POL-SNDRY-AMT * 100.
020874     MOVE RGR-POL-SNDRY-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-SNDRY-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-SNDRY-AMT-T (I).

557697     IF  RGR-LBILL-POL-SFB
557697         MOVE RGR-LBILL-POL-SFB-IND
557697                                TO MIR-LBILL-POL-SFB-IND-T (I)
557697     ELSE
557697         MOVE SPACES            TO MIR-LBILL-POL-SFB-IND-T (I)
557697     END-IF.

       0900-DISPLAY-GR-DETAIL-X.
           EXIT.


      *-----------------------
       0910-DISPLAY-GR-HEADER.
      *-----------------------

013578*    MOVE MIR-DV-OWN-CLI-NM-T (I)   TO WS-NAME.
013578*    MOVE RGR-LBILL-CLI-ID      TO GROUP-NO.
           MOVE RGR-LBILL-CLI-ID      TO MIR-LBILL-CLI-ID-T (I).
           MOVE RGR-LBILL-EFF-DT      TO L1640-INTERNAL-DATE.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE   TO MIR-LBILL-EFF-DT-T (I).
013578*    MOVE L1640-EXTERNAL-DATE   TO PAID-DATE.
013578*    MOVE WS-NAME               TO MIR-DV-OWN-CLI-NM-T (I).

013578*53-062     IF I = 1
013578*53-062         MOVE PAID-DATE         TO HOLD-DATE-1
013578*53-062         MOVE WS-NAME           TO HOLD-NAME-1
013578*557660     END-IF.

       0910-DISPLAY-GR-HEADER-X.
           EXIT.
      /
      *------------------------
       0920-DISPLAY-MAP-HEADER.
      *------------------------

           MOVE HOLD-GR               TO MIR-LBILL-CLI-ID.
010418     MOVE HOLD-SUBCO            TO MIR-SBSDRY-CO-ID.
           MOVE HOLD-PAID-DATE        TO L1640-INTERNAL-DATE.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE   TO MIR-LBILL-EFF-DT.
           MOVE HOLD-POLICY-NO        TO MIR-POL-ID-BASE.
           MOVE HOLD-POLICY-SUFFIX    TO MIR-POL-ID-SFX.
           MOVE HOLD-STATUS           TO MIR-LBILL-STAT-CD.

           PERFORM  0930-GET-GROUP-NAME
               THRU 0930-GET-GROUP-NAME-X.
      *
      *****************************************************
      *
      *    NOTE:  THE PREMIUM BILLED FOR THIS SYSTEM
      *           IS THE MODE PREMIUM LESS THE PREMIUM
      *           SUSPENSE SUCH THAT THE AMOUNT IS NOT LESS
      *           THAN ZERO
      *           THIS IS BECAUSE LATER ON DOWN THE LINE (IE 401)
      *           PREMIUM SUSPENSE IS USED TO PAY THE AS MUCH
      *           OF THE MODE PREMIUM AS POSSIBLE.
      *           TOTAL BILLED IS THE TOTAL OF THE AMOUNT OF
      *           THE MODE PREMIUM THAT IS STILL PAYABLE PLUS
      *           THE LOAN PAYMENT AMOUNT PLUS THE MISC PAYMENT
      *           AMOUNT.
      *****************************************************
      *
      *    SET UP BILLED TOTALS (THESE ARE AMOUNTS FROM 207)
      *
008455*    MOVE RGR-TOT-BILL-PREM-AMT  TO NUMBER-EDIT.
008455*    MOVE NUMBER-EDIT            TO MIR-TOT-BILL-PREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RGR-TOT-BILL-PREM-AMT * 100.
020874     MOVE RGR-TOT-BILL-PREM-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TOT-BILL-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-TOT-BILL-PREM-AMT.

008455*    MOVE RGR-TOT-BILL-LPAY-AMT  TO NUMBER-EDIT.
008455*    MOVE NUMBER-EDIT            TO MIR-TOT-BILL-LPAY-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RGR-TOT-BILL-LPAY-AMT * 100.
020874     MOVE RGR-TOT-BILL-LPAY-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TOT-BILL-LPAY-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-TOT-BILL-LPAY-AMT.

008455*    MOVE RGR-TOT-BILL-SNDRY-AMT TO NUMBER-EDIT.
008455*    MOVE NUMBER-EDIT            TO MIR-TOT-BILL-SNDRY-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RGR-TOT-BILL-SNDRY-AMT * 100.
020874     MOVE RGR-TOT-BILL-SNDRY-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TOT-BILL-SNDRY-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-TOT-BILL-SNDRY-AMT.

           COMPUTE TEMP-WORK-AREA-TOTAL =
                RGR-TOT-BILL-PREM-AMT   +
                RGR-TOT-BILL-LPAY-AMT   +
                RGR-TOT-BILL-SNDRY-AMT.
008455*    MOVE TEMP-WORK-AREA-TOTAL   TO NUMBER-EDIT.
008455*    MOVE NUMBER-EDIT            TO MIR-DV-TOT-BILL-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = TEMP-WORK-AREA-TOTAL * 100.
020874     MOVE TEMP-WORK-AREA-TOTAL  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-TOT-BILL-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-TOT-BILL-AMT.
      *
      *    SET UP CURRENT TOTALS
      *
008455*    MOVE RGR-TOT-CRNT-PREM-AMT  TO NUMBER-EDIT.
008455*    MOVE NUMBER-EDIT            TO MIR-TOT-CRNT-PREM-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RGR-TOT-CRNT-PREM-AMT * 100.
020874     MOVE RGR-TOT-CRNT-PREM-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TOT-CRNT-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-TOT-CRNT-PREM-AMT.
008455*    MOVE RGR-TOT-CRNT-LPAY-AMT  TO NUMBER-EDIT.
008455*    MOVE NUMBER-EDIT            TO MIR-TOT-CRNT-LPAY-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RGR-TOT-CRNT-LPAY-AMT * 100.
020874     MOVE RGR-TOT-CRNT-LPAY-AMT     TO L0290-INPUT-V02.
008455     MOVE 2                         TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TOT-CRNT-LPAY-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-TOT-CRNT-LPAY-AMT.
008455*    MOVE RGR-TOT-CRNT-SNDRY-AMT TO NUMBER-EDIT.
008455*    MOVE NUMBER-EDIT            TO MIR-TOT-CRNT-SNDRY-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RGR-TOT-CRNT-SNDRY-AMT * 100.
020874     MOVE RGR-TOT-CRNT-SNDRY-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TOT-CRNT-SNDRY-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-TOT-CRNT-SNDRY-AMT.

           COMPUTE TEMP-WORK-AREA-TOTAL =
                RGR-TOT-CRNT-PREM-AMT   +
                RGR-TOT-CRNT-LPAY-AMT   +
                RGR-TOT-CRNT-SNDRY-AMT.
008455*    MOVE TEMP-WORK-AREA-TOTAL   TO NUMBER-EDIT.
008455*    MOVE NUMBER-EDIT            TO MIR-DV-TOT-CRNT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = TEMP-WORK-AREA-TOTAL * 100.
020874     MOVE TEMP-WORK-AREA-TOTAL  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-TOT-CRNT-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-TOT-CRNT-AMT.

       0920-DISPLAY-MAP-HEADER-X.
           EXIT.


      *--------------------
       0930-GET-GROUP-NAME.
      *--------------------

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE HOLD-GR               TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.

           IF  L2435-RETRN-OK
557668*        MOVE L2435-CLI-NM-COMPRESSED  TO MIR-LBILL-CLI-IDNAM
557668         PERFORM  0980-FORMAT-SCREEN-NAME
557668             THRU 0980-FORMAT-SCREEN-NAME-X
013578*        MOVE L0620-SCREEN-NAME TO MIR-GRPNAM
013578         MOVE L0620-SCREEN-NAME TO MIR-DV-LBILL-CLI-NM
           ELSE
               MOVE 'CS02810008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       0930-GET-GROUP-NAME-X.
           EXIT.


      *-----------------------------
       0940-DISPLAY-MAINTAIN-VALUES.
      *-----------------------------

008455*    MOVE HOLD-MPREM        TO MIR-LBILL-POL-PREM-AMT.
008455*    MOVE HOLD-MLOAN        TO MIR-LBILL-POL-LPAY-AMT.
008455*    MOVE HOLD-MMISC        TO MIR-POL-SNDRY-AMT.
008455     MOVE HOLD-MPREM-X          TO MIR-LBILL-POL-PREM-AMT.
008455     MOVE HOLD-MLOAN-X          TO MIR-LBILL-POL-LPAY-AMT.
008455     MOVE HOLD-MMISC-X          TO MIR-POL-SNDRY-AMT.

       0940-DISPLAY-MAINTAIN-VALUES-X.
           EXIT.


      *---------------------
       0950-VALIDATE-VALUES.
      *---------------------

           MOVE  ZEROS                TO TEMP-WORK-AREA.
557660     MOVE MIR-LBILL-CLI-ID      TO HOLD-NAME-1.
557660     MOVE MIR-LBILL-EFF-DT      TO HOLD-DATE-1.
008455
008455     MOVE HOLD-MPREM-X          TO L0280-INPUT-DATA.
008455     MOVE 'N'                   TO L0280-SIGN-IND.
008455     MOVE 2                     TO L0280-PRECISION.
008455     MOVE LENGTH OF MIR-LBILL-POL-PREM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
008455     PERFORM 0280-1000-NUMERIC-EDIT
008455        THRU 0280-1000-NUMERIC-EDIT-X.
008455*    IF  (HOLD-MPREM-1-X NUMERIC)
008455*    AND (HOLD-MPREM-PT = '.')
008455*    AND (HOLD-MPREM-2-X NUMERIC)
008455*        COMPUTE TEMP-WORK-AREA = HOLD-MPREM-1-N + HOLD-MPREM-2-N
008455     IF  L0280-OK
008455         COMPUTE TEMP-WORK-AREA = L0280-OUTPUT-DOLLAR
           ELSE
               PERFORM  0940-DISPLAY-MAINTAIN-VALUES
                   THRU 0940-DISPLAY-MAINTAIN-VALUES-X
               MOVE 'CS02810004'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-MSG-ERROR-SW
           END-IF.

008455     MOVE HOLD-MLOAN-X          TO L0280-INPUT-DATA.
008455     MOVE 'N'                   TO L0280-SIGN-IND.
008455     MOVE 2                     TO L0280-PRECISION.
008455     MOVE LENGTH OF MIR-LBILL-POL-LPAY-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
008455     PERFORM 0280-1000-NUMERIC-EDIT
008455        THRU 0280-1000-NUMERIC-EDIT-X.
008455*    IF  (HOLD-MLOAN-1-X NUMERIC)
008455*    AND (HOLD-MLOAN-PT = '.')
008455*    AND (HOLD-MLOAN-2-X NUMERIC)
008455*        COMPUTE TEMP-WORK-AREA = TEMP-WORK-AREA +
008455*                 HOLD-MLOAN-1-N + HOLD-MLOAN-2-N
008455     IF  L0280-OK
008455         COMPUTE TEMP-WORK-AREA = TEMP-WORK-AREA +
008455                                  L0280-OUTPUT-DOLLAR
           ELSE
               PERFORM  0940-DISPLAY-MAINTAIN-VALUES
                   THRU 0940-DISPLAY-MAINTAIN-VALUES-X
               MOVE 'CS02810005'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-MSG-ERROR-SW
           END-IF.

008455     MOVE HOLD-MMISC-X          TO L0280-INPUT-DATA.
008455     MOVE 'N'                   TO L0280-SIGN-IND.
008455     MOVE 2                     TO L0280-PRECISION.
008455     MOVE LENGTH OF MIR-POL-SNDRY-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
008455     PERFORM 0280-1000-NUMERIC-EDIT
008455        THRU 0280-1000-NUMERIC-EDIT-X.
008455*    IF  (HOLD-MMISC-1-X NUMERIC)
008455*    AND (HOLD-MMISC-PT = '.')
008455*    AND (HOLD-MMISC-2-X NUMERIC)
008455*        COMPUTE TEMP-WORK-AREA = TEMP-WORK-AREA +
008455*                HOLD-MMISC-1-N + HOLD-MMISC-2-N
008455     IF  L0280-OK
008455         COMPUTE TEMP-WORK-AREA = TEMP-WORK-AREA +
008455                                  L0280-OUTPUT-DOLLAR
           ELSE
               PERFORM  0940-DISPLAY-MAINTAIN-VALUES
                   THRU 0940-DISPLAY-MAINTAIN-VALUES-X
               MOVE 'CS02810006'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-MSG-ERROR-SW
           END-IF.

      *
      * NOTE: WE NEED THIS TEST TO MAKE SURE THAT THE USER HAS
      *       ENTERED AT LEAST ONE OF THE MAINTAIN FIELDS DURING
      *       A MAINTAIN FUNCTION.
      *
           IF  TEMP-WORK-AREA NOT > 0
               MOVE 'CS02810038'      TO WGLOB-MSG-REF-INFO
               MOVE 0                 TO UPDATE-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-MSG-ERROR-SW
               GO TO 0950-VALIDATE-VALUES-X
557660     END-IF.

       0950-VALIDATE-VALUES-X.
           EXIT.


      *----------------------
       0960-ADD-TO-HOLD-CURR.
      *----------------------

           COMPUTE TEMP-WORK-AREA = RGR-LBILL-POL-PREM-AMT -
557788*          RGR-POL-PREM-SUSP-AMT + RGR-LBILL-POL-TAX-AMT.
557788           RGR-POL-PREM-SUSP-AMT.

           IF  TEMP-WORK-AREA < 0
               MOVE 0                 TO TEMP-WORK-AREA
557660     END-IF.

           COMPUTE HOLD-CURR-PREM-DUE = HOLD-CURR-PREM-DUE +
               TEMP-WORK-AREA.
           COMPUTE HOLD-CURR-LOAN = HOLD-CURR-LOAN +
               RGR-LBILL-POL-LPAY-AMT.
           COMPUTE HOLD-CURR-MISC = HOLD-CURR-MISC +
               RGR-POL-SNDRY-AMT.

       0960-ADD-TO-HOLD-CURR-X.
           EXIT.


      *-----------------------------
       0970-SUBTRACT-FROM-HOLD-CURR.
      *-----------------------------

           COMPUTE TEMP-WORK-AREA = RGR-LBILL-POL-PREM-AMT -
557788*          RGR-POL-PREM-SUSP-AMT + RGR-LBILL-POL-TAX-AMT.
557788           RGR-POL-PREM-SUSP-AMT.

           IF TEMP-WORK-AREA < 0
               MOVE 0                 TO TEMP-WORK-AREA
557660     END-IF.

           COMPUTE HOLD-CURR-PREM-DUE = HOLD-CURR-PREM-DUE -
               TEMP-WORK-AREA.
           COMPUTE HOLD-CURR-LOAN = HOLD-CURR-LOAN -
               RGR-LBILL-POL-LPAY-AMT.
           COMPUTE HOLD-CURR-MISC = HOLD-CURR-MISC -
               RGR-POL-SNDRY-AMT.

       0970-SUBTRACT-FROM-HOLD-CURR-X.
           EXIT.
      /
557668 0980-FORMAT-SCREEN-NAME.
557668     INITIALIZE L0620-INPUT-PARM-INFO
557668
557668     IF L2435-CLI-SEX-CD = 'C'
557668         MOVE L2435-CLI-FULL-NAME
                                      TO L0620-CLI-CO-NM
557668     ELSE
557668         MOVE L2435-CLI-GIV-NM  TO L0620-CLI-GIV-NM
557668         MOVE L2435-CLI-SUR-NM  TO L0620-CLI-SUR-NM
015705         MOVE L2435-CLI-MID-INIT-NM
015705                                TO L0620-CLI-MID-INIT-NM
015705         MOVE L2435-CLI-SFX-NM  TO L0620-CLI-SFX-NM
557668     END-IF.
557668     MOVE L2435-CLI-SEX-CD      TO L0620-CLI-SEX-CD
557668
557668     PERFORM  0620-1000-FORMAT-SCREEN-NAME
557668         THRU 0620-1000-FORMAT-SCREEN-NAME-X.
557668
557668 0980-FORMAT-SCREEN-NAME-X.
557668     EXIT.

      /
       9300-SETUP-MSIN-REFERENCE.

            MOVE SPACES               TO WGLOB-MSIN-REFERENCE.
            MOVE WGLOB-COMPANY-CODE   TO WGLOB-REF-COMPANY-CODE.
            MOVE 'C'                  TO WGLOB-REF-POLICY-OR-CLIENT.
            MOVE MIR-LBILL-CLI-ID     TO WGLOB-REF-CLIENT-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /

       9700-ZERO-MAINTAIN-FIELDS.

018243     PERFORM  0940-DISPLAY-MAINTAIN-VALUES
018243         THRU 0940-DISPLAY-MAINTAIN-VALUES-X.

008455*    MOVE '0000000.00'             TO  HOLD-MPREM.
008455*    MOVE '0000000.00'             TO  HOLD-MLOAN.
008455*    MOVE '0000000.00'             TO  HOLD-MMISC.
020874*    MOVE ZEROS                 TO  L0290-INPUT-NUMBER.
020874     MOVE ZEROS                 TO  L0290-INPUT-V02.
008455     MOVE 2                     TO  L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LBILL-POL-PREM-AMT
                                      TO  L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO  HOLD-MPREM-X.
008455     MOVE ZERO                  TO  HOLD-MPREM.
008455
020874*    MOVE ZEROS                 TO  L0290-INPUT-NUMBER.
020874     MOVE ZEROS                 TO  L0290-INPUT-V02.
008455     MOVE 2                     TO  L0290-PRECISION.
008455     MOVE LENGTH OF MIR-LBILL-POL-LPAY-AMT
                                      TO  L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO  HOLD-MLOAN-X.
008455     MOVE ZERO                  TO  HOLD-MLOAN.
008455
020874*    MOVE ZEROS                 TO  L0290-INPUT-NUMBER.
020874     MOVE ZEROS                 TO  L0290-INPUT-V02.
008455     MOVE 2                     TO  L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-SNDRY-AMT
                                      TO  L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO  HOLD-MMISC-X.
008455     MOVE ZERO                  TO  HOLD-MMISC.

018243*    PERFORM  0940-DISPLAY-MAINTAIN-VALUES
018243*        THRU 0940-DISPLAY-MAINTAIN-VALUES-X.

       9700-ZERO-MAINTAIN-FIELDS-X.
           EXIT.


       9710-ZERO-TOTAL-FIELDS.

008455*    MOVE ZEROS                    TO  NUMBER-EDIT.
008455*    MOVE NUMBER-EDIT              TO  MIR-TOT-CRNT-PREM-AMT
008455*                                      MIR-TOT-CRNT-LPAY-AMT
008455*                                      MIR-TOT-CRNT-SNDRY-AMT
008455*                                      MIR-TOT-BILL-PREM-AMT
008455*                                      MIR-TOT-BILL-LPAY-AMT
008455*                                      MIR-TOT-BILL-SNDRY-AMT
008455*                                      MIR-DV-TOT-CRNT-AMT
008455*                                      MIR-DV-TOT-BILL-AMT.
020874*    MOVE ZEROS                 TO  L0290-INPUT-NUMBER.
020874     MOVE ZEROS                 TO  L0290-INPUT-V02.
008455     MOVE 2                     TO  L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TOT-CRNT-PREM-AMT
                                      TO  L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO  MIR-TOT-CRNT-PREM-AMT.
008455
020874*    MOVE ZEROS                 TO  L0290-INPUT-NUMBER.
020874     MOVE ZEROS                 TO  L0290-INPUT-V02.
008455     MOVE 2                     TO  L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TOT-CRNT-LPAY-AMT
                                      TO  L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO  MIR-TOT-CRNT-LPAY-AMT.
008455
020874*    MOVE ZEROS                 TO  L0290-INPUT-NUMBER.
020874     MOVE ZEROS                 TO  L0290-INPUT-V02.
008455     MOVE 2                     TO  L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TOT-CRNT-SNDRY-AMT
                                      TO  L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO  MIR-TOT-CRNT-SNDRY-AMT.
008455
020874*    MOVE ZEROS                 TO  L0290-INPUT-NUMBER.
020874     MOVE ZEROS                 TO  L0290-INPUT-V02.
008455     MOVE 2                     TO  L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TOT-BILL-PREM-AMT
                                      TO  L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO  MIR-TOT-BILL-PREM-AMT.
008455
020874*    MOVE ZEROS                 TO  L0290-INPUT-NUMBER.
020874     MOVE ZEROS                 TO  L0290-INPUT-V02.
008455     MOVE 2                     TO  L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TOT-BILL-LPAY-AMT
                                      TO  L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO  MIR-TOT-BILL-LPAY-AMT.
008455
020874*    MOVE ZEROS                 TO  L0290-INPUT-NUMBER.
020874     MOVE ZEROS                 TO  L0290-INPUT-V02.
008455     MOVE 2                     TO  L0290-PRECISION.
008455     MOVE LENGTH OF MIR-TOT-BILL-SNDRY-AMT
                                      TO  L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO  MIR-TOT-BILL-SNDRY-AMT.
008455
020874*    MOVE ZEROS                 TO  L0290-INPUT-NUMBER.
020874     MOVE ZEROS                 TO  L0290-INPUT-V02.
008455     MOVE 2                     TO  L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-TOT-CRNT-AMT
                                      TO  L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO  MIR-DV-TOT-CRNT-AMT.
008455
020874*    MOVE ZEROS                 TO  L0290-INPUT-NUMBER.
020874     MOVE ZEROS                 TO  L0290-INPUT-V02.
008455     MOVE 2                     TO  L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-TOT-BILL-AMT
                                      TO  L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO  TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO  MIR-DV-TOT-BILL-AMT.

       9710-ZERO-TOTAL-FIELDS-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2520-0000-INIT-PARM-INFO
025970         THRU 2520-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2625-0000-INIT-PARM-INFO
025970         THRU 2625-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  N8.
025970     INITIALIZE  GRPA-MISCELLANEOUS-WORK-AREAS.
025970     INITIALIZE  MIR-MISCELLANEOUS-SCREEN-WORK.
025970     INITIALIZE  WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE  WLOCK-TWRK-OTHER-INFO.
025970
025970     SET PAGE-LIMIT-DEFAULT          TO TRUE.
025970     SET TRAN-CODE-INXX-DEFAULT      TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT         TO TRUE.
025970     SET UPDATE-REQUIRED-DEFAULT     TO TRUE.
025970     SET TRAN-CODE-FOUND-DEFAULT     TO TRUE.
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
025970 COPY XCPS1670.
025970 COPY XCPS8090.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY XCPS0280.
008455 COPY XCPL0280.
008455/
008455 COPY XCPS0290.
008455 COPY XCPL0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1680.
005409 COPY XCPL1680.
      /
018764*COPY CCCL0985.
018764 COPY CCPL0985.
016108/
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      /
018764*COPY CCCL2435.
018764 COPY CCPL2435.
      /
020478 COPY CCPS2625.
020478 COPY CCPL2625.
018764*COPY CCCL5600.
018764 COPY CCPL5600.
      /
016108 COPY CCPS0985.
016108/
018764*COPY CCCL5400.
018764 COPY CCPL5400.
016440 COPY CCPS5400.
      /
       COPY CCPS2430.
      /
       COPY CCPS2435.
      /
       COPY CCPS5600.
      /
013578*COPY XCPS2490.
      /
013578*COPY XCCL2490.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
025970 COPY CCPS0620.
557668 COPY CCPL0620.
      /
557697 COPY CCPS2520.
018764*COPY CCCL2520.
018764 COPY CCPL2520.
557697/
557697 COPY CCPPSFBL.
557697/
       COPY CCPAGR.
      /
       COPY CCPBGR.
      /
       COPY CCPCGR.
      /
       COPY CCPNGR.
      /
       COPY CCPUGR.
      /
       COPY CCPNPOL.
      /
010418 COPY CCPNSCOM.
      /
       COPY CCPNCVG.
      /
016108 COPY NCPPCVGS.
016108/
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY GR
014221                           '$VAR2' BY 'GR'.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      /
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM0281                     **
      *****************************************************************
