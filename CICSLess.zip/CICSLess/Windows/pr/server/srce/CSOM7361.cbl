      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7361.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7361                                         **
      **  REMARKS:  THIS MODULE PERFORMS DEATH CLAIM PAYMENT REVERSAL**
      **            FOR BENEFICIARY CLAIM AMOUNT AND INTEREST.       **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
026055**  6.6       INTEREST ON DELAYED DEATH CLAIMS                 **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7361'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                          PIC X(04).
               88  WS-BUS-FCN-PAY-REV                 VALUE '7361'.
           05  WS-WORK-CTR.
               10  WS-BENE                            PIC S9(04) BINARY.
           05  WS-CVG-NUM                             PIC S9(02) BINARY.
           05  WS-PDCL-INFO.
               10  WS-PDCL-DTHCLM-SEQ-NUM             PIC S9(04) BINARY.
           05  WS-PDCL-DISPLAY-KEY.
               10  WS-COMPANY-ID                      PIC X(02).
               10  WS-POLICY-ID                       PIC X(10).
               10  WS-SEQ-NUM                         PIC 9(04).

       01  WS-CONSTANT-AREA.
           05  WS-TWRK-KEY                            PIC X(04).
               88 WS-TWRK-KEY-DEFAULT                 VALUE '7361'.
           05  WS-MAX-DCBNFY-CTR                      PIC S9(04).
               88 WS-MAX-DCBNFY-CTR-DEFAULT           VALUE 99.

       01  WS-BUFFER-AREA.
           05  WS-DCBNFY-INFO.
               10  WS-DCBNFY-CTR                      PIC S9(04) BINARY.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWLOCK.
       COPY CCWWINDX.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRCVG.
       COPY CCFWCVG.

       COPY CCFRPOL.
       COPY CCFWPOL.

       COPY CCFWPDCL.
       COPY CCFRPDCL.

       COPY CCWWCVGS.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
028298 COPY CCWL2626.
       COPY CCWL5120.
       COPY CCWL5400.

       COPY CCWL7366.

       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL8090.
       COPY XCWLDTLK.

       COPY CCWLPGA.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7361.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-PAY-REV
                    PERFORM  2000-PAY-REVERSAL
                        THRU 2000-PAY-REVERSAL-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7361'           TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------------
       2000-PAY-REVERSAL.
      *------------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

      * VALIDATE KEY INFO

           PERFORM  8000-EDIT-INFO
               THRU 8000-EDIT-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-PAY-REVERSAL-X
           END-IF.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

      * INITIALIZE OUTPUT FIELDS

           PERFORM  8100-BLANK-DATA-FIELDS
               THRU 8100-BLANK-DATA-FIELDS-X.

      * GET PDCL INFORMATION

           PERFORM  2100-GET-PDCL-INFO
               THRU 2100-GET-PDCL-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  8100-BLANK-DATA-FIELDS
                   THRU 8100-BLANK-DATA-FIELDS-X
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-PAY-REVERSAL-X
           END-IF.

      * PROCESS PAY REVERSAL

           PERFORM  3000-PROCESS-PAY-REVERSAL
               THRU 3000-PROCESS-PAY-REVERSAL-X.

       2000-PAY-REVERSAL-X.
           EXIT.

      *-------------------
       2100-GET-PDCL-INFO.
      *-------------------

           MOVE LOW-VALUES              TO WPDCL-KEY.
           MOVE WGLOB-COMPANY-CODE      TO WPDCL-CO-ID.
           MOVE RPOL-POL-ID             TO WPDCL-POL-ID.
           MOVE WS-PDCL-DTHCLM-SEQ-NUM  TO WPDCL-DTHCLM-SEQ-NUM.

           PERFORM  PDCL-1000-READ
               THRU PDCL-1000-READ-X.

           IF  NOT WPDCL-IO-OK
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'XS00000001'        TO WGLOB-MSG-REF-INFO
               MOVE WPDCL-KEY             TO WS-PDCL-DISPLAY-KEY               
               MOVE 0                     TO L0290-PRECISION
               MOVE LENGTH OF WS-SEQ-NUM  TO L0290-MAX-OUT-LEN
               MOVE WPDCL-DTHCLM-SEQ-NUM  TO L0290-INPUT-NUMBER
               PERFORM  0290-1000-NUMERIC-FORMAT
                   THRU 0290-1000-NUMERIC-FORMAT-X
               MOVE L0290-OUTPUT-DATA     TO WS-SEQ-NUM
               MOVE WS-PDCL-DISPLAY-KEY   TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2100-GET-PDCL-INFO-X
           END-IF.

           IF  RPDCL-DTHCLM-STAT-REVRS
      *MSG: REVERSAL NOT ALLOWED. PENDING INTEREST ON DEATH CLAIM HAS
      *     BEEN REVERSED.
               MOVE 'CS73610001'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2100-GET-PDCL-INFO-X
           END-IF.

           IF  RPDCL-DTHCLM-STAT-PEND
           OR  RPDCL-DTHCLM-STAT-ERROR
      *MSG: REVERSAL NOT ALLOWED. NO PAYMENT FOR THE RECORD HAS BEEN
      *     PAID YET.
               MOVE 'CS73610002'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2100-GET-PDCL-INFO-X
           END-IF.

           PERFORM  2110-MOVE-PDCL-TO-MIR
               THRU 2110-MOVE-PDCL-TO-MIR-X.

       2100-GET-PDCL-INFO-X.
           EXIT.

      *----------------------
       2110-MOVE-PDCL-TO-MIR.
      *----------------------

           MOVE RPDCL-CVG-NUM            TO MIR-CVG-NUM.

           MOVE RPDCL-DTHCLM-AMT         TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DTHCLM-AMT TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DTHCLM-AMT.

           MOVE RPDCL-DTHCLM-ADDL-AMT    TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DTHCLM-ADDL-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DTHCLM-ADDL-AMT.

           MOVE RPDCL-DTHCLM-INT-DT-CD   TO MIR-DTHCLM-INT-DT-CD.

           MOVE RPDCL-DTHCLM-INT-STRT-DT TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO MIR-DTHCLM-INT-STRT-DT.

           MOVE RPDCL-DTHCLM-INT-PCT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DTHCLM-INT-PCT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DTHCLM-INT-PCT.

           MOVE RPDCL-DTHCLM-STAT-CD     TO MIR-DTHCLM-STAT-CD.

           MOVE RPDCL-DTHCLM-CREAT-DT    TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO MIR-DTHCLM-CREAT-DT.

           MOVE RPDCL-DTHCLM-OVRID-IND   TO MIR-DTHCLM-OVRID-IND.

           MOVE RPDCL-DTHCLM-COMNT-INFO-TXT
                                         TO MIR-DTHCLM-COMNT-INFO.

       2110-MOVE-PDCL-TO-MIR-X.
           EXIT.

      /
      *--------------------------
       3000-PROCESS-PAY-REVERSAL.
      *--------------------------

           EVALUATE TRUE

               WHEN MIR-DV-PRCES-STATE-CD = '2'
                    PERFORM  3100-PROCESS-PAY-REV-2
                        THRU 3100-PROCESS-PAY-REV-2-X

               WHEN MIR-DV-PRCES-STATE-CD = '3'
                    PERFORM  3300-PROCESS-PAY-REV-3
                        THRU 3300-PROCESS-PAY-REV-3-X

           END-EVALUATE.

       3000-PROCESS-PAY-REVERSAL-X.
           EXIT.

      *-----------------------
       3100-PROCESS-PAY-REV-2.
      *-----------------------

      * CALL CSDF7366 TO PERFORM EDIT ON EACH BENEFICIARY

           PERFORM  7366-1000-BUILD-PARM-INFO
               THRU 7366-1000-BUILD-PARM-INFO-X.

           SET L7366-PRCES-TYP-EDIT-ONLY TO TRUE.

           PERFORM  7366-1000-REV-DCBNFY-INT
               THRU 7366-1000-REV-DCBNFY-INT-X.

           IF  NOT L7366-RETRN-OK
               GO TO 3100-PROCESS-PAY-REV-2-X
           END-IF.

           MOVE L7366-DCBNFY-CTR         TO WS-DCBNFY-CTR.

           PERFORM  7000-MOVE-LINKAGE-TO-MIR
               THRU 7000-MOVE-LINKAGE-TO-MIR-X
               VARYING WS-BENE FROM 1 BY +1
               UNTIL   WS-BENE > WS-DCBNFY-CTR.

       3100-PROCESS-PAY-REV-2-X.
           EXIT.

      *-----------------------
       3300-PROCESS-PAY-REV-3.
      *-----------------------

      * CALL CSDF7366 TO PAY BENEFICIARY

           PERFORM  7366-1000-BUILD-PARM-INFO
               THRU 7366-1000-BUILD-PARM-INFO-X.

           SET L7366-PRCES-TYP-ALL       TO TRUE.

           PERFORM  7366-1000-REV-DCBNFY-INT
               THRU 7366-1000-REV-DCBNFY-INT-X.

           IF  NOT L7366-RETRN-OK
               GO TO 3300-PROCESS-PAY-REV-3-X
           END-IF.

           MOVE L7366-DCBNFY-CTR         TO WS-DCBNFY-CTR.

           PERFORM  7000-MOVE-LINKAGE-TO-MIR
               THRU 7000-MOVE-LINKAGE-TO-MIR-X
               VARYING WS-BENE FROM 1 BY +1
               UNTIL   WS-BENE > WS-DCBNFY-CTR.

      * REWRITE POL TABLE

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

      *MSG: REVERSAL TRANSACTION PROCESSED
           MOVE 'CS73610004'             TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3300-PROCESS-PAY-REV-3-X.
           EXIT.
      /
      *-------------------------
       7000-MOVE-LINKAGE-TO-MIR.
      *-------------------------

           MOVE L7366-CLI-ID (WS-BENE)  TO MIR-CLI-ID-T (WS-BENE).

           MOVE L7366-CLI-ID (WS-BENE)  TO L5120-CLI-ID.
           PERFORM  5120-1000-CLI-NAME-UPDATE
               THRU 5120-1000-CLI-NAME-UPDATE-X.
           MOVE L5120-CLI-NAME       TO MIR-DV-CLI-NM-T (WS-BENE).

           MOVE L7366-DCBNFY-PCT (WS-BENE)
                                     TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DCBNFY-PCT-T (WS-BENE)
                                     TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DCBNFY-PCT-T (WS-BENE).

           MOVE L7366-DCBNFY-PD-AMT (WS-BENE)
                                     TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DCBNFY-PD-AMT-T (WS-BENE)
                                     TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DCBNFY-PD-AMT-T (WS-BENE).

           MOVE L7366-DCBNFY-INT-PD-AMT (WS-BENE)
                                     TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DCBNFY-INT-PD-AMT-T (WS-BENE)
                                     TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO
                                     MIR-DCBNFY-INT-PD-AMT-T (WS-BENE).

           MOVE L7366-DCBNFY-PD-DT (WS-BENE)
                                     TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE  TO MIR-DCBNFY-PD-DT-T (WS-BENE).

           MOVE L7366-DCBNFY-REVRS-DT (WS-BENE)
                                     TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE  TO MIR-DCBNFY-REVRS-DT-T (WS-BENE).

           MOVE L7366-DCBNFY-PAYO-CD (WS-BENE)
                                     TO MIR-DCBNFY-PAYO-CD-T (WS-BENE).

           MOVE L7366-DCBNFY-FED-CALC-CD (WS-BENE)
             TO MIR-DCBNFY-FED-CALC-CD-T (WS-BENE).

           MOVE L7366-FED-TAXWH-AMT (WS-BENE)
                                     TO L0290-INPUT-V02.
           MOVE 2                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FED-TAXWH-AMT-T (WS-BENE)
                                     TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-FED-TAXWH-AMT-T (WS-BENE).

           MOVE L7366-DCBNFY-STAT-CD (WS-BENE)
                                     TO MIR-DCBNFY-STAT-CD-T (WS-BENE).

           MOVE L7366-DCBNFY-BPSS-IND (WS-BENE)
                                     TO MIR-DCBNFY-BPSS-IND-T (WS-BENE).

       7000-MOVE-LINKAGE-TO-MIR-X.
           EXIT.

      *---------------
       8000-EDIT-INFO.
      *---------------

      * VALIDATE KEY INFOMATION

            PERFORM  8010-EDIT-KEY-INFO
                THRU 8010-EDIT-KEY-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8000-EDIT-INFO-X
           END-IF.

       8000-EDIT-INFO-X.
           EXIT.

      *-------------------
       8010-EDIT-KEY-INFO.
      *-------------------
      *
      * VALIDATE POL NUMBER
      *
           MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.

           IF  NOT MIR-DV-PRCES-STATE-CD = '3'
               PERFORM  POL-1000-READ-TWRK-TS
                   THRU POL-1000-READ-TWRK-TS-X
           ELSE
               PERFORM  POL-2000-UPDATE-TWRK-TS
                   THRU POL-2000-UPDATE-TWRK-TS-X
               IF  MIR-RETRN-TS-MISMATCH
      *  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
      *  NOT COMPLETE
                   MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
                   MOVE 'POL'             TO WGLOB-MSG-PARM (01)
                   MOVE WPOL-KEY          TO WGLOB-MSG-PARM (02)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                    GO TO 8010-EDIT-KEY-INFO-X
               END-IF
           END-IF.

           IF  NOT WPOL-IO-OK
      * MSG:  POLICY NOT IN FILE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8010-EDIT-KEY-INFO-X
           END-IF.
      *
      *  DO POLICY ACCESS CHECKS
      *
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-CRCY-MSG-REQD    TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
               MOVE '1'               TO WGLOB-RETURN-CODE
               GO TO 8010-EDIT-KEY-INFO-X
           END-IF.
      *
      * LOAD WCVGS ARRAY
      *
           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           IF  WGLOB-MSG-ERROR-SW NOT = ZERO
               MOVE '1'               TO WGLOB-RETURN-CODE
               GO TO 8010-EDIT-KEY-INFO-X
           END-IF.
      *
      * VALID PDCL SEQ NUM
      *
           SET L0280-SIGN-NOT-PERMITTED    TO TRUE.
           MOVE ZERO                       TO L0280-PRECISION.
           MOVE 5                          TO L0280-LENGTH.
           MOVE 5                          TO L0280-INPUT-SIZE.
           MOVE MIR-DTHCLM-SEQ-NUM         TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG:     'SEQUENCE NUMBER MUST BE VALID NUMERIC'
               MOVE 'CS73610003'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8010-EDIT-KEY-INFO-X
           ELSE
               MOVE L0280-OUTPUT           TO WS-PDCL-DTHCLM-SEQ-NUM
           END-IF.

       8010-EDIT-KEY-INFO-X.
           EXIT.

      *-----------------------
       8100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       8100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.
           MOVE MIR-POL-ID-BASE          TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX           TO WGLOB-REF-POLICY-SUFFIX.
           SET WGLOB-REF-POLICY          TO TRUE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
           PERFORM  5120-0000-INIT-PARM-INFO
               THRU 5120-0000-INIT-PARM-INFO-X.

           PERFORM  5400-0000-INIT-PARM-INFO
               THRU 5400-0000-INIT-PARM-INFO-X.

           PERFORM  7366-0000-INIT-PARM-INFO
               THRU 7366-0000-INIT-PARM-INFO-X.

           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
           INITIALIZE WLOCK-TWRK-OTHER-INFO.
           INITIALIZE FREQUENTLY-USED-INDICES.

           SET WS-TWRK-KEY-DEFAULT        TO TRUE.
           SET WS-MAX-DCBNFY-CTR-DEFAULT  TO TRUE.
           SET MIR-RETRN-OK               TO TRUE.

           MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
       COPY NCPPCVGS.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPS8090.
       COPY CCPS5120.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL5120.

       COPY CCPS5400.
       COPY CCPL5400.

       COPY CCPS7366.
       COPY CCPL7366.

       COPY XCPL0260.
       COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPS1640.
       COPY XCPL1640.
       COPY XCPL8090.

       COPY XCPL0290.
       COPY XCPS0290.

       COPY CCPSPGA.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.

       COPY CCPNCVG.

       COPY CCPNPDCL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM7361                     **
      *****************************************************************
