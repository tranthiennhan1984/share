      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7830.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7830                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE RETRIEVE FUNCTION     **
      **            FOR THE FUTURE DATED POLICY REQUEST              **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020478**  6.6       FUTURE DATED TRANSACTION                         **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
038363**  7.1       TAX CALC OPTION DISPLAY ON FUTURE DATED TRANSACT **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7830'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-RETRIEVE       VALUE '7830'.
           05  WS-VALIDATE-SW                PIC X(01).
               88  WS-VALIDATE-OK            VALUE 'Y'.
               88  WS-VALIDATE-NOT-OK        VALUE 'N'.
036742*    05  WS-SAVE-TS                    PIC X(26).
036742     05  WS-SAVE-GEN-ID                PIC 9(10).
           05  WS-BUS-FCN-CHECK              PIC X(04).
               88  WS-BUS-FCN-SURR-FND-DEF   VALUE '8222'.
036742     05  WS-KEY.
036742         10  WS-KEY-DATE               PIC X(10).
036742         10  WS-KEY-GEN-ID             PIC 9(10).
036742     05  WS-EFF-DT                     PIC X(10).

       01  WS-CONSTANT-FIELDS.
           05  WS-TWRK-KEY                   PIC X(04).
               88  WS-TWRK-KEY-DEFAULT       VALUE '7830'.
           05  WS-LOC-CHG-MIR-LEN            PIC X(5).
               88  WS-LOC-CHG-MIR-LEN-DEFAULT
                                             VALUE '00060'.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWINDX.

       COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWPOL.
       COPY CCFRPOL.

           EXEC SQL INCLUDE CCFRPORQ END-EXEC.
           EXEC SQL INCLUDE CCFWPORQ END-EXEC.

       COPY XCFRDMAD.
       COPY XCFWDMAD.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
       COPY CCWL2430.
038363*COPY CCWL2626.

036742 COPY XCWLDTLK.
036742 COPY XCWL0280.
036742 COPY XCWL1640.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
      * CCWM7830 IS MAPPED TO OTHER MIR COPYBOOKS WITH POLICY ID AND
      * CREATE TIMESTAMP AS THE FIRST TWO FIELDS AFTER THE CONTROL
      * FIELDS.
       COPY CCWM7830.

      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------


           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

038363*    PERFORM  FPCK-1000-CHECK-POLICY
038363*        THRU FPCK-1000-CHECK-POLICY-X.
038363*
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7830'          TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000000'        TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                                             TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *-------------
       2000-RETRIEVE.
      *-------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED     TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           MOVE MIR-POL-ID                   TO  WPOL-POL-ID.
           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  NOT WPOL-IO-OK
      *MSG: RECORD (@1) NOT FOUND
               MOVE WPOL-POL-ID              TO WGLOB-MSG-PARM (1)
               MOVE 'POL'                    TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000001'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  PORQ-1000-READ
               THRU PORQ-1000-READ-X.

           IF  NOT WPORQ-IO-OK
      *MSG: FUTURE DATED POLICY ACTIVITY RECORD NOT FOUND
               MOVE 'CS78300001'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED     TO TRUE
           ELSE
               PERFORM  9200-MOVE-RECORD-TO-MIR
                   THRU 9200-MOVE-RECORD-TO-MIR-X
      *MSG: DETAILS FOR ACTIVITY RETRIEVED: CREATE TIMESTAMP (@1),
      *     TYPE (@2), BUSINESS PROCESS (@3), STATUS (@4)
036742*        MOVE RPORQ-POL-RQST-CREAT-TS  TO WGLOB-MSG-PARM (1)
036742         MOVE RPORQ-POL-RQST-EFF-DT    TO WS-KEY-DATE
036742         MOVE RPORQ-POL-RQST-GEN-ID    TO WS-KEY-GEN-ID
036742         MOVE WS-KEY                   TO WGLOB-MSG-PARM (1)

               MOVE RPORQ-POL-RQST-TYP-CD    TO WDMAD-DM-AV-CD
               MOVE 'POL-RQST-TYP-CD'        TO WDMAD-DM-AV-TBL-CD
               MOVE WGLOB-USER-LANG          TO WDMAD-DM-AV-DESC-LANG-CD

               PERFORM  DMAD-1000-READ
                   THRU DMAD-1000-READ-X
               MOVE RDMAD-DM-AV-DESC-TXT     TO WGLOB-MSG-PARM (2)
               MOVE RPORQ-BUS-FCN-ID         TO WGLOB-MSG-PARM (3)


               MOVE RPORQ-POL-RQST-STAT-CD   TO WDMAD-DM-AV-CD
               MOVE 'POL-RQST-STAT-CD'       TO WDMAD-DM-AV-TBL-CD
               MOVE WGLOB-USER-LANG          TO WDMAD-DM-AV-DESC-LANG-CD

               PERFORM  DMAD-1000-READ
                   THRU DMAD-1000-READ-X
               MOVE RDMAD-DM-AV-DESC-TXT     TO WGLOB-MSG-PARM (4)
               MOVE 'CS78300002'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

036742*    MOVE WS-SAVE-TS                   TO MIR-POL-RQST-CREAT-TS.
036742     MOVE WS-SAVE-GEN-ID               TO MIR-POL-RQST-GEN-ID.
036742     MOVE WS-EFF-DT                    TO MIR-POL-RQST-EFF-DT.

           MOVE RPORQ-BUS-FCN-ID             TO WS-BUS-FCN-CHECK.
           IF  WS-BUS-FCN-SURR-FND-DEF
      *MSG: WITHDRAWAL WILL BE PROCESSED USING POLICY ALLOCATION
      *     INSTRUCTIONS IN EFFECT AT THE TIME OF PROCESSING.
      *     INSTRUCTIONS CAN BE VIEWED ON POLICU ALLOCATION LIST.
               MOVE 'CS78300003'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2000-RETRIEVE-X.
           EXIT.

      /
      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------

           IF  MIR-POL-ID = SPACES
      *MSG: POLICY ID MUST BE ENTERED
               MOVE 'CS00000048'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-VALIDATE-NOT-OK        TO TRUE
           END-IF.

036742     MOVE MIR-POL-RQST-EFF-DT          TO L1640-EXTERNAL-DATE.
036742     PERFORM 1640-7000-MIR-TO-INT
036742        THRU 1640-7000-MIR-TO-INT-X.
036742     IF  NOT L1640-RETRN-OK
036742*MSG: EFFECTIVE DATE MUST BE IN VALID FORMAT
036742         MOVE 'CS00000054'             TO WGLOB-MSG-REF-INFO
036742         PERFORM  0260-1000-GENERATE-MESSAGE
036742             THRU 0260-1000-GENERATE-MESSAGE-X
036742         GO TO 2100-VALIDATE-KEYS-X
036742     END-IF.
036742     MOVE L1640-INTERNAL-DATE          TO WS-EFF-DT.
036742
036742*    MOVE MIR-POL-RQST-CREAT-TS        TO WS-SAVE-TS.
036742     MOVE MIR-POL-RQST-GEN-ID          TO L0280-INPUT-DATA.
036742     MOVE LENGTH OF MIR-POL-RQST-GEN-ID
036742                                       TO L0280-INPUT-SIZE.
036742     MOVE L0280-INPUT-SIZE             TO L0280-LENGTH.
036742     MOVE ZERO                         TO L0280-PRECISION.
036742     SET L0280-SIGN-NOT-PERMITTED      TO TRUE.
036742     SET L0280-SPACES-PERMITTED        TO TRUE.
036742
036742     PERFORM  0280-1000-NUMERIC-EDIT
036742         THRU 0280-1000-NUMERIC-EDIT-X.
036742
036742     IF  L0280-OK
036742         MOVE L0280-OUTPUT-V00         TO WS-SAVE-GEN-ID
036742     ELSE
036742         MOVE ZERO                     TO WS-SAVE-GEN-ID
036742*MSG: INVALID NUMERIC
036742         MOVE 'XS00000018'             TO WGLOB-MSG-REF-INFO
036742         PERFORM  0260-1000-GENERATE-MESSAGE
036742             THRU 0260-1000-GENERATE-MESSAGE-X
036742     END-IF.

       2100-VALIDATE-KEYS-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE MIR-POL-ID                   TO WPORQ-POL-ID.
036742*    MOVE MIR-POL-RQST-CREAT-TS        TO WPORQ-POL-RQST-CREAT-TS.
036742     MOVE WS-EFF-DT                    TO WPORQ-POL-RQST-EFF-DT.
036742     MOVE WS-SAVE-GEN-ID               TO WPORQ-POL-RQST-GEN-ID.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                       TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9200-MOVE-RECORD-TO-MIR.
      *--------------------------

           IF  RPORQ-POL-RQST-TYP-CRNT-LOC
               PERFORM  2430-1000-BUILD-PARM-INFO
                   THRU 2430-1000-BUILD-PARM-INFO-X

               MOVE RPOL-POL-ID              TO L2430-POL-ID
               MOVE ZERO                     TO I

               PERFORM  2430-2100-GET-OWNER
                   THRU 2430-2100-GET-OWNER-X
               MOVE L2430-CLI-ID             TO MIR-CLI-ID
               MOVE L2430-CLI-ADDR-TYP-CD    TO MIR-CLI-ADDR-TYP-CD
               MOVE WS-LOC-CHG-MIR-LEN       TO MIR-LENGTH
           ELSE

               MOVE WPORQ-POL-RQST-MSG-INFO-LENGTH
                                             TO
                                  WPORQ-POL-RQST-MSG-INFO-STRLEN
               MOVE 1                        TO
                                  WPORQ-POL-RQST-MSG-INFO-STRBEG

               SET  WPORQ-POL-RQST-MSG-INFO-SELCT
                                             TO TRUE

               PERFORM  PORQ-3000-READ-LOB
                   THRU PORQ-3000-READ-LOB-X

               MOVE RPORQ-POL-RQST-MSG-INFO-DATA
                                  (1:RPORQ-POL-RQST-MSG-INFO-LENGTH)
                                             TO
                                  MIR-PARM-AREA
                                  (1:RPORQ-POL-RQST-MSG-INFO-LENGTH)

           END-IF.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                     TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE         TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX          TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.
036742
036742     PERFORM  0280-0000-INIT-PARM-INFO
036742         THRU 0280-0000-INIT-PARM-INFO-X.
036742
036742     PERFORM  1640-0000-INIT-PARM-INFO
036742         THRU 1640-0000-INIT-PARM-INFO-X.

           PERFORM  2430-0000-INIT-PARM-INFO
               THRU 2430-0000-INIT-PARM-INFO-X.

038363*    PERFORM  2626-0000-INIT-PARM-INFO
038363*        THRU 2626-0000-INIT-PARM-INFO-X.
038363*
           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           INITIALIZE  WLOCK-TWRK-TIMESTAMP-INFO.

           INITIALIZE  WLOCK-TWRK-OTHER-INFO.
           INITIALIZE  FREQUENTLY-USED-INDICES.

           SET  WS-TWRK-KEY-DEFAULT          TO TRUE.
           SET  WS-LOC-CHG-MIR-LEN-DEFAULT   TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
038363*COPY CCPPFPCK.
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.

       COPY XCPPEXIT.

       COPY XCPPINIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPS8090.
       COPY CCPS2430.
038363*COPY CCPS2626.
038363*COPY CCPL2626.
       COPY CCPL2430.

       COPY XCPL0260.
036742
036742 COPY XCPS0280.
036742 COPY XCPL0280.

036742 COPY XCPS1640.
036742 COPY XCPL1640.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.

       COPY CCPUPOL.

       COPY CCPNPORQ.

       COPY XCPNDMAD.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM CSOM7830                        **
      *****************************************************************
