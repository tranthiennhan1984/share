      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM1214.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM1214                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE RT TABLE                                 **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015543**  6.0       CODE CLEANUP                                     **
016537**  6.2       CODE CLEANUP                                     **
016548**  6.2       CHANGE COMP TO BINARY                            **
017362**  6.2       CORRECT ERROR 34 TO GOT TO EXIT                  **
012525**  6.3       POLICY TERM AND CESSATION AGE (6.1.1E)           **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM1214'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

014590*COPY XCWL0030.
      *
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-LIST          VALUE '1214'.
016548*    05  WS-SUB                       PIC S9(04) COMP.
016548     05  WS-SUB                       PIC S9(04) BINARY.
016548*    05  WS-MAX-LIST-LINES            PIC S9(04) COMP VALUE 30.
025970*    05  WS-MAX-LIST-LINES            PIC S9(04) BINARY VALUE 30.
           05  WS-MIR-RTBL-IDT-NUM          PIC X(07).
           
       
025970 01  WS-CONSTANT-FIELDS.
025970     05  WS-MAX-LIST-LINES                PIC S9(4) COMP-3.  
025970         88  WS-MAX-LIST-LINES-DEFAULT    VALUE 30. 
      *
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
016537*COPY XCWWWKDT.
      *
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      *
       COPY CCFWRT.
       COPY CCFRRT.
      *
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM1214.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      *
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID        TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM1214'            TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'          TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'          TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      *
      *------------
       2000-LIST.
      *------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF MIR-RETRN-EDIT-ERROR
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  RT-1000-BROWSE
               THRU RT-1000-BROWSE-X.

           PERFORM  RT-2000-READ-NEXT
               THRU RT-2000-READ-NEXT-X.

           IF  WRT-IO-EOF
               PERFORM  RT-3000-END-BROWSE
                   THRU RT-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED   TO TRUE
017362         GO TO 2000-LIST-X
           END-IF.

           MOVE ZERO                       TO WS-SUB.
           PERFORM  2010-BROWSE-RT
               THRU 2010-BROWSE-RT-X
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WRT-IO-EOF.

           IF  WRT-IO-EOF
               CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
           END-IF.

           PERFORM  RT-3000-END-BROWSE
               THRU RT-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.


      *-----------------
       2010-BROWSE-RT.
      *-----------------
      *
           IF WS-SUB = ZERO
               ADD +1                  TO WS-SUB
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
               PERFORM  RT-2000-READ-NEXT
                   THRU RT-2000-READ-NEXT-X
               GO TO 2010-BROWSE-RT-X
           END-IF.
      *
           IF RRT-RTBL-IDT-NUM = WS-MIR-RTBL-IDT-NUM
012525     AND RRT-RTBL-MAT-XPRY-DUR = MIR-RTBL-MAT-XPRY-DUR-T (WS-SUB)
           AND RRT-DPOS-TRM-DY-DUR = MIR-DPOS-TRM-DY-DUR-T (WS-SUB)
           AND RRT-DPOS-TRM-MO-DUR = MIR-DPOS-TRM-MO-DUR-T (WS-SUB)
           AND RRT-LOC-GR-ID = MIR-LOC-GR-ID-T (WS-SUB)
           AND RRT-RTBL-AGE = MIR-RTBL-AGE-T (WS-SUB)
           AND RRT-RTBL-DB-OPT-CD = MIR-RTBL-DB-OPT-CD-T (WS-SUB)
           AND RRT-RTBL-ID = MIR-RTBL-ID-T (WS-SUB)
           AND RRT-RTBL-JNT-LIFE-CD =
               MIR-RTBL-JNT-LIFE-CD-T (WS-SUB)
           AND RRT-RTBL-PAR-CD = MIR-RTBL-PAR-CD-T (WS-SUB)
           AND RRT-RTBL-PNSN-QUALF-CD =
               MIR-RTBL-PNSN-QUALF-CD-T (WS-SUB)
           AND RRT-RTBL-RT-TYP-CD = MIR-RTBL-RT-TYP-CD-T (WS-SUB)
           AND RRT-RTBL-SEX-CD = MIR-RTBL-SEX-CD-T (WS-SUB)
           AND RRT-RTBL-SMKR-CD = MIR-RTBL-SMKR-CD-T (WS-SUB)
           AND RRT-RTBL-STBL-1-CD = MIR-RTBL-STBL-1-CD-T (WS-SUB)
           AND RRT-RTBL-STBL-2-CD = MIR-RTBL-STBL-2-CD-T (WS-SUB)
           AND RRT-RTBL-STBL-3-CD = MIR-RTBL-STBL-3-CD-T (WS-SUB)
           AND RRT-RTBL-STBL-4-CD = MIR-RTBL-STBL-4-CD-T (WS-SUB)
020874*        MOVE RRT-RTBL-AGE-DUR TO L0290-INPUT-NUMBER
020874         MOVE RRT-RTBL-AGE-DUR TO L0290-INPUT-V00
015543*        MOVE LENGTH MIR-RTBL-AGE-DUR-T (1) TO
015543         MOVE LENGTH OF MIR-RTBL-AGE-DUR-T (1) TO
                                      L0290-MAX-OUT-LEN
               MOVE ZERO           TO L0290-PRECISION
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO
                               MIR-DV-END-RTBL-AGE-DUR-T (WS-SUB)
           ELSE
               ADD +1              TO WS-SUB
               IF WS-SUB > WS-MAX-LIST-LINES
                   PERFORM 2015-RETURN-KEY-FOR-MORE
                      THRU 2015-RETURN-KEY-FOR-MORE-X
               ELSE
                   PERFORM  9200-MOVE-RECORD-TO-SCREEN
                       THRU 9200-MOVE-RECORD-TO-SCREEN-X
               END-IF
           END-IF.

           PERFORM  RT-2000-READ-NEXT
               THRU RT-2000-READ-NEXT-X.

       2010-BROWSE-RT-X.
           EXIT.
      *
      *-------------------------
       2015-RETURN-KEY-FOR-MORE.
      *-------------------------
      *
           MOVE RRT-RTBL-DB-OPT-CD     TO MIR-RTBL-DB-OPT-CD.
           MOVE RRT-RTBL-JNT-LIFE-CD   TO MIR-RTBL-JNT-LIFE-CD.
           MOVE RRT-LOC-GR-ID          TO MIR-LOC-GR-ID.
           MOVE RRT-RTBL-PAR-CD        TO MIR-RTBL-PAR-CD.
           MOVE RRT-RTBL-PNSN-QUALF-CD TO MIR-RTBL-PNSN-QUALF-CD.
           MOVE RRT-RTBL-RT-TYP-CD     TO MIR-RTBL-RT-TYP-CD.
           MOVE RRT-RTBL-ID            TO MIR-RTBL-ID.
           MOVE RRT-RTBL-SEX-CD        TO MIR-RTBL-SEX-CD.
           MOVE RRT-RTBL-SMKR-CD       TO MIR-RTBL-SMKR-CD.
           MOVE RRT-RTBL-STBL-1-CD     TO MIR-RTBL-STBL-1-CD.
           MOVE RRT-RTBL-STBL-2-CD     TO MIR-RTBL-STBL-2-CD.
           MOVE RRT-RTBL-STBL-3-CD     TO MIR-RTBL-STBL-3-CD.
           MOVE RRT-RTBL-STBL-4-CD     TO MIR-RTBL-STBL-4-CD.
           MOVE RRT-DPOS-TRM-DY-DUR    TO MIR-DPOS-TRM-DY-DUR.
           MOVE RRT-DPOS-TRM-MO-DUR    TO MIR-DPOS-TRM-MO-DUR.
012525     MOVE RRT-RTBL-MAT-XPRY-DUR  TO MIR-RTBL-MAT-XPRY-DUR.
           MOVE RRT-RTBL-AGE           TO MIR-RTBL-AGE.
           MOVE RRT-RTBL-IDT-NUM       TO L1660-INVERTED-DATE.
           PERFORM 1660-3000-CONVERT-INV-TO-INT
              THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE    TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT                                    
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.                                 
020462     PERFORM 1640-8000-INTERNAL-TO-MIR                                    
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE    TO MIR-RTBL-IDT-NUM.
      *
       2015-RETURN-KEY-FOR-MORE-X.
           EXIT.
      *
      *----------------
       7000-BUILD-KEYS.
      *----------------
      *
           PERFORM 0290-1000-BUILD-PARM-INFO
              THRU 0290-1000-BUILD-PARM-INFO-X.
           MOVE LOW-VALUES             TO WRT-KEY.
           MOVE ZERO                   TO WRT-RTBL-AGE-DUR.
           MOVE MIR-RTBL-DB-OPT-CD     TO WRT-RTBL-DB-OPT-CD.
           MOVE MIR-RTBL-JNT-LIFE-CD   TO WRT-RTBL-JNT-LIFE-CD.
           MOVE MIR-LOC-GR-ID          TO WRT-LOC-GR-ID.
           MOVE MIR-RTBL-PAR-CD        TO WRT-RTBL-PAR-CD.
           MOVE MIR-RTBL-PNSN-QUALF-CD TO WRT-RTBL-PNSN-QUALF-CD.
           MOVE MIR-RTBL-RT-TYP-CD     TO WRT-RTBL-RT-TYP-CD.
           MOVE MIR-RTBL-ID            TO WRT-RTBL-ID.
           MOVE MIR-RTBL-SEX-CD        TO WRT-RTBL-SEX-CD.
           MOVE MIR-RTBL-SMKR-CD       TO WRT-RTBL-SMKR-CD.
           MOVE MIR-RTBL-STBL-1-CD     TO WRT-RTBL-STBL-1-CD.
           MOVE MIR-RTBL-STBL-2-CD     TO WRT-RTBL-STBL-2-CD.
           MOVE MIR-RTBL-STBL-3-CD     TO WRT-RTBL-STBL-3-CD.
           MOVE MIR-RTBL-STBL-4-CD     TO WRT-RTBL-STBL-4-CD.
      *
012525     IF MIR-RTBL-MAT-XPRY-DUR = SPACE
012525         MOVE SPACE              TO WRT-RTBL-MAT-XPRY-DUR
012525     ELSE
012525         MOVE MIR-RTBL-MAT-XPRY-DUR TO L0280-INPUT-DATA
012525         MOVE LENGTH OF MIR-RTBL-MAT-XPRY-DUR TO L0280-INPUT-SIZE
012525         MOVE L0280-INPUT-SIZE   TO L0280-LENGTH
012525         MOVE ZERO               TO L0280-PRECISION
012525         PERFORM 0280-1000-NUMERIC-EDIT
012525            THRU 0280-1000-NUMERIC-EDIT-X
               MOVE L0280-OUTPUT       TO L0290-INPUT-NUMBER
012525         MOVE LENGTH OF MIR-RTBL-MAT-XPRY-DUR TO L0290-MAX-OUT-LEN
012525         MOVE ZERO               TO L0290-PRECISION
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X 
012525         MOVE L0290-OUTPUT-DATA  TO WRT-RTBL-MAT-XPRY-DUR
012525     END-IF.
012525*

           IF MIR-DPOS-TRM-DY-DUR = SPACE
               MOVE SPACE              TO WRT-DPOS-TRM-DY-DUR
           ELSE
               MOVE MIR-DPOS-TRM-DY-DUR TO L0280-INPUT-DATA
               MOVE LENGTH OF MIR-DPOS-TRM-DY-DUR TO L0280-INPUT-SIZE
               MOVE L0280-INPUT-SIZE   TO L0280-LENGTH
               MOVE ZERO               TO L0280-PRECISION
               PERFORM 0280-1000-NUMERIC-EDIT
                  THRU 0280-1000-NUMERIC-EDIT-X
               MOVE L0280-OUTPUT       TO L0290-INPUT-NUMBER
015543*        MOVE LENGTH MIR-DPOS-TRM-DY-DUR TO L0290-MAX-OUT-LEN
015543         MOVE LENGTH OF MIR-DPOS-TRM-DY-DUR TO L0290-MAX-OUT-LEN
               MOVE ZERO               TO L0290-PRECISION
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X 
               MOVE L0290-OUTPUT-DATA  TO WRT-DPOS-TRM-DY-DUR
           END-IF.
      *
           IF MIR-DPOS-TRM-MO-DUR = SPACE
               MOVE SPACE              TO WRT-DPOS-TRM-MO-DUR
           ELSE
               MOVE MIR-DPOS-TRM-MO-DUR TO L0280-INPUT-DATA
               MOVE LENGTH OF MIR-DPOS-TRM-MO-DUR TO L0280-INPUT-SIZE
               MOVE L0280-INPUT-SIZE   TO L0280-LENGTH
               MOVE ZERO               TO L0280-PRECISION
               PERFORM 0280-1000-NUMERIC-EDIT
                  THRU 0280-1000-NUMERIC-EDIT-X
               MOVE L0280-OUTPUT       TO L0290-INPUT-NUMBER
015543*        MOVE LENGTH MIR-DPOS-TRM-MO-DUR TO L0290-MAX-OUT-LEN
015543         MOVE LENGTH OF MIR-DPOS-TRM-MO-DUR TO L0290-MAX-OUT-LEN
               MOVE ZERO               TO L0290-PRECISION
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA  TO WRT-DPOS-TRM-MO-DUR
           END-IF.
      *
           IF MIR-RTBL-AGE = SPACE
               MOVE SPACE              TO WRT-RTBL-AGE
           ELSE
               MOVE MIR-RTBL-AGE       TO L0280-INPUT-DATA
               MOVE LENGTH OF MIR-RTBL-AGE TO L0280-INPUT-SIZE
               MOVE L0280-INPUT-SIZE   TO L0280-LENGTH
               MOVE ZERO               TO L0280-PRECISION
               PERFORM 0280-1000-NUMERIC-EDIT
                  THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT   TO WRT-RTBL-AGE-N
               ELSE
                   MOVE 'CS12140002'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-EDIT-ERROR TO TRUE
               END-IF
           END-IF.
      *
           MOVE MIR-RTBL-IDT-NUM       TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT                                    
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.                                 
020462     PERFORM 1640-7000-MIR-TO-INT                                         
020462        THRU 1640-7000-MIR-TO-INT-X.
      *
           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE TO L1660-INTERNAL-DATE
               PERFORM 1660-2000-CONVERT-INT-TO-INV
                  THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE TO WRT-RTBL-IDT-NUM-N
           ELSE
               MOVE 'CS12140001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.
      *
           MOVE HIGH-VALUES            TO WRT-ENDBR-KEY.
           MOVE ALL '9'                TO WRT-ENDBR-RTBL-IDT-NUM.
           MOVE 999                    TO WRT-ENDBR-RTBL-AGE-DUR.

       7000-BUILD-KEYS-X.
           EXIT.

      *

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

012525     MOVE SPACE                  TO MIR-RTBL-MAT-XPRY-DUR-G.
           MOVE SPACE                  TO MIR-DPOS-TRM-DY-DUR-G.
           MOVE SPACE                  TO MIR-DPOS-TRM-MO-DUR-G.
           MOVE SPACE                  TO MIR-LOC-GR-ID-G.
           MOVE SPACE                  TO MIR-RTBL-AGE-G.
           MOVE SPACE                  TO MIR-RTBL-DB-OPT-CD-G.
           MOVE SPACE                  TO MIR-RTBL-ID-G.
           MOVE SPACE                  TO MIR-RTBL-IDT-NUM-G.
           MOVE SPACE                  TO MIR-RTBL-JNT-LIFE-CD-G.
           MOVE SPACE                  TO MIR-RTBL-PAR-CD-G.
           MOVE SPACE                  TO MIR-RTBL-PNSN-QUALF-CD-G.
           MOVE SPACE                  TO MIR-RTBL-RT-TYP-CD-G.
           MOVE SPACE                  TO MIR-RTBL-SEX-CD-G.
           MOVE SPACE                  TO MIR-RTBL-SMKR-CD-G.
           MOVE SPACE                  TO MIR-RTBL-STBL-1-CD-G.
           MOVE SPACE                  TO MIR-RTBL-STBL-2-CD-G.
           MOVE SPACE                  TO MIR-RTBL-STBL-3-CD-G.
           MOVE SPACE                  TO MIR-RTBL-STBL-4-CD-G.
           MOVE SPACE                  TO MIR-RTBL-AGE-DUR-G.
           MOVE SPACE                  TO MIR-DV-END-RTBL-AGE-DUR-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      *
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

012525     MOVE RRT-RTBL-MAT-XPRY-DUR TO
012525                               MIR-RTBL-MAT-XPRY-DUR-T (WS-SUB).
           MOVE RRT-DPOS-TRM-DY-DUR  TO MIR-DPOS-TRM-DY-DUR-T (WS-SUB).
           MOVE RRT-DPOS-TRM-MO-DUR  TO MIR-DPOS-TRM-MO-DUR-T (WS-SUB).
           MOVE RRT-LOC-GR-ID        TO MIR-LOC-GR-ID-T (WS-SUB).
           MOVE RRT-RTBL-AGE         TO MIR-RTBL-AGE-T (WS-SUB).
           MOVE RRT-RTBL-DB-OPT-CD   TO MIR-RTBL-DB-OPT-CD-T (WS-SUB).
           MOVE RRT-RTBL-ID          TO MIR-RTBL-ID-T (WS-SUB).
           MOVE RRT-RTBL-JNT-LIFE-CD TO MIR-RTBL-JNT-LIFE-CD-T (WS-SUB).
           MOVE RRT-RTBL-PAR-CD      TO MIR-RTBL-PAR-CD-T (WS-SUB).
           MOVE RRT-RTBL-PNSN-QUALF-CD TO
                                     MIR-RTBL-PNSN-QUALF-CD-T (WS-SUB).
           MOVE RRT-RTBL-RT-TYP-CD   TO MIR-RTBL-RT-TYP-CD-T (WS-SUB).
           MOVE RRT-RTBL-SEX-CD      TO MIR-RTBL-SEX-CD-T (WS-SUB).
           MOVE RRT-RTBL-SMKR-CD     TO MIR-RTBL-SMKR-CD-T (WS-SUB).
           MOVE RRT-RTBL-STBL-1-CD   TO MIR-RTBL-STBL-1-CD-T (WS-SUB).
           MOVE RRT-RTBL-STBL-2-CD   TO MIR-RTBL-STBL-2-CD-T (WS-SUB).
           MOVE RRT-RTBL-STBL-3-CD   TO MIR-RTBL-STBL-3-CD-T (WS-SUB).
           MOVE RRT-RTBL-STBL-4-CD   TO MIR-RTBL-STBL-4-CD-T (WS-SUB).
020874*    MOVE RRT-RTBL-AGE-DUR     TO L0290-INPUT-NUMBER.
020874     MOVE RRT-RTBL-AGE-DUR     TO L0290-INPUT-V00.
015543*    MOVE LENGTH MIR-RTBL-AGE-DUR-T (1) TO L0290-MAX-OUT-LEN.
015543     MOVE LENGTH OF MIR-RTBL-AGE-DUR-T (1) TO L0290-MAX-OUT-LEN.
           MOVE ZERO                 TO L0290-PRECISION.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-RTBL-AGE-DUR-T (WS-SUB).
           MOVE L0290-OUTPUT-DATA TO MIR-DV-END-RTBL-AGE-DUR-T (WS-SUB).
           MOVE RRT-RTBL-IDT-NUM     TO WS-MIR-RTBL-IDT-NUM.
           MOVE RRT-RTBL-IDT-NUM     TO L1660-INVERTED-DATE.
           PERFORM 1660-3000-CONVERT-INV-TO-INT
              THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE  TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT                                    
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.                                 
020462     PERFORM 1640-8000-INTERNAL-TO-MIR                                    
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE  TO MIR-RTBL-IDT-NUM-T (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      *
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  WS-WORKING-STORAGE.
025970
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
025970     SET WS-MAX-LIST-LINES-DEFAULT   TO TRUE. 
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      *
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPS0290.
       COPY XCPL0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBRT.
      *
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM1214                      *
      *****************************************************************
