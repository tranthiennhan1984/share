      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7320.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7320                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE RETRIEVE FUNCTION     **
      **            FOR THE PDBG TABLE                               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020475**  6.4       DEATH BENEFIT GUARANTEES AND RIDERS              **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7320'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                     PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT         VALUE '7320'.

       01  WS-WORKING-STORAGE.
           05  WS-CONSTANT-FIELDS.
               10  WS-TWRK-KEY                 PIC X(04)
                                               VALUE '7320'.
           05  WS-WORK-FIELDS.
               10  WS-BUS-FCN-ID               PIC X(04).
                   88  WS-BUS-FCN-RETRIEVE     VALUE '7320'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRPH.
       COPY CCFWPH.
       COPY CCFWPDBG.
       COPY CCFRPDBG.

      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWL0290.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7320.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           MOVE MIR-BUS-FCN-ID    TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID     TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7320'         TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'       TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'       TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *-------------
       2000-RETRIEVE.
      *-------------

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.


           MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
           PERFORM PH-1000-READ-TWRK-TS
              THRU PH-1000-READ-TWRK-TS-X.
           IF  WPH-IO-NOT-FOUND
      *MSG: RECORD (@1) NOT FOUND
              MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (1)
              MOVE 'PH'               TO WGLOB-MSG-PARM (2)
              MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  PDBG-1000-READ
               THRU PDBG-1000-READ-X.

           IF  WPDBG-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WPDBG-KEY       TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'    TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.
      *
      *  MOVE RECORD INFORMATION TO THE MIR
      *
           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X.

       2000-RETRIEVE-X.
           EXIT.

      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES            TO WPDBG-KEY.
           MOVE MIR-PLAN-ID           TO WPDBG-PLAN-ID.
           MOVE MIR-LOC-GR-ID         TO WPDBG-LOC-GR-ID.
           MOVE MIR-PLAN-DBG-TYP-CD   TO WPDBG-PLAN-DBG-TYP-CD.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           INITIALIZE  MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9200-MOVE-RECORD-TO-MIR.
      *--------------------------

           MOVE RPDBG-PLAN-DBG-BASIC-CD   TO  MIR-PLAN-DBG-BASIC-CD.
           MOVE RPDBG-PLAN-DBG-LOCK-CD    TO  MIR-PLAN-DBG-LOCK-CD.
           MOVE RPDBG-PLAN-DBG-MAX-CD     TO  MIR-PLAN-DBG-MAX-CD.
           MOVE RPDBG-PLAN-DBG-LOAN-IND   TO  MIR-PLAN-DBG-LOAN-IND.
           MOVE RPDBG-PLAN-DBG-FCT-CD     TO  MIR-PLAN-DBG-FCT-CD.


           MOVE RPDBG-PLAN-DBG-LOCK-QTY   TO L0290-INPUT-V00.
           MOVE 0                         TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PLAN-DBG-LOCK-QTY
                                          TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA         TO MIR-PLAN-DBG-LOCK-QTY.


           MOVE RPDBG-PLAN-DBG-RESET-DUR  TO L0290-INPUT-V00.
           MOVE 0                         TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PLAN-DBG-RESET-DUR
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-PLAN-DBG-RESET-DUR.


           MOVE RPDBG-PLAN-DBG-GUAR-DUR  TO L0290-INPUT-V00.
           MOVE 0                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PLAN-DBG-GUAR-DUR
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-PLAN-DBG-GUAR-DUR.


           MOVE RPDBG-PLAN-DBG-MAX-AGE   TO L0290-INPUT-V00.
           MOVE 0                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PLAN-DBG-MAX-AGE
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-PLAN-DBG-MAX-AGE.


           MOVE RPDBG-PLAN-DBG-PREM-FCT  TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PLAN-DBG-PREM-FCT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-PLAN-DBG-PREM-FCT.


       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES              TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE  TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *-------------------------
       9990-INIT-WORKING-STORAGE.
      *-------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970*    INITIALIZE WS-WORK-FIELDS.
025970*    INITIALIZE WS-WORKING-STORAGE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     SET WS-TWRK-KEY-DEFAULT       TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY PH
                               '$VAR2' BY 'PH'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
025970 COPY XCPS8090.
       COPY XCPS0290.
       COPY XCPL0290.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPH.
       COPY CCPUPH.
       COPY CCPNPDBG.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM CSOM7320                        **
      *****************************************************************
