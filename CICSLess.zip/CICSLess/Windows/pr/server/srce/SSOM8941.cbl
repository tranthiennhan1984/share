      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM8941.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM8941                                         **
      **  REMARKS:  FBND - FUND BONUS DECLARATION CREATE             **
      **            THIS MODULE CREATES AN ENTRY IN THE FBND TABLE   **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
016016**  6.3       FUND BONUS (6.1.1E)                              **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019056**  6.3       REMOVE FND-BON-TYP-CD                            **
020462**  6.4       ISO DATE STANDARDIZATION                         **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM8941'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-PGM-WORK-AREA.
           05  WS-INVERTED-DATE             PIC 9(07).
           05  WS-INTERNAL-DATE.
               10  WS-INTERNAL-YYYY         PIC 9(04).
               10  FILLER                   PIC X(01).
               10  WS-INTERNAL-MM           PIC 9(02).
               10  FILLER                   PIC X(01).
               10  WS-INTERNAL-DD           PIC 9(02).
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-CREATE        VALUE '8941'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '8940'.
           05  WS-LAST-DATE-SW              PIC X(01).
               88  WS-LAST-DATE-OK          VALUE 'Y'.
               88  WS-LAST-DATE-NOT-OK      VALUE 'N'.
           05  WS-RH-PNTR-IND               PIC X(01).
               88  WS-RH-PNTR-EXIST         VALUE 'Y'.
               88  WS-RH-PNTR-NOT-EXIST     VALUE 'N'.

025970 01  WS-CONSTANT-AREA.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '8940'.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
018764*COPY XCWLPTR.

018763 COPY CCWWLOCK.

      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
018763*COPY SCFWFHBN.
018763*COPY SCFRFHBN.
      /
018763 COPY SCFWFBND.
018763 COPY SCFRFBND.
      /
       COPY SCFWFH.
       COPY SCFRFH.
      /
       COPY CCFWSCOM.
       COPY CCFRSCOM.
      /
       COPY CCFWRH.
       COPY CCFRRH.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
       COPY XCWLDTLK.
021930*COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
021930*COPY XCWL1680.
018763 COPY XCWL8090.

      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM8941.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------
026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

021930*    PERFORM  0290-1000-BUILD-PARM-INFO
021930*        THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           SET  MIR-RETRN-OK            TO TRUE.
           MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM 4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'SSOM8941'     TO WGLOB-MSG-PARM (2)
018763*             MOVE 'XS00000000'   TO WGLOB-MSG-REF-INFO
018763              MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *--------------------------
       3540-EXTERNAL-TO-INVERTED.
      *--------------------------

           PERFORM 1640-3000-EXTERNAL-TO-INT
              THRU 1640-3000-EXTERNAL-TO-INT-X.

           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE TO L1660-INTERNAL-DATE
               PERFORM 1660-2000-CONVERT-INT-TO-INV
                  THRU 1660-2000-CONVERT-INT-TO-INV-X
           ELSE
      *MSG:    ERROR CONVERTING INTERNAL DATE
               MOVE 'SS89410001'        TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR   TO TRUE
           END-IF.

       3540-EXTERNAL-TO-INVERTED-X.
           EXIT.
      /
      *--------------------
       4000-PROCESS-CREATE.
      *---------------------

           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM 4100-CREATE-EDITS
              THRU 4100-CREATE-EDITS-X.

           IF  WGLOB-GOOD-RETURN
               CONTINUE
           ELSE
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM 4600-CHECK-FOR-RH-PNTR
              THRU 4600-CHECK-FOR-RH-PNTR-X.

           IF  WGLOB-RETURN-ERROR
      *MSG: UNABLE TO CREATE, RATE HEADER DOES NOT EXIST
               MOVE 'SS89410002'        TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

018763*    MOVE MIR-FND-ID              TO WFHBN-FND-ID.
018763*    MOVE MIR-SBSDRY-CO-ID        TO WFHBN-SBSDRY-CO-ID.
018763*    MOVE WS-INVERTED-DATE        TO WFHBN-FND-BON-IDT-NUM.
018763     MOVE MIR-FND-ID              TO WFBND-FND-ID.
018763     MOVE MIR-SBSDRY-CO-ID        TO WFBND-SBSDRY-CO-ID.
018763     MOVE WS-INVERTED-DATE        TO WFBND-FND-BON-IDT-NUM.

018763*    PERFORM FHBN-1000-READ
018763*       THRU FHBN-1000-READ-X.
018763     PERFORM FBND-1000-READ
018763        THRU FBND-1000-READ-X.

018763*    IF  WFHBN-IO-OK
018763     IF  WFBND-IO-OK
      *MSG: FUND BONUS RECORD ALREADY EXISTS
               MOVE 'SS89410003'        TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR   TO TRUE
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

018763*    PERFORM 4500-CHECK-PREV-FHBN
018763*       THRU 4500-CHECK-PREV-FHBN-X.
018763     PERFORM 4500-CHECK-PREV-FBND
018763        THRU 4500-CHECK-PREV-FBND-X.

      * CREATE THE FHBN RECORD

           IF  WS-LAST-DATE-OK
018763*        MOVE WS-INVERTED-DATE TO WFHBN-FND-BON-IDT-NUM
018763         MOVE WS-INVERTED-DATE TO WFBND-FND-BON-IDT-NUM
018763*        PERFORM FHBN-1000-CREATE
018763*           THRU FHBN-1000-CREATE-X
018763*        PERFORM FHBN-1000-WRITE
018763*           THRU FHBN-1000-WRITE-X
018763         PERFORM FBND-1000-CREATE
018763            THRU FBND-1000-CREATE-X
018763         PERFORM FBND-1000-WRITE
018763            THRU FBND-1000-WRITE-X
018763         PERFORM  FBND-1000-READ-TWRK-TS
018763             THRU FBND-1000-READ-TWRK-TS-X
               PERFORM 9200-MOVE-RECORD-TO-SCREEN
                  THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *------------------
       4100-CREATE-EDITS.
      *------------------

           PERFORM 4130-EDIT-FUND
              THRU 4130-EDIT-FUND-X.

           PERFORM 4170-EDIT-SUB-CO
              THRU 4170-EDIT-SUB-CO-X.

           PERFORM 4190-EDIT-DATE
              THRU 4190-EDIT-DATE-X.

019056*    PERFORM 4195-EDIT-BONUS-TYPE
019056*       THRU 4195-EDIT-BONUS-TYPE-X.

       4100-CREATE-EDITS-X.
           EXIT.
      /
      *---------------
       4130-EDIT-FUND.
      *---------------

           IF  MIR-FND-ID = SPACE
      *MSG: FUND ID MUST BE ENTERED
               MOVE 'SS89410004'        TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR   TO TRUE
               GO TO 4130-EDIT-FUND-X
           END-IF.

           MOVE MIR-FND-ID              TO WFH-FND-ID.

           PERFORM FH-1000-READ
              THRU FH-1000-READ-X.

           IF  WFH-IO-NOT-FOUND
      *MGS: FUND NOT CREATED YET
               MOVE 'SS89410005'        TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR   TO TRUE
               GO TO 4130-EDIT-FUND-X
           END-IF.

       4130-EDIT-FUND-X.
           EXIT.
      /
      *-----------------
       4170-EDIT-SUB-CO.
      *-----------------

           MOVE MIR-SBSDRY-CO-ID        TO WSCOM-SBSDRY-CO-ID.

           PERFORM SCOM-2000-READ-INDEX
              THRU SCOM-2000-READ-INDEX-X.

           IF WSCOM-IO-NOT-FOUND
      *MGS: SUBSIDIARY COMPANY INVALID
               MOVE 'SS89410006'        TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR   TO TRUE
           END-IF.

       4170-EDIT-SUB-CO-X.
           EXIT.
      /
      *---------------
       4190-EDIT-DATE.
      *---------------

      * THE DATE BEING EDITED IN THIS PARAGRAPH IS THE DECLARATION DATE

           IF MIR-FND-BON-IDT-NUM = SPACE
      *MSG: FUND BONUS DECLARATION DATE MUST BE SPECIFIED
               MOVE 'SS89410007'        TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR   TO TRUE
               GO TO 4190-EDIT-DATE-X
           END-IF.

           MOVE MIR-FND-BON-IDT-NUM     TO L1640-EXTERNAL-DATE.

020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE TO L1660-INTERNAL-DATE
               MOVE L1640-INTERNAL-DATE TO WS-INTERNAL-DATE
               PERFORM 1660-2000-CONVERT-INT-TO-INV
                  THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE TO WS-INVERTED-DATE
           ELSE
      *MSG: FUND BONUS DECLARATION DATE INVALID, RE-ENTER
               MOVE 'SS89410008'        TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR   TO TRUE
           END-IF.

       4190-EDIT-DATE-X.
           EXIT.
      /
019056*---------------------
019056*4195-EDIT-BONUS-TYPE.
019056*---------------------
019056*
019056*    IF  MIR-FND-BON-TYP-VALID
019056*        CONTINUE
019056*    ELSE
019056*MSG: BONUS TYPE INVALID
019056*        MOVE 'SS89410009'        TO WGLOB-MSG-REF-INFO
019056*        PERFORM 0260-1000-GENERATE-MESSAGE
019056*           THRU 0260-1000-GENERATE-MESSAGE-X
019056*        SET WGLOB-RETURN-ERROR   TO TRUE
019056*    END-IF.
019056*
019056*4195-EDIT-BONUS-TYPE-X.
019056*    EXIT.
      /
      *---------------------
018763*4500-CHECK-PREV-FHBN.
018763 4500-CHECK-PREV-FBND.
      *---------------------
      * THIS PARAGRAPH READS THE PREVIOUS (MOST RECENT)
      * FUND BONUS RECORD (IF ONE EXISTS)

           SET WS-LAST-DATE-OK          TO TRUE.
018763*    MOVE LOW-VALUES              TO WFHBN-FND-BON-IDT-NUM.
018763*    MOVE WFHBN-KEY               TO WFHBN-ENDBR-KEY.
018763*    MOVE HIGH-VALUES             TO WFHBN-ENDBR-FND-BON-IDT-NUM.
018763     MOVE LOW-VALUES              TO WFBND-FND-BON-IDT-NUM.
018763     MOVE WFBND-KEY               TO WFBND-ENDBR-KEY.
018763     MOVE HIGH-VALUES             TO WFBND-ENDBR-FND-BON-IDT-NUM.

018763*    PERFORM FHBN-1000-BROWSE
018763*       THRU FHBN-1000-BROWSE-X.
018763     PERFORM FBND-1000-BROWSE
018763        THRU FBND-1000-BROWSE-X.

018763*    PERFORM FHBN-2000-READ-NEXT
018763*       THRU FHBN-2000-READ-NEXT-X.
018763     PERFORM FBND-2000-READ-NEXT
018763        THRU FBND-2000-READ-NEXT-X.

018763*    IF  WFHBN-IO-OK
018763     IF  WFBND-IO-OK
018763*        IF  WS-INVERTED-DATE > RFHBN-FND-BON-IDT-NUM
018763         IF  WS-INVERTED-DATE > RFBND-FND-BON-IDT-NUM
      *MSG:  BONUS DECLARATION DATE CANNOT BE EARLIER THAN
      *       LAST DECLARATION
                   MOVE 'SS89410010'    TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WS-LAST-DATE-NOT-OK TO TRUE
                   SET WGLOB-RETURN-ERROR  TO TRUE
               END-IF
           END-IF.

018763*    PERFORM FHBN-3000-END-BROWSE
018763*       THRU FHBN-3000-END-BROWSE-X.
018763     PERFORM FBND-3000-END-BROWSE
018763        THRU FBND-3000-END-BROWSE-X.

018763*4500-CHECK-PREV-FHBN-X.
018763 4500-CHECK-PREV-FBND-X.
           EXIT.
      /
      *-----------------------
       4600-CHECK-FOR-RH-PNTR.
      *-----------------------

           MOVE RFH-FND-BON-RH-ID       TO WRH-RH-ID.
           MOVE WS-INVERTED-DATE        TO WRH-RH-IDT-NUM.

           MOVE WRH-KEY                 TO WRH-ENDBR-KEY.
           MOVE HIGH-VALUES             TO WRH-ENDBR-RH-IDT-NUM.

           PERFORM RH-1000-BROWSE
              THRU RH-1000-BROWSE-X.

           IF  NOT WRH-IO-OK
               SET WGLOB-RETURN-ERROR   TO TRUE
               PERFORM RH-3000-END-BROWSE
                  THRU RH-3000-END-BROWSE-X
               GO TO 4600-CHECK-FOR-RH-PNTR-X
           END-IF.

           PERFORM RH-2000-READ-NEXT
              THRU RH-2000-READ-NEXT-X.

           IF  NOT WRH-IO-OK
               SET WGLOB-RETURN-ERROR   TO TRUE
               PERFORM RH-3000-END-BROWSE
                  THRU RH-3000-END-BROWSE-X
               GO TO 4600-CHECK-FOR-RH-PNTR-X
           END-IF.

           PERFORM RH-3000-END-BROWSE
              THRU RH-3000-END-BROWSE-X.

       4600-CHECK-FOR-RH-PNTR-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACE                   TO MIR-FND-BON-STAT-CD.
           MOVE SPACE                   TO MIR-FND-BON-EFF-DT.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

018763*    MOVE RFHBN-FND-BON-STAT-CD   TO MIR-FND-BON-STAT-CD.
018763*    MOVE RFHBN-FND-BON-EFF-DT    TO L1640-INTERNAL-DATE.
018763     MOVE RFBND-FND-BON-STAT-CD   TO MIR-FND-BON-STAT-CD.
018763     MOVE RFBND-FND-BON-EFF-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
018763     MOVE L1640-EXTERNAL-DATE     TO MIR-FND-BON-EFF-DT.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     SET WS-TWRK-KEY-DEFAULT     TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
018763 COPY CCPPTWTS REPLACING ==:VAR1:== BY FBND
018763                         '$VAR2' BY 'FBND'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
021930*COPY XCPS0290.
021930*COPY XCPL0290.
021930*
025970 COPY XCPS8090.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
      /
021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
018763*COPY SCPAFHBN.
018763*COPY SCPBFHBN.
018763*COPY SCPCFHBN.
018763*COPY SCPNFHBN.
018763 COPY SCPAFBND.
018763 COPY SCPBFBND.
018763 COPY SCPCFBND.
018763 COPY SCPNFBND.
018763 COPY SCPUFBND.
      /
       COPY SCPNFH.
      /
       COPY CCPNSCOM.
      /
       COPY CCPBRH.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM SSOM8941                     *
      ****************************************************************
