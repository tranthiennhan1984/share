      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. CSOM2724.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2724                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE IPRO TABLE                               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020463**  6.4       INVESTOR PROFILES                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2724'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                         PIC X(04).
               88  WS-BUS-FCN-LIST                   VALUE '2724'.
           05  WS-SUB                                PIC S9(04) BINARY.
025970*    05  WS-MAX-LIST-LINES                     PIC S9(04) BINARY
025970*                                              VALUE 100.
025970     05  WS-MAX-LIST-LINES                     PIC S9(04) BINARY.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWIPRO.
       COPY CCFRIPRO.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2724.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2724'       TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'     TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-LIST.
      *------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  IPRO-1000-BROWSE
               THRU IPRO-1000-BROWSE-X.

           IF WIPRO-IO-OK
               PERFORM  IPRO-2000-READ-NEXT
                   THRU IPRO-2000-READ-NEXT-X
           END-IF.
           
           IF NOT WIPRO-IO-OK 
           OR  WIPRO-IO-EOF
               PERFORM  IPRO-3000-END-BROWSE
                   THRU IPRO-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-LIST-X  
           END-IF.

           PERFORM  2010-BROWSE-IPRO
               THRU 2010-BROWSE-IPRO-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WIPRO-IO-EOF.

           IF  WIPRO-IO-EOF
               CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               MOVE RIPRO-PRFL-ID         TO MIR-PRFL-ID
           END-IF.

           PERFORM  IPRO-3000-END-BROWSE
               THRU IPRO-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.


      *-----------------
       2010-BROWSE-IPRO.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  IPRO-2000-READ-NEXT
               THRU IPRO-2000-READ-NEXT-X.

       2010-BROWSE-IPRO-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------
      *

           MOVE LOW-VALUES             TO WIPRO-KEY.

           MOVE MIR-PRFL-ID            TO WIPRO-PRFL-ID.

           MOVE HIGH-VALUES            TO WIPRO-ENDBR-KEY.

       7000-BUILD-KEYS-X.
           EXIT.

      /

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                 TO MIR-PRFL-ID-G.
           MOVE SPACES                 TO MIR-PRFL-XPRY-DT-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RIPRO-PRFL-ID           TO MIR-PRFL-ID-T (WS-SUB).

           MOVE RIPRO-PRFL-XPRY-DT      TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE     TO MIR-PRFL-XPRY-DT-T (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE          WS-WORKING-STORAGE.

           COMPUTE WS-MAX-LIST-LINES = LENGTH OF MIR-PRFL-ID-G
                                     / LENGTH OF MIR-PRFL-ID-T (1).
                                     
025970     MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBIPRO.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2724
      *****************************************************************
