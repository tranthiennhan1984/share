      *************************
       IDENTIFICATION DIVISION.
      *************************
      *
       PROGRAM-ID. SSOM0010.
      *
       COPY XCWWCRHT.
      *
      *****************************************************************
      **  MEMBER :  SSOM0010                                         **
      **  REMARKS:  FPXH: MAINTAIN FUND PLAN EXTENSION HEADER TABLE. **
      **            THIS MODULE PERFORMS THE TABLE MAINTENANCE       **
      **            FUNCTIONS FOR THE FUND PLAN EXTENSION HEADER.    **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP                                     **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
557973**  5.5       AMOUNT FIELD SIZING FOR INTL SUPPORT             **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010302**  5.6       REMOVE REFERENCES TO TSFR-FEE-PTR                **
011526**  5.6       ADD CALL TO AUDIT MODULE IF REQUESTED            **
012136**  5.6V      FREE LOOK AND INTEREST EARNINGS                  **
012141**  5.6V      PORTFOLIO EXPANSION                              **
014035**  5.6V      CODE CLEANUP & STANDARDIZATION                   **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL RECORD LOCKING                           **
014550**  6.2       REMOVE PLAN-OUT-ALLOC-CD                         **
016548**  6.2       CHANGE COMP TO BINARY                            **
016109**  6.3       FREE FUND TRANSFERS (6.1.2J)                     **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020475**  6.4       DEATH BENEFIT GUARANTEES AND RIDERS              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM0010'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      *

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'FPXH'.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-ID-VALID      VALUE
                   '1720' '1721' '1722' '1723' '1724' '1725'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '1720'.
               88  WS-BUS-FCN-CREATE        VALUE '1721'.
               88  WS-BUS-FCN-UPDATE        VALUE '1722'.
               88  WS-BUS-FCN-DELETE        VALUE '1723'.
               88  WS-BUS-FCN-LIST          VALUE '1724'.
               88  WS-BUS-FCN-KLONE         VALUE '1725'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '1720'.
           05  WS-DATA-EDITS                PIC X(01).
               88  WS-DATA-EDITS-OK         VALUE 'Y'.
               88  WS-DATA-EDITS-FAILED     VALUE 'N'.
016548*    05  WS-SUB                       PIC S9(04)  COMP.
016548     05  WS-SUB                       PIC S9(04)  BINARY.
           05  WS-SUB-99                    PIC 9(02)  VALUE ZEROS.
025970*    05  WS-MAX-LINES                 PIC 9(02)  VALUE 12.
025970*    05  WS-OK                        PIC X(01)  VALUE 'Y'.
025970*    05  WS-FAILED                    PIC X(01)  VALUE 'N'.
016109     05  WS-FREE-XFER-QTY-N           PIC 9(03).
016109     05  WS-FREE-XFER-QTY             REDEFINES
016109         WS-FREE-XFER-QTY-N.
016109         10  FILLER                   PIC X(01).
016109         10  WS-FREE-XFER-QTY-A       PIC X(02).
016109     05  WS-PIC92                     PIC 9(02).
016109     05  WS-PICX2                     REDEFINES
016109         WS-PIC92                     PIC X(02).

025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-TRANS-NAME-DEFAULT    VALUE 'FPXH'.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '1720'.
025970     05  WS-MAX-LINES                 PIC S9(04) BINARY.
025970         88  WS-MAX-LINES-DEFAULT     VALUE +12.
025970     05  WS-OK                        PIC X(01).
025970         88  WS-OK-DEFAULT            VALUE 'Y'.
025970     05  WS-FAILED                    PIC X(01).
025970         88  WS-FAILED-DEFAULT        VALUE 'N'.
      *
014035*COPY XCWWWKDT.
      /
       01  WS-FIELD-EDITS.
           05  WS-EDIT-FDRQD                PIC X(01).
               88   WS-VALID-FDRQD          VALUE 'S' 'R' 'N'.
           05  WS-EDIT-DIRECTION            PIC X(01).
               88   WS-VALID-DIRECTION      VALUE 'B' 'F'.
           05  WS-EDIT-ALLOC-IND            PIC X(01).
               88   WS-VALID-ALLOC-IND      VALUE 'P' 'A'.
           05  WS-EDIT-INT-CALC-IND         PIC X(01).
               88   WS-VALID-INT-CALC-IND   VALUE 'S' 'C'.
           05  WS-EDIT-NOTIFY-IND           PIC X(01).
               88   WS-VALID-NOTIFY-IND     VALUE 'W' 'C' 'N' 'B'.
           05  WS-EDIT-TSFR-FEE-TYPE        PIC X(01).
               88   WS-VALID-TSFR-FEE-TYPE  VALUE 'P' 'F' 'N'.
           05  WS-EDIT-MAX-P-SURR           PIC X(01).
               88   WS-VALID-MAX-P-SURR     VALUE 'N' 'P' 'M'.
           05  WS-EDIT-GUAR-TYPE            PIC X(01).
               88   WS-VALID-GUAR-TYPE      VALUE 'N' 'A' 'B' 'C'.
012136*    05  WS-EDIT-NTU-PROCESS-IND      PIC X(01).
012136*        88   WS-VALID-NTU-PROCESS-IND VALUE 'P' 'F' 'L'.
           05  WS-EDIT-FV-COMM              PIC X(01).
               88   WS-VALID-FV-COMM        VALUE 'Y' 'N'.
           05  WS-MIN-AUTO-TRMN-AMT-SW           PIC X(01)  VALUE ' '.
               88  WS-MIN-AUTO-TRMN-AMT-INVALID  VALUE 'Y'.
           05  WS-AUTO-TRMN-MO-DUR-SW            PIC X(01)  VALUE ' '.
               88  WS-AUTO-TRMN-MO-DUR-INVALID   VALUE 'Y'.
016109     05  WS-FREE-XFER-CD                   PIC X(01).
016109         88  WS-VALID-FREE-XFER-CD    VALUES 'C' 'F' 'N' 'D'.
016109         88  WS-FREE-XFER-CSV-BASIS        VALUE 'C'.
016109         88  WS-FREE-XFER-ACC-VAL-BASIS    VALUE 'F'.
016109         88  WS-FREE-XFER-NONE             VALUE 'N'.
016109         88  WS-FREE-XFER-DEP-PD-BASIS     VALUE 'D'.
016109     05  WS-FREE-XFER-PERI-CD              PIC X(01).
016109         88  WS-VALID-FREE-XFER-PERI  VALUES 'C' 'L' 'N' 'P'.
016109         88  WS-FREE-XFER-PERI-CAL-YR      VALUE 'C'.
016109         88  WS-FREE-XFER-PERI-LIFETIME    VALUE 'L'.
016109         88  WS-FREE-XFER-PERI-NONE        VALUE 'N'.
016109         88  WS-FREE-XFER-PERI-POL-YR      VALUE 'P'.
      /
       01  WS-DISPLAY-AND-NUM-FIELDS.
557973*    05  WS-NUM-AMT                   PIC S9(7)V99    COMP-3.
557973     05  WS-NUM-AMT                   PIC S9(13)V99    COMP-3.
           05  WS-NUM-PERCENT               PIC S9(18)      COMP-3.
           05  WS-NUM-PERCENT-R             REDEFINES WS-NUM-PERCENT.
               10  FILLER                   PIC X(6).
               10  WS-NUM-3V4               PIC S9(3)V9(4) COMP-3.
           05  WS-NUM-999                   PIC S9(03)     COMP-3.
           05  WS-DISPLAY-3                 PIC 9(3).
           05  WS-DISPLAY-3V4               PIC 9(3).9(4).
008455*    05  WS-DISPLAY-7V2               PIC 9(7).99.
      /
      *
014221 COPY CCWWLOCK.
       COPY XCWEBLCH.
      /
       COPY XCWL0280.
      /
008455 COPY XCWL0290.
008455/
014221 COPY XCWL8090.
014221/
       COPY CCFWPD.
       COPY CCFRPD.
014221/
014221 COPY CCFWPH.
014221 COPY CCFRPH.
      /
       COPY SCFWFX.
       COPY SCFRFX.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
012141 COPY XCWWFNDM.

       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      *
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY SCWM0010.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *
      ***************
       0000-MAINLINE.
      ***************
      *
026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.
      *
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.
      *
026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.
      *
       0000-MAINLINE-X.
           EXIT.
      /
      *****************************************************************
      *  PERFORM SECURITY PROCESSING AND INVOKE MODULES TO
      *      PROCESS USER REQUEST
      *****************************************************************
       2000-PROCESS-REQUEST.
      *
025970*    SET  MIR-RETRN-OK          TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.
      *
      *    VALIDATE KEY INPUT
      *
           PERFORM  7200-EDIT-FX-KEY
               THRU 7200-EDIT-FX-KEY-X.
      *
           IF WGLOB-MSG-ERROR-SW > 0
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.
      *
      *    PROCESS SCREEN FUNCTIONS
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X
      *
               WHEN WS-BUS-FCN-LIST
                    PERFORM  3500-PROCESS-LIST
                        THRU 3500-PROCESS-LIST-X
      *
               WHEN WS-BUS-FCN-CREATE
                    PERFORM  4000-PROCESS-CREATE
                        THRU 4000-PROCESS-CREATE-X
      *
               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X
      *
               WHEN WS-BUS-FCN-DELETE
                    PERFORM  6000-PROCESS-DELETE
                        THRU 6000-PROCESS-DELETE-X
      *
               WHEN WS-BUS-FCN-KLONE
                    PERFORM  6500-PROCESS-KLONE
                        THRU 6500-PROCESS-KLONE-X
      *
               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID  TO WGLOB-MSG-PARM (1)
                    MOVE 'SSOM0010'      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *****************************************************************
      *  INQUIRY PROCESSING: SETUP BROWSE KEYS, BEGIN BROWSE, AND
      *  LOAD DATA UNTIL END-OF-FILE OR SCREEN IS FULL.
      *****************************************************************
       3000-PROCESS-RETRIEVE.
      *
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
      *
014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID
014221     PERFORM PH-1000-READ-TWRK-TS
014221        THRU PH-1000-READ-TWRK-TS-X
014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221        MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (1)
014221        MOVE 'PH'               TO WGLOB-MSG-PARM (2)
014221        MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 3000-PROCESS-RETRIEVE-X
014221     END-IF.

           PERFORM  7100-BUILD-FX-KEY
               THRU 7100-BUILD-FX-KEY-X.
      *
           PERFORM  FX-1000-READ
               THRU FX-1000-READ-X.
           IF WFX-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WFX-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-RETRIEVE-X
557660     END-IF.
      *
      *    LOAD SCREEN DATA.
      *
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
      *
       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *****************************************************************
      *  BROWSE PROCESSING:
      *****************************************************************
       3500-PROCESS-LIST.
      *
           PERFORM  9150-BLANK-DATA-FIELDS-5
               THRU 9150-BLANK-DATA-FIELDS-5-X.
      *
           MOVE LOW-VALUES            TO WFX-KEY.
           MOVE HIGH-VALUES           TO WFX-ENDBR-KEY.
           PERFORM  7100-BUILD-FX-KEY
               THRU 7100-BUILD-FX-KEY-X.
      *
           PERFORM  FX-1000-BROWSE
               THRU FX-1000-BROWSE-X.
           IF WFX-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.
      *
           PERFORM  FX-2000-READ-NEXT
               THRU FX-2000-READ-NEXT-X.
           IF WFX-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  FX-3000-END-BROWSE
                   THRU FX-3000-END-BROWSE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.
      *
           IF MIR-PLAN-ID = SPACES
               MOVE RFX-PLAN-ID       TO MIR-PLAN-ID
           END-IF.
      *
           PERFORM  3520-DISPLAY-RECORDS
               THRU 3520-DISPLAY-RECORDS-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-LINES
               OR WFX-IO-EOF.
      *
           IF WFX-IO-EOF
               MOVE MIR-PLAN-ID-T (1) TO MIR-PLAN-ID
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE RFX-PLAN-ID       TO MIR-PLAN-ID
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
           PERFORM  FX-3000-END-BROWSE
               THRU FX-3000-END-BROWSE-X.
      *
       3500-PROCESS-LIST-X.
           EXIT.
      *
       3520-DISPLAY-RECORDS.
      *
           PERFORM  9250-MOVE-RECORD-TO-SCREEN-5
               THRU 9250-MOVE-RECORD-TO-SCREEN-5-X.
      *
           PERFORM  FX-2000-READ-NEXT
               THRU FX-2000-READ-NEXT-X.
      *
       3520-DISPLAY-RECORDS-X.
           EXIT.
      /
      *****************************************************************
      *  CREATE PROCESSING:
      *****************************************************************
       4000-PROCESS-CREATE.
      *
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
      *
      *    BUILD CONTROL FIELDS.
      *
           PERFORM  7100-BUILD-FX-KEY
               THRU 7100-BUILD-FX-KEY-X.
      *
      *    CHECK RECORD EXISTENCE
      *    MSG: RECORD (@1) NOT FOUND
      *
           PERFORM  FX-1000-READ
               THRU FX-1000-READ-X.
           IF WFX-IO-OK
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               MOVE WFX-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.
      *
           PERFORM  FX-1000-CREATE
               THRU FX-1000-CREATE-X.
      *
      *    READ PD WITH CURRENT PLAN CODE/RATE SCALE TO
      *    MAKE SURE PD RECORD EXISTS AND RPD-PLAN-INS-TYP-CD = F (FUND)
      *
           MOVE WFX-KEY               TO WPD-KEY.
           PERFORM  PD-1000-READ
               THRU PD-1000-READ-X.
           IF WPD-IO-OK
               IF RPD-PLAN-INS-TYP-CD = 'F'
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   MOVE 'SS00100025'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 4000-PROCESS-CREATE-X
557660         END-IF
           ELSE
               MOVE 'SS00100026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.
      *
      *    CREATE NEW RECORD - RECORD ALREADY INITIALIZED WHEN
      *    FX-1000-CREATE IS PERFORMED
      *
           PERFORM  FX-1000-WRITE
               THRU FX-1000-WRITE-X.

011526
011526     IF  WGLOB-AUDIT-REQUESTED
011526         PERFORM FX-1000-CALL-AUDIT
011526            THRU FX-1000-CALL-AUDIT-X
011526     END-IF.
      *
014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-1000-READ-TWRK-TS
014221        THRU PH-1000-READ-TWRK-TS-X.

      *
      *    MSG: RECORD CREATED - CONTINUE
      *
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
      *
       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *****************************************************************
      *  MAINTAIN PROCESSING:
      *      EDIT DATA FIELDS AND UPDATE RECORD.
      *      FIELDS WITH ERRORS ARE NOT UPDATED.
      *****************************************************************
       5000-PROCESS-UPDATE.
      *
014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-2000-UPDATE-TWRK-TS
014221        THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (1)
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  7100-BUILD-FX-KEY
               THRU 7100-BUILD-FX-KEY-X.

           PERFORM  FX-1000-READ-FOR-UPDATE
               THRU FX-1000-READ-FOR-UPDATE-X.

011526     IF  WFX-IO-OK
011526         IF  WGLOB-AUDIT-REQUESTED
011526             PERFORM FX-1000-CALL-AUDIT
011526                THRU FX-1000-CALL-AUDIT-X
011526         END-IF
011526     ELSE
      *
      *    MSG: LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS
      *
011526*    IF WFX-IO-NOT-FOUND
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WFX-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM PH-3000-UNLOCK
014221            THRU PH-3000-UNLOCK-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.
      *
           PERFORM  7300-DATA-EDITS
               THRU 7300-DATA-EDITS-X.
      *
           PERFORM  7400-CROSS-EDITS
               THRU 7400-CROSS-EDITS-X.
      *
           PERFORM  FX-2000-REWRITE
               THRU FX-2000-REWRITE-X.

014221     PERFORM  PH-2000-REWRITE
014221         THRU PH-2000-REWRITE-X.
011526
011526     IF  WGLOB-AUDIT-REQUESTED
011526         PERFORM FX-1000-CALL-AUDIT
011526            THRU FX-1000-CALL-AUDIT-X
011526     END-IF.
      *
014221     PERFORM  PH-1000-READ-TWRK-TS
014221         THRU PH-1000-READ-TWRK-TS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.
      *
      *    RESET COMMAND CODE (POP THE STACK IF REQUIRED IN FUTURE)
      *    MSG: MAINTENANCE COMPLETED - CONTINUE
      *     OR: RECORD UPDATED
      *
           IF WS-DATA-EDITS-OK
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
557660     END-IF.
      *
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *****************************************************************
      *  DELETE PROCESSING:
      *      REMOVE RECORD
      *****************************************************************
       6000-PROCESS-DELETE.
      *
014221     MOVE MIR-PLAN-ID           TO WPH-PLAN-ID.
014221     PERFORM PH-2000-UPDATE-TWRK-TS
014221        THRU PH-2000-UPDATE-TWRK-TS-X.

014221     IF  WPH-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (1)
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'PH'               TO WGLOB-MSG-PARM (01)
014221         MOVE WPH-PLAN-ID        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           PERFORM  7100-BUILD-FX-KEY
               THRU 7100-BUILD-FX-KEY-X.
           PERFORM  FX-1000-READ-FOR-UPDATE
               THRU FX-1000-READ-FOR-UPDATE-X.
      *
      *    MSG: RECORD (@1) LOST IN DELETE - CONTACT SYSTEMS
      *     OR: DELETE COMPLETED - CONTINUE
      *
           IF WFX-IO-NOT-FOUND
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WFX-KEY           TO WGLOB-MSG-PARM (1)
014221         PERFORM PH-3000-UNLOCK
014221            THRU PH-3000-UNLOCK-X
           ELSE
011526         IF  WGLOB-AUDIT-REQUESTED
011526             PERFORM FX-1000-CALL-AUDIT
011526                THRU FX-1000-CALL-AUDIT-X
011526         END-IF
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  FX-1000-DELETE
                   THRU FX-1000-DELETE-X
011526         IF  WGLOB-AUDIT-REQUESTED
011526             PERFORM FX-1000-CALL-AUDIT
011526                THRU FX-1000-CALL-AUDIT-X
011526         END-IF
014221         PERFORM  PH-2000-REWRITE
014221             THRU PH-2000-REWRITE-X
014221         PERFORM  PH-1000-READ-TWRK-TS
014221             THRU PH-1000-READ-TWRK-TS-X
557660     END-IF.
      *
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
      *
       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *****************************************************************
      *  KLONE PROCESSING:
      *****************************************************************
       6500-PROCESS-KLONE.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  7100-BUILD-FX-KEY
               THRU 7100-BUILD-FX-KEY-X.

           PERFORM  FX-1000-READ
               THRU FX-1000-READ-X.

           IF WFX-IO-OK
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           ELSE
      *    MSG : RECORD (@1) NOT FOUND
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WFX-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6500-PROCESS-KLONE-X
           END-IF.
      *
           MOVE MIR-PLAN-ID-2         TO WFX-PLAN-ID.

           PERFORM  FX-1000-READ
               THRU FX-1000-READ-X.

           IF WFX-IO-OK
      *    MSG:  RECORD (@1) ALREADY EXISTS
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               MOVE WFX-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6500-PROCESS-KLONE-X
           END-IF.

      *    READ PD WITH CURRENT PLAN CODE/RATE SCALE TO
      *    MAKE SURE PD RECORD EXISTS AND RPD-PLAN-INS-TYP-CD = F (FUND)

           MOVE WFX-KEY               TO WPD-KEY.
           PERFORM  PD-1000-READ
               THRU PD-1000-READ-X.
           IF WPD-IO-OK
               IF RPD-PLAN-INS-TYP-CD = 'F'
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   MOVE 'SS00100032'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 6500-PROCESS-KLONE-X
               END-IF
           ELSE
               MOVE 'SS00100033'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 6500-PROCESS-KLONE-X
           END-IF.

      *    READ RECORD TO BE KLONED

           MOVE MIR-PLAN-ID           TO WFX-PLAN-ID.

           PERFORM  FX-1000-READ
               THRU FX-1000-READ-X.

           IF WFX-IO-NOT-FOUND
      *    MSG:  READ (@1) LOST IN KLONE - CONTACT SYSTEMS
               MOVE WFX-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000143'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE MIR-PLAN-ID-2     TO WFX-PLAN-ID
               MOVE WFX-KEY           TO RFX-KEY
               PERFORM  FX-1000-WRITE
                   THRU FX-1000-WRITE-X
011526         IF  WGLOB-AUDIT-REQUESTED
011526             PERFORM FX-1000-CALL-AUDIT
011526                THRU FX-1000-CALL-AUDIT-X
011526         END-IF
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
      *    MSG:  RECORD KLONED
               MOVE 'SS00100024'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       6500-PROCESS-KLONE-X.
           EXIT.
      /
      *****************************************************************
      *  BUILD FPXH KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
      *****************************************************************
       7100-BUILD-FX-KEY.
      *
           MOVE MIR-PLAN-ID           TO WFX-PLAN-ID.
      *
       7100-BUILD-FX-KEY-X.
           EXIT.
      /
      *****************************************************************
      *  BUILD FPXH KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
      *****************************************************************
       7200-EDIT-FX-KEY.
      *
      *  FOR BROWSE NO EDIT IS NECESSARY
      *
           IF  WS-BUS-FCN-LIST
           OR  WS-BUS-FCN-KLONE
               GO TO 7200-EDIT-FX-KEY-X
557660     END-IF.
      *
      *  VERIFY THAT A VALID FX KEY HAS BEEN ENTERED
      *
           IF MIR-PLAN-ID = SPACES
      *        MESSAGE 'PLAN CODE MUST BE ENTERED'
               MOVE 'SS00100034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7200-EDIT-FX-KEY-X
557660     END-IF.
      *
           PERFORM  7100-BUILD-FX-KEY
               THRU 7100-BUILD-FX-KEY-X.
           PERFORM  FX-1000-READ
               THRU FX-1000-READ-X.
      *
           IF WS-BUS-FCN-CREATE
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               PERFORM  7220-EDIT-OTHER-PLAN-KEY
                   THRU 7220-EDIT-OTHER-PLAN-KEY-X
557660     END-IF.
      *
       7200-EDIT-FX-KEY-X.
           EXIT.
      /
       7210-EDIT-CREATE-PLAN-KEY.
      *
           IF WFX-IO-OK
      *        MESSAGE 'RECORD ALREADY EXISTS (@1)'
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               MOVE WFX-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       7210-EDIT-CREATE-PLAN-KEY-X.
           EXIT.
      /
       7220-EDIT-OTHER-PLAN-KEY.
      *
           IF WFX-IO-NOT-FOUND
      *        MESSAGE 'RECORD NOT FOUND @1'
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WFX-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.
      *
       7220-EDIT-OTHER-PLAN-KEY-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT DATA FIELDS ACCORDING TO THE DATA DICTIONARY
      *****************************************************************
       7300-DATA-EDITS.
      *
           MOVE WS-OK                 TO WS-DATA-EDITS.
      *
           PERFORM  7310-EDIT-SCREEN-1-FIELDS
               THRU 7310-EDIT-SCREEN-1-FIELDS-X.
           PERFORM  7330-EDIT-SCREEN-2-FIELDS
               THRU 7330-EDIT-SCREEN-2-FIELDS-X.
           PERFORM  7350-EDIT-SCREEN-3-FIELDS
               THRU 7350-EDIT-SCREEN-3-FIELDS-X.
           PERFORM  7370-EDIT-SCREEN-4-FIELDS
               THRU 7370-EDIT-SCREEN-4-FIELDS-X.
      *
       7300-DATA-EDITS-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT SCREEN 1 FIELDS
      *****************************************************************
       7310-EDIT-SCREEN-1-FIELDS.
      *
           PERFORM  7311-EDIT-MAX-NUM-FUND
               THRU 7311-EDIT-MAX-NUM-FUND-X.
      *
           PERFORM  7312-EDIT-REQUIRED-FUND
               THRU 7312-EDIT-REQUIRED-FUND-X.
      *
           PERFORM  7313-EDIT-AUTO-TERM-BENCHMK
               THRU 7313-EDIT-AUTO-TERM-BENCHMK-X.
      *
           PERFORM  7314-EDIT-AUTO-TERM-PERIOD
               THRU 7314-EDIT-AUTO-TERM-PERIOD-X.
      *
           PERFORM  7315-EDIT-PURCHASE-DIR
               THRU 7315-EDIT-PURCHASE-DIR-X.
      *
           PERFORM  7316-EDIT-TSFR-IN-DIR
               THRU 7316-EDIT-TSFR-IN-DIR-X.
      *
           PERFORM  7317-EDIT-TSFR-OUT-DIR
               THRU 7317-EDIT-TSFR-OUT-DIR-X.
      *
           PERFORM  7318-EDIT-WITHDRAW-DIR
               THRU 7318-EDIT-WITHDRAW-DIR-X.
      *
           PERFORM  7319-EDIT-MTHV-CV-DIR
               THRU 7319-EDIT-MTHV-CV-DIR-X.
      *
014550*    PERFORM  7320-EDIT-ALLOC-OUT-IND
014550*        THRU 7320-EDIT-ALLOC-OUT-IND-X.
014550*
           PERFORM  7321-EDIT-PEND-PAYT-INT
               THRU 7321-EDIT-PEND-PAYT-INT-X.
      *
           PERFORM  7322-EDIT-PEND-TSFR-INT
               THRU 7322-EDIT-PEND-TSFR-INT-X.
      *
           PERFORM  7323-EDIT-MIN-FOR-INT
               THRU 7323-EDIT-MIN-FOR-INT-X.
      *
           PERFORM  7324-EDIT-INT-CALC-IND
               THRU 7324-EDIT-INT-CALC-IND-X.
      *
       7310-EDIT-SCREEN-1-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 1 FIELD 1: MAXIMUM NUMBER OF FUNDS
      *****************************************************************
       7311-EDIT-MAX-NUM-FUND.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-PLAN-MAX-FND-QTY = SPACES
               MOVE RFX-PLAN-MAX-FND-QTY
                                      TO WS-DISPLAY-3
               MOVE WS-DISPLAY-3      TO MIR-PLAN-MAX-FND-QTY
               GO TO 7311-EDIT-MAX-NUM-FUND-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-PLAN-MAX-FND-QTY = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROES            TO MIR-PLAN-MAX-FND-QTY
557660     END-IF.
      *
      *  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE '3'                   TO L0280-LENGTH.
           MOVE MIR-PLAN-MAX-FND-QTY  TO L0280-INPUT-DATA.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'SS00100040'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
               GO TO 7311-EDIT-MAX-NUM-FUND-X
557660     END-IF.
      *
           MOVE L0280-OUTPUT          TO WS-NUM-999.
012141*    IF WS-NUM-999 > 15
012141     IF WS-NUM-999 > WFNDM-MAX-WFUND-NUM
               MOVE 'SS00100001'      TO WGLOB-MSG-REF-INFO
012141         MOVE WFNDM-MAX-WFUND-NUM
                                      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
           ELSE
           IF WS-NUM-999 < 1
               MOVE 'SS00100030'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
           ELSE
               MOVE WS-NUM-999        TO RFX-PLAN-MAX-FND-QTY
           END-IF
557660     END-IF.
      *
       7311-EDIT-MAX-NUM-FUND-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 1 FIELD 2: FUND RQUIRED INDICATOR
      *****************************************************************
       7312-EDIT-REQUIRED-FUND.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-PLAN-REQIR-FND-CD = SPACES
               MOVE RFX-PLAN-REQIR-FND-CD
                                      TO MIR-PLAN-REQIR-FND-CD
               GO TO 7312-EDIT-REQUIRED-FUND-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-PLAN-REQIR-FND-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-PLAN-REQIR-FND-CD
557660     END-IF.
      *
           MOVE MIR-PLAN-REQIR-FND-CD TO WS-EDIT-FDRQD.
           IF WS-VALID-FDRQD
               MOVE MIR-PLAN-REQIR-FND-CD
                                      TO RFX-PLAN-REQIR-FND-CD
           ELSE
               MOVE 'SS00100002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7312-EDIT-REQUIRED-FUND-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 1 FIELD 3: AUTOMATIC TERMINATION BENCHMARK
      *****************************************************************
       7313-EDIT-AUTO-TERM-BENCHMK.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-MIN-AUTO-TRMN-AMT = SPACES
008455*        MOVE RFX-MIN-AUTO-TRMN-AMT   TO WS-DISPLAY-7V2
008455*        MOVE WS-DISPLAY-7V2          TO MIR-MIN-AUTO-TRMN-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RFX-MIN-AUTO-TRMN-AMT
020874*                                     * 100
020874         MOVE RFX-MIN-AUTO-TRMN-AMT
020874                                TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-MIN-AUTO-TRMN-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-MIN-AUTO-TRMN-AMT
               GO TO 7313-EDIT-AUTO-TERM-BENCHMK-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-MIN-AUTO-TRMN-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-MIN-AUTO-TRMN-AMT
008455         MOVE ZERO              TO MIR-MIN-AUTO-TRMN-AMT
557660     END-IF.
      *
      *  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '2'                   TO L0280-PRECISION.
008455*    MOVE '7'                         TO L0280-LENGTH.
008455     MOVE LENGTH OF MIR-MIN-AUTO-TRMN-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
008455                            - 1.
           MOVE MIR-MIN-AUTO-TRMN-AMT TO L0280-INPUT-DATA.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-NUM-AMT
008455*        MOVE WS-NUM-AMT              TO WS-DISPLAY-7V2
008455*        MOVE WS-DISPLAY-7V2          TO MIR-MIN-AUTO-TRMN-AMT
               COMPUTE L0290-INPUT-NUMBER = L0280-OUTPUT
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-MIN-AUTO-TRMN-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-MIN-AUTO-TRMN-AMT
               MOVE WS-NUM-AMT        TO RFX-MIN-AUTO-TRMN-AMT
           ELSE
               SET WS-MIN-AUTO-TRMN-AMT-INVALID TO TRUE
               MOVE 'SS00100038'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7313-EDIT-AUTO-TERM-BENCHMK-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 1 FIELD 4: AUTOMATIC TERMINATION PERIOD
      *****************************************************************
       7314-EDIT-AUTO-TERM-PERIOD.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-AUTO-TRMN-MO-DUR = SPACES
020874*        MOVE RFX-AUTO-TRMN-MO-DUR
020874*                               TO WS-DISPLAY-3
020874*        MOVE WS-DISPLAY-3      TO MIR-AUTO-TRMN-MO-DUR
020874         MOVE RFX-AUTO-TRMN-MO-DUR  TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-AUTO-TRMN-MO-DUR
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-AUTO-TRMN-MO-DUR
               GO TO 7314-EDIT-AUTO-TERM-PERIOD-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-AUTO-TRMN-MO-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE '000'             TO MIR-AUTO-TRMN-MO-DUR
557660     END-IF.
      *
      *  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE '3'                   TO L0280-LENGTH.
           MOVE MIR-AUTO-TRMN-MO-DUR  TO L0280-INPUT-DATA.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
020874         MOVE L0280-OUTPUT      TO WS-NUM-999
020874         MOVE WS-NUM-999        TO RFX-AUTO-TRMN-MO-DUR
020874*        MOVE WS-NUM-999        TO WS-DISPLAY-3
020874*        MOVE WS-DISPLAY-3      TO MIR-AUTO-TRMN-MO-DUR
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-AUTO-TRMN-MO-DUR
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-AUTO-TRMN-MO-DUR
           ELSE
               SET WS-AUTO-TRMN-MO-DUR-INVALID TO TRUE
               MOVE 'SS00100041'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7314-EDIT-AUTO-TERM-PERIOD-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 1 FIELD 5: PURCHASE DIRECTION
      *****************************************************************
       7315-EDIT-PURCHASE-DIR.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-PLAN-PURCH-DIR-CD = SPACES
               MOVE RFX-PLAN-PURCH-DIR-CD
                                      TO MIR-PLAN-PURCH-DIR-CD
               GO TO 7315-EDIT-PURCHASE-DIR-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-PLAN-PURCH-DIR-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-PLAN-PURCH-DIR-CD
557660     END-IF.
      *
           MOVE MIR-PLAN-PURCH-DIR-CD TO WS-EDIT-DIRECTION.
           IF WS-VALID-DIRECTION
               MOVE MIR-PLAN-PURCH-DIR-CD
                                      TO RFX-PLAN-PURCH-DIR-CD
           ELSE
               MOVE 'SS00100054'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7315-EDIT-PURCHASE-DIR-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 1 FIELD 6: TRANSFER IN DIRECTION
      *****************************************************************
       7316-EDIT-TSFR-IN-DIR.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-XFER-IN-DIR-CD = SPACES
               MOVE RFX-XFER-IN-DIR-CD             TO MIR-XFER-IN-DIR-CD
               GO TO 7316-EDIT-TSFR-IN-DIR-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-XFER-IN-DIR-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-XFER-IN-DIR-CD
557660     END-IF.
      *
           MOVE MIR-XFER-IN-DIR-CD    TO WS-EDIT-DIRECTION.
           IF WS-VALID-DIRECTION
               MOVE MIR-XFER-IN-DIR-CD             TO RFX-XFER-IN-DIR-CD
           ELSE
               MOVE 'SS00100055'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7316-EDIT-TSFR-IN-DIR-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 1 FIELD 7: TRANSFER OUT DIRECTION
      *****************************************************************
       7317-EDIT-TSFR-OUT-DIR.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-XFER-OUT-DIR-CD = SPACES
               MOVE RFX-XFER-OUT-DIR-CD
                                      TO MIR-XFER-OUT-DIR-CD
               GO TO 7317-EDIT-TSFR-OUT-DIR-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-XFER-OUT-DIR-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-XFER-OUT-DIR-CD
557660     END-IF.
      *
           MOVE MIR-XFER-OUT-DIR-CD   TO WS-EDIT-DIRECTION.
           IF WS-VALID-DIRECTION
               MOVE MIR-XFER-OUT-DIR-CD
                                      TO RFX-XFER-OUT-DIR-CD
           ELSE
               MOVE 'SS00100056'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7317-EDIT-TSFR-OUT-DIR-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 1 FIELD 8: WITHDRAWAL DIRECTION
      *****************************************************************
       7318-EDIT-WITHDRAW-DIR.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-PLAN-WTHDR-DIR-CD = SPACES
               MOVE RFX-PLAN-WTHDR-DIR-CD
                                      TO MIR-PLAN-WTHDR-DIR-CD
               GO TO 7318-EDIT-WITHDRAW-DIR-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-PLAN-WTHDR-DIR-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-PLAN-WTHDR-DIR-CD
557660     END-IF.
      *
           MOVE MIR-PLAN-WTHDR-DIR-CD TO WS-EDIT-DIRECTION.
           IF WS-VALID-DIRECTION
               MOVE MIR-PLAN-WTHDR-DIR-CD
                                      TO RFX-PLAN-WTHDR-DIR-CD
           ELSE
               MOVE 'SS00100057'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7318-EDIT-WITHDRAW-DIR-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 1 FIELD 9: MONTHIVERSARY C.V. DIRECTION
      *****************************************************************
       7319-EDIT-MTHV-CV-DIR.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-MTHV-CV-DIR-CD = SPACES
               MOVE RFX-MTHV-CV-DIR-CD             TO MIR-MTHV-CV-DIR-CD
               GO TO 7319-EDIT-MTHV-CV-DIR-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-MTHV-CV-DIR-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-MTHV-CV-DIR-CD
557660     END-IF.
      *
           MOVE MIR-MTHV-CV-DIR-CD    TO WS-EDIT-DIRECTION.
           IF WS-VALID-DIRECTION
               MOVE MIR-MTHV-CV-DIR-CD             TO RFX-MTHV-CV-DIR-CD
           ELSE
               MOVE 'SS00100058'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7319-EDIT-MTHV-CV-DIR-X.
           EXIT.
      /
014550*****************************************************************
014550*  SCREEN 1 FIELD 10: ALLOCATION OUT INDICATOR
014550*****************************************************************
014550*7320-EDIT-ALLOC-OUT-IND.
014550*
014550*  DATA NOT ENTERED, REFRESH MIR AND EXIT
014550*
014550*    IF MIR-PLAN-OUT-ALLOC-CD = SPACES
014550*        MOVE RFX-PLAN-OUT-ALLOC-CD
014550*                               TO MIR-PLAN-OUT-ALLOC-CD
014550*        GO TO 7320-EDIT-ALLOC-OUT-IND-X
014550*    END-IF.
014550*
014550*  RESET FIELD TO BLANK VALUE
014550*
014550*    IF MIR-PLAN-OUT-ALLOC-CD = EBLCH-BLANK-FIELD-CHAR
014550*        MOVE SPACES            TO MIR-PLAN-OUT-ALLOC-CD
014550*    END-IF.
014550*
014550*    MOVE MIR-PLAN-OUT-ALLOC-CD TO WS-EDIT-ALLOC-IND.
014550*    IF WS-VALID-ALLOC-IND
014550*        MOVE MIR-PLAN-OUT-ALLOC-CD
014550*                               TO RFX-PLAN-OUT-ALLOC-CD
014550*    ELSE
014550*        MOVE 'SS00100004'      TO WGLOB-MSG-REF-INFO
014550*        PERFORM  0260-1000-GENERATE-MESSAGE
014550*            THRU 0260-1000-GENERATE-MESSAGE-X
014550*        MOVE WS-FAILED         TO WS-DATA-EDITS
014550*    END-IF.
014550*
014550*7320-EDIT-ALLOC-OUT-IND-X.
014550*    EXIT.
014550*
      *****************************************************************
      *  SCREEN 1 FIELD 11: PENDING PAYMENT INTEREST
      *****************************************************************
       7321-EDIT-PEND-PAYT-INT.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-PEND-PMT-INT-RT-ID = SPACES
               MOVE RFX-PEND-PMT-INT-RT-ID
                                      TO MIR-PEND-PMT-INT-RT-ID
               GO TO 7321-EDIT-PEND-PAYT-INT-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-PEND-PMT-INT-RT-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-PEND-PMT-INT-RT-ID
557660     END-IF.
      *
           MOVE MIR-PEND-PMT-INT-RT-ID TO RFX-PEND-PMT-INT-RT-ID.
      *
       7321-EDIT-PEND-PAYT-INT-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 1 FIELD 12: PENDING TRANSFER INTEREST
      *****************************************************************
       7322-EDIT-PEND-TSFR-INT.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-XFER-INT-RT-ID = SPACES
               MOVE RFX-XFER-INT-RT-ID             TO MIR-XFER-INT-RT-ID
               GO TO 7322-EDIT-PEND-TSFR-INT-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-XFER-INT-RT-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-XFER-INT-RT-ID
557660     END-IF.
      *
           MOVE MIR-XFER-INT-RT-ID    TO
                 RFX-XFER-INT-RT-ID.
      *
       7322-EDIT-PEND-TSFR-INT-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 1 FIELD 13: MINIMUM FOR INTEREST
      *****************************************************************
       7323-EDIT-MIN-FOR-INT.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-MIN-INT-ELIG-AMT = SPACES
008455*        MOVE RFX-MIN-INT-ELIG-AMT    TO WS-DISPLAY-7V2
008455*        MOVE WS-DISPLAY-7V2          TO MIR-MIN-INT-ELIG-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RFX-MIN-INT-ELIG-AMT
020874*                                     * 100
020874         MOVE RFX-MIN-INT-ELIG-AMT
020874                                TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-MIN-INT-ELIG-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-MIN-INT-ELIG-AMT
               GO TO 7323-EDIT-MIN-FOR-INT-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-MIN-INT-ELIG-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-MIN-INT-ELIG-AMT
008455         MOVE ZEROS             TO MIR-MIN-INT-ELIG-AMT
557660     END-IF.
      *
      *  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '2'                   TO L0280-PRECISION.
008455*    MOVE '7'                         TO L0280-LENGTH.
008455     MOVE LENGTH OF MIR-MIN-INT-ELIG-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
008455                            - 1.
           MOVE MIR-MIN-INT-ELIG-AMT  TO L0280-INPUT-DATA.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-NUM-AMT
008455*        MOVE WS-NUM-AMT              TO WS-DISPLAY-7V2
008455*        MOVE WS-DISPLAY-7V2          TO MIR-MIN-INT-ELIG-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-MIN-INT-ELIG-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-MIN-INT-ELIG-AMT
               MOVE WS-NUM-AMT        TO RFX-MIN-INT-ELIG-AMT
           ELSE
               MOVE 'SS00100042'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7323-EDIT-MIN-FOR-INT-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 1 FIELD 14: SIMPLE / COMPOUND INTEREST
      *****************************************************************
       7324-EDIT-INT-CALC-IND.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-INT-CALC-TYP-CD = SPACES
               MOVE RFX-INT-CALC-TYP-CD
                                      TO MIR-INT-CALC-TYP-CD
               GO TO 7324-EDIT-INT-CALC-IND-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-INT-CALC-TYP-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-INT-CALC-TYP-CD
557660     END-IF.
      *
           MOVE MIR-INT-CALC-TYP-CD   TO WS-EDIT-INT-CALC-IND.
           IF WS-VALID-INT-CALC-IND
               MOVE MIR-INT-CALC-TYP-CD
                                      TO RFX-INT-CALC-TYP-CD
           ELSE
               MOVE 'SS00100005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7324-EDIT-INT-CALC-IND-X.
           EXIT.
      /
      *****************************************************************
      *  EDIT SCREEN 2 FIELDS
      *****************************************************************
       7330-EDIT-SCREEN-2-FIELDS.
      *
           PERFORM  7331-EDIT-MIN-INITIAL-PAYT
               THRU 7331-EDIT-MIN-INITIAL-PAYT-X.
      *
           PERFORM  7332-EDIT-MIN-ADDL-PAYT
               THRU 7332-EDIT-MIN-ADDL-PAYT-X.
      *
           PERFORM  7333-EDIT-NOTIFICATION-IND
               THRU 7333-EDIT-NOTIFICATION-IND-X.
      *
           PERFORM  7334-EDIT-CONFIRM-NOTICE-MIN
               THRU 7334-EDIT-CONFIRM-NOTICE-MIN-X.
      *
           PERFORM  7335-EDIT-SET-UP-CHARGE
               THRU 7335-EDIT-SET-UP-CHARGE-X.
      *
      *
           PERFORM  7337-EDIT-TSFR-FEE-TYPE
               THRU 7337-EDIT-TSFR-FEE-TYPE-X.
      *
010302*    PERFORM  7338-EDIT-TSFR-FEE-PTR
010302*        THRU 7338-EDIT-TSFR-FEE-PTR-X.
      *
016109     PERFORM  7339-EDIT-FREE-XFER-CD
016109         THRU 7339-EDIT-FREE-XFER-CD-X.
016109
016109     PERFORM  7340-EDIT-FREE-XFER-QTY
016109         THRU 7340-EDIT-FREE-XFER-QTY-X.
016109
016109     PERFORM  7341-EDIT-FREE-XFER-PERI
016109         THRU 7341-EDIT-FREE-XFER-PERI-X.
016109
016109     IF WS-VALID-FREE-XFER-CD
016109         PERFORM  7342-EXTRA-EDITS
016109             THRU 7342-EXTRA-EDITS-X
016109     END-IF.

       7330-EDIT-SCREEN-2-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 2 FIELD 1: MINIMUM INITIAL PAYMENT
      *****************************************************************
       7331-EDIT-MIN-INITIAL-PAYT.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-MIN-INIT-DPOS-AMT = SPACES
008455*        MOVE RFX-MIN-INIT-DPOS-AMT   TO WS-DISPLAY-7V2
008455*        MOVE WS-DISPLAY-7V2          TO MIR-MIN-INIT-DPOS-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RFX-MIN-INIT-DPOS-AMT
020874*                                     * 100
020874         MOVE RFX-MIN-INIT-DPOS-AMT
020874                                TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-MIN-INIT-DPOS-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-MIN-INIT-DPOS-AMT
               GO TO 7331-EDIT-MIN-INITIAL-PAYT-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-MIN-INIT-DPOS-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-MIN-INIT-DPOS-AMT
008455         MOVE ZEROS             TO MIR-MIN-INIT-DPOS-AMT
557660     END-IF.
      *
      *  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '2'                   TO L0280-PRECISION.
008455*    MOVE '7'                         TO L0280-LENGTH.
008455     MOVE LENGTH OF MIR-MIN-INIT-DPOS-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
008455                            - 1.
           MOVE MIR-MIN-INIT-DPOS-AMT TO L0280-INPUT-DATA.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-NUM-AMT
008455*        MOVE WS-NUM-AMT              TO WS-DISPLAY-7V2
008455*        MOVE WS-DISPLAY-7V2          TO MIR-MIN-INIT-DPOS-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-MIN-INIT-DPOS-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-MIN-INIT-DPOS-AMT
               MOVE WS-NUM-AMT        TO RFX-MIN-INIT-DPOS-AMT
           ELSE
               MOVE 'SS00100043'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7331-EDIT-MIN-INITIAL-PAYT-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 2 FIELD 2: MINIMUM ADDITIONAL PAYMENT
      *****************************************************************
       7332-EDIT-MIN-ADDL-PAYT.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-MIN-ADDL-DPOS-AMT = SPACES
008455*        MOVE RFX-MIN-ADDL-DPOS-AMT   TO WS-DISPLAY-7V2
008455*        MOVE WS-DISPLAY-7V2          TO MIR-MIN-ADDL-DPOS-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RFX-MIN-ADDL-DPOS-AMT
020874*                                     * 100
020874         MOVE RFX-MIN-ADDL-DPOS-AMT
020874                                TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-MIN-ADDL-DPOS-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-MIN-ADDL-DPOS-AMT
               GO TO 7332-EDIT-MIN-ADDL-PAYT-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-MIN-ADDL-DPOS-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-MIN-ADDL-DPOS-AMT
008455         MOVE ZEROS             TO MIR-MIN-ADDL-DPOS-AMT
557660     END-IF.
      *
      *  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '2'                   TO L0280-PRECISION.
008455*    MOVE '7'                         TO L0280-LENGTH.
008455     MOVE LENGTH OF MIR-MIN-ADDL-DPOS-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
008455                            - 1.
           MOVE MIR-MIN-ADDL-DPOS-AMT TO L0280-INPUT-DATA.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-NUM-AMT
008455*        MOVE WS-NUM-AMT              TO WS-DISPLAY-7V2
008455*        MOVE WS-DISPLAY-7V2          TO MIR-MIN-ADDL-DPOS-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-MIN-ADDL-DPOS-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-MIN-ADDL-DPOS-AMT
               MOVE WS-NUM-AMT        TO RFX-MIN-ADDL-DPOS-AMT
           ELSE
               MOVE 'SS00100044'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7332-EDIT-MIN-ADDL-PAYT-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 2 FIELD 3: NOTIFICATION INDICATOR
      *****************************************************************
       7333-EDIT-NOTIFICATION-IND.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-PLAN-DPOS-NOTI-CD = SPACES
               MOVE RFX-PLAN-DPOS-NOTI-CD
                                      TO MIR-PLAN-DPOS-NOTI-CD
               GO TO 7333-EDIT-NOTIFICATION-IND-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-PLAN-DPOS-NOTI-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-PLAN-DPOS-NOTI-CD
557660     END-IF.
      *
           MOVE MIR-PLAN-DPOS-NOTI-CD TO WS-EDIT-NOTIFY-IND.
           IF WS-VALID-NOTIFY-IND
               MOVE MIR-PLAN-DPOS-NOTI-CD
                                      TO RFX-PLAN-DPOS-NOTI-CD
           ELSE
               MOVE 'SS00100028'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7333-EDIT-NOTIFICATION-IND-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 2 FIELD 4: CONFIRMATION NOTICE MINIMUM
      *****************************************************************
       7334-EDIT-CONFIRM-NOTICE-MIN.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-MIN-CNFRM-NOTI-AMT = SPACES
008455*        MOVE RFX-MIN-CNFRM-NOTI-AMT  TO WS-DISPLAY-7V2
008455*        MOVE WS-DISPLAY-7V2          TO MIR-MIN-CNFRM-NOTI-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RFX-MIN-CNFRM-NOTI-AMT
020874*                                     * 100
020874         MOVE RFX-MIN-CNFRM-NOTI-AMT
020874                                TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-MIN-CNFRM-NOTI-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-MIN-CNFRM-NOTI-AMT
               GO TO 7334-EDIT-CONFIRM-NOTICE-MIN-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-MIN-CNFRM-NOTI-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-MIN-CNFRM-NOTI-AMT
008455         MOVE ZEROS             TO MIR-MIN-CNFRM-NOTI-AMT
557660     END-IF.
      *
      *  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '2'                   TO L0280-PRECISION.
008455*    MOVE '7'                         TO L0280-LENGTH.
008455     MOVE LENGTH OF MIR-MIN-CNFRM-NOTI-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
008455                            - 1 .
           MOVE MIR-MIN-CNFRM-NOTI-AMT              TO L0280-INPUT-DATA.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-NUM-AMT
008455*        MOVE WS-NUM-AMT              TO WS-DISPLAY-7V2
008455*        MOVE WS-DISPLAY-7V2          TO MIR-MIN-CNFRM-NOTI-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-MIN-CNFRM-NOTI-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-MIN-CNFRM-NOTI-AMT
               MOVE WS-NUM-AMT        TO RFX-MIN-CNFRM-NOTI-AMT
           ELSE
               MOVE 'SS00100045'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7334-EDIT-CONFIRM-NOTICE-MIN-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 2 FIELD 5: SET UP CHARGE
      *****************************************************************
       7335-EDIT-SET-UP-CHARGE.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-SETUP-CHRG-AMT = SPACES
008455*        MOVE RFX-SETUP-CHRG-AMT      TO WS-DISPLAY-7V2
008455*        MOVE WS-DISPLAY-7V2          TO MIR-SETUP-CHRG-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RFX-SETUP-CHRG-AMT * 100
020874         MOVE RFX-SETUP-CHRG-AMT TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-SETUP-CHRG-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-SETUP-CHRG-AMT
               GO TO 7335-EDIT-SET-UP-CHARGE-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-SETUP-CHRG-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-SETUP-CHRG-AMT
008455         MOVE ZEROS             TO MIR-SETUP-CHRG-AMT
557660     END-IF.
      *
      *  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '2'                   TO L0280-PRECISION.
008455*    MOVE '7'                         TO L0280-LENGTH.
008455     MOVE LENGTH OF MIR-SETUP-CHRG-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
008455                            - 1.
           MOVE MIR-SETUP-CHRG-AMT    TO L0280-INPUT-DATA.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-NUM-AMT
008455*        MOVE WS-NUM-AMT              TO WS-DISPLAY-7V2
008455*        MOVE WS-DISPLAY-7V2          TO MIR-SETUP-CHRG-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-SETUP-CHRG-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-SETUP-CHRG-AMT
               MOVE WS-NUM-AMT        TO RFX-SETUP-CHRG-AMT
           ELSE
               MOVE 'SS00100046'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7335-EDIT-SET-UP-CHARGE-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 2 FIELD 7: TRANSFER FEE TYPE
      *****************************************************************
       7337-EDIT-TSFR-FEE-TYPE.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-XFER-FEE-TYP-CD = SPACES
               MOVE RFX-XFER-FEE-TYP-CD
                                      TO MIR-XFER-FEE-TYP-CD
               GO TO 7337-EDIT-TSFR-FEE-TYPE-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-XFER-FEE-TYP-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-XFER-FEE-TYP-CD
557660     END-IF.
      *
           MOVE MIR-XFER-FEE-TYP-CD   TO WS-EDIT-TSFR-FEE-TYPE.
           IF WS-VALID-TSFR-FEE-TYPE
               MOVE MIR-XFER-FEE-TYP-CD
                                      TO RFX-XFER-FEE-TYP-CD
           ELSE
               MOVE 'SS00100010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7337-EDIT-TSFR-FEE-TYPE-X.
           EXIT.
      /
010302*****************************************************************
010302*  SCREEN 2 FIELD 8: TRANSFER FEE POINTER
010302*****************************************************************
010302*7338-EDIT-TSFR-FEE-PTR.
010302*
010302*  DATA NOT ENTERED, REFRESH MIR AND EXIT
010302*
010302*    IF MIR-TFPTR = SPACES
010302*        MOVE RFX-XFER-FEE-RH-ID   TO MIR-TFPTR
010302*        GO TO 7338-EDIT-TSFR-FEE-PTR-X
010302*    END-IF.
010302*
010302*  RESET FIELD TO BLANK VALUE
010302*
010302*    IF MIR-TFPTR = EBLCH-BLANK-FIELD-CHAR
010302*        MOVE SPACES               TO MIR-TFPTR
010302*    END-IF.
010302*
010302*    MOVE MIR-TFPTR                TO RFX-XFER-FEE-RH-ID.
010302*
010302*7338-EDIT-TSFR-FEE-PTR-X.
010302*    EXIT.
010302*
016109*-----------------------
016109 7339-EDIT-FREE-XFER-CD.
016109*-----------------------
016109
016109     MOVE MIR-PLAN-FREE-XFER-CD TO WS-FREE-XFER-CD.
016109     IF NOT WS-VALID-FREE-XFER-CD
016109         MOVE 'SS00100065' TO WGLOB-MSG-REF-INFO
016109         PERFORM  0260-1000-GENERATE-MESSAGE
016109             THRU 0260-1000-GENERATE-MESSAGE-X
016109         SET MIR-RETRN-EDIT-ERROR TO TRUE
016109     ELSE
016109         MOVE MIR-PLAN-FREE-XFER-CD TO RFX-PLAN-FREE-XFER-CD
016109     END-IF.
016109
016109 7339-EDIT-FREE-XFER-CD-X.
016109     EXIT.
016109
016109*------------------------
016109 7340-EDIT-FREE-XFER-QTY.
016109*------------------------
016109*
016109* EDIT FREE TRANSFER QUANTITY
016109*
016109     IF MIR-PLAN-FREE-XFER-QTY = SPACES
016109         MOVE RFX-PLAN-FREE-XFER-QTY TO WS-PIC92
016109         MOVE WS-PICX2               TO MIR-PLAN-FREE-XFER-QTY
016109         GO TO 7340-EDIT-FREE-XFER-QTY-X
016109     END-IF.
016109
016109     MOVE 'N'               TO L0280-SIGN-IND.
016109     MOVE 2                 TO L0280-LENGTH.
016109     MOVE 0                 TO L0280-PRECISION.
016109     MOVE MIR-PLAN-FREE-XFER-QTY TO L0280-INPUT-DATA.
016109
016109     PERFORM  0280-1000-NUMERIC-EDIT
016109         THRU 0280-1000-NUMERIC-EDIT-X.
016109
016109     IF L0280-OK
016109         MOVE L0280-OUTPUT           TO RFX-PLAN-FREE-XFER-QTY
016109         MOVE RFX-PLAN-FREE-XFER-QTY TO WS-PIC92
016109         MOVE WS-PICX2               TO MIR-PLAN-FREE-XFER-QTY
016109     ELSE
016109* MSG: FREE TRANSFER # MUST BE NUMERIC - 99
016109         MOVE 'SS00100063'        TO WGLOB-MSG-REF-INFO
016109         PERFORM  0260-1000-GENERATE-MESSAGE
016109             THRU 0260-1000-GENERATE-MESSAGE-X
016109         SET MIR-RETRN-EDIT-ERROR TO TRUE
016109     END-IF.
016109
016109 7340-EDIT-FREE-XFER-QTY-X.
016109     EXIT.
016109
016109*-------------------------
016109 7341-EDIT-FREE-XFER-PERI.
016109*-------------------------
016109
016109     MOVE MIR-FREE-XFER-PERI-CD TO WS-FREE-XFER-PERI-CD.
016109     IF NOT WS-VALID-FREE-XFER-PERI
016109         MOVE 'SS00100066' TO WGLOB-MSG-REF-INFO
016109         PERFORM  0260-1000-GENERATE-MESSAGE
016109             THRU 0260-1000-GENERATE-MESSAGE-X
016109         SET MIR-RETRN-EDIT-ERROR TO TRUE
016109     ELSE
016109         MOVE MIR-FREE-XFER-PERI-CD TO RFX-FREE-XFER-PERI-CD
016109     END-IF.
016109
016109 7341-EDIT-FREE-XFER-PERI-X.
016109     EXIT.
016109
016109*-----------------
016109 7342-EXTRA-EDITS.
016109*-----------------
016109
016109     IF MIR-FREE-XFER-NONE
016109         GO TO 7342-EXTRA-EDITS-X
016109     END-IF.
016109
016109     IF MIR-PLAN-FREE-XFER-QTY = ZERO
016109* MSG: NUMBER OF FREE TRANSFERS MUST BE > ZERO
016109         MOVE 'SS00100062'        TO WGLOB-MSG-REF-INFO
016109         PERFORM  0260-1000-GENERATE-MESSAGE
016109             THRU 0260-1000-GENERATE-MESSAGE-X
016109         SET MIR-RETRN-EDIT-ERROR TO TRUE
016109     END-IF.
016109
016109     IF MIR-FREE-XFER-PERI-NONE
016109* MSG: FREE TRANSFER PERIOD MUST BE C, L, OR P
016109         MOVE 'SS00100064'        TO WGLOB-MSG-REF-INFO
016109         PERFORM  0260-1000-GENERATE-MESSAGE
016109             THRU 0260-1000-GENERATE-MESSAGE-X
016109         SET MIR-RETRN-EDIT-ERROR TO TRUE
016109     END-IF.
016109
016109 7342-EXTRA-EDITS-X.
016109     EXIT.

      *****************************************************************
      *  EDIT SCREEN 3 FIELDS
      *****************************************************************
       7350-EDIT-SCREEN-3-FIELDS.
      *
           PERFORM  7351-EDIT-MAX-PARTIAL-IND
               THRU 7351-EDIT-MAX-PARTIAL-IND-X.
      *
           PERFORM  7352-EDIT-MAX-PARTIAL-SURR
               THRU 7352-EDIT-MAX-PARTIAL-SURR-X.
      *
           PERFORM  7353-EDIT-MAX-PARTIAL-MONTHS
               THRU 7353-EDIT-MAX-PARTIAL-MONTHS-X.
      *
           PERFORM  7354-EDIT-MIN-SURR-AMT
               THRU 7354-EDIT-MIN-SURR-AMT-X.
      *
           PERFORM  7355-EDIT-GUAR-VALUE-TYPE
               THRU 7355-EDIT-GUAR-VALUE-TYPE-X.
      *
           PERFORM  7356-EDIT-GUAR-DB-PERCENT
               THRU 7356-EDIT-GUAR-DB-PERCENT-X.
      *
           PERFORM  7357-EDIT-GUAR-MAT-PERCENT
               THRU 7357-EDIT-GUAR-MAT-PERCENT-X.
      *
           PERFORM  7358-EDIT-GUAR-SURR-PERCENT
               THRU 7358-EDIT-GUAR-SURR-PERCENT-X.
      *
012136*    PERFORM  7359-EDIT-NTU-PROCESS-IND
012136*        THRU 7359-EDIT-NTU-PROCESS-IND-X.
      *
       7350-EDIT-SCREEN-3-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 3 FIELD 1: MAXIMUM PART SURR INDICATOR
      *****************************************************************
       7351-EDIT-MAX-PARTIAL-IND.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-PLAN-MAX-PSUR-CD = SPACES
               MOVE RFX-PLAN-MAX-PSUR-CD
                                      TO MIR-PLAN-MAX-PSUR-CD
               MOVE RFX-PLAN-MAX-PSUR-CD
                                      TO WS-EDIT-MAX-P-SURR
               GO TO 7351-EDIT-MAX-PARTIAL-IND-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-PLAN-MAX-PSUR-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-PLAN-MAX-PSUR-CD
557660     END-IF.
      *
           MOVE MIR-PLAN-MAX-PSUR-CD  TO WS-EDIT-MAX-P-SURR
           IF WS-VALID-MAX-P-SURR
               MOVE MIR-PLAN-MAX-PSUR-CD
                                      TO RFX-PLAN-MAX-PSUR-CD
           ELSE
               MOVE 'SS00100011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7351-EDIT-MAX-PARTIAL-IND-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 3 FIELD 2: MAXIMUM PART SURR PER PERIOD
      *****************************************************************
       7352-EDIT-MAX-PARTIAL-SURR.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-PLAN-MAX-PSUR-QTY = SPACES
               MOVE RFX-PLAN-MAX-PSUR-QTY
                                      TO WS-DISPLAY-3
               MOVE WS-DISPLAY-3      TO MIR-PLAN-MAX-PSUR-QTY
               GO TO 7352-EDIT-MAX-PARTIAL-SURR-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-PLAN-MAX-PSUR-QTY = EBLCH-BLANK-FIELD-CHAR
               MOVE '000'             TO MIR-PLAN-MAX-PSUR-QTY
557660     END-IF.
      *
      *  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE '3'                   TO L0280-LENGTH.
           MOVE MIR-PLAN-MAX-PSUR-QTY TO L0280-INPUT-DATA.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-999
               MOVE WS-NUM-999        TO
                     RFX-PLAN-MAX-PSUR-QTY
               MOVE WS-NUM-999        TO WS-DISPLAY-3
               MOVE WS-DISPLAY-3      TO MIR-PLAN-MAX-PSUR-QTY
           ELSE
               MOVE 'SS00100047'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7352-EDIT-MAX-PARTIAL-SURR-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 3 FIELD 3: MAXIMUM PART SURR PERIOD
      *****************************************************************
       7353-EDIT-MAX-PARTIAL-MONTHS.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-MAX-PSUR-MO-DUR = SPACES
020874*        MOVE RFX-MAX-PSUR-MO-DUR
020874*                               TO WS-DISPLAY-3
020874*        MOVE WS-DISPLAY-3      TO MIR-MAX-PSUR-MO-DUR
020874         MOVE RFX-MAX-PSUR-MO-DUR   TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-PSUR-MO-DUR
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-MAX-PSUR-MO-DUR
               GO TO 7353-EDIT-MAX-PARTIAL-MONTHS-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-MAX-PSUR-MO-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE '000'             TO MIR-MAX-PSUR-MO-DUR
557660     END-IF.
      *
      *  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE '3'                   TO L0280-LENGTH.
           MOVE MIR-MAX-PSUR-MO-DUR   TO L0280-INPUT-DATA.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-999
               MOVE WS-NUM-999        TO RFX-MAX-PSUR-MO-DUR
020874*        MOVE WS-NUM-999        TO WS-DISPLAY-3
020874*        MOVE WS-DISPLAY-3      TO MIR-MAX-PSUR-MO-DUR
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAX-PSUR-MO-DUR
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-MAX-PSUR-MO-DUR
           ELSE
               MOVE 'SS00100048'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7353-EDIT-MAX-PARTIAL-MONTHS-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 3 FIELD 4: MIMINUM PART SURR AMOUNT
      *****************************************************************
       7354-EDIT-MIN-SURR-AMT.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-PLAN-MIN-PSUR-AMT = SPACES
008455*        MOVE RFX-PLAN-MIN-PSUR-AMT   TO WS-DISPLAY-7V2
008455*        MOVE WS-DISPLAY-7V2          TO MIR-PLAN-MIN-PSUR-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RFX-PLAN-MIN-PSUR-AMT
020874*                                     * 100
020874         MOVE RFX-PLAN-MIN-PSUR-AMT
020874                                TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PLAN-MIN-PSUR-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PLAN-MIN-PSUR-AMT
               GO TO 7354-EDIT-MIN-SURR-AMT-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-PLAN-MIN-PSUR-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-PLAN-MIN-PSUR-AMT
008455         MOVE ZEROS             TO MIR-PLAN-MIN-PSUR-AMT
557660     END-IF.
      *
      *  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '2'                   TO L0280-PRECISION.
008455*    MOVE '7'                         TO L0280-LENGTH.
008455     MOVE LENGTH OF MIR-PLAN-MIN-PSUR-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
008455                            - 1.
           MOVE MIR-PLAN-MIN-PSUR-AMT TO L0280-INPUT-DATA.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO WS-NUM-AMT
008455*        MOVE WS-NUM-AMT              TO WS-DISPLAY-7V2
008455*        MOVE WS-DISPLAY-7V2          TO MIR-PLAN-MIN-PSUR-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-PLAN-MIN-PSUR-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-PLAN-MIN-PSUR-AMT
               MOVE WS-NUM-AMT        TO RFX-PLAN-MIN-PSUR-AMT
           ELSE
               MOVE 'SS00100049'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7354-EDIT-MIN-SURR-AMT-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 3 FIELD 5: GUARANTEED VALUE TYPE
      *****************************************************************
       7355-EDIT-GUAR-VALUE-TYPE.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-GUAR-VALU-CALC-CD = SPACES
               MOVE RFX-GUAR-VALU-CALC-CD
                                      TO MIR-GUAR-VALU-CALC-CD
               GO TO 7355-EDIT-GUAR-VALUE-TYPE-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-GUAR-VALU-CALC-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-GUAR-VALU-CALC-CD
557660     END-IF.
      *
           MOVE MIR-GUAR-VALU-CALC-CD TO WS-EDIT-GUAR-TYPE.
           IF WS-VALID-GUAR-TYPE
               MOVE MIR-GUAR-VALU-CALC-CD
                                      TO RFX-GUAR-VALU-CALC-CD
           ELSE
               MOVE 'SS00100012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7355-EDIT-GUAR-VALUE-TYPE-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 3 FIELD 6: GUARANTEED DEATH BENEFIT %
      *****************************************************************
       7356-EDIT-GUAR-DB-PERCENT.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
020475*    IF MIR-DB-GUAR-VALU-PCT = SPACES
020475     IF MIR-DTH-GUAR-VALU-PCT = SPACES
020874*        MOVE RFX-DB-GUAR-VALU-PCT
020874*                               TO WS-DISPLAY-3V4
020874*        MOVE WS-DISPLAY-3V4    TO MIR-DB-GUAR-VALU-PCT
020475*        MOVE RFX-DB-GUAR-VALU-PCT  TO L0290-INPUT-V04
020475         MOVE RFX-DTH-GUAR-VALU-PCT TO L0290-INPUT-V04
020874         MOVE 4                     TO L0290-PRECISION
020475*        MOVE LENGTH OF MIR-DB-GUAR-VALU-PCT
020475         MOVE LENGTH OF MIR-DTH-GUAR-VALU-PCT
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020475*        MOVE L0290-OUTPUT-DATA     TO MIR-DB-GUAR-VALU-PCT
020475         MOVE L0290-OUTPUT-DATA     TO MIR-DTH-GUAR-VALU-PCT
               GO TO 7356-EDIT-GUAR-DB-PERCENT-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
020475*    IF MIR-DB-GUAR-VALU-PCT = EBLCH-BLANK-FIELD-CHAR
020475*       MOVE '000.0000'        TO MIR-DB-GUAR-VALU-PCT
020475     IF MIR-DTH-GUAR-VALU-PCT = EBLCH-BLANK-FIELD-CHAR
020475        MOVE '000.0000'        TO MIR-DTH-GUAR-VALU-PCT
557660     END-IF.
      *
      *  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '4'                   TO L0280-PRECISION.
           MOVE '3'                   TO L0280-LENGTH.
020475*    MOVE MIR-DB-GUAR-VALU-PCT  TO L0280-INPUT-DATA.
020475     MOVE MIR-DTH-GUAR-VALU-PCT TO L0280-INPUT-DATA.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-PERCENT
           ELSE
               MOVE 'SS00100050'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
               GO TO 7356-EDIT-GUAR-DB-PERCENT-X
557660     END-IF.
      *
           IF WS-NUM-3V4 > 100.0000
               MOVE 'SS00100059'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
           ELSE
020874*        MOVE WS-NUM-3V4        TO WS-DISPLAY-3V4
020874*        MOVE WS-DISPLAY-3V4    TO MIR-DB-GUAR-VALU-PCT
020475*        MOVE WS-NUM-3V4        TO RFX-DB-GUAR-VALU-PCT
020475         MOVE WS-NUM-3V4        TO RFX-DTH-GUAR-VALU-PCT
020874         MOVE WS-NUM-3V4            TO L0290-INPUT-V04
020874         MOVE 4                     TO L0290-PRECISION
020475*        MOVE LENGTH OF MIR-DB-GUAR-VALU-PCT
020475         MOVE LENGTH OF MIR-DTH-GUAR-VALU-PCT
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020475*        MOVE L0290-OUTPUT-DATA     TO MIR-DB-GUAR-VALU-PCT
020475         MOVE L0290-OUTPUT-DATA     TO MIR-DTH-GUAR-VALU-PCT
557660     END-IF.
      *
       7356-EDIT-GUAR-DB-PERCENT-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 3 FIELD 7: GUARANTEED MATURITY %
      *****************************************************************
       7357-EDIT-GUAR-MAT-PERCENT.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-MAT-GUAR-VALU-PCT = SPACES
020874*        MOVE RFX-MAT-GUAR-VALU-PCT
020874*                               TO WS-DISPLAY-3V4
020874*        MOVE WS-DISPLAY-3V4    TO MIR-MAT-GUAR-VALU-PCT
020874         MOVE RFX-MAT-GUAR-VALU-PCT TO L0290-INPUT-V04
020874         MOVE 4                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAT-GUAR-VALU-PCT
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-MAT-GUAR-VALU-PCT
               GO TO 7357-EDIT-GUAR-MAT-PERCENT-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-MAT-GUAR-VALU-PCT = EBLCH-BLANK-FIELD-CHAR
               MOVE '000.0000'        TO MIR-MAT-GUAR-VALU-PCT
557660     END-IF.
      *
      *  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '4'                   TO L0280-PRECISION.
           MOVE '3'                   TO L0280-LENGTH.
           MOVE MIR-MAT-GUAR-VALU-PCT TO L0280-INPUT-DATA.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-PERCENT
           ELSE
               MOVE 'SS00100051'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
               GO TO 7357-EDIT-GUAR-MAT-PERCENT-X
557660     END-IF.
      *
           IF WS-NUM-3V4 > 100.00
               MOVE 'SS00100060'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
           ELSE
020874*        MOVE WS-NUM-3V4        TO WS-DISPLAY-3V4
020874*        MOVE WS-DISPLAY-3V4    TO MIR-MAT-GUAR-VALU-PCT
020874         MOVE WS-NUM-3V4            TO L0290-INPUT-V04
020874         MOVE 4                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-MAT-GUAR-VALU-PCT
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-MAT-GUAR-VALU-PCT
               MOVE WS-NUM-3V4        TO RFX-MAT-GUAR-VALU-PCT
557660     END-IF.
      *
       7357-EDIT-GUAR-MAT-PERCENT-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 3 FIELD 8: GUARANTEED SURRENDER %
      *****************************************************************
       7358-EDIT-GUAR-SURR-PERCENT.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-SURR-GUAR-VALU-PCT = SPACES
020874*        MOVE RFX-SURR-GUAR-VALU-PCT
020874*                               TO WS-DISPLAY-3V4
020874*        MOVE WS-DISPLAY-3V4    TO MIR-SURR-GUAR-VALU-PCT
020874         MOVE RFX-SURR-GUAR-VALU-PCT TO L0290-INPUT-V04
020874         MOVE 4                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-SURR-GUAR-VALU-PCT
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-SURR-GUAR-VALU-PCT
               GO TO 7358-EDIT-GUAR-SURR-PERCENT-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-SURR-GUAR-VALU-PCT = EBLCH-BLANK-FIELD-CHAR
               MOVE '000.0000'        TO MIR-SURR-GUAR-VALU-PCT
557660     END-IF.
      *
      *  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '4'                   TO L0280-PRECISION.
           MOVE '3'                   TO L0280-LENGTH.
           MOVE MIR-SURR-GUAR-VALU-PCT              TO L0280-INPUT-DATA.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-PERCENT
           ELSE
               MOVE 'SS00100052'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
               GO TO 7358-EDIT-GUAR-SURR-PERCENT-X
557660     END-IF.
      *
           IF WS-NUM-3V4 > 100.0000
               MOVE 'SS00100061'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
           ELSE
020874*        MOVE WS-NUM-3V4        TO WS-DISPLAY-3V4
020874*        MOVE WS-DISPLAY-3V4    TO MIR-SURR-GUAR-VALU-PCT
020874         MOVE WS-NUM-3V4            TO L0290-INPUT-V04
020874         MOVE 4                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-SURR-GUAR-VALU-PCT
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-SURR-GUAR-VALU-PCT
               MOVE WS-NUM-3V4            TO RFX-SURR-GUAR-VALU-PCT
557660     END-IF.
      *
       7358-EDIT-GUAR-SURR-PERCENT-X.
           EXIT.
      /
012136*****************************************************************
012136*  SCREEN 3 FIELD 9: NOT TAKEN PROCESSING INDICATOR
012136*****************************************************************
012136*7359-EDIT-NTU-PROCESS-IND.
012136*
012136*  DATA NOT ENTERED, REFRESH MIR AND EXIT
012136*
012136*    IF MIR-NTUPR = SPACES
012136*        MOVE RFX-NOT-TAKEN-PRCES-CD TO MIR-NTUPR
012136*        GO TO 7359-EDIT-NTU-PROCESS-IND-X
012136*    END-IF.
012136*
012136*  RESET FIELD TO BLANK VALUE
012136*
012136*    IF MIR-NTUPR = EBLCH-BLANK-FIELD-CHAR
012136*        MOVE SPACES                 TO MIR-NTUPR
012136*    END-IF.
012136*
012136*    MOVE MIR-NTUPR                  TO WS-EDIT-NTU-PROCESS-IND
012136*    IF WS-VALID-NTU-PROCESS-IND
012136*        MOVE MIR-NTUPR              TO RFX-NOT-TAKEN-PRCES-CD
012136*    ELSE
012136*        MOVE -1                     TO MIR-NTUPR-L
012136*        MOVE TATRB-DATA-ERROR       TO MIR-NTUPR-A
012136*        MOVE 'SS00100013'           TO WGLOB-MSG-REF-INFO
012136*        PERFORM  0260-1000-GENERATE-MESSAGE
012136*            THRU 0260-1000-GENERATE-MESSAGE-X
012136*        MOVE WS-FAILED              TO WS-DATA-EDITS
012136*    END-IF.
012136*
012136*7359-EDIT-NTU-PROCESS-IND-X.
012136*    EXIT.
012136*/
      *****************************************************************
      *  EDIT SCREEN 4 FIELDS
      *****************************************************************
       7370-EDIT-SCREEN-4-FIELDS.
      *
           PERFORM  7371-EDIT-COMM-PTR
               THRU 7371-EDIT-COMM-PTR-X.
      *
           PERFORM  7372-EDIT-FV-COMM-CONTROL
               THRU 7372-EDIT-FV-COMM-CONTROL-X.
      *
           PERFORM  7373-EDIT-FV-COMM-PTR
               THRU 7373-EDIT-FV-COMM-PTR-X.
      *
           PERFORM  7374-EDIT-FV-COMM-DUR-OFFSET
               THRU 7374-EDIT-FV-COMM-DUR-OFFSET-X.
      *
       7370-EDIT-SCREEN-4-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 4 FIELD 1: COMMISSION POINTER
      *****************************************************************
       7371-EDIT-COMM-PTR.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-DPOS-COMM-RH-ID = SPACES
               MOVE RFX-DPOS-COMM-RH-ID
                                      TO MIR-DPOS-COMM-RH-ID
               GO TO 7371-EDIT-COMM-PTR-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-DPOS-COMM-RH-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-DPOS-COMM-RH-ID
557660     END-IF.
      *
           MOVE MIR-DPOS-COMM-RH-ID   TO RFX-DPOS-COMM-RH-ID.
      *
       7371-EDIT-COMM-PTR-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 4 FIELD 2: FV COMMISSION CONTROL
      *****************************************************************
       7372-EDIT-FV-COMM-CONTROL.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-PLAN-CV-COMM-IND = SPACES
               MOVE RFX-PLAN-CV-COMM-IND
                                      TO MIR-PLAN-CV-COMM-IND
               GO TO 7372-EDIT-FV-COMM-CONTROL-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-PLAN-CV-COMM-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-PLAN-CV-COMM-IND
557660     END-IF.
      *
           MOVE MIR-PLAN-CV-COMM-IND  TO WS-EDIT-FV-COMM.
           IF WS-VALID-FV-COMM
               MOVE MIR-PLAN-CV-COMM-IND
                                      TO RFX-PLAN-CV-COMM-IND
           ELSE
               MOVE 'SS00100014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7372-EDIT-FV-COMM-CONTROL-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 4 FIELD 3: FV COMMISSION POINTER
      *****************************************************************
       7373-EDIT-FV-COMM-PTR.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-CV-COMM-RH-ID = SPACES
               MOVE RFX-CV-COMM-RH-ID TO MIR-CV-COMM-RH-ID
               GO TO 7373-EDIT-FV-COMM-PTR-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-CV-COMM-RH-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CV-COMM-RH-ID
557660     END-IF.
      *
           MOVE MIR-CV-COMM-RH-ID     TO RFX-CV-COMM-RH-ID.
      *
       7373-EDIT-FV-COMM-PTR-X.
           EXIT.
      /
      *****************************************************************
      *  SCREEN 4 FIELD 4: FV COMMISSION DUR OFFSET
      *****************************************************************
       7374-EDIT-FV-COMM-DUR-OFFSET.
      *
      *  DATA NOT ENTERED, REFRESH MIR AND EXIT
      *
           IF MIR-CV-COMM-CALC-DUR = SPACES
               MOVE RFX-CV-COMM-CALC-DUR
                                      TO WS-DISPLAY-3
               MOVE WS-DISPLAY-3      TO MIR-CV-COMM-CALC-DUR
               GO TO 7374-EDIT-FV-COMM-DUR-OFFSET-X
557660     END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
           IF MIR-CV-COMM-CALC-DUR = EBLCH-BLANK-FIELD-CHAR
               MOVE '000'             TO MIR-CV-COMM-CALC-DUR
557660     END-IF.
      *
      *  SET PARAMETERS FOR NUMERIC EDIT ROUTINE.
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE '3'                   TO L0280-LENGTH.
           MOVE MIR-CV-COMM-CALC-DUR  TO L0280-INPUT-DATA.
      *
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-NUM-999
               MOVE WS-NUM-999        TO RFX-CV-COMM-CALC-DUR
               MOVE WS-NUM-999        TO WS-DISPLAY-3
               MOVE WS-DISPLAY-3      TO MIR-CV-COMM-CALC-DUR
           ELSE
               MOVE 'SS00100053'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED         TO WS-DATA-EDITS
557660     END-IF.
      *
       7374-EDIT-FV-COMM-DUR-OFFSET-X.
           EXIT.
      /
      *****************************************************************
      *  DATA CROSS EDITS
      *****************************************************************
       7400-CROSS-EDITS.
      *
           IF RFX-PLAN-REQIR-FND-CD = 'S'
               IF RFX-PLAN-MAX-FND-QTY NOT = 1
                   MOVE 'SS00100031'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 1             TO RFX-PLAN-MAX-FND-QTY
                   MOVE '001'         TO MIR-PLAN-MAX-FND-QTY
557660         END-IF
557660     END-IF.
      *
      ******************************************************************
      * IF TERMINATION BENCHMARK IS ENTERED, THEN TERMINATION PERIOD   *
      * SHOULD ALSO BE ENTERED.  CONVERSELY, IF TERMINATION PERIOD IS  *
      * ENTERED, TERMINATION BENCHMARK SHOULD ALSO BE ENTERED.         *
      ******************************************************************
           IF  NOT WS-MIN-AUTO-TRMN-AMT-INVALID
           AND NOT WS-AUTO-TRMN-MO-DUR-INVALID
               IF (RFX-MIN-AUTO-TRMN-AMT  NOT = +0
               AND RFX-AUTO-TRMN-MO-DUR = 0)
               OR (RFX-MIN-AUTO-TRMN-AMT  = +0
               AND RFX-AUTO-TRMN-MO-DUR NOT = 0)
                   MOVE 'SS00100037'  TO WGLOB-MSG-REF-INFO
                   MOVE WS-FAILED     TO WS-DATA-EDITS
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.
      *
      ******************************************************************
      * IF INDICATOR IS M THEN, THEN PARTIAL MONTHS SHOULDN'T BE ZERO  *
      * CONVERSELY, IF PARTIAL MONTHS ARE ZERO, INDICATOR SHOULDN'T BE *
      * 'M'.                                                           *
      ******************************************************************
           IF WS-VALID-MAX-P-SURR
               IF RFX-PLAN-MAX-PSUR-CD NOT = 'M'
               AND RFX-MAX-PSUR-MO-DUR   NOT = 0
                   MOVE 'SS00100035'  TO WGLOB-MSG-REF-INFO
                   MOVE WS-FAILED     TO WS-DATA-EDITS
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
               IF RFX-PLAN-MAX-PSUR-CD = 'M'
                   AND RFX-MAX-PSUR-MO-DUR   = 0
                   MOVE 'SS00100036'  TO WGLOB-MSG-REF-INFO
                   MOVE WS-FAILED     TO WS-DATA-EDITS
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
               END-IF
557660     END-IF.
       7400-CROSS-EDITS-X.
           EXIT.
      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
       9100-BLANK-DATA-FIELDS.
      *
      *    BLANK OUT DATA ON GIVEN SCREEN
      *
           PERFORM  9110-BLANK-DATA-FIELDS-1
               THRU 9110-BLANK-DATA-FIELDS-1-X
           PERFORM  9120-BLANK-DATA-FIELDS-2
               THRU 9120-BLANK-DATA-FIELDS-2-X.
           PERFORM  9130-BLANK-DATA-FIELDS-3
               THRU 9130-BLANK-DATA-FIELDS-3-X.
           PERFORM  9140-BLANK-DATA-FIELDS-4
               THRU 9140-BLANK-DATA-FIELDS-4-X.
      *
       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES ON SCREEN 1
      *****************************************************************
       9110-BLANK-DATA-FIELDS-1.
      *
           MOVE SPACES                TO MIR-PLAN-MAX-FND-QTY.
           MOVE SPACES                TO MIR-PLAN-REQIR-FND-CD.
           MOVE SPACES                TO MIR-MIN-AUTO-TRMN-AMT.
           MOVE SPACES                TO MIR-AUTO-TRMN-MO-DUR.
           MOVE SPACES                TO MIR-PLAN-PURCH-DIR-CD.
           MOVE SPACES                TO MIR-XFER-IN-DIR-CD.
           MOVE SPACES                TO MIR-XFER-OUT-DIR-CD.
           MOVE SPACES                TO MIR-PLAN-WTHDR-DIR-CD.
           MOVE SPACES                TO MIR-MTHV-CV-DIR-CD.
014550*    MOVE SPACES                TO MIR-PLAN-OUT-ALLOC-CD.
           MOVE SPACES                TO MIR-PEND-PMT-INT-RT-ID.
           MOVE SPACES                TO MIR-XFER-INT-RT-ID.
           MOVE SPACES                TO MIR-MIN-INT-ELIG-AMT.
           MOVE SPACES                TO MIR-INT-CALC-TYP-CD.
      *
       9110-BLANK-DATA-FIELDS-1-X.
           EXIT.
      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES ON SCREEN 2
      *****************************************************************
       9120-BLANK-DATA-FIELDS-2.
      *
           MOVE SPACES                TO MIR-MIN-INIT-DPOS-AMT.
           MOVE SPACES                TO MIR-MIN-ADDL-DPOS-AMT.
           MOVE SPACES                TO MIR-PLAN-DPOS-NOTI-CD.
           MOVE SPACES                TO MIR-MIN-CNFRM-NOTI-AMT.
           MOVE SPACES                TO MIR-SETUP-CHRG-AMT.
           MOVE SPACES                TO MIR-XFER-FEE-TYP-CD.
010302*    MOVE SPACES            TO MIR-TFPTR.
016109     MOVE SPACES                TO MIR-PLAN-FREE-XFER-CD.
016109     MOVE SPACES                TO MIR-PLAN-FREE-XFER-QTY.
016109     MOVE SPACES                TO MIR-FREE-XFER-PERI-CD.
      *
       9120-BLANK-DATA-FIELDS-2-X.
           EXIT.
      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES ON SCREEN 3
      *****************************************************************
       9130-BLANK-DATA-FIELDS-3.
      *
           MOVE SPACES                TO MIR-PLAN-MAX-PSUR-CD.
           MOVE SPACES                TO MIR-PLAN-MAX-PSUR-QTY.
           MOVE SPACES                TO MIR-MAX-PSUR-MO-DUR.
           MOVE SPACES                TO MIR-PLAN-MIN-PSUR-AMT.
           MOVE SPACES                TO MIR-GUAR-VALU-CALC-CD.
020475*    MOVE SPACES                TO MIR-DB-GUAR-VALU-PCT.
020475     MOVE SPACES                TO MIR-DTH-GUAR-VALU-PCT.
           MOVE SPACES                TO MIR-MAT-GUAR-VALU-PCT.
           MOVE SPACES                TO MIR-SURR-GUAR-VALU-PCT.
012136*    MOVE SPACES            TO MIR-NTUPR.
      *
       9130-BLANK-DATA-FIELDS-3-X.
           EXIT.
      *
      *
      *
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES ON SCREEN 4
      *****************************************************************
       9140-BLANK-DATA-FIELDS-4.
      *
           MOVE SPACES                TO MIR-DPOS-COMM-RH-ID.
           MOVE SPACES                TO MIR-PLAN-CV-COMM-IND.
           MOVE SPACES                TO MIR-CV-COMM-RH-ID.
           MOVE SPACES                TO MIR-CV-COMM-CALC-DUR.
      *
       9140-BLANK-DATA-FIELDS-4-X.
           EXIT.
      *
       9150-BLANK-DATA-FIELDS-5.
      *
      *  MOVE SPACES TO FIELDS ON BROWSE SCREEN

           MOVE SPACES                TO MIR-PLAN-ID-G.
           MOVE SPACES                TO MIR-PLAN-REQIR-FND-CD-G.
           MOVE SPACES                TO MIR-PLAN-MAX-FND-QTY-G.
           MOVE SPACES                TO MIR-MIN-INIT-DPOS-AMT-G.
           MOVE SPACES                TO MIR-MIN-ADDL-DPOS-AMT-G.
      *
       9150-BLANK-DATA-FIELDS-5-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
       9200-MOVE-RECORD-TO-SCREEN.
      *
      *    MOVE DATA FOR GIVEN SCREEN
      *
           PERFORM  9210-MOVE-RECORD-TO-SCREEN-1
               THRU 9210-MOVE-RECORD-TO-SCREEN-1-X.
           PERFORM  9220-MOVE-RECORD-TO-SCREEN-2
               THRU 9220-MOVE-RECORD-TO-SCREEN-2-X.
           PERFORM  9230-MOVE-RECORD-TO-SCREEN-3
               THRU 9230-MOVE-RECORD-TO-SCREEN-3-X.
           PERFORM  9240-MOVE-RECORD-TO-SCREEN-4
               THRU 9240-MOVE-RECORD-TO-SCREEN-4-X.
      *
       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE FILE VALUES TO SCREEN 1
      *****************************************************************
       9210-MOVE-RECORD-TO-SCREEN-1.
      *
           MOVE RFX-PLAN-MAX-FND-QTY  TO WS-DISPLAY-3.
           MOVE WS-DISPLAY-3          TO MIR-PLAN-MAX-FND-QTY.
           MOVE RFX-PLAN-REQIR-FND-CD TO MIR-PLAN-REQIR-FND-CD.
008455*    MOVE RFX-MIN-AUTO-TRMN-AMT TO WS-DISPLAY-7V2.
008455*    MOVE WS-DISPLAY-7V2        TO MIR-MIN-AUTO-TRMN-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFX-MIN-AUTO-TRMN-AMT * 100.
020874     MOVE RFX-MIN-AUTO-TRMN-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PLAN-MIN-PSUR-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-MIN-AUTO-TRMN-AMT.
020874*    MOVE RFX-AUTO-TRMN-MO-DUR  TO WS-DISPLAY-3.
020874*    MOVE WS-DISPLAY-3          TO MIR-AUTO-TRMN-MO-DUR.
020874     MOVE RFX-AUTO-TRMN-MO-DUR  TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-AUTO-TRMN-MO-DUR
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-AUTO-TRMN-MO-DUR.
           MOVE RFX-PLAN-PURCH-DIR-CD TO MIR-PLAN-PURCH-DIR-CD.
           MOVE RFX-XFER-IN-DIR-CD    TO MIR-XFER-IN-DIR-CD.
           MOVE RFX-XFER-OUT-DIR-CD   TO MIR-XFER-OUT-DIR-CD.
           MOVE RFX-PLAN-WTHDR-DIR-CD TO MIR-PLAN-WTHDR-DIR-CD.
           MOVE RFX-MTHV-CV-DIR-CD    TO MIR-MTHV-CV-DIR-CD.
014550*    MOVE RFX-PLAN-OUT-ALLOC-CD TO MIR-PLAN-OUT-ALLOC-CD.
           MOVE RFX-PEND-PMT-INT-RT-ID TO MIR-PEND-PMT-INT-RT-ID.
           MOVE RFX-XFER-INT-RT-ID    TO MIR-XFER-INT-RT-ID.
008455*    MOVE RFX-MIN-INT-ELIG-AM   TO WS-DISPLAY-7V2.
008455*    MOVE WS-DISPLAY-7V2        TO MIR-MIN-INT-ELIG-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFX-MIN-INT-ELIG-AMT * 100.
020874     MOVE RFX-MIN-INT-ELIG-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-MIN-INT-ELIG-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-MIN-INT-ELIG-AMT.
           MOVE RFX-INT-CALC-TYP-CD   TO MIR-INT-CALC-TYP-CD.
      *
       9210-MOVE-RECORD-TO-SCREEN-1-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE FILE VALUES TO SCREEN 2
      *****************************************************************
       9220-MOVE-RECORD-TO-SCREEN-2.
      *
008455*    MOVE RFX-MIN-INIT-DPOS-AMT       TO WS-DISPLAY-7V2.
008455*    MOVE WS-DISPLAY-7V2              TO MIR-MIN-INIT-DPOS-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFX-MIN-INIT-DPOS-AMT * 100.
020874     MOVE RFX-MIN-INIT-DPOS-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-MIN-INIT-DPOS-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-MIN-INIT-DPOS-AMT.

008455*    MOVE RFX-MIN-ADDL-DPOS-AMT       TO WS-DISPLAY-7V2.
008455*    MOVE WS-DISPLAY-7V2              TO MIR-MIN-ADDL-DPOS-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFX-MIN-ADDL-DPOS-AMT * 100.
020874     MOVE RFX-MIN-ADDL-DPOS-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-MIN-ADDL-DPOS-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-MIN-ADDL-DPOS-AMT.

           MOVE RFX-PLAN-DPOS-NOTI-CD TO MIR-PLAN-DPOS-NOTI-CD.
008455*    MOVE RFX-MIN-CNFRM-NOTI-AMT      TO WS-DISPLAY-7V2.
008455*    MOVE WS-DISPLAY-7V2              TO MIR-MIN-CNFRM-NOTI-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFX-MIN-CNFRM-NOTI-AMT * 100.
020874     MOVE RFX-MIN-CNFRM-NOTI-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-MIN-CNFRM-NOTI-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-MIN-CNFRM-NOTI-AMT.

008455*    MOVE RFX-SETUP-CHRG-AMT          TO WS-DISPLAY-7V2.
008455*    MOVE WS-DISPLAY-7V2              TO MIR-SETUP-CHRG-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFX-SETUP-CHRG-AMT * 100.
020874     MOVE RFX-SETUP-CHRG-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-SETUP-CHRG-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-SETUP-CHRG-AMT.

           MOVE RFX-XFER-FEE-TYP-CD   TO MIR-XFER-FEE-TYP-CD.
010302*    MOVE RFX-XFER-FEE-RH-ID          TO MIR-TFPTR.
016109     MOVE RFX-PLAN-FREE-XFER-CD  TO MIR-PLAN-FREE-XFER-CD.
016109     MOVE RFX-PLAN-FREE-XFER-QTY TO WS-FREE-XFER-QTY-N.
016109     MOVE WS-FREE-XFER-QTY-A     TO MIR-PLAN-FREE-XFER-QTY.
016109     MOVE RFX-FREE-XFER-PERI-CD  TO MIR-FREE-XFER-PERI-CD.
      *
       9220-MOVE-RECORD-TO-SCREEN-2-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE FILE VALUES TO SCREEN 3
      *****************************************************************
       9230-MOVE-RECORD-TO-SCREEN-3.
      *
           MOVE RFX-PLAN-MAX-PSUR-CD  TO MIR-PLAN-MAX-PSUR-CD.
           MOVE RFX-PLAN-MAX-PSUR-QTY TO WS-DISPLAY-3.
           MOVE WS-DISPLAY-3          TO MIR-PLAN-MAX-PSUR-QTY.
020874*    MOVE RFX-MAX-PSUR-MO-DUR   TO WS-DISPLAY-3.
020874*    MOVE WS-DISPLAY-3          TO MIR-MAX-PSUR-MO-DUR.
020874     MOVE RFX-MAX-PSUR-MO-DUR   TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-MAX-PSUR-MO-DUR
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-MAX-PSUR-MO-DUR.
008455*    MOVE RFX-PLAN-MIN-PSUR-AMT       TO WS-DISPLAY-7V2.
008455*    MOVE WS-DISPLAY-7V2              TO MIR-PLAN-MIN-PSUR-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RFX-PLAN-MIN-PSUR-AMT * 100.
020874     MOVE RFX-PLAN-MIN-PSUR-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PLAN-MIN-PSUR-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PLAN-MIN-PSUR-AMT.

           MOVE RFX-GUAR-VALU-CALC-CD TO MIR-GUAR-VALU-CALC-CD.
020874*    MOVE RFX-DB-GUAR-VALU-PCT  TO WS-DISPLAY-3V4.
020874*    MOVE WS-DISPLAY-3V4        TO MIR-DB-GUAR-VALU-PCT.
020475*    MOVE RFX-DB-GUAR-VALU-PCT  TO L0290-INPUT-V04.
020475     MOVE RFX-DTH-GUAR-VALU-PCT TO L0290-INPUT-V04.
020874     MOVE 4                     TO L0290-PRECISION.
020475*    MOVE LENGTH OF MIR-DB-GUAR-VALU-PCT
020475     MOVE LENGTH OF MIR-DTH-GUAR-VALU-PCT
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020475*    MOVE L0290-OUTPUT-DATA     TO MIR-DB-GUAR-VALU-PCT.
020475     MOVE L0290-OUTPUT-DATA     TO MIR-DTH-GUAR-VALU-PCT.
020874*    MOVE RFX-MAT-GUAR-VALU-PCT TO WS-DISPLAY-3V4.
020874*    MOVE WS-DISPLAY-3V4        TO MIR-MAT-GUAR-VALU-PCT.
020874     MOVE RFX-MAT-GUAR-VALU-PCT TO L0290-INPUT-V04.
020874     MOVE 4                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-MAT-GUAR-VALU-PCT
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-MAT-GUAR-VALU-PCT.
020874*    MOVE RFX-SURR-GUAR-VALU-PCT                TO WS-DISPLAY-3V4.
020874*    MOVE WS-DISPLAY-3V4        TO MIR-SURR-GUAR-VALU-PCT.
020874     MOVE RFX-SURR-GUAR-VALU-PCT TO L0290-INPUT-V04.
020874     MOVE 4                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-SURR-GUAR-VALU-PCT
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-SURR-GUAR-VALU-PCT.
012136*    MOVE RFX-NOT-TAKEN-PRCES-CD      TO MIR-NTUPR.
      *
       9230-MOVE-RECORD-TO-SCREEN-3-X.
           EXIT.
      *
      *
      *
      *****************************************************************
      *  MOVE FILE VALUES TO SCREEN 4
      *****************************************************************
       9240-MOVE-RECORD-TO-SCREEN-4.
      *
           MOVE RFX-DPOS-COMM-RH-ID   TO MIR-DPOS-COMM-RH-ID.
           MOVE RFX-PLAN-CV-COMM-IND  TO MIR-PLAN-CV-COMM-IND.
           MOVE RFX-CV-COMM-RH-ID     TO MIR-CV-COMM-RH-ID.
           MOVE RFX-CV-COMM-CALC-DUR  TO WS-DISPLAY-3.
           MOVE WS-DISPLAY-3          TO MIR-CV-COMM-CALC-DUR.
      *
       9240-MOVE-RECORD-TO-SCREEN-4-X.
           EXIT.
      *
      *****************************************************************
      *  MOVE FILE VALUES TO SCREEN 5 (BROWSE SCREEN)
      *****************************************************************
       9250-MOVE-RECORD-TO-SCREEN-5.
      *
           MOVE RFX-PLAN-ID           TO MIR-PLAN-ID-T (WS-SUB).
           MOVE RFX-PLAN-REQIR-FND-CD
                                    TO MIR-PLAN-REQIR-FND-CD-T (WS-SUB).
           MOVE RFX-PLAN-MAX-FND-QTY  TO WS-DISPLAY-3.
           MOVE WS-DISPLAY-3         TO MIR-PLAN-MAX-FND-QTY-T (WS-SUB).
008455*    MOVE RFX-MIN-INIT-DPOS-AMT TO WS-DISPLAY-7V2.
008455*    MOVE WS-DISPLAY-7V2      TO MIR-MIN-INIT-DPOS-AMT-T (WS-SUB).
020874*    COMPUTE L0290-INPUT-NUMBER = RFX-MIN-INIT-DPOS-AMT * 100.
020874     MOVE RFX-MIN-INIT-DPOS-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-MIN-INIT-DPOS-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA   TO MIR-MIN-INIT-DPOS-AMT-T (WS-SUB).

008455*    MOVE RFX-MIN-ADDL-DPOS-AMT TO WS-DISPLAY-7V2.
008455*    MOVE WS-DISPLAY-7V2      TO MIR-MIN-ADDL-DPOS-AMT-T (WS-SUB).
020874*    COMPUTE L0290-INPUT-NUMBER = RFX-MIN-ADDL-DPOS-AMT * 100.
020874     MOVE RFX-MIN-ADDL-DPOS-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-MIN-ADDL-DPOS-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA   TO MIR-MIN-ADDL-DPOS-AMT-T (WS-SUB).
      *
       9250-MOVE-RECORD-TO-SCREEN-5-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
       9300-SETUP-MSIN-REFERENCE.
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
      *
       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WS-FIELD-EDITS.
025970     INITIALIZE WS-DISPLAY-AND-NUM-FIELDS.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

025970     SET WS-TRANS-NAME-DEFAULT  TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT    TO TRUE.
025970     SET WS-MAX-LINES-DEFAULT   TO TRUE.
025970     SET WS-OK-DEFAULT          TO TRUE.
025970     SET WS-FAILED-DEFAULT      TO TRUE.

025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY PH
014221                         '$VAR2' BY 'PH'.

       COPY XCPPEXIT.
      /
018764*COPY SCCLFX.
018764 COPY SCPLFX.
011526/
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPPINIT.
      /
008455 COPY XCPL0290.
008455 COPY XCPS0290.
008455/
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS                                 *
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNPD.
014221/
014221 COPY CCPNPH.
014221 COPY CCPUPH.
      /
       COPY SCPAFX.
      /
       COPY SCPBFX.

       COPY SCPNFX.
      /
       COPY SCPUFX.
      /
       COPY SCPXFX.
      /
       COPY SCPCFX.
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *
      *****************************************************************
      **                 END OF PROGRAM SSOM0010                     **
      *****************************************************************
