      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0311.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0311                                         **
      **  REMARKS:  IHST ONLINE TRANSACTION                          **
      **            ALLOWS FOR INQUIRY AND MAINTENANCE OF INTEREST   **
      **            HISTORY FILE                                     **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURE                **
557668**  5.5       NEW NAME FORMATTING                              **
557699**  5.5       NEW AUDIT MODULES                                **
557708**  5.5       ABEND HANDLING                                   **
008453**  5.5.2     MULTIPLE EXTERNAL DATE FORMATS                   **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
005409**  5.6       PUT WORK DATES THRU THE DATE ROUTINE TO GET      **
005409**            VALID DATE PRIOR TO MOVING TO DB2 TABLES         **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010418**  5.6       ADD SUB-COMPANY-CODE FIELD                       **
011365**  5.6       ADD MANUALLY UPDATED INDICATOR                   **
012624**  6.0       GLOBAL SECURITY                                  **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015543**  6.0       CODES CLEAN UP                                   **
014221**  6.2       LOGICAL RECORD LOCKING                           **
015692**  6.2       REPOPULATE MIR AFTER UPDATE                      **
016440**  6.2       COMBINE NB AND ADMIN - ONLINE REQUIREMENTS       **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      /
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0311'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.
026057 COPY CCWWIHSD.
026057 COPY XCWWWKDT.


014590*COPY XCWL0030.
025970
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY               PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT   VALUE '0260'.
       01  MISCELLANEOUS-WORK-AREAS.

           05  WS-EDIT-ERROR-SWITCH      PIC X(01).
               88  EDIT-ERROR             VALUE 'Y'.
           05  UPDATE-SW                 PIC X(01).
               88  NO-UPDATE              VALUE 'N'.
               88  UPDATE-REQUIRED        VALUE 'Y'.
           05  CURSOR-SW                 PIC 9.
               88  CURSOR-ON-POLNUM       VALUE 0.
               88  CURSOR-ON-GRPREM       VALUE 1.
           05  HOLD-FORCE                PIC X.
008453*    05  HOLD-DATE                 PIC X(9).
008453     05  HOLD-DATE                 PIC X(10).
           05  HOLD-I-DATE               PIC X(10).
           05  WS-BUS-FCN-ID             PIC X(04).
               88  WS-BUS-FCN-ID-VALID   VALUES
                   '0260' '0262'.
               88  WS-BUS-FCN-RETRIEVE   VALUE  '0260'.
               88  WS-BUS-FCN-UPDATE     VALUE  '0262'.
025970*    05  WS-TWRK-KEY               PIC X(04)  VALUE '0260'.
           05  POLICY-HOLD.
               10  POLICY-NUM            PIC X(09).
               10  POLICY-SUFF           PIC X(01).

       01  SUBSCRIPT-AREA.

016548*    05  I                         PIC S9(4) COMP.
016548     05  I                         PIC S9(4) BINARY.
016548*    05  N8                        PIC S9(4) COMP.
016548     05  N8                        PIC S9(4) BINARY.

       01  WS-NUMERIC-DISPLAY-FIELDS.

           05  WS-DISP-S0-5.
               10  WS-HOLD-S0-5          PIC +.9(5).
           05  WS-DISP-S4-5.
               10  WS-HOLD-S4-5          PIC +9(4).9(5).
008455*    05  WS-DISP-S7-2.
008455*        10  WS-HOLD-S7-2          PIC +9(7).9(2).
008455*    05  WS-DISP-S9-2.
008455*        10  WS-HOLD-S9-2          PIC +9(9).9(2).

       01  WS-NUM-EDIT-OUTPUT            PIC S9(18) COMP-3.

       01  WS-NUM-EDIT-13V5    REDEFINES
           WS-NUM-EDIT-OUTPUT            PIC S9(13)V9(05) COMP-3.
      /
016537*COPY XCWWWKDT.
      /
       COPY XCWLDTLK.
      /
       COPY XCWL1640.
005409 COPY XCWL1670.
005409 COPY XCWL1680.
      /
016108 COPY CCWL0985.
020478 COPY CCWL2626.
       COPY CCWL2430.
557668 COPY CCWL0620.
       COPY CCWL5400.
014221 COPY CCWWLOCK.
      /
       COPY XCWEBLCH.
      /
016537*COPY XCWTATRB.
      /
       COPY XCWL0280.
008455/
008455 COPY XCWL0290.
      /
014221 COPY XCWL8090.
      /
       COPY CCFWCVG.
       COPY CCFRCVG.

       COPY CCWWCVGS.
      /
       COPY CCFWIH.
       COPY CCFRIH.
      /
       COPY CCFWPOL.

       COPY CCFRPOL.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
016108 COPY CCWLPGA.
      /
       LINKAGE SECTION.

CVMQ71 COPY XCWWDFH.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0311.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *---------------
015543*0000-MAIN-LINE.
015543 0000-MAINLINE.
      *---------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

015543*0000-MAIN-LINE-X.
015543 0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

025970*    SET  MIR-RETRN-OK          TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.
008455
557660     PERFORM  9450-SETUP-MSIN-REFERENCE
               THRU 9450-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-POL-ID-BASE       TO POLICY-NUM.
           MOVE MIR-POL-ID-SFX        TO POLICY-SUFF.

           IF  WGLOB-MSG-ERROR-SW = 1
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           MOVE POLICY-HOLD           TO WPOL-POL-ID.
           MOVE MIR-ISWL-ANNV-DT      TO HOLD-DATE.
           MOVE ZERO                  TO WGLOB-MSG-ERROR-SW.
           MOVE 'N'                   TO UPDATE-SW.

      *
      *  READ THE POLICY FILE
      *
           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.
           IF  NOT WPOL-IO-OK
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO UPDATE-SW
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

      *
      *  SET UP KEY FOR INTEREST HISTORY FILE
      *
           MOVE HOLD-DATE             TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  NOT L1640-VALID
               MOVE 'CS00000036'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO UPDATE-SW
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           MOVE L1640-INTERNAL-DATE   TO HOLD-I-DATE.
           MOVE POLICY-HOLD           TO WIH-POL-ID.
005409*    MOVE HOLD-I-DATE              TO WIH-ISWL-ANNV-DT.
005409     MOVE HOLD-I-DATE           TO L1680-INTERNAL-1.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
005409     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
005409     MOVE L1680-INTERNAL-2      TO WIH-ISWL-ANNV-DT.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WIH-ISWL-ANNV-DT         TO WIHSD-EFF-DT.
026057     IF  WS-BUS-FCN-RETRIEVE
026057         PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057             THRU IHSD-1000-CHK-IHSD-INQUIRY-X
026057     ELSE
026057         PERFORM  IHSD-2000-CHK-IHSD-PROCESS
026057             THRU IHSD-2000-CHK-IHSD-PROCESS-X
026057     END-IF.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057         SET NO-UPDATE             TO TRUE
026057         GO TO 2000-PROCESS-REQUEST-X
026057     END-IF.

      *
      * VERIFY POLICY ACCESS
      *
012624     IF WS-BUS-FCN-UPDATE
012624         IF  RPOL-POL-SUSPENDED
012624*MSG:    POLICY CURRENTLY SUSPENDED - CANNOT MAINTAIN OR PROCESS
012624             MOVE 'XS00000240'         TO WGLOB-MSG-REF-INFO
012624             PERFORM  0260-1000-GENERATE-MESSAGE
012624                 THRU 0260-1000-GENERATE-MESSAGE-X
012624             GO TO 2000-PROCESS-REQUEST-X
012624         END-IF
016440*        IF  RPOL-POL-APPL-CTL-NBS
016440         IF  RPOL-POL-STAT-BEFORE-SETL
016440*MSG:    PENDING POLICY - CANNOT MAINTAIN OR PROCESS
012624             MOVE 'XS00000238'        TO WGLOB-MSG-REF-INFO
012624             PERFORM  0260-1000-GENERATE-MESSAGE
012624                 THRU 0260-1000-GENERATE-MESSAGE-X
012624             GO TO 2000-PROCESS-REQUEST-X
012624         END-IF
012624     END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
012624*    MOVE WGLOB-APPL-ID         TO L5400-SYS-APPL-CTL-CD.
016440
016440     EVALUATE TRUE
016440         WHEN WS-BUS-FCN-RETRIEVE
016440              SET L5400-POL-XFER-INQ    TO TRUE
016440         WHEN WS-BUS-FCN-UPDATE
016440              SET L5400-POL-XFER-UPDATE TO TRUE
016440     END-EVALUATE.
016440
           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
016440     OR  L5400-XFER-ACCS-RESTRICTED
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-UPDATE
                   IF  L5400-STAT-ACCS-RESTRICTED
                       GO TO 2000-PROCESS-REQUEST-X
                   ELSE
                       PERFORM  4000-PROCESS-UPDATE
                           THRU 4000-PROCESS-UPDATE-X
                   END-IF

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID  TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0311'      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *
      *  INQUIRY PROCESSING
      *

      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------

014221     MOVE MIR-POL-ID-BASE      TO WPOL-POL-ID-BASE.
014221     MOVE MIR-POL-ID-SFX       TO WPOL-POL-ID-SFX.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           PERFORM  IH-1000-READ
               THRU IH-1000-READ-X.

           IF  WIH-IO-OK
               PERFORM  9300-MOVE-FIELDS-TO-MIR
                   THRU 9300-MOVE-FIELDS-TO-MIR-X
               MOVE 'N'               TO UPDATE-SW
               MOVE 'CS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               MOVE 'CS03110001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO UPDATE-SW
557660     END-IF.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *
      *  MAINTAIN PROCESSING
      *
      *--------------------
       4000-PROCESS-UPDATE.
      *--------------------

016108*
016108* VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108     PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
016108         THRU CVGS-1000-LOAD-CVGS-ARRAY-X.
016108
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     MOVE HOLD-I-DATE           TO L0985-EFF-DT.
016108
016108     PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108         THRU 0985-1000-VAL-POL-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108         MOVE 'N'               TO UPDATE-SW
016108         GO TO 4000-PROCESS-UPDATE-X
016108     END-IF.

014221     MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID-BASE.
014221     MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.

014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF WPOL-IO-NOT-FOUND
014221*MSG: 'POLICY NOT ON POLICY FILE'
014221         SET EDIT-ERROR         TO TRUE
014221         MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
014221         MOVE WPOL-POL-ID       TO WGLOB-MSG-PARM (01)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 4000-PROCESS-UPDATE-X
014221     END-IF.

014221     IF MIR-RETRN-TS-MISMATCH
014221*MSG: 'TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE'
014221         SET EDIT-ERROR          TO TRUE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'POL'              TO WGLOB-MSG-PARM (01)
014221         MOVE WPOL-POL-ID        TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 4000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  IH-1000-READ-FOR-UPDATE
               THRU IH-1000-READ-FOR-UPDATE-X.

557699*    IF  NOT WIH-IO-OK
557699     IF  WIH-IO-OK
557699         IF WGLOB-AUDIT-REQUESTED
557699            PERFORM  IH-1000-CALL-AUDIT
557699                THRU IH-1000-CALL-AUDIT-X
557699         END-IF
557699     ELSE
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               MOVE 'CS03110001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO UPDATE-SW
014221         PERFORM  POL-3000-UNLOCK
014221             THRU POL-3000-UNLOCK-X
               GO TO 4000-PROCESS-UPDATE-X
557660     END-IF.

      *
      *  RESET SCREEN ATTRIBUTES FOR DATA INPUT, THIS WAY ANY
      *  ERRORS PICKED UP THE LAST TIME WILL NOT BE HIGHLIGHTED
      *  AS ERRORS AGAIN THIS TIME IF THEY WERE FIXED.
      *

           PERFORM  4521-EDIT-GROSS-ANN-PREM
               THRU 4521-EDIT-GROSS-ANN-PREM-X.
           PERFORM  4522-EDIT-NET-ANN-PREM
               THRU 4522-EDIT-NET-ANN-PREM-X.
           PERFORM  4523-EDIT-STATUS
               THRU 4523-EDIT-STATUS-X.
           PERFORM  4524-EDIT-DCL-INT
               THRU 4524-EDIT-DCL-INT-X.
           PERFORM  4525-EDIT-DCL-COI-RATE
               THRU 4525-EDIT-DCL-COI-RATE-X.

           PERFORM  4531-EDIT-BEGIN-YR-FUND
               THRU 4531-EDIT-BEGIN-YR-FUND-X.
           PERFORM  4532-EDIT-GUAR-INT
               THRU 4532-EDIT-GUAR-INT-X.
           PERFORM  4533-EDIT-EXCESS-INT
               THRU 4533-EDIT-EXCESS-INT-X.
           PERFORM  4534-EDIT-COST-OF-INS
               THRU 4534-EDIT-COST-OF-INS-X.

           PERFORM  4541-EDIT-END-YR-FUND
               THRU 4541-EDIT-END-YR-FUND-X.
           PERFORM  4542-EDIT-NET-CASH-VAL
               THRU 4542-EDIT-NET-CASH-VAL-X.
           PERFORM  4543-EDIT-DEATH-BENEFIT
               THRU 4543-EDIT-DEATH-BENEFIT-X.
           PERFORM  4544-EDIT-AVG-LOAN-BAL
               THRU 4544-EDIT-AVG-LOAN-BAL-X.

           IF  WGLOB-MSG-ERROR-SW = 1
               MOVE 'CS03110002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'CS00000010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           IF  UPDATE-REQUIRED
               MOVE WGLOB-PROCESS-DATE      TO RIH-ISWL-ANNV-UPDT-DT
011365         SET RIH-ISWL-ANNV-MANL       TO TRUE
               PERFORM  IH-2000-REWRITE
                   THRU IH-2000-REWRITE-X
557699         IF WGLOB-AUDIT-REQUESTED
557699            PERFORM  IH-1000-CALL-AUDIT
557699                THRU IH-1000-CALL-AUDIT-X
557699         END-IF
014221         PERFORM  POL-2000-REWRITE
014221             THRU POL-2000-REWRITE-X
014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X
014221     ELSE
014221         PERFORM  IH-3000-UNLOCK
014221             THRU IH-3000-UNLOCK-X
014221         PERFORM  POL-3000-UNLOCK
014221             THRU POL-3000-UNLOCK-X
557660     END-IF.
011365*
011365     MOVE RIH-ISWL-ANNV-MANL-IND      TO MIR-ISWL-ANNV-MANL-IND.
015692
015692     PERFORM  9300-MOVE-FIELDS-TO-MIR
015692         THRU 9300-MOVE-FIELDS-TO-MIR-X.
015692
015692
       4000-PROCESS-UPDATE-X.
           EXIT.
      /
      *
      *  EDIT LINE 2 OF IHST
      *
      *-------------------------
       4521-EDIT-GROSS-ANN-PREM.
      *-------------------------

           IF  MIR-POL-GRS-APREM-AMT                   =  SPACES
008455*        MOVE RIH-POL-GRS-APREM-AMT   TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-POL-GRS-APREM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RIH-POL-GRS-APREM-AMT * 100
020874         MOVE RIH-POL-GRS-APREM-AMT TO L0290-INPUT-V02
008455         MOVE 2                     TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-GRS-APREM-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY    TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-GRS-APREM-AMT
               GO TO 4521-EDIT-GROSS-ANN-PREM-X
557660     END-IF.

           IF  MIR-POL-GRS-APREM-AMT  =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+000000000.00'         TO MIR-POL-GRS-APREM-AMT
008455         MOVE  ZEROS            TO MIR-POL-GRS-APREM-AMT
557660     END-IF.

           MOVE 'Y'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 13                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-POL-GRS-APREM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE MIR-POL-GRS-APREM-AMT TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE 'Y'               TO UPDATE-SW
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RIH-POL-GRS-APREM-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-POL-GRS-APREM-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-POL-GRS-APREM-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-POL-GRS-APREM-AMT
           ELSE
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS03110003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4521-EDIT-GROSS-ANN-PREM-X.
           EXIT.
      /
      *-----------------------
       4522-EDIT-NET-ANN-PREM.
      *-----------------------

           IF  MIR-NET-APREM-AMT = SPACES
008455*        MOVE RIH-NET-APREM-AMT       TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-NET-APREM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RIH-NET-APREM-AMT * 100
020874         MOVE RIH-NET-APREM-AMT     TO L0290-INPUT-V02
008455         MOVE 2                     TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-NET-APREM-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-NET-APREM-AMT
               GO TO 4522-EDIT-NET-ANN-PREM-X
557660     END-IF.

           IF  MIR-NET-APREM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-NET-APREM-AMT
008455         MOVE  ZEROS            TO MIR-NET-APREM-AMT
557660     END-IF.

           MOVE 'Y'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-NET-APREM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE MIR-NET-APREM-AMT     TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE 'Y'               TO UPDATE-SW
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RIH-NET-APREM-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-NET-APREM-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-NET-APREM-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-NET-APREM-AMT
           ELSE
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS03110004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4522-EDIT-NET-ANN-PREM-X.
           EXIT.
      /
      *-----------------
       4523-EDIT-STATUS.
      *-----------------

           IF  MIR-ISWL-ANNV-STAT-CD = SPACES
               MOVE RIH-ISWL-ANNV-STAT-CD
                                      TO MIR-ISWL-ANNV-STAT-CD
               GO TO 4523-EDIT-STATUS-X
557660     END-IF.

           IF  MIR-ISWL-ANNV-STAT-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-ISWL-ANNV-STAT-CD
557660     END-IF.

           IF  MIR-ISWL-ANNV-STAT-CD = '1'
           OR  MIR-ISWL-ANNV-STAT-CD = '2'
           OR  MIR-ISWL-ANNV-STAT-CD = '3'
           OR  MIR-ISWL-ANNV-STAT-CD = '4'
               MOVE 'Y'               TO UPDATE-SW
               MOVE MIR-ISWL-ANNV-STAT-CD
                                      TO RIH-ISWL-ANNV-STAT-CD
           ELSE
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS03110005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4523-EDIT-STATUS-X.
           EXIT.
      /
      *------------------
       4524-EDIT-DCL-INT.
      *------------------

           IF  MIR-DCLR-INT-RT = SPACES
               MOVE RIH-DCLR-INT-RT   TO WS-HOLD-S0-5
               MOVE WS-DISP-S0-5      TO MIR-DCLR-INT-RT
               GO TO 4524-EDIT-DCL-INT-X
557660     END-IF.

           IF  MIR-DCLR-INT-RT = EBLCH-BLANK-FIELD-CHAR
               MOVE '+.00000'         TO MIR-DCLR-INT-RT
557660     END-IF.

           MOVE 'Y'                   TO L0280-SIGN-IND.
           MOVE 5                     TO L0280-PRECISION.
           MOVE 0                     TO L0280-LENGTH.
           MOVE 7                     TO L0280-INPUT-SIZE.
           MOVE MIR-DCLR-INT-RT       TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE 'Y'               TO UPDATE-SW
               MOVE L0280-OUTPUT      TO WS-NUM-EDIT-OUTPUT
               MOVE WS-NUM-EDIT-13V5  TO RIH-DCLR-INT-RT
               MOVE WS-NUM-EDIT-13V5  TO WS-HOLD-S0-5
               MOVE WS-DISP-S0-5      TO MIR-DCLR-INT-RT
           ELSE
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS03110006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4524-EDIT-DCL-INT-X.
           EXIT.
      /
      *-----------------------
       4525-EDIT-DCL-COI-RATE.
      *-----------------------

           IF  MIR-DCLR-COI-RT = SPACES
               MOVE RIH-DCLR-COI-RT   TO WS-HOLD-S4-5
               MOVE WS-DISP-S4-5      TO MIR-DCLR-COI-RT
               GO TO 4525-EDIT-DCL-COI-RATE-X
557660     END-IF.

           IF  MIR-DCLR-COI-RT = EBLCH-BLANK-FIELD-CHAR
               MOVE '+0000.00000'     TO MIR-DCLR-COI-RT
557660     END-IF.

           MOVE 'Y'                   TO L0280-SIGN-IND.
           MOVE 5                     TO L0280-PRECISION.
           MOVE 4                     TO L0280-LENGTH.
           MOVE 11                    TO L0280-INPUT-SIZE.
           MOVE MIR-DCLR-COI-RT       TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE 'Y'               TO UPDATE-SW
               MOVE L0280-OUTPUT      TO WS-NUM-EDIT-OUTPUT
               MOVE WS-NUM-EDIT-13V5  TO RIH-DCLR-COI-RT
               MOVE WS-NUM-EDIT-13V5  TO WS-HOLD-S4-5
               MOVE WS-DISP-S4-5      TO MIR-DCLR-COI-RT
           ELSE
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS03110007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4525-EDIT-DCL-COI-RATE-X.
           EXIT.
      /
      *
      *  EDIT LINE 3 OF IHST
      *

      *------------------------
       4531-EDIT-BEGIN-YR-FUND.
      *------------------------

           IF  MIR-BEG-YR-ACUM-AMT = SPACES
008455*        MOVE RIH-BEG-YR-ACUM-AMT     TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-BEG-YR-ACUM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RIH-BEG-YR-ACUM-AMT * 100
020874         MOVE RIH-BEG-YR-ACUM-AMT     TO L0290-INPUT-V02
008455         MOVE 2                       TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-BEG-YR-ACUM-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-BEG-YR-ACUM-AMT
               GO TO 4531-EDIT-BEGIN-YR-FUND-X
557660     END-IF.

           IF  MIR-BEG-YR-ACUM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+000000000.00'         TO MIR-BEG-YR-ACUM-AMT
008455         MOVE  ZEROS            TO MIR-BEG-YR-ACUM-AMT
557660     END-IF.

           MOVE 'Y'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 13                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-BEG-YR-ACUM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE MIR-BEG-YR-ACUM-AMT   TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE 'Y'               TO UPDATE-SW
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RIH-BEG-YR-ACUM-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-BEG-YR-ACUM-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-BEG-YR-ACUM-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-BEG-YR-ACUM-AMT
           ELSE
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS03110008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4531-EDIT-BEGIN-YR-FUND-X.
           EXIT.
      /
      *-------------------
       4532-EDIT-GUAR-INT.
      *-------------------

           IF  MIR-GUAR-INT-AMT = SPACES
008455*        MOVE RIH-GUAR-INT-AMT        TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-GUAR-INT-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RIH-GUAR-INT-AMT * 100
020874         MOVE RIH-GUAR-INT-AMT      TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-GUAR-INT-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-GUAR-INT-AMT
               GO TO 4532-EDIT-GUAR-INT-X
557660     END-IF.

           IF  MIR-GUAR-INT-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-GUAR-INT-AMT
008455         MOVE  ZEROS            TO MIR-GUAR-INT-AMT
557660     END-IF.

           MOVE 'Y'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-GUAR-INT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE MIR-GUAR-INT-AMT      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE 'Y'               TO UPDATE-SW
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RIH-GUAR-INT-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-GUAR-INT-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-GUAR-INT-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-GUAR-INT-AMT
           ELSE
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS03110009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4532-EDIT-GUAR-INT-X.
           EXIT.
      /
      *---------------------
       4533-EDIT-EXCESS-INT.
      *---------------------

           IF  MIR-XCES-INT-AMT = SPACES
008455*        MOVE RIH-XCES-INT-AMT        TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-XCES-INT-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RIH-XCES-INT-AMT * 100
020874         MOVE RIH-XCES-INT-AMT      TO L0290-INPUT-V02
008455         MOVE 2                     TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-XCES-INT-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY    TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-XCES-INT-AMT
               GO TO 4533-EDIT-EXCESS-INT-X
557660     END-IF.

           IF  MIR-XCES-INT-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+0000000.00'           TO MIR-XCES-INT-AMT
008455         MOVE  ZEROS            TO MIR-XCES-INT-AMT
557660     END-IF.

           MOVE 'Y'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 11                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-XCES-INT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE MIR-XCES-INT-AMT      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE 'Y'               TO UPDATE-SW
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RIH-XCES-INT-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S7-2
008455*        MOVE WS-DISP-S7-2            TO MIR-XCES-INT-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-XCES-INT-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-XCES-INT-AMT
           ELSE
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS03110010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4533-EDIT-EXCESS-INT-X.
           EXIT.
      /
      *----------------------
       4534-EDIT-COST-OF-INS.
      *----------------------

           IF  MIR-ISWL-ANNV-COI-AMT = SPACES
008455*        MOVE RIH-ISWL-ANNV-COI-AMT   TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-ISWL-ANNV-COI-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RIH-ISWL-ANNV-COI-AMT * 100
020874         MOVE RIH-ISWL-ANNV-COI-AMT      TO L0290-INPUT-V02
008455         MOVE 2                          TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-ISWL-ANNV-COI-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY         TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-ISWL-ANNV-COI-AMT
               GO TO 4534-EDIT-COST-OF-INS-X
557660     END-IF.

           IF  MIR-ISWL-ANNV-COI-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+000000000.00'         TO MIR-ISWL-ANNV-COI-AMT
008455         MOVE  ZEROS            TO MIR-ISWL-ANNV-COI-AMT
557660     END-IF.

           MOVE 'Y'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 13                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-ISWL-ANNV-COI-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE MIR-ISWL-ANNV-COI-AMT TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE 'Y'               TO UPDATE-SW
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RIH-ISWL-ANNV-COI-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-ISWL-ANNV-COI-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-ISWL-ANNV-COI-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-ISWL-ANNV-COI-AMT
           ELSE
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS03110011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4534-EDIT-COST-OF-INS-X.
           EXIT.
      /
      *
      *  EDIT LINE 4 OF IHST
      *

      *----------------------
       4541-EDIT-END-YR-FUND.
      *----------------------

           IF  MIR-YR-END-ACUM-AMT = SPACES
008455*        MOVE RIH-YR-END-ACUM-AMT     TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-YR-END-ACUM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RIH-YR-END-ACUM-AMT * 100
020874         MOVE RIH-YR-END-ACUM-AMT    TO L0290-INPUT-V02
008455         MOVE 2                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-YR-END-ACUM-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-YR-END-ACUM-AMT
               GO TO 4541-EDIT-END-YR-FUND-X
557660     END-IF.

           IF  MIR-YR-END-ACUM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+000000000.00'         TO MIR-YR-END-ACUM-AMT
008455         MOVE  ZEROS            TO MIR-YR-END-ACUM-AMT
557660     END-IF.

           MOVE 'Y'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 13                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-YR-END-ACUM-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE MIR-YR-END-ACUM-AMT   TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE 'Y'               TO UPDATE-SW
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RIH-YR-END-ACUM-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-YR-END-ACUM-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-YR-END-ACUM-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-YR-END-ACUM-AMT
           ELSE
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS03110012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4541-EDIT-END-YR-FUND-X.
           EXIT.
      /
      *-----------------------
       4542-EDIT-NET-CASH-VAL.
      *-----------------------

           IF  MIR-NET-CV-AMT = SPACES
008455*        MOVE RIH-NET-CV-AMT          TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-NET-CV-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RIH-NET-CV-AMT * 100
020874         MOVE RIH-NET-CV-AMT    TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-NET-CV-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-NET-CV-AMT
               GO TO 4542-EDIT-NET-CASH-VAL-X
557660     END-IF.

           IF  MIR-NET-CV-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+000000000.00'         TO MIR-NET-CV-AMT
008455         MOVE  ZEROS            TO MIR-NET-CV-AMT
557660     END-IF.

           MOVE 'Y'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 13                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-NET-CV-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE MIR-NET-CV-AMT        TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE 'Y'               TO UPDATE-SW
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RIH-NET-CV-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-NET-CV-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-NET-CV-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-NET-CV-AMT
           ELSE
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS03110013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4542-EDIT-NET-CASH-VAL-X.
           EXIT.
      /
      *------------------------
       4543-EDIT-DEATH-BENEFIT.
      *------------------------

           IF  MIR-ISWL-ANNV-DB-AMT = SPACES
008455*        MOVE RIH-ISWL-ANNV-DB-AMT    TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-ISWL-ANNV-DB-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RIH-ISWL-ANNV-DB-AMT * 100
020874         MOVE RIH-ISWL-ANNV-DB-AMT  TO L0290-INPUT-V02
008455         MOVE 2                     TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-ISWL-ANNV-DB-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY    TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-ISWL-ANNV-DB-AMT
               GO TO 4543-EDIT-DEATH-BENEFIT-X
557660     END-IF.

           IF  MIR-ISWL-ANNV-DB-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+000000000.00'         TO MIR-ISWL-ANNV-DB-AMT
008455         MOVE  ZEROS            TO MIR-ISWL-ANNV-DB-AMT
557660     END-IF.

           MOVE 'Y'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 13                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-ISWL-ANNV-DB-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE MIR-ISWL-ANNV-DB-AMT  TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE 'Y'               TO UPDATE-SW
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RIH-ISWL-ANNV-DB-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-ISWL-ANNV-DB-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-ISWL-ANNV-DB-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-ISWL-ANNV-DB-AMT
           ELSE
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS03110014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4543-EDIT-DEATH-BENEFIT-X.
           EXIT.
      /
      *-----------------------
       4544-EDIT-AVG-LOAN-BAL.
      *-----------------------

           IF  MIR-AVG-LOAN-BAL-AMT = SPACES
008455*        MOVE RIH-AVG-LOAN-BAL-AMT    TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-AVG-LOAN-BAL-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RIH-AVG-LOAN-BAL-AMT * 100
020874         MOVE RIH-AVG-LOAN-BAL-AMT    TO L0290-INPUT-V02
008455         MOVE 2                       TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-AVG-LOAN-BAL-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-AVG-LOAN-BAL-AMT
               GO TO 4544-EDIT-AVG-LOAN-BAL-X
557660     END-IF.

           IF  MIR-AVG-LOAN-BAL-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '+000000000.00'         TO MIR-AVG-LOAN-BAL-AMT
008455         MOVE  ZEROS            TO MIR-AVG-LOAN-BAL-AMT
557660     END-IF.

           MOVE 'Y'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 13                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-AVG-LOAN-BAL-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 4.
           MOVE MIR-AVG-LOAN-BAL-AMT  TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE 'Y'               TO UPDATE-SW
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RIH-AVG-LOAN-BAL-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-S9-2
008455*        MOVE WS-DISP-S9-2            TO MIR-AVG-LOAN-BAL-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-AVG-LOAN-BAL-AMT
                                      TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-AVG-LOAN-BAL-AMT
           ELSE
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS03110015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4544-EDIT-AVG-LOAN-BAL-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-DV-OWN-CLI-NM.
           MOVE SPACES                TO MIR-ISWL-ANNV-UPDT-DT.
           MOVE SPACES                TO MIR-POL-GRS-APREM-AMT.
           MOVE SPACES                TO MIR-NET-APREM-AMT.
           MOVE SPACES                TO MIR-ISWL-ANNV-STAT-CD.
           MOVE SPACES                TO MIR-DCLR-INT-RT.
           MOVE SPACES                TO MIR-DCLR-COI-RT.
           MOVE SPACES                TO MIR-BEG-YR-ACUM-AMT.
           MOVE SPACES                TO MIR-GUAR-INT-AMT.
           MOVE SPACES                TO MIR-XCES-INT-AMT.
           MOVE SPACES                TO MIR-ISWL-ANNV-COI-AMT.
           MOVE SPACES                TO MIR-YR-END-ACUM-AMT.
           MOVE SPACES                TO MIR-NET-CV-AMT.
           MOVE SPACES                TO MIR-ISWL-ANNV-DB-AMT.
           MOVE SPACES                TO MIR-AVG-LOAN-BAL-AMT.
011365     MOVE SPACES                TO MIR-ISWL-ANNV-MANL-IND.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *  MOVE FIELDS FROM IH RECORD TO MIR RECORD
      *

      *------------------------
       9300-MOVE-FIELDS-TO-MIR.
      *------------------------

      *
      *  SET UP MAP OUTPUT LINE1
      *
           MOVE WPOL-POL-ID           TO WCVG-POL-ID.
           MOVE 1                     TO WCVG-CVG-NUM-N.
           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X.
           IF  WCVG-IO-OK
               MOVE RCVG-CVG-INFO     TO WCVGS-CVG-INFO (1)
               MOVE RCVG-CVG-NUM      TO WCVGS-CVG-SEQ-NUM (1)
557668         MOVE 0                 TO I
               PERFORM  2430-1000-BUILD-PARM-INFO
                   THRU 2430-1000-BUILD-PARM-INFO-X
               PERFORM  2430-3100-GET-PRIM-INSRD
                   THRU 2430-3100-GET-PRIM-INSRD-X
557668*        MOVE L2430-CLI-NM-COMPRESSED  TO MIR-DV-OWN-CLI-NM

557668         INITIALIZE L0620-INPUT-PARM-INFO
557668         IF L2430-CLI-SEX-COMPANY
557668             MOVE L2430-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
557668         ELSE
557668             MOVE L2430-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
557668             MOVE L2430-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM
                                      TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM
                                      TO L0620-CLI-SFX-NM
557668         END-IF
557668         MOVE L2430-CLI-SEX-CD  TO L0620-CLI-SEX-CD

557668         PERFORM  0620-1000-FORMAT-SCREEN-NAME
557668             THRU 0620-1000-FORMAT-SCREEN-NAME-X

557668         MOVE L0620-SCREEN-NAME TO MIR-DV-OWN-CLI-NM

           ELSE
               MOVE '*** NO INSURED NAME ***'
                                      TO MIR-DV-OWN-CLI-NM
557660     END-IF.

           MOVE RIH-ISWL-ANNV-UPDT-DT TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-ISWL-ANNV-UPDT-DT.

      *
      *  SET UP MAP OUTPUT LINE2
      *
008455*    MOVE RIH-POL-GRS-APREM-AMT TO WS-HOLD-S9-2.
008455*    MOVE WS-DISP-S9-2          TO MIR-POL-GRS-APREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RIH-POL-GRS-APREM-AMT * 100.
020874     MOVE RIH-POL-GRS-APREM-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-GRS-APREM-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-GRS-APREM-AMT.
008455
008455*    MOVE RIH-NET-APREM-AMT     TO WS-HOLD-S7-2.
008455*    MOVE WS-DISP-S7-2          TO MIR-NET-APREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RIH-NET-APREM-AMT * 100.
020874     MOVE RIH-NET-APREM-AMT     TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-NET-APREM-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-NET-APREM-AMT.
008455
           MOVE RIH-ISWL-ANNV-STAT-CD TO MIR-ISWL-ANNV-STAT-CD.
           MOVE RIH-DCLR-INT-RT       TO WS-HOLD-S0-5.
           MOVE WS-DISP-S0-5          TO MIR-DCLR-INT-RT.
           MOVE RIH-DCLR-COI-RT       TO WS-HOLD-S4-5.
           MOVE WS-DISP-S4-5          TO MIR-DCLR-COI-RT.

      *
      *  SET UP MAP OUTPUT LINE3
      *
008455*    MOVE RIH-BEG-YR-ACUM-AMT   TO WS-HOLD-S9-2.
008455*    MOVE WS-DISP-S9-2          TO MIR-BEG-YR-ACUM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RIH-BEG-YR-ACUM-AMT * 100.
020874     MOVE RIH-BEG-YR-ACUM-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-BEG-YR-ACUM-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-BEG-YR-ACUM-AMT.
008455
008455*    MOVE RIH-GUAR-INT-AMT      TO WS-HOLD-S7-2.
008455*    MOVE WS-DISP-S7-2          TO MIR-GUAR-INT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RIH-GUAR-INT-AMT * 100.
020874     MOVE RIH-GUAR-INT-AMT      TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-GUAR-INT-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-GUAR-INT-AMT.
008455
008455*    MOVE RIH-XCES-INT-AMT      TO WS-HOLD-S7-2.
008455*    MOVE WS-DISP-S7-2          TO MIR-XCES-INT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RIH-XCES-INT-AMT * 100.
020874     MOVE RIH-XCES-INT-AMT      TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-XCES-INT-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-XCES-INT-AMT.
008455
008455*    MOVE RIH-ISWL-ANNV-COI-AMT TO WS-HOLD-S9-2.
008455*    MOVE WS-DISP-S9-2          TO MIR-ISWL-ANNV-COI-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RIH-ISWL-ANNV-COI-AMT * 100.
020874     MOVE RIH-ISWL-ANNV-COI-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-ISWL-ANNV-COI-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-ISWL-ANNV-COI-AMT.

      *
      *  SET UP MAP OUTPUT LINE4
      *
008455*    MOVE RIH-YR-END-ACUM-AMT   TO WS-HOLD-S9-2.
008455*    MOVE WS-DISP-S9-2          TO MIR-YR-END-ACUM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RIH-YR-END-ACUM-AMT * 100.
020874     MOVE RIH-YR-END-ACUM-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-YR-END-ACUM-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-YR-END-ACUM-AMT.
008455
008455*    MOVE RIH-NET-CV-AMT        TO WS-HOLD-S9-2.
008455*    MOVE WS-DISP-S9-2          TO MIR-NET-CV-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RIH-NET-CV-AMT * 100.
020874     MOVE RIH-NET-CV-AMT        TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-NET-CV-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-NET-CV-AMT.
008455
008455*    MOVE RIH-ISWL-ANNV-DB-AMT  TO WS-HOLD-S9-2.
008455*    MOVE WS-DISP-S9-2          TO MIR-ISWL-ANNV-DB-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RIH-ISWL-ANNV-DB-AMT * 100.
020874     MOVE RIH-ISWL-ANNV-DB-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-ISWL-ANNV-DB-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-ISWL-ANNV-DB-AMT.
008455
008455*    MOVE RIH-AVG-LOAN-BAL-AMT  TO WS-HOLD-S9-2.
008455*    MOVE WS-DISP-S9-2          TO MIR-AVG-LOAN-BAL-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RIH-AVG-LOAN-BAL-AMT * 100.
020874     MOVE RIH-AVG-LOAN-BAL-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-AVG-LOAN-BAL-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET L0290-SIGN-DISPLAY     TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-AVG-LOAN-BAL-AMT.
011365*
011365     MOVE RIH-ISWL-ANNV-MANL-IND        TO MIR-ISWL-ANNV-MANL-IND.
010418*
010418     MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.

       9300-MOVE-FIELDS-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9450-SETUP-MSIN-REFERENCE.
      *--------------------------

            MOVE SPACES               TO WGLOB-MSIN-REFERENCE.
            MOVE WGLOB-COMPANY-CODE   TO WGLOB-REF-COMPANY-CODE.
            MOVE 'P'                  TO WGLOB-REF-POLICY-OR-CLIENT.
            MOVE MIR-POL-ID-BASE      TO WGLOB-REF-POLICY-NUMBER.
            MOVE MIR-POL-ID-SFX       TO WGLOB-REF-POLICY-SUFFIX.

       9450-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  MISCELLANEOUS-WORK-AREAS.
025970     INITIALIZE  SUBSCRIPT-AREA.
025970     INITIALIZE  WS-NUMERIC-DISPLAY-FIELDS.
025970     INITIALIZE  WS-NUM-EDIT-OUTPUT.
025970     INITIALIZE  WS-NUM-EDIT-13V5.
025970     INITIALIZE  WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE  WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
026057 COPY CCPPIHSD.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
025970 COPY XCPS1670.
025970 COPY XCPS8090.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1680.
005409 COPY XCPL1680.
      /
016108 COPY CCPS0985.
018764*COPY CCCL0985.
018764 COPY CCPL0985.
       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
008455/
008455 COPY XCPS0290.
008455 COPY XCPL0290.
      /
016108 COPY NCPPCVGS.
016108/
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
018764*COPY CCCLIH.
018764 COPY CCPLIH.
       COPY CCPNIH.
       COPY CCPUIH.
      /
       COPY CCPNCVG.
      /
       COPY CCPNPOL.
014221 COPY CCPUPOL.
025970 COPY CCPS0620.
557668 COPY CCPL0620.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0311                     **
      *****************************************************************


