      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM1250.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM1250                                         **
      **  REMARKS:  UWDE - RECORD UNDERWRITING DECISIONS FOR CLIENTS **
      **            AND PENDING COVERAGES/MAINTAIN COVERAGE          **
      **            INFORMATION.                                     **
      **            THIS TRANSACTION ALLOWS THE USER TO RECORD       **
      **            SEPARATE DECISIONS FOR EACH CLIENT AND FOR EACH  **
      **            OF THE CLIENT'S PENDING COVERAGES. A VARIETY OF  **
      **            DIFFERENT COVERAGE INFORMATION CAN ALSO BE       **
      **            MAINTAINED. THE POLICY STATUS WILL AUTOMATICALLY **
      **            BE UPDATED AND IF THERE ARE NO OUTSTANDING       **
      **            ISSUE OR UNDERWRITING REQUIREMENTS, THE POLICY   **
      **            WILL AUTOMATICALLY BE ISSUED.                    **
      **                                                             **
      **  DOMAIN : UW                                                **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP/STANDARDIZATION                     **
557671**  5.5       ADD TRUE TABLE RATING CODE                       **
557708**  5.5       ABEND HANDLING                                   **
557767**  5.5       JOINT AGE CALCULATION                            **
557788**  5.5       POLICY TABLE SPLIT (SUSPENDED)                   **
557973**  5.5       AMOUNT FIELD SIZING FOR INTERNATIONAL USE        **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
012138**  5.6V      ADDING SEC GAP CALCULATIONS                      **
012148**  5.6V      WRITING AGENTS MOVED FROM POL TO POLW            **
012624**  6.0       SECURITY                                         **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       GLOBAL MESSAGING                                 **
014221**  6.2       LOGICAL LOCKING                                  **
015918**  6.2       GUIDELINE PREMIUMS                               **
016387**  6.2       REMOVAL OF CLIENT CONSOLIDATION                  **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017518**  6.2       CVG-STAT-CD NOT BEING UPDATED AFTER SETTLE       **
017570**  6.2       ALLOW UPDATE OF COVERAGE DECISION FROM A* TO *E  **
018278**  6.2       ADD SCROLL                                       **
015951**  6.3       DISABILITY RIDERS ON TRAD POLICIES (6.1.1E)      **
016641**  6.3       EXTENSIVE NUMERIC FORMATTING                     **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019982**  6.3       PCR FOR IIAB PLATFORM                            **
018691**  6.4       99 COVERAGES                                     **
018633**  6.4       TWRK CLEANUP                                     **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025388**  6.6       DATABASE CLEANUP                                 **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
027105**  6.6       99 COVERAGES HANDLING                            **
026766**  6.6       PERFORMANCE MONITORING                           **
024187**  6.7       REMOVE DATE ROUTINE LIMIT                        **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
031037**  7.0       TAMRA OFF ANNIVERSARY PROCESSING                 **
032329**  7.0       99 COVERAGES AND 98 FUNDS HANDLING               **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
026149**  7.1       STOP ISSUE OF NEW COVERAGE WITH PACKAGING ERRORS **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM1250'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

028298 COPY CCWL2626.
       COPY XCWL8090.
014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'UWDE'.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-VALID          VALUE '1250' '1252'.
               88  WS-BUS-FCN-RETRIEVE       VALUE '1250'.
               88  WS-BUS-FCN-UPDATE         VALUE '1252'.
013578*        88  WS-BUS-FCN-LIST           VALUE '1254'.
016548*    05  WS-SUB                       PIC S9(4)  COMP.
016548     05  WS-SUB                       PIC S9(4)  BINARY.
016548*    05  WS-IDX                       PIC S9(4)  COMP.
016548     05  WS-IDX                       PIC S9(4)  BINARY.
027105*    05  WS-CVG                       PIC 99.
027105     05  WS-CVG                       PIC 9(03).
007766*    05  WS-CVG-SUB                   PIC 99.
007766     05  WS-CVG-SUB                   PIC 999.
           05  WS-DISPLAY-START             PIC 9(3).
025970*    05  WS-NO-DISPLAY-LINES          PIC S9(3)  COMP-3
013578*                                                VALUE +5.
025970*                                                VALUE +20.
027105     05  WS-NO-DISPLAY-LINES          PIC S9(3)  COMP-3.
           05  WS-LINE                      PIC S9(3)  COMP-3.
025970*    05  WS-FIRST-PENDING-CVG-IND     PIC X(01) VALUE 'Y'.
025970     05  WS-FIRST-PENDING-CVG-IND     PIC X(01).
025970         88  WS-DEFAULT-FIRST-PEND-CVG-IND
025970                                      VALUE 'Y'.
016440         88 WS-FIRST-PENDING-CVG-YES  VALUE 'Y'.
016440         88 WS-FIRST-PENDING-CVG-NO   VALUE 'N'.
025970*    05  WS-FIRST-APPRV-CVG-IND       PIC X(01) VALUE 'N'.
025970     05  WS-FIRST-APPRV-CVG-IND       PIC X(01).
025970         88 WS-DEFAULT-FIRST-APPRV-CVG
025970                                      VALUE 'N'.
016440         88 WS-FIRST-APPRV-CVG-YES    VALUE 'Y'.
016440         88 WS-FIRST-APPRV-CVG-NO     VALUE 'N'.
016440     05  WS-CVG-UWGDECN-SUB-CD        PIC X(02).
016440         88 WS-CVG-UWGDECN-VALID      VALUE 'DC' 'FC' 'NP'
016440                                            'NT' 'PP'.
           05  WS-HIDDEN-SCREEN             PIC 9(2)   VALUE ZEROES.
           05  WS-SKIP                      PIC 9(3)   VALUE ZEROES.
           05  WS-PIC-ZZ9                   PIC ZZ9    VALUE ZEROES.
           05  WS-PIC-LEN3                  PIC 9(3)   VALUE ZEROES.
           05  WS-PIC-LEN4                  PIC 9.99   VALUE ZEROES.
008455*    05  WS-PIC-LEN6                  PIC 9(3).99 VALUE ZEROES.
008455*    05  WS-PIC-LEN9                  PIC 9(9)   VALUE ZEROES.
008455*    05  WS-PIC-LEN9Z                 PIC Z(8)9  VALUE ZEROES.
008455*    05  WS-PIC-LEN12                 PIC 9(9).99 VALUE ZEROES.
013578     05  WS-PIC-LEN11                 PIC S9(07)V99 VALUE ZEROES.
013578*    05  WS-PIC-LEN16                 PIC 9(13).99 VALUE ZEROES.
013578     05  WS-PIC-LEN16                 PIC 9(16) VALUE ZEROES.
           05  WS-PREV-POLICY               PIC X(10)  VALUE SPACES.
           05  WS-LAST-POL-CHEKD            PIC X(10)  VALUE SPACES.
           05  WS-CHECKS-FAILED             PIC X(01).
               88  SW-CHECKS-FAILED         VALUE  '1'.
           05  WS-CRSR-SET                  PIC X(01)  VALUE SPACES.
               88  SW-CRSR-SET              VALUE  'Y'.
               88  SW-NO-CRSR-SET           VALUE  'N'.
032329*    05  WS-PREV-UWGDECN-CD           PIC X(02)  OCCURS 20 TIMES.
032329     05  WS-PREV-UWGDECN-CD           PIC X(02)  OCCURS 99 TIMES.
007766*    05  WS-PREV-UWGDECN-CD           PIC X(02)  OCCURS 99 TIMES.
           05  WS-DECISION                  PIC X(02)  VALUE SPACES.
           05  WS-DECISION-OVLY             REDEFINES WS-DECISION.
               10  WS-DECISION-1            PIC X(01).
               10  WS-DECISION-2            PIC X(01).
           05  WS-MIR-DECISION              PIC X(02)  VALUE SPACES.
           05  WS-MIR-DECISION-OVLY         REDEFINES WS-MIR-DECISION.
               10  WS-MIR-DECISION-1        PIC X(01).
                   88  WS-MIR-DECISION-1-ACCEPTED      VALUE 'A'.
                   88  WS-MIR-DECISION-1-PENDING       VALUE 'P'.
                   88  WS-MIR-DECISION-1-DECLINED      VALUE 'D'.
               10  WS-MIR-DECISION-2        PIC X(01).
017570     05  WS-DECISION-APPROVED         PIC X(02).
017570         88 WS-DECISION-APPROVED-VALID
017570                                      VALUE 'AA' 'AC' 'AE'.
017570     05  WS-DECISION-ELMNT-UW         PIC X(02).
017570         88 WS-DECISION-ELMNT-UW-VALID
017570                                      VALUE 'PE' 'DE'.
           05  WS-MIR-POLICY.
               10  WS-MIR-POLICY-NUM        PIC X(09)  VALUE SPACES.
               10  WS-MIR-POLICY-SUF        PIC X(01)  VALUE SPACES.
025970*    05  WS-INSURED-FOUND             PIC X(01)  VALUE 'N'.
025970     05  WS-INSURED-FOUND             PIC X(01).
               88  WS-DEFAULT-INSURED-SW    VALUE 'N'.
               88  SW-INSURED-FOUND         VALUE 'Y'.
025970*    05  WS-COVERAGE-FOUND            PIC X(01)  VALUE 'N'.
025970     05  WS-COVERAGE-FOUND            PIC X(01).
025970         88  WS-DEFAULT-COVERAGE-SW   VALUE 'N'.
018278         88  SW-COVERAGE-FOUND        VALUE 'Y'.
           05  WS-CONTROL-ERROR             PIC X(01).
               88  SW-CONTROL-ERROR         VALUE 'Y'.
               88  SW-NO-CONTROL-ERROR      VALUE 'N'.
025970*    05  WS-COVERAGE-ERRORS           PIC X(01)  VALUE 'N'.
025970     05  WS-COVERAGE-ERRORS           PIC X(01).
025970         88  WS-DEFAULT-COVERAGE-ERRORS-SW
025970                                      VALUE 'N'.
               88  SW-COVERAGE-ERRORS       VALUE 'Y'.
025970*    05  WS-WITHIN-UW-LIMIT           PIC X(01)  VALUE 'N'.
025970     05  WS-WITHIN-UW-LIMIT           PIC X(01).
025970         88  WS-DEFAULT-WITHIN-UW-LIMIT
025970                                      VALUE 'N'.
               88  SW-WITHIN-UW-LIMIT       VALUE 'Y'.
025970*    05  WS-EDIT-ERROR                PIC X(01)  VALUE 'N'.
025970     05  WS-EDIT-ERROR                PIC X(01).
025970         88  WS-DEFAULT-EDIT-ERROR    VALUE 'N'.
               88  SW-EDIT-ERROR            VALUE 'Y'.
025970*    05  WS-AMMENDMENT-REQD-SW        PIC X(01)  VALUE 'N'.
025970     05  WS-AMMENDMENT-REQD-SW        PIC X(01).
025970         88  WS-DEFAULT-AMMENDMENT-REQD-SW
025970                                      VALUE 'N'.
               88  WS-AMMENDMENT-REQD       VALUE 'Y'.
025970*    05  WS-FIRST-TIME-THRU-SW        PIC X(01)  VALUE 'N'.
025970     05  WS-FIRST-TIME-THRU-SW        PIC X(01).
025970         88  WS-DEFAULT-FIRST-TIME-THRU-SW
025970                                      VALUE 'N'.
               88  WS-FIRST-TIME-THRU       VALUE 'Y'.
025970*    05  WS-CLIENT-DEC-CHG-SW         PIC X(01)  VALUE 'N'.
025970     05  WS-CLIENT-DEC-CHG-SW         PIC X(01).
025970         88  WS-DEFAULT-CLIENT-DEC-CHG-SW
025970                                      VALUE 'N'.
               88  WS-CLIENT-DEC-CHG        VALUE 'Y'.
               88  WS-CLIENT-DEC-NOT-CHG    VALUE 'N'.
025970*    05  WS-READ-POL-FOR-UPDATE-SW    PIC X(01)  VALUE 'N'.
025970     05  WS-READ-POL-FOR-UPDATE-SW    PIC X(01).
025970         88  WS-DEFAULT-READ-POL-UPDT-SW
025970                                      VALUE 'N'.
               88  WS-READ-POL-FOR-UPDATE   VALUE 'Y'.
014221         88  WS-READ-POL-FOR-UPDATE-NO VALUE 'N'.
025970*    05  WS-REWRITE-POL-SW            PIC X(01)  VALUE 'N'.
025970     05  WS-REWRITE-POL-SW            PIC X(01).
025970         88  WS-DEFAULT-REWRITE-POL-SW
025970                                      VALUE 'N'.
014221         88  WS-REWRITE-POL           VALUE 'Y'.
014221         88  WS-REWRITE-POL-NO        VALUE 'N'.
012138     05  WS-REWRITE-CVGS-SW           PIC X(01).
012138         88  WS-REWRITE-CVGS          VALUE 'Y'.
012138         88  WS-REWRITE-CVGS-NO       VALUE 'N'.
           05  WS-RL-IO-STATUS              PIC 9(01).
               88  WS-RL-IO-EOF             VALUE 8.
018278         88  WS-RL-IO-OK              VALUE ZERO.
557973*    05  WS-UW-AMOUNT                 PIC S9(11)V99 COMP-3.
557973     05  WS-UW-AMOUNT                 PIC S9(13)V99 COMP-3.
           05  WS-HOLD-CVG-STAT             PIC X(03)  VALUE SPACES.
           05  WS-SAVE-POLICY               PIC X(10) VALUE SPACES.
           05  WS-POLICY-TABLE.
               10  WS-POLICY-ARRAY          PIC X(10) OCCURS 10 TIMES.
           05  WS-POL-SUB                   PIC S9(04) COMP-3
                                            VALUE ZERO.
025970*    05  WS-POLICY-ERROR-SW           PIC X(01) VALUE 'N'.
025970     05  WS-POLICY-ERROR-SW           PIC X(01).
025970         88  WS-DEFAULT-POLICY-ERROR-SW
025970                                      VALUE 'N'.
               88  WS-POLICY-ERROR          VALUE 'Y'.
025970*    05  WS-POLICY-FOUND-SW           PIC X(01) VALUE 'N'.
025970     05  WS-POLICY-FOUND-SW           PIC X(01).
025970         88  WS-DEFAULT-POLICY-FOUND-SW
025970                                      VALUE 'N'.
               88  WS-POLICY-FOUND          VALUE 'Y'.
           05  WS-CVG-FOUND-SW              PIC X(01).
               88  WS-CVG-FOUND             VALUE 'Y'.
               88  WS-CVG-NOT-FOUND         VALUE 'N'.
           05  WS-CLI-READ-IND              PIC X(01).
               88  WS-CLI-READ-REQD         VALUE 'N'.
               88  WS-CLI-READ-DONE         VALUE 'Y'.
           05  WS-POL-EDIT-ERR-SW           PIC X(01).
               88  WS-POL-EDIT-ERR          VALUE 'Y'.
               88  WS-POL-EDIT-ERR-NO       VALUE 'N'.
015951     05  WS-HEALTH-PRODUCT-SW         PIC X(01).
015951         88 WS-HEALTH-POL-OR-CVG-FOUND      VALUE 'Y'.
015951         88 WS-HEALTH-POL-CVG-NOT-FOUND     VALUE 'N'.

      *
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-DEFAULT-TRANS-NAME               VALUE 'UWDE'.
      *
013578*    05  WS-CLI-SUR-NM-1-4            PIC X(04).
018633*    05  WS-TWRK-KEY                  PIC X(04) VALUE '1250'.
018633*    05  WS-WORK-AREA.
018633*        10 WS-CLIENT-NUMBER          PIC X(10).
018633*        10 WS-PROGRAM-NUMBER         PIC X(04).
018633*        10 WS-SCREEN-DISPLAYED       PIC X(02).
018633*        10 WS-SCREEN-MAX-IND         PIC X(01).
018633*        10 WS-CLI-DECN               PIC X(02).
018633*        10 WS-CLI-DECN-TYP           PIC X(02).
018633*        10 WS-CVG-DECN.
018633*           15 WS-CVG-DECN-ARRAY      PIC X(02) OCCURS 20 TIMES.
018633*        10 WS-CVG-DECN-SUB.
018633*           15 WS-CVG-DECN-SUB-ARRAY  PIC X(02) OCCURS 20 TIMES.
018633*        10 WS-PLAN-ID.
018633*           15 WS-PLAN-ID-ARRAY       PIC X(06) OCCURS 20 TIMES.
018633*        10 WS-CVG-FACE-AMT.
018633*           15 WS-CVG-FACE-AMT-ARRAY  PIC X(16) OCCURS 20 TIMES.
018633*        10 WS-CVG-AD-FACE-AMT.
018633*           15 WS-CVG-AD-FACE-AMT-ARRAY
018633*                                     PIC X(16) OCCURS 20 TIMES.
018633*        10 WS-CVG-AD-MULT-FCT.
018633*           15 WS-CVG-AD-MULT-FCT-ARRAY
018633*                                     PIC X(04) OCCURS 20 TIMES.
018633*        10 WS-CVG-WP-MULT-FCT.
018633*           15 WS-CVG-WP-MULT-FCT-ARRAY
018633*                                     PIC X(04) OCCURS 20 TIMES.
018633*        10 WS-CVG-STBL-1.
018633*           15 WS-CVG-STBL-1-ARRAY  PIC X(02) OCCURS 20 TIMES.
018633*        10 WS-CVG-STBL-2.
018633*           15 WS-CVG-STBL-2-ARRAY  PIC X(03) OCCURS 20 TIMES.
018633*        10 WS-CVG-STBL-3.
018633*           15 WS-CVG-STBL-3-ARRAY  PIC X(05) OCCURS 20 TIMES.
018633*        10 WS-CVG-STBL-4.
018633*           15 WS-CVG-STBL-4-ARRAY   PIC X(03) OCCURS 20 TIMES.
018633*        10 WS-CVG-ENHC-TYP.
018633*           15 WS-CVG-ENHC-TYP-ARRAY PIC X(01) OCCURS 20 TIMES.
018633*        10 WS-CVG-ME-FCT.
018633*           15 WS-CVG-ME-FCT-ARRAY    PIC X(04) OCCURS 20 TIMES.
018633*        10 WS-CVG-ME-RAT.
018633*           15 WS-CVG-ME-RAT-ARRAY  PIC X(02) OCCURS 20 TIMES.
018633*        10 WS-CVG-ME-REASN.
018633*           15 WS-CVG-ME-REASN-ARRAY PIC X(01) OCCURS 20 TIMES.
018633*        10 WS-CVG-COLA-SELCT.
018633*           15 WS-CVG-COLA-SELCT-ARRAY PIC X(01) OCCURS 20 TIMES.
018633*        10 WS-REDC-EP-SELCT.
018633*           15 WS-REDC-EP-SELCT-ARRAY  PIC X(01) OCCURS 20 TIMES.
018633*        10 WS-OWN-OCCP-SELCT.
018633*           15 WS-OWN-OCCP-SELCT-ARRAY PIC X(01) OCCURS 20 TIMES.
018633*        10 WS-CVG-LTA-SELCT.
018633*           15 WS-CVG-LTA-SELCT-ARRAY PIC X(01) OCCURS 20 TIMES.
018633*        10 WS-CVG-LTB-SELCT.
018633*           15 WS-CVG-LTB-SELCT-ARRAY PIC X(01) OCCURS 20 TIMES.
018633*        10 WS-PDISAB-SELCT.
018633*           15 WS-PDISAB-SELCT-ARRAY  PIC X(01) OCCURS 20 TIMES.
018633*        10 WS-CVG-UWG-EXCL-1.
018633*           15 WS-CVG-UWG-EXCL-1-ARRAY PIC X(03) OCCURS 20 TIMES.
018633*        10 WS-CVG-UWG-EXCL-2.
018633*           15 WS-CVG-UWG-EXCL-2-ARRAY PIC X(03) OCCURS 20 TIMES.
018633*        10 WS-CVG-UWG-EXCL-3.
018633*           15 WS-CVG-UWG-EXCL-3-ARRAY PIC X(03) OCCURS 20 TIMES.
018633*        10 WS-CVG-ME-DUR.
018633*           15 WS-CVG-ME-DUR-ARRAY     PIC X(03) OCCURS 20 TIMES.
018633*        10 WS-CVG-FE-UPREM-AMT.
018633*           15 WS-CVG-FE-UPREM-AMT-ARRAY
018633*                                      PIC X(11) OCCURS 20 TIMES.
018633*        10 WS-CVG-FE-REASN.
018633*           15 WS-CVG-FE-REASN-ARRAY   PIC X(01) OCCURS 20 TIMES.
018633*        10 WS-CVG-FE-DUR.
018633*           15 WS-CVG-FE-DUR-ARRAY PIC X(03) OCCURS 20 TIMES.
018633*        10 WS-CVG-RT-AGE.
018633*           15 WS-CVG-RT-AGE-ARRAY  PIC X(03) OCCURS 20 TIMES.
018633*        10 WS-AGE-RAT-REASN.
018633*           15 WS-AGE-RAT-REASN-ARRAY  PIC X(01) OCCURS 20 TIMES.
018633*        10 WS-CVG-SMKR.
018633*           15 WS-CVG-SMKR-ARRAY PIC X(01) OCCURS 20 TIMES.
018633*        10 WS-CVG-SEX.
018633*           15 WS-CVG-SEX-ARRAY PIC X(01) OCCURS 20 TIMES.
018633*        10 WS-CVG-UWG-AMT.
018633*           15 WS-CVG-UWG-AMT-ARRAY PIC X(16) OCCURS 20 TIMES.
018633*        10 WS-UWG-AMT-REASN.
018633*           15 WS-UWG-AMT-REASN-ARRAY PIC X(01) OCCURS 20 TIMES.
018633*        10 WS-LO-RL-KEY.
018633*            15  WS-LO-CO-ID                   PIC X(02).
018633*            15  WS-LO-CLI-ID                  PIC X(10).
018633*            15  WS-LO-REL-SYS-ID              PIC X(08).
018633*            15  WS-LO-REL-SYS-REF-ID          PIC X(12).
018633*            15  WS-LO-REL-SYS-REF-ID-R        REDEFINES
018633*                WS-LO-REL-SYS-REF-ID.
018633*                20  WS-LO-REL-SYS-REF-POL-ID  PIC X(10).
018633*                20  WS-LO-REL-SYS-REF-CVG-NUM PIC X(02).
018633*            15  WS-LO-REL-TYP-CD              PIC X(01).
018633*        10 WS-HI-RL-KEY.
018633*            15  WS-HI-CO-ID                   PIC X(02).
018633*            15  WS-HI-CLI-ID                  PIC X(10).
018633*            15  WS-HI-REL-SYS-ID              PIC X(08).
018633*            15  WS-HI-REL-SYS-REF-ID          PIC X(12).
018633*            15  WS-HI-REL-SYS-REF-ID-R        REDEFINES
018633*                WS-HI-REL-SYS-REF-ID.
018633*                20  WS-HI-REL-SYS-REF-POL-ID  PIC X(10).
018633*                20  WS-HI-REL-SYS-REF-CVG-NUM PIC X(02).
018633*            15  WS-HI-REL-TYP-CD              PIC X(01).
018633*
018633 COPY XCWLCOMM REPLACING '$VAR1' BY '1250'.
018633     15 LCOMM-CLIENT-NUMBER       PIC X(10).
018633     15 LCOMM-PROGRAM-NUMBER      PIC X(04).
018633     15 LCOMM-SCREEN-DISPLAYED    PIC X(02).
018633     15 LCOMM-SCREEN-MAX-IND      PIC X(01).
018633     15 LCOMM-CLI-DECN            PIC X(02).
018633     15 LCOMM-CLI-DECN-TYP        PIC X(02).
032329*    15 LCOMM-CVG-TBL             OCCURS 20 TIMES.
032329     15 LCOMM-CVG-TBL             OCCURS 99 TIMES.
018633        20 LCOMM-CVG-DECN-T             PIC X(02).
018633        20 LCOMM-CVG-DECN-SUB-T         PIC X(02).
018633        20 LCOMM-PLAN-ID-T              PIC X(06).
018633        20 LCOMM-CVG-FACE-AMT-T         PIC X(16).
018633        20 LCOMM-CVG-AD-FACE-AMT-T      PIC X(16).
018633        20 LCOMM-CVG-AD-MULT-FCT-T      PIC X(04).
018633        20 LCOMM-CVG-WP-MULT-FCT-T      PIC X(04).
018633        20 LCOMM-CVG-STBL-1-T           PIC X(02).
018633        20 LCOMM-CVG-STBL-2-T           PIC X(03).
018633        20 LCOMM-CVG-STBL-3-T           PIC X(05).
018633        20 LCOMM-CVG-STBL-4-T           PIC X(03).
018633        20 LCOMM-CVG-ENHC-TYP-T         PIC X(01).
018633        20 LCOMM-CVG-ME-FCT-T           PIC X(04).
018633        20 LCOMM-CVG-ME-RAT-T           PIC X(02).
018633        20 LCOMM-CVG-ME-REASN-T         PIC X(01).
018633        20 LCOMM-CVG-COLA-SELCT-T       PIC X(01).
018633        20 LCOMM-REDC-EP-SELCT-T        PIC X(01).
018633        20 LCOMM-OWN-OCCP-SELCT-T       PIC X(01).
018633        20 LCOMM-CVG-LTA-SELCT-T        PIC X(01).
018633        20 LCOMM-CVG-LTB-SELCT-T        PIC X(01).
018633        20 LCOMM-PDISAB-SELCT-T         PIC X(01).
018633        20 LCOMM-CVG-UWG-EXCL-1-T       PIC X(03).
018633        20 LCOMM-CVG-UWG-EXCL-2-T       PIC X(03).
018633        20 LCOMM-CVG-UWG-EXCL-3-T       PIC X(03).
018633        20 LCOMM-CVG-ME-DUR-T           PIC X(03).
018633        20 LCOMM-CVG-FE-UPREM-AMT-T     PIC X(11).
018633        20 LCOMM-CVG-FE-REASN-T         PIC X(01).
018633        20 LCOMM-CVG-FE-DUR-T           PIC X(03).
018633        20 LCOMM-CVG-RT-AGE-T           PIC X(03).
018633        20 LCOMM-AGE-RAT-REASN-T        PIC X(01).
018633        20 LCOMM-CVG-SMKR-T             PIC X(01).
018633        20 LCOMM-CVG-SEX-T              PIC X(01).
018633        20 LCOMM-CVG-UWG-AMT-T          PIC X(16).
018633        20 LCOMM-UWG-AMT-REASN-T        PIC X(01).
018633     15 LCOMM-LO-RL-KEY.
018633         20  LCOMM-LO-CO-ID                PIC X(02).
018633         20  LCOMM-LO-CLI-ID               PIC X(10).
018633         20  LCOMM-LO-REL-SYS-ID           PIC X(08).
018633         20  LCOMM-LO-REL-SYS-REF-ID       PIC X(12).
018633         20  LCOMM-LO-REL-SYS-REF-ID-R     REDEFINES
018633             LCOMM-LO-REL-SYS-REF-ID.
018633             25  LCOMM-LO-REL-SYS-REF-POL-ID PIC X(10).
018633             25  LCOMM-LO-REL-SYS-REF-CVG-NUM PIC X(02).
018633         20  LCOMM-LO-REL-TYP-CD           PIC X(01).
018633     15 LCOMM-HI-RL-KEY.
018633         20  LCOMM-HI-CO-ID                PIC X(02).
018633         20  LCOMM-HI-CLI-ID               PIC X(10).
018633         20  LCOMM-HI-REL-SYS-ID           PIC X(08).
018633         20  LCOMM-HI-REL-SYS-REF-ID       PIC X(12).
018633         20  LCOMM-HI-REL-SYS-REF-ID-R     REDEFINES
018633             LCOMM-HI-REL-SYS-REF-ID.
018633             25  LCOMM-HI-REL-SYS-REF-POL-ID PIC X(10).
018633             25  LCOMM-HI-REL-SYS-REF-CVG-NUM PIC X(02).
018633         20  LCOMM-HI-REL-TYP-CD           PIC X(01).
018633
025970 01  WS-TEMP-AREA.
018278     05  WS-TMP-MIR-LIST-ENTRY.
018278         10  WS-TMP-CVG-NUM                 PIC X(02).
018278         10  WS-TMP-CVG-CSTAT-CD            PIC X(03).
018278         10  WS-TMP-CVG-FACE-AMT            PIC X(16).
018278         10  WS-TMP-PLAN-ID                 PIC X(06).
018278         10  WS-TMP-POL-ID-BASE             PIC X(09).
018278         10  WS-TMP-POL-ID-SFX              PIC X(01).
018278         10  WS-TMP-CVG-AD-FACE-AMT         PIC X(16).
018278         10  WS-TMP-CVG-AD-MULT-FCT         PIC X(04).
018278         10  WS-TMP-CVG-UWG-AMT             PIC X(16).
018278         10  WS-TMP-CVG-COLA-SELCT-CD       PIC X(01).
018278         10  WS-TMP-CVG-ENHC-TYP-CD         PIC X(01).
018278         10  WS-TMP-CVG-UWG-EXCL-1-CD       PIC X(03).
018278         10  WS-TMP-CVG-UWG-EXCL-2-CD       PIC X(03).
018278         10  WS-TMP-CVG-UWG-EXCL-3-CD       PIC X(03).
018278         10  WS-TMP-CVG-FE-DUR              PIC X(03).
018278         10  WS-TMP-CVG-FE-UPREM-AMT        PIC X(11).
018278         10  WS-TMP-CVG-FE-REASN-CD         PIC X(01).
018278         10  WS-TMP-REDC-EP-SELCT-IND       PIC X(01).
025388*        10  WS-TMP-CVG-LIVES-INSRD-CD      PIC X(01).
025388         10  WS-TMP-LIVES-INSRD-QTY         PIC X(01).
018278         10  WS-TMP-CVG-LTA-SELCT-IND       PIC X(01).
018278         10  WS-TMP-CVG-LTB-SELCT-IND       PIC X(01).
018278         10  WS-TMP-CVG-ME-RAT-CD           PIC X(02).
018278         10  WS-TMP-CVG-ME-DUR              PIC X(03).
018278         10  WS-TMP-OWN-OCCP-SELCT-IND      PIC X(01).
018278         10  WS-TMP-CVG-PREV-FACE-AMT       PIC X(16).
018278         10  WS-TMP-PDISAB-SELCT-IND        PIC X(01).
018278         10  WS-TMP-LINK-POL-ISS-IND        PIC X(01).
018278         10  WS-TMP-POL-OPTL-CD             PIC X(01).
018278         10  WS-TMP-CVG-RT-AGE              PIC X(03).
018278         10  WS-TMP-AGE-RAT-REASN-CD        PIC X(01).
018278         10  WS-TMP-CVG-ME-REASN-CD         PIC X(01).
018278         10  WS-TMP-CVG-SPND-CSTAT-CD       PIC X(03).
018278         10  WS-TMP-CVG-SEX-CD              PIC X(01).
018278         10  WS-TMP-CVG-SMKR-CD             PIC X(01).
018278         10  WS-TMP-CVG-SUPP-BNFT-CD        PIC X(01).
018278         10  WS-TMP-CVG-STBL-1-CD           PIC X(02).
018278         10  WS-TMP-CVG-STBL-2-CD           PIC X(03).
018278         10  WS-TMP-CVG-STBL-3-CD           PIC X(05).
018278         10  WS-TMP-CVG-STBL-4-CD           PIC X(03).
018278         10  WS-TMP-CVG-UWGDECN-CD          PIC X(02).
018278         10  WS-TMP-CVG-UWGDECN-SUB-CD      PIC X(02).
018278         10  WS-TMP-CVG-ME-FCT              PIC X(04).
018278         10  WS-TMP-UWG-AMT-REASN-CD        PIC X(01).
018278         10  WS-TMP-CVG-WP-MULT-FCT         PIC X(04).
018278     05  WS-TMP1-TWRK-LIST-ENTRY.
018278         10  WS-TMP1-CVG-DECN               PIC X(02).
018278         10  WS-TMP1-CVG-DECN-SUB           PIC X(02).
018278         10  WS-TMP1-PLAN-ID                PIC X(06).
018278         10  WS-TMP1-CVG-FACE-AMT           PIC X(16).
018278         10  WS-TMP1-CVG-AD-FACE-AMT        PIC X(16).
018278         10  WS-TMP1-CVG-AD-MULT-FCT        PIC X(04).
018278         10  WS-TMP1-CVG-WP-MULT-FCT        PIC X(04).
018278         10  WS-TMP1-CVG-STBL-1             PIC X(02).
018278         10  WS-TMP1-CVG-STBL-2             PIC X(03).
018278         10  WS-TMP1-CVG-STBL-3             PIC X(05).
018278         10  WS-TMP1-CVG-STBL-4             PIC X(03).
018278         10  WS-TMP1-CVG-ENHC-TYP           PIC X(01).
018278         10  WS-TMP1-CVG-ME-FCT             PIC X(04).
018278         10  WS-TMP1-CVG-ME-RAT             PIC X(02).
018278         10  WS-TMP1-CVG-ME-REASN           PIC X(01).
018278         10  WS-TMP1-CVG-COLA-SELCT         PIC X(01).
018278         10  WS-TMP1-REDC-EP-SELCT          PIC X(01).
018278         10  WS-TMP1-OWN-OCCP-SELCT         PIC X(01).
018278         10  WS-TMP1-CVG-LTA-SELCT          PIC X(01).
018278         10  WS-TMP1-CVG-LTB-SELCT          PIC X(01).
018278         10  WS-TMP1-PDISAB-SELCT           PIC X(01).
018278         10  WS-TMP1-CVG-UWG-EXCL-1         PIC X(03).
018278         10  WS-TMP1-CVG-UWG-EXCL-2         PIC X(03).
018278         10  WS-TMP1-CVG-UWG-EXCL-3         PIC X(03).
018278         10  WS-TMP1-CVG-ME-DUR             PIC X(03).
018278         10  WS-TMP1-CVG-FE-UPREM-AMT       PIC X(11).
018278         10  WS-TMP1-CVG-FE-REASN           PIC X(01).
018278         10  WS-TMP1-CVG-FE-DUR             PIC X(03).
018278         10  WS-TMP1-CVG-RT-AGE             PIC X(03).
018278         10  WS-TMP1-AGE-RAT-REASN          PIC X(01).
018278         10  WS-TMP1-CVG-SMKR               PIC X(01).
018278         10  WS-TMP1-CVG-SEX                PIC X(01).
018278         10  WS-TMP1-CVG-UWG-AMT            PIC X(16).
018278         10  WS-TMP1-UWG-AMT-REASN          PIC X(01).
018278
018278     05  WS-LIST-SCROLL-SW                  PIC X(01).
018278         88  WS-LIST-REFRESH                VALUE SPACE.
018278         88  WS-LIST-BCKWRD                 VALUE 'B'.
018278         88  WS-LIST-FORWRD                 VALUE 'F'.
018278         88  WS-LIST-RELOAD                 VALUE 'R'.
018278
014221     05  WS-NEW-POL-SW                      PIC X(01).
018278         88  WS-NEW-POL                     VALUE 'Y'.
018278         88  WS-NEW-POL-NO                  VALUE 'N'.
      *
      *****************************************************************
      * COMMON COPYBOOKS
      *****************************************************************

       COPY CCWWINDX.
      *
       COPY XCWWWKDT.
014221 COPY CCWWLOCK.
       COPY XCWEBLCH.
      *
      *
      *****************************************************************
      * I/O    COPYBOOKS
      *****************************************************************

       COPY CCFWRL.
       COPY CCFRRL.
      *
014221 COPY CCFWCLI.
014221 COPY CCFRCLI.
      *
       COPY CCFWEDIT.
       COPY CCFREDIT.
      *
       COPY CCFWCVG.
       COPY CCFRCVG.
      *
       COPY CCFHPOL.
       COPY CCFWPOL.
      *
      *****************************************************************
      * CALLED PARAMETER INFORMATION
      *****************************************************************
013578 COPY CCWL0620.
      *
016440 COPY NCWL0303.
      *
016440 COPY NCWL6410.
      *
016440 COPY CCWL5150.
      *
016503 COPY CCWL0289.
      *
016440 COPY CCWL2222.
      *
016440 COPY CCWL2400.
016440 COPY CCWL2520.
      *
       COPY CCWL0570.
      *
       COPY CCWL0953.
      *
       COPY CCWL2450.
      *
557788 COPY CCWL2470.
      *
015918*COPY CCWL5300.
      *
       COPY CCWL5400.
      *
       COPY CCWL5440.
      *
       COPY CCWL5600.
      *
       COPY CCWL6060.
      *
012148 COPY CCWL8240.
      *
031037*COPY CCWL8300.
031037*
       COPY NCWL0700.
      *
       COPY NCWL0760.
      *
       COPY NCWL1251.
      *
       COPY NCWL1255.
      *
       COPY NCWL1390.
      *
       COPY NCWL2437.
      *
       COPY XCWL1510.
      *
       COPY XCWL1670.
       COPY XCWL1680.
       COPY XCWLDTLK.
      *
      *
008455 COPY XCWL0290.
008455*
013578 COPY XCWL0280.
      *
      *****************************************************************
      * INPUT PARAMETER
      *****************************************************************

007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
      *
       COPY CCFRPOL.
      *
       COPY CCWWCVGS.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM1250.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

018633     PERFORM  COMM-1000-INITIALIZE
018633         THRU COMM-1000-INITIALIZE-X.
018633
019982     INITIALIZE L2222-PARM-INFO.

           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.
      *

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.

      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------
      *
      *   INITIALISE VARIABLES NEEDED FOR THIS TRANSACTION
      *

025970*    MOVE MIR-BUS-FCN-ID    TO WS-BUS-FCN-ID.
018633*    MOVE SPACES            TO WS-WORK-AREA.
018633*
018278     EVALUATE TRUE
018278
018278         WHEN WS-BUS-FCN-UPDATE
018278              SET WS-LIST-RELOAD      TO TRUE
018278
018278         WHEN MIR-DV-BCKWRD-SCROLL
018278              SET WS-LIST-BCKWRD      TO TRUE
018278
018278         WHEN MIR-DV-REFRESH-SCROLL
018278              SET WS-LIST-REFRESH     TO TRUE
018278
018278         WHEN MIR-DV-FORWRD-SCROLL
018278              SET WS-LIST-FORWRD      TO TRUE
018278
018278         WHEN OTHER
018278              SET WS-LIST-REFRESH     TO TRUE
018278
018278     END-EVALUATE.
018278
008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.
           PERFORM  2100-INITIALISE
               THRU 2100-INITIALISE-X.
      *
      *   VALIDATE THE CONTROL FIELDS ENTERED
      *
557660     PERFORM  2500-VALIDATE-CONTROL-FIELDS
557660         THRU 2500-VALIDATE-CONTROL-FIELDS-X.

           IF SW-CONTROL-ERROR
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
557660     END-IF.

           IF SW-CONTROL-ERROR
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

      *
      *   BUILD REQUIRED PARMS
      *
           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

      *
      *   PROCESS TRANSACTION BASED ON ENTER CODE
      *

014221
014221     MOVE ZEROS                 TO WLOCK-IDX.
014221     INITIALIZE                 WLOCK-MULT-TWRK-TS-TABLE.

           EVALUATE TRUE


                WHEN WS-BUS-FCN-RETRIEVE

                   PERFORM  3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X


                WHEN WS-BUS-FCN-UPDATE

                   PERFORM  5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

                WHEN OTHER

      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                   MOVE MIR-BUS-FCN-ID
                                     TO WGLOB-MSG-PARM (1)
                   MOVE 'NSOM1250'
                                     TO WGLOB-MSG-PARM (2)
                   MOVE 'XS00000237' TO  WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-INVALD-RQST TO TRUE
           END-EVALUATE.

      *
       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *-----------------
       2100-INITIALISE.
      *-----------------
      *
      *   INITIALISE WORK VARIABLES
      *
           SET  WGLOB-GOOD-RETURN    TO TRUE.
018278*    MOVE 1                     TO WS-LINE.
018278     MOVE ZERO                  TO WS-LINE.
           MOVE SPACES                TO WS-PREV-POLICY.
           MOVE SPACES                TO WS-LAST-POL-CHEKD.

018633*    PERFORM 9700-RETRIEVE-TWRK
018633*       THRU 9700-RETRIEVE-TWRK-X.
018633     PERFORM COMM-1000-RETRIEVE-TWRK
018633        THRU COMM-1000-RETRIEVE-TWRK-X.

018633*    IF L8090-RETRN-OK
018633*       MOVE L8090-AREA-INFO-TEXT TO WS-WORK-AREA
018633*    END-IF.
018633*
           IF  MIR-CLI-ID  =  SPACES
018633*        MOVE  WS-CLIENT-NUMBER
018633         MOVE  LCOMM-CLIENT-NUMBER
                                      TO  MIR-CLI-ID
557660     END-IF.

018633*    PERFORM 9900-DELETE-TWRK
018633*       THRU 9900-DELETE-TWRK-X.
018633     PERFORM COMM-3000-DELETE-TWRK
018633        THRU COMM-3000-DELETE-TWRK-X.

      *
      *   SET UP MESSAGE VARIABLES
      *
           PERFORM  9300-SETUP-MSIN-REFERENCE-1
               THRU 9300-SETUP-MSIN-REFERENCE-1-X.

       2100-INITIALISE-X.
           EXIT.
      *
      *-----------------------------
557660 2500-VALIDATE-CONTROL-FIELDS.
      *-----------------------------
      *
      *   VALIDATE CONTROL FIELDS: VALIDATE THE CLIENT AND SCROLL
      *   VALUES ENTERED.
      *
           SET SW-NO-CONTROL-ERROR TO TRUE.
           SET SW-NO-CRSR-SET      TO TRUE.

      *
      *   DETERMINE IF THE CLIENT RECORD EXISTS
      *   CHECK CLIENT CONFIDENTIALITY AND CLEAR CASE STATUS
      *
           PERFORM 5600-0000-INIT-PARM-INFO
              THRU 5600-0000-INIT-PARM-INFO-X.

           PERFORM 5600-1000-BUILD-PARM-INFO
              THRU 5600-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID            TO L5600-CLI-ID.
           SET L5600-CCAS-MSG-NOT-REQD   TO TRUE.
016387*    SET L5600-CNSLDT-MSG-NOT-REQD TO TRUE.

           PERFORM 5600-1000-CLI-CHK
              THRU 5600-1000-CLI-CHK-X.

           IF L5600-RETRN-CLI-NOT-FOUND
               SET SW-CRSR-SET      TO TRUE
               SET SW-CONTROL-ERROR TO TRUE
           END-IF.

           IF L5600-CNFD-ACCS-RESTRICTED
              SET SW-CONTROL-ERROR TO TRUE
           END-IF.

           IF L5600-CCAS-ACCS-RESTRICTED
              MOVE 'XS00000199'       TO WGLOB-MSG-REF-INFO
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
              IF WGLOB-MSG-SEVRTY-FATAL
                 SET SW-CONTROL-ERROR TO TRUE
              END-IF
           END-IF.

014221* LOGICAL LOCKING -
014221* GET THE TIMESTAMP FOR THE CLIENT RECORD

014221     MOVE MIR-CLI-ID            TO WCLI-CLI-ID.

014221     IF  WS-BUS-FCN-UPDATE
014221         PERFORM  CLI-2000-UPDATE-TWRK-TS
014221             THRU CLI-2000-UPDATE-TWRK-TS-X
014221     ELSE
014221         PERFORM  CLI-1000-READ-TWRK-TS
014221             THRU CLI-1000-READ-TWRK-TS-X
014221     END-IF.
014221
014221     IF  NOT WCLI-IO-OK
014221         MOVE WCLI-KEY     TO WGLOB-MSG-PARM (1)
014221*MSG: CLIENT (@1) DOES NOT EXIST
014221         MOVE 'XS00000076' TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         SET SW-CONTROL-ERROR TO TRUE
014221         GO TO 2500-VALIDATE-CONTROL-FIELDS-X
014221     END-IF.
014221
014221     IF  WS-BUS-FCN-UPDATE
014221         IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221             MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221             MOVE 'CLI'                 TO WGLOB-MSG-PARM (01)
014221             MOVE WCLI-KEY              TO WGLOB-MSG-PARM (02)
014221             PERFORM  0260-1000-GENERATE-MESSAGE
014221                 THRU 0260-1000-GENERATE-MESSAGE-X
014221            GO TO 2500-VALIDATE-CONTROL-FIELDS-X
014221         ELSE
014221            PERFORM  CLI-3000-UNLOCK
014221                THRU CLI-3000-UNLOCK-X
014221         END-IF
014221     END-IF.
      *
      * GET CLIENT INFO
      *
           MOVE MIR-CLI-ID            TO L2437-CLI-ID.
           PERFORM  2437-1000-OBTAIN-CLI-INFO
              THRU  2437-1000-OBTAIN-CLI-INFO-X.
           IF L2437-RETRN-OK
013578*       MOVE L2437-CLI-SUR-NM             TO WS-CLI-SUR-NM-1-4
013578        INITIALIZE                  L0620-INPUT-PARM-INFO
013578        MOVE L2437-CLI-ENTR-GIV-NM        TO L0620-CLI-GIV-NM
013578        MOVE L2437-CLI-ENTR-SUR-NM        TO L0620-CLI-SUR-NM
013578        MOVE L2437-CLI-MID-INIT-NM  TO L0620-CLI-MID-INIT-NM
013578        MOVE L2437-CLI-SFX-NM       TO L0620-CLI-SFX-NM
013578        MOVE L2437-CLI-SEX-CD       TO L0620-CLI-SEX-CD
013578        PERFORM 0620-1000-FORMAT-SCREEN-NAME
013578           THRU 0620-1000-FORMAT-SCREEN-NAME-X
013578        MOVE L0620-SCREEN-NAME      TO MIR-DV-INSRD-CLI-NM
           ELSE
              IF L2437-RETRN-CLI-NOT-FOUND
                 MOVE L2437-WCLI-KEY  TO WGLOB-MSG-PARM (1)
                 MOVE 'XS00000076'    TO WGLOB-MSG-REF-INFO
                 PERFORM 0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
                 SET SW-CONTROL-ERROR  TO TRUE
557660           GO TO 2500-VALIDATE-CONTROL-FIELDS-X
              END-IF
           END-IF.

           SET WS-CLI-READ-DONE        TO TRUE.

      *
      *   DETERMINE IF PROCESSING A NEW CLIENT, OR FIRST TIME IN
      *   UPDATE THE CLIENT NUMBER IN THE COMMON AREA
      *
018633*    IF  MIR-CLI-ID            NOT =  WS-CLIENT-NUMBER
018633*    OR  WGLOB-MAIN-PGM-NUMBER NOT =  WS-PROGRAM-NUMBER
018633*        MOVE  SPACES           TO  WS-SCREEN-DISPLAYED
018633*        MOVE  SPACES           TO  WS-SCREEN-MAX-IND
018633     IF  MIR-CLI-ID            NOT =  LCOMM-CLIENT-NUMBER
018633     OR  WGLOB-MAIN-PGM-NUMBER NOT =  LCOMM-PROGRAM-NUMBER
018633         MOVE  SPACES           TO  LCOMM-SCREEN-DISPLAYED
018633         MOVE  SPACES           TO  LCOMM-SCREEN-MAX-IND
               IF  WGLOB-MSG-ERROR-SW = ZERO
018633*            MOVE MIR-CLI-ID    TO WS-CLIENT-NUMBER
018633             MOVE MIR-CLI-ID    TO LCOMM-CLIENT-NUMBER
               END-IF
           END-IF.


      *
      *   DETERMINE THE SCREEN TO DISPLAY AND, AS A RESULT, THE NUMBER
      *   OF RECORDS TO PRE-READ BEFORE STARTING THE PROCESSING
      *
018633*    IF  WS-SCREEN-DISPLAYED = SPACES
018633     IF  LCOMM-SCREEN-DISPLAYED = SPACES
               MOVE ZEROS             TO WS-HIDDEN-SCREEN
               MOVE +1                TO WS-SKIP
               GO TO 2500-VALIDATE-CONTROL-FIELDS-X
           END-IF.

      *
      *   IN MAINTAIN, DISPLAY THE SAME DATA
      *
018633*    MOVE WS-SCREEN-DISPLAYED              TO WS-HIDDEN-SCREEN.
018633     MOVE LCOMM-SCREEN-DISPLAYED           TO WS-HIDDEN-SCREEN.
           IF  WS-BUS-FCN-UPDATE
            OR WS-BUS-FCN-RETRIEVE
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
018633*        IF WS-SCREEN-MAX-IND = SPACES
018633         IF LCOMM-SCREEN-MAX-IND = SPACES
                   ADD 1 TO WS-HIDDEN-SCREEN
               END-IF
           END-IF.

           COMPUTE WS-SKIP = WS-HIDDEN-SCREEN * WS-NO-DISPLAY-LINES
                             + 1.

557660 2500-VALIDATE-CONTROL-FIELDS-X.
           EXIT.
      *
      *
      *-----------------------
       3000-PROCESS-RETRIEVE.
      *-----------------------
      *
      *    VERIFY RECORD EXISTS, DISPLAY FIELDS AND
      *    DATA FIELD MODIFICATION.
      *
      *   BLANK OUT THE LAST DISPLAY.
      *
018633*    PERFORM  9900-DELETE-TWRK
018633*        THRU 9900-DELETE-TWRK-X.
018633     PERFORM  COMM-3000-DELETE-TWRK
018633         THRU COMM-3000-DELETE-TWRK-X.
014221
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.
018278*
018278*   DISPLAY THE CLIENT INFORMATION ON THE SCREEN
018278*
018278*    PERFORM  8000-DISPLAY-CLIENT
018278*        THRU 8000-DISPLAY-CLIENT-X.
018278*
018278*   ALWAYS BROWSE FROM THE BEGINNING OF THE RELATIONSHIP FILE
018278*
018278*    MOVE SPACES                TO WRL-KEY.
018278*    MOVE MIR-CLI-ID            TO WRL-CLI-ID.
018278*    MOVE WGLOB-SYS-CTL-ID      TO WRL-REL-SYS-ID.
018278*
018278*    MOVE HIGH-VALUES           TO WRL-ENDBR-KEY.
018278*    MOVE MIR-CLI-ID            TO WRL-ENDBR-CLI-ID.
018278*    MOVE WGLOB-SYS-CTL-ID      TO WRL-ENDBR-REL-SYS-ID.
018278*
018278*   DISPLAY THE COVERAGE INFORMATION ON THE SCREEN
018278*   IF A BLANK DISPLAY IS CREATED AND SCREEN NUMBER IS GREATER
018278*   THAN ONE THEN WE HAVE GONE PAST THE LAST DISPLAY.
018278*
018278*
018278*    PERFORM  8100-DISPLAY-COVERAGES
018278*        THRU 8100-DISPLAY-COVERAGES-X.
018278*
018278     PERFORM  5100-DISPLAY-SCREEN
018278         THRU 5100-DISPLAY-SCREEN-X.
018278
018278     IF  WS-LIST-BCKWRD
018278         PERFORM  5200-REVERSE-LIST
018278             THRU 5200-REVERSE-LIST-X
018278     END-IF.
018278
018278*    IF WS-LINE = 1
018278*        MOVE MIR-CLI-ID        TO WGLOB-MSG-PARM (1)
018278*MSG:    NO RECORDS TO DISPLAY FOR CLIENT @1
018278*        MOVE 'NS12500001'      TO WGLOB-MSG-REF-INFO
018278*    ELSE
018278*        IF WS-RL-IO-EOF
018278*            MOVE 'XS00000015'  TO WGLOB-MSG-REF-INFO
018278*        ELSE
018278*            MOVE 'XS00000014'
018278*                           TO WGLOB-MSG-REF-INFO
018278*            SET WGLOB-MORE-DATA-EXISTS TO TRUE
018278*        END-IF
018278*    END-IF.
018278*
018278     EVALUATE TRUE
018278
018278         WHEN WS-LINE = ZERO
018278*MSG: NO RECORDS TO DISPLAY FOR CLIENT @1
018278              MOVE MIR-CLI-ID        TO WGLOB-MSG-PARM (1)
018278              MOVE 'NS12500001'      TO WGLOB-MSG-REF-INFO
018278
018278         WHEN WS-RL-IO-EOF
018278          AND MIR-DV-BCKWRD-SCROLL
018278*MSG: 'TOP OF LIST'
018278              MOVE 'XS00000245'      TO WGLOB-MSG-REF-INFO
018278
018278         WHEN WS-RL-IO-EOF
018278*MSG: 'END OF LIST'
018278              MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
018278
018278         WHEN OTHER
018278              MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
018278              SET WGLOB-MORE-DATA-EXISTS TO TRUE
018278
018278     END-EVALUATE.
018278
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.


018633*     MOVE MIR-CLI-UWGDECN-CD      TO WS-CLI-DECN.
018633*     MOVE MIR-CLI-UWGDECN-TYP-CD  TO WS-CLI-DECN-TYP.
018633      MOVE MIR-CLI-UWGDECN-CD      TO LCOMM-CLI-DECN.
018633      MOVE MIR-CLI-UWGDECN-TYP-CD  TO LCOMM-CLI-DECN-TYP.
018633*
018633*
018633*     MOVE WS-WORK-AREA      TO L8090-AREA-INFO-TEXT.

018633*    PERFORM 9800-WRITE-TWRK
018633*       THRU 9800-WRITE-TWRK-X.
018633     PERFORM COMM-2000-WRITE-TWRK
018633        THRU COMM-2000-WRITE-TWRK-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.

013578*------------
013578*3500-PROCESS-LIST.
013578*------------
013578*
013578*
013578*   BROWSE  PROCESSING: DISPLAY CLIENT INFORMATION AND COVERAGE
013578*   BLANK OUT THE LAST DISPLAY.
013578*
013578*    PERFORM  9100-BLANK-DATA-FIELDS
013578*        THRU 9100-BLANK-DATA-FIELDS-X.
013578*
013578*   DISPLAY THE CLIENT INFORMATION ON THE SCREEN
013578*
013578*    PERFORM  8000-DISPLAY-CLIENT
013578*        THRU 8000-DISPLAY-CLIENT-X.
013578*
013578*   ALWAYS BROWSE FROM THE BEGINNING OF THE RELATIONSHIP FILE
013578*
013578*    MOVE SPACES                TO WRL-KEY.
013578*    MOVE MIR-CLI-ID            TO WRL-CLI-ID.
013578*    MOVE 'NEWBUS'              TO WRL-REL-SYS-ID.
013578*
013578*    MOVE HIGH-VALUES           TO WRL-ENDBR-KEY.
013578*    MOVE MIR-CLI-ID            TO WRL-ENDBR-CLI-ID.
013578*    MOVE 'NEWBUS'              TO WRL-ENDBR-REL-SYS-ID.
013578*
013578*   DISPLAY THE COVERAGE INFORMATION ON THE SCREEN
013578*   IF A BLANK DISPLAY IS CREATED AND SCREEN NUMBER IS GREATER
013578*   THAN ONE THEN WE HAVE GONE PAST THE LAST DISPLAY.
013578*
013578*    PERFORM  8100-DISPLAY-COVERAGES
013578*        THRU 8100-DISPLAY-COVERAGES-X.
013578*
013578*   COMPLETION MESSAGE
013578*   EITHER NO RECORDS WERE FOUND FOR THE CLIENT, OR BROWSE WAS
013578*   COMPLETED OR MORE DATA TO VIEW.
013578*
013578*    MOVE WS-HIDDEN-SCREEN      TO WS-SCREEN-DISPLAYED.
013578*
013578*    IF WS-LINE = 1
013578*        MOVE MIR-CLI-ID        TO WGLOB-MSG-PARM (1)
013578*MSG:    NO RECORDS TO BE DISPLAYED
013578*        MOVE 'NS12500014'      TO WGLOB-MSG-REF-INFO
013578*    ELSE
013578*        IF WS-RL-IO-EOF
013578*            MOVE 'XS00000015'  TO WGLOB-MSG-REF-INFO
013578*            MOVE 'Y'           TO WS-SCREEN-MAX-IND
013578*        ELSE
013578*            MOVE SPACES    TO WS-SCREEN-MAX-IND
013578*            MOVE 'XS00000014'
013578*                           TO WGLOB-MSG-REF-INFO
013578*            SET WGLOB-MORE-DATA-EXISTS TO TRUE
013578*        END-IF
013578*    END-IF.
013578*
013578*    MOVE WS-WORK-AREA      TO L8090-AREA-INFO-TEXT.
013578*
013578*    PERFORM 9800-WRITE-TWRK
013578*       THRU 9800-WRITE-TWRK-X.
013578*
013578*    PERFORM  0260-1000-GENERATE-MESSAGE
013578*        THRU 0260-1000-GENERATE-MESSAGE-X.
013578*
013578*3500-PROCESS-LIST-X.
013578*    EXIT.
      *
      *----------------
       5000-PROCESS-UPDATE.
      *----------------
      *
013578*   ONLY THE ASSIGNED UNDERWRITER IS ALLOWED TO MAINTAIN.
013578*
013578     IF L2437-CLI-UW-USER-2-ID = SPACES
013578         IF L2437-CLI-UW-USER-1-ID  NOT = WGLOB-USER-ID
013578*MSG:        USER NOT ALLOWED TO MAINTAIN
013578             MOVE 'NS12500018'  TO WGLOB-MSG-REF-INFO
013578             PERFORM  0260-1000-GENERATE-MESSAGE
013578                 THRU 0260-1000-GENERATE-MESSAGE-X
013578             PERFORM 5100-DISPLAY-SCREEN
013578                THRU 5100-DISPLAY-SCREEN-X
018633*            MOVE WS-WORK-AREA  TO L8090-AREA-INFO-TEXT
018633*            PERFORM  9800-WRITE-TWRK
018633*                THRU 9800-WRITE-TWRK-X
018633             PERFORM  COMM-2000-WRITE-TWRK
018633                 THRU COMM-2000-WRITE-TWRK-X
013578             GO TO 5000-PROCESS-UPDATE-X
034802*        ELSE
034802*            NEXT SENTENCE
013578         END-IF
013578     ELSE
013578         IF L2437-CLI-UW-USER-2-ID  NOT = WGLOB-USER-ID
013578*MSG:        USER NOT ALLOWED TO MAINTAIN
013578             MOVE 'NS12500018'  TO WGLOB-MSG-REF-INFO
013578             PERFORM  0260-1000-GENERATE-MESSAGE
013578                 THRU 0260-1000-GENERATE-MESSAGE-X
013578             PERFORM 5100-DISPLAY-SCREEN
013578                THRU 5100-DISPLAY-SCREEN-X
018633*            MOVE WS-WORK-AREA  TO L8090-AREA-INFO-TEXT
018633*            PERFORM  9800-WRITE-TWRK
018633*                THRU 9800-WRITE-TWRK-X
018633             PERFORM  COMM-2000-WRITE-TWRK
018633                 THRU COMM-2000-WRITE-TWRK-X
013578             GO TO 5000-PROCESS-UPDATE-X
               END-IF
           END-IF.

           INITIALIZE WS-RL-IO-STATUS.

      *
      *   EDIT THE UNDERWRITER'S UNDERWRITING LIMITS
      *
           PERFORM  5212-EDIT-UW-LIMIT
               THRU 5212-EDIT-UW-LIMIT-X.
      *
      *
      *   EDIT AND ANALYSE THE COVERAGES ENTERED ON THE SCREEN
      *   (KEEP TRACK OF ANY COVERAGE ERRORS FROM EITHER THE COVERAGE
      *    EDIT MODULE OR THE COVERAGE DECISION EDITS)
      *
           MOVE 'N'                   TO WS-COVERAGE-ERRORS.


013578*  FROM WHAT IS STORED IN TWRK, CHECK TO SEE WHICH FIELDS HAVE
013578*  UPDATED.  MOVE SPACES TO FIELDS THAT HAVEN'T BEEN CHANGED
013578*  TO PREVENT THEM FROM GOING THROUGH EDIT PROCESSING.

013578     PERFORM  8300-CHECK-UPDATE-FIELDS
013578        THRU  8300-CHECK-UPDATE-FIELDS-X
013578              VARYING WS-IDX FROM 1 BY 1
013578              UNTIL WS-IDX > WS-NO-DISPLAY-LINES.

018633*    IF WS-CLI-DECN = MIR-CLI-UWGDECN-CD
018633     IF LCOMM-CLI-DECN = MIR-CLI-UWGDECN-CD
013578        MOVE SPACES TO MIR-CLI-UWGDECN-CD
013578     END-IF.

018633*    IF WS-CLI-DECN-TYP = MIR-CLI-UWGDECN-TYP-CD
018633     IF LCOMM-CLI-DECN-TYP = MIR-CLI-UWGDECN-TYP-CD
013578        MOVE SPACES TO MIR-CLI-UWGDECN-TYP-CD
013578     END-IF.

014221     PERFORM  POL-3000-SET-MNTS-TWRK-TS
014221         THRU POL-3000-SET-MNTS-TWRK-TS-X.

           PERFORM  8400-PROCESS-COVERAGES
               THRU 8400-PROCESS-COVERAGES-X
                    VARYING WS-IDX FROM 1 BY 1
014221*             UNTIL WS-IDX > WS-NO-DISPLAY-LINES.
014221              UNTIL WS-IDX > WS-NO-DISPLAY-LINES
014221                 OR WGLOB-RETURN-ERROR.
014221
014221     IF  WGLOB-RETURN-ERROR
018633*        MOVE WS-WORK-AREA          TO L8090-AREA-INFO-TEXT
018633*        PERFORM 9800-WRITE-TWRK
018633*           THRU 9800-WRITE-TWRK-X
018633         PERFORM COMM-2000-WRITE-TWRK
018633            THRU COMM-2000-WRITE-TWRK-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.
014221
      *
      *   REWRITE THE POLICY RECORD IF REQUIRED.
      *
           IF  WS-REWRITE-POL
               PERFORM  8912-REWRITE-POLICY
                   THRU 8912-REWRITE-POLICY-X
           END-IF.
      *
      *   EDIT AND PROCESS THE CLIENT DECISION
      *
           PERFORM  8500-CLIENT-DECISION
               THRU 8500-CLIENT-DECISION-X.
      *
      *   PERFORM PREM CALC, POLICY ANALYSIS AND ISSUE PROCESSING
      *
           PERFORM 8525-ATTEMPT-ISSUE
              THRU 8525-ATTEMPT-ISSUE-X.
      *
      *   EXIT FROM MAINTAIN MODE WHEN MAINTENANCE IS SUCCESSFUL
      *
           IF SW-COVERAGE-ERRORS
           OR SW-EDIT-ERROR
      *MSG: RECORD UPDATED
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
           ELSE
018278*        SET WS-BUS-FCN-RETRIEVE TO TRUE
      *MSG: MAINTENANCE COMPLETED - CONTINUE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

      *
      *   DISPLAY CLIENT INFO
      *
           IF  WS-CLI-READ-REQD
               MOVE MIR-CLI-ID        TO L2437-CLI-ID
               PERFORM  2437-1000-OBTAIN-CLI-INFO
                  THRU  2437-1000-OBTAIN-CLI-INFO-X
           END-IF.

           PERFORM 8000-DISPLAY-CLIENT
              THRU 8000-DISPLAY-CLIENT-X.

           IF WS-RL-IO-EOF
018633*        MOVE SPACES            TO WS-SCREEN-DISPLAYED
018633         MOVE SPACES            TO LCOMM-SCREEN-DISPLAYED
           END-IF.
018633*
018633*    MOVE WS-WORK-AREA          TO L8090-AREA-INFO-TEXT

018633*    PERFORM 9800-WRITE-TWRK
018633*       THRU 9800-WRITE-TWRK-X.
018633     PERFORM COMM-2000-WRITE-TWRK
018633        THRU COMM-2000-WRITE-TWRK-X.
014221
014221     PERFORM  POL-2000-BUILD-MNTS-TWRK
014221         THRU POL-2000-BUILD-MNTS-TWRK-X.
014221
014221
       5000-PROCESS-UPDATE-X.
           EXIT.
      *
013578*-------------------
013578 5100-DISPLAY-SCREEN.
013578*-------------------
013578
013578     PERFORM  8000-DISPLAY-CLIENT
013578         THRU 8000-DISPLAY-CLIENT-X.
018278*
018278*   ALWAYS BROWSE FROM THE BEGINNING OF THE RELATIONSHIP FILE
018278*
018278*    MOVE SPACES                TO WRL-KEY.
018278*    MOVE MIR-CLI-ID            TO WRL-CLI-ID.
018278*    MOVE WGLOB-SYS-CTL-ID      TO WRL-REL-SYS-ID.
018278*
018278*    MOVE HIGH-VALUES           TO WRL-ENDBR-KEY.
018278*    MOVE MIR-CLI-ID            TO WRL-ENDBR-CLI-ID.
018278*    MOVE WGLOB-SYS-CTL-ID      TO WRL-ENDBR-REL-SYS-ID.
018278*
018278     MOVE LOW-VALUES            TO WRL-KEY.
018278     MOVE MIR-CLI-ID            TO WRL-CLI-ID.
018278     MOVE WGLOB-SYS-CTL-ID      TO WRL-REL-SYS-ID.
018278
018278     MOVE HIGH-VALUES           TO WRL-ENDBR-KEY.
018278     MOVE MIR-CLI-ID            TO WRL-ENDBR-CLI-ID.
018278     MOVE WGLOB-SYS-CTL-ID      TO WRL-ENDBR-REL-SYS-ID.
018278
018278     EVALUATE TRUE
018278
018278         WHEN WS-LIST-RELOAD
018633*             MOVE WS-LO-RL-KEY  TO WRL-KEY
018633              MOVE LCOMM-LO-RL-KEY TO WRL-KEY
018278
018278         WHEN WS-LIST-FORWRD
018278              PERFORM  5110-GET-NEXT-FORWRD-KEY
018278                  THRU 5110-GET-NEXT-FORWRD-KEY-X
018278
018278         WHEN WS-LIST-BCKWRD
018278              PERFORM  5120-GET-NEXT-BCKWRD-KEY
018278                  THRU 5120-GET-NEXT-BCKWRD-KEY-X
018278
018278     END-EVALUATE.
018278
013578     PERFORM  8100-DISPLAY-COVERAGES
013578         THRU 8100-DISPLAY-COVERAGES-X.
013578
013578
013578 5100-DISPLAY-SCREEN-X.
013578     EXIT.
018278
018278*-------------------------
018278 5110-GET-NEXT-FORWRD-KEY.
018278*-------------------------
018278
018633*    MOVE WS-HI-RL-KEY       TO WRL-KEY.
018633     MOVE LCOMM-HI-RL-KEY    TO WRL-KEY.
018278
018278     MOVE HIGH-VALUES        TO WRL-ENDBR-KEY.
018278     MOVE MIR-CLI-ID         TO WRL-ENDBR-CLI-ID.
018278     MOVE WGLOB-SYS-CTL-ID   TO WRL-ENDBR-REL-SYS-ID.
018278
018278     PERFORM  RL-1000-BROWSE
018278         THRU RL-1000-BROWSE-X.
018278
018278     PERFORM
018278         VARYING I FROM 1 BY 1
018278         UNTIL I > 2
018278         OR NOT WRL-IO-OK
018278
018278         PERFORM  RL-2000-READ-NEXT
018278             THRU RL-2000-READ-NEXT-X
018278         IF  WRL-IO-OK
018278             CONTINUE
018278         ELSE
018633*            MOVE WS-LO-RL-KEY        TO WRL-KEY
018633             MOVE LCOMM-LO-RL-KEY     TO WRL-KEY
018278         END-IF
018278
018278     END-PERFORM.
018278
018278     PERFORM  RL-3000-END-BROWSE
018278         THRU RL-3000-END-BROWSE-X.
018278
018278
018278 5110-GET-NEXT-FORWRD-KEY-X.
018278     EXIT.
018278
018278*-------------------------
018278 5120-GET-NEXT-BCKWRD-KEY.
018278*-------------------------
018278
018633*    MOVE WS-LO-RL-KEY       TO WRL-KEY.
018633     MOVE LCOMM-LO-RL-KEY    TO WRL-KEY.
018278
018278     MOVE LOW-VALUES         TO WRL-ENDBR-KEY.
018278     MOVE MIR-CLI-ID         TO WRL-ENDBR-CLI-ID.
018278     MOVE WGLOB-SYS-CTL-ID   TO WRL-ENDBR-REL-SYS-ID.
018278
018278     PERFORM  RL-1000-BROWSE-PREV
018278         THRU RL-1000-BROWSE-PREV-X.
018278
018278     PERFORM
018278         VARYING I FROM 1 BY 1
018278         UNTIL I > 2
018278         OR NOT WRL-IO-OK
018278         OR NOT WGLOB-GOOD-RETURN
018278
018278         PERFORM  8110-GET-NEXT-INSURED
018278             THRU 8110-GET-NEXT-INSURED-X
018278
018278         IF  WRL-IO-OK
018278             CONTINUE
018278         ELSE
018633*            MOVE WS-HI-RL-KEY        TO WRL-KEY
018633             MOVE LCOMM-HI-RL-KEY     TO WRL-KEY
018278         END-IF
018278
018278     END-PERFORM.
018278
018278     PERFORM  RL-3000-END-BROWSE-PREV
018278         THRU RL-3000-END-BROWSE-PREV-X.
018278
018278 5120-GET-NEXT-BCKWRD-KEY-X.
018278     EXIT.
018278
018278*---------------------------
018278 5200-REVERSE-LIST.
018278*---------------------------
018278
018278     MOVE +1                          TO J.
018278
018278     PERFORM
018278         VARYING I FROM WS-LINE BY -1
018278         UNTIL  I <= J
018278
018278         PERFORM  5210-SWAP-MIR
018278             THRU 5210-SWAP-MIR-X
018278         ADD +1                       TO J
018278
018278     END-PERFORM.
018278
018278     MOVE +1                          TO J.
018278
018278     PERFORM
018278         VARYING I FROM WS-LINE BY -1
018278         UNTIL  I <= J
018278
018278         PERFORM  5211-SWAP-TWRK
018278             THRU 5211-SWAP-TWRK-X
018278         ADD +1                       TO J
018278
018278     END-PERFORM.
018278
018278 5200-REVERSE-LIST-X.
018278     EXIT.
018278
018278*---------------------------
018278 5210-SWAP-MIR.
018278*---------------------------
018278
018278     MOVE MIR-CVG-NUM-T (J)
018278     TO WS-TMP-CVG-NUM.
018278     MOVE MIR-CVG-NUM-T (I)
018278     TO MIR-CVG-NUM-T (J).
018278     MOVE WS-TMP-CVG-NUM
018278     TO MIR-CVG-NUM-T (I).
018278
018278     MOVE MIR-CVG-CSTAT-CD-T (J)
018278     TO WS-TMP-CVG-CSTAT-CD.
018278     MOVE MIR-CVG-CSTAT-CD-T (I)
018278     TO MIR-CVG-CSTAT-CD-T (J).
018278     MOVE WS-TMP-CVG-CSTAT-CD
018278     TO MIR-CVG-CSTAT-CD-T (I).
018278
018278     MOVE MIR-CVG-FACE-AMT-T (J)
018278     TO WS-TMP-CVG-FACE-AMT.
018278     MOVE MIR-CVG-FACE-AMT-T (I)
018278     TO MIR-CVG-FACE-AMT-T (J).
018278     MOVE WS-TMP-CVG-FACE-AMT
018278     TO MIR-CVG-FACE-AMT-T (I).
018278
018278     MOVE MIR-PLAN-ID-T (J)
018278     TO WS-TMP-PLAN-ID.
018278     MOVE MIR-PLAN-ID-T (I)
018278     TO MIR-PLAN-ID-T (J).
018278     MOVE WS-TMP-PLAN-ID
018278     TO MIR-PLAN-ID-T (I).
018278
018278     MOVE MIR-POL-ID-BASE-T (J)
018278     TO WS-TMP-POL-ID-BASE.
018278     MOVE MIR-POL-ID-BASE-T (I)
018278     TO MIR-POL-ID-BASE-T (J).
018278     MOVE WS-TMP-POL-ID-BASE
018278     TO MIR-POL-ID-BASE-T (I).
018278
018278     MOVE MIR-POL-ID-SFX-T (J)
018278     TO WS-TMP-POL-ID-SFX.
018278     MOVE MIR-POL-ID-SFX-T (I)
018278     TO MIR-POL-ID-SFX-T (J).
018278     MOVE WS-TMP-POL-ID-SFX
018278     TO MIR-POL-ID-SFX-T (I).
018278
018278     MOVE MIR-CVG-AD-FACE-AMT-T (J)
018278     TO WS-TMP-CVG-AD-FACE-AMT.
018278     MOVE MIR-CVG-AD-FACE-AMT-T (I)
018278     TO MIR-CVG-AD-FACE-AMT-T (J).
018278     MOVE WS-TMP-CVG-AD-FACE-AMT
018278     TO MIR-CVG-AD-FACE-AMT-T (I).
018278
018278     MOVE MIR-CVG-AD-MULT-FCT-T (J)
018278     TO WS-TMP-CVG-AD-MULT-FCT.
018278     MOVE MIR-CVG-AD-MULT-FCT-T (I)
018278     TO MIR-CVG-AD-MULT-FCT-T (J).
018278     MOVE WS-TMP-CVG-AD-MULT-FCT
018278     TO MIR-CVG-AD-MULT-FCT-T (I).
018278
018278     MOVE MIR-CVG-UWG-AMT-T (J)
018278     TO WS-TMP-CVG-UWG-AMT.
018278     MOVE MIR-CVG-UWG-AMT-T (I)
018278     TO MIR-CVG-UWG-AMT-T (J).
018278     MOVE WS-TMP-CVG-UWG-AMT
018278     TO MIR-CVG-UWG-AMT-T (I).
018278
018278     MOVE MIR-CVG-COLA-SELCT-CD-T (J)
018278     TO WS-TMP-CVG-COLA-SELCT-CD.
018278     MOVE MIR-CVG-COLA-SELCT-CD-T (I)
018278     TO MIR-CVG-COLA-SELCT-CD-T (J).
018278     MOVE WS-TMP-CVG-COLA-SELCT-CD
018278     TO MIR-CVG-COLA-SELCT-CD-T (I).
018278
018278     MOVE MIR-CVG-ENHC-TYP-CD-T (J)
018278     TO WS-TMP-CVG-ENHC-TYP-CD.
018278     MOVE MIR-CVG-ENHC-TYP-CD-T (I)
018278     TO MIR-CVG-ENHC-TYP-CD-T (J).
018278     MOVE WS-TMP-CVG-ENHC-TYP-CD
018278     TO MIR-CVG-ENHC-TYP-CD-T (I).
018278
018278     MOVE MIR-CVG-UWG-EXCL-1-CD-T (J)
018278     TO WS-TMP-CVG-UWG-EXCL-1-CD.
018278     MOVE MIR-CVG-UWG-EXCL-1-CD-T (I)
018278     TO MIR-CVG-UWG-EXCL-1-CD-T (J).
018278     MOVE WS-TMP-CVG-UWG-EXCL-1-CD
018278     TO MIR-CVG-UWG-EXCL-1-CD-T (I).
018278
018278     MOVE MIR-CVG-UWG-EXCL-2-CD-T (J)
018278     TO WS-TMP-CVG-UWG-EXCL-2-CD.
018278     MOVE MIR-CVG-UWG-EXCL-2-CD-T (I)
018278     TO MIR-CVG-UWG-EXCL-2-CD-T (J).
018278     MOVE WS-TMP-CVG-UWG-EXCL-2-CD
018278     TO MIR-CVG-UWG-EXCL-2-CD-T (I).
018278
018278     MOVE MIR-CVG-UWG-EXCL-3-CD-T (J)
018278     TO WS-TMP-CVG-UWG-EXCL-3-CD.
018278     MOVE MIR-CVG-UWG-EXCL-3-CD-T (I)
018278     TO MIR-CVG-UWG-EXCL-3-CD-T (J).
018278     MOVE WS-TMP-CVG-UWG-EXCL-3-CD
018278     TO MIR-CVG-UWG-EXCL-3-CD-T (I).
018278
018278     MOVE MIR-CVG-FE-DUR-T (J)
018278     TO WS-TMP-CVG-FE-DUR.
018278     MOVE MIR-CVG-FE-DUR-T (I)
018278     TO MIR-CVG-FE-DUR-T (J).
018278     MOVE WS-TMP-CVG-FE-DUR
018278     TO MIR-CVG-FE-DUR-T (I).
018278
018278     MOVE MIR-CVG-FE-UPREM-AMT-T (J)
018278     TO WS-TMP-CVG-FE-UPREM-AMT.
018278     MOVE MIR-CVG-FE-UPREM-AMT-T (I)
018278     TO MIR-CVG-FE-UPREM-AMT-T (J).
018278     MOVE WS-TMP-CVG-FE-UPREM-AMT
018278     TO MIR-CVG-FE-UPREM-AMT-T (I).
018278
018278     MOVE MIR-CVG-FE-REASN-CD-T (J)
018278     TO WS-TMP-CVG-FE-REASN-CD.
018278     MOVE MIR-CVG-FE-REASN-CD-T (I)
018278     TO MIR-CVG-FE-REASN-CD-T (J).
018278     MOVE WS-TMP-CVG-FE-REASN-CD
018278     TO MIR-CVG-FE-REASN-CD-T (I).
018278
018278     MOVE MIR-REDC-EP-SELCT-IND-T (J)
018278     TO WS-TMP-REDC-EP-SELCT-IND.
018278     MOVE MIR-REDC-EP-SELCT-IND-T (I)
018278     TO MIR-REDC-EP-SELCT-IND-T (J).
018278     MOVE WS-TMP-REDC-EP-SELCT-IND
018278     TO MIR-REDC-EP-SELCT-IND-T (I).
018278
025388*    MOVE MIR-CVG-LIVES-INSRD-CD-T (J)
025388*    TO WS-TMP-CVG-LIVES-INSRD-CD.
025388*    MOVE MIR-CVG-LIVES-INSRD-CD-T (I)
025388*    TO MIR-CVG-LIVES-INSRD-CD-T (J).
025388*    MOVE WS-TMP-CVG-LIVES-INSRD-CD
025388*    TO MIR-CVG-LIVES-INSRD-CD-T (I).
025388     MOVE MIR-LIVES-INSRD-QTY-T (J)
025388     TO WS-TMP-LIVES-INSRD-QTY.
025388     MOVE MIR-LIVES-INSRD-QTY-T (I)
025388     TO MIR-LIVES-INSRD-QTY-T (J).
025388     MOVE WS-TMP-LIVES-INSRD-QTY
025388     TO MIR-LIVES-INSRD-QTY-T (I).
018278
018278     MOVE MIR-CVG-LTA-SELCT-IND-T (J)
018278     TO WS-TMP-CVG-LTA-SELCT-IND.
018278     MOVE MIR-CVG-LTA-SELCT-IND-T (I)
018278     TO MIR-CVG-LTA-SELCT-IND-T (J).
018278     MOVE WS-TMP-CVG-LTA-SELCT-IND
018278     TO MIR-CVG-LTA-SELCT-IND-T (I).
018278
018278     MOVE MIR-CVG-LTB-SELCT-IND-T (J)
018278     TO WS-TMP-CVG-LTB-SELCT-IND.
018278     MOVE MIR-CVG-LTB-SELCT-IND-T (I)
018278     TO MIR-CVG-LTB-SELCT-IND-T (J).
018278     MOVE WS-TMP-CVG-LTB-SELCT-IND
018278     TO MIR-CVG-LTB-SELCT-IND-T (I).
018278
018278     MOVE MIR-CVG-ME-RAT-CD-T (J)
018278     TO WS-TMP-CVG-ME-RAT-CD.
018278     MOVE MIR-CVG-ME-RAT-CD-T (I)
018278     TO MIR-CVG-ME-RAT-CD-T (J).
018278     MOVE WS-TMP-CVG-ME-RAT-CD
018278     TO MIR-CVG-ME-RAT-CD-T (I).
018278
018278     MOVE MIR-CVG-ME-DUR-T (J)
018278     TO WS-TMP-CVG-ME-DUR.
018278     MOVE MIR-CVG-ME-DUR-T (I)
018278     TO MIR-CVG-ME-DUR-T (J).
018278     MOVE WS-TMP-CVG-ME-DUR
018278     TO MIR-CVG-ME-DUR-T (I).
018278
018278     MOVE MIR-OWN-OCCP-SELCT-IND-T (J)
018278     TO WS-TMP-OWN-OCCP-SELCT-IND.
018278     MOVE MIR-OWN-OCCP-SELCT-IND-T (I)
018278     TO MIR-OWN-OCCP-SELCT-IND-T (J).
018278     MOVE WS-TMP-OWN-OCCP-SELCT-IND
018278     TO MIR-OWN-OCCP-SELCT-IND-T (I).
018278
018278     MOVE MIR-CVG-PREV-FACE-AMT-T (J)
018278     TO WS-TMP-CVG-PREV-FACE-AMT.
018278     MOVE MIR-CVG-PREV-FACE-AMT-T (I)
018278     TO MIR-CVG-PREV-FACE-AMT-T (J).
018278     MOVE WS-TMP-CVG-PREV-FACE-AMT
018278     TO MIR-CVG-PREV-FACE-AMT-T (I).
018278
018278     MOVE MIR-PDISAB-SELCT-IND-T (J)
018278     TO WS-TMP-PDISAB-SELCT-IND.
018278     MOVE MIR-PDISAB-SELCT-IND-T (I)
018278     TO MIR-PDISAB-SELCT-IND-T (J).
018278     MOVE WS-TMP-PDISAB-SELCT-IND
018278     TO MIR-PDISAB-SELCT-IND-T (I).
018278
018278     MOVE MIR-LINK-POL-ISS-IND-T (J)
018278     TO WS-TMP-LINK-POL-ISS-IND.
018278     MOVE MIR-LINK-POL-ISS-IND-T (I)
018278     TO MIR-LINK-POL-ISS-IND-T (J).
018278     MOVE WS-TMP-LINK-POL-ISS-IND
018278     TO MIR-LINK-POL-ISS-IND-T (I).
018278
018278     MOVE MIR-POL-OPTL-CD-T (J)
018278     TO WS-TMP-POL-OPTL-CD.
018278     MOVE MIR-POL-OPTL-CD-T (I)
018278     TO MIR-POL-OPTL-CD-T (J).
018278     MOVE WS-TMP-POL-OPTL-CD
018278     TO MIR-POL-OPTL-CD-T (I).
018278
018278     MOVE MIR-CVG-RT-AGE-T (J)
018278     TO WS-TMP-CVG-RT-AGE.
018278     MOVE MIR-CVG-RT-AGE-T (I)
018278     TO MIR-CVG-RT-AGE-T (J).
018278     MOVE WS-TMP-CVG-RT-AGE
018278     TO MIR-CVG-RT-AGE-T (I).
018278
018278     MOVE MIR-AGE-RAT-REASN-CD-T (J)
018278     TO WS-TMP-AGE-RAT-REASN-CD.
018278     MOVE MIR-AGE-RAT-REASN-CD-T (I)
018278     TO MIR-AGE-RAT-REASN-CD-T (J).
018278     MOVE WS-TMP-AGE-RAT-REASN-CD
018278     TO MIR-AGE-RAT-REASN-CD-T (I).
018278
018278     MOVE MIR-CVG-ME-REASN-CD-T (J)
018278     TO WS-TMP-CVG-ME-REASN-CD.
018278     MOVE MIR-CVG-ME-REASN-CD-T (I)
018278     TO MIR-CVG-ME-REASN-CD-T (J).
018278     MOVE WS-TMP-CVG-ME-REASN-CD
018278     TO MIR-CVG-ME-REASN-CD-T (I).
018278
018278     MOVE MIR-CVG-SPND-CSTAT-CD-T (J)
018278     TO WS-TMP-CVG-SPND-CSTAT-CD.
018278     MOVE MIR-CVG-SPND-CSTAT-CD-T (I)
018278     TO MIR-CVG-SPND-CSTAT-CD-T (J).
018278     MOVE WS-TMP-CVG-SPND-CSTAT-CD
018278     TO MIR-CVG-SPND-CSTAT-CD-T (I).
018278
018278     MOVE MIR-CVG-SEX-CD-T (J)
018278     TO WS-TMP-CVG-SEX-CD.
018278     MOVE MIR-CVG-SEX-CD-T (I)
018278     TO MIR-CVG-SEX-CD-T (J).
018278     MOVE WS-TMP-CVG-SEX-CD
018278     TO MIR-CVG-SEX-CD-T (I).
018278
018278     MOVE MIR-CVG-SMKR-CD-T (J)
018278     TO WS-TMP-CVG-SMKR-CD.
018278     MOVE MIR-CVG-SMKR-CD-T (I)
018278     TO MIR-CVG-SMKR-CD-T (J).
018278     MOVE WS-TMP-CVG-SMKR-CD
018278     TO MIR-CVG-SMKR-CD-T (I).
018278
018278     MOVE MIR-CVG-SUPP-BNFT-CD-T (J)
018278     TO WS-TMP-CVG-SUPP-BNFT-CD.
018278     MOVE MIR-CVG-SUPP-BNFT-CD-T (I)
018278     TO MIR-CVG-SUPP-BNFT-CD-T (J).
018278     MOVE WS-TMP-CVG-SUPP-BNFT-CD
018278     TO MIR-CVG-SUPP-BNFT-CD-T (I).
018278
018278     MOVE MIR-CVG-STBL-1-CD-T (J)
018278     TO WS-TMP-CVG-STBL-1-CD.
018278     MOVE MIR-CVG-STBL-1-CD-T (I)
018278     TO MIR-CVG-STBL-1-CD-T (J).
018278     MOVE WS-TMP-CVG-STBL-1-CD
018278     TO MIR-CVG-STBL-1-CD-T (I).
018278
018278     MOVE MIR-CVG-STBL-2-CD-T (J)
018278     TO WS-TMP-CVG-STBL-2-CD.
018278     MOVE MIR-CVG-STBL-2-CD-T (I)
018278     TO MIR-CVG-STBL-2-CD-T (J).
018278     MOVE WS-TMP-CVG-STBL-2-CD
018278     TO MIR-CVG-STBL-2-CD-T (I).
018278
018278     MOVE MIR-CVG-STBL-3-CD-T (J)
018278     TO WS-TMP-CVG-STBL-3-CD.
018278     MOVE MIR-CVG-STBL-3-CD-T (I)
018278     TO MIR-CVG-STBL-3-CD-T (J).
018278     MOVE WS-TMP-CVG-STBL-3-CD
018278     TO MIR-CVG-STBL-3-CD-T (I).
018278
018278     MOVE MIR-CVG-STBL-4-CD-T (J)
018278     TO WS-TMP-CVG-STBL-4-CD.
018278     MOVE MIR-CVG-STBL-4-CD-T (I)
018278     TO MIR-CVG-STBL-4-CD-T (J).
018278     MOVE WS-TMP-CVG-STBL-4-CD
018278     TO MIR-CVG-STBL-4-CD-T (I).
018278
018278     MOVE MIR-CVG-UWGDECN-CD-T (J)
018278     TO WS-TMP-CVG-UWGDECN-CD.
018278     MOVE MIR-CVG-UWGDECN-CD-T (I)
018278     TO MIR-CVG-UWGDECN-CD-T (J).
018278     MOVE WS-TMP-CVG-UWGDECN-CD
018278     TO MIR-CVG-UWGDECN-CD-T (I).
018278
018278     MOVE MIR-CVG-UWGDECN-SUB-CD-T (J)
018278     TO WS-TMP-CVG-UWGDECN-SUB-CD.
018278     MOVE MIR-CVG-UWGDECN-SUB-CD-T (I)
018278     TO MIR-CVG-UWGDECN-SUB-CD-T (J).
018278     MOVE WS-TMP-CVG-UWGDECN-SUB-CD
018278     TO MIR-CVG-UWGDECN-SUB-CD-T (I).
018278
018278     MOVE MIR-CVG-ME-FCT-T (J)
018278     TO WS-TMP-CVG-ME-FCT.
018278     MOVE MIR-CVG-ME-FCT-T (I)
018278     TO MIR-CVG-ME-FCT-T (J).
018278     MOVE WS-TMP-CVG-ME-FCT
018278     TO MIR-CVG-ME-FCT-T (I).
018278
018278     MOVE MIR-UWG-AMT-REASN-CD-T (J)
018278     TO WS-TMP-UWG-AMT-REASN-CD.
018278     MOVE MIR-UWG-AMT-REASN-CD-T (I)
018278     TO MIR-UWG-AMT-REASN-CD-T (J).
018278     MOVE WS-TMP-UWG-AMT-REASN-CD
018278     TO MIR-UWG-AMT-REASN-CD-T (I).
018278
018278     MOVE MIR-CVG-WP-MULT-FCT-T (J)
018278     TO WS-TMP-CVG-WP-MULT-FCT.
018278     MOVE MIR-CVG-WP-MULT-FCT-T (I)
018278     TO MIR-CVG-WP-MULT-FCT-T (J).
018278     MOVE WS-TMP-CVG-WP-MULT-FCT
018278     TO MIR-CVG-WP-MULT-FCT-T (I).
018278
018278 5210-SWAP-MIR-X.
018278     EXIT.
018278
018278*---------------------------
018278 5211-SWAP-TWRK.
018278*---------------------------
018278
018633*    MOVE WS-CVG-DECN-ARRAY (J)
018633     MOVE LCOMM-CVG-DECN-T (J)
018278     TO WS-TMP1-CVG-DECN.
018633*    MOVE WS-CVG-DECN-ARRAY (I)
018633*    TO WS-CVG-DECN-ARRAY (J).
018633     MOVE LCOMM-CVG-DECN-T (I)
018633     TO LCOMM-CVG-DECN-T (J).
018278     MOVE WS-TMP1-CVG-DECN
018633*    TO WS-CVG-DECN-ARRAY (I).
018633     TO LCOMM-CVG-DECN-T (I).
018278
018633*    MOVE WS-CVG-DECN-SUB-ARRAY (J)
018633     MOVE LCOMM-CVG-DECN-SUB-T (J)
018278     TO WS-TMP1-CVG-DECN-SUB.
018633*    MOVE WS-CVG-DECN-SUB-ARRAY (I)
018633*    TO WS-CVG-DECN-SUB-ARRAY (J).
018633     MOVE LCOMM-CVG-DECN-SUB-T (I)
018633     TO LCOMM-CVG-DECN-SUB-T (J).
018278     MOVE WS-TMP1-CVG-DECN-SUB
018633*    TO WS-CVG-DECN-SUB-ARRAY (I).
018633     TO LCOMM-CVG-DECN-SUB-T (I).
018278
018633*    MOVE WS-PLAN-ID-ARRAY (J)
018633     MOVE LCOMM-PLAN-ID-T (J)
018278     TO WS-TMP1-PLAN-ID.
018633*    MOVE WS-PLAN-ID-ARRAY (I)
018633*    TO WS-PLAN-ID-ARRAY (J).
018633     MOVE LCOMM-PLAN-ID-T (I)
018633     TO LCOMM-PLAN-ID-T (J).
018278     MOVE WS-TMP1-PLAN-ID
018633*    TO WS-PLAN-ID-ARRAY (I).
018633     TO LCOMM-PLAN-ID-T (I).
018278
018633*    MOVE WS-CVG-FACE-AMT-ARRAY (J)
018633     MOVE LCOMM-CVG-FACE-AMT-T (J)
018278     TO WS-TMP1-CVG-FACE-AMT.
018633*    MOVE WS-CVG-FACE-AMT-ARRAY (I)
018633*    TO WS-CVG-FACE-AMT-ARRAY (J).
018633     MOVE LCOMM-CVG-FACE-AMT-T (I)
018633     TO LCOMM-CVG-FACE-AMT-T (J).
018278     MOVE WS-TMP1-CVG-FACE-AMT
018633*    TO WS-CVG-FACE-AMT-ARRAY (I).
018633     TO LCOMM-CVG-FACE-AMT-T (I).
018278
018633*    MOVE WS-CVG-AD-FACE-AMT-ARRAY (J)
018633     MOVE LCOMM-CVG-AD-FACE-AMT-T (J)
018278     TO WS-TMP1-CVG-AD-FACE-AMT.
018633*    MOVE WS-CVG-AD-FACE-AMT-ARRAY (I)
018633*    TO WS-CVG-AD-FACE-AMT-ARRAY (J).
018633     MOVE LCOMM-CVG-AD-FACE-AMT-T (I)
018633     TO LCOMM-CVG-AD-FACE-AMT-T (J).
018278     MOVE WS-TMP1-CVG-AD-FACE-AMT
018633*    TO WS-CVG-AD-FACE-AMT-ARRAY (I).
018633     TO LCOMM-CVG-AD-FACE-AMT-T (I).
018278
018633*    MOVE WS-CVG-AD-MULT-FCT-ARRAY (J)
018633     MOVE LCOMM-CVG-AD-MULT-FCT-T (J)
018278     TO WS-TMP1-CVG-AD-MULT-FCT.
018633*    MOVE WS-CVG-AD-MULT-FCT-ARRAY (I)
018633*    TO WS-CVG-AD-MULT-FCT-ARRAY (J).
018633     MOVE LCOMM-CVG-AD-MULT-FCT-T (I)
018633     TO LCOMM-CVG-AD-MULT-FCT-T (J).
018278     MOVE WS-TMP1-CVG-AD-MULT-FCT
018633*    TO WS-CVG-AD-MULT-FCT-ARRAY (I).
018633     TO LCOMM-CVG-AD-MULT-FCT-T (I).
018278
018633*    MOVE WS-CVG-WP-MULT-FCT-ARRAY (J)
018633     MOVE LCOMM-CVG-WP-MULT-FCT-T (J)
018278     TO WS-TMP1-CVG-WP-MULT-FCT.
018633*    MOVE WS-CVG-WP-MULT-FCT-ARRAY (I)
018633*    TO WS-CVG-WP-MULT-FCT-ARRAY (J).
018633     MOVE LCOMM-CVG-WP-MULT-FCT-T (I)
018633     TO LCOMM-CVG-WP-MULT-FCT-T (J).
018278     MOVE WS-TMP1-CVG-WP-MULT-FCT
018633*    TO WS-CVG-WP-MULT-FCT-ARRAY (I).
018633     TO LCOMM-CVG-WP-MULT-FCT-T (I).
018278
018633*    MOVE WS-CVG-STBL-1-ARRAY (J)
018633     MOVE LCOMM-CVG-STBL-1-T (J)
018278     TO WS-TMP1-CVG-STBL-1.
018633*    MOVE WS-CVG-STBL-1-ARRAY (I)
018633*    TO WS-CVG-STBL-1-ARRAY (J).
018633     MOVE LCOMM-CVG-STBL-1-T (I)
018633     TO LCOMM-CVG-STBL-1-T (J).
018278     MOVE WS-TMP1-CVG-STBL-1
018633*    TO WS-CVG-STBL-1-ARRAY (I).
018633     TO LCOMM-CVG-STBL-1-T (I).
018278
018633*    MOVE WS-CVG-STBL-2-ARRAY (J)
018633     MOVE LCOMM-CVG-STBL-2-T (J)
018278     TO WS-TMP1-CVG-STBL-2.
018633*    MOVE WS-CVG-STBL-2-ARRAY (I)
018633*    TO WS-CVG-STBL-2-ARRAY (J).
018633     MOVE LCOMM-CVG-STBL-2-T (I)
018633     TO LCOMM-CVG-STBL-2-T (J).
018278     MOVE WS-TMP1-CVG-STBL-2
018633*    TO WS-CVG-STBL-2-ARRAY (I).
018633     TO LCOMM-CVG-STBL-2-T (I).
018278
018633*    MOVE WS-CVG-STBL-3-ARRAY (J)
018633     MOVE LCOMM-CVG-STBL-3-T (J)
018278     TO WS-TMP1-CVG-STBL-3.
018633*    MOVE WS-CVG-STBL-3-ARRAY (I)
018633*    TO WS-CVG-STBL-3-ARRAY (J).
018633     MOVE LCOMM-CVG-STBL-3-T (I)
018633     TO LCOMM-CVG-STBL-3-T (J).
018278     MOVE WS-TMP1-CVG-STBL-3
018633*    TO WS-CVG-STBL-3-ARRAY (I).
018633     TO LCOMM-CVG-STBL-3-T (I).
018278
018633*    MOVE WS-CVG-STBL-4-ARRAY (J)
018633     MOVE LCOMM-CVG-STBL-4-T (J)
018278     TO WS-TMP1-CVG-STBL-4.
018633*    MOVE WS-CVG-STBL-4-ARRAY (I)
018633*    TO WS-CVG-STBL-4-ARRAY (J).
018633     MOVE LCOMM-CVG-STBL-4-T (I)
018633     TO LCOMM-CVG-STBL-4-T (J).
018278     MOVE WS-TMP1-CVG-STBL-4
018633*    TO WS-CVG-STBL-4-ARRAY (I).
018633     TO LCOMM-CVG-STBL-4-T (I).
018278
018633*    MOVE WS-CVG-ENHC-TYP-ARRAY (J)
018633     MOVE LCOMM-CVG-ENHC-TYP-T (J)
018278     TO WS-TMP1-CVG-ENHC-TYP.
018633*    MOVE WS-CVG-ENHC-TYP-ARRAY (I)
018633*    TO WS-CVG-ENHC-TYP-ARRAY (J).
018633     MOVE LCOMM-CVG-ENHC-TYP-T (I)
018633     TO LCOMM-CVG-ENHC-TYP-T (J).
018278     MOVE WS-TMP1-CVG-ENHC-TYP
018633*    TO WS-CVG-ENHC-TYP-ARRAY (I).
018633     TO LCOMM-CVG-ENHC-TYP-T (I).
018278
018633*    MOVE WS-CVG-ME-FCT-ARRAY (J)
018633     MOVE LCOMM-CVG-ME-FCT-T (J)
018278     TO WS-TMP1-CVG-ME-FCT.
018633*    MOVE WS-CVG-ME-FCT-ARRAY (I)
018633*    TO WS-CVG-ME-FCT-ARRAY (J).
018633     MOVE LCOMM-CVG-ME-FCT-T (I)
018633     TO LCOMM-CVG-ME-FCT-T (J).
018278     MOVE WS-TMP1-CVG-ME-FCT
018633*    TO WS-CVG-ME-FCT-ARRAY (I).
018633     TO LCOMM-CVG-ME-FCT-T (I).
018278
018633*    MOVE WS-CVG-ME-RAT-ARRAY (J)
018633     MOVE LCOMM-CVG-ME-RAT-T (J)
018278     TO WS-TMP1-CVG-ME-RAT.
018633*    MOVE WS-CVG-ME-RAT-ARRAY (I)
018633*    TO WS-CVG-ME-RAT-ARRAY (J).
018633     MOVE LCOMM-CVG-ME-RAT-T (I)
018633     TO LCOMM-CVG-ME-RAT-T (J).
018278     MOVE WS-TMP1-CVG-ME-RAT
018633*    TO WS-CVG-ME-RAT-ARRAY (I).
018633     TO LCOMM-CVG-ME-RAT-T (I).
018278
018633*    MOVE WS-CVG-ME-REASN-ARRAY (J)
018633     MOVE LCOMM-CVG-ME-REASN-T (J)
018278     TO WS-TMP1-CVG-ME-REASN.
018633*    MOVE WS-CVG-ME-REASN-ARRAY (I)
018633*    TO WS-CVG-ME-REASN-ARRAY (J).
018633     MOVE LCOMM-CVG-ME-REASN-T (I)
018633     TO LCOMM-CVG-ME-REASN-T (J).
018278     MOVE WS-TMP1-CVG-ME-REASN
018633*    TO WS-CVG-ME-REASN-ARRAY (I).
018633     TO LCOMM-CVG-ME-REASN-T (I).
018278
018633*    MOVE WS-CVG-COLA-SELCT-ARRAY (J)
018633     MOVE LCOMM-CVG-COLA-SELCT-T (J)
018278     TO WS-TMP1-CVG-COLA-SELCT.
018633*    MOVE WS-CVG-COLA-SELCT-ARRAY (I)
018633*    TO WS-CVG-COLA-SELCT-ARRAY (J).
018633     MOVE LCOMM-CVG-COLA-SELCT-T (I)
018633     TO LCOMM-CVG-COLA-SELCT-T (J).
018278     MOVE WS-TMP1-CVG-COLA-SELCT
018633*    TO WS-CVG-COLA-SELCT-ARRAY (I).
018633     TO LCOMM-CVG-COLA-SELCT-T (I).
018278
018633*    MOVE WS-REDC-EP-SELCT-ARRAY (J)
018633     MOVE LCOMM-REDC-EP-SELCT-T (J)
018278     TO WS-TMP1-REDC-EP-SELCT.
018633*    MOVE WS-REDC-EP-SELCT-ARRAY (I)
018633*    TO WS-REDC-EP-SELCT-ARRAY (J).
018633     MOVE LCOMM-REDC-EP-SELCT-T (I)
018633     TO LCOMM-REDC-EP-SELCT-T (J).
018278     MOVE WS-TMP1-REDC-EP-SELCT
018633*    TO WS-REDC-EP-SELCT-ARRAY (I).
018633     TO LCOMM-REDC-EP-SELCT-T (I).
018278
018633*    MOVE WS-OWN-OCCP-SELCT-ARRAY (J)
018633     MOVE LCOMM-OWN-OCCP-SELCT-T (J)
018278     TO WS-TMP1-OWN-OCCP-SELCT.
018633*    MOVE WS-OWN-OCCP-SELCT-ARRAY (I)
018633*    TO WS-OWN-OCCP-SELCT-ARRAY (J).
018633     MOVE LCOMM-OWN-OCCP-SELCT-T (I)
018633     TO LCOMM-OWN-OCCP-SELCT-T (J).
018278     MOVE WS-TMP1-OWN-OCCP-SELCT
018633*    TO WS-OWN-OCCP-SELCT-ARRAY (I).
018633     TO LCOMM-OWN-OCCP-SELCT-T (I).
018278
018633*    MOVE WS-CVG-LTA-SELCT-ARRAY (J)
018633     MOVE LCOMM-CVG-LTA-SELCT-T (J)
018278     TO WS-TMP1-CVG-LTA-SELCT.
018633*    MOVE WS-CVG-LTA-SELCT-ARRAY (I)
018633*    TO WS-CVG-LTA-SELCT-ARRAY (J).
018633     MOVE LCOMM-CVG-LTA-SELCT-T (I)
018633     TO LCOMM-CVG-LTA-SELCT-T (J).
018278     MOVE WS-TMP1-CVG-LTA-SELCT
018633*    TO WS-CVG-LTA-SELCT-ARRAY (I).
018633     TO LCOMM-CVG-LTA-SELCT-T (I).
018278
018633*    MOVE WS-CVG-LTB-SELCT-ARRAY (J)
018633     MOVE LCOMM-CVG-LTB-SELCT-T (J)
018278     TO WS-TMP1-CVG-LTB-SELCT.
018633*    MOVE WS-CVG-LTB-SELCT-ARRAY (I)
018633*    TO WS-CVG-LTB-SELCT-ARRAY (J).
018633     MOVE LCOMM-CVG-LTB-SELCT-T (I)
018633     TO LCOMM-CVG-LTB-SELCT-T (J).
018278     MOVE WS-TMP1-CVG-LTB-SELCT
018633*    TO WS-CVG-LTB-SELCT-ARRAY (I).
018633     TO LCOMM-CVG-LTB-SELCT-T (I).
018278
018633*    MOVE WS-PDISAB-SELCT-ARRAY (J)
018633     MOVE LCOMM-PDISAB-SELCT-T (J)
018278     TO WS-TMP1-PDISAB-SELCT.
018633*    MOVE WS-PDISAB-SELCT-ARRAY (I)
018633*    TO WS-PDISAB-SELCT-ARRAY (J).
018633     MOVE LCOMM-PDISAB-SELCT-T (I)
018633     TO LCOMM-PDISAB-SELCT-T (J).
018278     MOVE WS-TMP1-PDISAB-SELCT
018633*    TO WS-PDISAB-SELCT-ARRAY (I).
018633     TO LCOMM-PDISAB-SELCT-T (I).
018278
018633*    MOVE WS-CVG-UWG-EXCL-1-ARRAY (J)
018633     MOVE LCOMM-CVG-UWG-EXCL-1-T (J)
018278     TO WS-TMP1-CVG-UWG-EXCL-1.
018633*    MOVE WS-CVG-UWG-EXCL-1-ARRAY (I)
018633*    TO WS-CVG-UWG-EXCL-1-ARRAY (J).
018633     MOVE LCOMM-CVG-UWG-EXCL-1-T (I)
018633     TO LCOMM-CVG-UWG-EXCL-1-T (J).
018278     MOVE WS-TMP1-CVG-UWG-EXCL-1
018633*    TO WS-CVG-UWG-EXCL-1-ARRAY (I).
018633     TO LCOMM-CVG-UWG-EXCL-1-T (I).
018278
018633*    MOVE WS-CVG-UWG-EXCL-2-ARRAY (J)
018633     MOVE LCOMM-CVG-UWG-EXCL-2-T (J)
018278     TO WS-TMP1-CVG-UWG-EXCL-2.
018633*    MOVE WS-CVG-UWG-EXCL-2-ARRAY (I)
018633*    TO WS-CVG-UWG-EXCL-2-ARRAY (J).
018633     MOVE LCOMM-CVG-UWG-EXCL-2-T (I)
018633     TO LCOMM-CVG-UWG-EXCL-2-T (J).
018278     MOVE WS-TMP1-CVG-UWG-EXCL-2
018633*    TO WS-CVG-UWG-EXCL-2-ARRAY (I).
018633     TO LCOMM-CVG-UWG-EXCL-2-T (I).
018278
018633*    MOVE WS-CVG-UWG-EXCL-3-ARRAY (J)
018633     MOVE LCOMM-CVG-UWG-EXCL-3-T (J)
018278     TO WS-TMP1-CVG-UWG-EXCL-3.
018633*    MOVE WS-CVG-UWG-EXCL-3-ARRAY (I)
018633*    TO WS-CVG-UWG-EXCL-3-ARRAY (J).
018633     MOVE LCOMM-CVG-UWG-EXCL-3-T (I)
018633     TO LCOMM-CVG-UWG-EXCL-3-T (J).
018278     MOVE WS-TMP1-CVG-UWG-EXCL-3
018633*    TO WS-CVG-UWG-EXCL-3-ARRAY (I).
018633     TO LCOMM-CVG-UWG-EXCL-3-T (I).
018278
018633*    MOVE WS-CVG-ME-DUR-ARRAY (J)
018633     MOVE LCOMM-CVG-ME-DUR-T (J)
018278     TO WS-TMP1-CVG-ME-DUR.
018633*    MOVE WS-CVG-ME-DUR-ARRAY (I)
018633*    TO WS-CVG-ME-DUR-ARRAY (J).
018633     MOVE LCOMM-CVG-ME-DUR-T (I)
018633     TO LCOMM-CVG-ME-DUR-T (J).
018278     MOVE WS-TMP1-CVG-ME-DUR
018633*    TO WS-CVG-ME-DUR-ARRAY (I).
018633     TO LCOMM-CVG-ME-DUR-T (I).
018278
018633*    MOVE WS-CVG-FE-UPREM-AMT-ARRAY (J)
018633     MOVE LCOMM-CVG-FE-UPREM-AMT-T (J)
018278     TO WS-TMP1-CVG-FE-UPREM-AMT.
018633*    MOVE WS-CVG-FE-UPREM-AMT-ARRAY (I)
018633*    TO WS-CVG-FE-UPREM-AMT-ARRAY (J).
018633     MOVE LCOMM-CVG-FE-UPREM-AMT-T (I)
018633     TO LCOMM-CVG-FE-UPREM-AMT-T (J).
018278     MOVE WS-TMP1-CVG-FE-UPREM-AMT
018633*    TO WS-CVG-FE-UPREM-AMT-ARRAY (I).
018633     TO LCOMM-CVG-FE-UPREM-AMT-T (I).
018278
018633*    MOVE WS-CVG-FE-REASN-ARRAY (J)
018633     MOVE LCOMM-CVG-FE-REASN-T (J)
018278     TO WS-TMP1-CVG-FE-REASN.
018633*    MOVE WS-CVG-FE-REASN-ARRAY (I)
018633*    TO WS-CVG-FE-REASN-ARRAY (J).
018633     MOVE LCOMM-CVG-FE-REASN-T (I)
018633     TO LCOMM-CVG-FE-REASN-T (J).
018278     MOVE WS-TMP1-CVG-FE-REASN
018633*    TO WS-CVG-FE-REASN-ARRAY (I).
018633     TO LCOMM-CVG-FE-REASN-T (I).
018278
018633*    MOVE WS-CVG-FE-DUR-ARRAY (J)
018633     MOVE LCOMM-CVG-FE-DUR-T (J)
018278     TO WS-TMP1-CVG-FE-DUR.
018633*    MOVE WS-CVG-FE-DUR-ARRAY (I)
018633*    TO WS-CVG-FE-DUR-ARRAY (J).
018633     MOVE LCOMM-CVG-FE-DUR-T (I)
018633     TO LCOMM-CVG-FE-DUR-T (J).
018278     MOVE WS-TMP1-CVG-FE-DUR
018633*    TO WS-CVG-FE-DUR-ARRAY (I).
018633     TO LCOMM-CVG-FE-DUR-T (I).
018278
018633*    MOVE WS-CVG-RT-AGE-ARRAY (J)
018633     MOVE LCOMM-CVG-RT-AGE-T (J)
018278     TO WS-TMP1-CVG-RT-AGE.
018633*    MOVE WS-CVG-RT-AGE-ARRAY (I)
018633*    TO WS-CVG-RT-AGE-ARRAY (J).
018633     MOVE LCOMM-CVG-RT-AGE-T (I)
018633     TO LCOMM-CVG-RT-AGE-T (J).
018278     MOVE WS-TMP1-CVG-RT-AGE
018633*    TO WS-CVG-RT-AGE-ARRAY (I).
018633     TO LCOMM-CVG-RT-AGE-T (I).
018278
018633*    MOVE LCOMM-AGE-RAT-REASN-ARRAY (J)
018633     MOVE LCOMM-AGE-RAT-REASN-T (J)
018278     TO WS-TMP1-AGE-RAT-REASN.
018633*    MOVE LCOMM-AGE-RAT-REASN-ARRAY (I)
018633*    TO LCOMM-AGE-RAT-REASN-ARRAY (J).
018633     MOVE LCOMM-AGE-RAT-REASN-T (I)
018633     TO LCOMM-AGE-RAT-REASN-T (J).
018278     MOVE WS-TMP1-AGE-RAT-REASN
018633*    TO LCOMM-AGE-RAT-REASN-ARRAY (I).
018633     TO LCOMM-AGE-RAT-REASN-T (I).
018278
018633*    MOVE WS-CVG-SMKR-ARRAY (J)
018633     MOVE LCOMM-CVG-SMKR-T (J)
018278     TO WS-TMP1-CVG-SMKR.
018633*    MOVE WS-CVG-SMKR-ARRAY (I)
018633*    TO WS-CVG-SMKR-ARRAY (J).
018633     MOVE LCOMM-CVG-SMKR-T (I)
018633     TO LCOMM-CVG-SMKR-T (J).
018278     MOVE WS-TMP1-CVG-SMKR
018633*    TO WS-CVG-SMKR-ARRAY (I).
018633     TO LCOMM-CVG-SMKR-T (I).
018278
018633*    MOVE WS-CVG-SEX-ARRAY (J)
018633     MOVE LCOMM-CVG-SEX-T (J)
018278     TO WS-TMP1-CVG-SEX.
018633*    MOVE WS-CVG-SEX-ARRAY (I)
018633*    TO WS-CVG-SEX-ARRAY (J).
018633     MOVE LCOMM-CVG-SEX-T (I)
018633     TO LCOMM-CVG-SEX-T (J).
018278     MOVE WS-TMP1-CVG-SEX
018633*    TO WS-CVG-SEX-ARRAY (I).
018633     TO LCOMM-CVG-SEX-T (I).
018278
018633*    MOVE WS-CVG-UWG-AMT-ARRAY (J)
018633     MOVE LCOMM-CVG-UWG-AMT-T (J)
018278     TO WS-TMP1-CVG-UWG-AMT.
018633*    MOVE WS-CVG-UWG-AMT-ARRAY (I)
018633*    TO WS-CVG-UWG-AMT-ARRAY (J).
018633     MOVE LCOMM-CVG-UWG-AMT-T (I)
018633     TO LCOMM-CVG-UWG-AMT-T (J).
018278     MOVE WS-TMP1-CVG-UWG-AMT
018633*    TO WS-CVG-UWG-AMT-ARRAY (I).
018633     TO LCOMM-CVG-UWG-AMT-T (I).
018278
018633*    MOVE LCOMM-UWG-AMT-REASN-ARRAY (J)
018633     MOVE LCOMM-UWG-AMT-REASN-T (J)
018278     TO WS-TMP1-UWG-AMT-REASN.
018633*    MOVE LCOMM-UWG-AMT-REASN-ARRAY (I)
018633*    TO LCOMM-UWG-AMT-REASN-ARRAY (J).
018633     MOVE LCOMM-UWG-AMT-REASN-T (I)
018633     TO LCOMM-UWG-AMT-REASN-T (J).
018278     MOVE WS-TMP1-UWG-AMT-REASN
018633*    TO LCOMM-UWG-AMT-REASN-ARRAY (I).
018633     TO LCOMM-UWG-AMT-REASN-T (I).
018278
018278 5211-SWAP-TWRK-X.
018278     EXIT.

      *--------------------
       5212-EDIT-UW-LIMIT.
      *--------------------
      *
      *   EDIT UW LIMIT: EDIT THE CLIENTS AMOUNT TO BE UNDERWRITTEN
      *   WITH THE UNDERWRITERS LIMIT TO DETERMINE IF THE UNDERWRITER
      *   HAS AUTHORITY TO MAKE THE DECISION.
      *

           MOVE 'N'                   TO WS-WITHIN-UW-LIMIT.
      *
      *   DETERMINE UNDERWRITER LIMIT FOR DECISION MAKING
      *
           PERFORM  5910-DETERMINE-UW-LIMIT
               THRU 5910-DETERMINE-UW-LIMIT-X.

           IF L1510-RETRN-USCL-NOT-FOUND
      *MSG:   USCL RECORD FOR UW LIMIT NOT FOUND - KEY @1
              MOVE 'NS12500025'       TO WGLOB-MSG-REF-INFO
              MOVE L1510-USER-SEC-CLASS
                                      TO WGLOB-MSG-PARM (1)
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5212-EDIT-UW-LIMIT-X
           END-IF.

           IF L1510-RETRN-AMT-ERROR
      *MSG:   UW LIMIT MUST BE NUMERIC - SEE USCL KEY @1
              MOVE 'NS12500026'       TO WGLOB-MSG-REF-INFO
              MOVE L1510-USER-SEC-CLASS
                                      TO WGLOB-MSG-PARM (1)
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5212-EDIT-UW-LIMIT-X
           END-IF.

      *
      *   DETERMINE THE AMOUNT TO BE UNDERWRITTEN FOR THE CLIENT
      *
           PERFORM  5920-DETERMINE-UW-AMOUNT
               THRU 5920-DETERMINE-UW-AMOUNT-X.
           IF NOT L1390-RETRN-OK
               GO TO 5212-EDIT-UW-LIMIT-X
           END-IF.
      *
      *   CHECK UNDERWRITERS LIMIT AGAINST AMOUNT TO BE UNDERWRITTEN
      *
           IF L1390-BUSINESS-CLASS = 'H'
               MOVE L1390-H-UW-AMOUNT TO WS-UW-AMOUNT
           ELSE
               MOVE L1390-UW-AMOUNT   TO WS-UW-AMOUNT
           END-IF.

           IF L1510-USER-UW-LIMIT NOT <  WS-UW-AMOUNT
               SET SW-WITHIN-UW-LIMIT TO TRUE
           END-IF.

       5212-EDIT-UW-LIMIT-X.
           EXIT.
      *
      *------------------------
       5910-DETERMINE-UW-LIMIT.
      *------------------------
      *
      *   DETERMINE UW LIMIT: LINK TO THE UNDERWRITER LIMIT MODULE
      *
           PERFORM  1510-1000-BUILD-PARM-INFO
               THRU 1510-1000-BUILD-PARM-INFO-X.

           PERFORM  1510-1000-GET-UW-LIMIT
               THRU 1510-1000-GET-UW-LIMIT-X.
      *
       5910-DETERMINE-UW-LIMIT-X.
           EXIT.
      *
      *-------------------------
       5920-DETERMINE-UW-AMOUNT.
      *-------------------------
      *
      *   DETERMINE UW AMOUNT: LINK TO THE MODULE TO DETERMINE THE
      *   AMOUNT OF INSURANCE TO BE UNDERWRITTEN.
      *
           PERFORM 1390-1000-BUILD-PARM-INFO
              THRU 1390-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID            TO L1390-CLIENT-NO.
           SET L1390-USER-ID-NOT-REQD TO TRUE.

           PERFORM  1390-1000-ACCUM-UW-AMT
               THRU 1390-1000-ACCUM-UW-AMT-X.

       5920-DETERMINE-UW-AMOUNT-X.
           EXIT.
016503*-------------------
016503 6000-GET-NXT-ACTV.
016503*-------------------
016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503
016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.
016503 6000-GET-NXT-ACTV-X.
016503     EXIT.
      *
      *--------------------
       8000-DISPLAY-CLIENT.
      *--------------------
      *
      *   DISPLAY CLIENT: DISPLAY CLIENT INFORMATION ON THE SCREEN
      *
013578*    IF L2437-CLI-SEX-CD = 'C'
013578*       MOVE L2437-CLI-CO-NM    TO MIR-CLI-SUR-NM
013578*    ELSE
013578*       MOVE L2437-CLI-SUR-NM   TO MIR-CLI-SUR-NM
013578*    END-IF.

013578     MOVE L0620-SCREEN-NAME      TO MIR-DV-INSRD-CLI-NM.
           MOVE L2437-CLI-BTH-DT      TO L1680-INTERNAL-1.
           MOVE WGLOB-SYSTEM-DATE-INT TO L1680-INTERNAL-2.
           PERFORM  1680-2000-COMP-DAYS-BETWEEN
               THRU 1680-2000-COMP-DAYS-BETWEEN-X.
024187*    MOVE L1680-NUMBER-OF-YEARS TO WS-PIC-ZZ9.
024187*    MOVE WS-PIC-ZZ9            TO MIR-DV-CLI-INSRD-AGE.
024187     MOVE L1680-NUMBER-OF-YEARS TO L0290-INPUT-V00.
024187     MOVE 0                     TO L0290-PRECISION.
024187     MOVE LENGTH OF MIR-DV-CLI-INSRD-AGE
024187                                TO L0290-MAX-OUT-LEN.
024187     PERFORM 0290-2000-FORMAT-FOR-MIR
024187        THRU 0290-2000-FORMAT-FOR-MIR-X.
024187     MOVE L0290-OUTPUT-DATA    TO MIR-DV-CLI-INSRD-AGE.


           MOVE L2437-CLI-SEX-CD      TO MIR-CLI-SEX-CD.
           MOVE L2437-CLI-SMKR-CD     TO MIR-CLI-SMKR-CD.
           MOVE L2437-CLI-UW-USER-1-ID              TO MIR-UW-USER-1-ID.
           MOVE L2437-CLI-UW-USER-2-ID              TO MIR-UW-USER-2-ID.

           IF MIR-CLI-UWGDECN-CD = SPACES
               MOVE L2437-CLI-UWGDECN-CD
                                      TO MIR-CLI-UWGDECN-CD
           END-IF.

           IF MIR-CLI-UWGDECN-TYP-CD = SPACES
               MOVE L2437-CLI-UWGDECN-TYP-CD
                                      TO MIR-CLI-UWGDECN-TYP-CD
           END-IF.

       8000-DISPLAY-CLIENT-X.
           EXIT.
      *-----------------------
       8100-DISPLAY-COVERAGES.
      *-----------------------
      *
      *   DISPLAY COVERAGES: GIVEN A STARTING KEY, SEARCH THE
      *   RELATIONSHIP FILE FOR ALL THE COVERAGES THAT THIS CLIENT IS
      *   AN INSURED ON, AND THEN DISPLAY THE APPROPRIATE DATA.
      *
      *   POSITION AT AND READ FIRST RECORD FOR THE GIVEN SCREEN
      *
           MOVE ZEROS                 TO WS-RL-IO-STATUS.
018278*    PERFORM RL-1000-BROWSE
018278*       THRU RL-1000-BROWSE-X.
018278*
018278     IF  WS-LIST-BCKWRD
018278         PERFORM  RL-1000-BROWSE-PREV
018278             THRU RL-1000-BROWSE-PREV-X
018278     ELSE
018278         PERFORM  RL-1000-BROWSE
018278             THRU RL-1000-BROWSE-X
018278     END-IF.

           IF WRL-IO-OK
               PERFORM  8110-GET-NEXT-INSURED
                   THRU 8110-GET-NEXT-INSURED-X
                        VARYING I FROM 1 BY 1
                          UNTIL I > WS-SKIP
                             OR WRL-IO-EOF
                             OR NOT WGLOB-GOOD-RETURN
           ELSE
               MOVE WRL-IO-STATUS     TO WS-RL-IO-STATUS
               GO TO 8100-DISPLAY-COVERAGES-X
557660     END-IF.
      *
      *   DISPLAY THE COVERAGE RECORD
      *
           PERFORM  8120-PROCESS-INSURED
               THRU 8120-PROCESS-INSURED-X
018278*               UNTIL (WS-LINE > WS-NO-DISPLAY-LINES)
018278                UNTIL (WS-LINE >= WS-NO-DISPLAY-LINES)
                         OR (WRL-IO-EOF)
                         OR NOT WGLOB-GOOD-RETURN.

           MOVE WRL-IO-STATUS         TO WS-RL-IO-STATUS.
018278*    PERFORM RL-3000-END-BROWSE
018278*       THRU RL-3000-END-BROWSE-X.
018278
018278     IF  WS-LIST-BCKWRD
018278         PERFORM  RL-3000-END-BROWSE-PREV
018278             THRU RL-3000-END-BROWSE-PREV-X
018278     ELSE
018278         PERFORM  RL-3000-END-BROWSE
018278             THRU RL-3000-END-BROWSE-X
018278     END-IF.
018278
014221     PERFORM  POL-2000-BUILD-MNTS-TWRK
014221         THRU POL-2000-BUILD-MNTS-TWRK-X.

       8100-DISPLAY-COVERAGES-X.
           EXIT.
      *
      *-----------------------
       8110-GET-NEXT-INSURED.
      *-----------------------
      *
      *   GET NEXT INSURED: READ THE RELATIONSHIP FILE TO FIND THE NEXT
      *   INSURED RECORD FOR THIS CLIENT.
      *

           MOVE 'N'                   TO WS-INSURED-FOUND.
018278     MOVE 'N'                   TO WS-COVERAGE-FOUND.

           PERFORM  8111-GET-NEXT-INSURED-L
               THRU 8111-GET-NEXT-INSURED-L-X
018278*             UNTIL SW-INSURED-FOUND
018278              UNTIL SW-COVERAGE-FOUND
                       OR WRL-IO-EOF
                       OR NOT WGLOB-GOOD-RETURN.

       8110-GET-NEXT-INSURED-X.
           EXIT.

      *
      *------------------------
       8111-GET-NEXT-INSURED-L.
      *------------------------
      *
      *   GET NEXT INSURED L: LOOP THROUGH THE RELATIONSHIP FILE,
      *   SEARCHING FOR AN INSURED RECORD
018278*   WITH A NON-SETTLED COVERAGE
018278*
      *
018278*    PERFORM RL-2000-READ-NEXT
018278*       THRU RL-2000-READ-NEXT-X.
018278*
018278     IF  WS-LIST-BCKWRD
018278         PERFORM  RL-2000-READ-PREV
018278             THRU RL-2000-READ-PREV-X
018278     ELSE
018278         PERFORM  RL-2000-READ-NEXT
018278             THRU RL-2000-READ-NEXT-X
018278     END-IF.

      *
      *   CHECK FOR RIGHT CLIENT AND SYSTEM, ELSE SET END OF FILE
      *
           IF NOT WRL-IO-OK
               GO TO 8111-GET-NEXT-INSURED-L-X
557660     END-IF.
      *
      *   CHECK FOR INSURED
      *
           IF RRL-REL-TYP-CD  NOT = 'I'
               GO TO 8111-GET-NEXT-INSURED-L-X
557660     END-IF.
      *
      *   FIRST GET THE POLICY AND DO VARIOUS CHECKS
      *
           IF  RRL-REL-SYS-REF-POL-ID NOT = WS-LAST-POL-CHEKD
014221         SET WS-NEW-POL               TO TRUE
               PERFORM  8112-CHECK-POLICY
                   THRU 8112-CHECK-POLICY-X
014221     ELSE
018278         SET WS-NEW-POL-NO            TO TRUE
557660     END-IF.
      *
           IF  SW-CHECKS-FAILED
               GO TO  8111-GET-NEXT-INSURED-L-X
557660     END-IF.
      *
      *   INSURED HAS BEEN FOUND
      *
           SET SW-INSURED-FOUND TO TRUE.
      *
      *   BUILD KEY AND THEN READ THE COVERAGE RECORD
      *
           MOVE RRL-REL-SYS-REF-POL-ID                   TO WCVG-POL-ID.
           MOVE RRL-REL-SYS-REF-CVG-NUM
                                      TO WCVG-CVG-NUM.
           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X.
           IF WCVG-IO-NOT-FOUND
               MOVE 'XS00000056'      TO WGLOB-MSG-REF-INFO
               MOVE WCVG-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
018278         GO TO 8111-GET-NEXT-INSURED-L-X
           END-IF.

018278     SET SW-COVERAGE-FOUND              TO TRUE.
014221     IF  WS-NEW-POL
014221         MOVE  RRL-REL-SYS-REF-POL-ID   TO WPOL-POL-ID
014221         PERFORM  POL-1000-READ-MNTS-TS
014221             THRU POL-1000-READ-MNTS-TS-X
018278     END-IF.

       8111-GET-NEXT-INSURED-L-X.
           EXIT.
      *
      *------------------
       8112-CHECK-POLICY.
      *------------------
      *
      *  CHECK POLICY: CHECK THE POLICY CONFIDENTIALITY, BRANCH
      *  SECURITY AND STATUS TO DETERMINE IF WE CAN PROCESS THE
      *  COVERAGE.
      *
           MOVE  RRL-REL-SYS-REF-POL-ID
                                      TO WS-LAST-POL-CHEKD.
           MOVE  ZEROES               TO  WS-CHECKS-FAILED.
           MOVE  RRL-REL-SYS-REF-POL-ID
                                      TO WPOL-POL-ID.
           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
               MOVE  'XS00000097'     TO WGLOB-MSG-REF-INFO
               MOVE  WPOL-KEY         TO  WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO  8112-CHECK-POLICY-X
557660     END-IF.

012148     PERFORM  8240-1000-BUILD-PARM-INFO
012148         THRU 8240-1000-BUILD-PARM-INFO-X.
012148     MOVE WPOL-POL-ID           TO L8240-POL-ID.
012148     PERFORM  8240-1000-RETRIEVE-POLW
012148         THRU 8240-1000-RETRIEVE-POLW-X.

      *
      *  DO POLICY CONFIDENTIALITY CHECK
      *
           PERFORM 5400-1000-BUILD-PARM-INFO
              THRU 5400-1000-BUILD-PARM-INFO-X.
012624*    SET L5400-CTL-MSG-NOT-REQD  TO TRUE.
           SET L5400-STAT-MSG-NOT-REQD TO TRUE.
012624*    MOVE WGLOB-APPL-ID         TO L5400-SYS-APPL-CTL-CD.


           PERFORM 5400-1000-POL-CHK
              THRU 5400-1000-POL-CHK-X.
           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
016440     OR  L5400-XFER-ACCS-WARNING
               SET SW-CHECKS-FAILED TO TRUE
               GO TO  8112-CHECK-POLICY-X
           END-IF.

       8112-CHECK-POLICY-X.
           EXIT.
      *
      *---------------------
       8120-PROCESS-INSURED.
      *---------------------
      *
      *   DISPLAY THE COVERGE INFORMATION
      *

016440* ONLY DISPLAY COVERAGE FOR PENDING OR REJECTED COVERAGES

016440*    IF  RCVG-CVG-STAT-IN-FORCE
016440*    AND RPOL-POL-NOT-SUSPENDED
016440     IF  NOT RCVG-CVG-STAT-BEFORE-SETL
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               PERFORM  8121-DISPLAY-COVERAGE
                   THRU 8121-DISPLAY-COVERAGE-X
557660     END-IF.
      *
      *   GET THE NEXT INSURED RELATIONSHIP RECORD
      *
           PERFORM  8110-GET-NEXT-INSURED
               THRU 8110-GET-NEXT-INSURED-X.

       8120-PROCESS-INSURED-X.
           EXIT.
      *
      *----------------------
       8121-DISPLAY-COVERAGE.
      *----------------------
      *
      *   DISPLAY THE COVERAGE DATA
      *
018278     ADD +1                     TO WS-LINE.
018278
018278     IF  WS-LINE = 1
018278         IF  WS-LIST-BCKWRD
018633*            MOVE WRL-KEY       TO WS-HI-RL-KEY
018633             MOVE WRL-KEY       TO LCOMM-HI-RL-KEY
018278         ELSE
018633*            MOVE WRL-KEY       TO WS-LO-RL-KEY
018633             MOVE WRL-KEY       TO LCOMM-LO-RL-KEY
018278         END-IF
018278     END-IF.
018278
018278     IF  WS-LIST-BCKWRD
018633*        MOVE WRL-KEY           TO WS-LO-RL-KEY
018633         MOVE WRL-KEY           TO LCOMM-LO-RL-KEY
018278     ELSE
018633*        MOVE WRL-KEY           TO WS-HI-RL-KEY
018633         MOVE WRL-KEY           TO LCOMM-HI-RL-KEY
018278     END-IF.

           MOVE RCVG-POL-ID-BASE      TO MIR-POL-ID-BASE-T (WS-LINE).
           MOVE RCVG-POL-ID-SFX       TO MIR-POL-ID-SFX-T (WS-LINE).
           MOVE RCVG-CVG-NUM          TO MIR-CVG-NUM-T (WS-LINE).

           MOVE RCVG-PLAN-ID          TO MIR-PLAN-ID-T (WS-LINE).

008455*    MOVE RCVG-CVG-FACE-AMT       TO WS-PIC-LEN12.
008455*    MOVE WS-PIC-LEN12            TO MIR-CVG-FACE-AMT-T (WS-LINE).
020874*    COMPUTE L0290-INPUT-NUMBER = RCVG-CVG-FACE-AMT * 100.
020874     MOVE RCVG-CVG-FACE-AMT     TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-FACE-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.

008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-FACE-AMT-T (WS-LINE).
008455*    MOVE RCVG-CVG-AD-FACE-AMT    TO WS-PIC-LEN12.
008455*    MOVE WS-PIC-LEN12     TO MIR-CVG-AD-FACE-AMT-T (WS-LINE).
020874*    COMPUTE L0290-INPUT-NUMBER = RCVG-CVG-AD-FACE-AMT * 100.
020874     MOVE RCVG-CVG-AD-FACE-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-AD-FACE-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA    TO MIR-CVG-AD-FACE-AMT-T (WS-LINE).

020874*    MOVE RCVG-CVG-AD-MULT-FCT  TO WS-PIC-LEN4.
020874*    MOVE WS-PIC-LEN4          TO MIR-CVG-AD-MULT-FCT-T (WS-LINE).
020874     MOVE RCVG-CVG-AD-MULT-FCT  TO L0290-INPUT-V02.
020874     MOVE 2                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CVG-AD-MULT-FCT-T (WS-LINE)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA    TO MIR-CVG-AD-MULT-FCT-T (WS-LINE).

020874*    MOVE RCVG-CVG-WP-MULT-FCT  TO WS-PIC-LEN4.
020874*    MOVE WS-PIC-LEN4          TO MIR-CVG-WP-MULT-FCT-T (WS-LINE).
020874     MOVE RCVG-CVG-WP-MULT-FCT  TO L0290-INPUT-V02.
020874     MOVE 2                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CVG-WP-MULT-FCT-T (WS-LINE)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA    TO MIR-CVG-WP-MULT-FCT-T (WS-LINE).
           MOVE RCVG-CVG-STBL-1-CD    TO MIR-CVG-STBL-1-CD-T (WS-LINE).
           MOVE RCVG-CVG-STBL-2-CD    TO MIR-CVG-STBL-2-CD-T (WS-LINE).
           MOVE RCVG-CVG-STBL-3-CD    TO MIR-CVG-STBL-3-CD-T (WS-LINE).
           MOVE RCVG-CVG-STBL-4-CD    TO MIR-CVG-STBL-4-CD-T (WS-LINE).
           MOVE RCVG-CVG-ENHC-TYP-CD
                                   TO MIR-CVG-ENHC-TYP-CD-T   (WS-LINE).
           MOVE RCVG-CVG-UWGDECN-CD   TO MIR-CVG-UWGDECN-CD-T (WS-LINE).

           MOVE RCVG-CVG-UWGDECN-SUB-CD
                                  TO MIR-CVG-UWGDECN-SUB-CD-T (WS-LINE).
           MOVE RCVG-CVG-COLA-SELCT-CD
                                  TO MIR-CVG-COLA-SELCT-CD-T  (WS-LINE).
           MOVE RCVG-REDC-EP-SELCT-IND
                                  TO MIR-REDC-EP-SELCT-IND-T  (WS-LINE).
           MOVE RCVG-OWN-OCCP-SELCT-IND
                                TO MIR-OWN-OCCP-SELCT-IND-T   (WS-LINE).
           MOVE RCVG-CVG-LTA-SELCT-IND
                                 TO MIR-CVG-LTA-SELCT-IND-T   (WS-LINE).
           MOVE RCVG-CVG-LTB-SELCT-IND
                                 TO MIR-CVG-LTB-SELCT-IND-T   (WS-LINE).
           MOVE RCVG-PDISAB-SELCT-IND
                                   TO MIR-PDISAB-SELCT-IND-T  (WS-LINE).
           MOVE RCVG-CVG-UWG-EXCL-CD (1)
                                   TO MIR-CVG-UWG-EXCL-1-CD-T (WS-LINE).
           MOVE RCVG-CVG-UWG-EXCL-CD (2)
                                   TO MIR-CVG-UWG-EXCL-2-CD-T (WS-LINE).
           MOVE RCVG-CVG-UWG-EXCL-CD (3)
                                   TO MIR-CVG-UWG-EXCL-3-CD-T (WS-LINE).
           MOVE RCVG-CVG-ME-REASN-CD TO MIR-CVG-ME-REASN-CD-T (WS-LINE).
           MOVE RCVG-CVG-FE-REASN-CD TO MIR-CVG-FE-REASN-CD-T (WS-LINE).
016641*    MOVE RCVG-CVG-ME-FCT       TO WS-PIC-LEN4.
016641*    MOVE WS-PIC-LEN4           TO MIR-CVG-ME-FCT-T (WS-LINE).
020874*    COMPUTE L0290-INPUT-NUMBER = RCVG-CVG-ME-FCT * 100.
020874     MOVE RCVG-CVG-ME-FCT      TO L0290-INPUT-V02.
016641     MOVE 2  TO L0290-PRECISION.
016641     MOVE LENGTH OF MIR-CVG-ME-FCT-T (WS-LINE)
016641                                TO L0290-MAX-OUT-LEN.
016641     SET L0290-SIGN-SUPPRESS              TO TRUE.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016641     MOVE L0290-OUTPUT-DATA TO MIR-CVG-ME-FCT-T (WS-LINE).
016641
557671     MOVE RCVG-CVG-ME-RAT-CD    TO MIR-CVG-ME-RAT-CD-T (WS-LINE).
           MOVE RCVG-CVG-ME-DUR       TO WS-PIC-LEN3.
           MOVE WS-PIC-LEN3           TO MIR-CVG-ME-DUR-T (WS-LINE).
008455*    MOVE RCVG-CVG-FE-UPREM-AMT   TO WS-PIC-LEN6.
008455*    MOVE WS-PIC-LEN6        TO MIR-CVG-FE-UPREM-AMT-T (WS-LINE).
020874*    COMPUTE L0290-INPUT-NUMBER = RCVG-CVG-FE-UPREM-AMT * 100.
020874     MOVE RCVG-CVG-FE-UPREM-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-FE-UPREM-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN.
013578     SET  L0290-SIGN-DISPLAY      TO TRUE.
013578     SET  L0290-SIGN-POS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA   TO MIR-CVG-FE-UPREM-AMT-T (WS-LINE).

           MOVE RCVG-CVG-FE-DUR       TO WS-PIC-LEN3.
           MOVE WS-PIC-LEN3           TO MIR-CVG-FE-DUR-T (WS-LINE).
           MOVE RCVG-CVG-RT-AGE       TO MIR-CVG-RT-AGE-T (WS-LINE).
           MOVE RCVG-AGE-RAT-REASN-CD
                                    TO MIR-AGE-RAT-REASN-CD-T (WS-LINE).
           MOVE RCVG-CVG-SMKR-CD      TO MIR-CVG-SMKR-CD-T (WS-LINE).
           MOVE RCVG-CVG-SEX-CD       TO MIR-CVG-SEX-CD-T (WS-LINE).
008455*    MOVE RCVG-CVG-UWG-AMT        TO WS-PIC-LEN9.
008455*    MOVE WS-PIC-LEN9             TO MIR-CVG-UWG-AMT-T (WS-LINE).
020874*    COMPUTE L0290-INPUT-NUMBER = RCVG-CVG-UWG-AMT.
020874     MOVE RCVG-CVG-UWG-AMT      TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-UWG-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-UWG-AMT-T (WS-LINE).

           MOVE RCVG-UWG-AMT-REASN-CD
                                    TO MIR-UWG-AMT-REASN-CD-T (WS-LINE).
008455*    MOVE RCVG-CVG-PREV-FACE-AMT  TO WS-PIC-LEN9Z.
008455*    MOVE WS-PIC-LEN9Z      TO MIR-CVG-PREV-FACE-AMT-T (WS-LINE).
020874*    COMPUTE L0290-INPUT-NUMBER = RCVG-CVG-PREV-FACE-AMT.
020874     MOVE RCVG-CVG-PREV-FACE-AMT  TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-PREV-FACE-AMT-T (WS-LINE)
008455                                TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS
020874*                               TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA  TO MIR-CVG-PREV-FACE-AMT-T (WS-LINE).

557767*    MOVE RCVG-CVG-LIVES-INSRD-CD-N
557767*                           TO MIR-CVG-LIVES-INSRD-CD-T (WS-LINE).
025388*    MOVE RCVG-CVG-LIVES-INSRD-CD
025388*                           TO MIR-CVG-LIVES-INSRD-CD-T (WS-LINE).
025388     MOVE RCVG-LIVES-INSRD-QTY
025388                          TO MIR-LIVES-INSRD-QTY-T (WS-LINE).
           MOVE RCVG-CVG-SUPP-BNFT-CD
                                    TO MIR-CVG-SUPP-BNFT-CD-T (WS-LINE).
           MOVE RPOL-POL-OPTL-CD      TO MIR-POL-OPTL-CD-T (WS-LINE).
           MOVE RPOL-LINK-POL-ISS-IND
                                    TO MIR-LINK-POL-ISS-IND-T (WS-LINE).
           MOVE RCVG-CVG-CSTAT-CD     TO MIR-CVG-CSTAT-CD-T (WS-LINE).
           MOVE RCVG-CVG-SPND-CSTAT-CD
                                   TO MIR-CVG-SPND-CSTAT-CD-T (WS-LINE).

013578     PERFORM 8200-SAVE-RETRIEVE-INFO
013578        THRU 8200-SAVE-RETRIEVE-INFO-X.

018278*    ADD 1 TO WS-LINE.
018278*
       8121-DISPLAY-COVERAGE-X.
           EXIT.
      *
013578*----------------------
013578 8200-SAVE-RETRIEVE-INFO.
013578*----------------------
013578
013578*    SOME FIELDS NEED TO BE STORED IN TWRK AS A CHECK FOR THE
013578*    UPDATE TO DETERMINE WHICH FIELDS HAVE INDEED BEEN UPDATED.
013578
018633*    MOVE RCVG-PLAN-ID      TO WS-PLAN-ID-ARRAY (WS-LINE).
018633     MOVE RCVG-PLAN-ID      TO LCOMM-PLAN-ID-T (WS-LINE).
013578
020874*    COMPUTE L0290-INPUT-NUMBER = RCVG-CVG-FACE-AMT * 100.
020874     MOVE RCVG-CVG-FACE-AMT TO L0290-INPUT-V02.
013578     MOVE 2                 TO L0290-PRECISION.
018633*    MOVE LENGTH OF WS-CVG-FACE-AMT-ARRAY (WS-LINE)
018633     MOVE LENGTH OF LCOMM-CVG-FACE-AMT-T (WS-LINE)
013578                            TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
013578
018633*    MOVE L0290-OUTPUT-DATA TO WS-CVG-FACE-AMT-ARRAY (WS-LINE).
018633     MOVE L0290-OUTPUT-DATA TO LCOMM-CVG-FACE-AMT-T (WS-LINE).
013578
020874*    COMPUTE L0290-INPUT-NUMBER = RCVG-CVG-AD-FACE-AMT * 100.
020874     MOVE RCVG-CVG-AD-FACE-AMT  TO L0290-INPUT-V02.
013578     MOVE 2                 TO L0290-PRECISION.
018633*    MOVE LENGTH OF WS-CVG-AD-FACE-AMT-ARRAY (WS-LINE)
018633     MOVE LENGTH OF LCOMM-CVG-AD-FACE-AMT-T (WS-LINE)
013578                            TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018633*    MOVE L0290-OUTPUT-DATA TO WS-CVG-AD-FACE-AMT-ARRAY (WS-LINE).
018633     MOVE L0290-OUTPUT-DATA TO LCOMM-CVG-AD-FACE-AMT-T (WS-LINE).
013578
013578     MOVE RCVG-CVG-AD-MULT-FCT  TO WS-PIC-LEN4.
018633*    MOVE WS-PIC-LEN4       TO WS-CVG-AD-MULT-FCT-ARRAY (WS-LINE).
018633     MOVE WS-PIC-LEN4       TO LCOMM-CVG-AD-MULT-FCT-T (WS-LINE).
013578
013578     MOVE RCVG-CVG-WP-MULT-FCT  TO WS-PIC-LEN4.
018633*    MOVE WS-PIC-LEN4       TO WS-CVG-WP-MULT-FCT-ARRAY (WS-LINE).
018633     MOVE WS-PIC-LEN4       TO LCOMM-CVG-WP-MULT-FCT-T (WS-LINE).
013578
018633*    MOVE RCVG-CVG-STBL-1-CD    TO WS-CVG-STBL-1-ARRAY (WS-LINE).
018633*    MOVE RCVG-CVG-STBL-2-CD    TO WS-CVG-STBL-2-ARRAY (WS-LINE).
018633*    MOVE RCVG-CVG-STBL-3-CD    TO WS-CVG-STBL-3-ARRAY (WS-LINE).
018633*    MOVE RCVG-CVG-STBL-4-CD    TO WS-CVG-STBL-4-ARRAY (WS-LINE).
018633     MOVE RCVG-CVG-STBL-1-CD    TO LCOMM-CVG-STBL-1-T (WS-LINE).
018633     MOVE RCVG-CVG-STBL-2-CD    TO LCOMM-CVG-STBL-2-T (WS-LINE).
018633     MOVE RCVG-CVG-STBL-3-CD    TO LCOMM-CVG-STBL-3-T (WS-LINE).
018633     MOVE RCVG-CVG-STBL-4-CD    TO LCOMM-CVG-STBL-4-T (WS-LINE).
013578     MOVE RCVG-CVG-ENHC-TYP-CD
018633*                            TO WS-CVG-ENHC-TYP-ARRAY  (WS-LINE).
018633*    MOVE RCVG-CVG-UWGDECN-CD   TO WS-CVG-DECN-ARRAY (WS-LINE).
018633                             TO LCOMM-CVG-ENHC-TYP-T (WS-LINE).
018633     MOVE RCVG-CVG-UWGDECN-CD   TO LCOMM-CVG-DECN-T (WS-LINE).
013578     MOVE RCVG-CVG-UWGDECN-SUB-CD
018633*                           TO WS-CVG-DECN-SUB-ARRAY (WS-LINE).
018633                            TO LCOMM-CVG-DECN-SUB-T (WS-LINE).
013578     MOVE RCVG-CVG-COLA-SELCT-CD
018633*                           TO WS-CVG-COLA-SELCT-ARRAY (WS-LINE).
018633                            TO LCOMM-CVG-COLA-SELCT-T (WS-LINE).
013578     MOVE RCVG-REDC-EP-SELCT-IND
018633*                           TO WS-REDC-EP-SELCT-ARRAY  (WS-LINE).
018633                            TO LCOMM-REDC-EP-SELCT-T (WS-LINE).
013578     MOVE RCVG-OWN-OCCP-SELCT-IND
018633*                         TO WS-OWN-OCCP-SELCT-ARRAY (WS-LINE).
018633                          TO LCOMM-OWN-OCCP-SELCT-T (WS-LINE).
013578     MOVE RCVG-CVG-LTA-SELCT-IND
018633*                          TO WS-CVG-LTA-SELCT-ARRAY   (WS-LINE).
018633                           TO LCOMM-CVG-LTA-SELCT-T (WS-LINE).
013578     MOVE RCVG-CVG-LTB-SELCT-IND
018633*                          TO WS-CVG-LTB-SELCT-ARRAY   (WS-LINE).
018633                           TO LCOMM-CVG-LTB-SELCT-T (WS-LINE).
013578     MOVE RCVG-PDISAB-SELCT-IND
018633*                            TO WS-PDISAB-SELCT-ARRAY (WS-LINE).
018633                             TO LCOMM-PDISAB-SELCT-T (WS-LINE).
013578     MOVE RCVG-CVG-UWG-EXCL-CD (1)
018633*                            TO WS-CVG-UWG-EXCL-1-ARRAY (WS-LINE).
018633                             TO LCOMM-CVG-UWG-EXCL-1-T (WS-LINE).
013578     MOVE RCVG-CVG-UWG-EXCL-CD (2)
018633*                            TO WS-CVG-UWG-EXCL-2-ARRAY (WS-LINE).
018633                             TO LCOMM-CVG-UWG-EXCL-2-T (WS-LINE).
013578     MOVE RCVG-CVG-UWG-EXCL-CD (3)
018633*                            TO WS-CVG-UWG-EXCL-3-ARRAY (WS-LINE).
018633*    MOVE RCVG-CVG-ME-REASN-CD TO WS-CVG-ME-REASN-ARRAY (WS-LINE).
018633*    MOVE RCVG-CVG-FE-REASN-CD TO WS-CVG-FE-REASN-ARRAY (WS-LINE).
018633                             TO LCOMM-CVG-UWG-EXCL-3-T (WS-LINE).
018633     MOVE RCVG-CVG-ME-REASN-CD TO LCOMM-CVG-ME-REASN-T (WS-LINE).
018633     MOVE RCVG-CVG-FE-REASN-CD TO LCOMM-CVG-FE-REASN-T (WS-LINE).
013578     MOVE RCVG-CVG-ME-FCT       TO WS-PIC-LEN4.
018633*    MOVE WS-PIC-LEN4         TO WS-CVG-ME-FCT-ARRAY (WS-LINE).
018633*    MOVE RCVG-CVG-ME-RAT-CD  TO WS-CVG-ME-RAT-ARRAY (WS-LINE).
018633     MOVE WS-PIC-LEN4         TO LCOMM-CVG-ME-FCT-T (WS-LINE).
018633     MOVE RCVG-CVG-ME-RAT-CD  TO LCOMM-CVG-ME-RAT-T (WS-LINE).
013578     MOVE RCVG-CVG-ME-DUR     TO WS-PIC-LEN3.
018633*    MOVE WS-PIC-LEN3         TO WS-CVG-ME-DUR-ARRAY (WS-LINE).
018633     MOVE WS-PIC-LEN3         TO LCOMM-CVG-ME-DUR-T (WS-LINE).
020874*    COMPUTE L0290-INPUT-NUMBER = RCVG-CVG-FE-UPREM-AMT * 100.
020874     MOVE RCVG-CVG-FE-UPREM-AMT TO L0290-INPUT-V02.
013578     MOVE 2                     TO L0290-PRECISION.
018633*    MOVE LENGTH OF WS-CVG-FE-UPREM-AMT-ARRAY (WS-LINE)
018633     MOVE LENGTH OF LCOMM-CVG-FE-UPREM-AMT-T (WS-LINE)
013578                                TO L0290-MAX-OUT-LEN.
013578     SET  L0290-SIGN-DISPLAY      TO TRUE.
013578     SET  L0290-SIGN-POS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
013578     MOVE L0290-OUTPUT-DATA
018633*                      TO WS-CVG-FE-UPREM-AMT-ARRAY (WS-LINE).
018633                       TO LCOMM-CVG-FE-UPREM-AMT-T (WS-LINE).
013578
013578     MOVE RCVG-CVG-FE-DUR      TO WS-PIC-LEN3.
018633*    MOVE WS-PIC-LEN3          TO WS-CVG-FE-DUR-ARRAY (WS-LINE).
018633*    MOVE RCVG-CVG-RT-AGE      TO WS-CVG-RT-AGE-ARRAY (WS-LINE).
018633     MOVE WS-PIC-LEN3          TO LCOMM-CVG-FE-DUR-T (WS-LINE).
018633     MOVE RCVG-CVG-RT-AGE      TO LCOMM-CVG-RT-AGE-T (WS-LINE).
013578     MOVE RCVG-AGE-RAT-REASN-CD
018633*                          TO LCOMM-AGE-RAT-REASN-ARRAY (WS-LINE).
018633                           TO LCOMM-AGE-RAT-REASN-T (WS-LINE).
018633*    MOVE RCVG-CVG-SMKR-CD     TO WS-CVG-SMKR-ARRAY (WS-LINE).
018633*    MOVE RCVG-CVG-SEX-CD      TO WS-CVG-SEX-ARRAY (WS-LINE).
018633     MOVE RCVG-CVG-SMKR-CD     TO LCOMM-CVG-SMKR-T (WS-LINE).
018633     MOVE RCVG-CVG-SEX-CD      TO LCOMM-CVG-SEX-T (WS-LINE).
020874*    COMPUTE L0290-INPUT-NUMBER = RCVG-CVG-UWG-AMT.
020874     MOVE RCVG-CVG-UWG-AMT     TO L0290-INPUT-V00.
013578     MOVE 0                    TO L0290-PRECISION.
018633*    MOVE LENGTH OF WS-CVG-UWG-AMT-ARRAY (WS-LINE)
018633     MOVE LENGTH OF LCOMM-CVG-UWG-AMT-T (WS-LINE)
013578                               TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
018633*    MOVE L0290-OUTPUT-DATA    TO WS-CVG-UWG-AMT-ARRAY (WS-LINE).
018633     MOVE L0290-OUTPUT-DATA    TO LCOMM-CVG-UWG-AMT-T (WS-LINE).
013578
013578     MOVE RCVG-UWG-AMT-REASN-CD
018633*                         TO LCOMM-UWG-AMT-REASN-ARRAY (WS-LINE).
018633                              TO LCOMM-UWG-AMT-REASN-T (WS-LINE).
013578
013578 8200-SAVE-RETRIEVE-INFO-X.
013578     EXIT.
013578*

013578*-----------------------
013578 8300-CHECK-UPDATE-FIELDS.
013578*-----------------------
013578
018633*    IF WS-CVG-DECN-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-DECN-T (WS-IDX)
013578                              = MIR-CVG-UWGDECN-CD-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-CVG-UWGDECN-CD-T (WS-IDX)
013578     END-IF.
013578
013578
018633*    IF WS-CVG-DECN-SUB-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-DECN-SUB-T (WS-IDX)
013578                            =  MIR-CVG-UWGDECN-SUB-CD-T (WS-IDX)
013578        MOVE SPACES    TO      MIR-CVG-UWGDECN-SUB-CD-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-PLAN-ID-ARRAY (WS-IDX)
018633     IF LCOMM-PLAN-ID-T (WS-IDX)
013578                              = MIR-PLAN-ID-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-PLAN-ID-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-FACE-AMT-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-FACE-AMT-T (WS-IDX)
013578                            =  MIR-CVG-FACE-AMT-T (WS-IDX)
013578        MOVE SPACES    TO      MIR-CVG-FACE-AMT-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-AD-FACE-AMT-ARRAY(WS-IDX)
018633     IF LCOMM-CVG-AD-FACE-AMT-T(WS-IDX)
013578                              = MIR-CVG-AD-FACE-AMT-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-CVG-AD-FACE-AMT-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-AD-MULT-FCT-ARRAY(WS-IDX)
018633     IF LCOMM-CVG-AD-MULT-FCT-T(WS-IDX)
013578                              = MIR-CVG-AD-MULT-FCT-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-CVG-AD-MULT-FCT-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-WP-MULT-FCT-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-WP-MULT-FCT-T (WS-IDX)
013578                            =  MIR-CVG-WP-MULT-FCT-T (WS-IDX)
013578        MOVE SPACES    TO      MIR-CVG-WP-MULT-FCT-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-STBL-1-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-STBL-1-T (WS-IDX)
013578                              = MIR-CVG-STBL-1-CD-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-CVG-STBL-1-CD-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-STBL-2-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-STBL-2-T (WS-IDX)
013578                              = MIR-CVG-STBL-2-CD-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-CVG-STBL-2-CD-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-STBL-3-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-STBL-3-T (WS-IDX)
013578                              = MIR-CVG-STBL-3-CD-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-CVG-STBL-3-CD-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-STBL-4-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-STBL-4-T (WS-IDX)
013578                              = MIR-CVG-STBL-4-CD-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-CVG-STBL-4-CD-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-ENHC-TYP-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-ENHC-TYP-T (WS-IDX)
                                    = MIR-CVG-ENHC-TYP-CD-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-CVG-ENHC-TYP-CD-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-ME-FCT-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-ME-FCT-T (WS-IDX)
013578                            =  MIR-CVG-ME-FCT-T (WS-IDX)
013578        MOVE SPACES    TO      MIR-CVG-ME-FCT-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-ME-RAT-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-ME-RAT-T (WS-IDX)
013578                              = MIR-CVG-ME-RAT-CD-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-CVG-ME-RAT-CD-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-ME-REASN-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-ME-REASN-T (WS-IDX)
013578                            =  MIR-CVG-ME-REASN-CD-T (WS-IDX)
013578        MOVE SPACES    TO      MIR-CVG-ME-REASN-CD-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-COLA-SELCT-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-COLA-SELCT-T (WS-IDX)
013578                              = MIR-CVG-COLA-SELCT-CD-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-CVG-COLA-SELCT-CD-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-REDC-EP-SELCT-ARRAY (WS-IDX)
018633     IF LCOMM-REDC-EP-SELCT-T (WS-IDX)
013578                            =  MIR-REDC-EP-SELCT-IND-T (WS-IDX)
013578        MOVE SPACES    TO      MIR-REDC-EP-SELCT-IND-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-OWN-OCCP-SELCT-ARRAY (WS-IDX)
018633     IF LCOMM-OWN-OCCP-SELCT-T (WS-IDX)
013578                            =  MIR-OWN-OCCP-SELCT-IND-T (WS-IDX)
013578        MOVE SPACES    TO      MIR-OWN-OCCP-SELCT-IND-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-LTA-SELCT-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-LTA-SELCT-T (WS-IDX)
013578                            =  MIR-CVG-LTA-SELCT-IND-T (WS-IDX)
013578        MOVE SPACES    TO      MIR-CVG-LTA-SELCT-IND-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-LTB-SELCT-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-LTB-SELCT-T (WS-IDX)
013578                            =  MIR-CVG-LTB-SELCT-IND-T (WS-IDX)
013578        MOVE SPACES    TO      MIR-CVG-LTB-SELCT-IND-T (WS-IDX)
013578     END-IF.
013578
013578     IF LCOMM-PDISAB-SELCT-T (WS-IDX)
013578                            =  MIR-PDISAB-SELCT-IND-T (WS-IDX)
013578        MOVE SPACES    TO      MIR-PDISAB-SELCT-IND-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-UWG-EXCL-1-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-UWG-EXCL-1-T (WS-IDX)
013578                              = MIR-CVG-UWG-EXCL-1-CD-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-CVG-UWG-EXCL-1-CD-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-UWG-EXCL-2-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-UWG-EXCL-2-T (WS-IDX)
013578                              = MIR-CVG-UWG-EXCL-2-CD-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-CVG-UWG-EXCL-2-CD-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-UWG-EXCL-3-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-UWG-EXCL-3-T (WS-IDX)
013578                              = MIR-CVG-UWG-EXCL-3-CD-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-CVG-UWG-EXCL-3-CD-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-ME-DUR-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-ME-DUR-T (WS-IDX)
013578                            =  MIR-CVG-ME-DUR-T (WS-IDX)
013578        MOVE SPACES    TO      MIR-CVG-ME-DUR-T (WS-IDX)
013578     END-IF.
013578

013578     MOVE MIR-CVG-FE-UPREM-AMT-T (WS-IDX) TO L0280-INPUT-DATA.
013578     SET L0280-SIGN-PERMITTED             TO TRUE.
013578     MOVE LENGTH OF MIR-CVG-FE-UPREM-AMT-T (WS-IDX)
013578                                          TO L0280-INPUT-SIZE.
013578     MOVE LENGTH OF MIR-CVG-FE-UPREM-AMT-T (WS-IDX)
013578                                          TO L0280-LENGTH.
013578     MOVE '2'                             TO L0280-PRECISION.
013578     PERFORM 0280-1000-NUMERIC-EDIT
013578        THRU 0280-1000-NUMERIC-EDIT-X.
013578     IF L0280-OK
013578        MOVE L0280-OUTPUT-V02             TO WS-PIC-LEN11
020874*       COMPUTE L0290-INPUT-NUMBER = WS-PIC-LEN11 * 100
020874        MOVE WS-PIC-LEN11                 TO L0290-INPUT-V02
013578        MOVE 2                            TO L0290-PRECISION
013578        MOVE LENGTH OF MIR-CVG-FE-UPREM-AMT-T (WS-IDX)
013578                                          TO L0290-MAX-OUT-LEN
013578        SET L0290-SIGN-DISPLAY      TO TRUE
013578        SET L0290-SIGN-POS-DISPLAY  TO TRUE
020874*       PERFORM  0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874        PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU 0290-2000-FORMAT-FOR-MIR-X
013578        MOVE L0290-OUTPUT-DATA TO MIR-CVG-FE-UPREM-AMT-T (WS-IDX)
013578     END-IF.

018633*    IF WS-CVG-FE-UPREM-AMT-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-FE-UPREM-AMT-T (WS-IDX)
013578                              = MIR-CVG-FE-UPREM-AMT-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-CVG-FE-UPREM-AMT-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-FE-REASN-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-FE-REASN-T (WS-IDX)
013578                            =  MIR-CVG-FE-REASN-CD-T (WS-IDX)
013578        MOVE SPACES    TO      MIR-CVG-FE-REASN-CD-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-FE-DUR-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-FE-DUR-T (WS-IDX)
013578                              = MIR-CVG-FE-DUR-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-CVG-FE-DUR-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-RT-AGE-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-RT-AGE-T (WS-IDX)
013578                            =  MIR-CVG-RT-AGE-T (WS-IDX)
013578        MOVE SPACES    TO      MIR-CVG-RT-AGE-T (WS-IDX)
013578     END-IF.
013578
013578     IF LCOMM-AGE-RAT-REASN-T (WS-IDX)
013578                              = MIR-AGE-RAT-REASN-CD-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-AGE-RAT-REASN-CD-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-SMKR-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-SMKR-T (WS-IDX)
013578                            =  MIR-CVG-SMKR-CD-T (WS-IDX)
013578        MOVE SPACES    TO      MIR-CVG-SMKR-CD-T (WS-IDX)
013578     END-IF.
013578
018633*    IF WS-CVG-SEX-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-SEX-T (WS-IDX)
013578                              = MIR-CVG-SEX-CD-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-CVG-SEX-CD-T (WS-IDX)
013578     END-IF.
013578

013578     MOVE MIR-CVG-UWG-AMT-T (WS-IDX)      TO L0280-INPUT-DATA.
013578     SET L0280-SIGN-PERMITTED             TO TRUE.
013578     MOVE LENGTH OF MIR-CVG-UWG-AMT-T (WS-IDX)
013578                                          TO L0280-INPUT-SIZE.
013578     MOVE LENGTH OF MIR-CVG-UWG-AMT-T (WS-IDX)
013578                                          TO L0280-LENGTH.
013578     MOVE '2'                             TO L0280-PRECISION.
013578     PERFORM 0280-1000-NUMERIC-EDIT
013578        THRU 0280-1000-NUMERIC-EDIT-X.
013578     IF L0280-OK
013578        MOVE L0280-OUTPUT                 TO WS-PIC-LEN16
020874*       COMPUTE L0290-INPUT-NUMBER = WS-PIC-LEN16 / 100
020874        COMPUTE L0290-INPUT-V00 = WS-PIC-LEN16 / 100
013578        MOVE '0'                          TO L0290-PRECISION
013578        MOVE LENGTH OF MIR-CVG-UWG-AMT-T (WS-IDX)
013578                                       TO L0290-MAX-OUT-LEN
020874*       PERFORM  0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874        PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU 0290-2000-FORMAT-FOR-MIR-X
013578        MOVE L0290-OUTPUT-DATA TO MIR-CVG-UWG-AMT-T (WS-IDX)
013578     END-IF.

018633*    IF WS-CVG-UWG-AMT-ARRAY (WS-IDX)
018633     IF LCOMM-CVG-UWG-AMT-T (WS-IDX)
013578                            =  MIR-CVG-UWG-AMT-T (WS-IDX)
013578        MOVE SPACES    TO      MIR-CVG-UWG-AMT-T (WS-IDX)
013578     END-IF.
013578
013578
018633*    IF LCOMM-UWG-AMT-REASN-ARRAY (WS-IDX)
018633     IF LCOMM-UWG-AMT-REASN-T (WS-IDX)
013578                              = MIR-UWG-AMT-REASN-CD-T (WS-IDX)
013578        MOVE SPACES         TO  MIR-UWG-AMT-REASN-CD-T (WS-IDX)
013578     END-IF.
013578
013578

013578 8300-CHECK-UPDATE-FIELDS-X.
013578     EXIT.

      *
      *----------------------
       8400-PROCESS-COVERAGES.
      *----------------------
      *
      *   PROCESS COVERAGES: EDIT AND ANALYSE EACH COVERAGE.
      *   DO NOT PROCESS BLANK LINES.
      *
           IF MIR-CVG-NUM-T (WS-IDX) = SPACES
               GO TO 8400-PROCESS-COVERAGES-X
557660     END-IF.
      *
      *   STORE THE CURRENT POLICY BEING PROCESSED.
      *
           MOVE MIR-POL-ID-BASE-T (WS-IDX) TO WS-MIR-POLICY-NUM.
           MOVE MIR-POL-ID-SFX-T (WS-IDX) TO WS-MIR-POLICY-SUF.
      *
      *   DETERMINE IF WE ARE PROCESSING THE SAME POLICY
      *
014221*    SET  WS-READ-POL-FOR-UPDATE-NO  TO TRUE

           IF WS-MIR-POLICY NOT = WS-PREV-POLICY
014221*        SET  WS-READ-POL-FOR-UPDATE TO TRUE
               PERFORM  8910-NEW-POLICY
                   THRU 8910-NEW-POLICY-X
014221*        IF NOT WGLOB-GOOD-RETURN
014221*            GO TO 8400-PROCESS-COVERAGES-X
014221*        END-IF
           END-IF.

014221     IF  WGLOB-RETURN-ERROR
014221         GO TO 8400-PROCESS-COVERAGES-X
014221     END-IF.
014221
           MOVE MIR-CVG-NUM-T (WS-IDX)                        TO WS-CVG.
      *
      *   RESET MESSAGE INQUIRY VARIABLES FOR CURRENT POLICY/CVG.
      *
           PERFORM  9350-SETUP-MSIN-REFERENCE-2
               THRU 9350-SETUP-MSIN-REFERENCE-2-X.

      *
      *   MOVE THE EDITED COVERAGE RECORD TO RECORD LAYOUT.
      *
           MOVE MIR-CVG-NUM-T    (WS-IDX)
                                      TO RCVG-CVG-NUM.
           MOVE WCVGS-CVG-INFO (WS-CVG)
                                      TO RCVG-CVG-INFO.
      *
      *   EDIT THE COVERAGE DECISION
      *
           PERFORM  8430-COVERAGE-DECISION
               THRU 8430-COVERAGE-DECISION-X.
      *
      *   RESTORE THE RECORD TO WCVGS IN CASE IT CHANGED.
      *
           MOVE MIR-CVG-NUM-T(WS-IDX) TO WCVGS-CVG-SEQ-NUM(WS-CVG)
           MOVE RCVG-CVG-INFO         TO WCVGS-CVG-INFO   (WS-CVG).
      *
      *   LINK TO THE COVERAGE EDIT MODULE
      *
           PERFORM  8420-COVERAGE-EDITS
               THRU 8420-COVERAGE-EDITS-X.
      *
      *   UPDATE MATURITY/EXPIRY DATE ON CVG WHEN DECLINING OR
      *   REVERSING A DECLINE DECISION.
      *
           PERFORM  8425-DECLINED-MAT-XPRY-DT
               THRU 8425-DECLINED-MAT-XPRY-DT-X.

      *
      *   REWRITE THE COVERAGE
      *

           MOVE WS-CVG                TO I.
           PERFORM  CVGR-2000-REWRITE-COVERAGE
               THRU CVGR-2000-REWRITE-COVERAGE-X.

           IF  RPOL-POL-SUSPENDED
               PERFORM  5440-1000-BUILD-PARM-INFO
                  THRU  5440-1000-BUILD-PARM-INFO-X
               MOVE WS-CVG            TO L5440-CVG-NUM
               SET  L5440-PEND-CVG-ALLOW TO TRUE
               PERFORM 5440-1000-BASE-CVG-DEFAULTS
                  THRU 5440-1000-BASE-CVG-DEFAULTS-X
           END-IF.
      *
      *** IF DATA WAS ENTERED ON AN APPROVED COVERAGE, A MESSAGE
      *** INDICATING AN AMMENDMENT MAY BE NECESSARY IS GENERATED.
      *
           IF  WS-AMMENDMENT-REQD
      *MSG:    POLICY/COVERAGE (@2 @1) UPDATED - AMENDMENT MAY BE
      *        REQUIRED
               MOVE 'NS12500017'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-CVG-NUM-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
               MOVE MIR-POL-ID-BASE-T (WS-IDX)
                                      TO WS-MIR-POLICY-NUM
               MOVE MIR-POL-ID-SFX-T (WS-IDX)
                                      TO WS-MIR-POLICY-SUF
               MOVE WS-MIR-POLICY     TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

016440     IF MIR-CVG-UWGDECN-CD-T (WS-IDX) NOT = SPACES
016440        PERFORM 8560-REJECT-DECLINED-CVG
016440           THRU 8560-REJECT-DECLINED-CVG-X
016440     END-IF.

      *
      *   RESTORE THE COVERAGE DECISION/TYPE IF A VALUE WAS NOT KEYED.
      *
           IF  NOT SW-EDIT-ERROR
           OR  MIR-CVG-UWGDECN-CD-T(WS-IDX) = SPACES
               MOVE RCVG-CVG-UWGDECN-CD
                                      TO MIR-CVG-UWGDECN-CD-T (WS-IDX)
557660     END-IF.
      *
           IF  NOT SW-EDIT-ERROR
           OR  MIR-CVG-UWGDECN-SUB-CD-T(WS-IDX) = SPACES
               MOVE RCVG-CVG-UWGDECN-SUB-CD
                                    TO MIR-CVG-UWGDECN-SUB-CD-T (WS-IDX)
557660     END-IF.
      *
      *   RESTORE THE POLICY FIELDS THAT ARE DISPLAYED.
      *
           MOVE RPOL-POL-OPTL-CD      TO MIR-POL-OPTL-CD-T (WS-IDX).
           MOVE RPOL-LINK-POL-ISS-IND
                                     TO MIR-LINK-POL-ISS-IND-T (WS-IDX).
      *
      *   MOVE OTHER REQUIRED COVERAGE FIELDS TO THE SCREEN.
      *
      *
008455*    MOVE RCVG-CVG-PREV-FACE-AMT         TO WS-PIC-LEN9Z.
008455*    MOVE WS-PIC-LEN9Z      TO MIR-CVG-PREV-FACE-AMT-T (WS-IDX).
020874*    COMPUTE L0290-INPUT-NUMBER = RCVG-CVG-PREV-FACE-AMT.
020874     MOVE RCVG-CVG-PREV-FACE-AMT  TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-PREV-FACE-AMT-T (WS-IDX)
008455                                TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS      TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA   TO MIR-CVG-PREV-FACE-AMT-T (WS-IDX).

           MOVE RCVG-CVG-SUPP-BNFT-CD
                                     TO MIR-CVG-SUPP-BNFT-CD-T (WS-IDX).
557767*    MOVE RCVG-CVG-LIVES-INSRD-CD-N
557767*                     TO MIR-CVG-LIVES-INSRD-CD-T (WS-IDX).
025388*    MOVE RCVG-CVG-LIVES-INSRD-CD
025388*                            TO MIR-CVG-LIVES-INSRD-CD-T (WS-IDX).
025388     MOVE RCVG-LIVES-INSRD-QTY
025388                           TO MIR-LIVES-INSRD-QTY-T (WS-IDX).
           MOVE RCVG-CVG-CSTAT-CD     TO MIR-CVG-CSTAT-CD-T (WS-IDX).
           MOVE RCVG-CVG-SPND-CSTAT-CD
                                    TO MIR-CVG-SPND-CSTAT-CD-T (WS-IDX).
020874*    MOVE RCVG-CVG-WP-MULT-FCT  TO WS-PIC-LEN4.
020874*    MOVE WS-PIC-LEN4           TO MIR-CVG-WP-MULT-FCT-T (WS-IDX).
020874     MOVE RCVG-CVG-WP-MULT-FCT  TO L0290-INPUT-V02.
020874     MOVE 2                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CVG-WP-MULT-FCT-T (WS-IDX)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA    TO MIR-CVG-WP-MULT-FCT-T (WS-IDX).

      *
      *   SUB-TABLES/IMBEDDED BENEFITS HAVE BEEN CHANGE ON CONNECTED
      *   COVERAGE - RECORD MUST BE UPDATED
      *
015951     SET WS-HEALTH-POL-CVG-NOT-FOUND TO TRUE.
015951     IF  RPOL-POL-INS-TYP-HEALTH
015951         SET WS-HEALTH-POL-OR-CVG-FOUND TO TRUE
015951     ELSE
015951         PERFORM 8405-CHECK-FOR-DI-CVG
015951            THRU 8405-CHECK-FOR-DI-CVG-X
015951            VARYING I FROM 1 BY 1
015951              UNTIL I > RPOL-POL-CVG-REC-CTR-N
015951                 OR WS-HEALTH-POL-OR-CVG-FOUND
015951     END-IF.

           IF  L0570-CHK-GIR
015951*    AND RPOL-POL-INS-TYP-HEALTH
015951     AND WS-HEALTH-POL-OR-CVG-FOUND
               PERFORM 1255-1000-BUILD-PARM-INFO
                  THRU 1255-1000-BUILD-PARM-INFO-X
               MOVE WS-CVG            TO L1255-CVG-NUM
               PERFORM 1255-1000-GIR-CHK
                  THRU 1255-1000-GIR-CHK-X
               PERFORM 8410-CHECK-GIR
                   THRU 8410-CHECK-GIR-X
                   VARYING WS-CVG-SUB FROM 1 BY 1
                   UNTIL WS-CVG-SUB > RPOL-POL-CVG-REC-CTR-N
557660     END-IF.

           IF  MIR-CVG-UWGDECN-CD-T (WS-IDX) = 'NE'
               MOVE WS-IDX            TO WS-LINE
557660     END-IF.

           INITIALIZE WS-MIR-DECISION.

       8400-PROCESS-COVERAGES-X.
           EXIT.
      *
015951*----------------------
015951 8405-CHECK-FOR-DI-CVG.
015951*----------------------
015951     IF  WCVGS-CVG-INS-TYP-HEALTH (I)
015951         AND WCVGS-CVG-STAT-IN-FORCE (I)
015951         SET WS-HEALTH-POL-OR-CVG-FOUND TO TRUE
015951     END-IF.
015951
015951 8405-CHECK-FOR-DI-CVG-X.
015951     EXIT.

      ****************
       8410-CHECK-GIR.
      ****************

      *** CHECK IF SCREEN NEEDS TO BE REFRESHED

           IF WS-CVG-SUB > WS-CVG
               GO TO 8410-CHECK-GIR-X
557660     END-IF.

           SUBTRACT 1 FROM WS-IDX GIVING I.
           SET WS-CVG-NOT-FOUND TO TRUE.
           PERFORM
               VARYING I FROM I BY -1
               UNTIL I < +1
                  OR WS-CVG-FOUND

                  IF (MIR-CVG-NUM-T (I) = WS-CVG-SUB        AND
                      MIR-POL-ID-BASE-T (I) = RCVG-POL-ID-BASE  AND
                      MIR-POL-ID-SFX-T (I) = RCVG-POL-ID-SFX)
                      SET WS-CVG-FOUND TO TRUE
                  END-IF

           END-PERFORM.

           IF I < +1
               GO TO 8410-CHECK-GIR-X
557660     END-IF.

           MOVE WCVGS-CVG-STBL-1-CD (WS-CVG-SUB)
                                      TO MIR-CVG-STBL-1-CD-T (I).
           MOVE WCVGS-CVG-STBL-2-CD (WS-CVG-SUB)
                                      TO MIR-CVG-STBL-2-CD-T (I).
           MOVE WCVGS-CVG-STBL-3-CD (WS-CVG-SUB)
                                      TO MIR-CVG-STBL-3-CD-T (I).
           MOVE WCVGS-CVG-STBL-4-CD (WS-CVG-SUB)
                                      TO MIR-CVG-STBL-4-CD-T (I).

           MOVE WCVGS-CVG-CSTAT-CD (WS-CVG-SUB)
                                      TO MIR-CVG-CSTAT-CD-T (I).
           MOVE WCVGS-CVG-SPND-CSTAT-CD (WS-CVG-SUB)
                                    TO MIR-CVG-SPND-CSTAT-CD-T (WS-IDX).

           MOVE WCVGS-CVG-COLA-SELCT-CD (WS-CVG)
                                      TO MIR-CVG-COLA-SELCT-CD-T (I).
           MOVE WCVGS-REDC-EP-SELCT-IND (WS-CVG)
                                      TO MIR-REDC-EP-SELCT-IND-T (I).
           MOVE WCVGS-OWN-OCCP-SELCT-IND (WS-CVG)
                                      TO MIR-OWN-OCCP-SELCT-IND-T (I).
           MOVE WCVGS-CVG-LTA-SELCT-IND (WS-CVG)
                                      TO MIR-CVG-LTA-SELCT-IND-T (I).
           MOVE WCVGS-CVG-LTB-SELCT-IND (WS-CVG)
                                      TO MIR-CVG-LTB-SELCT-IND-T (I).
           MOVE WCVGS-PDISAB-SELCT-IND (WS-CVG)
                                      TO MIR-PDISAB-SELCT-IND-T (I).

       8410-CHECK-GIR-X.
           EXIT.
      *
      *
      *--------------------
       8420-COVERAGE-EDITS.
      *--------------------
      *
      *   BUILD THE PARAMETERS AND LINK TO THE COVERAGE EDIT MODULE
      *
           PERFORM 0570-1000-BUILD-PARM-INFO
              THRU 0570-1000-BUILD-PARM-INFO-X.
           MOVE SPACES                TO L0570-CVG-EDIT-INFO.
015918*    SET L0570-BYPASS-GDLN           TO TRUE.
           SET L0570-PRCES-POLICY-NOT-REQD TO TRUE.

           MOVE MIR-PLAN-ID-T (WS-IDX)           TO  L0570-PLAN-ID.
           MOVE MIR-CVG-FACE-AMT-T (WS-IDX)
                                      TO  L0570-FACE-AMT.
           MOVE MIR-CVG-AD-FACE-AMT-T (WS-IDX)
                                      TO  L0570-AD-FACE-AMT.
           MOVE MIR-CVG-AD-MULT-FCT-T (WS-IDX)
                                      TO  L0570-AD-MULT-FCT.
           MOVE MIR-CVG-WP-MULT-FCT-T (WS-IDX)
                                      TO  L0570-WP-MULT-FCT.
           MOVE MIR-CVG-STBL-1-CD-T (WS-IDX)
                                      TO  L0570-STBL-1-CD.
           MOVE MIR-CVG-STBL-2-CD-T (WS-IDX)
                                      TO  L0570-STBL-2-CD.
           MOVE MIR-CVG-STBL-3-CD-T (WS-IDX)
                                      TO  L0570-STBL-3-CD.
           MOVE MIR-CVG-STBL-4-CD-T (WS-IDX)
                                      TO  L0570-STBL-4-CD.
           MOVE MIR-CVG-ENHC-TYP-CD-T   (WS-IDX)
                                      TO  L0570-CVG-ENHC-TYP-CD.
           MOVE MIR-CVG-ME-FCT-T (WS-IDX)
                                      TO  L0570-ME-FCT.
557671     MOVE MIR-CVG-ME-RAT-CD-T (WS-IDX)
                                      TO  L0570-ME-RAT-CD.
           MOVE MIR-CVG-ME-REASN-CD-T (WS-IDX)
                                      TO  L0570-ME-REASN-CD.
           MOVE MIR-CVG-COLA-SELCT-CD-T  (WS-IDX)
                                      TO  L0570-CVG-COLA-TYP-CD.
           MOVE MIR-REDC-EP-SELCT-IND-T  (WS-IDX)
                                      TO  L0570-REDC-EP-SELCT-IND.
           MOVE MIR-OWN-OCCP-SELCT-IND-T   (WS-IDX)
                                      TO  L0570-OWN-OCCP-SELCT-IND.
           MOVE MIR-CVG-LTA-SELCT-IND-T   (WS-IDX)
                                      TO  L0570-CVG-LTA-SELCT-IND.
           MOVE MIR-CVG-LTB-SELCT-IND-T   (WS-IDX)
                                      TO  L0570-CVG-LTB-SELCT-IND.
           MOVE MIR-PDISAB-SELCT-IND-T  (WS-IDX)
                                      TO  L0570-PDISAB-SELCT-IND.
           MOVE MIR-CVG-UWG-EXCL-1-CD-T   (WS-IDX)
                                      TO  L0570-CVG-EXCL-CD (1).
           MOVE MIR-CVG-UWG-EXCL-2-CD-T   (WS-IDX)
                                      TO  L0570-CVG-EXCL-CD (2).
           MOVE MIR-CVG-UWG-EXCL-3-CD-T   (WS-IDX)
                                      TO  L0570-CVG-EXCL-CD (3).
           MOVE MIR-CVG-ME-DUR-T (WS-IDX)
                                      TO  L0570-ME-DUR.
           MOVE MIR-CVG-FE-UPREM-AMT-T (WS-IDX)
                                      TO  L0570-FE-UPREM-AMT.
           MOVE MIR-CVG-FE-REASN-CD-T (WS-IDX)
                                      TO  L0570-FE-REASN-CD.
           MOVE MIR-CVG-FE-DUR-T (WS-IDX)
                                      TO  L0570-FE-DUR.
           MOVE MIR-CVG-RT-AGE-T (WS-IDX)
                                      TO  L0570-RT-AGE.
           MOVE MIR-AGE-RAT-REASN-CD-T (WS-IDX)
                                      TO  L0570-AGE-RAT-REASN-CD.
           MOVE MIR-CVG-SMKR-CD-T (WS-IDX)
                                      TO  L0570-SMKR-CD.
           MOVE MIR-CVG-SEX-CD-T (WS-IDX)
                                      TO  L0570-SEX-CD.
           MOVE MIR-CVG-UWG-AMT-T (WS-IDX)
                                      TO  L0570-UWG-AMT.
           MOVE MIR-UWG-AMT-REASN-CD-T (WS-IDX)
                                      TO  L0570-UWG-AMT-REASN-CD.

           MOVE 'N'                   TO WS-AMMENDMENT-REQD-SW.
           IF  L0570-CVG-EDIT-INFO        NOT = SPACES
               SET  WS-AMMENDMENT-REQD  TO TRUE
           END-IF.

           MOVE MIR-CVG-NUM-T (WS-IDX)                TO  L0570-CVG-NUM.

           MOVE SPACES                TO L0570-HOLD-CLI-INFO.
           PERFORM 1251-1000-BUILD-PARM-INFO
              THRU 1251-1000-BUILD-PARM-INFO-X.
           MOVE WS-MIR-POLICY         TO L1251-POL-ID.
           MOVE L0570-CVG-NUM         TO L1251-CVG-NUM.
           PERFORM 1251-1000-CLI-RETRIEVAL
              THRU 1251-1000-CLI-RETRIEVAL-X.
           IF L1251-RETRN-OK
               MOVE L1251-CLI-INFO    TO L0570-HOLD-CLI-INFO
           END-IF.

           MOVE  WS-MIR-POLICY        TO L2450-POL-ID.
           MOVE  L0570-CVG-NUM        TO L2450-CVG.
           MOVE  RPOL-POL-CVG-REC-CTR-N
                                      TO L2450-POL-CVG-REC-CTR.
           MOVE  L0570-CVG-NUM        TO WS-SUB.

           PERFORM  2450-2000-READ-CVG-AGENTS
               THRU 2450-2000-READ-CVG-AGENTS-X.
           IF L2450-RETRN-OK
              MOVE L2450-AGT-ID (WS-SUB, 1)
                                      TO L0570-HOLD-AGT-ID (1)
              MOVE L2450-AGT-ID (WS-SUB, 2)
                                      TO L0570-HOLD-AGT-ID (2)
              MOVE L2450-AGT-ID (WS-SUB, 3)
                                      TO L0570-HOLD-AGT-ID (3)
           END-IF.

      *
      *  CALL CSLF0570 TO PERFORM EDITS, CROSS-EDITS, MAINTENANCE
      *  AND COVERAGE ANALYZE
      *
           PERFORM  0570-1000-MAINTAIN-COVERAGE
               THRU 0570-1000-MAINTAIN-COVERAGE-X.
      *
      *   CHECK THE RESULTS OF THE EDIT ON EACH FIELD. A FIELD IN ERROR
      *   IS INDICATED BY THE PRESENCE OF HIGH VALUES IN THE PARAMETER
      *   FIELD. THE SCREEN FIELDS ARE RESET TO THE WCVGS ARRAY
      *   VALUES IF NO ERROR HAS OCCURRED.
      *

           SET SW-NO-CRSR-SET TO TRUE.

      *
      *   THE PLAN AND RATE SCALE ARE TREATED AS ONE FIELD. IF  AN
      *   ERROR OCCURRED, IT SHOULD BE RESTORED IN THE MIR USING
      *   THE VALUE IN THE WCVGS ARRAY.
      *
           IF L0570-PLAN-ID = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
               IF MIR-PLAN-ID-T (WS-IDX)     = SPACES
                   MOVE WCVGS-PLAN-ID (L0570-CVG-NUM)
                                      TO MIR-PLAN-ID-T (WS-IDX)
034802*        ELSE
034802*            NEXT SENTENCE
557660         END-IF
           ELSE
               MOVE WCVGS-PLAN-ID (L0570-CVG-NUM)
                                      TO MIR-PLAN-ID-T (WS-IDX)
557660     END-IF.


           IF L0570-FACE-AMT    = HIGH-VALUES
               SET  SW-CRSR-SET           TO TRUE
           ELSE
008455*        MOVE WCVGS-CVG-FACE-AMT (L0570-CVG-NUM)
008455*                                 TO WS-PIC-LEN12
008455*        MOVE WS-PIC-LEN12        TO MIR-CVG-FACE-AMT-T (WS-IDX)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                WCVGS-CVG-FACE-AMT (L0570-CVG-NUM) * 100
020874         MOVE WCVGS-CVG-FACE-AMT (L0570-CVG-NUM)
020874                                TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-FACE-AMT-T (WS-IDX)
008455                                TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-FACE-AMT-T (WS-IDX)
557660     END-IF.

           IF L0570-AD-FACE-AMT     = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
008455*        MOVE WCVGS-CVG-AD-FACE-AMT (L0570-CVG-NUM)
008455*                                   TO WS-PIC-LEN12
008455*        MOVE WS-PIC-LEN12   TO MIR-CVG-AD-FACE-AMT-T (WS-IDX)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                WCVGS-CVG-AD-FACE-AMT (L0570-CVG-NUM) * 100
020874         MOVE WCVGS-CVG-AD-FACE-AMT (L0570-CVG-NUM)
020874                                TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-AD-FACE-AMT-T (WS-IDX)
008455                                TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-AD-FACE-AMT-T (WS-IDX)
557660     END-IF.

           IF L0570-AD-MULT-FCT    = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
020874*        MOVE WCVGS-CVG-AD-MULT-FCT (L0570-CVG-NUM)
020874*                               TO WS-PIC-LEN4
020874*        MOVE WS-PIC-LEN4       TO MIR-CVG-AD-MULT-FCT-T (WS-IDX)
020874         MOVE WCVGS-CVG-AD-MULT-FCT (L0570-CVG-NUM)
020874                                TO L0290-INPUT-V02
020874         MOVE 2                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CVG-AD-MULT-FCT-T (WS-IDX)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CVG-AD-MULT-FCT-T (WS-IDX)
557660     END-IF.

           IF L0570-WP-MULT-FCT = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
020874*        MOVE WCVGS-CVG-WP-MULT-FCT (L0570-CVG-NUM)
020874*                               TO WS-PIC-LEN4
020874*        MOVE WS-PIC-LEN4       TO MIR-CVG-WP-MULT-FCT-T (WS-IDX)
020874         MOVE WCVGS-CVG-WP-MULT-FCT (L0570-CVG-NUM)
020874                                TO L0290-INPUT-V02
020874         MOVE 2                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CVG-WP-MULT-FCT-T (WS-IDX)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CVG-WP-MULT-FCT-T (WS-IDX)
557660     END-IF.

           IF L0570-STBL-1-CD  = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-STBL-1-CD (L0570-CVG-NUM)
                                      TO MIR-CVG-STBL-1-CD-T (WS-IDX)
557660     END-IF.

           IF L0570-STBL-2-CD  = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-STBL-2-CD (L0570-CVG-NUM)
                                      TO MIR-CVG-STBL-2-CD-T (WS-IDX)
557660     END-IF.

           IF L0570-STBL-3-CD  = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-STBL-3-CD (L0570-CVG-NUM)
                                      TO MIR-CVG-STBL-3-CD-T (WS-IDX)
557660     END-IF.

           IF L0570-STBL-4-CD  = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-STBL-4-CD (L0570-CVG-NUM)
                                      TO MIR-CVG-STBL-4-CD-T (WS-IDX)
557660     END-IF.

           IF L0570-CVG-ENHC-TYP-CD = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-ENHC-TYP-CD (L0570-CVG-NUM)
                                      TO MIR-CVG-ENHC-TYP-CD-T (WS-IDX)
557660     END-IF.

           IF L0570-CVG-COLA-TYP-CD = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-COLA-SELCT-CD (L0570-CVG-NUM)
                                     TO MIR-CVG-COLA-SELCT-CD-T (WS-IDX)
557660     END-IF.

           IF L0570-REDC-EP-SELCT-IND = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-REDC-EP-SELCT-IND (L0570-CVG-NUM)
                                     TO MIR-REDC-EP-SELCT-IND-T (WS-IDX)
557660     END-IF.

           IF L0570-OWN-OCCP-SELCT-IND = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-OWN-OCCP-SELCT-IND (L0570-CVG-NUM)
                                    TO MIR-OWN-OCCP-SELCT-IND-T (WS-IDX)
557660     END-IF.

           IF L0570-CVG-LTA-SELCT-IND = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-LTA-SELCT-IND (L0570-CVG-NUM)
                                     TO MIR-CVG-LTA-SELCT-IND-T (WS-IDX)
557660     END-IF.

           IF L0570-CVG-LTB-SELCT-IND = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-LTB-SELCT-IND (L0570-CVG-NUM)
                                     TO MIR-CVG-LTB-SELCT-IND-T (WS-IDX)
557660     END-IF.

           IF L0570-PDISAB-SELCT-IND = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-PDISAB-SELCT-IND (L0570-CVG-NUM)
                                      TO MIR-PDISAB-SELCT-IND-T (WS-IDX)
557660     END-IF.

           IF L0570-CVG-EXCL-CD (1) = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-UWG-EXCL-1-CD (L0570-CVG-NUM)
                                     TO MIR-CVG-UWG-EXCL-1-CD-T (WS-IDX)
557660     END-IF.

           IF L0570-CVG-EXCL-CD (2) = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-UWG-EXCL-2-CD (L0570-CVG-NUM)
                                     TO MIR-CVG-UWG-EXCL-2-CD-T (WS-IDX)
557660     END-IF.

           IF L0570-CVG-EXCL-CD (3) = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-UWG-EXCL-3-CD (L0570-CVG-NUM)
                                     TO MIR-CVG-UWG-EXCL-3-CD-T (WS-IDX)
557660     END-IF.

           IF L0570-ME-FCT          = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
020874*        MOVE WCVGS-CVG-ME-FCT (L0570-CVG-NUM)
020874*                               TO WS-PIC-LEN4
020874*        MOVE WS-PIC-LEN4       TO MIR-CVG-ME-FCT-T (WS-IDX)
020874         MOVE WCVGS-CVG-ME-FCT (L0570-CVG-NUM) TO L0290-INPUT-V02
020874         MOVE 2                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CVG-ME-FCT-T (WS-IDX)
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CVG-ME-FCT-T (WS-IDX)
557660     END-IF.

557671     IF L0570-ME-RAT-CD       = HIGH-VALUES
557671         SET SW-CRSR-SET            TO TRUE
557671     ELSE
557671         MOVE WCVGS-CVG-ME-RAT-CD (L0570-CVG-NUM)
557671                                TO MIR-CVG-ME-RAT-CD-T (WS-IDX)
557671     END-IF.

           IF L0570-ME-REASN-CD     = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-ME-REASN-CD (L0570-CVG-NUM)
                                      TO MIR-CVG-ME-REASN-CD-T (WS-IDX)
557660     END-IF.

           IF L0570-ME-DUR         = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-ME-DUR (L0570-CVG-NUM)
                                      TO WS-PIC-LEN3
               MOVE WS-PIC-LEN3       TO MIR-CVG-ME-DUR-T (WS-IDX)
557660     END-IF.

           IF L0570-FE-UPREM-AMT    = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
008455*        MOVE WCVGS-CVG-FE-UPREM-AMT (L0570-CVG-NUM)
008455*                                     TO WS-PIC-LEN6
008455*        MOVE WS-PIC-LEN6    TO MIR-CVG-FE-UPREM-AMT-T (WS-IDX)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                WCVGS-CVG-FE-UPREM-AMT (L0570-CVG-NUM) * 100
020874         MOVE WCVGS-CVG-FE-UPREM-AMT (L0570-CVG-NUM)
020874                                TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-FE-UPREM-AMT-T (WS-IDX)
008455                                TO L0290-MAX-OUT-LEN
008455         SET  L0290-SIGN-DISPLAY      TO TRUE
008455         SET  L0290-SIGN-POS-DISPLAY  TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-FE-UPREM-AMT-T (WS-IDX)
557660     END-IF.

           IF L0570-FE-REASN-CD  = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-FE-REASN-CD (L0570-CVG-NUM)
                                      TO MIR-CVG-FE-REASN-CD-T (WS-IDX)
557660     END-IF.

           IF L0570-FE-DUR         = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-FE-DUR (L0570-CVG-NUM)
                                      TO WS-PIC-LEN3
               MOVE WS-PIC-LEN3       TO MIR-CVG-FE-DUR-T (WS-IDX)
557660     END-IF.

           IF L0570-RT-AGE   = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-RT-AGE (L0570-CVG-NUM)
                                      TO MIR-CVG-RT-AGE-T (WS-IDX)
557660     END-IF.

           IF L0570-AGE-RAT-REASN-CD = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-AGE-RAT-REASN-CD (L0570-CVG-NUM)
                                      TO MIR-AGE-RAT-REASN-CD-T (WS-IDX)
557660     END-IF.

           IF L0570-SMKR-CD          = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-SMKR-CD (L0570-CVG-NUM)
                                      TO MIR-CVG-SMKR-CD-T (WS-IDX)
557660     END-IF.

           IF L0570-SEX-CD          = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-CVG-SEX-CD (L0570-CVG-NUM)
                                      TO MIR-CVG-SEX-CD-T (WS-IDX)
557660     END-IF.

           IF L0570-UWG-AMT      = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
008455*        MOVE WCVGS-CVG-UWG-AMT (L0570-CVG-NUM)
008455*                                   TO WS-PIC-LEN9
008455*        MOVE WS-PIC-LEN9           TO MIR-CVG-UWG-AMT-T (WS-IDX)
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                WCVGS-CVG-UWG-AMT (L0570-CVG-NUM)
020874         MOVE WCVGS-CVG-UWG-AMT (L0570-CVG-NUM)
020874                                TO L0290-INPUT-V02
008455         MOVE 0                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVG-UWG-AMT-T (WS-IDX)
008455                                TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVG-UWG-AMT-T (WS-IDX)
557660     END-IF.

           IF L0570-UWG-AMT-REASN-CD = HIGH-VALUES
               SET SW-CRSR-SET            TO TRUE
           ELSE
               MOVE WCVGS-UWG-AMT-REASN-CD (L0570-CVG-NUM)
                                      TO MIR-UWG-AMT-REASN-CD-T (WS-IDX)
557660     END-IF.

           IF L0570-EDIT-ERROR
           OR SW-CRSR-SET
              SET SW-COVERAGE-ERRORS TO TRUE
           END-IF.
      *
      *  IN ORDER TO IDENTIFY WHICH POLICY SHOULD NOT GO THROUGH
      *  ISSUE/SETTLE PROCESSING LATER ON IN THIS PROGRAM WE NEED
      *  TO STORE THE POLICY NUMBER FOR WHICH THE COVERAGE ERRORS
      *  HAVE OCCURED ON
      *
           IF L0570-EDIT-ERROR
           OR SW-CRSR-SET
               MOVE WS-MIR-POLICY     TO WS-SAVE-POLICY
               PERFORM  8936-READ-POLICY-ARRAY
                   THRU 8936-READ-POLICY-ARRAY-X
                   VARYING I FROM 1 BY 1
                   UNTIL I > 10
                   OR WS-POLICY-FOUND
               IF WS-POLICY-FOUND
                   MOVE 'N'           TO WS-POLICY-FOUND-SW
               ELSE
                   COMPUTE WS-POL-SUB = WS-POL-SUB + 1
                   MOVE WS-MIR-POLICY TO WS-POLICY-ARRAY (WS-POL-SUB)
                   SET  WS-POLICY-ERROR TO TRUE
               END-IF
           END-IF.


       8420-COVERAGE-EDITS-X.
           EXIT.
      *
       8425-DECLINED-MAT-XPRY-DT.
      *
      *   UPDATE MATURITY/EXPIRY DATE ON CVG WHEN DECLINING OR
      *   REVERSING A DECLINE DECISION.
      *
           EVALUATE TRUE ALSO TRUE ALSO TRUE

               WHEN WS-MIR-DECISION-1                = 'D'
               ALSO WCVGS-CVG-UWGDECN-CD(WS-CVG)     = 'DE'
               ALSO WS-PREV-UWGDECN-CD  (WS-CVG) NOT = 'DE'
                   IF WCVGS-CVG-ISS-EFF-DT        (WS-CVG) =
                      WCVGS-CVG-MAT-XPRY-DT       (WS-CVG)
                       CONTINUE
                   ELSE
                       MOVE WCVGS-CVG-MAT-XPRY-DT (WS-CVG)
                                      TO
                            WCVGS-PREV-MAT-XPRY-DT(WS-CVG)
                       MOVE WCVGS-CVG-ISS-EFF-DT  (WS-CVG)
                                      TO
                            WCVGS-CVG-MAT-XPRY-DT (WS-CVG)
                   END-IF

               WHEN WS-MIR-DECISION-1                = 'P'
               ALSO ANY
               ALSO WS-PREV-UWGDECN-CD  (WS-CVG)     = 'DE'
                   IF WCVGS-PREV-MAT-XPRY-DT(WS-CVG) > WWKDT-ZERO-DT
                       MOVE WCVGS-PREV-MAT-XPRY-DT(WS-CVG)
                                      TO
                            WCVGS-CVG-MAT-XPRY-DT (WS-CVG)
                       MOVE WWKDT-ZERO-DT
                                      TO
                            WCVGS-PREV-MAT-XPRY-DT(WS-CVG)
                   END-IF

               WHEN WS-MIR-DECISION-1                = 'A'
               ALSO ANY
               ALSO WS-PREV-UWGDECN-CD  (WS-CVG)     = 'DE'
                   IF WCVGS-PREV-MAT-XPRY-DT(WS-CVG) > WWKDT-ZERO-DT
                       MOVE WCVGS-PREV-MAT-XPRY-DT(WS-CVG)
                                      TO
                            WCVGS-CVG-MAT-XPRY-DT (WS-CVG)
                       MOVE WWKDT-ZERO-DT
                                      TO
                            WCVGS-PREV-MAT-XPRY-DT(WS-CVG)
                   END-IF
               WHEN OTHER
                   CONTINUE
           END-EVALUATE.
      *
       8425-DECLINED-MAT-XPRY-DT-X.
           EXIT.
      *
      *-----------------------
       8430-COVERAGE-DECISION.
      *-----------------------
      *
      *   BYPASS WHEN COVERAGE DECISION/REASON NOT ENTERED
      *
           IF  MIR-CVG-UWGDECN-CD-T (WS-IDX) = SPACES
           AND MIR-CVG-UWGDECN-SUB-CD-T (WS-IDX) = SPACES
               GO TO 8430-COVERAGE-DECISION-X
557660     END-IF.
      *
      *   EDIT THE COVERAGE DECISION
      *
           IF MIR-CVG-UWGDECN-CD-T (WS-IDX) NOT = SPACES
               PERFORM  8431-EDIT-CVG-DECISION
                   THRU 8431-EDIT-CVG-DECISION-X
557660     END-IF.
      *
      *   EDIT THE DECISON REASON
      *
           IF MIR-CVG-UWGDECN-SUB-CD-T (WS-IDX) NOT = SPACES
               PERFORM  8432-EDIT-CVG-REASON
                   THRU 8432-EDIT-CVG-REASON-X
557660     END-IF.

       8430-COVERAGE-DECISION-X.
           EXIT.
      *
      *-----------------------
       8431-EDIT-CVG-DECISION.
      *-----------------------
      *
      *   CHECK UNDERWRITERS LIMIT
      *   (DEPENDING OF THE SEVERITY OF THE MESSAGE, THE DECISION WILL
      *    EITHER BE ALLOWED OR NOT ALLOWED)
      *
           IF NOT SW-WITHIN-UW-LIMIT
               MOVE MIR-CVG-NUM-T (WS-IDX)
                                      TO WGLOB-MSG-PARM (1)
      *MSG:    AMT ABOVE UW LIMIT. CVG DECISION NOT ACCEPTED
               MOVE 'NS12500004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   GO TO 8431-EDIT-CVG-DECISION-X
557660         END-IF
557660     END-IF.
      *
      *   REDEFINE DECISION INTO TWO 1 BYTE FIELDS
      *
           MOVE MIR-CVG-UWGDECN-CD-T (WS-IDX)
                                      TO WS-MIR-DECISION.

           MOVE RCVG-CVG-UWGDECN-CD   TO WS-DECISION.
      *
      *   KEEP TRACK OF ANY COVERAGE DECISION EDIT ERRORS
      *
           MOVE 'N'                   TO WS-EDIT-ERROR.
      *
      *   CHECK TO SEE IF ANY CLIENTS ON THIS COVERAGE ARE PENDING.

           IF  WS-MIR-DECISION-1 = 'A'
              PERFORM 1251-1000-BUILD-PARM-INFO
                 THRU 1251-1000-BUILD-PARM-INFO-X
               MOVE  RCVG-POL-ID      TO L1251-POL-ID
               MOVE MIR-CVG-NUM-T(WS-IDX)
                                      TO L1251-CVG-NUM
               PERFORM  1251-2000-CLI-PEND-CHECK
                  THRU  1251-2000-CLI-PEND-CHECK-X
               IF L1251-CLI-PENDING
                   GO TO 8431-EDIT-CVG-DECISION-X
               END-IF
           END-IF.
      *
      *   A BLANK COVERAGE DECISION CANNOT BE UPDATED.
      *
           IF RCVG-CVG-UWGDECN-CD = SPACE
      *MSG:    BLANK COVERAGE DECISION CANNOT BE UPDATED
               MOVE 'NS12500015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8431-EDIT-CVG-DECISION-X
           END-IF.
      *
      *   COVERAGE DECISION MUST BE ACCEPT DECLINE OR PENDING
      *
           IF  WS-MIR-DECISION-1 NOT = 'A'
           AND WS-MIR-DECISION-1 NOT = 'D'
           AND WS-MIR-DECISION-1 NOT = 'P'
      *MSG:    COVERAGE DECISION MUST BE A,D OR P
               MOVE 'NS12500005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET SW-EDIT-ERROR TO TRUE
           END-IF.
      *
      *   THE BASE COVERAGE CANNOT BE DECLINED WHEN THE PRIMARY INSURED
      *   HAS BEEN APPROVED
      *
           IF WS-MIR-DECISION-1 = 'D'
               IF MIR-CVG-NUM-T(WS-IDX)    = '01'
557767*        AND RCVG-CVG-LIVES-INSRD-CD-N = 1
025388*        AND RCVG-CVG-LIVES-INSRD-CD   = 1
025388         AND RCVG-LIVES-INSRD-QTY  = 1
                   IF L2437-CLI-UWGDECN-APROV-ELUWG
      *MSG:  CANNOT DECLINE BASE COVERAGE - CLIENT HAS BEEN APPROVED
                       MOVE 'NS12500006'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                       SET SW-EDIT-ERROR TO TRUE
557660             END-IF
557660         END-IF
557660     END-IF.
      *
      *   THE BASE COVERAGE CANNOT BE ACCEPTED WHEN THE PRIMARY
      *   INSURED HAS BEEN DECLINED
      *
016537*    IF WS-MIR-DECISION-1 = 'A'
016537*        IF  MIR-CVG-NUM-T(WS-IDX)       = '01'
557767*        AND RCVG-CVG-LIVES-INSRD-CD-N = 1
016537*        AND RCVG-CVG-LIVES-INSRD-CD = 1
016537*            IF L2437-CLI-UWGDECN-DECLINED
016537*  MSG (F) INVALID COVERAGE DECISION WHEN CLIENT DECISION IS 'DE'
016537*                MOVE 'NS12500023'
016537*                               TO WGLOB-MSG-REF-INFO
016537*                PERFORM  0260-1000-GENERATE-MESSAGE
016537*                    THRU 0260-1000-GENERATE-MESSAGE-X
016537*                IF WGLOB-MSG-SEVRTY-FATAL
016537*                    GO TO 8431-EDIT-CVG-DECISION-X
016537*                END-IF
016537*            END-IF
016537*        END-IF
016537*    END-IF.
016537
016537     IF  WS-MIR-DECISION-1 = 'A'
016537     AND MIR-CVG-NUM-T(WS-IDX) = '01'
025388*    AND RCVG-CVG-LIVES-INSRD-CD = 1
025388     AND RCVG-LIVES-INSRD-QTY = 1
016537     AND L2437-CLI-UWGDECN-DECLINED
016537*  MSG (F) INVALID COVERAGE DECISION WHEN CLIENT DECISION IS 'DE'
016537         MOVE 'NS12500023'  TO WGLOB-MSG-REF-INFO
016537         PERFORM  0260-1000-GENERATE-MESSAGE
016537             THRU 0260-1000-GENERATE-MESSAGE-X
016537         IF WGLOB-MSG-SEVRTY-FATAL
016537             GO TO 8431-EDIT-CVG-DECISION-X
016537         END-IF
016537     END-IF.
      *
      *   A COVERAGE DECISION CANNOT BE MADE WHEN THE CLIENT DECISION
      *   IS 'PW'
      *
      *
      *   UNDERWRITER MUST CHANGE STATUS OF DECISION (FIRST CHARACTER
      *   MUST BE CHANGED)
      *
           IF WS-MIR-DECISION-1 = WS-DECISION-1
      *MSG: DECISION STATUS (PENDING, APPROVED, DECLINED) MUST BE
      *     CHANGED
               MOVE 'NS12500021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET SW-EDIT-ERROR TO TRUE
557660     END-IF.


      *
      *   THE SECOND CHARACTER OF THE DECISION CANNOT BE CHANGED
017570*   UNLESS THE CHANGE IS FROM AN APPROVED DECISION TO
017570*   AN ELEMETARY UNDERWRITING DECISION (A* TO *E)

017570     MOVE WS-MIR-DECISION TO     WS-DECISION-ELMNT-UW.
017570     MOVE WS-DECISION     TO     WS-DECISION-APPROVED.

           IF WS-MIR-DECISION-2 NOT = WS-DECISION-2
017570     AND NOT (WS-DECISION-APPROVED-VALID
017570     AND WS-DECISION-ELMNT-UW-VALID)
      *MSG: COVERAGE DECISION INVALID - 2ND CHARACTER CANNOT CHANGE
               MOVE 'NS12500008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET SW-EDIT-ERROR TO TRUE
557660     END-IF.
      *
      *   EXIT WHEN AN ERROR IS FOUND
      *
           IF SW-EDIT-ERROR
               SET  SW-COVERAGE-ERRORS  TO TRUE
               GO TO 8431-EDIT-CVG-DECISION-X
557660     END-IF.
      *
      *   CHANGE LOCATION OF DECISION TO ELEMENTARY UNDERWRITING
      *
           MOVE 'E'                   TO WS-MIR-DECISION-2.
      *
      *   UPDATE COVERAGE RECORD
      *   (RESET THE STATUS WHEN CHANGING FROM A DECLINE)
      *
           MOVE RCVG-CVG-UWGDECN-CD   TO WS-PREV-UWGDECN-CD(WS-CVG)
           MOVE WS-MIR-DECISION       TO RCVG-CVG-UWGDECN-CD
           MOVE WGLOB-SYSTEM-DATE-INT TO RCVG-CVG-UWGDECN-DT
      *
      *   BUILD PARAMETERS AND LINK TO THE DAL WRITE MODULE
      *
           MOVE 'P'                   TO L0760-POL-OR-CLI-TYPE.
           MOVE RCVG-POL-ID           TO L0760-POL-OR-CLI-ID.
           MOVE WS-IDX                TO L0760-CVG-NUM-N.
           MOVE 'CODEC'               TO L0760-DAL-ACTIVITY.
           MOVE RCVG-CVG-UWGDECN-CD   TO L0760-DAL-ACTION.
           PERFORM  0760-1000-PROCESS-DAL-ENTRY
               THRU 0760-1000-PROCESS-DAL-ENTRY-X.
      *
       8431-EDIT-CVG-DECISION-X.
           EXIT.
      *
      *-----------------------
       8432-EDIT-CVG-REASON.
      *-----------------------
      *
      *   RESET THE REASON
      *
           IF MIR-CVG-UWGDECN-SUB-CD-T (WS-IDX) = SPACES
               MOVE RCVG-CVG-UWGDECN-SUB-CD
                                    TO MIR-CVG-UWGDECN-SUB-CD-T (WS-IDX)
               GO TO 8432-EDIT-CVG-REASON-X
           ELSE
               IF MIR-CVG-UWGDECN-SUB-CD-T (WS-IDX)
                                    = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES      TO MIR-CVG-UWGDECN-SUB-CD-T (WS-IDX)
557660         END-IF
557660     END-IF.
      *
      *   VALIDATE THE REASON AGAINST EDIT
      *
           MOVE 'CODEC'               TO WEDIT-ETBL-TYP-ID.
           MOVE MIR-CVG-UWGDECN-SUB-CD-T (WS-IDX)
                                      TO WEDIT-ETBL-VALU-ID.
           MOVE WGLOB-USER-LANG       TO WEDIT-ETBL-LANG-CD.
           PERFORM  EDIT-1000-READ
               THRU EDIT-1000-READ-X.
           IF WEDIT-IO-OK
               MOVE MIR-CVG-UWGDECN-SUB-CD-T (WS-IDX)
                                      TO RCVG-CVG-UWGDECN-SUB-CD
           ELSE
      *MSG: DECISION REASON MUST BE IN EDIT TYPE 'CODEC'
               MOVE 'NS12500009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  SW-COVERAGE-ERRORS  TO TRUE
557660     END-IF.
      *
       8432-EDIT-CVG-REASON-X.
           EXIT.
      *
      *---------------------
       8500-CLIENT-DECISION.
      *---------------------
      *
      *   SET A SWITCH INDICATING CLIENT DEC/TYPE NOT CHANGED.
      *
           SET WS-CLIENT-DEC-NOT-CHG TO TRUE.
      *
      *   BYPASS WHEN CLIENT DECISION/TYPE ARE NOT ENTERED
      *
           IF  MIR-CLI-UWGDECN-CD = SPACES
           AND MIR-CLI-UWGDECN-TYP-CD = SPACES
               GO TO 8500-CLIENT-DECISION-X
557660     END-IF.
      *
      *   BYPASS THE CLIENT DECISION LOGIC WHEN AN EDIT ERROR OCCURS
      *
           IF SW-COVERAGE-ERRORS
      *MSG: CLIENT DECISION BYPASSED BECAUSE OF ERRORS
               MOVE 'NS12500010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8500-CLIENT-DECISION-X
557660     END-IF.
      *
      *   RESET MESSAGE INQUIRY VARIABLES FOR CLIENT.
      *
           PERFORM  9300-SETUP-MSIN-REFERENCE-1
               THRU 9300-SETUP-MSIN-REFERENCE-1-X.
      *
      *   EDIT THE CLIENT DECISION
      *
           MOVE 'N'                   TO WS-EDIT-ERROR.
           IF MIR-CLI-UWGDECN-CD NOT = SPACES
               PERFORM  8510-EDIT-CLIENT-DECISION
                   THRU 8510-EDIT-CLIENT-DECISION-X
557660     END-IF.
      *
      *   EDIT THE CLIENT DECISON REASON
      *
           IF MIR-CLI-UWGDECN-TYP-CD NOT = SPACES
               PERFORM  8520-EDIT-CLIENT-REASON
                   THRU 8520-EDIT-CLIENT-REASON-X
557660     END-IF.

           IF SW-EDIT-ERROR
           OR L2437-CLI-UPDT-INDS  = SPACES
              GO TO 8500-CLIENT-DECISION-X
           END-IF.

014221* LOGICAL LOCKING -
014221* UPDATE THE TIMESTAMP ON THE CLIENT RECORD
014221     MOVE MIR-CLI-ID            TO WCLI-CLI-ID
014221     PERFORM CLI-2000-UPDATE-TWRK-TS
014221        THRU CLI-2000-UPDATE-TWRK-TS-X
014221     IF WCLI-IO-NOT-FOUND
014221*MSG: CLIENT NOT ON CLIENT FILE
014221        MOVE WCLI-KEY           TO WGLOB-MSG-PARM (1)
014221        MOVE 'XS00000076'       TO WGLOB-MSG-REF-INFO
014221        PERFORM 0260-1000-GENERATE-MESSAGE
014221           THRU 0260-1000-GENERATE-MESSAGE-X
014221        SET SW-EDIT-ERROR       TO TRUE
014221        GO TO 8500-CLIENT-DECISION-X
014221     END-IF
014221     IF MIR-RETRN-TS-MISMATCH
014221* MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*      PROCESS NOT COMPLETE
014221        MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221        MOVE 'CLI'              TO WGLOB-MSG-PARM (01)
014221        MOVE WCLI-CLI-ID        TO WGLOB-MSG-PARM (02)
014221        PERFORM 0260-1000-GENERATE-MESSAGE
014221           THRU 0260-1000-GENERATE-MESSAGE-X
014221        SET SW-EDIT-ERROR       TO TRUE
014221        GO TO 8500-CLIENT-DECISION-X
014221     END-IF.
014221     PERFORM CLI-3000-UNLOCK
014221        THRU CLI-3000-UNLOCK-X.
      *
      *   UPDATE THE CLIENT RECORD
      *
           MOVE MIR-CLI-ID            TO L2437-CLI-ID.
           PERFORM  2437-2000-UPDT-CLI-INFO
              THRU  2437-2000-UPDT-CLI-INFO-X.

014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.
014221
           IF L2437-RETRN-CLI-CCAS-LOCKED
              MOVE 'XS00000199'       TO WGLOB-MSG-REF-INFO
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
              IF L2437-RETRN-CLI-NOT-FOUND
                 MOVE L2437-WCLI-KEY  TO WGLOB-MSG-PARM (1)
                 MOVE 'XS00000076'    TO WGLOB-MSG-REF-INFO
                 PERFORM 0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
              END-IF
           END-IF.

           SET WS-CLI-READ-REQD        TO TRUE.

       8500-CLIENT-DECISION-X.
           EXIT.
      *
      *----------------------------------------------------------------
      *   EDIT CLIENT: EDIT THE CLIENT DECISION FOR VALIDITY.
      *----------------------------------------------------------------
       8510-EDIT-CLIENT-DECISION.
      *
      *   CHECK UNDERWRITERS LIMIT
      *   (DEPENDING OF THE SEVERITY OF THE MESSAGE, THE DECISION WILL
      *    EITHER BE ALLOWED OR NOT ALLOWED)
      *
           IF NOT SW-WITHIN-UW-LIMIT
      *MSG: AMOUNT ABOVE UW LIMIT, CLIENT DECISION NOT ACCEPTED
               MOVE 'NS12500022'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE L2437-CLI-UWGDECN-CD
                                      TO MIR-CLI-UWGDECN-CD
                   GO TO 8510-EDIT-CLIENT-DECISION-X
557660         END-IF
557660     END-IF.
      *
      *   A BLANK CLIENT CODE CANNOT BE UPDATED.
      *
           IF L2437-CLI-UWGDECN-CD = SPACES
      * MSG: BLANK CLIENT DECISION CANNOT BE UPDATED
               MOVE 'NS12500016'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE L2437-CLI-UWGDECN-CD
                                      TO MIR-CLI-UWGDECN-CD
               GO TO 8510-EDIT-CLIENT-DECISION-X
557660     END-IF.
      *
           MOVE MIR-CLI-UWGDECN-CD    TO WS-MIR-DECISION.
           MOVE L2437-CLI-UWGDECN-CD  TO WS-DECISION.
      *
      *   CAN ONLY CHANGE DECISION TO ACCEPT, DECLINE OR PENDING
      *
           IF  WS-MIR-DECISION-1 NOT = 'A'
           AND WS-MIR-DECISION-1 NOT = 'D'
           AND WS-MIR-DECISION-1 NOT = 'P'
      *MSG: CLIENT DECISION MUST BE A,D OR P
               MOVE 'NS12500013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET SW-EDIT-ERROR TO TRUE
557660     END-IF.
      *
      *   UNDERWRITER MUST CHANGE STATUS OF DECISION (FIRST CHARACTER
      *   MUST BE CHANGED)
      *
           IF WS-MIR-DECISION-1 = WS-DECISION-1
      *MSG: DECISION STATUS (PENDING, APPROVED, DECLINED) MUST BE
      *     CHANGED
               MOVE 'NS12500021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET SW-EDIT-ERROR TO TRUE
557660     END-IF.
      *
      *   THE SECOND CHARACTER OF THE DECISION CANNOT BE CHANGED
017570*   UNLESS THE CHANGE IS FROM AN APPROVED DECISION TO
017570*   AN ELEMETARY UNDERWRITING DECISION (A* TO *E)

017570     MOVE WS-MIR-DECISION TO     WS-DECISION-ELMNT-UW.
017570     MOVE WS-DECISION     TO     WS-DECISION-APPROVED.

           IF WS-MIR-DECISION-2 NOT = WS-DECISION-2
017570     AND NOT (WS-DECISION-APPROVED-VALID
017570     AND WS-DECISION-ELMNT-UW-VALID)
      *MSG: COVERAGE DECISION INVALID - 2ND CHARACTER CANNOT CHANGE
               MOVE 'NS12500008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET SW-EDIT-ERROR TO TRUE
557660     END-IF.
      *
      *   EXIT WHEN AN ERROR IS FOUND
      *
           IF SW-EDIT-ERROR
               MOVE L2437-CLI-UWGDECN-CD
                                      TO MIR-CLI-UWGDECN-CD
               GO TO 8510-EDIT-CLIENT-DECISION-X
557660     END-IF.
      *
      *   CHANGE LOCATION OF DECISION TO ELEMENTARY UNDERWRITING
      *
           MOVE 'E'                   TO WS-MIR-DECISION-2.
           MOVE WS-MIR-DECISION       TO MIR-CLI-UWGDECN-CD.
      *
      *   SET A SWITCH INDICATING THE CLIENT DECISION HAS CHANGED.
      *
           IF WS-MIR-DECISION NOT = WS-DECISION
              SET WS-CLIENT-DEC-CHG TO TRUE
           END-IF.
      *
      *   UPDATE CLIENT RECORD
      *
           MOVE WS-MIR-DECISION       TO L2437-CLI-UWGDECN-CD.
           MOVE WGLOB-SYSTEM-DATE-INT TO L2437-CLI-UWGDECN-DT.
           SET L2437-CLI-UWGDECN-CD-UPDT TO TRUE.
      *
      *   UPDATE PREV DECLINED INDICATOR AND DATE IF CLIENT IS DECLINED
      *
           IF  WS-CLIENT-DEC-CHG
           AND L2437-CLI-UWGDECN-DECLINED
               MOVE WGLOB-SYSTEM-DATE-INT
                                      TO L2437-CLI-PREV-DCLN-DT
               SET L2437-CLI-PREV-DCLN-DECLINED TO TRUE
               SET L2437-CLI-PREV-DCLN-IND-UPDT TO TRUE
557660     END-IF.
      *
      *   BUILD PARAMETERS AND LINK TO THE DAL WRITE MODULE
      *
           MOVE 'C'                   TO L0760-POL-OR-CLI-TYPE.
           MOVE MIR-CLI-ID            TO L0760-POL-OR-CLI-ID.
           MOVE ZERO                  TO L0760-CVG-NUM-N.
           MOVE 'CLDEC'               TO L0760-DAL-ACTIVITY.
           MOVE L2437-CLI-UWGDECN-CD  TO L0760-DAL-ACTION.
           PERFORM  0760-1000-PROCESS-DAL-ENTRY
               THRU 0760-1000-PROCESS-DAL-ENTRY-X.
      *
       8510-EDIT-CLIENT-DECISION-X.
           EXIT.
      *
      *-----------------------
       8520-EDIT-CLIENT-REASON.
      *-----------------------
      *
      *   EDIT CLIENT REASON: EDIT THE CLIENT REASON FOR VALIDITY.
      *   RESET THE REASON
      *
           IF  MIR-CLI-UWGDECN-TYP-CD = SPACES
               MOVE L2437-CLI-UWGDECN-TYP-CD
                                      TO MIR-CLI-UWGDECN-TYP-CD
               GO TO 8520-EDIT-CLIENT-REASON-X
           ELSE
               IF MIR-CLI-UWGDECN-TYP-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CLI-UWGDECN-TYP-CD
557660         END-IF
557660     END-IF.
      *
      *   VALIDATE THE REASON AGAINST EDIT
      *
           MOVE 'CLDEC'               TO WEDIT-ETBL-TYP-ID.
           MOVE MIR-CLI-UWGDECN-TYP-CD   TO WEDIT-ETBL-VALU-ID.
           MOVE WGLOB-USER-LANG       TO WEDIT-ETBL-LANG-CD.
           PERFORM  EDIT-1000-READ
               THRU EDIT-1000-READ-X.
           IF WEDIT-IO-OK
               MOVE MIR-CLI-UWGDECN-TYP-CD
                                      TO L2437-CLI-UWGDECN-TYP-CD
               SET  L2437-CLI-UWGDECN-TYP-CD-UPDT TO TRUE
           ELSE
      *MSG:  CLIENT DECISION REASON MUST BE IN EDIT TYPE 'CLDEC'
               MOVE 'NS12500012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET SW-EDIT-ERROR        TO TRUE
557660     END-IF.

       8520-EDIT-CLIENT-REASON-X.
           EXIT.
      *
      *-------------------
       8525-ATTEMPT-ISSUE.
      *-------------------
      *
      *   PROCESS-CVGS: READ AND PROCESS EITHER
      *                   1- ALL COVERAGES FOR THE CLIENT
      *               OR  2- ALL COVERAGES CURRENTLY DISPLAYED
      *
      *   RESET MESSAGE INQUIRY VARIABLES FOR CURRENT POLICY.
      *
           PERFORM  9350-SETUP-MSIN-REFERENCE-2
               THRU 9350-SETUP-MSIN-REFERENCE-2-X.
      *
      *   BROWSE THE RL FILE. IF CLIENT DECISION WAS CHANGED, ALL
      *   POLICIES FOR THE CLIENT ARE PROCESSED. OTHERWISE ONLY THOSE
      *   DISPLAYED ARE PROCESSED.
      *
           MOVE SPACES                TO WRL-KEY.
           MOVE MIR-CLI-ID            TO WRL-CLI-ID.
016440*    MOVE 'NEWBUS'              TO WRL-REL-SYS-ID.
016440     MOVE WGLOB-SYS-CTL-ID      TO WRL-REL-SYS-ID.
           MOVE HIGH-VALUES           TO WRL-ENDBR-KEY.
           MOVE MIR-CLI-ID            TO WRL-ENDBR-CLI-ID.
016440*    MOVE 'NEWBUS'              TO WRL-ENDBR-REL-SYS-ID.
016440     MOVE WGLOB-SYS-CTL-ID      TO WRL-ENDBR-REL-SYS-ID.
           IF WS-CLIENT-DEC-NOT-CHG
               MOVE MIR-POL-ID-BASE-T (1)  TO WS-MIR-POLICY-NUM
               MOVE MIR-POL-ID-SFX-T (1)  TO WS-MIR-POLICY-SUF
               MOVE WS-MIR-POLICY     TO WRL-REL-SYS-REF-POL-ID
               MOVE MIR-CVG-NUM-T (1) TO WRL-REL-SYS-REF-CVG-NUM
557660     END-IF.
      *
      *   POSITION AT, AND THEN READ THE FIRST RECORD
      *
           PERFORM RL-1000-BROWSE
              THRU RL-1000-BROWSE-X.
           IF WRL-IO-OK
               PERFORM  8110-GET-NEXT-INSURED
                   THRU 8110-GET-NEXT-INSURED-X
           ELSE
               MOVE WRL-KEY           TO WGLOB-MSG-PARM (1)
      *MSG: PROBLEMS ENCOUNTERED PROCESSING RL FILE - CONTACT SYSTEMS
               MOVE 'NS12500011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8525-ATTEMPT-ISSUE-X
557660     END-IF.
      *
      *   PROCESS ALL COVERAGES NECESSARY FOR THE CLIENT. IF CLIENT DEC
      *   WAS NOT CHANGED ONLY READ THE RECORDS CURRENTLY DISPLAYED.
      *
           SET WS-FIRST-TIME-THRU TO TRUE.
      *
           IF WS-CLIENT-DEC-CHG
               PERFORM  8530-CHANGE-COVERAGES
                   THRU 8530-CHANGE-COVERAGES-X
                       UNTIL WRL-IO-EOF
                          OR NOT WGLOB-GOOD-RETURN
           ELSE
               PERFORM  8530-CHANGE-COVERAGES
                   THRU 8530-CHANGE-COVERAGES-X
                   VARYING WS-CVG-SUB FROM 1 BY 1
                     UNTIL WRL-IO-EOF
                        OR NOT WGLOB-GOOD-RETURN
                        OR WS-CVG-SUB > WS-NO-DISPLAY-LINES
                        OR MIR-CVG-NUM-T (WS-CVG-SUB) = SPACES
557660     END-IF.
      *
           PERFORM RL-3000-END-BROWSE
              THRU RL-3000-END-BROWSE-X.
      *
      *   DO A FINAL POLICY ANALYSIS AND ATTEMPT ISSUE.
      *

           PERFORM  8930-PROCESS-POLICY
               THRU 8930-PROCESS-POLICY-X.


      *
       8525-ATTEMPT-ISSUE-X.
           EXIT.
      *
      *----------------------
       8530-CHANGE-COVERAGES.
      *----------------------
      *

016440* FOR THE UPDATE, THE COVERAGES THAT ARE BEING PROCESSED
016440* ARE BASED ON THE COVERAGES THAT WERE RETREIVED (WHICH
016440* WILL ALL BE PENDING OR REJECTED)

016440*   CHANGE THE NEXT PENDING COVERAGE AND GET THE NEXT ONE.
      *
016440     IF RCVG-CVG-STAT-BEFORE-SETL
               PERFORM  8540-PROCESS-COVERAGE
                   THRU 8540-PROCESS-COVERAGE-X
016440     END-IF.

      *
      * THIS WILL READ IN THE NEXT POLICY AND CVG WHERE RELATIONSH ='I'
      *
           PERFORM  8110-GET-NEXT-INSURED
               THRU 8110-GET-NEXT-INSURED-X.
      *
       8530-CHANGE-COVERAGES-X.
           EXIT.
      *
      *----------------------
       8540-PROCESS-COVERAGE.
      *----------------------
      *
      *   LINK TO THE POLICY ANALYSIS ROUTINE WHEN THE POLICY CHANGES
      *   (AND IT IS NOT THE FIRST TIME IN)
      *   THE NEW POLICY HAS ALREADY BEEN READ IN BY
      *    8110-GET-NEXT-INSURED
      *
           MOVE RRL-REL-SYS-REF-POL-ID                 TO WS-MIR-POLICY.

           IF WS-MIR-POLICY NOT = WS-PREV-POLICY
               MOVE RPOL-REC-INFO     TO HPOL-REC-INFO
               IF WS-FIRST-TIME-THRU
                   MOVE 'N'           TO WS-FIRST-TIME-THRU-SW
               ELSE
                   PERFORM  8930-PROCESS-POLICY
                       THRU 8930-PROCESS-POLICY-X
               END-IF
           END-IF.
      *
      *   READ IN THE CVG ARRAY
      *

           IF WS-MIR-POLICY NOT = WS-PREV-POLICY
               PERFORM  9350-SETUP-MSIN-REFERENCE-2
                   THRU 9350-SETUP-MSIN-REFERENCE-2-X
               MOVE HPOL-REC-INFO     TO RPOL-REC-INFO
               MOVE WS-MIR-POLICY     TO WS-PREV-POLICY
               PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
                  THRU  CVGS-1000-LOAD-CVGS-ARRAY-X
               IF WGLOB-MSG-ERROR-SW > ZERO
                  SET WGLOB-RETURN-ERROR TO TRUE
                  GO TO 8540-PROCESS-COVERAGE-X
               END-IF
           END-IF.
      *
      *   DEFAULT THE COVERAGE DECISION IF NECESSARY.
      *
           IF WS-CLIENT-DEC-CHG
               PERFORM  8545-DEFAULT-COVERAGE
                   THRU 8545-DEFAULT-COVERAGE-X
557660     END-IF.

       8540-PROCESS-COVERAGE-X.
           EXIT.
      *
      *-----------------------
       8545-DEFAULT-COVERAGE.
      *-----------------------
      *
      *   READ THE CURRENT COVERAGE FOR UPDATE PURPOSES
      *
           MOVE RRL-REL-SYS-REF-CVG-NUM
                                      TO WS-CVG.
           MOVE WCVGS-CVG-INFO (WS-CVG)
                                      TO RCVG-CVG-INFO.
           MOVE WS-CVG                TO RCVG-CVG-NUM-N.
      *
      *   EXIT WHEN MULTIPLE LIVES ON THIS COVERAGE OR
      *   EXIT WHEN THE COVERAGE HAS BEEN APPROVED OR
      *   EXIT IF THE CURRENT COV DECISION IS BLANK
      *
557767*    IF RCVG-CVG-LIVES-INSRD-CD-N > 1
025388*    IF RCVG-CVG-LIVES-INSRD-CD > 1
025388     IF RCVG-LIVES-INSRD-QTY > 1
           OR RCVG-CVG-UWGDECN-APPROVED
           OR RCVG-CVG-UWGDECN-CD = SPACES
           OR RCVG-CVG-UWGDECN-BYPASS
           OR RCVG-CVG-UWGDECN-DECLINED
               GO TO 8545-DEFAULT-COVERAGE-X
           END-IF.
      *
      *   APPLY THE NEW CLIENT DECISION TO THE COVERAGE
      *
           MOVE RCVG-CVG-UWGDECN-CD   TO WS-PREV-UWGDECN-CD(WS-CVG)
           MOVE MIR-CLI-UWGDECN-CD    TO RCVG-CVG-UWGDECN-CD.
           MOVE MIR-CLI-UWGDECN-CD    TO WS-MIR-DECISION.
           MOVE WGLOB-SYSTEM-DATE-INT TO RCVG-CVG-UWGDECN-DT.
      *
      *   UPDATE THE WCVGS ARRAY
      *

           MOVE RCVG-CVG-INFO         TO WCVGS-CVG-INFO (WS-CVG).

      *   RESET THE MATURITY/EXPIRY DATE
           PERFORM  8425-DECLINED-MAT-XPRY-DT
               THRU 8425-DECLINED-MAT-XPRY-DT-X.
           INITIALIZE WS-MIR-DECISION.

      *
      *   LINK TO THE COVERAGE ANALYSIS MODULE.
      *   CLIENT DECISION IS ONLY ACCEPTED IF THERE WERE NO COVERAGE
      *   EDIT ERRORS SO EDIT SWITCH IS SET TO 'C' (COMPLETE).
      *


016440* GET SPECIAL FREQUENCY BILLING VALUES FOR PHST
016440* PROCESSING

016440     PERFORM  2520-1000-BUILD-PARM-INFO
016440         THRU 2520-1000-BUILD-PARM-INFO-X.
016440
016440     IF RPOL-POL-SFB-CD NOT = SPACES
016440         MOVE  RPOL-POL-ID            TO L2520-POL-ID
016440         MOVE  RPOL-PLAN-ID           TO L2520-PLAN-ID
016440         PERFORM  2520-1000-GET-SFB-INFO
016440             THRU 2520-1000-GET-SFB-INFO-X
016440         IF L2520-RETRN-IO-ERROR
016440         OR L2520-RETRN-INVALID-REQUEST
016440             SET WGLOB-RETURN-ERROR TO TRUE
016440             GO TO 8545-DEFAULT-COVERAGE-X
016440         END-IF
016440     END-IF.

016440* BUILD ORIG PHST VALUES WITH WCVGS ARRAY
016440* THE WCVGS-CVG-CSTAT-CD WILL GET UPDATED
016440* TO 'R' IF DECISION IS DECLINED, AFTER COVERAGE ANALYSIS

025970*    PERFORM  2400-0000-INIT-PARM-INFO
025970     PERFORM  2400-0050-BUILD-PARM-INFO
025970*        THRU 2400-0000-INIT-PARM-INFO-X.
025970         THRU 2400-0050-BUILD-PARM-INFO-X.

           PERFORM  8920-COVERAGE-ANALYSIS
               THRU 8920-COVERAGE-ANALYSIS-X.


016440     PERFORM  8560-REJECT-DECLINED-CVG
016440         THRU 8560-REJECT-DECLINED-CVG-X.


016440* PROCESS COVERAGE REJECT HISTORY ON PHST

016440     PERFORM  2400-1000-BUILD-PARM-INFO
016440         THRU 2400-1000-BUILD-PARM-INFO-X.
016440     MOVE WGLOB-PROCESS-DATE  TO L2400-EFF-DT.
016440     PERFORM  2400-1000-GENERATE-PHST
016440         THRU 2400-1000-GENERATE-PHST-X.
016440     PERFORM  2400-2000-RETRN-PARM-INFO
016440         THRU 2400-2000-RETRN-PARM-INFO-X.
      *
      *   UPDATE THE COVERAGE STATUS ON THE SCREEN.
      *
           PERFORM  8550-UPDATE-MIR-DEC
               THRU 8550-UPDATE-MIR-DEC-X
               VARYING J FROM 1 BY 1
               UNTIL J > WS-NO-DISPLAY-LINES.
           IF  RPOL-POL-SUSPENDED
               PERFORM  5440-1000-BUILD-PARM-INFO
                   THRU 5440-1000-BUILD-PARM-INFO-X
               MOVE WS-CVG            TO L5440-CVG-NUM
               SET L5440-PEND-CVG-ALLOW TO TRUE
               PERFORM 5440-1000-BASE-CVG-DEFAULTS
                  THRU 5440-1000-BASE-CVG-DEFAULTS-X
           END-IF.
      *
      *   BUILD PARAMETERS AND LINK TO THE DAL WRITE MODULE
      *
           MOVE 'P'                   TO L0760-POL-OR-CLI-TYPE.
           MOVE RCVG-POL-ID           TO L0760-POL-OR-CLI-ID.
           MOVE WS-CVG                TO L0760-CVG-NUM-N.
           MOVE 'CODEC'               TO L0760-DAL-ACTIVITY.
           MOVE RCVG-CVG-UWGDECN-CD   TO L0760-DAL-ACTION.
           PERFORM  0760-1000-PROCESS-DAL-ENTRY
               THRU 0760-1000-PROCESS-DAL-ENTRY-X.
      *
       8545-DEFAULT-COVERAGE-X.
           EXIT.
      *
      *--------------------
       8550-UPDATE-MIR-DEC.
      *--------------------
      *
      *   UPDATE THE DECISION FIELD ON THE SCREEN IF IT IS CURRENTLY
      *   BEING DISPLAYED. UPDATE THE CVG STATUS AS WELL.
      *
           IF  MIR-POL-ID-BASE-T (J) = WS-MIR-POLICY-NUM
           AND MIR-POL-ID-SFX-T (J) = WS-MIR-POLICY-SUF
           AND MIR-CVG-NUM-T (J) = WRL-REL-SYS-REF-CVG-NUM
               MOVE RCVG-CVG-CSTAT-CD TO MIR-CVG-CSTAT-CD-T (J)
               MOVE RCVG-CVG-SPND-CSTAT-CD
                                      TO MIR-CVG-SPND-CSTAT-CD-T (J)
               MOVE RCVG-CVG-UWGDECN-CD
                                      TO MIR-CVG-UWGDECN-CD-T (J)
               MOVE RCVG-CVG-UWGDECN-SUB-CD
                                      TO MIR-CVG-UWGDECN-SUB-CD-T (J)
557660     END-IF.
      *
       8550-UPDATE-MIR-DEC-X.
           EXIT.
      *
016440*-------------------------
016440 8560-REJECT-DECLINED-CVG.
016440*-------------------------

016440* IF THE COVERAGE'S UNDERWRITING DECISION CODE HAS BEEN UPDATE
016440* TO 'DE', THE COVERAGE STATUS WILL BE CHANGED TO REJECTED IN
016440* THE COVERAGE ANALYSIS
016440* FOR INFORCE POLICIES WITH NEWLY REJECTED COVERAGES
016440* GENERATE '02' EXTRACTS
016440* IF UWGDECN-SUB-CD IS DC,FC,NP,NT, OR PP,PRODUCE CORRESPONDING
016440* PRTX LETTERS

016440     IF  RPOL-POL-STAT-IN-FORCE
016440     AND RCVG-CVG-STAT-REJECTED
016440
016440* UPDATE COVERAGE FIELDS
016440
016440         PERFORM  5150-1000-BUILD-PARM-INFO
016440             THRU 5150-1000-BUILD-PARM-INFO-X
016440
016440         MOVE RCVG-CVG-NUM-N          TO L5150-CVG-NUM
016440         SET  L5150-NEW-STAT-REJECTED TO TRUE
016440         MOVE WGLOB-PROCESS-DATE      TO L5150-EFF-DT
016440         SET  L5150-TERMINATING       TO TRUE
016440
016440         PERFORM  5150-2000-SNGL-CVG-STAT-UPDT
016440             THRU 5150-2000-SNGL-CVG-STAT-UPDT-X
016440
016440         IF  NOT L5150-RETRN-OK
016440             SET WGLOB-RETURN-ERROR     TO TRUE
016440             GO TO 8560-REJECT-DECLINED-CVG-X
016440         END-IF
016440
016440         MOVE RCVG-CVG-UWGDECN-SUB-CD
016440                                         TO WS-CVG-UWGDECN-SUB-CD
016440         IF WS-CVG-UWGDECN-VALID
016440
016440            PERFORM  0303-1000-BUILD-PARM-INFO
016440                THRU 0303-1000-BUILD-PARM-INFO-X
016440
016440            MOVE RCVG-CVG-UWGDECN-SUB-CD TO L0303-DOC-ID
016440            MOVE RPOL-POL-ID             TO L0303-POL-ID
016440            MOVE RCVG-CVG-NUM-N          TO L0303-CVG-NUM-N
016440            MOVE L2437-CLI-ID            TO L0303-CLI-ID
016440            MOVE RPOL-SBSDRY-CO-ID       TO L0303-SBSDRY-CO-ID
016440            MOVE WGLOB-PROCESS-DATE   TO L0303-TRNXT-TRXN-EFF-DT
016440            SET L0303-TRNXT-TYP-MISC-PRT TO TRUE
016440            PERFORM  0303-1000-WRITE-PRTX-TRAN
016440                THRU 0303-1000-WRITE-PRTX-TRAN-X
016440         END-IF
016440
016440     END-IF.
016440* FOR COVERAGES WITH CVG-UWGDECN-CD = 'DE' PERFORM
016440* UNDERWRITING CLEANUP. 'A*' GETS CLEANUP IN SETTLE CCPP1100
016440     IF RPOL-POL-STAT-IN-FORCE
016440     AND RCVG-CVG-UWGDECN-DECLINED
016440          PERFORM  CVGR-2000-REWRITE-COVERAGE
016440              THRU CVGR-2000-REWRITE-COVERAGE-X
016440          MOVE RPOL-REC-INFO       TO HPOL-REC-INFO
016440          PERFORM  6410-1000-BUILD-PARM-INFO
016440              THRU 6410-1000-BUILD-PARM-INFO-X
016440          SET L6410-EVNT-REJECT    TO TRUE
016440          SET L6410-PRCES-CLEANUP-DECLINE TO TRUE
016440          PERFORM  6410-1000-UW-CLEANUP
016440              THRU 6410-1000-UW-CLEANUP-X
016440          IF NOT L6410-RETRN-OK
016440             SET WGLOB-RETURN-ERROR TO TRUE
016440             GO TO 8560-REJECT-DECLINED-CVG-X
016440          END-IF
016440     END-IF.

016440 8560-REJECT-DECLINED-CVG-X.
016440     EXIT.


      *-----------------
       8910-NEW-POLICY.
      *-----------------
      *
      *   NEW POLICY: WHENEVER THE POLICY NUMBER CHANGES WE MUST READ
      *               IN THE POLICY AND ALL ASSOCIATED COVERAGES
      *               TO SUCCESSFULLY PERFORM THE COVERAGE EDIT
      *               AND POLICY ANALYSIS ROUTINES.

      *
      *   REWRITE THE POLICY RECORD IF REQUIRED
      *
           IF  WS-REWRITE-POL
               PERFORM  8912-REWRITE-POLICY
                   THRU 8912-REWRITE-POLICY-X
           END-IF.
      *
      *   READ IN THE NEW POLICY
      *
           MOVE WS-MIR-POLICY             TO WPOL-POL-ID.
014221*    IF  WS-READ-POL-FOR-UPDATE
014221*        PERFORM  POL-1000-READ-FOR-UPDATE
014221*            THRU POL-1000-READ-FOR-UPDATE-X
014221*        MOVE 'N'               TO WS-READ-POL-FOR-UPDATE-SW
014221*        SET  WS-REWRITE-POL       TO TRUE
014221*    ELSE
014221*        PERFORM  POL-1000-READ
014221*            THRU POL-1000-READ-X
014221*    END-IF.
014221     MOVE WPOL-KEY                  TO WLOCK-PRCES-TWRK-TS-KEY.
014221     SET  WS-REWRITE-POL            TO TRUE.
014221     PERFORM  POL-4000-UPDATE-MNTS-TW-TS
014221         THRU POL-4000-UPDATE-MNTS-TW-TS-X
014221
014221     IF WPOL-IO-NOT-FOUND
014221         SET WGLOB-RETURN-ERROR     TO TRUE
014221         MOVE 'XS00000097'          TO WGLOB-MSG-REF-INFO
014221         MOVE WPOL-KEY              TO WGLOB-MSG-PARM (1)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 8910-NEW-POLICY-X
014221     END-IF.
014221
014221     IF  MIR-RETRN-TS-MISMATCH
014221         SET WGLOB-RETURN-ERROR     TO TRUE
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221         MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221         MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221         MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221     END-IF.
014221
014221     IF  WGLOB-RETURN-ERROR
014221         SET WS-REWRITE-POL-NO      TO TRUE
014221         GO TO 8910-NEW-POLICY-X
014221     END-IF.

      *
      *   WHEN MORE THAN ONE COVERAGE IS FOUND ON A POLICY IT WILL BE
      *   NECESSARY TO READ THEM ALL IN SO THAT THE COVERAGE EDIT AND
      *   POLICY ANALYSIS ROUTINES WILL FUNCTION.
      *
           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
              THRU  CVGS-1000-LOAD-CVGS-ARRAY-X.
      *
           MOVE WS-MIR-POLICY         TO WS-PREV-POLICY.

015918*    IF  RPOL-POL-TAX-GDLN-PREM-APPLY
015918*        PERFORM  5300-0000-INIT-PARM-INFO
015918*            THRU 5300-0000-INIT-PARM-INFO-X
015918*    END-IF.

031037*    IF RPOL-SE-GDLN-APREM
025970*        PERFORM  8300-0000-INIT-PARM-INFO
031037*        PERFORM  8300-0500-BUILD-PARM-INFO
025970*            THRU 8300-0000-INIT-PARM-INFO-X
031037*            THRU 8300-0500-BUILD-PARM-INFO-X
031037*    END-IF.


       8910-NEW-POLICY-X.
           EXIT.
      *
      *--------------------
       8912-REWRITE-POLICY.
      *--------------------
      *
      * RECALCULATE THE GUIDELINE PREMIUM FOR ACCEPTED COVERAGES ONLY.
      * FOR EACH NEW POLICY, AND RE-WRITE THE COVERAGES.
      *
012138     SET WS-REWRITE-CVGS-NO      TO TRUE.
012138
015918*    IF  RPOL-POL-TAX-GDLN-PREM-APPLY
015918*        PERFORM 5300-1000-BUILD-PARM-INFO
015918*           THRU 5300-1000-BUILD-PARM-INFO-X
015918* READ SUSPEND INFORMATION
015918*        PERFORM 2470-1000-BUILD-PARM-INFO
015918*           THRU 2470-1000-BUILD-PARM-INFO-X
015918*        IF  RPOL-POL-SUSPENDED
015918*            PERFORM 2470-1000-READ-SUSPEND
015918*               THRU 2470-1000-READ-SUSPEND-X
015918*            IF  NOT L2470-RETRN-OK
015918*MSG 'POLICY OUT OF SYNC WITH SPND FOR @1 IN @2'
015918*                MOVE RPOL-POL-ID
015918*                               TO WGLOB-MSG-PARM (1)
015918*                MOVE WGLOB-MAIN-PGM-ID
015918*                               TO WGLOB-MSG-PARM (2)
015918*                MOVE 'XS00000229'
015918*                               TO WGLOB-MSG-REF-INFO
015918*                PERFORM  0260-1000-GENERATE-MESSAGE
015918*                    THRU 0260-1000-GENERATE-MESSAGE-X
015918*                GO TO 8912-REWRITE-POLICY-X
015918*            END-IF
015918*            MOVE RPOL-POL-SPND-EFF-DT     TO L5300-EFF-DT
015918*            MOVE L2470-SPND-POL-EFF-DT
015918*                               TO L5300-EFF-DT
015918*        ELSE
015918*            MOVE RPOL-POL-ISS-EFF-DT
015918*                               TO L5300-EFF-DT
015918*        END-IF
015918*        SET L5300-FORCE-RECALC TO TRUE
015918*        PERFORM  5300-3000-CALC-TEST-GDLN
015918*            THRU 5300-3000-CALC-TEST-GDLN-X
015918*        PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
015918*            THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
015918*        SET WS-REWRITE-CVGS               TO TRUE
015918*    END-IF.

031037*    PERFORM  8915-REWRITE-SE-GAP
031037*        THRU 8915-REWRITE-SE-GAP-X.
012138
012138     IF  WS-REWRITE-CVGS
012138         PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
012138             THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
012138     END-IF.
012138

016503* GET NEXT ACTIVITY INFORMATION

016503     PERFORM  6000-GET-NXT-ACTV
016503         THRU 6000-GET-NXT-ACTV-X.

           PERFORM POL-2000-REWRITE
              THRU POL-2000-REWRITE-X.

014221*    MOVE 'N'                   TO WS-REWRITE-POL-SW.
014221     SET WS-REWRITE-POL-NO      TO TRUE.
014221
014221     PERFORM  8913-UPDATE-POL-TWRK-TS
014221         THRU 8913-UPDATE-POL-TWRK-TS-X.
014221

       8912-REWRITE-POLICY-X.
           EXIT.

014221*--------------------------
014221 8913-UPDATE-POL-TWRK-TS.
014221*--------------------------
014221
014221     PERFORM  POL-1000-READ
014221         THRU POL-1000-READ-X.
014221
014221     SET  WLOCK-PRCES-START        TO TRUE.
014221     PERFORM
014221         VARYING WLOCK-IDX FROM +1 BY +1
014221         UNTIL WLOCK-PRCES-COMPLETED
014221            OR WLOCK-IDX > WLOCK-MAX-MULT-TS
014221            IF  WLOCK-MULT-TWRK-TS-KEY (WLOCK-IDX) = RPOL-KEY
014221                MOVE RPOL-PREV-UPDT-TS
014221                         TO WLOCK-MULT-TWRK-TS (WLOCK-IDX)
014221                SET WLOCK-PRCES-COMPLETED    TO TRUE
014221            END-IF
014221     END-PERFORM.
014221
014221 8913-UPDATE-POL-TWRK-TS-X.
014221     EXIT.
014221
      *
031037*---------------------------
031037*8915-REWRITE-SE-GAP.
031037*---------------------------
012138*
012138* RECALCULATE THE SEC GUIDELINE PREMIUM FOR ACCEPTED COVERAGES
012138* ONLY. FOR EACH NEW POLICY, AND RE-WRITE COVERAGES.
012138*
031037*    IF RPOL-SE-GDLN-APREM
031037*        PERFORM  8300-1000-BUILD-PARM-INFO
031037*            THRU 8300-1000-BUILD-PARM-INFO-X
031037*
031037* READ SUSPEND INFORMATION
031037*
031037*        PERFORM  2470-1000-BUILD-PARM-INFO
031037*            THRU 2470-1000-BUILD-PARM-INFO-X
031037*        IF RPOL-POL-SUSPENDED
031037*            PERFORM  2470-1000-READ-SUSPEND
031037*                THRU 2470-1000-READ-SUSPEND-X
031037*            IF NOT L2470-RETRN-OK
031037*                MOVE RPOL-POL-ID
031037*                               TO WGLOB-MSG-PARM (1)
031037*                MOVE WGLOB-MAIN-PGM-ID
031037*                               TO WGLOB-MSG-PARM (2)
031037*                MOVE 'XS00000229'
031037*                               TO WGLOB-MSG-REF-INFO
031037*                PERFORM  0260-1000-GENERATE-MESSAGE
031037*                    THRU 0260-1000-GENERATE-MESSAGE-X
031037*                GO TO 8915-REWRITE-SE-GAP-X
031037*            END-IF
031037*            MOVE L2470-SPND-POL-EFF-DT
031037*                               TO L8300-EFF-DT
031037*        ELSE
031037*            MOVE RPOL-POL-ISS-EFF-DT
031037*                               TO L8300-EFF-DT
031037*        END-IF
031037*        SET L8300-FORCE-RECALC         TO TRUE
031037*        PERFORM  8300-1000-CALC-SE-GDLN-PREM
031037*            THRU 8300-1000-CALC-SE-GDLN-PREM-X
031037*        SET WS-REWRITE-CVGS            TO TRUE
031037*
031037*    END-IF.
031037*
031037*8915-REWRITE-SE-GAP-X.
031037*    EXIT.
012138*
      *-----------------------
       8920-COVERAGE-ANALYSIS.
      *-----------------------
      *
      *   BUILD THE PARAMETERS AND LINK TO THE COVERAGE ANALYSIS MODULE
      *
           MOVE RCVG-CVG-NUM          TO WGLOB-REF-COVERAGE-NUMBER.

           PERFORM 6060-1000-BUILD-PARM-INFO
              THRU 6060-1000-BUILD-PARM-INFO-X.

           MOVE RCVG-CVG-NUM          TO L6060-CVG-NUM.

           PERFORM  6060-1000-ANALYZE-CVG
               THRU 6060-1000-ANALYZE-CVG-X.

           MOVE WCVGS-CVG-INFO (WS-CVG)
                                      TO RCVG-CVG-INFO.
           MOVE SPACES                TO WGLOB-REF-COVERAGE-NUMBER.

       8920-COVERAGE-ANALYSIS-X.
           EXIT.
      *
      *--------------------
       8930-PROCESS-POLICY.
      *--------------------
      *
      *   READ IN THE POLICY FOR UPDATE.
      *
           MOVE WS-PREV-POLICY        TO WPOL-POL-ID.
           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X

           IF WPOL-IO-NOT-FOUND
               SET WGLOB-RETURN-ERROR TO TRUE
               MOVE 'XS00000097'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8930-PROCESS-POLICY-X
557660     END-IF.

      *
      * CALL CSLF0953 TO PERFORM EDITS/CROSS-EDITS AND RECALC PRMS, TAX
      * ETC.
      *
           PERFORM 0953-1000-BUILD-PARM-INFO
              THRU 0953-1000-BUILD-PARM-INFO-X.
           MOVE WGLOB-PROCESS-DATE    TO L0953-EFF-DT.

           IF  RPOL-POL-ISS-DT-TYP-CD = 'C'
           AND RPOL-POL-ISS-EFF-DT NOT = WGLOB-PROCESS-DATE
               SET L0953-DT-CHNG-CRNT   TO TRUE
               SET L0953-ISS-DT-CHANGED TO TRUE
           END-IF.

012148     MOVE L8240-AGT-ID (1)      TO L0953-POLW-AGT-ID (1).
012148     MOVE L8240-AGT-ID (2)      TO L0953-POLW-AGT-ID (2).
012148     MOVE L8240-AGT-ID (3)      TO L0953-POLW-AGT-ID (3).

016440     IF RPOL-POL-STAT-IN-FORCE
016440        SET L0953-GDLN-PREM-UPDATE-NO TO TRUE
016440     END-IF.

           PERFORM 0953-1000-MAINTAIN-POLICY
              THRU 0953-1000-MAINTAIN-POLICY-X.

      *
      *   RE-WRITE THE COVERAGE RECORDS.
      *
           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
              THRU  CVGR-1000-REWRITE-CVGS-ARRAY-X.

           IF L0953-RETRN-ERROR
           OR L0953-EDIT-ERROR
           OR L0953-CROSS-EDIT-ERROR
026149     OR L0953-PACKAGING-ERROR           
               SET WS-POL-EDIT-ERR          TO TRUE
           ELSE
               SET WS-POL-EDIT-ERR-NO       TO TRUE
           END-IF.
      *
      *   RESET NEXT ACTIVITY DATE FIELDS, AND UPDATE THE POLICY

016503*    MOVE  'RSH'                TO  RPOL-NXT-ACTV-TYP-CD.
016503*    MOVE  WWKDT-ZERO-DT        TO  RPOL-POL-NXT-ACTV-DT.

      *  IF THERE ARE ANY COVERAGE ERRORS (EITHER ON SCREEN ERRORS
      *  OR COVERAGE EDIT ERRORS) THE POLICY FOR THAT COVERAGE CANNOT
      *  HAVE ISSUE/SETTLE PROCESSING ATTEMPTED.
      *
           IF WS-POLICY-ERROR
               MOVE WPOL-POL-ID       TO WS-SAVE-POLICY
               PERFORM  8936-READ-POLICY-ARRAY
                   THRU 8936-READ-POLICY-ARRAY-X
                   VARYING I FROM 1 BY 1
                   UNTIL I > 10
                   OR WS-POLICY-FOUND
               IF WS-POLICY-FOUND
                   MOVE 'N'           TO WS-POLICY-FOUND-SW
016503             PERFORM 6000-GET-NXT-ACTV
016503                THRU 6000-GET-NXT-ACTV-X
                   PERFORM  POL-2000-REWRITE
                       THRU POL-2000-REWRITE-X
014221             PERFORM  8913-UPDATE-POL-TWRK-TS
014221                 THRU 8913-UPDATE-POL-TWRK-TS-X
      * MSG: POLICY (@1) ISSUE NOT ATTEMPTED - ERRORS ON COVERAGE
                   MOVE 'NS12500024'  TO WGLOB-MSG-REF-INFO
                   MOVE WS-SAVE-POLICY             TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 8930-PROCESS-POLICY-X
034802*        ELSE
034802*            NEXT SENTENCE
557660         END-IF
034802*    ELSE
034802*        NEXT SENTENCE
557660     END-IF.

      *
      *  IF POLICY ANALYSIS SUCCESFUL, TRY POLICY ISSUE.
      *  ELSE THE POLICY MUST BE UNLOCKED.
      *  (WHEN THE POLICY HAS BEEN UPDATED, REWRITE THE RECORD, ELSE
      *  JUST UNLOCK THE RECORD).
      *
      *

016440* IF POLICY IS IN FORCE, CALL SUB-ROUTINE TO DETERMINE IF
016440* ANY PENDING COVERAGES EXIST - FOR COVERAGE LEVEL ISSUE
016440* PROCESSING


016440     INITIALIZE L2222-INFORCE-POL-PEND-CVG-IND.
016440     IF  RPOL-POL-STAT-IN-FORCE
016440         PERFORM  2222-1000-BUILD-PARM-INFO
016440             THRU 2222-1000-BUILD-PARM-INFO-X
016440         MOVE RPOL-POL-ID       TO L2222-POL-ID
016440         PERFORM  2222-1000-FIND-PEND-CVG
016440             THRU 2222-1000-FIND-PEND-CVG-X
016440     END-IF.

           IF  WGLOB-GOOD-RETURN
           AND NOT RPOL-LINK-POL-ISS
           AND NOT SW-EDIT-ERROR
           AND NOT WS-POL-EDIT-ERR
           AND WS-MIR-DECISION-1 NOT = 'P'
               IF  RPOL-POL-STAT-COMPLETE
               OR (RPOL-POL-ERROR-CORRECTED AND RPOL-POL-UWG-COMPLETE)
016440         OR  (L2222-INFORCE-POL-PEND-CVG
016440         AND  L2222-CVG-UWGDECN-COMPLETE)
                   PERFORM  8940-POLICY-ISSUE
                       THRU 8940-POLICY-ISSUE-X
                   GO TO 8930-PROCESS-POLICY-X
557660         END-IF
557660     END-IF.
      *
016503     PERFORM  6000-GET-NXT-ACTV
016503         THRU 6000-GET-NXT-ACTV-X.


           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

014221     PERFORM  8913-UPDATE-POL-TWRK-TS
014221         THRU 8913-UPDATE-POL-TWRK-TS-X.
      *
      *  ISSUE IS NOT ATTEMPTED FOR LINKED POLICIES. A DAL ENTRY AND
      *  MESSAGE ARE CREATED TO REFLECT THIS.
      *
           IF NOT RPOL-LINK-POL-ISS
               GO TO 8930-PROCESS-POLICY-X
557660     END-IF.

           MOVE 'P'                   TO L0760-POL-OR-CLI-TYPE.
           MOVE WS-PREV-POLICY        TO L0760-POL-OR-CLI-ID.
           MOVE 'ISSUE'               TO L0760-DAL-ACTIVITY.
           MOVE 'LINK'                TO L0760-DAL-ACTION.
           MOVE ZEROS                 TO L0760-CVG-NUM.
           MOVE SPACES                TO L0760-MESSAGE-NUMBER.
           PERFORM  0760-1000-PROCESS-DAL-ENTRY
               THRU 0760-1000-PROCESS-DAL-ENTRY-X.

      *MSG: ISSUE NOT ATTEMPTED FOR LINKED POLICY - @1
           MOVE 'NS12500019'          TO WGLOB-MSG-REF-INFO.
           MOVE WS-PREV-POLICY        TO WGLOB-MSG-PARM (1).
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
       8930-PROCESS-POLICY-X.
           EXIT.
      *
      *-----------------------
       8936-READ-POLICY-ARRAY.
      *-----------------------

           IF WS-POLICY-ARRAY (I) = WS-SAVE-POLICY
               SET WS-POLICY-FOUND TO TRUE
           END-IF.

       8936-READ-POLICY-ARRAY-X.
           EXIT.
      *
      ***************************************************************
      *  POLICY ISSUE:  LINK TO THE POLICY ISSUE MODULE
      ***************************************************************

       8940-POLICY-ISSUE.


      *  BUILD PARAMETERS AND LINK TO POLICY ISSUE MODULE.
      *  THIS MODULE WILL ALSO ATTEMPT POLICY SETTLE.

      *** MESSAGE (I) ISSUE PROCESSING INITIATED FOR (@1)
           MOVE 'XS00000200'          TO WGLOB-MSG-REF-INFO.
           MOVE RPOL-POL-ID           TO WGLOB-MSG-PARM (1).
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM 0700-1000-BUILD-PARM-INFO
              THRU 0700-1000-BUILD-PARM-INFO-X.
           SET L0700-ATTEMPT-SETTLE-REQD TO TRUE.


014660     MOVE '1252' TO L0700-BUS-FCN-ID.

           MOVE RPOL-POL-ISS-DT-TYP-CD               TO L0700-ISSUE-IND.

016440* ENABLE COVERAGE-LEVEL SETTLE

016440     IF RPOL-POL-STAT-IN-FORCE
016440        SET WS-FIRST-APPRV-CVG-NO   TO TRUE
016440        PERFORM 8950-GET-CVG-SETTLE-INFO
016440           THRU 8950-GET-CVG-SETTLE-INFO-X
016440           VARYING WS-CVG FROM 1 BY 1
016440             UNTIL WS-CVG > RPOL-POL-CVG-REC-CTR-N
016440                OR WS-FIRST-APPRV-CVG-YES
016440        SET L0700-CHNG-RATE-AGE     TO TRUE
016440     ELSE
016440        MOVE RPOL-POL-ISS-EFF-DT   TO L0700-EFF-DT
016440     END-IF.

016440*    MOVE RPOL-POL-ISS-EFF-DT   TO L0700-EFF-DT.
557660*    MOVE WS-CLI-SUR-NM-1-4        TO L0700-CLI-SUR-NM-1-4.
      *IF THE CLIENT IS A COMPANY THE CLIENT SURNAME WILL BE BLANK
013578*    IF L2437-CLI-SEX-CD = 'C'
013578*        MOVE L2437-CLI-CO-NM   TO L0700-CLI-SUR-NM-1-4
013578*    ELSE
013578*        MOVE WS-CLI-SUR-NM-1-4 TO L0700-CLI-SUR-NM-1-4
013578*    END-IF.

012148     MOVE L8240-AGT-ID (1)      TO L0700-POLW-AGT-ID (1).
012148     MOVE L8240-AGT-ID (2)      TO L0700-POLW-AGT-ID (2).
012148     MOVE L8240-AGT-ID (3)      TO L0700-POLW-AGT-ID (3).

           PERFORM  0700-1000-ISSUE-POLICY
               THRU 0700-1000-ISSUE-POLICY-X.

      *
      * REWRITE THE RECORD - SINCE UPDATES TO RPOL FIELDS MAY HAVE
      * OCCURRED DURING POLICY ANALYSIS.
      *
016503     PERFORM  6000-GET-NXT-ACTV
016503         THRU 6000-GET-NXT-ACTV-X.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

014221     PERFORM  8913-UPDATE-POL-TWRK-TS
014221         THRU 8913-UPDATE-POL-TWRK-TS-X.

017518* REWRITE THE COVERAGES - SINCE UPDATES TO THE WCVGS ARRAY
017518* MAY HAVE OCCURRED DURING ISSUE/SETTLE PROCESSING

017518     PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
017518        THRU  CVGR-1000-REWRITE-CVGS-ARRAY-X.

       8940-POLICY-ISSUE-X.
           EXIT.

016440*-------------------------
016440 8950-GET-CVG-SETTLE-INFO.
016440*-------------------------

016440* CHECK COVERAGE UNDERWRITING DECISION FOR PENDING COVERAGES.
016440* SET L0700 FIELDS FOR COVERAGE PROCESSING
016440* IF DECISION IS APPROVED OR BYPASSED ON ANY PENDING COVEAGE
016440* SET L0700-CVG-UWGDECN-COMPLETE

016440
016440     IF NOT WCVGS-CVG-STAT-PENDING (WS-CVG)
016440        GO TO 8950-GET-CVG-SETTLE-INFO-X
016440     END-IF.
016440
016440     IF WS-FIRST-PENDING-CVG-YES
016440        MOVE WCVGS-CVG-ISS-EFF-DT (WS-CVG)
016440                                 TO L0700-CVG-ISS-EFF-DT
016440        MOVE WCVGS-CVG-ISS-EFF-DT (WS-CVG)
016440                                 TO L0700-EFF-DT
016440        SET WS-FIRST-PENDING-CVG-NO        TO TRUE
016440     END-IF.
016440
016440     IF WCVGS-CVG-UWGDECN-APPROVED (WS-CVG)
016440     OR WCVGS-CVG-UWGDECN-BYPASS (WS-CVG)
016440        MOVE WCVGS-CVG-ISS-EFF-DT (WS-CVG)
016440                                 TO L0700-CVG-ISS-EFF-DT
016440        MOVE WCVGS-CVG-ISS-EFF-DT (WS-CVG)
016440                                 TO L0700-EFF-DT
016440        SET L0700-CVG-UWGDECN-COMPLETE     TO TRUE
016440        SET WS-FIRST-APPRV-CVG-YES         TO TRUE
016440     END-IF.
016440
016440     SET L0700-CVG-PROCESS                 TO TRUE.
016440
016440 8950-GET-CVG-SETTLE-INFO-X.
016440     EXIT.

      *------------------------
       9100-BLANK-DATA-FIELDS.
      *------------------------
      *
      *    MOVE SPACES TO EACH SCREEN DATA FIELD.
      *
013578*    MOVE SPACES                TO MIR-CLI-SUR-NM.
013578     MOVE SPACES                TO MIR-DV-INSRD-CLI-NM.
           MOVE SPACES                TO MIR-DV-CLI-INSRD-AGE.
           MOVE SPACES                TO MIR-CLI-SEX-CD.
           MOVE SPACES                TO MIR-CLI-SMKR-CD.
           MOVE SPACES                TO MIR-UW-USER-1-ID.
           MOVE SPACES                TO MIR-UW-USER-2-ID.
           MOVE SPACES                TO MIR-CLI-UWGDECN-CD.
           MOVE SPACES                TO MIR-CLI-UWGDECN-TYP-CD.
           MOVE SPACES                TO MIR-CVG-STBL-3-CD-G.
           MOVE SPACES                TO MIR-CVG-STBL-4-CD-G.
           MOVE SPACES                TO MIR-CVG-ENHC-TYP-CD-G.
           MOVE SPACES                TO MIR-CVG-COLA-SELCT-CD-G.
           MOVE SPACES                TO MIR-REDC-EP-SELCT-IND-G.
           MOVE SPACES                TO MIR-OWN-OCCP-SELCT-IND-G.
           MOVE SPACES                TO MIR-CVG-LTA-SELCT-IND-G.
           MOVE SPACES                TO MIR-CVG-LTB-SELCT-IND-G.
           MOVE SPACES                TO MIR-PDISAB-SELCT-IND-G.
           MOVE SPACES                TO MIR-CVG-UWG-EXCL-1-CD-G.
           MOVE SPACES                TO MIR-CVG-UWG-EXCL-2-CD-G.
           MOVE SPACES                TO MIR-CVG-UWG-EXCL-3-CD-G.

           PERFORM  9110-BLANK-DISPLAY-LINES
               THRU 9110-BLANK-DISPLAY-LINES-X
               VARYING J FROM 1 BY 1
               UNTIL (J > WS-NO-DISPLAY-LINES).

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *--------------------------
       9110-BLANK-DISPLAY-LINES.
      *--------------------------
      *
      *  SET EACH DISPLAY LINE TO BLANKS
      *
           MOVE SPACES                TO MIR-CVG-NUM-T (J).
           MOVE SPACES                TO MIR-POL-ID-BASE-T (J).
           MOVE SPACES                TO MIR-POL-ID-SFX-T (J).
           MOVE SPACES                TO MIR-PLAN-ID-T (J).
           MOVE SPACES                TO MIR-CVG-FACE-AMT-T (J).
           MOVE SPACES                TO MIR-CVG-AD-FACE-AMT-T (J).
           MOVE SPACES                TO MIR-CVG-AD-MULT-FCT-T (J).
           MOVE SPACES                TO MIR-CVG-WP-MULT-FCT-T (J).
           MOVE SPACES                TO MIR-CVG-STBL-1-CD-T (J).
           MOVE SPACES                TO MIR-CVG-STBL-2-CD-T (J).
           MOVE SPACES                TO MIR-CVG-UWGDECN-CD-T (J).
           MOVE SPACES                TO MIR-CVG-ME-FCT-T (J).
557671     MOVE SPACES                TO MIR-CVG-ME-RAT-CD-T (J).
           MOVE SPACES                TO MIR-CVG-ME-REASN-CD-T (J).
           MOVE SPACES                TO MIR-CVG-ME-DUR-T (J).
           MOVE SPACES                TO MIR-CVG-FE-UPREM-AMT-T (J).
           MOVE SPACES                TO MIR-CVG-FE-REASN-CD-T (J).
           MOVE SPACES                TO MIR-CVG-FE-DUR-T (J).
           MOVE SPACES                TO MIR-CVG-RT-AGE-T (J).
           MOVE SPACES                TO MIR-AGE-RAT-REASN-CD-T (J).
           MOVE SPACES                TO MIR-CVG-SMKR-CD-T (J).
           MOVE SPACES                TO MIR-CVG-SEX-CD-T (J).
           MOVE SPACES                TO MIR-CVG-UWG-AMT-T (J).
           MOVE SPACES                TO MIR-UWG-AMT-REASN-CD-T (J).
           MOVE SPACES                TO MIR-CVG-PREV-FACE-AMT-T (J).
025388*    MOVE SPACES                TO MIR-CVG-LIVES-INSRD-CD-T (J).
025388     MOVE SPACES                TO MIR-LIVES-INSRD-QTY-T (J).
           MOVE SPACES                TO MIR-CVG-SUPP-BNFT-CD-T (J).
           MOVE SPACES                TO MIR-POL-OPTL-CD-T (J).
           MOVE SPACES                TO MIR-LINK-POL-ISS-IND-T (J).
           MOVE SPACES                TO MIR-CVG-CSTAT-CD-T (J).
           MOVE SPACES                TO MIR-CVG-SPND-CSTAT-CD-T (J).

       9110-BLANK-DISPLAY-LINES-X.
           EXIT.
      *
      *----------------------------
       9300-SETUP-MSIN-REFERENCE-1.
      *----------------------------
      *
      *    SET REFERENCE: MOVE DATA WHICH IDENTIFIES THE OBJECT THAT IS
      *    WORKED ON TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING.
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'C'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-CLI-ID            TO WGLOB-REF-CLIENT-NUMBER.

       9300-SETUP-MSIN-REFERENCE-1-X.
           EXIT.
      *
      *----------------------------
       9350-SETUP-MSIN-REFERENCE-2.
      *----------------------------
      *
      *    SET REFERENCE: MOVE DATA WHICH IDENTIFIES THE OBJECT THAT IS
      *    WORKED ON TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING.
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE WS-MIR-POLICY         TO WGLOB-REF-POLICY-ID.

       9350-SETUP-MSIN-REFERENCE-2-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0303-0000-INIT-PARM-INFO
025970         THRU 0303-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0570-0000-INIT-PARM-INFO
025970         THRU 0570-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0700-0000-INIT-PARM-INFO
025970         THRU 0700-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0760-0000-INIT-PARM-INFO
025970         THRU 0760-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0953-0000-INIT-PARM-INFO
025970         THRU 0953-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1251-0000-INIT-PARM-INFO
025970         THRU 1251-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1255-0000-INIT-PARM-INFO
025970         THRU 1255-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1390-0000-INIT-PARM-INFO
025970         THRU 1390-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1510-0000-INIT-PARM-INFO
025970         THRU 1510-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2222-0000-INIT-PARM-INFO
025970         THRU 2222-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2400-0000-INIT-PARM-INFO
025970         THRU 2400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2450-0000-INIT-PARM-INFO
025970         THRU 2450-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2470-0000-INIT-PARM-INFO
025970         THRU 2470-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2520-0000-INIT-PARM-INFO
025970         THRU 2520-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  5150-0000-INIT-PARM-INFO
025970         THRU 5150-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5440-0000-INIT-PARM-INFO
025970         THRU 5440-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6060-0000-INIT-PARM-INFO
025970         THRU 6060-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6410-0000-INIT-PARM-INFO
025970         THRU 6410-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8240-0000-INIT-PARM-INFO
025970         THRU 8240-0000-INIT-PARM-INFO-X.
025970
031037*    PERFORM  8300-0000-INIT-PARM-INFO
031037*        THRU 8300-0000-INIT-PARM-INFO-X.
031037*
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WS-TEMP-AREA.
025970     INITIALIZE                         FREQUENTLY-USED-INDICES.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TRANS-NAME          TO TRUE.
025970     SET WS-DEFAULT-FIRST-PEND-CVG-IND  TO TRUE.
025970     SET WS-DEFAULT-FIRST-APPRV-CVG     TO TRUE.
025970     SET WS-DEFAULT-INSURED-SW          TO TRUE.
025970     SET WS-DEFAULT-COVERAGE-SW         TO TRUE.
025970     SET WS-DEFAULT-COVERAGE-ERRORS-SW  TO TRUE.
025970     SET WS-DEFAULT-WITHIN-UW-LIMIT     TO TRUE.
025970     SET WS-DEFAULT-EDIT-ERROR          TO TRUE.
025970     SET WS-DEFAULT-AMMENDMENT-REQD-SW  TO TRUE.
025970     SET WS-DEFAULT-FIRST-TIME-THRU-SW  TO TRUE.
025970     SET WS-DEFAULT-CLIENT-DEC-CHG-SW   TO TRUE.
025970     SET WS-DEFAULT-READ-POL-UPDT-SW    TO TRUE.
025970     SET WS-DEFAULT-REWRITE-POL-SW      TO TRUE.
025970     SET WS-DEFAULT-POLICY-ERROR-SW     TO TRUE.
025970     SET WS-DEFAULT-POLICY-FOUND-SW     TO TRUE.
023514
025970     MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.
025970     MOVE SPACES                       TO WWKDT-WORK-FIELDS.
027105
027105     COMPUTE WS-NO-DISPLAY-LINES
027105           = LENGTH OF MIR-CVG-UWGDECN-CD-G
027105           / LENGTH OF MIR-CVG-UWGDECN-CD-T (1).
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *
018633***************************
018633*9500-BUILD-TWRK-KEY.
018633***************************
018633*
018633*    MOVE WS-TWRK-KEY           TO L8090-BUS-FCN-ID.
018691*    MOVE ZEROS                 TO L8090-TEMP-WRK-SEQ-NUM.
018633*    MOVE +1                    TO L8090-TEMP-WRK-SEQ-NUM.
018633*    SET  L8090-USAGE-COMM      TO TRUE.
018633*    MOVE LENGTH OF WS-WORK-AREA
018633*                               TO L8090-AREA-LEN.
018633*
018633*
018633*9500-BUILD-TWRK-KEY-X.
018633*    EXIT.
018633*
018633***************************
018633*9700-RETRIEVE-TWRK.
018633***************************
018633*
018633*    PERFORM 9500-BUILD-TWRK-KEY
018633*       THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    PERFORM 8090-2000-RETRIEVE-TWRK
018633*       THRU 8090-2000-RETRIEVE-TWRK-X.
018633*
018633*
018633*9700-RETRIEVE-TWRK-X.
018633*    EXIT.
018633*
018633***************************
018633*9800-WRITE-TWRK.
018633***************************
018633*
018633*    PERFORM 9500-BUILD-TWRK-KEY
018633*       THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*    MOVE LENGTH OF WS-WORK-AREA
018633*                TO L8090-AREA-LEN.
018633*
018633*    PERFORM 8090-1000-WRITE-TWRK
018633*       THRU 8090-1000-WRITE-TWRK-X.
018633*
018633*
018633*9800-WRITE-TWRK-X.
018633*    EXIT.
018633*
018633***************************
018633*9900-DELETE-TWRK.
018633***************************
018633*
018633*    PERFORM 9500-BUILD-TWRK-KEY
018633*       THRU 9500-BUILD-TWRK-KEY-X.
018633*
018633*
018633*    PERFORM 8090-3000-DELETE-TWRK
018633*       THRU 8090-3000-DELETE-TWRK-X.
018633*
018633*
018633*9900-DELETE-TWRK-X.
018633*    EXIT.
018633*
      *****************************************************************
      *  PROCESSING COPYBOOKS
      *****************************************************************
      ****************************************************************

028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY NCPPCVGR.
       COPY NCPPCVGS.
      *
       COPY XCPPINIT.
       COPY XCPPEXIT.
      *
025970 COPY XCPS1670.
025970 COPY CCPS2450.
018633 COPY XCPSCOMM.
018633 COPY XCPPCOMM.
018633
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CLI
014221                         '$VAR2' BY 'CLI'.
      *
014660*COPY XCPPMEXT.
      *
      ****************************************************************
      * LINK PROCESSING COPYBOOKS                                    *
      ****************************************************************
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
013578 COPY CCPL0620.
      *
       COPY CCPSPGA.
016440 COPY NCPS0303.
018764*COPY NCCL0303.
018764 COPY NCPL0303.
      *
016440 COPY NCPS6410.
018764*COPY NCCL6410.
018764 COPY NCPL6410.
      *
016440 COPY CCPS5150.
018764*COPY CCCL5150.
018764 COPY CCPL5150.
      *
016503 COPY CCPS0289.
018764*COPY CCCL0289.
018764 COPY CCPL0289.
      *
016440 COPY CCPS2222.
018764*COPY CCCL2222.
018764 COPY CCPL2222.
      *
016440 COPY CCPS2400.
018764*COPY CCCL2400.
018764 COPY CCPL2400.
      *
016440 COPY CCPS2520.
018764*COPY CCCL2520.
018764 COPY CCPL2520.

       COPY CCPS0570.
018764*COPY CCCL0570.
018764 COPY CCPL0570.
      *
       COPY CCPS0953.
018764*COPY CCCL0953.
018764 COPY CCPL0953.
      *
018764*COPY CCCL2450.
018764 COPY CCPL2450.
      *
557788 COPY CCPS2470.
018764*COPY CCCL2470.
018764 COPY CCPL2470.
      *
015918*COPY CCPS5300.
015918*COPY CCCL5300.
      *
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      *
       COPY CCPS5440.
018764*COPY CCCL5440.
018764 COPY CCPL5440.
      *
       COPY CCPS5600.
018764*COPY CCCL5600.
018764 COPY CCPL5600.
      *
       COPY CCPS6060.
018764*COPY CCCL6060.
018764 COPY CCPL6060.
      *
012148 COPY CCPS8240.
018764*COPY CCCL8240.
018764 COPY CCPL8240.
      *
031037*COPY CCPS8300.
018764*COPY CCCL8300.
031037*COPY CCPL8300.
       COPY NCPS0700.
018764*COPY NCCL0700.
018764 COPY NCPL0700.
      *
018764*COPY NCCL0760.
025970 COPY NCPS0760.
018764 COPY NCPL0760.
      *
       COPY NCPS1251.
018764*COPY NCCL1251.
018764 COPY NCPL1251.
      *
       COPY NCPS1255.
018764*COPY NCCL1255.
018764 COPY NCPL1255.
      *
       COPY NCPS1390.
018764*COPY NCCL1390.
018764 COPY NCPL1390.
      *
018764*COPY NCCL2437.
025970 COPY NCPS2437.
018764 COPY NCPL2437.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
       COPY XCPS1510.
018764*COPY XCCL1510.
018764 COPY XCPL1510.
      *
018764*COPY XCCL8090.
018633 COPY XCPS8090.
018764 COPY XCPL8090.
      *
025970 COPY XCPS1680.
       COPY XCPL1680.
      *
      *
008455 COPY XCPL0290.
008455 COPY XCPS0290.
008455*
025970 COPY XCPS0280.
013578 COPY XCPL0280.
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************

       COPY CCPNCVG.
       COPY CCPUCVG.
      *
       COPY CCPNEDIT.
      *
       COPY CCPNPOL.
       COPY CCPUPOL.
014221 COPY CCPPMNTS REPLACING ==:VAR1:== BY POL
014221                             '$VAR2' BY 'POL'.

      *
014221 COPY CCPNCLI.
014221 COPY CCPUCLI.
      *
       COPY CCPBRL.
018278 COPY CCPVRL.
      *
      *****************************************************************
      * ERROR HANDLING ROUTINES
      *****************************************************************
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM1250                     **
      *****************************************************************
