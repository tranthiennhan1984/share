      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7819.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7819                                         **
      **  REMARKS:  THIS MODULE PERFORMS                             **
      **            FINANCIAL ACTIVITY - PERIODIC DEDUCTION DETAILS  **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018839**  6.3       FINANCIAL BALANCES FLOW                          **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020469**  6.4       MULTI-CURRENCY FUND PROCESSING                   **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021239**  6.4       FUND UNIT VALUE                                  **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
021657**  6.6       CORRECT FIELD NAMES IN MIR COPYBOOKS             **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
025999**  6.6       MESSAGE CORRECTION                               **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
030054**  7.0       PHST SEQUENCE NUMBER EXPANSION                   **
033899**  7.0       M&E TRANSFER MISSING FROM POLICY ACTIVITY LIST   **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7819'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

       01  WS-WORKING-STORAGE.
           05  WS-MAX-LINE                   PIC 999 VALUE 139.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-RETRIEVE       VALUE '7819'.
           05  WS-CVG                        PIC 99.
           05  WS-SEQ                        PIC X(20).
           05  FILLER             REDEFINES  WS-SEQ.
               10  WS-SEQ-NUM                PIC 999.
               10  FILLER                    PIC X(17).
           05  WS-FA-SEQ-NUM                 PIC 999.
           05  WS-SUB                        PIC 999.
           05  WS-WEALTH-ACCUM-IND           PIC X.
               88  WS-WEALTH-ACCUM-YES       VALUE 'Y'.
               88  WS-WEALTH-ACCUM-NO        VALUE 'N'.
           05  WS-ADM-REC-FOUND-IND          PIC X(001).
               88  WS-ADM-REC-FOUND-NO       VALUE 'N'.
               88  WS-ADM-REC-FOUND-YES      VALUE 'Y'.
           05  WS-GROUP-END-IND              PIC X.
               88  WS-GROUP-END-YES          VALUE 'Y'.
               88  WS-GROUP-END-NO           VALUE 'N'.
           05  WS-SAVE-EFF-IDT-NUM           PIC X(007).
           05  WS-SAVE-EFF-DT                PIC X(010).
030054*    05  WS-SAVE-SEQ-NUM               PIC 9(003).
030054     05  WS-SAVE-SEQ-NUM               PIC 9(005).
021239*    05  WS-INIT-WORK                  PIC S9(8)V9(9).
021239*    05  WS-ACUM-WORK                  PIC S9(8)V9(9).
021239*    05  WS-UNIT-QTY                   PIC S9(8)V9(9).
           05  WS-ACTIVITY-TYPE-ID              PIC X(4).
               88  WS-ACTIVITY-TYPE-ADMIN-FEES  VALUE '4007' '4008'
                                                '5002' '5003' '5004'
                                                '4014' '5100'.
               88  WS-ACTIVITY-TYPE-REVRS VALUE '4001' '4002' '4003'
                                                '4006' '4007' '4008'
                                                '4011' '4012' '4013'
                                                '4014' '4015' '4017'
                                                '4018' '5002' '5003'
                                                '5004' '5005' '5006'
033899*                                         '5007' '5010' '5100'
033899                                          '5007' '5011' '5100'
                                                '5022'.
           05  WS-CLI-TRXN-AMT               PIC S9(13)V9(02).
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
026057 COPY CCWWIHSD.
       COPY XCWWWKDT.
       COPY CCWWINDX.
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWPOL.
       COPY CCFRPOL.
       COPY CCFWCVG.
       COPY CCFRCVG.
       COPY CCWWCVGS.
       COPY CCFREDIT.
       COPY CCFWEDIT.
       COPY SCFWFA.
       COPY SCFRFA.
       COPY SCFWFD.
       COPY SCFRFD.
021239 COPY SCFRFDUT.
       COPY CCFWCFLW.
       COPY CCFRCFLW.
       COPY CCFWPHST.
       COPY CCFRPHST.
       COPY CCFWUH.
       COPY CCFRUH.
       COPY CCFWUHCO.
       COPY CCFRUHCO.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
021239 COPY SCWL7791.
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
       COPY XCWL8090.
020469 COPY XCWL8640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7819.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    INITIALIZE                   WS-WORK-AREA.
025970*    MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.
025970*    SET  MIR-RETRN-OK         TO TRUE.
025970*    MOVE SPACES               TO MIR-OUTPUT-AREA.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7819'     TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'   TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *-------------
       2000-RETRIEVE.
      *-------------

           MOVE MIR-POL-ID             TO WPOL-POL-ID.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: (@2) RECORD (@1) NOT FOUND
               MOVE WPOL-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'POL'            TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000344'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           SET WS-WEALTH-ACCUM-NO TO TRUE.

           PERFORM  2010-INS-TYPE-CHECK
               THRU 2010-INS-TYPE-CHECK-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > RPOL-POL-CVG-REC-CTR-N
                  OR WS-WEALTH-ACCUM-YES.

           IF WS-WEALTH-ACCUM-NO
      * MSG: FINANCIAL ACTIVITY IS NOT AVAILABLE FOR THIS TYPE OF POLICY
               MOVE 'CS78190001'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-RETRIEVE-X
           END-IF.


021657*    MOVE MIR-DV-FIRST-SEQ-NUM      TO L0280-INPUT-DATA.
021657     MOVE MIR-DV-FIN-TRXN-SEQ-NUM   TO L0280-INPUT-DATA.
021657*    MOVE LENGTH OF MIR-DV-FIRST-SEQ-NUM TO L0280-INPUT-SIZE.
021657     MOVE LENGTH OF MIR-DV-FIN-TRXN-SEQ-NUM TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE          TO L0280-LENGTH.
           MOVE ZERO                      TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
           MOVE L0280-OUTPUT              TO WS-SAVE-SEQ-NUM.


           MOVE MIR-DV-FIN-TRXN-EFF-DT    TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
026057     IF  L1640-NOT-VALID
026057*MSG:    'DATE @1 INVALID'
026057         MOVE 'CS78190002'      TO WGLOB-MSG-REF-INFO
026057         MOVE MIR-DV-FIN-TRXN-EFF-DT TO WGLOB-MSG-PARM (1)
026057         PERFORM  0260-1000-GENERATE-MESSAGE
026057             THRU 0260-1000-GENERATE-MESSAGE-X
026057         SET MIR-RETRN-RQST-FAILED  TO TRUE
026057         GO TO 2000-RETRIEVE-X
026057     END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE L1640-INTERNAL-DATE      TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF  WIHSD-CHK-EFF-DT-NOT-OK
026057         SET MIR-RETRN-RQST-FAILED  TO TRUE
026057         GO TO 2000-RETRIEVE-X
026057     END-IF.

           MOVE L1640-INTERNAL-DATE       TO WS-SAVE-EFF-DT.
           MOVE L1640-INTERNAL-DATE       TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE       TO WS-SAVE-EFF-IDT-NUM.

           MOVE 1                         TO WS-SUB.

           EVALUATE TRUE

               WHEN WS-SAVE-SEQ-NUM = ZERO
                   PERFORM  3000-MTH-DED
                       THRU 3000-MTH-DED-X

               WHEN OTHER
                   PERFORM  4000-ADM-DED
                       THRU 4000-ADM-DED-X

           END-EVALUATE.


       2000-RETRIEVE-X.
           EXIT.


      *--------------------
       2010-INS-TYPE-CHECK.
      *--------------------

           IF WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-SUB)
           OR WCVGS-CVG-INS-TYP-SEG-FUND    (WS-SUB)
           OR WCVGS-CVG-INS-TYP-FPA         (WS-SUB)
               SET WS-WEALTH-ACCUM-YES TO TRUE
           END-IF.

       2010-INS-TYPE-CHECK-X.
           EXIT.


      *-------------
       3000-MTH-DED.
      *-------------

           MOVE RPOL-POL-ID             TO WUH-POL-ID.
           MOVE WS-SAVE-EFF-DT          TO WUH-MTHV-EFF-DT-NUM.
           MOVE ZERO                    TO WUH-MTHV-EFF-DT-NUM-DY.

           PERFORM  UH-1000-READ
               THRU UH-1000-READ-X.

           IF NOT WUH-IO-OK
              GO TO 3000-MTH-DED-X
           END-IF.


           MOVE RUH-KEY                 TO WUHCO-KEY.
           MOVE WUHCO-KEY               TO WUHCO-ENDBR-KEY.
           MOVE LOW-VALUE               TO WUHCO-CVG-NUM.
           MOVE HIGH-VALUE              TO WUHCO-ENDBR-CVG-NUM.

           PERFORM  UHCO-1000-BROWSE
               THRU UHCO-1000-BROWSE-X.

           PERFORM  UHCO-2000-READ-NEXT
               THRU UHCO-2000-READ-NEXT-X.

           IF WUHCO-IO-EOF
              PERFORM  UHCO-3000-END-BROWSE
                  THRU UHCO-3000-END-BROWSE-X
              GO TO 3000-MTH-DED-X
           END-IF.

           PERFORM  3100-UHCO-LOOP
               THRU 3100-UHCO-LOOP-X
              UNTIL WUHCO-IO-EOF.

           PERFORM  UHCO-3000-END-BROWSE
               THRU UHCO-3000-END-BROWSE-X.

       3000-MTH-DED-X.
           EXIT.

      *---------------
       3100-UHCO-LOOP.
      *---------------

           MOVE RUHCO-CVG-NUM           TO WS-CVG.

           EVALUATE TRUE

               WHEN WCVGS-CVG-INS-TYP-SEG-FUND (WS-CVG)
                   PERFORM  3200-MTH-DED-FA
                       THRU 3200-MTH-DED-FA-X

               WHEN WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-CVG)
               WHEN WCVGS-CVG-INS-TYP-FPA         (WS-CVG)
                   PERFORM  3300-MTH-DED-CFLW
                       THRU 3300-MTH-DED-CFLW-X

           END-EVALUATE.

           PERFORM  UHCO-2000-READ-NEXT
               THRU UHCO-2000-READ-NEXT-X.

       3100-UHCO-LOOP-X.
           EXIT.


      *---------------
       3200-MTH-DED-FA.
      *---------------

           MOVE RPOL-POL-ID              TO WFA-POL-ID.
           MOVE RUHCO-CVG-NUM            TO WFA-CVG-NUM.
           MOVE WS-SAVE-EFF-IDT-NUM      TO WFA-CIA-IDT-NUM.
           MOVE WFA-KEY                  TO WFA-ENDBR-KEY.
           MOVE +000                     TO WFA-CIA-SEQ-NUM.
           MOVE +999                     TO WFA-ENDBR-CIA-SEQ-NUM.

           PERFORM  FA-1000-BROWSE
               THRU FA-1000-BROWSE-X.

           PERFORM  FA-2000-READ-NEXT
               THRU FA-2000-READ-NEXT-X.

           IF WFA-IO-EOF
              PERFORM  FA-3000-END-BROWSE
                  THRU FA-3000-END-BROWSE-X
              GO TO 3200-MTH-DED-FA-X
           END-IF.

           SET WS-ADM-REC-FOUND-NO       TO TRUE
           PERFORM  3210-MTH-DED-FA-LOOP
               THRU 3210-MTH-DED-FA-LOOP-X
              UNTIL WFA-IO-EOF
                 OR WS-ADM-REC-FOUND-YES.

           PERFORM  FA-3000-END-BROWSE
               THRU FA-3000-END-BROWSE-X.

           IF WS-ADM-REC-FOUND-NO
              GO TO 3200-MTH-DED-FA-X
           END-IF.


           MOVE RFA-POL-ID             TO WFD-POL-ID.
           MOVE RFA-CVG-NUM            TO WFD-CVG-NUM.
           MOVE RFA-FRST-FIA-FND-ID    TO WFD-FND-ID.
           MOVE RFA-CIA-IDT-NUM        TO WFD-FIA-IDT-NUM.
           MOVE RFA-CIA-SEQ-NUM        TO WFD-FIA-SEQ-NUM.

           PERFORM  5110-READ-FD
               THRU 5110-READ-FD-X
               UNTIL WFD-FND-ID = SPACE.

       3200-MTH-DED-FA-X.
           EXIT.


      *--------------------
       3210-MTH-DED-FA-LOOP.
      *--------------------

           IF  RFA-CIA-TYP-ADMIN
           AND RFA-CIA-REASN-MORT-CHRG
               SET WS-ADM-REC-FOUND-YES  TO TRUE
               GO TO 3210-MTH-DED-FA-LOOP-X
           END-IF.

           PERFORM  FA-2000-READ-NEXT
               THRU FA-2000-READ-NEXT-X.

       3210-MTH-DED-FA-LOOP-X.
           EXIT.


      *------------------
       3300-MTH-DED-CFLW.
      *------------------

           MOVE RPOL-POL-ID                  TO WCFLW-POL-ID.
           MOVE RUHCO-CVG-NUM                TO WCFLW-CVG-NUM.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG) TO WCFLW-CF-TYP-CD.
           MOVE WS-SAVE-EFF-DT               TO WCFLW-CF-EFF-DT.
           MOVE WCFLW-KEY                    TO WCFLW-ENDBR-KEY.
           MOVE +000                         TO WCFLW-CF-SEQ-NUM.
           MOVE +999                         TO WCFLW-ENDBR-CF-SEQ-NUM.

           PERFORM  CFLW-1000-BROWSE
               THRU CFLW-1000-BROWSE-X.

           PERFORM  CFLW-2000-READ-NEXT
               THRU CFLW-2000-READ-NEXT-X.

           IF WCFLW-IO-EOF
              PERFORM  CFLW-3000-END-BROWSE
                  THRU CFLW-3000-END-BROWSE-X
              GO TO 3300-MTH-DED-CFLW-X
           END-IF.

           SET WS-ADM-REC-FOUND-NO       TO TRUE
           PERFORM  3310-MTH-DED-CFLW-LOOP
               THRU 3310-MTH-DED-CFLW-LOOP-X
              UNTIL WCFLW-IO-EOF
                 OR WS-ADM-REC-FOUND-YES.

           PERFORM  CFLW-3000-END-BROWSE
               THRU CFLW-3000-END-BROWSE-X.

           IF WS-ADM-REC-FOUND-NO
              GO TO 3300-MTH-DED-CFLW-X
           END-IF.

           PERFORM  5210-CFLW-TO-MIR
               THRU 5210-CFLW-TO-MIR-X.

       3300-MTH-DED-CFLW-X.
           EXIT.


      *----------------------
       3310-MTH-DED-CFLW-LOOP.
      *----------------------

           IF (RCFLW-CF-TRXN-ADMIN-FEE
           OR  RCFLW-CF-TRXN-ADMIN-FEE-REVRS)
           AND RCFLW-CF-REASN-MORTALITY
               SET WS-ADM-REC-FOUND-YES   TO TRUE
               GO TO 3310-MTH-DED-CFLW-LOOP-X
           END-IF.

           PERFORM  CFLW-2000-READ-NEXT
               THRU CFLW-2000-READ-NEXT-X.

       3310-MTH-DED-CFLW-LOOP-X.
           EXIT.


      *-------------
       4000-ADM-DED.
      *-------------

           MOVE RPOL-POL-ID               TO WPHST-POL-ID.
           MOVE WS-SAVE-EFF-IDT-NUM       TO WPHST-PCHST-EFF-IDT-NUM.
           MOVE WS-SAVE-SEQ-NUM           TO WPHST-PCHST-SEQ-NUM.

           PERFORM  PHST-1000-READ
               THRU PHST-1000-READ-X.

           IF NOT WPHST-IO-OK
               GO TO 4000-ADM-DED-X
           END-IF.

           MOVE RPHST-POL-ACTV-TYP-ID TO WS-ACTIVITY-TYPE-ID.
           IF  NOT WS-ACTIVITY-TYPE-ADMIN-FEES
               GO TO 4000-ADM-DED-X
           END-IF.

           IF RPHST-PCHST-STAT-CD NOT = MIR-DV-FIN-TRXN-STAT-CD
               GO TO 4000-ADM-DED-X
           END-IF.

           PERFORM  4200-PROCESS-ADM-FEE
               THRU 4200-PROCESS-ADM-FEE-X.

       4000-ADM-DED-X.
           EXIT.


      *---------------------
       4200-PROCESS-ADM-FEE.
      *---------------------

           MOVE RPHST-CVG-NUM             TO WS-CVG.

           EVALUATE TRUE

               WHEN WCVGS-CVG-INS-TYP-SEG-FUND (WS-CVG)
                   PERFORM  4300-ADM-FEE-FA
                       THRU 4300-ADM-FEE-FA-X

               WHEN WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-CVG)
               WHEN WCVGS-CVG-INS-TYP-FPA         (WS-CVG)
                   PERFORM  4400-ADM-FEE-CFLW
                       THRU 4400-ADM-FEE-CFLW-X

           END-EVALUATE.

       4200-PROCESS-ADM-FEE-X.
           EXIT.


      *---------------
       4300-ADM-FEE-FA.
      *---------------

           MOVE RPHST-POL-ID             TO WFA-POL-ID.
           MOVE RPHST-CVG-NUM            TO WFA-CVG-NUM.
           MOVE RPHST-PCHST-EFF-IDT-NUM  TO WFA-CIA-IDT-NUM.

           IF  RPHST-PCHST-STAT-REVERSED
           AND WS-ACTIVITY-TYPE-REVRS
               MOVE RPHST-PCHST-OLD-VALU-TXT
                                         TO WS-SEQ
           ELSE
               MOVE RPHST-PCHST-NEW-VALU-TXT
                                         TO WS-SEQ
           END-IF.

           COMPUTE WS-FA-SEQ-NUM = 1000 - WS-SEQ-NUM.
           MOVE WS-FA-SEQ-NUM            TO WFA-CIA-SEQ-NUM.

           PERFORM  FA-1000-READ
               THRU FA-1000-READ-X.

           IF NOT WFA-IO-OK
               GO TO 4300-ADM-FEE-FA-X
           END-IF.

           IF  RFA-CIA-TYP-ADMIN
           AND NOT RFA-CIA-REASN-MORT-CHRG
               CONTINUE
           ELSE
               GO TO 4300-ADM-FEE-FA-X
           END-IF.

           MOVE RFA-POL-ID             TO WFD-POL-ID.
           MOVE RFA-CVG-NUM            TO WFD-CVG-NUM.
           MOVE RFA-FRST-FIA-FND-ID    TO WFD-FND-ID.
           MOVE RFA-CIA-IDT-NUM        TO WFD-FIA-IDT-NUM.
           MOVE RFA-CIA-SEQ-NUM        TO WFD-FIA-SEQ-NUM.

           PERFORM  5110-READ-FD
               THRU 5110-READ-FD-X
               UNTIL WFD-FND-ID = SPACE.

       4300-ADM-FEE-FA-X.
           EXIT.

      *-----------------
       4400-ADM-FEE-CFLW.
      *-----------------

           MOVE RPHST-POL-ID                 TO WCFLW-POL-ID.
           MOVE RPHST-CVG-NUM                TO WCFLW-CVG-NUM.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG) TO WCFLW-CF-TYP-CD.
           MOVE RPHST-PCHST-EFF-DT           TO WCFLW-CF-EFF-DT.

           IF  RPHST-PCHST-STAT-REVERSED
           AND WS-ACTIVITY-TYPE-REVRS
               MOVE RPHST-PCHST-OLD-VALU-TXT
                                         TO WS-SEQ
           ELSE
               MOVE RPHST-PCHST-NEW-VALU-TXT
                                         TO WS-SEQ
           END-IF.

           MOVE WS-SEQ-NUM                   TO WCFLW-CF-SEQ-NUM-N.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

           IF NOT WCFLW-IO-OK
               GO TO 4400-ADM-FEE-CFLW-X
           END-IF.

           IF (RCFLW-CF-TRXN-ADMIN-FEE
           OR  RCFLW-CF-TRXN-ADMIN-FEE-REVRS)
           AND NOT RCFLW-CF-REASN-MORTALITY
               CONTINUE
           ELSE
               GO TO 4400-ADM-FEE-CFLW-X
           END-IF.

           PERFORM  5210-CFLW-TO-MIR
               THRU 5210-CFLW-TO-MIR-X.

       4400-ADM-FEE-CFLW-X.
           EXIT.


      *-------------
       5110-READ-FD.
      *-------------

           PERFORM  FD-1000-READ
               THRU FD-1000-READ-X.

           IF NOT WFD-IO-OK
              MOVE SPACES             TO WFD-FND-ID
              GO TO 5110-READ-FD-X
           END-IF.

021239     PERFORM  7791-0000-INIT-PARM-INFO
021239         THRU 7791-0000-INIT-PARM-INFO-X.
021239
021239     MOVE RFD-KEY                TO RFDUT-KEY.
021239
021239     PERFORM  7791-1000-RETRIEVE-UNITS
021239         THRU 7791-1000-RETRIEVE-UNITS-X.
021239
021239     IF  NOT L7791-RETRN-OK
021239         MOVE SPACES            TO WFD-FND-ID
021239         GO TO 5110-READ-FD-X
021239     END-IF.
021239
           PERFORM  5120-FD-TO-MIR
               THRU 5120-FD-TO-MIR-X.

           MOVE RFD-NXT-FIA-FND-ID    TO WFD-FND-ID.

       5110-READ-FD-X.
           EXIT.


      *---------------
       5120-FD-TO-MIR.
      *---------------

           IF WS-SUB > WS-MAX-LINE
              GO TO 5120-FD-TO-MIR-X
           END-IF.


020874*    COMPUTE L0290-INPUT-NUMBER = RFD-FIA-FND-TRXN-AMT * 100.
020874     MOVE RFD-FIA-FND-TRXN-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-FIN-TRXN-GRS-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
                                TO MIR-DV-FIN-TRXN-GRS-AMT-T (WS-SUB).

020469     MOVE RFD-FIA-ORIG-TRXN-AMT    TO L0290-INPUT-V02.
020469     MOVE 2                        TO L0290-PRECISION.
020469     MOVE LENGTH OF MIR-DV-FIA-POL-CRCY-AMT-T (WS-SUB)
020469                                   TO L0290-MAX-OUT-LEN.
020469     SET L0290-SIGN-DISPLAY        TO TRUE.
020469     PERFORM 0290-2000-FORMAT-FOR-MIR
020469        THRU 0290-2000-FORMAT-FOR-MIR-X.
020469     MOVE L0290-OUTPUT-DATA
020469                          TO MIR-DV-FIA-POL-CRCY-AMT-T (WS-SUB).

           MOVE RFD-FND-ID               TO WEDIT-ETBL-VALU-ID.
           PERFORM  SGFD-2000-DESC
               THRU SGFD-2000-DESC-X.
           MOVE REDIT-ETBL-DESC-TXT  TO MIR-DV-FND-DESC-TXT-T (WS-SUB).

021239*
021239*    COMPUTE WS-INIT-WORK =
021239*                RFD-FIA-INTG-IUNIT-QTY + RFD-FIA-DCML-IUNIT-QTY.
021239*    COMPUTE WS-ACUM-WORK =
021239*                RFD-FIA-INTG-AUNIT-QTY + RFD-FIA-DCML-AUNIT-QTY.
021239*    IF WS-ACUM-WORK NOT = ZERO
021239*        MOVE WS-ACUM-WORK          TO WS-UNIT-QTY
021239*    ELSE
021239*        MOVE WS-INIT-WORK          TO WS-UNIT-QTY
021239*    END-IF.
021239*
021239*
020874*    COMPUTE L0290-INPUT-NUMBER = WS-UNIT-QTY * 1000000000.
021239*    MOVE WS-UNIT-QTY               TO L0290-INPUT-V09.
021239*    MOVE 9                         TO L0290-PRECISION.
021239     MOVE RFDUT-FIA-UNIT-QTY        TO L0290-INPUT-V06.
021239     MOVE +6                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-FIN-TRXN-UNIT-QTY-T (WS-SUB)
                                          TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS  TO TRUE.
           SET L0290-SIGN-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
                               TO MIR-DV-FIN-TRXN-UNIT-QTY-T (WS-SUB).

021239*
021239*    IF RFD-FIA-AUNIT-PRIC-AMT NOT = ZERO
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                           = RFD-FIA-AUNIT-PRIC-AMT * 1000000000
021239*        MOVE RFD-FIA-AUNIT-PRIC-AMT  TO L0290-INPUT-V09
021239*    ELSE
020874*        COMPUTE L0290-INPUT-NUMBER
020874*                           = RFD-FIA-IUNIT-PRIC-AMT * 1000000000
021239*        MOVE RFD-FIA-IUNIT-PRIC-AMT   TO L0290-INPUT-V09
021239*    END-IF.
021239*
021239     MOVE RFDUT-FIA-UNIT-PRIC-AMT  TO L0290-INPUT-V09.
           MOVE 9                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-UNIT-PRC-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
                               TO MIR-DV-UNIT-PRC-AMT-T (WS-SUB).

020469     MOVE RPOL-POL-CRCY-CD         TO MIR-CIA-CRCY-CD-T (WS-SUB).
020469
020469     PERFORM  8640-1000-BUILD-PARM-INFO
020469         THRU 8640-1000-BUILD-PARM-INFO-X.
020469
020469     MOVE RFD-FND-ID               TO L8640-FND-ID.
020469
020469     PERFORM  8640-1000-GET-FND-CRCY-CD
020469         THRU 8640-1000-GET-FND-CRCY-CD-X.
020469
020469     IF  L8640-RETRN-OK
020469         MOVE L8640-FND-CRCY-CD    TO MIR-FIA-CRCY-CD-T (WS-SUB)
020469     ELSE
020469         MOVE SPACES               TO MIR-FIA-CRCY-CD-T (WS-SUB)
020469     END-IF.

           ADD +1                            TO WS-SUB.

       5120-FD-TO-MIR-X.
           EXIT.


      *-----------------
       5210-CFLW-TO-MIR.
      *-----------------

           IF WS-SUB > WS-MAX-LINE
              GO TO 5210-CFLW-TO-MIR-X
           END-IF.

           MOVE RCFLW-CF-CLI-TRXN-AMT    TO WS-CLI-TRXN-AMT.
           IF RCFLW-CF-REVRS-PRCES-DT NOT = WWKDT-ZERO-DT
              COMPUTE WS-CLI-TRXN-AMT = -1 * WS-CLI-TRXN-AMT
           END-IF.

020874*    COMPUTE L0290-INPUT-NUMBER = WS-CLI-TRXN-AMT * 100.
020874     MOVE WS-CLI-TRXN-AMT          TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-FIN-TRXN-GRS-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
                                TO MIR-DV-FIN-TRXN-GRS-AMT-T (WS-SUB).

020469     MOVE WS-CLI-TRXN-AMT          TO L0290-INPUT-V02.
020469     MOVE 2                        TO L0290-PRECISION.
020469     MOVE LENGTH OF MIR-DV-FIA-POL-CRCY-AMT-T (WS-SUB)
020469                                   TO L0290-MAX-OUT-LEN.
020469     SET L0290-SIGN-DISPLAY        TO TRUE.
020469     PERFORM 0290-2000-FORMAT-FOR-MIR
020469        THRU 0290-2000-FORMAT-FOR-MIR-X.
020469     MOVE L0290-OUTPUT-DATA
020469                          TO MIR-DV-FIA-POL-CRCY-AMT-T (WS-SUB).

           MOVE WCVGS-PLAN-ID (WS-CVG)   TO WEDIT-ETBL-VALU-ID.
           PERFORM PLAN-2000-DESC
              THRU PLAN-2000-DESC-X.
           MOVE REDIT-ETBL-DESC-TXT  TO MIR-DV-FND-DESC-TXT-T (WS-SUB).

020469     MOVE RPOL-POL-CRCY-CD         TO MIR-CIA-CRCY-CD-T (WS-SUB).
020469     MOVE RPOL-POL-CRCY-CD         TO MIR-FIA-CRCY-CD-T (WS-SUB).

           ADD +1                        TO WS-SUB.

       5210-CFLW-TO-MIR-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY   TO TRUE.
           MOVE MIR-POL-ID         TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  7791-0000-INIT-PARM-INFO
025970         THRU 7791-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8640-0000-INIT-PARM-INFO
025970         THRU 8640-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORK-AREA.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

025970     MOVE SPACES               TO WWKDT-WORK-FIELDS.

025970     MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.
025970     MOVE SPACES               TO MIR-OUTPUT-AREA.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

026057 COPY CCPPIHSD.
       COPY NCPPCVGS.
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPEPLAN.
       COPY CCPESGFD.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
025970 COPY XCPS1670.
025970 COPY XCPS8090.
021239 COPY SCPS7791.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
021239 COPY SCPL7791.
021239
       COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL0290.
       COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
       COPY XCPL8090.
      /
020469 COPY XCPS8640.
020469 COPY XCPL8640.
020469/
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCVG.
       COPY CCPNPOL.
       COPY CCPUPOL.
       COPY CCPNEDIT.
       COPY SCPBFA.
       COPY SCPNFA.
       COPY SCPNFD.
       COPY CCPBCFLW.
       COPY CCPNCFLW.
       COPY CCPNUH.
       COPY CCPBUHCO.
       COPY CCPNPHST.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM CSOM7819                        **
      *****************************************************************
