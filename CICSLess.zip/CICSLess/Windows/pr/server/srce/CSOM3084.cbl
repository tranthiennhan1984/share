      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3084.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3084                                         **
      **  REMARKS:  PLAR - PLAN ALLOCATION RULE TABLE LIST           **
      **            THIS MODULE LISTS ALL ENTRIES IN THE PLAR TABLE  **
      **            FOR A SPECIFIED PLAN                             **
      **                                                             **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
015290**  6.3       PRE & POST TEFRA PROCESSING ENHANCEMENTS         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3084'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

025970 01  WS-CONSTANT-AREA.
025970     05  WS-MAX-BROWSE-CTR            PIC S9(4)  VALUE +100.
025970         88  WS-MAX-BROWSE-CTR-DEFAULT           VALUE +100.
025970
       01  WS-PGM-WORK-AREA.
025970*    05  WS-SUB                       PIC S9(4)  COMP.
025970     05  WS-SUB                       PIC S9(4)  BINARY.
025970*    05  WS-MAX-BROWSE-CTR            PIC S9(4)  VALUE +100.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-LIST          VALUE '3084'.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFWPLAR.
       COPY CCFRPLAR.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
021930*COPY XCWLDTLK.
       COPY XCWL0290.
       COPY XCWEBLCH.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3084.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

025970*    SET  MIR-RETRN-OK            TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  3500-PROCESS-LIST
                        THRU 3500-PROCESS-LIST-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM3084'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------------
       3500-PROCESS-LIST.
      *------------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           IF  MIR-PLAN-ID = SPACES
           OR  MIR-PLAN-ID = EBLCH-BLANK-FIELD-CHAR
      *MSG:    PLAN ID IS REQUIRED
               MOVE 'CS30840001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM  3510-BROWSE-NORMAL
               THRU 3510-BROWSE-NORMAL-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *-------------------
       3510-BROWSE-NORMAL.
      *-------------------

           MOVE LOW-VALUES              TO WPLAR-KEY.
           MOVE HIGH-VALUES             TO WPLAR-ENDBR-KEY.

           MOVE MIR-PLAN-ID             TO WPLAR-PLAN-ID.
           MOVE MIR-PLAR-ALLOC-TYP-CD
                                        TO WPLAR-PLAR-ALLOC-TYP-CD.

           MOVE WPLAR-PLAN-ID           TO WPLAR-ENDBR-PLAN-ID.

           PERFORM  PLAR-1000-BROWSE
               THRU PLAR-1000-BROWSE-X.

           PERFORM  PLAR-2000-READ-NEXT
               THRU PLAR-2000-READ-NEXT-X.

           PERFORM  3600-DISPLAY-RECORD
               THRU 3600-DISPLAY-RECORD-X
               VARYING WS-SUB FROM 1 BY 1
                 UNTIL WS-SUB > WS-MAX-BROWSE-CTR
                 OR    NOT WPLAR-IO-OK.

           IF  NOT WPLAR-IO-EOF
      *MSG: TO VIEW MORE DATA SELECT MORE
               MOVE 'CS30840002'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RPLAR-PLAN-ID       TO MIR-PLAN-ID
               MOVE RPLAR-PLAR-ALLOC-TYP-CD
                                        TO MIR-PLAR-ALLOC-TYP-CD
               SET WGLOB-MORE-DATA-EXISTS
                                        TO TRUE
           ELSE
               IF  MIR-PLAR-ALLOC-TYP-CD-T (1) > SPACES
                   MOVE MIR-PLAR-ALLOC-TYP-CD-T (1)
                                        TO MIR-PLAR-ALLOC-TYP-CD
      *MSG: END OF FILE REACHED
                   MOVE 'CS30840003'    TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      *MSG: NO RECORD FOUND FOR DISPLAY
                   MOVE 'XS00000034'    TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           PERFORM  PLAR-3000-END-BROWSE
               THRU PLAR-3000-END-BROWSE-X.

       3510-BROWSE-NORMAL-X.
           EXIT.
      /
      *--------------------
       3600-DISPLAY-RECORD.
      *--------------------

           MOVE RPLAR-PLAR-ALLOC-TYP-CD
                              TO MIR-PLAR-ALLOC-TYP-CD-T  (WS-SUB).
           MOVE RPLAR-PLAR-DPOS-DFLT-IND
                              TO MIR-PLAR-DPOS-DFLT-IND-T (WS-SUB).
           MOVE RPLAR-PLAR-WTHDR-ORDR-CD
                              TO MIR-PLAR-WTHDR-ORDR-CD-T (WS-SUB).
           MOVE RPLAR-PLAR-XFER-ONLY-IND
                              TO MIR-PLAR-XFER-ONLY-IND-T  (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RPLAR-PLAR-WTHDR-SEQ-NUM.
020874     MOVE RPLAR-PLAR-WTHDR-SEQ-NUM   TO L0290-INPUT-V00.
           MOVE 0                          TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PLAR-WTHDR-SEQ-NUM-T (WS-SUB)
                                           TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA          TO MIR-PLAR-WTHDR-SEQ-NUM-T
                                              (WS-SUB).

           PERFORM PLAR-2000-READ-NEXT
              THRU PLAR-2000-READ-NEXT-X.

       3600-DISPLAY-RECORD-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACE                   TO MIR-PLAR-ALLOC-TYP-CD-G.
           MOVE SPACE                   TO MIR-PLAR-DPOS-DFLT-IND-G.
           MOVE SPACE                   TO MIR-PLAR-WTHDR-ORDR-CD-G.
           MOVE SPACE                   TO MIR-PLAR-XFER-ONLY-IND-G.
           MOVE ZEROS                   TO MIR-PLAR-WTHDR-SEQ-NUM-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  WS-PGM-WORK-AREA.
025970     SET  WS-MAX-BROWSE-CTR-DEFAULT TO TRUE.
025970     SET  MIR-RETRN-OK          TO  TRUE.
025970     MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
       COPY XCPL0260.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBPLAR.
021930*COPY CCPNPLAR.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM3084                     *
      ****************************************************************
