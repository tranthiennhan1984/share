      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM8945.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM8945                                         **
      **  REMARKS:  FBND - FUND BONUS DECLARATION LIST - DATE        **
      **            THIS MODULE LISTS ALL ENTRIES IN THE FBND TABLE  **
      **            FOR A SPECIFIED DECLARATION DATE                 **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
016016**  6.3       FUND BONUS (6.1.1E)                              **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019056**  6.3       REMOVE FND-BON-TYP-CD                            **
020462**  6.4       ISO DATE STANDARDIZATION                         **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM8945'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-PGM-WORK-AREA.
025970*    05  WS-SUB                       PIC S9(4)  COMP.
025970*    05  WS-MAX-BROWSE-CTR            PIC S9(4)  COMP.
025970     05  WS-SUB                       PIC S9(4)  BINARY.
025970     05  WS-MAX-BROWSE-CTR            PIC S9(4)  BINARY.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-LIST-DATE     VALUE '8945'.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
018764*COPY XCWLPTR.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
018763*COPY SCFWFHBN.
018763*COPY SCFRFHBN.
021930*COPY SCFWFBND.
018763 COPY SCFRFBND.
      /
018763*COPY SCFWFHBS.
018763 COPY SCFWFBNE.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
       COPY XCWLDTLK.
021930*COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
       COPY XCWEBLCH.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM8945.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

021930*    PERFORM  0290-1000-BUILD-PARM-INFO
021930*        THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           SET  MIR-RETRN-OK            TO TRUE.
           MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST-DATE
                    PERFORM 3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'SSOM8945'     TO WGLOB-MSG-PARM (2)
018763*             MOVE 'XS00000000'   TO WGLOB-MSG-REF-INFO
018763              MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------------
       3500-PROCESS-LIST.
      *------------------

           COMPUTE WS-MAX-BROWSE-CTR = LENGTH OF MIR-SBSDRY-CO-ID-G
                                     / LENGTH OF MIR-SBSDRY-CO-ID-T (1).

      ****************************************************************
      * EACH RECORD OF THE BROWSE SCREEN.  THIS WILL ALLOW
      * USERS TO CHOSE A RECORD(S) TO PERFORM INQUIRE,
      * MAINTAIN OR DELETE PROCESSING FOR THE FUND RECORD
      * SELECTED.
      *
      *  CHECK ENTER CODE FIELDS FOR INPUT
      ****************************************************************

           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM 3520-BROWSE-INVERTED
              THRU 3520-BROWSE-INVERTED-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *---------------------
       3520-BROWSE-INVERTED.
      *---------------------

018763*    MOVE LOW-VALUES              TO WFHBS-KEY.
018763*    MOVE HIGH-VALUES             TO WFHBS-ENDBR-KEY.
018763     MOVE LOW-VALUES              TO WFBNE-KEY.
018763     MOVE HIGH-VALUES             TO WFBNE-ENDBR-KEY.

           IF  MIR-SBSDRY-CO-ID = SPACES
           OR  MIR-SBSDRY-CO-ID = EBLCH-BLANK-FIELD-CHAR
      * MSG: SUB COMPANY REQUIRED FOR BROWSE BY DECLARATION DATE
               MOVE 'SS89450001'        TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR   TO TRUE
           END-IF.

           IF  MIR-FND-BON-IDT-NUM = SPACES
           OR  MIR-FND-BON-IDT-NUM = EBLCH-BLANK-FIELD-CHAR
      * MSG: DECLARATION DATE REQUIRED FOR BROWSE BY DECLARATION DATE
               MOVE 'SS89450002'        TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR   TO TRUE
           END-IF.


           IF  WGLOB-RETURN-ERROR
               GO TO 3520-BROWSE-INVERTED-X
           END-IF.

           IF  MIR-FND-ID > SPACES
018763*        MOVE MIR-FND-ID          TO WFHBS-FND-ID
018763         MOVE MIR-FND-ID          TO WFBNE-FND-ID
           END-IF.

018763*    MOVE MIR-SBSDRY-CO-ID        TO WFHBS-SBSDRY-CO-ID.
018763     MOVE MIR-SBSDRY-CO-ID        TO WFBNE-SBSDRY-CO-ID.

           MOVE MIR-FND-BON-IDT-NUM     TO L1640-EXTERNAL-DATE.

           PERFORM 3540-EXTERNAL-TO-INVERTED
              THRU 3540-EXTERNAL-TO-INVERTED-X.

018763*    MOVE L1660-INVERTED-DATE     TO WFHBS-FND-BON-IDT-NUM.
018763     MOVE L1660-INVERTED-DATE     TO WFBNE-FND-BON-IDT-NUM.

           IF  WGLOB-RETURN-ERROR
               GO TO 3520-BROWSE-INVERTED-X
           END-IF.

018763*    MOVE WFHBS-KEY               TO WFHBS-ENDBR-KEY.
018763*    MOVE HIGH-VALUES             TO WFHBS-ENDBR-FND-BON-IDT-NUM.
018763     MOVE WFBNE-KEY               TO WFBNE-ENDBR-KEY.
018763     MOVE HIGH-VALUES             TO WFBNE-ENDBR-FND-BON-IDT-NUM.

018763*    PERFORM FHBS-1000-BROWSE
018763*       THRU FHBS-1000-BROWSE-X.
018763     PERFORM FBNE-1000-BROWSE
018763        THRU FBNE-1000-BROWSE-X.

018763*    PERFORM FHBS-2000-READ-NEXT
018763*       THRU FHBS-2000-READ-NEXT-X.
018763     PERFORM FBNE-2000-READ-NEXT
018763        THRU FBNE-2000-READ-NEXT-X.

           PERFORM 3600-DISPLAY-RECORD
              THRU 3600-DISPLAY-RECORD-X
              VARYING WS-SUB FROM 1 BY 1
                UNTIL WS-SUB > WS-MAX-BROWSE-CTR
018763*            OR WFHBS-IO-EOF.
018763             OR WFBNE-IO-EOF.

018763*    IF  NOT WFHBS-IO-EOF
018763     IF  NOT WFBNE-IO-EOF
      *MSG: TO VIEW MORE DATA PRESS ENTER
               MOVE 'SS89450003'        TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
018763*        MOVE RFHBN-FND-ID        TO MIR-FND-ID
018763*        MOVE RFHBN-SBSDRY-CO-ID  TO MIR-SBSDRY-CO-ID
018763*        MOVE RFHBN-FND-BON-IDT-NUM
018763         MOVE RFBND-FND-ID        TO MIR-FND-ID
018763         MOVE RFBND-SBSDRY-CO-ID  TO MIR-SBSDRY-CO-ID
018763         MOVE RFBND-FND-BON-IDT-NUM
                                        TO L1660-INVERTED-DATE
               PERFORM 3610-INVERTED-TO-EXTERNAL
                  THRU 3610-INVERTED-TO-EXTERNAL-X
               MOVE L1640-EXTERNAL-DATE
                                        TO MIR-FND-BON-IDT-NUM
019056*        MOVE RFHBN-FND-BON-TYP-CD
019056*                                 TO MIR-FND-BON-TYP-CD
               SET WGLOB-MORE-DATA-EXISTS
                                        TO TRUE
           ELSE
               IF  MIR-FND-ID-T (1) > SPACES
                   MOVE MIR-FND-ID-T (1)
                                        TO MIR-FND-ID
                   MOVE MIR-SBSDRY-CO-ID-T (1)
                                        TO MIR-SBSDRY-CO-ID
                   MOVE MIR-FND-BON-IDT-NUM-T  (1)
                                        TO MIR-FND-BON-IDT-NUM
019056*            MOVE MIR-FND-BON-TYP-CD-T  (1)
019056*                                 TO MIR-FND-BON-TYP-CD
      *MSG: END OF FILE REACHED
                   MOVE 'SS89450004'    TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      *MSG: NO RECORD FOUND FOR DISPLAY
                   MOVE 'XS00000034'    TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

018763*    PERFORM FHBS-3000-END-BROWSE
018763*       THRU FHBS-3000-END-BROWSE-X.
018763     PERFORM FBNE-3000-END-BROWSE
018763        THRU FBNE-3000-END-BROWSE-X.

       3520-BROWSE-INVERTED-X.
           EXIT.
      /
      *--------------------------
       3540-EXTERNAL-TO-INVERTED.
      *--------------------------

020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE TO L1660-INTERNAL-DATE
               PERFORM 1660-2000-CONVERT-INT-TO-INV
                  THRU 1660-2000-CONVERT-INT-TO-INV-X
           ELSE
      *MSG:  ERROR CONVERTING INTERNAL DATE
               MOVE 'SS89450005'        TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR   TO TRUE
           END-IF.

       3540-EXTERNAL-TO-INVERTED-X.
           EXIT.
      /
      *--------------------
       3600-DISPLAY-RECORD.
      *--------------------

018763*    IF  RFHBN-SBSDRY-CO-ID NOT = MIR-SBSDRY-CO-ID
018763     IF  RFBND-SBSDRY-CO-ID NOT = MIR-SBSDRY-CO-ID
               SUBTRACT +1 FROM WS-SUB
           ELSE
018763*     MOVE RFHBN-FND-ID            TO MIR-FND-ID-T (WS-SUB)
018763*     MOVE RFHBN-SBSDRY-CO-ID      TO MIR-SBSDRY-CO-ID-T (WS-SUB)
018763*     MOVE RFHBN-FND-BON-IDT-NUM   TO L1660-INVERTED-DATE
018763      MOVE RFBND-FND-ID            TO MIR-FND-ID-T (WS-SUB)
018763      MOVE RFBND-SBSDRY-CO-ID      TO MIR-SBSDRY-CO-ID-T (WS-SUB)
018763      MOVE RFBND-FND-BON-IDT-NUM   TO L1660-INVERTED-DATE
            PERFORM 3610-INVERTED-TO-EXTERNAL
               THRU 3610-INVERTED-TO-EXTERNAL-X
            MOVE L1640-EXTERNAL-DATE  TO MIR-FND-BON-IDT-NUM-T (WS-SUB)
019056*     MOVE RFHBN-FND-BON-TYP-CD TO MIR-FND-BON-TYP-CD-T (WS-SUB)
           END-IF.

018763*    PERFORM FHBS-2000-READ-NEXT
018763*       THRU FHBS-2000-READ-NEXT-X.
018763     PERFORM FBNE-2000-READ-NEXT
018763        THRU FBNE-2000-READ-NEXT-X.

       3600-DISPLAY-RECORD-X.
           EXIT.
      /
      *--------------------------
       3610-INVERTED-TO-EXTERNAL.
      *--------------------------

           PERFORM 1660-3000-CONVERT-INV-TO-INT
              THRU 1660-3000-CONVERT-INV-TO-INT-X.

           MOVE L1660-INTERNAL-DATE     TO L1640-INTERNAL-DATE.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

       3610-INVERTED-TO-EXTERNAL-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACE                   TO MIR-FND-ID-G.
           MOVE SPACE                   TO MIR-SBSDRY-CO-ID-G.
           MOVE SPACE                   TO MIR-FND-BON-IDT-NUM-G.
019056*    MOVE SPACE                   TO MIR-FND-BON-TYP-CD-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
021930*COPY XCPS0290.
021930*COPY XCPL0290.
021930*
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
018763*COPY SCPBFHBS.
018763*COPY SCPNFHBS.
018763 COPY SCPBFBNE.
021930*COPY SCPNFBNE.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM SSOM8945                     *
      ****************************************************************
