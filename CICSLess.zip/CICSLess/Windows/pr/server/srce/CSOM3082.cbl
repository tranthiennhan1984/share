      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM3082.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM3082                                         **
      **  REMARKS:  PLAR - PLAN ALLOCATION RULE TABLE UPDATE         **
      **            THIS MODULE UPDATES THE PLAR TABLE               **
      **  DOMAIN :  PR                                               **
      **                                                             **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
015290**  6.3       PRE & POST TEFRA PROCESSING ENHANCEMENTS         **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM3082'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-UPDATE        VALUE '3082'.
           05  WS-TWRK-KEY                  PIC X(04)
                                            VALUE '3080'.
025970         88 WS-TWRK-KEY-DEFAULT          VALUE '3080'.
           05  WS-DPOS-DFLT-IND             PIC X(01).
               88  WS-VALID-DPOS-DFLT-IND   VALUE 'Y' 'N'.
               88  WS-DPOS-DFLT-YES         VALUE 'Y'.
               88  WS-DPOS-DFLT-NO          VALUE 'N'.
           05  WS-DUP-DPOS-DFLT-SW          PIC X(01).
               88  WS-DUP-DPOS-DFLT         VALUE 'Y'.
               88  WS-DUP-DPOS-DFLT-NO      VALUE 'N'.
           05  WS-DUP-WTHDR-PRCES-SEQ-SW    PIC X(01).
               88  WS-DUP-WTHDR-PRCES-SEQ   VALUE 'Y'.
               88  WS-DUP-WTHDR-PRCES-SEQ-NO VALUE 'N'.
           05  WS-PLAR-WTHDR-SEQ-NUM        PIC 9(01).

           05  WS-OLD-DPOS-DFLT-IND         PIC X(01).
               88  WS-OLD-DPOS-DFLT-YES     VALUE 'Y'.
           05  WS-OLD-TFR-IND               PIC X(01).
               88  WS-OLD-TFR-YES           VALUE 'Y'.
           05  WS-TFR-IND                   PIC X(01).
               88  WS-VALID-TFR-IND         VALUE 'Y' 'N'.
           05  WS-SUB                       PIC S9(04)   BINARY.
           05  WS-MAX-ALLOC-TYP             PIC S9(01)
                                            VALUE +9.
025970         88 WS-MAX-ALLOC-TYP-DEFAULT          VALUE +9.                                            

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY CCWWLOCK.
      /
021930*COPY CCWLPGA.
021930*
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
      /
       COPY CCFWPLAR.
       COPY CCFRPLAR.
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
       COPY CCFRPOL.
      /
       COPY CCWWCVGS.
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
      /
       COPY CCWL3088.
021930*COPY XCWLDTLK.
       COPY XCWL0280.
021930*COPY XCWL0290.
       COPY XCWL8090.
       COPY XCWL8960.
021930*COPY XCWEBLCH.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM3082.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------
026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

021930*    PERFORM  0290-1000-BUILD-PARM-INFO
021930*        THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           SET  MIR-RETRN-OK       TO TRUE.
           MOVE MIR-BUS-FCN-ID     TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM 5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM3082'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------

           PERFORM 5200-EDIT-KEY
              THRU 5200-EDIT-KEY-X.

           IF  WGLOB-RETURN-ERROR
               IF  MIR-RETRN-TS-MISMATCH
                   CONTINUE
               ELSE
                   PERFORM  PH-3000-UNLOCK
                       THRU PH-3000-UNLOCK-X
               END-IF
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  5400-EDIT-DATA
               THRU 5400-EDIT-DATA-X.

           IF  WGLOB-RETURN-ERROR
               PERFORM  PLAR-3000-UNLOCK
                   THRU PLAR-3000-UNLOCK-X
               PERFORM  PH-3000-UNLOCK
                   THRU PH-3000-UNLOCK-X
           ELSE
               PERFORM  PLAR-2000-REWRITE
                   THRU PLAR-2000-REWRITE-X
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM  PLAR-1000-CALL-AUDIT
                       THRU PLAR-1000-CALL-AUDIT-X
               END-IF
               PERFORM  PH-2000-REWRITE
                   THRU PH-2000-REWRITE-X
               PERFORM  PH-1000-READ-TWRK-TS
                   THRU PH-1000-READ-TWRK-TS-X
           END-IF.

      * CROSS CHECK IF DEFAULT PLAN IS THERE

           PERFORM  3088-0000-INIT-PARM-INFO
               THRU 3088-0000-INIT-PARM-INFO-X.

           MOVE MIR-PLAN-ID                  TO L3088-PLAN-ID.

           PERFORM  3088-2000-PLAR-INFO
               THRU 3088-2000-PLAR-INFO-X.


       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *---------------
       5200-EDIT-KEY.
      *---------------

           IF  MIR-PLAN-ID = SPACES
      *MSG:    PLAN ID IS REQUIRED
               MOVE 'CS30820001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 5200-EDIT-KEY-X
           END-IF.

           MOVE MIR-PLAN-ID             TO WPH-PLAN-ID.

           PERFORM  PH-2000-UPDATE-TWRK-TS
               THRU PH-2000-UPDATE-TWRK-TS-X.

           IF  WPH-IO-NOT-FOUND
      *MSG:  PLAN @1 IS NOT A VALID PLAN
               MOVE 'CS30820002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 5200-EDIT-KEY-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
      *     PROCESS NOT COMPLETE
               MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
               MOVE 'PH'               TO WGLOB-MSG-PARM (01)
               MOVE WPH-KEY            TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 5200-EDIT-KEY-X
           END-IF.

           MOVE MIR-PLAN-ID             TO WPLAR-PLAN-ID.
           MOVE MIR-PLAR-ALLOC-TYP-CD
                                        TO WPLAR-PLAR-ALLOC-TYP-CD.

           PERFORM  PLAR-1000-READ-FOR-UPDATE
               THRU PLAR-1000-READ-FOR-UPDATE-X.

           IF  WPLAR-IO-OK
               IF  WGLOB-AUDIT-REQUESTED
                   PERFORM  PLAR-1000-CALL-AUDIT
                       THRU PLAR-1000-CALL-AUDIT-X
               END-IF
           ELSE
      *MSG:  PLAN ALLOCATION RULE RECORD NOT EXIST
               MOVE 'CS30820003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

       5200-EDIT-KEY-X.
           EXIT.
      /
      *--------------
       5400-EDIT-DATA.
      *--------------

      * EDIT DEPOSIT DEFAULT INDICATOR

           SET  WS-DUP-DPOS-DFLT-NO         TO TRUE.
           SET  WS-DUP-WTHDR-PRCES-SEQ-NO   TO TRUE.

           MOVE RPLAR-PLAR-DPOS-DFLT-IND    TO WS-OLD-DPOS-DFLT-IND.
           MOVE RPLAR-PLAR-XFER-ONLY-IND    TO WS-OLD-TFR-IND.
           MOVE MIR-PLAR-DPOS-DFLT-IND      TO WS-DPOS-DFLT-IND.

           IF  WS-VALID-DPOS-DFLT-IND
      * CROSS EDIT FOR DEPOSIT DEFAULT INDICATOR
               PERFORM  5420-XEDIT-DPOS-DFLT-IND
                   THRU 5420-XEDIT-DPOS-DFLT-IND-X
           ELSE
      *MSG: DEPOSIT DEFAULT INDICATOR MUST BE YES OR NO
               MOVE 'CS30820004'              TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      * EDIT WITHDRAWAL PROCESSING ORDER

           IF  MIR-PLAR-WTHDR-SEQ-NUM < '0'
           OR  MIR-PLAR-WTHDR-SEQ-NUM > '9'
      *MSG:  WITHDRAWAL PROCESS SEQUENCE MUST BE SINGLE NUMERIC
               MOVE 'CS30820005'        TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      * NUMERIC EDIT FOR WITHDRAWAL PROCESSING SEQUENCE
                MOVE  MIR-PLAR-WTHDR-SEQ-NUM    TO L0280-INPUT-DATA
                SET L0280-SIGN-NOT-PERMITTED    TO TRUE
                MOVE 0                          TO L0280-PRECISION
                MOVE 1                          TO L0280-LENGTH
                MOVE 1                          TO L0280-INPUT-SIZE
                PERFORM  0280-1000-NUMERIC-EDIT
                    THRU 0280-1000-NUMERIC-EDIT-X
                IF  L0280-OK
                    MOVE L0280-OUTPUT           TO WS-PLAR-WTHDR-SEQ-NUM
      * TEST FOR DUPLICATE PROCESSING SEQUENCE
                    PERFORM  5440-XEDIT-WTHDR-PRCES-SEQR
                        THRU 5440-XEDIT-WTHDR-PRCES-SEQR-X
                ELSE
      *MSG:  WITHDRAWAL PROCESS SEQUENCE MUST BE SINGLE NUMERIC
                    MOVE 'CS30820005'     TO  WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                END-IF
           END-IF.

      * EDIT WITHDRAWAL PROCESSING OPTION

           IF  MIR-PLAR-WTHDR-ORDR-CD = SPACES
      *MSG: WITHDRAWAL PROCESSING OPTION MUST BE SELECTED
               MOVE 'CS30820006'            TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  8960-1000-BUILD-PARM-INFO
                   THRU 8960-1000-BUILD-PARM-INFO-X
               MOVE 'PLAR-WTHDR-ORDR-CD'    TO L8960-AV-TBL-CD
               MOVE MIR-PLAR-WTHDR-ORDR-CD  TO L8960-AV-CD
               PERFORM  8960-1000-VALIDATE-CODE
                   THRU 8960-1000-VALIDATE-CODE-X
               IF  L8960-RETRN-OK
                   MOVE MIR-PLAR-WTHDR-ORDR-CD
                                            TO RPLAR-PLAR-WTHDR-ORDR-CD
               ELSE
      *MSG:   INVALID WITHDRAWAL PROCESS OPTION
                  MOVE 'CS30820007'         TO WGLOB-MSG-REF-INFO
                  PERFORM 0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

      * EDIT  TRANSFER ALLOWED INDICATOR.

           MOVE MIR-PLAR-XFER-ONLY-IND      TO WS-TFR-IND.

           IF  WS-VALID-TFR-IND
               MOVE MIR-PLAR-XFER-ONLY-IND  TO RPLAR-PLAR-XFER-ONLY-IND
           ELSE
      *MSG:   INVALID TRANSFER ALLOWED INDICATOR
              MOVE 'CS30820008'             TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  RPLAR-PLAR-DPOS-DFLT-IND = 'Y'
           AND RPLAR-PLAR-XFER-ONLY-IND = 'Y'
               PERFORM  5460-XEDIT-DFLT-TFR
                   THRU 5460-XEDIT-DFLT-TFR-X
           END-IF.

       5400-EDIT-DATA-X.
           EXIT.
      /
      *-------------------------
       5420-XEDIT-DPOS-DFLT-IND.
      *-------------------------

           IF  WS-DPOS-DFLT-YES
               PERFORM  3088-0000-INIT-PARM-INFO
                   THRU 3088-0000-INIT-PARM-INFO-X
               MOVE MIR-PLAN-ID             TO L3088-PLAN-ID
               SET  L3088-TRXN-TYP-ALL      TO TRUE
               SET  L3088-CHECK-DFLT-NO     TO TRUE

               PERFORM  3088-2000-PLAR-INFO
                   THRU 3088-2000-PLAR-INFO-X

               IF  L3088-DFLT-ALLOC-TYP-CD NOT = SPACES
               AND L3088-DFLT-ALLOC-TYP-CD NOT = MIR-PLAR-ALLOC-TYP-CD
                   SET WS-DUP-DPOS-DFLT         TO TRUE
               END-IF
           END-IF.

           IF  WS-DUP-DPOS-DFLT
      *MSG:  ONLY ONE DEPOSIT DEFAULT ALLOWED ON FUND SOURCE ALLOCATION
                MOVE 'CS30820010'           TO WGLOB-MSG-REF-INFO
                PERFORM  0260-1000-GENERATE-MESSAGE
                    THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
                MOVE MIR-PLAR-DPOS-DFLT-IND TO RPLAR-PLAR-DPOS-DFLT-IND
           END-IF.

       5420-XEDIT-DPOS-DFLT-IND-X.
           EXIT.
      /
      *---------------------------
       5440-XEDIT-WTHDR-PRCES-SEQR.
      *---------------------------

           PERFORM  3088-0000-INIT-PARM-INFO
               THRU 3088-0000-INIT-PARM-INFO-X.

           MOVE MIR-PLAN-ID                  TO L3088-PLAN-ID.
           SET  L3088-CHECK-DFLT-NO          TO TRUE.

           PERFORM  3088-2000-PLAR-INFO
               THRU 3088-2000-PLAR-INFO-X.

           PERFORM  5442-CHK-DUP-WTHDR-PRCES-SEQ
               THRU 5442-CHK-DUP-WTHDR-PRCES-SEQ-X
               VARYING WS-SUB FROM +1 BY +1
               UNTIL WS-SUB > WS-MAX-ALLOC-TYP
                  OR WS-DUP-WTHDR-PRCES-SEQ.

           IF  WS-DUP-WTHDR-PRCES-SEQ
      *MSG:  WITHDRAWAL PROCESSING SEQUENCE NUMBER ALREADY EXISTS FOR
      *      PLAN @1
               MOVE 'CS30820011'           TO WGLOB-MSG-REF-INFO
               MOVE L3088-PLAN-ID          TO WGLOB-MSG-PARM (01)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE WS-PLAR-WTHDR-SEQ-NUM  TO RPLAR-PLAR-WTHDR-SEQ-NUM
           END-IF.

       5440-XEDIT-WTHDR-PRCES-SEQR-X.
           EXIT.
      /
      *-----------------------------
       5442-CHK-DUP-WTHDR-PRCES-SEQ.
      *-----------------------------

           IF  MIR-PLAR-ALLOC-TYP-CD = L3088-PLAR-ALLOC-TYP-CD (WS-SUB)
               CONTINUE
           ELSE
               IF  WS-PLAR-WTHDR-SEQ-NUM > 0
               AND WS-PLAR-WTHDR-SEQ-NUM
                       = L3088-PLAR-WTHDR-SEQ-NUM (WS-SUB)
                   SET WS-DUP-WTHDR-PRCES-SEQ  TO TRUE
               END-IF
           END-IF.

       5442-CHK-DUP-WTHDR-PRCES-SEQ-X.
           EXIT.
      /
      *---------------------------
       5460-XEDIT-DFLT-TFR.
      *---------------------------

           IF  WS-OLD-DPOS-DFLT-YES
      *MSG: TRANSFER INDICATOR CANNOT BE SET IN DEFAULT ALLOCATION
               MOVE 'CS30820012'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-OLD-TFR-IND         TO RPLAR-PLAR-XFER-ONLY-IND
           END-IF.

           IF  WS-OLD-TFR-YES
      *MSG: DEPOSIT DEFAULT INDCATOR MUST BE UNCHECKED, FOR TRANSFER
      *     ONLY INDICATOR TO APPLY
               MOVE 'CS30820013'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-OLD-DPOS-DFLT-IND   TO RPLAR-PLAR-DPOS-DFLT-IND
           END-IF.

           IF  NOT WS-OLD-DPOS-DFLT-YES
           AND NOT WS-OLD-TFR-YES
      *MSG: TRANSFER INDICATOR CANNOT BE SET IN DEFAULT ALLOCATION
               MOVE 'CS30820012'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
      *MSG: DEPOSIT DEFAULT INDCATOR MUST BE UNCHECKED, FOR TRANSFER
      *     ONLY INDICATOR TO APPLY
               MOVE 'CS30820013'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-OLD-TFR-IND         TO RPLAR-PLAR-XFER-ONLY-IND
               MOVE WS-OLD-DPOS-DFLT-IND   TO RPLAR-PLAR-DPOS-DFLT-IND
           END-IF.

       5460-XEDIT-DFLT-TFR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  3088-0000-INIT-PARM-INFO
025970         THRU 3088-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     SET WS-TWRK-KEY-DEFAULT TO TRUE.
025970     SET WS-MAX-ALLOC-TYP-DEFAULT TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY PH
                               '$VAR2' BY 'PH'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
       COPY CCPLPLAR.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
021930*COPY XCPS0290.
021930*COPY XCPL0290.
021930*
       COPY CCPS3088.
       COPY CCPL3088.
      /
021930*COPY XCPS8090.
       COPY XCPL8090.
      /
       COPY XCPS8960.
       COPY XCPL8960.
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
021930*COPY CCPNPLAR.
       COPY CCPUPLAR.
      /
       COPY CCPNPH.
       COPY CCPUPH.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM3082                     *
      ****************************************************************
