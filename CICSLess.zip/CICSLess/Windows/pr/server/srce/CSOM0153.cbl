      *************************
       IDENTIFICATION DIVISION.
      *************************
      *
       PROGRAM-ID. CSOM0153.
      *
       COPY XCWWCRHT.
      *
      *****************************************************************
      **  MEMBER :  CSOM0153                                         **
      **  REMARKS:  PDUR - PROTECTED COVERAGE DETAILS/DURATION       **
      **            MAINTENANCE. THIS PROCESS DRIVER IS USED TO      **
      **            UPDATE ALLOCATION AND COMMISSION BALANCES ON THE **
      **            CVGD TABLE. ANOTHER MODULE IS CALLED TO UPDATE   **
      **            AGENT-RELATED FIELDS ON THE CVGA TABLE.          **
      **                                                             **
      **  DOMAIN :  CV                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557668**  5.5       NEW NAME FORMATTING                              **
557699**  5.5       NEW AUDIT MODULE                                 **
557708**  5.5       ABEND HANDLING                                   **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010418**  5.6       ADD SUB-COMPANY-CODE FIELD                       **
012624**  6.0       GLOBAL SECURITY                                  **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015543**  6.0       CODE CLEAN UP                                    **
014221**  6.2       LOGICAL LOCKING                                  **
014591**  6.2       COMBINE PLAN-ID & RS                             **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017449**  6.2       DISPLAY INSURED INSTEAD OF OWNER                 **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019297**  6.3       GENERATE CURRENCY MSG                            **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023163**  6.5       COMMISSIONABLE AGENT DETAIL                      **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WOKING STORAGE INITIALIZATION                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028789**  6.7       EXTERNAL AGENCY INTEGRATION - REAL TIME INFO.    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
      *
      *************************
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0153'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      *************************
      *

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME             PIC X(04)  VALUE 'PDUR'.
           05  WS-BUS-FCN-ID             PIC X(04).
               88  WS-BUS-FCN-ID-VALID   VALUES
                   '0240' '0242'.
               88  WS-BUS-FCN-RETRIEVE   VALUE  '0240'.
               88  WS-BUS-FCN-UPDATE     VALUE  '0242'.
025970*    05  WS-TWRK-KEY               PIC X(04) VALUE  '0240'.
025970 01 WS-CONSTANTS.
025970     05  WS-TRANS-NAME             PIC X(04).
025970         88 WS-TRANS-PDUR          VALUE 'PDUR'.
025970     05  WS-TWRK-KEY               PIC X(04).
025970         88 WS-TWRK-KEY-DEFAULT    VALUE  '0240'.

      /
016537*COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      /
       COPY XCWEBLCH.
      /
016537*COPY XCWTATRB.
      /
028789 COPY CCWL0083.
557668 COPY CCWL0620.
       COPY CCWL2430.
       COPY XCWL0280.
008455 COPY XCWL0290.
014221 COPY XCWL8090.
       COPY CCWL2450.
       COPY CCWL5400.
023163 COPY CCWL2451.
      /
       01  CD-MISC-WORK-AREAS.
           05  HOLD-RIDER                   PIC XX.
016548*    05  I                            PIC S9(4) COMP.
016548     05  I                            PIC S9(4) BINARY.
016548*    05  J                            PIC S9(4) COMP.
016548     05  J                            PIC S9(4) BINARY.
023163     05  JJ                           PIC S9(4) BINARY.
           05  WS-EDIT-ERROR-SWITCH         PIC X(01).
               88  EDIT-ERROR               VALUE 'Y'.
           05  UPDATE-SW                    PIC X(01).
               88  NO-UPDATE                VALUE 'N'.
               88  UPDATE-REQUIRED          VALUE 'Y'.
           05  VALID-POLICY-SWITCH          PIC X.
               88  POLICY-VALID             VALUE 'Y'.
               88  POLICY-NOT-VALID         VALUE 'N'.
           05  VALID-RIDER-SWITCH           PIC X.
               88  RIDER-VALID              VALUE 'Y'.
               88  RIDER-NOT-VALID          VALUE 'N'.
015543     05  VALID-CVGD-DUR-SWITCH        PIC X.
015543         88  CVGD-DUR-VALID           VALUE 'Y'.
015543         88  CVGD-DUR-NOT-VALID       VALUE 'N'.
           05  HV-OWNER                     PIC X(50).
014591*    05  HV-PLAN                      PIC X(5).
           05  POLICY-HOLD.
               10  POLICY-NUM               PIC X(9).
               10  POLICY-SUFF              PIC X(1).
014221     05  WS-TS-ERROR-SW               PIC X(1).
014221         88  WS-TS-ERROR              VALUE 'Y'.
014221         88  WS-TS-ERROR-NO           VALUE 'N'.
013578*    05  WS-NUMERIC-DISPLAY-FIELDS.
013578*        10  WS-DISP-1-0.
013578*            15  WS-HOLD-1-0          PIC 9(1).
008455*        10  WS-DISP-7-2.
008455*            15  WS-HOLD-7-2          PIC 9(7).99.
008455*        10  WS-DISP-9-2.
008455*            15  WS-HOLD-9-2          PIC 9(9).99.
023163     05  WS-DFLT-CVDC-AGT-SW          PIC X.
023163         88  WS-DFLT-CVDC-AGT-NO      VALUE 'N'.
023163         88  WS-DFLT-CVDC-AGT         VALUE 'Y'.

      /
016537*COPY CCWWTR00.
      /
016537*COPY CCFHUSER.
      /
       01  FILE-WS-START  PIC X(51)
           VALUE '********* START OF FILE WORKING STORAGE *********'.
      /
023163*COPY CCFWCVGD.
023163*COPY CCFRCVGD.
      /
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFWPOL.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.

      *
       COPY CCFRPOL.
      *
       COPY CCWWCVGS.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      *
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0153.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.


026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           SET  MIR-RETRN-OK          TO TRUE.
           MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

028789     PERFORM  0083-2000-LOCATE-AGT-INFO
028789         THRU 0083-2000-LOCATE-AGT-INFO-X.
028789
028789     MOVE  L0083-AGT-SYS-IND    TO MIR-DV-XTRNL-AGT-INQ-IND.
028789
           IF  WGLOB-MSG-ERROR-SW           >  0
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

015543     PERFORM  2010-VALIDATE-CVG-NUM
015543         THRU 2010-VALIDATE-CVG-NUM-X.
015543
015543     IF  RIDER-NOT-VALID
015543         GO TO 2000-PROCESS-REQUEST-X
015543     END-IF.
015543
015543     PERFORM  2020-VALIDATE-CVGD-DUR
015543         THRU 2020-VALIDATE-CVGD-DUR-X.
015543
015543     IF  CVGD-DUR-NOT-VALID
015543         GO TO 2000-PROCESS-REQUEST-X
015543     END-IF.

           MOVE MIR-POL-ID-BASE       TO POLICY-NUM.
           MOVE MIR-POL-ID-SFX        TO POLICY-SUFF.
023163*    MOVE POLICY-HOLD           TO RCVGD-POL-ID.
023163*    MOVE POLICY-HOLD           TO WCVGD-POL-ID.
           MOVE POLICY-HOLD           TO WPOL-POL-ID.
           MOVE POLICY-HOLD           TO WCVG-POL-ID.
023163*    MOVE MIR-CVG-NUM           TO WCVGD-CVG-NUM-N.
           MOVE MIR-CVG-NUM           TO WCVG-CVG-NUM-N.
           MOVE MIR-CVG-NUM           TO HOLD-RIDER.
023163*    MOVE MIR-CVGD-DUR          TO WCVGD-CVGD-DUR.

           MOVE ZERO                  TO WGLOB-MSG-ERROR-SW.
           MOVE 'N'                   TO UPDATE-SW.

           PERFORM  7000-GET-POLICY-MASTER
               THRU 7000-GET-POLICY-MASTER-X.

      *
      *    CHECK TO SEE IF THE POLICY IS VALID
      *

           IF  POLICY-VALID
               PERFORM  5400-1000-BUILD-PARM-INFO
                   THRU 5400-1000-BUILD-PARM-INFO-X
012624*        SET L5400-SYS-APPL-CTL-ADMIN      TO TRUE
016440         IF WS-BUS-FCN-UPDATE
016440            SET L5400-POL-XFER-UPDATE      TO TRUE
019297            SET L5400-CRCY-MSG-REQD        TO TRUE
016440         END-IF
019297*        SET L5400-CRCY-MSG-REQD           TO TRUE

               PERFORM  5400-1000-POL-CHK
                   THRU 5400-1000-POL-CHK-X
      *
      *    CHECK THE ACCESS RESTRICTION CODES
      *
               IF  L5400-CNFD-ACCS-RESTRICTED
019297*        OR  L5400-CRCY-ACCS-RESTRICTED
               OR  L5400-BRCH-ACCS-RESTRICTED
016440         OR  L5400-XFER-ACCS-RESTRICTED
                   GO TO 2000-PROCESS-REQUEST-X
               END-IF

012624*        IF (L5400-CTL-ACCS-RESTRICTED
012624*        OR  L5400-STAT-ACCS-RESTRICTED)
012624*        AND NOT WS-BUS-FCN-RETRIEVE
012624*            GO TO 2000-PROCESS-REQUEST-X
012624*        END-IF
012624
012624         IF  RPOL-POL-SUSPENDED
012624         AND NOT WS-BUS-FCN-RETRIEVE
012624*MSG:    POLICY CURRENTLY SUSPENDED - CANNOT MAINTAIN OR PROCESS
012624             MOVE 'XS00000240'         TO WGLOB-MSG-REF-INFO
012624             PERFORM  0260-1000-GENERATE-MESSAGE
012624                 THRU 0260-1000-GENERATE-MESSAGE-X
012624             GO TO 2000-PROCESS-REQUEST-X
012624         END-IF
012624
016440*        IF  RPOL-POL-APPL-CTL-NBS
016440*        AND NOT WS-BUS-FCN-RETRIEVE
016440*MSG:    NEWBUS POLICY - CANNOT MAINTAIN OR PROCESS
016440*            MOVE 'XS00000238'        TO WGLOB-MSG-REF-INFO
016440*            PERFORM  0260-1000-GENERATE-MESSAGE
016440*                THRU 0260-1000-GENERATE-MESSAGE-X
016440*            GO TO 2000-PROCESS-REQUEST-X
016440*        END-IF
012624
012624         IF  L5400-STAT-ACCS-RESTRICTED
012624         AND NOT WS-BUS-FCN-RETRIEVE
012624             GO TO 2000-PROCESS-REQUEST-X
012624         END-IF
019297         IF  L5400-CRCY-ACCS-RESTRICTED
019297         AND NOT WS-BUS-FCN-RETRIEVE
019297             GO TO 2000-PROCESS-REQUEST-X
019297         END-IF
           END-IF.


           IF  POLICY-VALID
               PERFORM  7500-GET-RIDER
                   THRU 7500-GET-RIDER-X
016440         IF  RCVG-CVG-STAT-BEFORE-SETL
016440         AND NOT WS-BUS-FCN-RETRIEVE
016440*MSG:    PENDING STATUS- CANNOT MAINTAIN OR PROCESS
016440             MOVE 'XS00000244'        TO WGLOB-MSG-REF-INFO
016440             PERFORM  0260-1000-GENERATE-MESSAGE
016440                 THRU 0260-1000-GENERATE-MESSAGE-X
016440             GO TO 2000-PROCESS-REQUEST-X
016440         END-IF

               IF  RIDER-VALID
                   PERFORM  2430-1000-BUILD-PARM-INFO
                       THRU 2430-1000-BUILD-PARM-INFO-X
017449*            PERFORM  2430-2100-GET-OWNER
017449*                THRU 2430-2100-GET-OWNER-X
017449             PERFORM  2430-3100-GET-PRIM-INSRD
017449                 THRU 2430-3100-GET-PRIM-INSRD-X
557668*            MOVE L2430-CLI-NM-COMPRESSED  TO MIR-DV-OWN-CLI-NM

557668             INITIALIZE L0620-INPUT-PARM-INFO
557668             IF L2430-CLI-SEX-COMPANY
557668                MOVE L2430-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
557668             ELSE
557668                MOVE L2430-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
557668                MOVE L2430-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
                      MOVE L2430-CLI-MID-INIT-NM
                                      TO L0620-CLI-MID-INIT-NM
                      MOVE L2430-CLI-SFX-NM
                                      TO L0620-CLI-SFX-NM
557668             END-IF
557668             MOVE L2430-CLI-SEX-CD
                                      TO L0620-CLI-SEX-CD

557668             PERFORM  0620-1000-FORMAT-SCREEN-NAME
557668                 THRU 0620-1000-FORMAT-SCREEN-NAME-X

557668             MOVE L0620-SCREEN-NAME
017449*                               TO MIR-DV-OWN-CLI-NM
017449                                TO MIR-DV-INSRD-CLI-NM

                   MOVE WCVGS-PLAN-ID (I)
                                      TO MIR-PLAN-ID
               END-IF
           END-IF.

           IF  POLICY-NOT-VALID
           OR  RIDER-NOT-VALID
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

023163     PERFORM  2451-0000-INIT-PARM-INFO
023163         THRU 2451-0000-INIT-PARM-INFO-X.
023163
023163     MOVE POLICY-HOLD           TO L2451-CD-POL-ID.
023163     MOVE MIR-CVG-NUM           TO L2451-CD-CVG-NUM.
023163     MOVE MIR-CVGD-DUR          TO L2451-CD-CVG-DUR.
023163
023163     IF  WGLOB-AUDIT-REQUESTED
023163         SET  L2451-AUDIT-REQUEST  TO TRUE
023163     END-IF.
023163
023163     PERFORM  2451-3000-RETRIEVE-CVGD-CVDC
023163         THRU 2451-3000-RETRIEVE-CVGD-CVDC-X.
023163
023163*    PERFORM  CVGD-1000-READ-FOR-UPDATE
023163*        THRU CVGD-1000-READ-FOR-UPDATE-X.

023163*    IF  WCVGD-IO-OK
023163*        IF  WGLOB-AUDIT-REQUESTED
023163*            PERFORM  CVGD-1000-CALL-AUDIT
023163*                THRU CVGD-1000-CALL-AUDIT-X
023163*        END-IF
023163*    ELSE
023163*    IF  WCVGD-IO-NOT-FOUND
023163     IF  L2451-CD-NOT-FOUND
      * 01530001 COVERAGE AMTS PER DURATION RECORD HAS NOT BEEN CREATED
               MOVE 'CS01530001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-PROCESS-REQUEST-X
023163*    END-IF
           END-IF.

      *
      *    DUE TO THE REQUIRES NEED OF READING THE COVERAGE AGENTS'
      *    INOFRMATIONS, A CALL TO THE CCPS2450 IS PLACED.
      *


           PERFORM  2450-1000-BUILD-PARM-INFO
               THRU 2450-1000-BUILD-PARM-INFO-X.
           PERFORM  2450-2000-READ-CVG-AGENTS
               THRU 2450-2000-READ-CVG-AGENTS-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID  TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0153'      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'    TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

014221     IF  WS-TS-ERROR
014221         GO TO 2000-PROCESS-REQUEST-X
014221     END-IF.

           PERFORM  2100-CLEAN-UP-LOOSE-ENDS
               THRU 2100-CLEAN-UP-LOOSE-ENDS-X.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
015543*----------------------
015543 2010-VALIDATE-CVG-NUM.
015543*----------------------
015543
015543     SET RIDER-VALID              TO TRUE.
015543     SET L0280-SIGN-NOT-PERMITTED TO TRUE.
015543     MOVE ZERO                    TO L0280-PRECISION.
015543     MOVE LENGTH OF MIR-CVG-NUM   TO L0280-INPUT-SIZE.
015543     MOVE L0280-INPUT-SIZE        TO L0280-LENGTH.
015543     MOVE MIR-CVG-NUM             TO L0280-INPUT-DATA.
015543
015543     PERFORM  0280-1000-NUMERIC-EDIT
015543         THRU 0280-1000-NUMERIC-EDIT-X.
015543
015543     IF  L0280-OK
020874*        MOVE L0280-OUTPUT        TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT        TO L0290-INPUT-V00
015543         MOVE ZERO                TO L0290-PRECISION
015543         MOVE LENGTH OF MIR-CVG-NUM
015543                                  TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
015543         MOVE L0290-OUTPUT-DATA   TO MIR-CVG-NUM
015543     ELSE
015543         SET RIDER-NOT-VALID      TO TRUE
015543* 01530010 COVERAGE NUMBER INVALID.
015543         MOVE 'CS01530010'        TO WGLOB-MSG-REF-INFO
015543         PERFORM  0260-1000-GENERATE-MESSAGE
015543             THRU 0260-1000-GENERATE-MESSAGE-X
015543     END-IF.
015543
015543 2010-VALIDATE-CVG-NUM-X.
015543     EXIT.
015543/
015543*-----------------------
015543 2020-VALIDATE-CVGD-DUR.
015543*-----------------------
015543
015543     SET CVGD-DUR-VALID           TO TRUE.
015543     SET L0280-SIGN-NOT-PERMITTED TO TRUE.
015543     MOVE ZERO                    TO L0280-PRECISION.
015543     MOVE LENGTH OF MIR-CVGD-DUR  TO L0280-INPUT-SIZE.
015543     MOVE L0280-INPUT-SIZE        TO L0280-LENGTH.
015543     MOVE MIR-CVGD-DUR            TO L0280-INPUT-DATA.
015543
015543     PERFORM  0280-1000-NUMERIC-EDIT
015543         THRU 0280-1000-NUMERIC-EDIT-X.
015543
015543     IF  L0280-OK
020874*        MOVE L0280-OUTPUT        TO L0290-INPUT-NUMBER
020874         MOVE L0280-OUTPUT        TO L0290-INPUT-V00
015543         MOVE ZERO                TO L0290-PRECISION
015543         MOVE LENGTH OF MIR-CVGD-DUR
015543                                  TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
015543         MOVE L0290-OUTPUT-DATA   TO MIR-CVGD-DUR
015543     ELSE
015543         SET CVGD-DUR-NOT-VALID   TO TRUE
015543* 01530011 DURATION NUMBER INVALID.
015543         MOVE 'CS01530011'        TO WGLOB-MSG-REF-INFO
015543         PERFORM  0260-1000-GENERATE-MESSAGE
015543             THRU 0260-1000-GENERATE-MESSAGE-X
015543     END-IF.
015543
015543 2020-VALIDATE-CVGD-DUR-X.
015543     EXIT.
015543/
      *-------------------------
       2100-CLEAN-UP-LOOSE-ENDS.
      *-------------------------

           IF  UPDATE-REQUIRED
023163*        PERFORM  CVGD-2000-REWRITE
023163*            THRU CVGD-2000-REWRITE-X
557699         IF  WGLOB-AUDIT-REQUESTED
023163             SET  L2451-AUDIT-REQUEST  TO TRUE
023163*            PERFORM  CVGD-1000-CALL-AUDIT
023163*                THRU CVGD-1000-CALL-AUDIT-X
557699         END-IF

023163         PERFORM  2451-6000-UPDATE-CVGD-CVDC
023163             THRU 2451-6000-UPDATE-CVGD-CVDC-X

014221         PERFORM  POL-2000-REWRITE
014221             THRU POL-2000-REWRITE-X
014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X
           ELSE
014221         IF  WS-BUS-FCN-UPDATE
014221             PERFORM  POL-3000-UNLOCK
014221                 THRU POL-3000-UNLOCK-X
014221         END-IF
023163*        IF  WCVGD-IO-OK
023163*            PERFORM  CVGD-3000-UNLOCK
023163*                THRU CVGD-3000-UNLOCK-X
023163*        END-IF
           END-IF.

       2100-CLEAN-UP-LOOSE-ENDS-X.
           EXIT.
      /

      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------

014221     MOVE POLICY-HOLD           TO WPOL-POL-ID.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           PERFORM  8000-MOVE-FIELDS-TO-OUTPUT
               THRU 8000-MOVE-FIELDS-TO-OUTPUT-X.

           MOVE 'N'                   TO UPDATE-SW.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------

           MOVE 'N'                   TO WS-EDIT-ERROR-SWITCH.
           MOVE 'N'                   TO UPDATE-SW.
014221     SET  WS-TS-ERROR-NO        TO TRUE.

014221     MOVE POLICY-HOLD           TO WPOL-POL-ID.

014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        SET WS-TS-ERROR            TO TRUE
014221        GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.


           PERFORM  5100-EDIT-FIELDS
               THRU 5100-EDIT-FIELDS-X.

013578***  IF  EDIT-ERROR
013578***      CONTINUE
013578***  ELSE
013578***      MOVE 'CS00000010'      TO WGLOB-MSG-REF-INFO
013578***      PERFORM  0260-1000-GENERATE-MESSAGE
013578***          THRU 0260-1000-GENERATE-MESSAGE-X
013578***  END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *-----------------
       5100-EDIT-FIELDS.
      *-----------------

           PERFORM  5101-EDIT-CUM-PMTS-DUR
               THRU 5101-EDIT-CUM-PMTS-DUR-X.

           PERFORM  5102-EDIT-CUM-LOAD-DUR
               THRU 5102-EDIT-CUM-LOAD-DUR-X.

           PERFORM  5106-DFLT-CVDC-AGT
               THRU 5106-DFLT-CVDC-AGT-X
               VARYING J FROM 1 BY 1
               UNTIL J > 3.

           PERFORM  5103-EDIT-COMM-PAID
               THRU 5103-EDIT-COMM-PAID-X
               VARYING J FROM 1 BY 1
               UNTIL J > 3.

           PERFORM  5104-EDIT-COMM-EARNED
               THRU 5104-EDIT-COMM-EARNED-X
               VARYING J FROM 1 BY 1
               UNTIL J > 3.

           PERFORM  5105-EDIT-COMM-ADVANCED
               THRU 5105-EDIT-COMM-ADVANCED-X
               VARYING J FROM 1 BY 1
               UNTIL J > 3.

       5100-EDIT-FIELDS-X.
           EXIT.
      /
      *-----------------------
       5101-EDIT-CUM-PMTS-DUR.
      *-----------------------

           IF  MIR-CVGD-PMT-AMT = SPACES
008455*        MOVE RCVGD-CVGD-PMT-AMT      TO WS-HOLD-9-2
008455*        MOVE WS-DISP-9-2             TO MIR-CVGD-PMT-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RCVGD-CVGD-PMT-AMT * 100
023163*        MOVE RCVGD-CVGD-PMT-AMT TO L0290-INPUT-V02
023163         MOVE L2451-CD-PMT-AMT   TO L0290-INPUT-V02
008455         MOVE 2                  TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVGD-PMT-AMT
                                       TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVGD-PMT-AMT
               GO TO 5101-EDIT-CUM-PMTS-DUR-X
           END-IF.

           IF  MIR-CVGD-PMT-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '000000000.00'          TO MIR-CVGD-PMT-AMT
008455         MOVE  ZEROS            TO MIR-CVGD-PMT-AMT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                           TO L0280-LENGTH.
008455*    MOVE 12                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVGD-PMT-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           MOVE MIR-CVGD-PMT-AMT      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE 'Y'               TO UPDATE-SW
               MOVE L0280-OUTPUT-DOLLAR
023163                                TO L2451-CD-PMT-AMT
023163*                               TO RCVGD-CVGD-PMT-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-9-2
008455*        MOVE WS-DISP-9-2             TO MIR-CVGD-PMT-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVGD-PMT-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVGD-PMT-AMT
           ELSE
      * 01530002  CUMULATIVE PAYMENTS DURATION MUST BE A VALID NUMERIC
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS01530002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5101-EDIT-CUM-PMTS-DUR-X.
           EXIT.
      /
      *-----------------------
       5102-EDIT-CUM-LOAD-DUR.
      *-----------------------

           IF  MIR-CVGD-PMT-LOAD-AMT = SPACES
008455*        MOVE RCVGD-CVGD-PMT-LOAD-AMT TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-CVGD-PMT-LOAD-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = RCVGD-CVGD-PMT-LOAD-AMT
020874*                                     * 100
023163*        MOVE RCVGD-CVGD-PMT-LOAD-AMT TO  L0290-INPUT-V02
023163         MOVE L2451-CD-PMT-LOAD-AMT   TO  L0290-INPUT-V02
008455         MOVE 2                       TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVGD-PMT-LOAD-AMT
                                            TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVGD-PMT-LOAD-AMT
               GO TO 5102-EDIT-CUM-LOAD-DUR-X
           END-IF.

           IF  MIR-CVGD-PMT-LOAD-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-CVGD-PMT-LOAD-AMT
008455         MOVE  ZEROS            TO MIR-CVGD-PMT-LOAD-AMT
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CVGD-PMT-LOAD-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           MOVE MIR-CVGD-PMT-LOAD-AMT TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE 'Y'               TO UPDATE-SW
               MOVE L0280-OUTPUT-DOLLAR
023163                                TO L2451-CD-PMT-LOAD-AMT
023163*                               TO RCVGD-CVGD-PMT-LOAD-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-CVGD-PMT-LOAD-AMT
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CVGD-PMT-LOAD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CVGD-PMT-LOAD-AMT
           ELSE
      * 01530003  CUMULATIVE LOAD DURATION MUST BE A VALID NUMERIC
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS01530003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5102-EDIT-CUM-LOAD-DUR-X.
           EXIT.
      /

      *--------------------
       5103-EDIT-COMM-PAID.
      *--------------------

      *
      * EDIT COMM-PAID
      *  01530005  # MUST BE ENTERED TO CHANGE THE COMMISSION FIELDS

023163     PERFORM
023163        VARYING JJ FROM 1 BY 1
023163          UNTIL JJ >  3
023163             OR L2451-CD-COMM-AGT-ID (JJ)
023163                = L2450-AGT-ID       (I, J)
023163         CONTINUE
023163     END-PERFORM.
023163
023163     IF  JJ > 3
023163         GO TO 5103-EDIT-COMM-PAID-X
023163     END-IF.
023163
023163*    IF  MIR-COMM-PD-1-AMT-T (J)                =  SPACES
023163     IF  MIR-CVGD-COMM-PD-AMT-T (J) = SPACES
               IF  L2450-AGT-ID (I, J)    NOT =  SPACES
008455*            MOVE RCVGD-COMM-PD-AMT (J) TO WS-HOLD-7-2
008455*            MOVE WS-DISP-7-2           TO MIR-COMM-PD-1-AMT-T (J)
020874*            COMPUTE L0290-INPUT-NUMBER
020874*                  = RCVGD-COMM-PD-AMT (J) * 100
023163*            MOVE RCVGD-COMM-PD-AMT (J) TO L0290-INPUT-V02
023163             MOVE L2451-CD-COMM-PD-AMT (J) TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
023163*            MOVE LENGTH OF MIR-COMM-PD-1-AMT-T (J)
023163             MOVE LENGTH OF MIR-CVGD-COMM-PD-AMT-T (J)
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
023163                                TO MIR-CVGD-COMM-PD-AMT-T (J)
023163*                               TO MIR-COMM-PD-1-AMT-T (J)
                   GO TO 5103-EDIT-COMM-PAID-X
               ELSE
008455*            MOVE '0000000.00'          TO MIR-COMM-PD-1-AMT-T (J)
023163             MOVE  ZEROS        TO MIR-CVGD-COMM-PD-AMT-T (J)
023163*            MOVE  ZEROS        TO MIR-COMM-PD-1-AMT-T (J)
008455*            GO TO 5103-EDIT-COMM-PAID-X
               END-IF
           END-IF.

023163     IF  MIR-CVGD-COMM-PD-AMT-T (J) = EBLCH-BLANK-FIELD-CHAR
023163         MOVE  ZEROS            TO MIR-CVGD-COMM-PD-AMT-T (J)
023163     END-IF.
023163*    IF  MIR-COMM-PD-1-AMT-T (J) = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'              TO MIR-COMM-PD-1-AMT-T (J)
023163*        MOVE  ZEROS            TO MIR-COMM-PD-1-AMT-T (J)
023163*    END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                             TO L0280-LENGTH.
008455*    MOVE 10                            TO L0280-INPUT-SIZE.
023163*    MOVE LENGTH OF MIR-COMM-PD-1-AMT-T (J)
023163     MOVE LENGTH OF MIR-CVGD-COMM-PD-AMT-T (J)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
023163*    MOVE MIR-COMM-PD-1-AMT-T (J)
023163     MOVE MIR-CVGD-COMM-PD-AMT-T (J)
                                      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

      *  01530006  COMMISSION PAID MUST BE A VALID NUMERIC
           IF  L0280-OK
               MOVE 'Y'               TO UPDATE-SW
               MOVE L0280-OUTPUT-DOLLAR
023163                                TO L2451-CD-COMM-PD-AMT (JJ)
023163*                               TO RCVGD-COMM-PD-AMT (J)
008455*        MOVE L0280-OUTPUT-DOLLAR       TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2               TO MIR-COMM-PD-1-AMT-T (J)
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
023163*        MOVE LENGTH OF MIR-COMM-PD-1-AMT-T (J)
023163         MOVE LENGTH OF MIR-CVGD-COMM-PD-AMT-T (J)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
023163         MOVE L0290-OUTPUT-DATA TO MIR-CVGD-COMM-PD-AMT-T (J)
023163*        MOVE L0290-OUTPUT-DATA TO MIR-COMM-PD-1-AMT-T (J)
           ELSE
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS01530006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5103-EDIT-COMM-PAID-X.
           EXIT.
      /
      *----------------------
       5104-EDIT-COMM-EARNED.
      *----------------------

      * EDIT COMM-EARNED
023163     PERFORM
023163        VARYING JJ FROM 1 BY 1
023163          UNTIL JJ >  3
023163             OR L2451-CD-COMM-AGT-ID (JJ)
023163                = L2450-AGT-ID       (I, J)
023163         CONTINUE
023163     END-PERFORM.
023163
023163     IF  JJ > 3
023163         GO TO 5104-EDIT-COMM-EARNED-X
023163     END-IF.
023163
023163*    IF  MIR-COMM-EARN-1-AMT-T (J)              =  SPACES
023163     IF  MIR-CVGD-COMM-EARN-AMT-T (J)         =  SPACES
               IF  L2450-AGT-ID (I, J)  NOT =  SPACES
008455*            MOVE RCVGD-COMM-EARN-AMT (J)
008455*                                     TO WS-HOLD-7-2
008455*            MOVE WS-DISP-7-2         TO MIR-COMM-EARN-1-AMT-T (J)
020874*            COMPUTE L0290-INPUT-NUMBER
020874*                  = RCVGD-COMM-EARN-AMT (J) * 100
023163*            MOVE RCVGD-COMM-EARN-AMT (J) TO L0290-INPUT-V02
023163             MOVE L2451-CD-COMM-EARN-AMT (J) TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
023163*            MOVE LENGTH OF MIR-COMM-EARN-1-AMT-T (J)
023163             MOVE LENGTH OF MIR-CVGD-COMM-EARN-AMT-T (J)
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
023163                                TO MIR-CVGD-COMM-EARN-AMT-T (J)
023163*                               TO MIR-COMM-EARN-1-AMT-T (J)
                   GO TO 5104-EDIT-COMM-EARNED-X
               ELSE
008455*            MOVE '0000000.00'        TO MIR-COMM-EARN-1-AMT-T (J)
023163             MOVE  ZEROS        TO MIR-CVGD-COMM-EARN-AMT-T (J)
023163*            MOVE  ZEROS        TO MIR-COMM-EARN-1-AMT-T (J)
008455*            GO TO 5104-EDIT-COMM-EARNED-X
               END-IF
           END-IF.

023163     IF  MIR-CVGD-COMM-EARN-AMT-T (J) = EBLCH-BLANK-FIELD-CHAR
023163         MOVE  ZEROS            TO MIR-CVGD-COMM-EARN-AMT-T (J)
023163     END-IF.
023163*    IF  MIR-COMM-EARN-1-AMT-T (J)  =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-COMM-EARN-1-AMT-T (J)
023163*        MOVE  ZEROS            TO MIR-COMM-EARN-1-AMT-T (J)
023163*    END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
023163*    MOVE LENGTH OF MIR-COMM-EARN-1-AMT-T (J)
023163     MOVE LENGTH OF MIR-CVGD-COMM-EARN-AMT-T (J)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
023163*    MOVE MIR-COMM-EARN-1-AMT-T (J)
023163     MOVE MIR-CVGD-COMM-EARN-AMT-T (J)
                                      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE 'Y'               TO UPDATE-SW
               MOVE L0280-OUTPUT-DOLLAR
023163                                TO L2451-CD-COMM-EARN-AMT (J)
023163*                               TO RCVGD-COMM-EARN-AMT (J)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-COMM-EARN-1-AMT-T (J)
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
023163*        MOVE LENGTH OF MIR-COMM-EARN-1-AMT-T (J)
023163         MOVE LENGTH OF MIR-CVGD-COMM-EARN-AMT-T (J)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
023163*        MOVE L0290-OUTPUT-DATA TO MIR-COMM-EARN-1-AMT-T (J)
023163         MOVE L0290-OUTPUT-DATA TO MIR-CVGD-COMM-EARN-AMT-T (J)
           ELSE
      *  01530007  COMMISSION EARNED MUST BE A VALID NUMERIC
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS01530007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5104-EDIT-COMM-EARNED-X.
           EXIT.
      /
      *------------------------
       5105-EDIT-COMM-ADVANCED.
      *------------------------

      *
      * EDIT COMM-ADVANCED
      *
023163     PERFORM
023163        VARYING JJ FROM 1 BY 1
023163          UNTIL JJ >  3
023163             OR L2451-CD-COMM-AGT-ID (JJ)
023163                = L2450-AGT-ID (I, J)
023163         CONTINUE
023163     END-PERFORM.
023163

023163     IF  JJ > 3
023163         GO TO 5105-EDIT-COMM-ADVANCED-X
023163     END-IF.
023163
023163*    IF  MIR-COMM-ADV-1-AMT-T (J)              =  SPACES
023163     IF  MIR-CVGD-COMM-ADV-AMT-T (J)         =  SPACES
               IF  L2450-AGT-ID (I, J)  NOT =  SPACES
008455*            MOVE RCVGD-COMM-ADV-AMT (J)
008455*                                     TO WS-HOLD-7-2
008455*            MOVE WS-DISP-7-2         TO MIR-COMM-ADV-1-AMT-T (J)
020874*            COMPUTE L0290-INPUT-NUMBER
020874*                  = RCVGD-COMM-ADV-AMT (J) * 100
023163*            MOVE RCVGD-COMM-ADV-AMT (J) TO L0290-INPUT-V02
023163             MOVE L2451-CD-COMM-ADV-AMT (J) TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
023163*            MOVE LENGTH OF MIR-COMM-ADV-1-AMT-T (J)
023163             MOVE LENGTH OF MIR-CVGD-COMM-ADV-AMT-T (J)
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
023163                                TO MIR-CVGD-COMM-ADV-AMT-T (J)
023163*                               TO MIR-COMM-ADV-1-AMT-T (J)
                   GO TO 5105-EDIT-COMM-ADVANCED-X
               ELSE
008455*            MOVE '0000000.00'        TO MIR-COMM-ADV-1-AMT-T (J)
023163*            MOVE  ZEROS        TO MIR-COMM-ADV-1-AMT-T (J)
008455*            GO TO 5105-EDIT-COMM-ADVANCED-X
023163             MOVE  ZEROS        TO MIR-CVGD-COMM-ADV-AMT-T (J)
               END-IF
           END-IF.

023163     IF  MIR-CVGD-COMM-ADV-AMT-T (J) = EBLCH-BLANK-FIELD-CHAR
023163         MOVE  ZEROS            TO MIR-CVGD-COMM-ADV-AMT-T (J)
023163     END-IF.
023163*    IF  MIR-COMM-ADV-1-AMT-T (J)  =  EBLCH-BLANK-FIELD-CHAR
008455*        MOVE '0000000.00'            TO MIR-COMM-ADV-1-AMT-T (J)
023163*        MOVE  ZEROS            TO MIR-COMM-ADV-1-AMT-T (J)
023163*    END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 7                           TO L0280-LENGTH.
008455*    MOVE 10                          TO L0280-INPUT-SIZE.
023163*    MOVE LENGTH OF MIR-COMM-ADV-1-AMT-T (J)
023163     MOVE LENGTH OF MIR-CVGD-COMM-ADV-AMT-T (J)
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
023163*    MOVE MIR-COMM-ADV-1-AMT-T (J)
023163     MOVE MIR-CVGD-COMM-ADV-AMT-T (J)
                                      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE 'Y'               TO UPDATE-SW
               MOVE L0280-OUTPUT-DOLLAR
023163                                TO L2451-CD-COMM-ADV-AMT (J)
023163*                               TO RCVGD-COMM-ADV-AMT (J)
008455*        MOVE L0280-OUTPUT-DOLLAR     TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-COMM-ADV-1-AMT-T (J)
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
023163*        MOVE LENGTH OF MIR-COMM-ADV-1-AMT-T (J)
023163         MOVE LENGTH OF MIR-CVGD-COMM-ADV-AMT-T (J)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
023163*        MOVE L0290-OUTPUT-DATA TO MIR-COMM-ADV-1-AMT-T (J)
023163         MOVE L0290-OUTPUT-DATA TO MIR-CVGD-COMM-ADV-AMT-T (J)
           ELSE
      *  01530008  COMMISSION ADVANCED MUST BE A VALID NUMERIC
               MOVE 'Y'               TO WS-EDIT-ERROR-SWITCH
               MOVE 'CS01530008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5105-EDIT-COMM-ADVANCED-X.
           EXIT.
023163/
023163*-----------------------
023163 5106-DFLT-CVDC-AGT.
023163*-----------------------
023163
023163* LOOK FOR A CVGA AGENT ID NOT IN CVDC
023163* AND USE THE CVGA AGENT ID
023163*
023163     PERFORM
023163        VARYING JJ FROM 1 BY 1
023163          UNTIL JJ >  3
023163             OR L2451-CD-COMM-AGT-ID (JJ)
023163                = L2450-AGT-ID       (I, J)
023163         CONTINUE
023163     END-PERFORM.
023163
023163     IF  JJ > 3
023163         SET WS-DFLT-CVDC-AGT-NO  TO TRUE
023163         PERFORM
023163            VARYING JJ FROM 1 BY 1
023163              UNTIL JJ >  3
023163                 OR WS-DFLT-CVDC-AGT
023163                 IF  L2451-CD-COMM-AGT-ID (JJ)     = SPACES
023163                 AND L2450-AGT-ID       (I, J) NOT = SPACES
023163                     MOVE L2450-AGT-ID            (I, J)
023163                       TO L2451-CD-COMM-AGT-ID      (JJ)
023163                     SET WS-DFLT-CVDC-AGT  TO TRUE
023163                 END-IF
023163         END-PERFORM
023163     END-IF.
023163
023163 5106-DFLT-CVDC-AGT-X.
023163     EXIT.
      /
      *-----------------------
       7000-GET-POLICY-MASTER.
      *-----------------------

           MOVE 'Y'                   TO VALID-POLICY-SWITCH.

      *
      *    THE RECORDS ARE READ ONLY AND NOT REWRITTEN
      *

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

      * 00000019 POLICY NOT IN FILE
           IF  NOT WPOL-IO-OK
               MOVE 'N'               TO VALID-POLICY-SWITCH
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      * 01530009 NO COVERAGES EXIST ON THIS POLICY
           IF  POLICY-VALID
           AND RPOL-POL-CVG-REC-CTR-N = 0
               MOVE 'N'               TO VALID-POLICY-SWITCH
               MOVE 'CS01530009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  POLICY-VALID
           AND HOLD-RIDER > RPOL-POL-CVG-REC-CTR-N
      * 01530010 COVERAGE NUMBER INVALID.
               MOVE 'N'               TO VALID-POLICY-SWITCH
               MOVE 'CS01530010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7000-GET-POLICY-MASTER-X.
           EXIT.
      /
      *---------------
       7500-GET-RIDER.
      *---------------

           MOVE 'Y'                   TO VALID-RIDER-SWITCH.
           MOVE HOLD-RIDER            TO I.

      *
      *    THE RECORDS ARE READ ONLY AND NOT REWRITTEN
      *

           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X.

           IF  NOT WCVG-IO-OK
               MOVE 'N'               TO VALID-RIDER-SWITCH
      * 00000021 COVERAGE RECORD MUST EXIST. RE-ENTER.
               MOVE 'CS00000021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE RCVG-CVG-INFO     TO WCVGS-CVG-INFO (I)
               MOVE RCVG-CVG-NUM      TO WCVGS-CVG-SEQ-NUM (I)
           END-IF.

       7500-GET-RIDER-X.
           EXIT.
      /
      *---------------------------
       8000-MOVE-FIELDS-TO-OUTPUT.
      *---------------------------

008455*    MOVE RCVGD-CVGD-PMT-AMT          TO WS-HOLD-9-2.
008455*    MOVE WS-DISP-9-2                 TO MIR-CVGD-PMT-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RCVGD-CVGD-PMT-AMT * 100.
023163*    MOVE RCVGD-CVGD-PMT-AMT    TO L0290-INPUT-V02.
023163     MOVE L2451-CD-PMT-AMT      TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVGD-PMT-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVGD-PMT-AMT.
008455*    MOVE RCVGD-CVGD-PMT-LOAD-AMT     TO WS-HOLD-7-2.
008455*    MOVE WS-DISP-7-2                 TO MIR-CVGD-PMT-LOAD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RCVGD-CVGD-PMT-LOAD-AMT * 100.
023163*    MOVE RCVGD-CVGD-PMT-LOAD-AMT    TO L0290-INPUT-V02.
023163     MOVE L2451-CD-PMT-LOAD-AMT      TO L0290-INPUT-V02.
008455     MOVE 2                          TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVGD-PMT-LOAD-AMT
                                           TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVGD-PMT-LOAD-AMT.

           PERFORM  8100-SET-UP-AGENTS
               THRU 8100-SET-UP-AGENTS-X
               VARYING J FROM 1 BY 1
               UNTIL J > 3.

010418     MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.

       8000-MOVE-FIELDS-TO-OUTPUT-X.
           EXIT.
      /
      *-------------------
       8100-SET-UP-AGENTS.
      *-------------------

013578*    MOVE J                     TO WS-HOLD-1-0.
013578*    MOVE WS-DISP-1-0           TO MIR-AGTNO-T (J).
023163*
023163* FIND COVERAGE DURATION COMMISSION (CVDC) INFO
023163* FOR A COVERAGE AGENT (CVGA)
023163*
023163     PERFORM
023163        VARYING JJ FROM 1 BY 1
023163          UNTIL JJ >  3
023163             OR L2451-CD-COMM-AGT-ID (JJ)
023163                = L2450-AGT-ID       (I, J)
023163         CONTINUE
023163     END-PERFORM.
023163
023163     IF  JJ > 3
023163         GO TO 8100-SET-UP-AGENTS-X
023163     END-IF.
023163
           IF  L2450-AGT-ID (I, J)      NOT =  SPACES
023163         MOVE L2450-AGT-ID (I, J)       TO MIR-AGT-ID-T (J)
008455*        MOVE RCVGD-COMM-PD-AMT (J)   TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-COMM-PD-1-AMT-T (J)
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = RCVGD-COMM-PD-AMT (J) * 100
023163*        MOVE RCVGD-COMM-PD-AMT (J) TO L0290-INPUT-V02
023163         MOVE L2451-CD-COMM-PD-AMT (JJ) TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
023163         MOVE LENGTH OF MIR-CVGD-COMM-PD-AMT-T (J)
023163*        MOVE LENGTH OF MIR-COMM-PD-1-AMT-T (J)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
023163         MOVE L0290-OUTPUT-DATA TO MIR-CVGD-COMM-PD-AMT-T (J)
023163*        MOVE L0290-OUTPUT-DATA TO MIR-COMM-PD-1-AMT-T (J)
008455*        MOVE RCVGD-COMM-EARN-AMT (J) TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-COMM-EARN-1-AMT-T (J)
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = RCVGD-COMM-EARN-AMT (J) * 100
023163*        MOVE RCVGD-COMM-EARN-AMT (J) TO L0290-INPUT-V02
023163         MOVE L2451-CD-COMM-EARN-AMT (JJ) TO L0290-INPUT-V02
008455         MOVE 2                       TO L0290-PRECISION
023163*        MOVE LENGTH OF MIR-COMM-EARN-1-AMT-T (J)
023163         MOVE LENGTH OF MIR-CVGD-COMM-EARN-AMT-T (J)
                                            TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
023163*        MOVE L0290-OUTPUT-DATA TO MIR-COMM-EARN-1-AMT-T (J)
023163         MOVE L0290-OUTPUT-DATA TO MIR-CVGD-COMM-EARN-AMT-T (J)
008455*        MOVE RCVGD-COMM-ADV-AMT (J)  TO WS-HOLD-7-2
008455*        MOVE WS-DISP-7-2             TO MIR-COMM-ADV-1-AMT-T (J)
020874*        COMPUTE L0290-INPUT-NUMBER
020874*              = RCVGD-COMM-ADV-AMT (J) * 100
023163*        MOVE RCVGD-COMM-ADV-AMT (J) TO L0290-INPUT-V02
023163         MOVE L2451-CD-COMM-ADV-AMT (JJ) TO L0290-INPUT-V02
008455         MOVE 2                      TO L0290-PRECISION
023163*        MOVE LENGTH OF MIR-COMM-ADV-1-AMT-T (J)
023163         MOVE LENGTH OF MIR-CVGD-COMM-ADV-AMT-T (J)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
023163*        MOVE L0290-OUTPUT-DATA TO MIR-COMM-ADV-1-AMT-T (J)
023163         MOVE L0290-OUTPUT-DATA TO MIR-CVGD-COMM-ADV-AMT-T (J)
           ELSE
023163         MOVE SPACES            TO MIR-AGT-ID-T (J)
008455*        MOVE '0000000.00'            TO MIR-COMM-PD-1-AMT-T (J)
020874*        MOVE ZEROS             TO L0290-INPUT-NUMBER
020874         MOVE ZEROS             TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
023163*        MOVE LENGTH OF MIR-COMM-PD-1-AMT-T (J)
023163         MOVE LENGTH OF MIR-CVGD-COMM-PD-AMT-T (J)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
023163*        MOVE L0290-OUTPUT-DATA TO MIR-COMM-PD-1-AMT-T (J)
023163         MOVE L0290-OUTPUT-DATA TO MIR-CVGD-COMM-PD-AMT-T (J)
008455*        MOVE '0000000.00'            TO MIR-COMM-EARN-1-AMT-T (J)
020874*        MOVE ZEROS             TO L0290-INPUT-NUMBER
020874         MOVE ZEROS             TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
023163*        MOVE LENGTH OF MIR-COMM-EARN-1-AMT-T (J)
023163         MOVE LENGTH OF MIR-CVGD-COMM-EARN-AMT-T (J)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
023163*        MOVE L0290-OUTPUT-DATA TO MIR-COMM-EARN-1-AMT-T (J)
023163         MOVE L0290-OUTPUT-DATA TO MIR-CVGD-COMM-EARN-AMT-T (J)
008455*        MOVE '0000000.00'            TO MIR-COMM-ADV-1-AMT-T (J)
020874*        MOVE ZEROS             TO L0290-INPUT-NUMBER
020874         MOVE ZEROS             TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
023163*        MOVE LENGTH OF MIR-COMM-ADV-1-AMT-T (J)
023163         MOVE LENGTH OF MIR-CVGD-COMM-ADV-AMT-T (J)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
023163         MOVE L0290-OUTPUT-DATA TO MIR-CVGD-COMM-ADV-AMT-T (J)
023163*        MOVE L0290-OUTPUT-DATA TO MIR-COMM-ADV-1-AMT-T (J)
           END-IF.

       8100-SET-UP-AGENTS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

            MOVE SPACES               TO WGLOB-MSIN-REFERENCE.
            MOVE WGLOB-COMPANY-CODE   TO WGLOB-REF-COMPANY-CODE.
            MOVE 'P'                  TO WGLOB-REF-POLICY-OR-CLIENT.
            MOVE MIR-POL-ID-BASE      TO WGLOB-REF-POLICY-NUMBER.
            MOVE MIR-POL-ID-SFX       TO WGLOB-REF-POLICY-SUFFIX.
            MOVE MIR-CVG-NUM          TO WGLOB-REF-COVERAGE-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
028789     PERFORM  0083-0000-INIT-PARM-INFO
028789         THRU 0083-0000-INIT-PARM-INFO-X.
028789
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2450-0000-INIT-PARM-INFO
025970         THRU 2450-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2451-0000-INIT-PARM-INFO
025970         THRU 2451-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE CD-MISC-WORK-AREAS.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-TRANS-PDUR           TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT     TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
008455 COPY XCPL0290.
      /
028789 COPY CCPS0083.
028789 COPY CCPL0083.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      /
023163 COPY CCPS2451.
023163 COPY CCPL2451.
      /
008455 COPY XCPS0290.
       COPY CCPS2430.
       COPY CCPS2450.
       COPY CCPS5400.
018764*COPY CCCL2450.
018764 COPY CCPL2450.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
023163*COPY CCPUCVGD.
       COPY CCPNCVG.
018764*COPY CCCLCVGD.
023163*COPY CCPLCVGD.
      /
       COPY CCPNPOL.
014221 COPY CCPUPOL.
025970 COPY CCPS0620.
557668 COPY CCPL0620.
      /
026070*COPY XCCPABND.
026070 COPY XCCPERR.
557708*COPY XCCPHNDL.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM0153                     **
      *****************************************************************
