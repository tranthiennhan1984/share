      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0180.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0180                                         **
      **  REMARKS:  RESPONSIBLE FOR ONLINE MAINTENANCE OF THE POLICY **
      **            FOLLOW-UP INFORMATION (POLN) USING THE POLF      **
      **            TRANSACTION IN THE ADMIN SYSTEM.                **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
555080**  5.5       FIX ATTRIBUTE PROBLEMS, MOVE RECORD TO KEY       **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557668**  5.5       STANDARD CLIENT SCREEN NAME FORMATTING           **
557708**  5.5       NEW CICS ABEND PROCESSING                        **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010418**  5.6       ADD SUB-COMPANY-CODE FIELD                       **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
014221**  6.2       LOGICAL LOCKING                                  **
016440**  6.2       NB/AD CONSOLIDATIION                             **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEANUP                                     **
016548**  6.2       CHANGE COMP TO BINARY                            **
017705**  6.2       FORMAT SEQUENCE NUMBER FOR UPDATE                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
015705**  6.4       NAME FORMATTING                                  **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
027105**  6.6       99 COVERAGES HANDLING                            **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0180'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
       COPY XCWWWKDT.
       COPY XCWEBLCH.
014221 COPY CCWWLOCK.
      /
       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'POLF'.

           05  WS-BUS-FCN-ID                PIC X(4).
               88  WS-BUS-FCN-VALID         VALUE
                   '0180' '0181' '0182' '0183' '0184'.
               88  WS-BUS-FCN-LIST          VALUE '0184'.
               88  WS-BUS-FCN-CREATE        VALUE '0181'.
               88  WS-BUS-FCN-UPDATE        VALUE '0182'.
               88  WS-BUS-FCN-DELETE        VALUE '0183'.
               88  WS-BUS-FCN-RETRIEVE      VALUE '0180'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '0180'.

           05  WS-PIC-99                    PIC 99.
           05  WS-PIC-999                   PIC 999.
016548*    05  WS-SUB                       PIC S9(04) COMP.
016548     05  WS-SUB                       PIC S9(04) BINARY.
016548*    05  WS-LINE                      PIC S9(04) COMP.
016548     05  WS-LINE                      PIC S9(04) BINARY.
016548*    05  WS-MAX-SCREEN-LINES          PIC S9(04) COMP VALUE +10.
025970*    05  WS-MAX-SCREEN-LINES          PIC S9(04) BINARY VALUE +10.
027105*    05  I                            PIC 99 VALUE ZEROES.
027105     05  I                            PIC 9(03) VALUE ZEROES.

           05  WS-DATA-VALID-IND            PIC X(01).
               88  DATA-VALID               VALUE '0'.
               88  DATA-INVALID             VALUE '1'.
           05  WS-COMMAND-DATE-EDIT-IND     PIC X(01).
               88  COMMAND-DATE-VALID       VALUE '0'.
               88  COMMAND-DATE-INVALID     VALUE '1'.
           05  WS-COMMAND-SEQ-EDIT-IND      PIC X(01).
               88  COMMAND-SEQ-VALID        VALUE '0'.
               88  COMMAND-SEQ-INVALID      VALUE '1'.
           05  WS-BROWSE-SW                 PIC X(01).
               88  BRO-REC-FOUND            VALUE 'Y'.
               88  BRO-REC-NOT-FOUND        VALUE 'N'.
           05  WS-POL-REC-SW                PIC X(01).
               88  POL-REC-FOUND            VALUE 'Y'.
               88  POL-REC-NOT-FOUND        VALUE 'N'.
           05  WS-POL-REWRITE-SW            PIC X(01).
               88  WS-POL-REWRITE           VALUE 'Y'.
               88  WS-NO-POL-REWRITE        VALUE 'N'.
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                   PIC X(04).
025970         88 WS-TRANS-NAME-DEFAULT        VALUE 'POLF'.
025970     05  WS-TWRK-KEY                     PIC X(04).
025970         88 WS-TWRK-KEY-DEFAULT          VALUE '0180'.
025970     05  WS-MAX-SCREEN-LINES             PIC S9(04) BINARY.
025970         88 WS-MAX-SCREEN-LINES-DEFAULT  VALUE +10.

      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCFWPOLN.
       COPY CCFRPOLN.
      /
016503 COPY CCFWCVG.
016503 COPY CCFRCVG.
      /
016503 COPY CCWL0289.
557668 COPY CCWL0620.
       COPY CCWL2430.
028298 COPY CCWL2626.
       COPY CCWL5400.
      /
       COPY XCWL0280.
020874 COPY XCWL0290.
014221 COPY XCWL8090.
      /
       COPY XCWLDTLK.
       COPY XCWL1640.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
016503 COPY CCWWCVGS.
016503 COPY CCWLPGA.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0180.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

025970*    MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

      *  BACK OUT DELETE FUNCTION

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.


           PERFORM  9800-SETUP-MSIN-REFERENCE
               THRU 9800-SETUP-MSIN-REFERENCE-X.

           PERFORM  9500-DISPLAY-REQ-INFO
               THRU 9500-DISPLAY-REQ-INFO-X.

      * WHEN POLICY IS NOT FOUND OR ACCESS IS RESTRICTED, EXIT
           IF POL-REC-NOT-FOUND
           OR L5400-CNFD-ACCS-RESTRICTED
           OR L5400-BRCH-ACCS-RESTRICTED
016440     OR L5400-XFER-ACCS-RESTRICTED
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                   PERFORM  3500-PROCESS-LIST
                      THRU  3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                   PERFORM  4000-CREATE
                      THRU  4000-CREATE-X

               WHEN WS-BUS-FCN-RETRIEVE
                   PERFORM  5100-PROCESS-RETRIEVE
                      THRU  5100-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-UPDATE
                   PERFORM  5200-PROCESS-UPDATE
                      THRU  5200-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                   PERFORM  6000-PROCESS-DELETE
                      THRU  6000-PROCESS-DELETE-X


           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.


      *--------------------
       3100-DISPLAY-RECORD.
      *--------------------

           PERFORM  9600-MOVE-RECORD-TO-SCREEN
              THRU  9600-MOVE-RECORD-TO-SCREEN-X.

           MOVE 'Y'                   TO  WS-BROWSE-SW.
           ADD 1                        TO  WS-LINE.

           PERFORM  POLN-2000-READ-NEXT
               THRU POLN-2000-READ-NEXT-X.

       3100-DISPLAY-RECORD-X.
           EXIT.
      /
           EXIT.
      /
      ****************************************************************
      * INQUIRY PROCESSING:  SETUP BROWSE KEYS, BEGIN BROWSE, AND    *
      * LOAD DATA ARRAY UNTIL END-OF-FILE OR SCREEN IS FULL.         *
      ****************************************************************

      *------------------
       3500-PROCESS-LIST.
      *------------------

           MOVE 'N'                   TO  WS-BROWSE-SW.
           MOVE LOW-VALUES            TO  WPOLN-KEY.
           MOVE HIGH-VALUES           TO  WPOLN-ENDBR-KEY.
           MOVE MIR-POL-ID-BASE            TO  WPOLN-POL-ID-BASE
                                            WPOLN-ENDBR-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX            TO  WPOLN-POL-ID-SFX
                                            WPOLN-ENDBR-POL-ID-SFX.
           IF  MIR-POL-NOTI-DT NOT = SPACES
               AND MIR-POL-NOTI-DT NOT = EBLCH-BLANK-FIELD-CHAR
               PERFORM  8000-COMMAND-LINE-DATE-EDITS
                  THRU  8000-COMMAND-LINE-DATE-EDITS-X
               IF COMMAND-DATE-INVALID
034802*            NEXT SENTENCE
034802             CONTINUE
               ELSE
                   MOVE MIR-POL-NOTI-DT
                                      TO  L1640-EXTERNAL-DATE
020462*            PERFORM 1640-3000-EXTERNAL-TO-INT
020462*               THRU 1640-3000-EXTERNAL-TO-INT-X
020462             PERFORM 1640-7000-MIR-TO-INT
020462                THRU 1640-7000-MIR-TO-INT-X
                   MOVE L1640-INTERNAL-DATE
                                      TO  WPOLN-POL-NOTI-DT
557660         END-IF
           ELSE
               MOVE WWKDT-LOW-DT      TO  WPOLN-POL-NOTI-DT
557660     END-IF.

           MOVE WWKDT-HIGH-DT         TO  WPOLN-ENDBR-POL-NOTI-DT.

           IF  MIR-POL-NOTI-SEQ-NUM NOT = SPACES
               AND MIR-POL-NOTI-SEQ-NUM NOT = EBLCH-BLANK-FIELD-CHAR
               PERFORM  8100-COMMAND-LINE-SEQ-EDITS
                  THRU  8100-COMMAND-LINE-SEQ-EDITS-X
               IF COMMAND-SEQ-INVALID
                   GO TO 3500-PROCESS-LIST-X
               ELSE
                   MOVE MIR-POL-NOTI-SEQ-NUM
                                      TO  WS-PIC-999
                   MOVE WS-PIC-999    TO  WPOLN-POL-NOTI-SEQ-NUM-N
557660         END-IF
557660     END-IF.

555080     IF COMMAND-DATE-INVALID
555080         GO TO 3500-PROCESS-LIST-X
555080     END-IF.

           PERFORM POLN-1000-BROWSE
              THRU POLN-1000-BROWSE-X.

           IF WPOLN-IO-EOF
               MOVE 'XS00000015'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           IF  WPOLN-IO-OK
               PERFORM  POLN-2000-READ-NEXT
                   THRU POLN-2000-READ-NEXT-X
               IF NOT WPOLN-IO-EOF
                  MOVE 1              TO  WS-LINE
                  PERFORM  3100-DISPLAY-RECORD
                     THRU  3100-DISPLAY-RECORD-X
                        UNTIL WPOLN-IO-EOF
                        OR (WS-LINE > WS-MAX-SCREEN-LINES)
557660         END-IF
557660     END-IF.

           IF  BRO-REC-NOT-FOUND
               MOVE 'XS00000034'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
557660     END-IF.

           IF WPOLN-IO-EOF
               MOVE 'XS00000015'      TO  WGLOB-MSG-REF-INFO
555080         MOVE MIR-POL-NOTI-DT-T (1)
                                      TO  MIR-POL-NOTI-DT
555080         MOVE MIR-POL-NOTI-SEQ-NUM-T (1)
                                      TO  MIR-POL-NOTI-SEQ-NUM
           ELSE
               MOVE RPOLN-POL-NOTI-DT TO  L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO  MIR-POL-NOTI-DT
               MOVE RPOLN-POL-NOTI-SEQ-NUM
                                      TO  MIR-POL-NOTI-SEQ-NUM
               MOVE RPOLN-POL-ID-BASE TO  MIR-POL-ID-BASE
               MOVE RPOLN-POL-ID-SFX  TO  MIR-POL-ID-SFX
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
               MOVE 'XS00000014'      TO  WGLOB-MSG-REF-INFO
557660     END-IF.

           PERFORM  POLN-3000-END-BROWSE
              THRU  POLN-3000-END-BROWSE-X.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.


       3500-PROCESS-LIST-X.
           EXIT.

      *------------
       4000-CREATE.
      *------------

           PERFORM  8000-COMMAND-LINE-DATE-EDITS
              THRU  8000-COMMAND-LINE-DATE-EDITS-X.

           IF  COMMAND-DATE-INVALID
               GO TO 4000-CREATE-X
557660     END-IF.

           PERFORM 4100-CREATE-SEQ-NUM-FIND
              THRU 4100-CREATE-SEQ-NUM-FIND-X.

           MOVE MIR-POL-ID-BASE            TO  WPOLN-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX            TO  WPOLN-POL-ID-SFX.
           MOVE MIR-POL-NOTI-DT       TO  L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE   TO  WPOLN-POL-NOTI-DT.
           MOVE MIR-POL-NOTI-SEQ-NUM  TO  WS-PIC-999.
           MOVE WS-PIC-999            TO  WPOLN-POL-NOTI-SEQ-NUM-N.

           PERFORM  POLN-1000-CREATE
               THRU POLN-1000-CREATE-X.
           PERFORM  POLN-1000-WRITE
               THRU POLN-1000-WRITE-X.
      *
      *  UPDATE THE POLICY NEXT ACTIVITY DATE AND TYPE
      *
           IF RPOL-POL-STAT-IN-FORCE
               MOVE RPOL-KEY          TO WPOL-KEY
               MOVE 'N'               TO WS-POL-REWRITE-SW
               PERFORM  POL-1000-READ-FOR-UPDATE
                   THRU POL-1000-READ-FOR-UPDATE-X
               IF WPOL-IO-OK
                   MOVE 'Y'           TO WS-POL-REWRITE-SW
016503             PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
016503                 THRU CVGS-1000-LOAD-CVGS-ARRAY-X
016503*            MOVE WWKDT-ZERO-DT TO RPOL-POL-NXT-ACTV-DT
016503*            IF RPOL-NXT-ACTV-TYP-CD NOT = 'SCH'
016503*                MOVE 'RSH'     TO RPOL-NXT-ACTV-TYP-CD
016503*            END-IF
557660         END-IF
557660     END-IF.

           IF RPOL-POL-STAT-IN-FORCE
           AND WS-POL-REWRITE
016503         PERFORM  0289-1000-INIT-PARM-INFO
016503             THRU 0289-1000-INIT-PARM-INFO-X
016503         PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503             THRU 0289-1000-OBTAIN-NXT-ACTV-X
016503         IF  L0289-RETRN-OK
016503             MOVE L0289-NXT-ACTV-TYP-CD  TO RPOL-NXT-ACTV-TYP-CD
016503             MOVE L0289-NXT-ACTV-DT      TO RPOL-POL-NXT-ACTV-DT
016503         ELSE
016503             MOVE 'RSH'                  TO RPOL-NXT-ACTV-TYP-CD
016503             MOVE WGLOB-PROCESS-DATE     TO RPOL-POL-NXT-ACTV-DT
016503         END-IF
               PERFORM  POL-2000-REWRITE
                   THRU POL-2000-REWRITE-X
557660     END-IF.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           MOVE 'XS00000004'          TO  WGLOB-MSG-REF-INFO.
      * MSG: ' RECORD CREATED - CONTINUE'
           PERFORM  0260-1000-GENERATE-MESSAGE
              THRU  0260-1000-GENERATE-MESSAGE-X.

           MOVE 'XS00000016'          TO  WGLOB-MSG-REF-INFO.
      * MSG: ' MAINTAIN DETAILS'
           PERFORM  0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           MOVE 1                     TO  WS-LINE.
           PERFORM  9600-MOVE-RECORD-TO-SCREEN
              THRU  9600-MOVE-RECORD-TO-SCREEN-X.

       4000-CREATE-X.
           EXIT.

      *-------------------------
       4100-CREATE-SEQ-NUM-FIND.
      *-------------------------

           MOVE LOW-VALUES            TO  WPOLN-KEY.
           MOVE HIGH-VALUES           TO  WPOLN-ENDBR-KEY.
           MOVE MIR-POL-ID-BASE            TO  WPOLN-POL-ID-BASE
                                            WPOLN-ENDBR-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX            TO  WPOLN-POL-ID-SFX
                                            WPOLN-ENDBR-POL-ID-SFX.
           MOVE MIR-POL-NOTI-DT       TO  L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE   TO  WPOLN-POL-NOTI-DT
                                            WPOLN-ENDBR-POL-NOTI-DT.

           PERFORM  POLN-1000-BROWSE
              THRU  POLN-1000-BROWSE-X.

           IF  WPOLN-IO-OK
               PERFORM  POLN-2000-READ-NEXT
                  THRU  POLN-2000-READ-NEXT-X
               IF  WPOLN-IO-OK
                   MOVE RPOLN-POL-NOTI-SEQ-NUM
                                      TO WS-PIC-999
                   PERFORM  4200-CREATE-SEQ-BROWSE
                      THRU  4200-CREATE-SEQ-BROWSE-X
                        UNTIL WPOLN-IO-EOF
020874*            ADD  1              TO WS-PIC-999
020874*            MOVE WS-PIC-999    TO MIR-POL-NOTI-SEQ-NUM
020874             COMPUTE L0290-INPUT-V00 = WS-PIC-999
020874                                     + 1
020874             MOVE ZERO                  TO L0290-PRECISION
020874             MOVE LENGTH OF MIR-POL-NOTI-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
020874             MOVE L0290-OUTPUT-DATA     TO MIR-POL-NOTI-SEQ-NUM
                   PERFORM  POLN-3000-END-BROWSE
                      THRU  POLN-3000-END-BROWSE-X
               ELSE
                   MOVE '001'         TO MIR-POL-NOTI-SEQ-NUM
                   PERFORM  POLN-3000-END-BROWSE
                      THRU  POLN-3000-END-BROWSE-X
557660         END-IF
           ELSE
               MOVE '001'             TO MIR-POL-NOTI-SEQ-NUM
557660     END-IF.

           MOVE 'CS01800010'          TO  WGLOB-MSG-REF-INFO.
      * MSG: ' SEQUENCE NUMBER IGNORED, NEXT AVAILABLE NUMBER USED'
           PERFORM  0260-1000-GENERATE-MESSAGE
              THRU  0260-1000-GENERATE-MESSAGE-X.

       4100-CREATE-SEQ-NUM-FIND-X.
           EXIT.

      *-----------------------
       4200-CREATE-SEQ-BROWSE.
      *-----------------------

           PERFORM  POLN-2000-READ-NEXT
              THRU  POLN-2000-READ-NEXT-X.

           IF NOT WPOLN-IO-EOF
               MOVE RPOLN-POL-NOTI-SEQ-NUM
                                      TO WS-PIC-999
557660     END-IF.

       4200-CREATE-SEQ-BROWSE-X.
           EXIT.
      /
016537*--------------
016537*5000-MAINTAIN.
016537*--------------
016537*
016537*        PERFORM 5100-PROCESS-RETRIEVE
016537*           THRU 5100-PROCESS-RETRIEVE-X.
016537*
016537*        PERFORM 5200-PROCESS-UPDATE
016537*           THRU 5200-PROCESS-UPDATE-X.
016537*
016537*5000-MAINTAIN-X.
016537*    EXIT.

      *---------------------
       5100-PROCESS-RETRIEVE.
      *---------------------

           PERFORM  8000-COMMAND-LINE-DATE-EDITS
              THRU  8000-COMMAND-LINE-DATE-EDITS-X.

555080*    IF  COMMAND-DATE-INVALID
555080*        GO TO 5100-MAINTAIN-PART-1-X
555080*    END-IF.

           PERFORM  8100-COMMAND-LINE-SEQ-EDITS
              THRU  8100-COMMAND-LINE-SEQ-EDITS-X.

           IF  COMMAND-SEQ-INVALID
555080     OR  COMMAND-DATE-INVALID
               GO TO 5100-PROCESS-RETRIEVE-X
557660     END-IF.

014221     MOVE MIR-POL-ID-BASE           TO  WPOL-POL-ID-BASE.
014221     MOVE MIR-POL-ID-SFX            TO  WPOL-POL-ID-SFX.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           MOVE MIR-POL-ID-BASE            TO  WPOLN-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX            TO  WPOLN-POL-ID-SFX.
           MOVE MIR-POL-NOTI-DT       TO  L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE   TO  WPOLN-POL-NOTI-DT.
           MOVE MIR-POL-NOTI-SEQ-NUM  TO  WS-PIC-999.
           MOVE WS-PIC-999            TO  WPOLN-POL-NOTI-SEQ-NUM-N.

           PERFORM  POLN-1000-READ
               THRU POLN-1000-READ-X.

           IF WPOLN-IO-NOT-FOUND
               MOVE 'XS00000001'      TO  WGLOB-MSG-REF-INFO
               MOVE WPOLN-KEY         TO  WGLOB-MSG-PARM (1)
      * MSG: ' RECORD  @1 NOT FOUND'
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5100-PROCESS-RETRIEVE-X
           ELSE
               MOVE 'XS00000016'      TO  WGLOB-MSG-REF-INFO
      * MSG: ' MAINTAIN DETAILS'
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO  WS-LINE
               PERFORM  9600-MOVE-RECORD-TO-SCREEN
                  THRU  9600-MOVE-RECORD-TO-SCREEN-X
557660     END-IF.

       5100-PROCESS-RETRIEVE-X.
           EXIT.

      *---------------------
       5200-PROCESS-UPDATE.
      *---------------------

017705     PERFORM  8100-COMMAND-LINE-SEQ-EDITS
017705        THRU  8100-COMMAND-LINE-SEQ-EDITS-X.
017705
017705     IF  COMMAND-SEQ-INVALID
017705         GO TO 5200-PROCESS-UPDATE-X
017705     END-IF.

014221     MOVE MIR-POL-ID-BASE           TO  WPOL-POL-ID-BASE.
014221     MOVE MIR-POL-ID-SFX            TO  WPOL-POL-ID-SFX.

014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221         MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221         MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221         MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5200-PROCESS-UPDATE-X
014221     END-IF.

014221     IF  WPOL-IO-NOT-FOUND
014221*MSG: @2 RECORD (@1) NOT FOUND
014221         MOVE 'XS00000001'          TO WGLOB-MSG-REF-INFO
014221         MOVE WPOL-KEY              TO WGLOB-MSG-PARM (01)
014221         MOVE 'POL'                 TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5200-PROCESS-UPDATE-X
014221     END-IF.

           MOVE MIR-POL-ID-BASE            TO  WPOLN-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX            TO  WPOLN-POL-ID-SFX.
           MOVE MIR-POL-NOTI-DT       TO  L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE   TO  WPOLN-POL-NOTI-DT.
           MOVE MIR-POL-NOTI-SEQ-NUM  TO  WS-PIC-999.
           MOVE WS-PIC-999            TO  WPOLN-POL-NOTI-SEQ-NUM-N.

           PERFORM  POLN-1000-READ-FOR-UPDATE
               THRU POLN-1000-READ-FOR-UPDATE-X.

           IF WPOLN-IO-NOT-FOUND
               MOVE 'XS00000001'      TO  WGLOB-MSG-REF-INFO
               MOVE WPOLN-KEY         TO  WGLOB-MSG-PARM (1)
      * MSG: ' RECORD  @1 NOT FOUND'
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  POL-3000-UNLOCK
014221             THRU POL-3000-UNLOCK-X
               GO TO 5200-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  5400-EDIT-POLICY-REQ
               THRU 5400-EDIT-POLICY-REQ-X.

           PERFORM  5900-CROSS-EDIT
               THRU 5900-CROSS-EDIT-X.

           IF DATA-INVALID
014221         PERFORM  POL-3000-UNLOCK
014221             THRU POL-3000-UNLOCK-X
               GO TO 5200-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  POLN-2000-REWRITE
               THRU POLN-2000-REWRITE-X.
      *
      *  UPDATE THE POLICY NEXT ACTIVITY DATE AND TYPE
      *
014221*    IF RPOL-POL-STAT-IN-FORCE
014221*       MOVE RPOL-KEY          TO WPOL-KEY
014221*       MOVE 'N'               TO WS-POL-REWRITE-SW
014221*       PERFORM  POL-1000-READ-FOR-UPDATE
014221*           THRU POL-1000-READ-FOR-UPDATE-X
014221*        IF WPOL-IO-OK
014221*            MOVE 'Y'           TO WS-POL-REWRITE-SW
016503*            MOVE WWKDT-ZERO-DT TO RPOL-POL-NXT-ACTV-DT
016503*            IF RPOL-NXT-ACTV-TYP-CD NOT = 'SCH'
016503*                MOVE 'RSH'     TO RPOL-NXT-ACTV-TYP-CD
016503*            END-IF
014221*        END-IF
014221*    END-IF.

016503      PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
016503          THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

014221*    IF RPOL-POL-STAT-IN-FORCE
014221*    AND WS-POL-REWRITE
016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD  TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT      TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'                  TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE     TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.
014221*    END-IF.
           PERFORM  POL-2000-REWRITE
                THRU POL-2000-REWRITE-X.
014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           MOVE '0180'                   TO  WS-BUS-FCN-ID.
           MOVE 'XS00000008'          TO  WGLOB-MSG-REF-INFO.
      * MSG: 'RECORD UPDATED'
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       5200-PROCESS-UPDATE-X.
           EXIT.
      /
      *---------------------
       5400-EDIT-POLICY-REQ.
      *---------------------

           MOVE '0'                   TO  WS-DATA-VALID-IND.
           PERFORM  5500-NOTIFY-FREQUENCY
               THRU 5500-NOTIFY-FREQUENCY-X.

           PERFORM  5600-NOTIFY-NUMBER
               THRU 5600-NOTIFY-NUMBER-X.

           PERFORM  5700-NOTIFY-DEPARTMENT
               THRU 5700-NOTIFY-DEPARTMENT-X.

           PERFORM  5800-NOTIFY-REASON
               THRU 5800-NOTIFY-REASON-X.

       5400-EDIT-POLICY-REQ-X.
           EXIT.
      /
      *----------------------
       5500-NOTIFY-FREQUENCY.
      *----------------------

           IF MIR-POL-NOTI-MO-DUR-T (1)           =  SPACES
               MOVE  RPOLN-POL-NOTI-MO-DUR-N
                                      TO MIR-POL-NOTI-MO-DUR-T (1)
               GO TO 5500-NOTIFY-FREQUENCY-X
557660     END-IF.

           IF MIR-POL-NOTI-MO-DUR-T (1)  = EBLCH-BLANK-FIELD-CHAR
               MOVE ZEROES            TO MIR-POL-NOTI-MO-DUR-T (1)
               MOVE ZEROES            TO RPOLN-POL-NOTI-MO-DUR-N
               GO TO 5500-NOTIFY-FREQUENCY-X
557660     END-IF.

           MOVE MIR-POL-NOTI-MO-DUR-T (1)
                                      TO  L0280-INPUT-DATA.
           MOVE 'N'                   TO  L0280-SIGN-IND.
           MOVE 2                     TO  L0280-LENGTH.
           MOVE 0                     TO  L0280-PRECISION.
           MOVE 2                     TO  L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
020874*        MOVE L0280-OUTPUT      TO  WS-PIC-99
020874*        MOVE WS-PIC-99         TO  MIR-POL-NOTI-MO-DUR-T (1)
020874*        MOVE WS-PIC-99         TO  RPOLN-POL-NOTI-MO-DUR-N
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-NOTI-MO-DUR-T (1)
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-POL-NOTI-MO-DUR-T (1)
020874         MOVE L0280-OUTPUT          TO  RPOLN-POL-NOTI-MO-DUR-N
           ELSE
               MOVE 'CS01800007'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO  WS-DATA-VALID-IND
557660     END-IF.

       5500-NOTIFY-FREQUENCY-X.
           EXIT.


      *-------------------
       5600-NOTIFY-NUMBER.
      *-------------------

           IF MIR-POL-NOTI-QTY-T (1)           = SPACES
               MOVE  RPOLN-POL-NOTI-QTY-N
                                      TO MIR-POL-NOTI-QTY-T (1)
               GO TO 5600-NOTIFY-NUMBER-X
557660     END-IF.

           IF MIR-POL-NOTI-QTY-T (1) = EBLCH-BLANK-FIELD-CHAR
               MOVE '01'              TO  MIR-POL-NOTI-QTY-T (1)
               MOVE 1                 TO  RPOLN-POL-NOTI-QTY-N
               GO TO 5600-NOTIFY-NUMBER-X
557660     END-IF.

           IF MIR-POL-NOTI-QTY-T (1)           = ZEROES
               MOVE 'CS01800011'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO  WS-DATA-VALID-IND
               GO TO 5600-NOTIFY-NUMBER-X
557660     END-IF.

           MOVE MIR-POL-NOTI-QTY-T (1)             TO  L0280-INPUT-DATA.
           MOVE 'N'                   TO  L0280-SIGN-IND.
           MOVE 2                     TO  L0280-LENGTH.
           MOVE 0                     TO  L0280-PRECISION.
           MOVE 2                     TO  L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO  WS-PIC-99
               MOVE WS-PIC-99         TO  MIR-POL-NOTI-QTY-T (1)
               MOVE WS-PIC-99         TO  RPOLN-POL-NOTI-QTY-N
           ELSE
               MOVE 'CS01800008'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO  WS-DATA-VALID-IND
557660     END-IF.

       5600-NOTIFY-NUMBER-X.
           EXIT.


      *-----------------------
       5700-NOTIFY-DEPARTMENT.
      *-----------------------

           IF MIR-POL-NOTI-DEPT-ID-T (1) = SPACES
               MOVE  RPOLN-POL-NOTI-DEPT-ID
                                      TO MIR-POL-NOTI-DEPT-ID-T (1)
557660     END-IF.

           IF MIR-POL-NOTI-DEPT-ID-T (1) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO  MIR-POL-NOTI-DEPT-ID-T (1)
557660     END-IF.

           MOVE MIR-POL-NOTI-DEPT-ID-T (1)
                                      TO  WEDIT-ETBL-VALU-ID.
           PERFORM  DEPT-1000-EDIT-DEPARTMENT
               THRU DEPT-1000-EDIT-DEPARTMENT-X.

           IF NOT WEDIT-IO-OK
               MOVE 'CS01800006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-VALID-IND
           ELSE
               MOVE MIR-POL-NOTI-DEPT-ID-T (1)
                                      TO  RPOLN-POL-NOTI-DEPT-ID
557660     END-IF.

       5700-NOTIFY-DEPARTMENT-X.
           EXIT.


      *-------------------
       5800-NOTIFY-REASON.
      *-------------------

           IF MIR-POL-NOTI-REASN-CD-T (1) = SPACES
               MOVE  RPOLN-POL-NOTI-REASN-CD
                                      TO MIR-POL-NOTI-REASN-CD-T (1)
557660     END-IF.

           IF MIR-POL-NOTI-REASN-CD-T (1) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO  MIR-POL-NOTI-REASN-CD-T (1)
557660     END-IF.

           MOVE MIR-POL-NOTI-REASN-CD-T (1)
                                      TO  WEDIT-ETBL-VALU-ID.
           PERFORM  NOTR-1000-EDIT-NOTIFY-RSN
               THRU NOTR-1000-EDIT-NOTIFY-RSN-X.

           IF NOT WEDIT-IO-OK
               MOVE 'CS01800003'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-DATA-VALID-IND
           ELSE
               MOVE MIR-POL-NOTI-REASN-CD-T (1)
                                      TO  RPOLN-POL-NOTI-REASN-CD
557660     END-IF.

       5800-NOTIFY-REASON-X.
           EXIT.
      /
      *----------------
       5900-CROSS-EDIT.
      *----------------

           IF MIR-POL-NOTI-MO-DUR-T (1) = '00'
           AND MIR-POL-NOTI-QTY-T (1) > '01'
               MOVE 'CS01800012'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO  WS-DATA-VALID-IND
557660     END-IF.

           IF MIR-POL-NOTI-MO-DUR-T (1) > '00'
           AND MIR-POL-NOTI-QTY-T (1) = '01'
               MOVE 'CS01800013'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5900-CROSS-EDIT-X.
           EXIT.
      /
      ****************************************************************
      * DELETE PROCESSING:                                           *
      *   FORCE = 1:  USER HAS ENTERED KEY DETAILS.                  *
      *   FORCE = 9:  USER HAS VERIFIED DELETE REQUEST.              *
      ****************************************************************

      *-------------------
       6000-PROCESS-DELETE.
      *-------------------

           PERFORM  8000-COMMAND-LINE-DATE-EDITS
              THRU  8000-COMMAND-LINE-DATE-EDITS-X.


           PERFORM  8100-COMMAND-LINE-SEQ-EDITS
              THRU  8100-COMMAND-LINE-SEQ-EDITS-X.

           IF  COMMAND-SEQ-INVALID
555080     OR  COMMAND-DATE-INVALID
               GO TO 6000-PROCESS-DELETE-X
557660     END-IF.

014221     MOVE MIR-POL-ID-BASE           TO  WPOL-POL-ID-BASE.
014221     MOVE MIR-POL-ID-SFX            TO  WPOL-POL-ID-SFX.

014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221         MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221         MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
014221         MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           MOVE MIR-POL-ID-BASE            TO  WPOLN-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX            TO  WPOLN-POL-ID-SFX.
           MOVE MIR-POL-NOTI-DT       TO  L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE   TO  WPOLN-POL-NOTI-DT.
           MOVE MIR-POL-NOTI-SEQ-NUM  TO  WS-PIC-999.
           MOVE WS-PIC-999            TO  WPOLN-POL-NOTI-SEQ-NUM-N.

           PERFORM POLN-1000-READ
              THRU POLN-1000-READ-X.

           IF WPOLN-IO-NOT-FOUND
               MOVE WPOLN-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9700-BLANK-DATA-FIELDS
                   THRU 9700-BLANK-DATA-FIELDS-X
           ELSE
               MOVE 1                 TO WS-LINE
               PERFORM  9600-MOVE-RECORD-TO-SCREEN
                   THRU 9600-MOVE-RECORD-TO-SCREEN-X
               MOVE 'XS00000009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

           MOVE MIR-POL-ID-BASE            TO  WPOLN-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX            TO  WPOLN-POL-ID-SFX.
           MOVE MIR-POL-NOTI-DT       TO  L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE   TO  WPOLN-POL-NOTI-DT.
           MOVE MIR-POL-NOTI-SEQ-NUM  TO  WS-PIC-999.
           MOVE WS-PIC-999            TO  WPOLN-POL-NOTI-SEQ-NUM-N.

           PERFORM POLN-1000-READ-FOR-UPDATE
              THRU POLN-1000-READ-FOR-UPDATE-X.

           IF WPOLN-IO-OK
               PERFORM  POLN-1000-DELETE
                   THRU POLN-1000-DELETE-X
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               MOVE '0180'               TO WS-BUS-FCN-ID
               PERFORM  9700-BLANK-DATA-FIELDS
                   THRU 9700-BLANK-DATA-FIELDS-X
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE WPOLN-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  POL-3000-UNLOCK
014221             THRU POL-3000-UNLOCK-X
014221         GO TO 6000-PROCESS-DELETE-X
557660     END-IF.

014221*    PERFORM  0260-1000-GENERATE-MESSAGE
014221*        THRU 0260-1000-GENERATE-MESSAGE-X.
      *
      *  UPDATE THE POLICY NEXT ACTIVITY DATE AND TYPE
      *
014221*    IF RPOL-POL-STAT-IN-FORCE
014221*        MOVE RPOL-KEY          TO WPOL-KEY
014221*        MOVE 'N'               TO WS-POL-REWRITE-SW
014221*        PERFORM  POL-1000-READ-FOR-UPDATE
014221*            THRU POL-1000-READ-FOR-UPDATE-X
014221*        IF WPOL-IO-OK
014221*            MOVE 'Y'           TO WS-POL-REWRITE-SW
016503*            MOVE WWKDT-ZERO-DT TO RPOL-POL-NXT-ACTV-DT
016503*            IF RPOL-NXT-ACTV-TYP-CD NOT = 'SCH'
016503*                MOVE 'RSH'     TO RPOL-NXT-ACTV-TYP-CD
016503*            END-IF
014221*        END-IF
014221*    END-IF.

016503     PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
016503         THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

014221*    IF RPOL-POL-STAT-IN-FORCE
014221*    AND WS-POL-REWRITE
016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD  TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT      TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'                  TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE     TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.
           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.
014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.
014221*    END-IF.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *-----------------------------
       8000-COMMAND-LINE-DATE-EDITS.
      *-----------------------------


           MOVE '0'                   TO  WS-COMMAND-DATE-EDIT-IND.

           IF MIR-POL-NOTI-DT = SPACES
              OR MIR-POL-NOTI-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE 'CS01800009'      TO  WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO  WS-COMMAND-DATE-EDIT-IND
               GO TO 8000-COMMAND-LINE-DATE-EDITS-X
557660     END-IF.

           MOVE MIR-POL-NOTI-DT       TO  L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.

           IF L1640-NOT-VALID
               MOVE 'CS01800004'      TO  WGLOB-MSG-REF-INFO
               MOVE MIR-POL-NOTI-DT   TO  WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO  WS-COMMAND-DATE-EDIT-IND
           ELSE
               IF L1640-INTERNAL-DATE NOT > WGLOB-PROCESS-DATE
                   MOVE 'CS01800005'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE '1'           TO WS-COMMAND-DATE-EDIT-IND
557660         END-IF
557660     END-IF.

       8000-COMMAND-LINE-DATE-EDITS-X.
           EXIT.
      /
      *----------------------------
       8100-COMMAND-LINE-SEQ-EDITS.
      *----------------------------

           MOVE '0'                   TO  WS-COMMAND-SEQ-EDIT-IND.
      * VALIDATE NUMERIC FORMAT OF SEQUENCE NUMBER

013578     MOVE ZERO                  TO L0280-PRECISION.
013578     MOVE 3                     TO L0280-LENGTH.
013578     MOVE 3                     TO L0280-INPUT-SIZE.
013578     MOVE MIR-POL-NOTI-SEQ-NUM  TO L0280-INPUT-DATA.
013578     PERFORM  0280-1000-NUMERIC-EDIT
013578         THRU 0280-1000-NUMERIC-EDIT-X.

013578     IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-PIC-999
020874*        MOVE WS-PIC-999        TO MIR-POL-NOTI-SEQ-NUM
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-NOTI-SEQ-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-POL-NOTI-SEQ-NUM
013578     ELSE
013578*    IF  MIR-POL-NOTI-SEQ-NUM NOT NUMERIC
               MOVE 'CS01800002'      TO  WGLOB-MSG-REF-INFO
      * MSG: ' SEQUENCE NUMBER MUST BE NUMERIC
               PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU  0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO  WS-COMMAND-SEQ-EDIT-IND
557660     END-IF.

       8100-COMMAND-LINE-SEQ-EDITS-X.
           EXIT.
      *----------------------
       9500-DISPLAY-REQ-INFO.
      *----------------------


           MOVE 'Y'                   TO  WS-POL-REC-SW.

           MOVE MIR-POL-ID-BASE            TO  WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX            TO  WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF WPOL-IO-NOT-FOUND
               MOVE 'XS00000070'      TO  WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY          TO  WGLOB-MSG-PARM (1)
      * MSG: ' POLICY RECORD NOT FOUND'
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO  WS-POL-REC-SW
555080         MOVE SPACES            TO MIR-DV-OWN-CLI-NM
555080         MOVE SPACES            TO MIR-POL-CSTAT-CD
               GO TO 9500-DISPLAY-REQ-INFO-X
557660     END-IF.


           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

016440     IF  WS-BUS-FCN-CREATE
016440     OR  WS-BUS-FCN-UPDATE
016440     OR  WS-BUS-FCN-DELETE
016440         SET L5400-POL-XFER-UPDATE   TO TRUE
016440     END-IF.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.


           MOVE ZERO                  TO I.
           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.
           MOVE RPOL-POL-ID           TO L2430-POL-ID.
           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF L2430-RETRN-OK
557668*        MOVE L2430-CLI-NM-COMPRESSED TO MIR-DV-CLI-NM
557668         INITIALIZE                   L0620-INPUT-PARM-INFO
557668         IF L2430-CLI-SEX-COMPANY
557668            MOVE L2430-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
557668         ELSE
557668            MOVE L2430-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
557668            MOVE L2430-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
015705            MOVE L2430-CLI-MID-INIT-NM   TO
015705                              L0620-CLI-MID-INIT-NM
015705            MOVE L2430-CLI-SFX-NM        TO L0620-CLI-SFX-NM

557668         END-IF
557668         MOVE L2430-CLI-SEX-CD  TO L0620-CLI-SEX-CD
557668         PERFORM  0620-1000-FORMAT-SCREEN-NAME
557668             THRU 0620-1000-FORMAT-SCREEN-NAME-X
557668         MOVE L0620-SCREEN-NAME TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES            TO MIR-DV-OWN-CLI-NM
           END-IF.

           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD.

       9500-DISPLAY-REQ-INFO-X.
           EXIT.
      /
       9600-MOVE-RECORD-TO-SCREEN.

           MOVE RPOLN-POL-NOTI-DT     TO  L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO  MIR-POL-NOTI-DT-T (WS-LINE).

020874*    MOVE RPOLN-POL-NOTI-SEQ-NUM-N
020874*                               TO  WS-PIC-999.
020874*    MOVE WS-PIC-999         TO  MIR-POL-NOTI-SEQ-NUM-T (WS-LINE).
020874     MOVE RPOLN-POL-NOTI-SEQ-NUM-N TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-POL-NOTI-SEQ-NUM-T (WS-LINE)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA  TO MIR-POL-NOTI-SEQ-NUM-T (WS-LINE).
           MOVE RPOLN-POL-NOTI-REASN-CD
                                  TO  MIR-POL-NOTI-REASN-CD-T (WS-LINE).
           MOVE RPOLN-POL-NOTI-DEPT-ID
                                   TO  MIR-POL-NOTI-DEPT-ID-T (WS-LINE).
           MOVE RPOLN-POL-NOTI-QTY-N  TO  WS-PIC-99.
           MOVE WS-PIC-99             TO  MIR-POL-NOTI-QTY-T (WS-LINE).
020874*    MOVE RPOLN-POL-NOTI-MO-DUR-N
020874*                               TO  WS-PIC-99.
020874*    MOVE WS-PIC-99           TO  MIR-POL-NOTI-MO-DUR-T (WS-LINE).
020874     MOVE RPOLN-POL-NOTI-MO-DUR-N TO L0290-INPUT-V00.
020874     MOVE ZERO                  TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-POL-NOTI-MO-DUR-T (WS-LINE)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA  TO MIR-POL-NOTI-MO-DUR-T (WS-LINE).

010418     MOVE RPOL-SBSDRY-CO-ID     TO  MIR-SBSDRY-CO-ID.

       9600-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
       9700-BLANK-DATA-FIELDS.

           PERFORM  9710-MOVE-SPACES-TO-SCREEN
              THRU  9710-MOVE-SPACES-TO-SCREEN-X
                   VARYING WS-LINE FROM 1 BY 1
                       UNTIL WS-LINE > WS-MAX-SCREEN-LINES.

       9700-BLANK-DATA-FIELDS-X.
           EXIT.

       9710-MOVE-SPACES-TO-SCREEN.

           MOVE SPACES           TO  MIR-POL-NOTI-DT-T       (WS-LINE).
           MOVE SPACES           TO  MIR-POL-NOTI-SEQ-NUM-T  (WS-LINE).
           MOVE SPACES           TO  MIR-POL-NOTI-REASN-CD-T (WS-LINE).
           MOVE SPACES           TO  MIR-POL-NOTI-DEPT-ID-T  (WS-LINE).
           MOVE SPACES           TO  MIR-POL-NOTI-QTY-T      (WS-LINE).
           MOVE SPACES           TO  MIR-POL-NOTI-MO-DUR-T   (WS-LINE).

       9710-MOVE-SPACES-TO-SCREEN-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************

       9800-SETUP-MSIN-REFERENCE.

           MOVE SPACES                TO  WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO  WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                   TO  WGLOB-REF-POLICY-OR-CLIENT.

           MOVE MIR-POL-ID-BASE       TO  WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO  WGLOB-REF-POLICY-SUFFIX.

       9800-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-TRANS-NAME-DEFAULT       TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT         TO TRUE.
025970     SET WS-MAX-SCREEN-LINES-DEFAULT TO TRUE.
025970
025970     MOVE SPACES                 TO WWKDT-WORK-FIELDS.
025970
025970     MOVE MIR-BUS-FCN-ID         TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
      /
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
016503 COPY NCPPCVGS.
      /
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
014660*COPY XCPPMEXT.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      /
018764*COPY XCCL0260.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
025970 COPY XCPS8090.
016503 COPY CCPS0289.
018764*COPY CCCL0289.
018764 COPY CCPL0289.
020874 COPY XCPS0290.
020874 COPY XCPL0290.
      /
       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      /
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      /
       COPY CCPS5400.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
       COPY CCPENOTR.
      /
       COPY CCPEDEPT.
      /
025970 COPY CCPS0620.
557668 COPY CCPL0620.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
       COPY CCPCPOLN.
       COPY CCPBPOLN.
       COPY CCPAPOLN.
       COPY CCPNPOLN.
       COPY CCPUPOLN.
       COPY CCPXPOLN.
      /
016503 COPY CCPNCVG.
      /
       COPY CCPNEDIT.
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM0180                     **
      *****************************************************************
