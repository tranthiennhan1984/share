      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7354.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7354                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE LIST FUNCTION     **
      **            FOR THE PDCL TABLE                               **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
026055**  6.6       INTEREST ON DELAYED DEATH CLAIMS                 **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7354'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                          PIC X(04).
               88  WS-BUS-FCN-LIST                    VALUE '7354'.
           05  WS-SUB                                 PIC S9(04) BINARY.
           05  WS-CVG-NUM                             PIC S9(02) BINARY.
           05  WS-POL-DTHCLM-QTY                      PIC 9(02).
           05  WS-POL-DTHCLM-CD                       PIC X(01).
               88  WS-POL-DTHCLM-PEND-ERROR           VALUE '1'.
               88  WS-POL-DTHCLM-REV-PD-PARTL-PD      VALUE '2'.

       01  WS-CONSTANT-AREA.
           05  WS-MAX-BROWSE-LINES                    PIC S9(4)  BINARY.
               88  WS-MAX-BROWSE-LINES-DEFAULT        VALUE +12.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWLOCK.
       COPY CCWWINDX.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRCVG.
       COPY CCFWCVG.

       COPY CCFRPOL.
       COPY CCFWPOL.

       COPY CCFWPDCL.
       COPY CCFRPDCL.

       COPY CCWWCVGS.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWLDTLK.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7354.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7354'           TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *----------
       2000-LIST.
      *----------

           MOVE MIR-DV-POL-DTHCLM-CD        TO WS-POL-DTHCLM-CD.

      * VALIDATE KEY

           PERFORM  8000-EDIT-INFO
               THRU 8000-EDIT-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      * DISPLAY RECORDS

           PERFORM  2100-POL-PDCL-BROWSE
               THRU 2100-POL-PDCL-BROWSE-X.

       2000-LIST-X.
           EXIT.
      /
      *---------------------
       2100-POL-PDCL-BROWSE.
      *---------------------

           MOVE LOW-VALUES              TO WPDCL-KEY.
           MOVE WGLOB-COMPANY-CODE      TO WPDCL-CO-ID.
           MOVE MIR-POL-ID              TO WPDCL-POL-ID.
           MOVE MIR-DTHCLM-SEQ-NUM      TO WPDCL-DTHCLM-SEQ-NUM.

           MOVE WPDCL-KEY               TO WPDCL-ENDBR-KEY.
           MOVE +9999                   TO WPDCL-ENDBR-DTHCLM-SEQ-NUM.

           PERFORM  PDCL-1000-BROWSE
               THRU PDCL-1000-BROWSE-X.

           PERFORM  PDCL-2000-READ-NEXT
               THRU PDCL-2000-READ-NEXT-X.

           IF  WPDCL-IO-EOF
               PERFORM  PDCL-3000-END-BROWSE
                   THRU PDCL-3000-END-BROWSE-X
               PERFORM  2102-DISPLAY-NO-RECORD-MSG
                   THRU 2102-DISPLAY-NO-RECORD-MSG-X
               PERFORM  2106-MOVE-POL-DTHCLM-QTY
                   THRU 2106-MOVE-POL-DTHCLM-QTY-X
               GO TO 2100-POL-PDCL-BROWSE-X
           END-IF.

           MOVE ZERO                    TO WS-SUB.
           MOVE ZERO                    TO WS-POL-DTHCLM-QTY.

           PERFORM  2120-POL-PDCL-BROWSE-LOOP
               THRU 2120-POL-PDCL-BROWSE-LOOP-X
               UNTIL WS-SUB > WS-MAX-BROWSE-LINES
                  OR WPDCL-IO-EOF.

           IF  WPDCL-IO-EOF
               PERFORM  2104-DISPLAY-END-LIST-MSG
                   THRU 2104-DISPLAY-END-LIST-MSG-X
           ELSE
               MOVE RPDCL-DTHCLM-SEQ-NUM      TO MIR-DTHCLM-SEQ-NUM
               SET WGLOB-MORE-DATA-EXISTS     TO TRUE
      *MSG:    '** TO VIEW MORE DATA PRESS ENTER **'
               MOVE 'XS00000014'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  PDCL-3000-END-BROWSE
               THRU PDCL-3000-END-BROWSE-X.

           PERFORM  2106-MOVE-POL-DTHCLM-QTY
               THRU 2106-MOVE-POL-DTHCLM-QTY-X.

       2100-POL-PDCL-BROWSE-X.
           EXIT.

      *---------------------------
       2102-DISPLAY-NO-RECORD-MSG.
      *---------------------------

           IF  WS-POL-DTHCLM-REV-PD-PARTL-PD
      *MSG:   'NO PENDING DEATH CLAIM RECORDS NEED TO BE REVERSED'
               MOVE 'CS73540004'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE SPACE          TO MIR-DV-POL-DTHCLM-CD
               GO TO 2102-DISPLAY-NO-RECORD-MSG-X
           END-IF.

      *MSG:   'NO RECORDS FOUND TO DISPLAY'
           MOVE 'CS73540005'       TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       2102-DISPLAY-NO-RECORD-MSG-X.
           EXIT.

      *--------------------------
       2104-DISPLAY-END-LIST-MSG.
      *--------------------------

           IF  WS-POL-DTHCLM-REV-PD-PARTL-PD
           AND MIR-DTHCLM-STAT-CD-T (1) = SPACE
      *MSG:   'NO PENDING DEATH CLAIM RECORDS NEED TO BE REVERSED'
               MOVE 'CS73540004'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE SPACE          TO MIR-DV-POL-DTHCLM-CD
               GO TO 2104-DISPLAY-END-LIST-MSG-X
           END-IF.

      *MSG:   'END OF LIST'
           MOVE 'XS00000015'       TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           IF  WS-POL-DTHCLM-REV-PD-PARTL-PD
      *MSG:   'DEATH CLAIM REVERSED.  PLEASE REVERSE THE PAID PENDING
      *        DEATH CLAIM RECORD.'
               MOVE 'CS73540006'   TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2104-DISPLAY-END-LIST-MSG-X.
           EXIT.

      *-------------------------
       2106-MOVE-POL-DTHCLM-QTY.
      *-------------------------

           MOVE WS-POL-DTHCLM-QTY         TO L0290-INPUT-V00.
           MOVE ZERO                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-POL-DTHCLM-QTY
                                          TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA         TO MIR-DV-POL-DTHCLM-QTY.

       2106-MOVE-POL-DTHCLM-QTY-X.
           EXIT.

      *--------------------------
       2120-POL-PDCL-BROWSE-LOOP.
      *--------------------------

      * IF MIR-DV-POL-DTHCLM-CD = 1, DISPLAY RECORDS WITH
      * STATUS = PENDING AND ERROR

           IF  WS-POL-DTHCLM-PEND-ERROR
               PERFORM  2140-DISPLAY-PEND-ERROR-REC
                   THRU 2140-DISPLAY-PEND-ERROR-REC-X
               GO TO 2120-POL-PDCL-BROWSE-LOOP-X
           END-IF.

      * IF MIR-DV-POL-DTHCLM-CD = 2, DISPLAY RECORDS WITH
      * STATUS = PAID AND PARTIALLY PAID

           IF  WS-POL-DTHCLM-REV-PD-PARTL-PD
               PERFORM  2160-DISPLAY-PD-PARTL-PD-REC
                   THRU 2160-DISPLAY-PD-PARTL-PD-REC-X
               GO TO 2120-POL-PDCL-BROWSE-LOOP-X
           END-IF.

      * MOVE RECORD TO MIR

           ADD +1                     TO WS-SUB.
           IF  WS-SUB > WS-MAX-BROWSE-LINES
               GO TO 2120-POL-PDCL-BROWSE-LOOP-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  PDCL-2000-READ-NEXT
               THRU PDCL-2000-READ-NEXT-X.

       2120-POL-PDCL-BROWSE-LOOP-X.
           EXIT.

      *----------------------------
       2140-DISPLAY-PEND-ERROR-REC.
      *----------------------------

      * MATCH COVERAGE NUM AND DISPLAY RECORDS WITH STATUS = PAID OR
      * PARTIALLY PAID

           IF  RPDCL-CVG-NUM-N = WS-CVG-NUM
           AND (RPDCL-DTHCLM-STAT-PEND
           OR   RPDCL-DTHCLM-STAT-ERROR)
               ADD +1                 TO WS-POL-DTHCLM-QTY
           ELSE
               PERFORM  PDCL-2000-READ-NEXT
                   THRU PDCL-2000-READ-NEXT-X
               GO TO 2140-DISPLAY-PEND-ERROR-REC-X
           END-IF.

      * MOVE RECORD TO MIR

           ADD +1                     TO WS-SUB.
           IF  WS-SUB > WS-MAX-BROWSE-LINES
               GO TO 2140-DISPLAY-PEND-ERROR-REC-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  PDCL-2000-READ-NEXT
               THRU PDCL-2000-READ-NEXT-X.

       2140-DISPLAY-PEND-ERROR-REC-X.
           EXIT.

      *-----------------------------
       2160-DISPLAY-PD-PARTL-PD-REC.
      *-----------------------------

      * MATCH COVERAGE NUM AND DISPLAY RECORDS WITH STATUS = PAID OR
      * PARTIALLY PAID

           IF  RPDCL-CVG-NUM-N = WS-CVG-NUM
           AND (RPDCL-DTHCLM-STAT-PD
           OR   RPDCL-DTHCLM-STAT-PARTL-PD)
               CONTINUE
           ELSE
               PERFORM  PDCL-2000-READ-NEXT
                   THRU PDCL-2000-READ-NEXT-X
               GO TO 2160-DISPLAY-PD-PARTL-PD-REC-X
           END-IF.

      * MOVE RECORD TO MIR
           ADD +1                     TO WS-SUB.
           IF  WS-SUB > WS-MAX-BROWSE-LINES
               GO TO 2160-DISPLAY-PD-PARTL-PD-REC-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  PDCL-2000-READ-NEXT
               THRU PDCL-2000-READ-NEXT-X.

       2160-DISPLAY-PD-PARTL-PD-REC-X.
           EXIT.

      *---------------
       8000-EDIT-INFO.
      *---------------

      * VALIDATE KEY INFOMATION

            PERFORM  8010-EDIT-KEY-INFO
                THRU 8010-EDIT-KEY-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8000-EDIT-INFO-X
           END-IF.

       8000-EDIT-INFO-X.
           EXIT.

      *-------------------
       8010-EDIT-KEY-INFO.
      *-------------------
      *
      * VALIDATE POL NUMBER
      *
           MOVE MIR-POL-ID-BASE            TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX             TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'XS00000001'           TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID            TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8010-EDIT-KEY-INFO-X
           END-IF.
      *
      *  VALIDATE SEQUENCE NUMBER
      *
           IF  MIR-DTHCLM-SEQ-NUM = SPACE
               MOVE ZEROES                 TO MIR-DTHCLM-SEQ-NUM
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED    TO TRUE.
           MOVE ZERO                       TO L0280-PRECISION.
           MOVE 4                          TO L0280-LENGTH.
           MOVE 4                          TO L0280-INPUT-SIZE.
           MOVE MIR-DTHCLM-SEQ-NUM         TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG:     'SEQUENCE NUMBER MUST BE VALID NUMERIC'
               MOVE 'CS73540003'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8010-EDIT-KEY-INFO-X
           END-IF.

      * VALIDATE MIR-CVG-NUM IF MIR-DV-POL-DTHCML-CD = '1' OR '2'

           IF  WS-POL-DTHCLM-PEND-ERROR
           OR  WS-POL-DTHCLM-REV-PD-PARTL-PD
               CONTINUE
           ELSE
               GO TO 8010-EDIT-KEY-INFO-X
           END-IF.

           IF  MIR-CVG-NUM = SPACES
               MOVE ZERO                   TO WS-CVG-NUM
               GO TO 8010-EDIT-KEY-INFO-X
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED    TO TRUE.
           MOVE ZERO                       TO L0280-PRECISION.
           MOVE 2                          TO L0280-LENGTH.
           MOVE 2                          TO L0280-INPUT-SIZE.
           MOVE MIR-CVG-NUM                TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG:     'COVERAGE NUMBER MUST BE VALID NUMERIC OR SPACES'
               MOVE 'CS73540001'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8010-EDIT-KEY-INFO-X
           ELSE
               MOVE L0280-OUTPUT           TO WS-CVG-NUM
           END-IF.

       8010-EDIT-KEY-INFO-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-CVG-NUM-G.
           MOVE SPACES                   TO MIR-DTHCLM-SEQ-NUM-G.
           MOVE SPACES                   TO MIR-DTHCLM-STAT-CD-G.
           MOVE SPACES                   TO MIR-DTHCLM-AMT-G.
           MOVE SPACES                   TO MIR-DTHCLM-ADDL-AMT-G.
           MOVE SPACES                   TO MIR-DTHCLM-OVRID-IND-G.
           MOVE SPACES                   TO MIR-DTHCLM-INT-DT-CD-G.
           MOVE SPACES                   TO MIR-DTHCLM-INT-STRT-DT-G.
           MOVE SPACES                   TO MIR-DTHCLM-INT-PCT-G.
           MOVE SPACES                   TO MIR-DTHCLM-CREAT-DT-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.

      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE RPDCL-CVG-NUM         TO MIR-CVG-NUM-T (WS-SUB).

           MOVE RPDCL-DTHCLM-SEQ-NUM  TO L0290-INPUT-V00.
           MOVE ZERO                  TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DTHCLM-SEQ-NUM-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DTHCLM-SEQ-NUM-T (WS-SUB).

           MOVE RPDCL-DTHCLM-STAT-CD  TO MIR-DTHCLM-STAT-CD-T (WS-SUB).

           MOVE RPDCL-DTHCLM-AMT      TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DTHCLM-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DTHCLM-AMT-T (WS-SUB).

           MOVE RPDCL-DTHCLM-ADDL-AMT TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DTHCLM-ADDL-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DTHCLM-ADDL-AMT-T (WS-SUB).

           MOVE RPDCL-DTHCLM-OVRID-IND
                                     TO MIR-DTHCLM-OVRID-IND-T (WS-SUB).
           MOVE RPDCL-DTHCLM-INT-DT-CD
                                     TO MIR-DTHCLM-INT-DT-CD-T (WS-SUB).

           MOVE RPDCL-DTHCLM-INT-STRT-DT TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE      TO
                                      MIR-DTHCLM-INT-STRT-DT-T (WS-SUB).

           MOVE RPDCL-DTHCLM-INT-PCT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DTHCLM-INT-PCT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DTHCLM-INT-PCT-T (WS-SUB).

           MOVE RPDCL-DTHCLM-CREAT-DT    TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-DTHCLM-CREAT-DT-T (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.
           MOVE MIR-POL-ID-BASE          TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX           TO WGLOB-REF-POLICY-SUFFIX.
           SET WGLOB-REF-POLICY          TO TRUE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
           INITIALIZE WLOCK-TWRK-OTHER-INFO.
           INITIALIZE FREQUENTLY-USED-INDICES.

           SET WS-MAX-BROWSE-LINES-DEFAULT TO TRUE.
           SET MIR-RETRN-OK                TO TRUE.

           MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0260.

       COPY XCPS0280.
       COPY XCPL0280.

       COPY XCPS0290.
       COPY XCPL0290.

       COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.

       COPY CCPBPDCL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM7354                     **
      *****************************************************************
