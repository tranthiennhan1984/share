      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7380.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7380                                         **
      **  REMARKS:  POLT - POLICY TAX HISTORY INQUIRY MODULE         **
      **                                                             **
      **  DOMAIN :  TX                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
029059**  7.1       CASH VALUE ACCUMULATION TEST                     **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7380'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.
       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04)
                                                VALUE SPACES.
               88  WS-BUS-FCN-RETRIEVE          VALUE '7380'.
           05  WS-TWRK-KEY                  PIC X(04)
                                                VALUE'7380'.
           05  WS-PCHST-SEQ-NUM-MAX         PIC S9(05) COMP-3.
           05  WS-CDA-SEQ-NUM-MAX           PIC S9(04) COMP-3.
           05  WS-POL-PAYO-NUM-MAX          PIC S9(06) COMP-3.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWINDX.
       COPY XCWWWKDT.
       COPY XCWLDTLK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRPOL.
       COPY CCFWPOL.
       COPY CCFRPOLT.
       COPY CCFWPOLT.
       COPY CCFWCVG.
       COPY CCFRCVG.
       COPY CCWWCVGS.
       COPY CCWLPGA.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWL8090.
       COPY CCWL0620.
       COPY CCWL2430.
       COPY XCWL0290.
       COPY XCWL0280.
       COPY XCWL1640.
       COPY XCWL1660.
       COPY CCWWLOCK.
       COPY CCWL2626.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7380.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.
      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-POL-ID                    TO WPOL-POL-ID.

           PERFORM  2100-INITIAL-SCREEN-EDITS
               THRU 2100-INITIAL-SCREEN-EDITS-X.

           IF  WGLOB-MSG-ERROR-SW  =  1
               GO TO 1000-PROCESS-REQUEST-X
           END-IF.

           MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7380'           TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-------------
       2000-RETRIEVE.
      *-------------

           MOVE MIR-POL-ID               TO WPOLT-POL-ID.

           PERFORM  POLT-1000-READ
               THRU POLT-1000-READ-X.

           IF  WPOLT-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WPOLT-KEY            TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

      *  MOVE RECORD INFORMATION TO THE MIR

           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X.

       2000-RETRIEVE-X.
           EXIT.
      /
      *-------------------------
       2100-INITIAL-SCREEN-EDITS.
      *-------------------------

      * VALIDATE THE POLICY NUMBER

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF NOT WPOL-IO-OK
      *MSG: POLICY NOT ON FILE
               MOVE 'CS00000019'         TO WGLOB-MSG-REF-INFO
               PERFORM  9000-BLANK-DATA-FIELDS
                   THRU 9000-BLANK-DATA-FIELDS-X
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
           ELSE
               PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
                   THRU CVGS-1000-LOAD-CVGS-ARRAY-X
           END-IF.

      * VALIDATE EFFECTIVE DATE

           IF  MIR-POL-TAX-EFF-DT  = SPACES
               MOVE WWKDT-LOW-DT         TO WPOLT-POL-TAX-EFF-DT
           ELSE
               MOVE MIR-POL-TAX-EFF-DT   TO L1640-EXTERNAL-DATE
               PERFORM  1640-7000-MIR-TO-INT
                   THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-NOT-VALID
      *            MESSAGE - INVALID EFFECTIVE DATE - REENTER
                   MOVE 'XS00000355'     TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE L1640-INTERNAL-DATE 
                                         TO WPOLT-POL-TAX-EFF-DT
               END-IF
           END-IF.

      * VALIDATE SEQUENCE NUMBER

           MOVE ZERO                     TO L0280-PRECISION.
           MOVE LENGTH OF MIR-POL-TAX-SEQ-NUM
                                         TO L0280-LENGTH.
           MOVE LENGTH OF MIR-POL-TAX-SEQ-NUM
                                         TO L0280-INPUT-SIZE.
           MOVE MIR-POL-TAX-SEQ-NUM      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT         TO WPOLT-POL-TAX-SEQ-NUM
           ELSE
      *MSG:    THE SEQUENCE NUMBER MUST BE NUMERIC.
               MOVE 'CS73800001'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-TAX-SEQ-NUM  TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2100-INITIAL-SCREEN-EDITS-X.
           EXIT.
      /
      *----------------------
       9000-BLANK-DATA-FIELDS.
      *----------------------

           MOVE SPACES            TO  MIR-POL-TAX-STAT-CD.
           MOVE SPACES            TO  MIR-POL-TAX-EVNT-CD.
           MOVE SPACES            TO  MIR-POL-TAX-ACTV-CD.
           MOVE SPACES            TO  MIR-PCHST-EFF-IDT-NUM.
           MOVE SPACES            TO  MIR-PCHST-SEQ-NUM.
           MOVE SPACES            TO  MIR-CDA-TYP-CD.
           MOVE SPACES            TO  MIR-CDA-EFF-IDT-NUM.
           MOVE SPACES            TO  MIR-CDA-SEQ-NUM.
           MOVE SPACES            TO  MIR-POL-PAYO-NUM.
           MOVE SPACES            TO  MIR-ORIG-SEQ-NUM.
           MOVE SPACES            TO  MIR-TAXBL-PAYO-AMT.
           MOVE SPACES            TO  MIR-TAXBL-PAYO-YTD-AMT.
           MOVE SPACES            TO  MIR-TAXBL-PAYO-PYR-AMT.
           MOVE SPACES            TO  MIR-TAXBL-PAYO-NYR-AMT.
           MOVE SPACES            TO  MIR-PROV-TAXWH-AMT.
           MOVE SPACES            TO  MIR-PROV-TAXWH-YTD-AMT.
           MOVE SPACES            TO  MIR-PROV-TAXWH-NYR-AMT.
           MOVE SPACES            TO  MIR-PROV-TAX-SUSP-AMT.
           MOVE SPACES            TO  MIR-PAYO-FTAXWH-AMT.
           MOVE SPACES            TO  MIR-FED-TAXWH-YTD-AMT.
           MOVE SPACES            TO  MIR-FED-TAXWH-NYR-AMT.
           MOVE SPACES            TO  MIR-FED-TAXWH-PYR-AMT.
           MOVE SPACES            TO  MIR-FED-TAXWH-ADDL-AMT.
           MOVE SPACES            TO  MIR-FED-TAX-SUSP-AMT.
           MOVE SPACES            TO  MIR-FTAXWH-INSTR-CD.
           MOVE SPACES            TO  MIR-FTAXWH-INSTR-AMT.
           MOVE SPACES            TO  MIR-FTAXWH-INSTR-PCT.
           MOVE SPACES            TO  MIR-FTAXWH-RQST-CD.
           MOVE SPACES            TO  MIR-FTAXWH-RQST-AMT.
           MOVE SPACES            TO  MIR-FTAXWH-RQST-PCT.
           MOVE SPACES            TO  MIR-FTAXWH-AMT.
           MOVE SPACES            TO  MIR-LTAXWH-LTD-AMT.
           MOVE SPACES            TO  MIR-LTAXWH-INSTR-CD.
           MOVE SPACES            TO  MIR-LTAXWH-INSTR-AMT.
           MOVE SPACES            TO  MIR-LTAXWH-INSTR-PCT.
           MOVE SPACES            TO  MIR-LTAXWH-RQST-CD.
           MOVE SPACES            TO  MIR-LTAXWH-RQST-AMT.
           MOVE SPACES            TO  MIR-LTAXWH-RQST-PCT.
           MOVE SPACES            TO  MIR-LTAXWH-AMT.
           MOVE SPACES            TO  MIR-IA-TAX-EXCL-PCT.
           MOVE SPACES            TO  MIR-NTAXBL-PAY-YTD-AMT.
           MOVE SPACES            TO  MIR-NTAXBL-PAY-LTD-AMT.
           MOVE SPACES            TO  MIR-TAXBL-PAYO-LTD-AMT.
           MOVE SPACES            TO  MIR-IA-REMN-INV-AMT.
           MOVE SPACES            TO  MIR-TAXBL-PREM-PD-AMT.
           MOVE SPACES            TO  MIR-DPOS-PREM-LTD-AMT.
           MOVE SPACES            TO  MIR-TAX-SUPP-PREM-AMT.
           MOVE SPACES            TO  MIR-TAX-TRNST-ELE-AMT.
           MOVE SPACES            TO  MIR-TAX-NCPI-AMT.
           MOVE SPACES            TO  MIR-TAX-LOAN-INT-AMT.
           MOVE SPACES            TO  MIR-TAX-ACQ-COST-AMT.
           MOVE SPACES            TO  MIR-TAX-ACRU-AMT.
           MOVE SPACES            TO  MIR-TAX-XPCT-PMT-AMT.
           MOVE SPACES            TO  MIR-POL-TAX-CV-AMT.
           MOVE SPACES            TO  MIR-POL-TAX-ACB-AMT.
           MOVE SPACES            TO  MIR-TAX-ANNV-ACB-AMT.
           MOVE SPACES            TO  MIR-POL-SIDFND-ACB-AMT.
           MOVE SPACES            TO  MIR-TAX-DISP-YTD-AMT.
           MOVE SPACES            TO  MIR-LOAN-DISP-YTD-AMT.
           MOVE SPACES            TO  MIR-LOAN-DISP-TAX-AMT.
           MOVE SPACES            TO  MIR-PREV-DISP-TAX-AMT.
           MOVE SPACES            TO  MIR-TAX-PREV-DISP-AMT.
           MOVE SPACES            TO  MIR-PREV-LOAN-DISP-AMT.
           MOVE SPACES            TO  MIR-TAX-MORT-GAIN-AMT.
           MOVE SPACES            TO  MIR-TAX-MORT-LOS-AMT.
           MOVE SPACES            TO  MIR-TAX-LOAN-DEDBL-AMT.
           MOVE SPACES            TO  MIR-TAX-LOAN-DOD-AMT.
           MOVE SPACES            TO  MIR-TAX-1035-ACB-AMT.
           MOVE SPACES            TO  MIR-TAX-1035-PD-AMT.
           MOVE SPACES            TO  MIR-TAXBL-GAIN-81-AMT.
           MOVE SPACES            TO  MIR-TAX-GAIN-AMT.
029059     MOVE SPACES            TO  MIR-CVAT-NSP-AMT.
           MOVE SPACES            TO  MIR-MAX-TXEMP-INCR-PCT.
           MOVE SPACES            TO  MIR-MAX-TXEMP-DECR-PCT.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *-----------------------
       9200-MOVE-RECORD-TO-MIR.
      *-----------------------

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  L2430-RETRN-OK
               INITIALIZE L0620-INPUT-PARM-INFO
               IF  L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES                    TO MIR-DV-OWN-CLI-NM
           END-IF.

      *    MOVE THE TRANSACTION INFORMATION TO SCREEN

           MOVE RPOLT-POL-TAX-STAT-CD         TO MIR-POL-TAX-STAT-CD.
           MOVE RPOLT-POL-TAX-EVNT-CD         TO MIR-POL-TAX-EVNT-CD.
           MOVE RPOLT-POL-TAX-ACTV-CD         TO MIR-POL-TAX-ACTV-CD.

           IF  RPOLT-PCHST-EFF-IDT-NUM = SPACES
               MOVE WWKDT-ZERO-DT             TO MIR-PCHST-EFF-IDT-NUM
           ELSE
               MOVE RPOLT-PCHST-EFF-IDT-NUM   TO L1660-INVERTED-DATE
               PERFORM  1660-3000-CONVERT-INV-TO-INT
                   THRU 1660-3000-CONVERT-INV-TO-INT-X
               MOVE L1660-INTERNAL-DATE       TO L1640-INTERNAL-DATE
               PERFORM  1640-8000-INTERNAL-TO-MIR
                   THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE       TO MIR-PCHST-EFF-IDT-NUM
           END-IF.

           IF  RPOLT-PCHST-SEQ-NUM = ZEROS
               MOVE ZEROS                     TO MIR-PCHST-SEQ-NUM
           ELSE     
               COMPUTE L0290-INPUT-V00   = WS-PCHST-SEQ-NUM-MAX
                                         - RPOLT-PCHST-SEQ-NUM
               MOVE 0                         TO L0290-PRECISION
               MOVE LENGTH OF MIR-PCHST-SEQ-NUM   
                                              TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA         TO MIR-PCHST-SEQ-NUM
           END-IF.

           MOVE RPOLT-CDA-TYP-CD              TO MIR-CDA-TYP-CD.

           IF  RPOLT-CDA-EFF-IDT-NUM = SPACES
               MOVE WWKDT-ZERO-DT             TO MIR-CDA-EFF-IDT-NUM
           ELSE
               MOVE RPOLT-CDA-EFF-IDT-NUM     TO L1660-INVERTED-DATE
               PERFORM  1660-3000-CONVERT-INV-TO-INT
                   THRU 1660-3000-CONVERT-INV-TO-INT-X
               MOVE L1660-INTERNAL-DATE       TO L1640-INTERNAL-DATE
               PERFORM  1640-8000-INTERNAL-TO-MIR
                   THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE       TO MIR-CDA-EFF-IDT-NUM
           END-IF.

           IF  RPOLT-CDA-SEQ-NUM = ZEROS
               MOVE ZEROS                     TO MIR-CDA-SEQ-NUM
           ELSE  
               COMPUTE L0290-INPUT-V00   = WS-CDA-SEQ-NUM-MAX
                                         - RPOLT-CDA-SEQ-NUM
               MOVE 0                         TO L0290-PRECISION
               MOVE LENGTH OF MIR-CDA-SEQ-NUM TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA         TO MIR-CDA-SEQ-NUM
           END-IF.

           IF  RPOLT-POL-PAYO-NUM = ZEROS
               MOVE ZEROS                     TO MIR-POL-PAYO-NUM
           ELSE  
               COMPUTE L0290-INPUT-V00   = WS-POL-PAYO-NUM-MAX
                                         - RPOLT-POL-PAYO-NUM
               MOVE 0                         TO L0290-PRECISION
               MOVE LENGTH OF MIR-POL-PAYO-NUM 
                                              TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA         TO MIR-POL-PAYO-NUM
           END-IF.

           MOVE RPOLT-ORIG-SEQ-NUM            TO MIR-ORIG-SEQ-NUM.

      *    MOVE THE POLICY TAX INFORMATION TO SCREEN

           PERFORM  9210-MOVE-WDRAW-PROV-INFO
               THRU 9210-MOVE-WDRAW-PROV-INFO-X.

           PERFORM  9220-MOVE-FED-TAX-INFO
               THRU 9220-MOVE-FED-TAX-INFO-X.

           PERFORM  9230-MOVE-LOC-TAX-INFO
               THRU 9230-MOVE-LOC-TAX-INFO-X.

           PERFORM  9240-MOVE-IA-TAX-INFO
               THRU 9240-MOVE-IA-TAX-INFO-X.

           PERFORM  9250-MOVE-ACB-INFO
               THRU 9250-MOVE-ACB-INFO-X.

           PERFORM  9260-MOVE-GDLN-INFO
               THRU 9260-MOVE-GDLN-INFO-X.

           PERFORM  9270-MOVE-EXEMT-INFO
               THRU 9270-MOVE-EXEMT-INFO-X.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *-------------------------
       9210-MOVE-WDRAW-PROV-INFO.
      *-------------------------

      *    MOVE THE POLICY TAX WITHDRAWALS INFORMATION TO SCREEN

           MOVE RPOLT-TAXBL-PAYO-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAXBL-PAYO-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAXBL-PAYO-AMT.
           MOVE RPOLT-TAXBL-PAYO-YTD-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAXBL-PAYO-YTD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAXBL-PAYO-YTD-AMT.
           MOVE RPOLT-TAXBL-PAYO-PYR-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAXBL-PAYO-PYR-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAXBL-PAYO-PYR-AMT.
           MOVE RPOLT-TAXBL-PAYO-NYR-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAXBL-PAYO-NYR-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAXBL-PAYO-NYR-AMT.

      *    MOVE THE POLICY PROVINCIAL TAX INFORMATION TO SCREEN

           MOVE RPOLT-PROV-TAXWH-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PROV-TAXWH-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-PROV-TAXWH-AMT.
           MOVE RPOLT-PROV-TAXWH-YTD-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PROV-TAXWH-YTD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-PROV-TAXWH-YTD-AMT.
           MOVE RPOLT-PROV-TAXWH-NYR-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PROV-TAXWH-NYR-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-PROV-TAXWH-NYR-AMT.
           MOVE RPOLT-PROV-TAX-SUSP-AMT  TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PROV-TAX-SUSP-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-PROV-TAX-SUSP-AMT.

       9210-MOVE-WDRAW-PROV-INFO-X.
           EXIT.
      /
      *----------------------
       9220-MOVE-FED-TAX-INFO.
      *----------------------

      *    MOVE THE POLICY FEDERAL TAX WITHHOLDING INFORMATION TO SCREEN

           MOVE RPOLT-PAYO-FTAXWH-AMT    TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PAYO-FTAXWH-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-PAYO-FTAXWH-AMT.
           MOVE RPOLT-FED-TAXWH-YTD-AMT  TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FED-TAXWH-YTD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-FED-TAXWH-YTD-AMT.
           MOVE RPOLT-FED-TAXWH-NYR-AMT  TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FED-TAXWH-NYR-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-FED-TAXWH-NYR-AMT.
           MOVE RPOLT-FED-TAXWH-PYR-AMT  TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FED-TAXWH-PYR-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-FED-TAXWH-PYR-AMT.
           MOVE RPOLT-FED-TAXWH-ADDL-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FED-TAXWH-ADDL-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-FED-TAXWH-ADDL-AMT.
           MOVE RPOLT-FED-TAX-SUSP-AMT   TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FED-TAX-SUSP-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-FED-TAX-SUSP-AMT.
           MOVE RPOLT-FTAXWH-INSTR-CD    TO MIR-FTAXWH-INSTR-CD.
           MOVE RPOLT-FTAXWH-INSTR-AMT   TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FTAXWH-INSTR-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-FTAXWH-INSTR-AMT.
           MOVE RPOLT-FTAXWH-INSTR-PCT   TO L0290-INPUT-V04.
           MOVE 4                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FTAXWH-INSTR-PCT
                                         TO L0290-MAX-OUT-LEN.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-FTAXWH-INSTR-PCT.
           MOVE RPOLT-FTAXWH-RQST-CD     TO MIR-FTAXWH-RQST-CD.
           MOVE RPOLT-FTAXWH-RQST-AMT    TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FTAXWH-RQST-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-FTAXWH-RQST-AMT.
           MOVE RPOLT-FTAXWH-RQST-PCT    TO L0290-INPUT-V04.
           MOVE 4                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FTAXWH-RQST-PCT
                                         TO L0290-MAX-OUT-LEN.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-FTAXWH-RQST-PCT.
           MOVE RPOLT-FTAXWH-AMT         TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FTAXWH-AMT TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-FTAXWH-AMT.

       9220-MOVE-FED-TAX-INFO-X.
           EXIT.
      /
      *----------------------
       9230-MOVE-LOC-TAX-INFO.
      *----------------------

      *    MOVE THE LOCATION TAX WITHHOLDING INFORMATION TO SCREEN

           MOVE RPOLT-LTAXWH-LTD-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-LTAXWH-LTD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-LTAXWH-LTD-AMT.
           MOVE RPOLT-LTAXWH-INSTR-CD    TO  MIR-LTAXWH-INSTR-CD.
           MOVE RPOLT-LTAXWH-INSTR-AMT   TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-LTAXWH-INSTR-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-LTAXWH-INSTR-AMT.
           MOVE RPOLT-LTAXWH-INSTR-PCT   TO L0290-INPUT-V04.
           MOVE 4                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-LTAXWH-INSTR-PCT
                                         TO L0290-MAX-OUT-LEN.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-LTAXWH-INSTR-PCT.
           MOVE RPOLT-LTAXWH-RQST-CD     TO  MIR-LTAXWH-RQST-CD.
           MOVE RPOLT-LTAXWH-RQST-AMT    TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-LTAXWH-RQST-AMT.
           MOVE RPOLT-LTAXWH-RQST-PCT    TO L0290-INPUT-V04.
           MOVE 4                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-LTAXWH-RQST-PCT
                                         TO L0290-MAX-OUT-LEN.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-LTAXWH-RQST-PCT.
           MOVE RPOLT-LTAXWH-AMT         TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-LTAXWH-AMT TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-LTAXWH-AMT.

       9230-MOVE-LOC-TAX-INFO-X.
           EXIT.
      /
      *---------------------
       9240-MOVE-IA-TAX-INFO.
      *---------------------

      *    MOVE THE US IMMEDIATE ANNUITY TAX INFORMATION TO SCREEN

           MOVE RPOLT-IA-TAX-EXCL-PCT    TO L0290-INPUT-V04.
           MOVE 4                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-IA-TAX-EXCL-PCT
                                         TO L0290-MAX-OUT-LEN.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-IA-TAX-EXCL-PCT.
           MOVE RPOLT-NTAXBL-PAY-YTD-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-NTAXBL-PAY-YTD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-NTAXBL-PAY-YTD-AMT.
           MOVE RPOLT-NTAXBL-PAY-LTD-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-NTAXBL-PAY-LTD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-NTAXBL-PAY-LTD-AMT.
           MOVE RPOLT-TAXBL-PAYO-LTD-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAXBL-PAYO-LTD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAXBL-PAYO-LTD-AMT.
           MOVE RPOLT-IA-REMN-INV-AMT    TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-IA-REMN-INV-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-IA-REMN-INV-AMT.
           MOVE RPOLT-TAXBL-PREM-PD-AMT  TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAXBL-PREM-PD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAXBL-PREM-PD-AMT.

       9240-MOVE-IA-TAX-INFO-X.
           EXIT.
      /
      *------------------
       9250-MOVE-ACB-INFO.
      *------------------

      *    MOVE THE ACB - MISCELLANEOUS TAX INFORMATION TO SCREEN

           MOVE RPOLT-DPOS-PREM-LTD-AMT  TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DPOS-PREM-LTD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-DPOS-PREM-LTD-AMT.
           MOVE RPOLT-TAX-SUPP-PREM-AMT  TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-SUPP-PREM-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-SUPP-PREM-AMT.
           MOVE RPOLT-TAX-TRNST-ELE-AMT  TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-TRNST-ELE-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-TRNST-ELE-AMT.
           MOVE RPOLT-TAX-NCPI-AMT       TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-NCPI-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-NCPI-AMT.
           MOVE RPOLT-TAX-LOAN-INT-AMT   TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-LOAN-INT-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-LOAN-INT-AMT.
           MOVE RPOLT-TAX-ACQ-COST-AMT   TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-ACQ-COST-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-ACQ-COST-AMT.
           MOVE RPOLT-TAX-ACRU-AMT       TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-ACRU-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-ACRU-AMT.
           MOVE RPOLT-TAX-XPCT-PMT-AMT   TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-XPCT-PMT-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-XPCT-PMT-AMT.
           MOVE RPOLT-POL-TAX-CV-AMT     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-TAX-CV-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-POL-TAX-CV-AMT.
           MOVE RPOLT-POL-TAX-ACB-AMT    TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-TAX-ACB-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-POL-TAX-ACB-AMT.

      *    MOVE THE ACB - ADJUSTED COST BASIS INFORMATION TO SCREEN

           MOVE RPOLT-TAX-ANNV-ACB-AMT   TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-ANNV-ACB-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-ANNV-ACB-AMT.
           MOVE RPOLT-POL-SIDFND-ACB-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-SIDFND-ACB-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-POL-SIDFND-ACB-AMT.

      *    MOVE THE ACB - DISPOSITIONS INFORMATION TO SCREEN

           MOVE RPOLT-TAX-DISP-YTD-AMT   TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-DISP-YTD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-DISP-YTD-AMT.
           MOVE RPOLT-LOAN-DISP-YTD-AMT  TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-LOAN-DISP-YTD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-LOAN-DISP-YTD-AMT.
           MOVE RPOLT-LOAN-DISP-TAX-AMT  TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-LOAN-DISP-TAX-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-LOAN-DISP-TAX-AMT.
           MOVE RPOLT-PREV-DISP-TAX-AMT  TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PREV-DISP-TAX-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-PREV-DISP-TAX-AMT.
           MOVE RPOLT-TAX-PREV-DISP-AMT  TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-PREV-DISP-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-PREV-DISP-AMT.
           MOVE RPOLT-PREV-LOAN-DISP-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PREV-LOAN-DISP-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-PREV-LOAN-DISP-AMT.

      *    MOVE THE ACB - AFTER ANNUITIZATION INFORMATION TO SCREEN

           MOVE RPOLT-TAX-MORT-GAIN-AMT  TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-MORT-GAIN-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-MORT-GAIN-AMT.
           MOVE RPOLT-TAX-MORT-LOS-AMT   TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-MORT-LOS-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-MORT-LOS-AMT.

       9250-MOVE-ACB-INFO-X.
           EXIT.
      /
      *-------------------
       9260-MOVE-GDLN-INFO.
      *-------------------

      *    MOVE THE GUIDELINE - LOAN INFORMATION TO SCREEN

           MOVE RPOLT-TAX-LOAN-DEDBL-AMT TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-LOAN-DEDBL-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-LOAN-DEDBL-AMT.
           MOVE RPOLT-TAX-LOAN-DOD-AMT   TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-LOAN-DOD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-LOAN-DOD-AMT.

      *    GUIDELINE - 1035 EXCHANGE AND QUALIFIED TRANSFERS INFORMATION

           MOVE RPOLT-TAX-1035-ACB-AMT   TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-1035-ACB-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-1035-ACB-AMT.
           MOVE RPOLT-TAX-1035-PD-AMT    TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-1035-PD-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-1035-PD-AMT.

      *    MOVE THE GUIDELINE - TAX DETAILS INFORMATION TO SCREEN

           MOVE RPOLT-TAXBL-GAIN-81-AMT  TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAXBL-GAIN-81-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAXBL-GAIN-81-AMT.
           MOVE RPOLT-TAX-GAIN-AMT       TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-TAX-GAIN-AMT
                                         TO L0290-MAX-OUT-LEN.
           SET  L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-TAX-GAIN-AMT.
029059
029059*    CASH VALUE ACCUMULATION TEST NET SINGLE PREMIUM AMOUNT
029059
029059     MOVE RPOLT-CVAT-NSP-AMT       TO L0290-INPUT-V02.
029059     MOVE 2                        TO L0290-PRECISION.
029059     MOVE LENGTH OF MIR-CVAT-NSP-AMT
029059                                   TO L0290-MAX-OUT-LEN.
029059     SET  L0290-SIGN-DISPLAY       TO TRUE.
029059
029059     PERFORM  0290-2000-FORMAT-FOR-MIR
029059         THRU 0290-2000-FORMAT-FOR-MIR-X.
029059
029059     MOVE L0290-OUTPUT-DATA        TO MIR-CVAT-NSP-AMT.

       9260-MOVE-GDLN-INFO-X.
           EXIT.
      /
      *--------------------
       9270-MOVE-EXEMT-INFO.
      *--------------------

           MOVE RPOLT-MAX-TXEMP-INCR-PCT TO L0290-INPUT-V04.
           MOVE 4                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-MAX-TXEMP-INCR-PCT
                                         TO L0290-MAX-OUT-LEN.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-MAX-TXEMP-INCR-PCT.
           MOVE RPOLT-MAX-TXEMP-DECR-PCT TO L0290-INPUT-V04.
           MOVE 4                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-MAX-TXEMP-DECR-PCT
                                         TO L0290-MAX-OUT-LEN.

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA        TO MIR-MAX-TXEMP-DECR-PCT.

       9270-MOVE-EXEMT-INFO-X.
           EXIT.
      /
      *-------------------------
       9300-SETUP-MSIN-REFERENCE.
      *-------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY         TO TRUE.
           MOVE MIR-POL-ID               TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *-------------------------
       9990-INIT-WORKING-STORAGE.
      *-------------------------

           INITIALIZE WS-WORKING-STORAGE.
           MOVE 99999                    TO WS-PCHST-SEQ-NUM-MAX.
           MOVE 1000                     TO WS-CDA-SEQ-NUM-MAX.
           MOVE 100000                   TO WS-POL-PAYO-NUM-MAX.
      
           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.
      
           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           PERFORM  0620-0000-INIT-PARM-INFO
               THRU 0620-0000-INIT-PARM-INFO-X.

           PERFORM  2430-0000-INIT-PARM-INFO
               THRU 2430-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

           PERFORM  1660-0000-INIT-PARM-INFO
               THRU 1660-0000-INIT-PARM-INFO-X.

           PERFORM  2626-0000-INIT-PARM-INFO
               THRU 2626-0000-INIT-PARM-INFO-X.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
       COPY XCPSTIMR.
       COPY XCCPTIMR.
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  POLT
                                '$VAR2'   BY 'POLT'.
       COPY NCPPCVGS.
       COPY CCPPFPCK.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPS8090.
       COPY XCPL8090.
       COPY XCPL0260.
       COPY CCPS0620.
       COPY CCPL0620.
       COPY CCPS2430.
       COPY CCPL2430.
       COPY XCPS0290.
       COPY XCPL0290.
       COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPS1640.
       COPY XCPL1640.
       COPY XCPS1660.
       COPY XCPL1660.
       COPY CCPS2626.
       COPY CCPL2626.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPNCVG.
       COPY CCPNPOLT.
       COPY CCPUPOLT.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCP0030.
       COPY XCCPERR.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM7380                     **
      *****************************************************************
