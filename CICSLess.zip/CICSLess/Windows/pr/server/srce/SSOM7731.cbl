      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM7731.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM7731                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE RECORD CREATE           **
      **            FUNCTION FOR THE UTRA TABLE                      **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
021239**  6.4       FUND UNIT VALUE                                  **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM7731'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
      ****************************************************************
      *  DATABASE COPYBOOKS                                          *
      ****************************************************************
       COPY CCFWEDIT.
       COPY CCFREDIT.
       COPY XCWEBLCH.

      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************

      ****************************************************************
      *  WORKING AREA                                                *
      ****************************************************************
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-CREATE         VALUE '7731'.
           05  WS-MIR-LIST-SIZE              PIC S9(04) BINARY.
           05  WS-SUB                        PIC S9(04) BINARY.
           05  WS-DEFN-FCT-QTY-TBL.
               10  WS-DEFN-FCT-QTY-ENTRY OCCURS 20.
                   15  WS-UTR-DEFN-FCT-QTY   PIC 9(04).
           05  WS-DEFN-FCT-QTY-TBL-SIZE      PIC S9(04) BINARY.
           05  WS-ASIGN-EFF-DT               PIC X(10).
           05  WS-DEFN-RULE-ID               PIC 9(04).

       01  WS-CONSTANT-AREA.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970*                                      VALUE '7730'.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '7730'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************

      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY SCFWUTRA.
       COPY SCFRUTRA.
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWL8090.
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL1640.
       COPY SCWL7740.

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM7731.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-CREATE
                        THRU 2000-CREATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE WPGWS-CRNT-PGM-ID
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-----------
       2000-CREATE.
      *-----------

           IF  WS-MIR-LIST-SIZE NOT = WS-DEFN-FCT-QTY-TBL-SIZE
      *MSG: INTERNAL TABLE OUT SYNC WITH MIR
               MOVE 'SS77310001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  2100-VALIDATE-DATA
               THRU 2100-VALIDATE-DATA-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  7740-0000-INIT-PARM-INFO
               THRU 7740-0000-INIT-PARM-INFO-X.

           PERFORM
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MIR-LIST-SIZE
               OR WGLOB-MSG-ERROR-SW > ZERO

               MOVE MIR-UTR-DEFN-FCT-CD-T (WS-SUB)
                 TO L7740-DEFN-FCT-CD (WS-SUB)

               MOVE WS-UTR-DEFN-FCT-QTY (WS-SUB)
                 TO L7740-DEFN-FCT-QTY (WS-SUB)

           END-PERFORM.

           PERFORM  7740-1000-RULE-LOOKUP
               THRU 7740-1000-RULE-LOOKUP-X.

           IF  L7740-RETRN-OK
               MOVE L7740-DEFN-RULE-ID  TO WUTRA-UTR-DEFN-RULE-ID
               MOVE WS-ASIGN-EFF-DT     TO WUTRA-UTR-ASIGN-EFF-DT
               PERFORM  UTRA-2000-READ-INDEX
                   THRU UTRA-2000-READ-INDEX-X

               IF  WUTRA-IO-OK
      *MSG: RECORD ALREADY EXISTS
                   MOVE 'CS00000005'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-RQST-FAILED
                     TO TRUE
                   GO TO 2000-CREATE-X
               END-IF
           ELSE
               IF  L7740-DEFN-FCT-CD (1) = SPACE
      *MSG: NO FACTOR SPECIFIED
                   MOVE 'SS77310007'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-RQST-FAILED
                     TO TRUE
                   GO TO 2000-CREATE-X
               END-IF

               PERFORM  7740-2000-RULE-ADD
                   THRU 7740-2000-RULE-ADD-X
           END-IF.

           MOVE L7740-DEFN-RULE-ID     TO WUTRA-UTR-DEFN-RULE-ID.
           MOVE WS-ASIGN-EFF-DT        TO WUTRA-UTR-ASIGN-EFF-DT.
           MOVE MIR-UTR-ASIGN-TYP-CD   TO RUTRA-UTR-ASIGN-TYP-CD.

           PERFORM  UTRA-1000-WRITE
               THRU UTRA-1000-WRITE-X.

           PERFORM  9350-SETUP-AUDIT-INFO
               THRU 9350-SETUP-AUDIT-INFO-X.

           PERFORM  UTRA-1000-READ-TWRK-TS
               THRU UTRA-1000-READ-TWRK-TS-X.

       2000-CREATE-X.
           EXIT.
      /
      *----------------------------
       2100-VALIDATE-DATA.
      *----------------------------

           PERFORM  2110-EDIT-UTR-ASIGN-TYP-CD
               THRU 2110-EDIT-UTR-ASIGN-TYP-CD-X.

           PERFORM  2120-EDIT-UTR-ASIGN-EFF-DT
               THRU 2120-EDIT-UTR-ASIGN-EFF-DT-X.

           PERFORM  2130-EDIT-UTR-DEFN-FCT
               THRU 2130-EDIT-UTR-DEFN-FCT-X.

       2100-VALIDATE-DATA-X.
           EXIT.

      *----------------------------
       2110-EDIT-UTR-ASIGN-TYP-CD.
      *----------------------------

           MOVE MIR-UTR-ASIGN-TYP-CD   TO WEDIT-ETBL-VALU-ID.

           PERFORM  UVTP-1000-EDIT
               THRU UVTP-1000-EDIT-X.

           IF  NOT WEDIT-IO-OK
      *MSG: UNIT TYPE CODE (@1) NOT ON EDIT (@2)
               MOVE 'SS77310002'         TO WGLOB-MSG-REF-INFO
               MOVE WEDIT-ETBL-VALU-ID   TO WGLOB-MSG-PARM (1)
               MOVE 'UVTYP'              TO WGLOB-MSG-PARM (2)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2110-EDIT-UTR-ASIGN-TYP-CD-X.
           EXIT.

      *----------------------------
       2120-EDIT-UTR-ASIGN-EFF-DT.
      *----------------------------

           MOVE MIR-UTR-ASIGN-EFF-DT   TO L1640-EXTERNAL-DATE

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      *MSG: INVALID ASSIGNMENT EFFECTIVE DATE
               MOVE 'SS77310003'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L1640-INTERNAL-DATE
                                       TO WS-ASIGN-EFF-DT
           END-IF.

       2120-EDIT-UTR-ASIGN-EFF-DT-X.
           EXIT.

      *----------------------------
       2130-EDIT-UTR-DEFN-FCT.
      *----------------------------

           SET L0280-SIGN-NOT-PERMITTED         TO TRUE.
           MOVE ZERO                            TO L0280-PRECISION
           MOVE LENGTH OF MIR-UTR-DEFN-FCT-QTY-T (1)
             TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - L0280-PRECISION
                                - 1.

           PERFORM
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MIR-LIST-SIZE

               PERFORM  2131-EDIT-UTR-DEFN-FCT-ROW
                   THRU 2131-EDIT-UTR-DEFN-FCT-ROW-X

           END-PERFORM.

       2130-EDIT-UTR-DEFN-FCT-X.
           EXIT.

      *----------------------------
       2131-EDIT-UTR-DEFN-FCT-ROW.
      *----------------------------

           IF  MIR-UTR-DEFN-FCT-CD-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE
                 TO MIR-UTR-DEFN-FCT-CD-T (WS-SUB)
           ELSE
               MOVE MIR-UTR-DEFN-FCT-CD-T (WS-SUB)
                 TO WEDIT-ETBL-VALU-ID

               PERFORM  UVFT-1000-EDIT
                   THRU UVFT-1000-EDIT-X

               IF  NOT WEDIT-IO-OK
      *MSG: UNIT FACTOR CODE (@1) NOT ON EDIT (@2)
                   MOVE 'SS77310004'       TO WGLOB-MSG-REF-INFO
                   MOVE WEDIT-ETBL-VALU-ID TO WGLOB-MSG-PARM (1)
                   MOVE 'UVFCT'            TO WGLOB-MSG-PARM (2)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           MOVE MIR-UTR-DEFN-FCT-QTY-T (WS-SUB)
             TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF  L0280-OK
               MOVE L0280-OUTPUT-V00
                 TO WS-UTR-DEFN-FCT-QTY (WS-SUB)
           ELSE
      *MSG: INVALID FACTOR QUANTITY
               MOVE 'SS77310005'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2131-EDIT-UTR-DEFN-FCT-ROW-X
           END-IF.

           IF  MIR-UTR-DEFN-FCT-CD-T (WS-SUB) NOT = SPACE
               IF  WS-UTR-DEFN-FCT-QTY (WS-SUB) = 0
      *MSG: UNIT TYPE FACTOR COUNT MUST > ZERO
      *     WHEN UNIT FACTOR CODE IS SPECIFIED
                   MOVE 'SS77310008'       TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           ELSE
               IF  WS-UTR-DEFN-FCT-QTY (WS-SUB) > 0
      *MSG: UNIT TYPE FACTOR COUNT MUST = ZERO
      *     WHEN UNIT FACTOR CODE IS NOT SPECIFIED
                   MOVE 'SS77310009'       TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       2131-EDIT-UTR-DEFN-FCT-ROW-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      /
      *----------------------
       9350-SETUP-AUDIT-INFO.
      *----------------------

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM  UTRA-1000-CALL-AUDIT
                   THRU UTRA-1000-CALL-AUDIT-X
           END-IF.

       9350-SETUP-AUDIT-INFO-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7740-0000-INIT-PARM-INFO
025970         THRU 7740-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

           COMPUTE WS-MIR-LIST-SIZE = LENGTH OF MIR-UTR-DEFN-FCT-QTY-G
                         / LENGTH OF MIR-UTR-DEFN-FCT-QTY-T (1).

           COMPUTE WS-DEFN-FCT-QTY-TBL-SIZE =
                   LENGTH OF WS-DEFN-FCT-QTY-TBL /
                   LENGTH OF WS-DEFN-FCT-QTY-ENTRY (1).

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

025970     SET WS-TWRK-KEY-DEFAULT     TO TRUE.
025970
       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  UTRA
                                '$VAR2'   BY 'UTRA'.

       COPY CCPEUVFT.

       COPY CCPEUVTP.

      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL8090.

       COPY XCPL0260.

025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.

025970 COPY XCPS1640.
       COPY XCPL1640.
      /
       COPY SCPS7740.
       COPY SCPL7740.
      /
       COPY SCPLUTRA.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY SCPNUTRA.
       COPY SCPUUTRA.
       COPY SCPAUTRA.

       COPY CCPNEDIT.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                      END OF PROGRAM SSOM7731                **
      *****************************************************************
