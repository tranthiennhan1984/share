      *************************
       IDENTIFICATION DIVISION.
      *************************
      *
       PROGRAM-ID. CSOM0675.
      *
      *
       COPY XCWWCRHT.
      *
      *****************************************************************
      **  MEMBER :  CSOM0675                                         **
      **  REMARKS:  LHST - LOAN HISTORY. THIS MODULE IS USED TO      **
      **            DISPLAY LOAN HISTORY RECORDS FOR CASH AND APL    **
      **            (AUTOMATIC PREMIUM LOAN) LOANS. INFORMATION ON   **
      **            THESE RECORDS INCLUDE THE LOAN STATUS, LOAN      **
      **            AMOUNT AND TAX WITHHELD AMOUNT.                  **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURES               **
557668**  5.5       STANDARD CLIENT SCREEN NAME FORMATTING           **
557708**  5.5       NEW CICS ABEND HANDLING                          **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
005409**  5.6       PUT WORK DATES THRU THE DATE ROUTINE TO GET      **
005409**            VALID DATE PRIOR TO MOVING TO DB2 TABLES         **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010397**  5.6       ADD A NEW FIELD 'TRANSACTION TYPE TO BOTH        **
010397**            INQUIRE AND BROWSE SCREEN & RENAME THE DATA      **
010397**            FIELD                                            **
010418**  5.6       READ POLICY TO RETRIEVE THE SUBCOMPANY ID        **
010418**            FOR GUI DISPLAY                                  **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015543**  6.0       RENAME 000-MAINLINE                              **
013693**  6.2       CHANGE FEDERAL TAX AMOUNT DISPLAY                **
016548**  6.2       CHANGE COMP TO BINARY                            **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018842**  6.3       NET LOAN PROCESSSING                             **
020769**  6.3       GET ALL USTX FOR LOAN TAX WITHHELD AMOUNT        **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************
      *
      **********************
       DATA DIVISION.
      **********************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0675'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  COMP VALUE +0.
016548     05  WS-SUB                       PIC S9(4)  BINARY VALUE +0.
016548*    05  I                            PIC S9(4)  COMP VALUE +0.
016548     05  I                            PIC S9(4)  BINARY VALUE +0.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  COMP VALUE +10.
025970*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  BINARY VALUE +10.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '0530' '0534'.
               88  WS-BUS-FCN-INQUIRE       VALUE '0530'.
               88  WS-BUS-FCN-LIST          VALUE '0534'.
           05  WS-END-BROWSE-SW             PIC X(01).
               88  WS-END-BROWSE            VALUE 'Y'.
               88  WS-NO-END-BROWSE         VALUE 'N'.
           05  WS-BROWSE-TYPE-SW            PIC X(01).
               88  WS-ALTERNATE-BROWSE      VALUE 'A'.
               88  WS-KEY-BROWSE            VALUE 'K'.
           05  WS-LOAN-TYPE                 PIC X(01).
010397*        88  WS-LOAN-TYPE-VALID       VALUE 'A' 'C' ' '.
010397         88  WS-LOAN-TYPE-VALID       VALUE 'A' 'C' 'O' ' '.
           05  WS-PIC-999                   PIC 9(03).
008455*    05  WS-DISPLAY-AMOUNT            PIC ZZZZZZ9.99.
           05  WS-EFF-DATE                  PIC X(10).

020769     05  WS-USTX-LTAXWH-AMT           PIC S9(13)V99 COMP-3.
020769     05  WS-USTX-FED-TAXWH-AMT        PIC S9(13)V99 COMP-3.
020769     05  WS-USTX-ORIG-LOAN-SW         PIC X.
020769         88  WS-USTX-ORIG-LOAN-FOUND  VALUE 'Y'.
020769         88  WS-USTX-ORIG-LOAN-NOTFND VALUE 'N'.

025970 01  WS-CONSTANTS.
025970     05  WS-MAX-BROWSE-LINES              PIC S9(4) BINARY.
025970         88  WS-MAX-BROWSE-LINES-DEFAULT  VALUE +10.
      *
026057 COPY CCWWIHSD.
       COPY XCWWWKDT.
018763 COPY XCWEBLCH.
      *
       01  FILE-WS-START  PIC X(51)
           VALUE '********* START OF FILE WORKING STORAGE *********'.
      *
       COPY CCFWLHSD.
      *
       COPY CCFWPOL.
       COPY CCFWLHST.
       COPY CCFRLHST.
013693 COPY CCFRUSTX.
013693 COPY CCFWUSTX.
      *
       01  LPGA-WS-START  PIC X(51)
           VALUE '********* START OF PARAMETER AREAS *********'.
      *
028298 COPY CCWL2626.
       COPY XCWLDTLK.
      *
       COPY XCWL0280.
       COPY XCWL1640.
005409 COPY XCWL1670.
005409 COPY XCWL1680.
008455 COPY XCWL0290.
      *
557668 COPY CCWL0620.
       COPY CCWL2430.
       COPY CCWL5400.
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      *
       COPY CCFRPOL.
      *
       01  LINKAGE-WS-START  PIC X(51)
           VALUE '********* START OF LINKAGE SECTION *********'.

      *******************
       LINKAGE   SECTION.
      *******************

CVMQ71 COPY XCWWDFHQ.
      *
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0675.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
015543 0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

015543 0000-MAINLINE-X.
           EXIT.

      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------

008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *    MOVE ENTER CODE TO A WORK FIELD, AND DECIDE WHICH SCREEN TO
      *    DISPLAY.
      *
025970*    MOVE MIR-BUS-FCN-ID           TO WS-BUS-FCN-ID.

      *
      *  VALIDATE KEY AND CONTROL FIELDS.
      *
           PERFORM  2100-VALIDATE-CONTROL-FIELDS
               THRU 2100-VALIDATE-CONTROL-FIELDS-X.

           IF WGLOB-MSG-ERROR-SW > 0
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF WS-BUS-FCN-INQUIRE
               PERFORM  3000-RETRIEVE
                   THRU 3000-RETRIEVE-X
           END-IF.

           IF WS-BUS-FCN-LIST
               PERFORM  3500-LIST
                   THRU 3500-LIST-X
           END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *-----------------------------
       2100-VALIDATE-CONTROL-FIELDS.
      *-----------------------------

           PERFORM  2110-VALIDATE-POLICY
               THRU 2110-VALIDATE-POLICY-X.

           PERFORM  2120-VALIDATE-TYPE
               THRU 2120-VALIDATE-TYPE-X.

           PERFORM  2130-VALIDATE-EFFDT
               THRU 2130-VALIDATE-EFFDT-X.

           PERFORM  2140-VALIDATE-SEQ
               THRU 2140-VALIDATE-SEQ-X.

       2100-VALIDATE-CONTROL-FIELDS-X.
           EXIT.

      ****************************************************************
      *   VALIDATE POLICY:
      *   ENSURE THAT THE POLICY EXISTS, THAT CONFIDENTIAL CHECKS ARE
      *   SATISFIED
      *****************************************************************

      *---------------------
       2110-VALIDATE-POLICY.
      *---------------------

           IF MIR-POL-ID = SPACES
      *        MSG: POLICY NUMBER IS REQUIRED
               MOVE 'CS06750001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2110-VALIDATE-POLICY-X
           END-IF.

           MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
      *        MSG: POLICY (@1) DOES NOT EXIST
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2110-VALIDATE-POLICY-X
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.


           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.
      *
       2110-VALIDATE-POLICY-X.
           EXIT.
      *
      ****************************************************************
      *   EDIT LOAN TYPE:
      *   ENSURE THAT THE LOAN TYPE IS VALID (A, C OR BLANK)
      ****************************************************************

      *-------------------
       2120-VALIDATE-TYPE.
      *-------------------

018763     IF  MIR-POL-LOAN-ID = EBLCH-BLANK-FIELD-CHAR
018763         MOVE SPACE             TO MIR-POL-LOAN-ID
018763     END-IF.
           MOVE MIR-POL-LOAN-ID       TO WS-LOAN-TYPE.

           IF WS-LOAN-TYPE-VALID
               GO TO 2120-VALIDATE-TYPE-X
           ELSE
010397*        MSG: LOAN TYPE MUST BE A, C, O OR BLANK
               MOVE 'CS06750002'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-LOAN-ID   TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2120-VALIDATE-TYPE-X.
           EXIT.

      *--------------------
       2130-VALIDATE-EFFDT.
      *--------------------

           IF  MIR-POL-LOAN-EFF-DT = SPACES
               MOVE WGLOB-PROCESS-DATE            TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-POL-LOAN-EFF-DT
               MOVE L1640-INTERNAL-DATE
                                      TO WS-EFF-DATE
               GO TO 2130-VALIDATE-EFFDT-X
           END-IF.

           MOVE MIR-POL-LOAN-EFF-DT   TO L1640-EXTERNAL-DATE.

020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO WS-EFF-DATE
026057*        GO TO 2130-VALIDATE-EFFDT-X
           ELSE
      *        MSG: EFFECTIVE DATE MUST BE VALID OR BLANK
               MOVE 'CS06750003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-EFF-DATE              TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.

       2130-VALIDATE-EFFDT-X.
           EXIT.

      *------------------
       2140-VALIDATE-SEQ.
      *------------------

           IF MIR-POL-LOAN-SEQ-NUM = SPACES
               MOVE '999'             TO MIR-POL-LOAN-SEQ-NUM
               GO TO 2140-VALIDATE-SEQ-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE MIR-POL-LOAN-SEQ-NUM  TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
020874*         MOVE L0280-OUTPUT     TO WS-PIC-999
020874*         MOVE WS-PIC-999       TO MIR-POL-LOAN-SEQ-NUM
020874          MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874          MOVE ZERO                  TO L0290-PRECISION
020874          MOVE LENGTH OF MIR-POL-LOAN-SEQ-NUM
020874                                     TO L0290-MAX-OUT-LEN
020874          PERFORM 0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
020874          MOVE L0290-OUTPUT-DATA     TO MIR-POL-LOAN-SEQ-NUM
           ELSE
      *        MSG: SEQUENCE NUMBER MUST BE NUMERIC
               MOVE 'CS06750004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2140-VALIDATE-SEQ-X.
           EXIT.

      *-------------
       3000-RETRIEVE.
      *-------------
      *
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  8000-BUILD-LHST-KEY
               THRU 8000-BUILD-LHST-KEY-X.

           PERFORM  LHST-1000-READ
               THRU LHST-1000-READ-X.

           IF NOT WLHST-IO-OK
      *        MSG: LOAN HISTORY RECORD NOT FOUND
               MOVE 'CS06750005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-RETRIEVE-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

      *    MSG: INQUIRE COMPLETED - CONTINUE
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.


       3000-RETRIEVE-X.
           EXIT.

      *------------
       3500-LIST.
      *------------
      *
           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      *
      *  CHECK MIR-POL-LOAN-ID TO DETERMINE TYPE OF BROWSE
      *
           IF MIR-POL-LOAN-ID = SPACES
               PERFORM  3520-ALTERNATE-BROWSE
                   THRU 3520-ALTERNATE-BROWSE-X
           END-IF.

           IF MIR-POL-LOAN-ID > SPACES
               PERFORM  3530-KEY-BROWSE
                   THRU 3530-KEY-BROWSE-X
           END-IF.
      *
           IF WS-NO-END-BROWSE
               GO TO 3500-LIST-X
           END-IF.
      *
           IF WLHST-IO-EOF
           OR WLHSD-IO-EOF
      *MSG: END OF FILE REACHED
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
           ELSE
      *MSG: TO VIEW MORE DATA PRESS ENTER
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
           END-IF.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           IF WS-ALTERNATE-BROWSE
               PERFORM  LHSD-3000-END-BROWSE-PREV
                   THRU LHSD-3000-END-BROWSE-PREV-X
           ELSE
               PERFORM  LHST-3000-END-BROWSE-PREV
                   THRU LHST-3000-END-BROWSE-PREV-X
           END-IF.

       3500-LIST-X.
           EXIT.

      *----------------------
       3520-ALTERNATE-BROWSE.
      *----------------------

           PERFORM  8100-BUILD-LHSD-KEY
               THRU 8100-BUILD-LHSD-KEY-X.

           PERFORM  LHSD-1000-BROWSE-PREV
               THRU LHSD-1000-BROWSE-PREV-X.
           IF WLHSD-IO-EOF
      *MSG: NO RECORDS FOUND
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-NO-END-BROWSE TO TRUE
               GO TO 3520-ALTERNATE-BROWSE-X
           END-IF.

           PERFORM  LHSD-2000-READ-PREV
               THRU LHSD-2000-READ-PREV-X.
           IF WLHSD-IO-EOF
      *MSG: NO RECORDS FOUND
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  LHSD-3000-END-BROWSE-PREV
                   THRU LHSD-3000-END-BROWSE-PREV-X
               SET WS-NO-END-BROWSE TO TRUE
               GO TO 3520-ALTERNATE-BROWSE-X
           END-IF.

           SET WS-ALTERNATE-BROWSE  TO TRUE.
           PERFORM  3540-DISPLAY-RECORD
               THRU 3540-DISPLAY-RECORD-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-BROWSE-LINES
               OR WLHSD-IO-EOF.

           IF WLHSD-IO-EOF
               GO TO 3520-ALTERNATE-BROWSE-X
           ELSE
               MOVE RLHST-POL-LOAN-EFF-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X                   
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-POL-LOAN-EFF-DT
020874*        MOVE RLHST-POL-LOAN-SEQ-NUM
020874*                               TO WS-PIC-999
020874*        MOVE WS-PIC-999        TO MIR-POL-LOAN-SEQ-NUM
020874         MOVE RLHST-POL-LOAN-SEQ-NUM TO L0290-INPUT-V00
020874         MOVE ZERO                   TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-LOAN-SEQ-NUM
020874                                     TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-POL-LOAN-SEQ-NUM
           END-IF.

       3520-ALTERNATE-BROWSE-X.
           EXIT.

      *----------------
       3530-KEY-BROWSE.
      *----------------

           PERFORM  8000-BUILD-LHST-KEY
               THRU 8000-BUILD-LHST-KEY-X.

           PERFORM  LHST-1000-BROWSE-PREV
               THRU LHST-1000-BROWSE-PREV-X.
           IF WLHST-IO-EOF
      *MSG: NO RECORDS FOUND
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-NO-END-BROWSE TO TRUE
               GO TO 3530-KEY-BROWSE-X
           END-IF.

           PERFORM  LHST-2000-READ-PREV
               THRU LHST-2000-READ-PREV-X.
           IF WLHST-IO-EOF
      *MSG: NO RECORDS FOUND
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  LHST-3000-END-BROWSE-PREV
                   THRU LHST-3000-END-BROWSE-PREV-X
               SET WS-NO-END-BROWSE TO TRUE
               GO TO 3530-KEY-BROWSE-X
           END-IF.

           SET WS-KEY-BROWSE  TO TRUE.
           PERFORM  3540-DISPLAY-RECORD
               THRU 3540-DISPLAY-RECORD-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-BROWSE-LINES
               OR WLHST-IO-EOF.

           IF WLHST-IO-EOF
               GO TO 3530-KEY-BROWSE-X
           ELSE
               MOVE RLHST-POL-LOAN-ID TO MIR-POL-LOAN-ID
               MOVE RLHST-POL-LOAN-EFF-DT
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X                   
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-POL-LOAN-EFF-DT
020874*        MOVE RLHST-POL-LOAN-SEQ-NUM
020874*                               TO WS-PIC-999
020874*        MOVE WS-PIC-999        TO MIR-POL-LOAN-SEQ-NUM
020874         MOVE RLHST-POL-LOAN-SEQ-NUM TO L0290-INPUT-V00
020874         MOVE ZERO                   TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-POL-LOAN-SEQ-NUM
020874                                     TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA      TO MIR-POL-LOAN-SEQ-NUM
           END-IF.

       3530-KEY-BROWSE-X.
           EXIT.

      *--------------------
       3540-DISPLAY-RECORD.
      *--------------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           IF WS-ALTERNATE-BROWSE
               PERFORM  LHSD-2000-READ-PREV
                   THRU LHSD-2000-READ-PREV-X
           ELSE
               PERFORM  LHST-2000-READ-PREV
                   THRU LHST-2000-READ-PREV-X
           END-IF.

       3540-DISPLAY-RECORD-X.
           EXIT.
      *
      *
      *--------------------
       8000-BUILD-LHST-KEY.
      *--------------------

           MOVE RPOL-POL-ID           TO WLHST-POL-ID
           MOVE MIR-POL-LOAN-ID       TO WLHST-POL-LOAN-ID
005409*    MOVE WS-EFF-DATE         TO WLHST-POL-LOAN-EFF-DT
005409     MOVE WS-EFF-DATE           TO L1680-INTERNAL-1
005409     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS
005409     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS
005409     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS
005409     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X
005409     MOVE L1680-INTERNAL-2      TO WLHST-POL-LOAN-EFF-DT
           MOVE MIR-POL-LOAN-SEQ-NUM  TO WLHST-POL-LOAN-SEQ-NUM

           MOVE WLHST-KEY             TO WLHST-ENDBR-KEY.
           MOVE WWKDT-LOW-DT          TO WLHST-ENDBR-POL-LOAN-EFF-DT.
           MOVE ZEROES                TO WLHST-ENDBR-POL-LOAN-SEQ-NUM.

       8000-BUILD-LHST-KEY-X.
           EXIT.

      *--------------------
       8100-BUILD-LHSD-KEY.
      *--------------------

           MOVE RPOL-POL-ID           TO WLHSD-POL-ID.
005409*    MOVE WS-EFF-DATE         TO WLHSD-POL-LOAN-EFF-DT.
005409     MOVE WS-EFF-DATE           TO L1680-INTERNAL-1.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-YEARS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-MONTHS.
005409     MOVE ZERO                  TO L1680-NUMBER-OF-DAYS.
005409     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
005409         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
005409     MOVE L1680-INTERNAL-2      TO WLHSD-POL-LOAN-EFF-DT.
           MOVE MIR-POL-LOAN-SEQ-NUM  TO WLHSD-POL-LOAN-SEQ-NUM.

           MOVE WLHSD-KEY             TO WLHSD-ENDBR-KEY.
           MOVE WWKDT-LOW-DT          TO WLHSD-ENDBR-POL-LOAN-EFF-DT.
           MOVE ZEROES                TO WLHSD-ENDBR-POL-LOAN-SEQ-NUM.

       8100-BUILD-LHSD-KEY-X.
           EXIT.

      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************

      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-POL-LOAN-ID-G.
           MOVE SPACES                TO MIR-POL-LOAN-EFF-DT-G.
           MOVE SPACES                TO MIR-POL-LOAN-SEQ-NUM-G.
           MOVE SPACES                TO MIR-POL-LOAN-STAT-CD-G.
           MOVE SPACES                TO MIR-POL-LOAN-TRXN-AMT-G.
           MOVE SPACES                TO MIR-POL-LOAN-APL-IND-G.
010397     MOVE SPACES                TO MIR-POL-LOAN-TRXN-CD-G.
018842     MOVE SPACES                TO MIR-POL-LOAN-INT-PCT-G.
018842     MOVE SPACES                TO MIR-ADV-INT-AMT-G.

           MOVE SPACES                TO MIR-POL-LOAN-STAT-CD.
           MOVE SPACES                TO MIR-POL-LOAN-TRXN-AMT.
           MOVE SPACES                TO MIR-POL-LOAN-APL-IND.
013693*    MOVE SPACES                TO MIR-POL-LOAN-TAXWH-AMT.
013693     MOVE SPACES                TO MIR-USTX-FED-TAXWH-AMT.
010397     MOVE SPACES                TO MIR-POL-LOAN-TRXN-CD.
010418     MOVE SPACES                TO MIR-SBSDRY-CO-ID.
018842     MOVE SPACES                TO MIR-POL-LOAN-INT-PCT.
018842     MOVE SPACES                TO MIR-ADV-INT-AMT.


       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN
      *****************************************************************

      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.
           IF L2430-RELATIONSHIP-FOUND
557668*        MOVE L2430-CLI-NM-COMPRESSED TO MIR-DV-CLI-NM
557668         INITIALIZE              L0620-INPUT-PARM-INFO
557668         IF L2430-CLI-SEX-COMPANY
557668            MOVE L2430-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
557668         ELSE
557668            MOVE L2430-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
557668            MOVE L2430-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
557668         END-IF
557668         MOVE L2430-CLI-SEX-CD  TO L0620-CLI-SEX-CD
557668         PERFORM  0620-1000-FORMAT-SCREEN-NAME
557668             THRU 0620-1000-FORMAT-SCREEN-NAME-X
557668         MOVE L0620-SCREEN-NAME TO MIR-DV-CLI-NM
           ELSE
               MOVE SPACES            TO MIR-DV-CLI-NM
           END-IF.

010418     MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.
010418
           IF WS-BUS-FCN-LIST
               PERFORM  9210-MOVE-LHST-TO-BROWSE
                   THRU 9210-MOVE-LHST-TO-BROWSE-X
           ELSE
               PERFORM  9220-MOVE-LHST-TO-INQUIRE
                   THRU 9220-MOVE-LHST-TO-INQUIRE-X
           END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      *
      *
      *-------------------------
       9210-MOVE-LHST-TO-BROWSE.
      *-------------------------


           MOVE RLHST-POL-LOAN-ID     TO MIR-POL-LOAN-ID-T  (WS-SUB).
           MOVE RLHST-POL-LOAN-EFF-DT TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-POL-LOAN-EFF-DT-T (WS-SUB).
020874*    MOVE RLHST-POL-LOAN-SEQ-NUM                    TO WS-PIC-999.
020874*    MOVE WS-PIC-999           TO MIR-POL-LOAN-SEQ-NUM-T (WS-SUB).
020874     MOVE RLHST-POL-LOAN-SEQ-NUM TO L0290-INPUT-V00.
020874     MOVE ZERO                   TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-POL-LOAN-SEQ-NUM-T (WS-SUB)
020874                                 TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA   TO MIR-POL-LOAN-SEQ-NUM-T (WS-SUB).
           MOVE RLHST-POL-LOAN-STAT-CD
                                    TO MIR-POL-LOAN-STAT-CD-T  (WS-SUB).
008455*    MOVE RLHST-POL-LOAN-AMT  TO WS-DISPLAY-AMOUNT.
008455*    MOVE WS-DISPLAY-AMOUNT   TO MIR-POL-LOAN-TRXN-AMT-T (WS-SUB).

008455*    COMPUTE L0290-INPUT-NUMBER = RLHST-POL-LOAN-AMT * 100.
020874*    COMPUTE L0290-INPUT-NUMBER = RLHST-POL-LOAN-TRXN-AMT * 100.
020874     MOVE RLHST-POL-LOAN-TRXN-AMT TO L0290-INPUT-V02.
008455     MOVE 2                       TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-LOAN-TRXN-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS
020874*                               TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA   TO MIR-POL-LOAN-TRXN-AMT-T (WS-SUB).

010397     MOVE RLHST-POL-LOAN-TRXN-CD
                                     TO MIR-POL-LOAN-TRXN-CD-T (WS-SUB).
           MOVE RLHST-POL-LOAN-APL-IND
                                     TO MIR-POL-LOAN-APL-IND-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RLHST-POL-LOAN-INT-PCT * 10000.
020874     MOVE RLHST-POL-LOAN-INT-PCT  TO L0290-INPUT-V04.
018842     MOVE 4                       TO L0290-PRECISION.
018842     MOVE LENGTH OF MIR-POL-LOAN-INT-PCT-T (WS-SUB)
018842                                TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS
020874*                               TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
018842     MOVE L0290-OUTPUT-DATA   TO MIR-POL-LOAN-INT-PCT-T (WS-SUB).
020874*    COMPUTE L0290-INPUT-NUMBER = RLHST-ADV-INT-AMT * 100.
020874     MOVE RLHST-ADV-INT-AMT     TO L0290-INPUT-V02.
018842     MOVE 2                     TO L0290-PRECISION.
018842     MOVE LENGTH OF MIR-ADV-INT-AMT-T (WS-SUB)
018842                                TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS
020874*                               TO TRUE.
018842     PERFORM  0290-1000-NUMERIC-FORMAT
018842         THRU 0290-1000-NUMERIC-FORMAT-X.
018842     MOVE L0290-OUTPUT-DATA   TO MIR-ADV-INT-AMT-T (WS-SUB).


       9210-MOVE-LHST-TO-BROWSE-X.
           EXIT.
      *
      *--------------------------
       9220-MOVE-LHST-TO-INQUIRE.
      *--------------------------

           MOVE RLHST-POL-LOAN-STAT-CD          TO MIR-POL-LOAN-STAT-CD.
008455*    MOVE RLHST-POL-LOAN-AMT       TO WS-DISPLAY-AMOUNT.
008455*    MOVE WS-DISPLAY-AMOUNT        TO MIR-POL-LOAN-TRXN-AMT.
008455*    COMPUTE L0290-INPUT-NUMBER = RLHST-POL-LOAN-AMT * 100.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RLHST-POL-LOAN-TRXN-AMT * 100.
020874     MOVE RLHST-POL-LOAN-TRXN-AMT TO L0290-INPUT-V02.
008455     MOVE 2                       TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-POL-LOAN-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS
020874*                               TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-POL-LOAN-TRXN-AMT.
018763     MOVE RLHST-POL-LOAN-TRXN-CD   TO MIR-POL-LOAN-TRXN-CD.
018763     MOVE RLHST-POL-LOAN-APL-IND   TO MIR-POL-LOAN-APL-IND.
020874*    COMPUTE L0290-INPUT-NUMBER = RLHST-POL-LOAN-INT-PCT * 10000.
020874     MOVE RLHST-POL-LOAN-INT-PCT TO L0290-INPUT-V04.
018842     MOVE 4                      TO L0290-PRECISION.
018842     MOVE LENGTH OF MIR-POL-LOAN-INT-PCT
018842                                TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS
020874*                               TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
018842     MOVE L0290-OUTPUT-DATA   TO MIR-POL-LOAN-INT-PCT.
020874*    COMPUTE L0290-INPUT-NUMBER = RLHST-ADV-INT-AMT * 100.
020874     MOVE RLHST-ADV-INT-AMT     TO L0290-INPUT-V02.
018842     MOVE 2                     TO L0290-PRECISION.
018842     MOVE LENGTH OF MIR-ADV-INT-AMT
018842                                TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS
020874*                                TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
018842     MOVE L0290-OUTPUT-DATA   TO MIR-ADV-INT-AMT.

013693     IF NOT RPOL-POL-CTRY-US
013693        MOVE ZEROES             TO MIR-USTX-LTAXWH-AMT
013693        MOVE ZEROES             TO MIR-USTX-FED-TAXWH-AMT
013693        GO TO 9220-MOVE-LHST-TO-INQUIRE-X
013693      END-IF.
013693
013693     MOVE RLHST-POL-LOAN-EFF-DT TO L1640-INTERNAL-DATE.
013693     MOVE L1640-YYYY-1          TO WUSTX-USTX-EFF-YR.
013693     MOVE RLHST-POL-ID          TO WUSTX-POL-ID.
013693     MOVE RLHST-POL-LOAN-EFF-DT TO WUSTX-USTX-EFF-DT.
013693     MOVE RLHST-TAX-SEQ-NUM     TO WUSTX-USTX-SEQ-NUM.
013693
013693     PERFORM  USTX-1000-READ
013693         THRU USTX-1000-READ-X.
013693
020769     IF  WUSTX-IO-OK
020769         MOVE  RUSTX-USTX-LTAXWH-AMT    TO WS-USTX-LTAXWH-AMT
020769         MOVE  RUSTX-USTX-FED-TAXWH-AMT TO WS-USTX-FED-TAXWH-AMT
020769         IF  RUSTX-USTX-TAXBL-EVNT-LIC
020769             SET WS-USTX-ORIG-LOAN-NOTFND TO TRUE
020769             PERFORM  9225-GET-ORIG-LOAN-USTX
020769                 THRU 9225-GET-ORIG-LOAN-USTX-X
020769                 UNTIL NOT WUSTX-IO-OK
020769                 OR    WS-USTX-ORIG-LOAN-FOUND
020769         END-IF
020769     ELSE
020769         MOVE ZEROES             TO MIR-USTX-LTAXWH-AMT
020769         MOVE ZEROES             TO MIR-USTX-FED-TAXWH-AMT
020769         GO TO 9220-MOVE-LHST-TO-INQUIRE-X
020769     END-IF.

020769*    IF WUSTX-IO-OK
020769*       COMPUTE L0290-INPUT-NUMBER = RUSTX-USTX-LTAXWH-AMT * 100
020769*       MOVE 2                            TO L0290-PRECISION
020769*       MOVE LENGTH OF MIR-USTX-LTAXWH-AMT
020769*                                         TO L0290-MAX-OUT-LEN
020769*       SET L0290-LEAD-ZEROS-SUPPRESS     TO TRUE
020769*
020769*       PERFORM  0290-1000-NUMERIC-FORMAT
020769*           THRU 0290-1000-NUMERIC-FORMAT-X
020769*       MOVE L0290-OUTPUT-DATA            TO MIR-USTX-LTAXWH-AMT
020769*
020769*       COMPUTE L0290-INPUT-NUMBER = RUSTX-USTX-FED-TAXWH-AMT
020769*                                  * 100
020769*       MOVE 2                            TO L0290-PRECISION
020769*       MOVE LENGTH OF MIR-USTX-FED-TAXWH-AMT
020769*                                         TO L0290-MAX-OUT-LEN
020769*       SET L0290-LEAD-ZEROS-SUPPRESS     TO TRUE
020769*
020769*       PERFORM  0290-1000-NUMERIC-FORMAT
020769*           THRU 0290-1000-NUMERIC-FORMAT-X
020769*       MOVE L0290-OUTPUT-DATA  TO MIR-USTX-FED-TAXWH-AMT
020769*    ELSE
020769*       MOVE ZEROES             TO MIR-USTX-LTAXWH-AMT
020769*       MOVE ZEROES             TO MIR-USTX-FED-TAXWH-AMT
020769*       GO TO 9220-MOVE-LHST-TO-INQUIRE-X
020769*    END-IF.
020769*

020874*    COMPUTE L0290-INPUT-NUMBER = WS-USTX-LTAXWH-AMT * 100.
020874     MOVE WS-USTX-LTAXWH-AMT           TO L0290-INPUT-V02.
020769     MOVE 2                            TO L0290-PRECISION.
020769     MOVE LENGTH OF MIR-USTX-LTAXWH-AMT
020769                                       TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS     TO TRUE.
020769
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
020769     MOVE L0290-OUTPUT-DATA            TO MIR-USTX-LTAXWH-AMT.
020769
020874*    COMPUTE L0290-INPUT-NUMBER = WS-USTX-FED-TAXWH-AMT
020874*                               * 100.
020874     MOVE WS-USTX-FED-TAXWH-AMT        TO L0290-INPUT-V02.
020769     MOVE 2                            TO L0290-PRECISION.
020769     MOVE LENGTH OF MIR-USTX-FED-TAXWH-AMT
020769                                       TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS     TO TRUE.
020769
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
020769     MOVE L0290-OUTPUT-DATA            TO MIR-USTX-FED-TAXWH-AMT.

020874*    MOVE RLHST-TAX-SEQ-NUM               TO L0290-INPUT-NUMBER.
020874     MOVE RLHST-TAX-SEQ-NUM               TO L0290-INPUT-V00.
013693     MOVE 0                               TO L0290-PRECISION.
013693     MOVE LENGTH OF MIR-TAX-SEQ-NUM       TO L0290-MAX-OUT-LEN.
020874*    SET  L0290-LEAD-ZEROS-SUPPRESS       TO TRUE
013693
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
013693     MOVE L0290-OUTPUT-DATA               TO MIR-TAX-SEQ-NUM.

018763*    MOVE RLHST-POL-LOAN-TRXN-CD          TO MIR-POL-LOAN-TRXN-CD.
018763*    MOVE RLHST-POL-LOAN-APL-IND          TO MIR-POL-LOAN-APL-IND.
008455*    MOVE RLHST-POL-LOAN-TAXWH-AMT TO WS-DISPLAY-AMOUNT.
008455*    MOVE WS-DISPLAY-AMOUNT        TO MIR-POL-LOAN-TAXWH-AMT.
008455*    COMPUTE L0290-INPUT-NUMBER = RLHST-POL-LOAN-TAXWH-AMT * 100.
008455*    MOVE 2                     TO L0290-PRECISION.
008455*    MOVE LENGTH OF MIR-POL-LOAN-TAXWH-AMT
      *                               TO L0290-MAX-OUT-LEN.
008455*    SET  L0290-LEAD-ZEROS-SUPPRESS
008455*                               TO TRUE.
008455*    PERFORM  0290-1000-NUMERIC-FORMAT
008455*        THRU 0290-1000-NUMERIC-FORMAT-X.
008455*    MOVE L0290-OUTPUT-DATA     TO MIR-POL-LOAN-TAXWH-AMT.
008455*

       9220-MOVE-LHST-TO-INQUIRE-X.
           EXIT.

020769*------------------------
020769 9225-GET-ORIG-LOAN-USTX.
020769*------------------------
020769
020769     SUBTRACT 1                        FROM WUSTX-USTX-SEQ-NUM.
020769     PERFORM  USTX-1000-READ
020769         THRU USTX-1000-READ-X.
020769
020769     IF  WUSTX-IO-OK
020769     AND RUSTX-USTX-TAXBL-EVNT-ORL
020769         ADD  RUSTX-USTX-LTAXWH-AMT    TO WS-USTX-LTAXWH-AMT
020769         ADD  RUSTX-USTX-FED-TAXWH-AMT TO WS-USTX-FED-TAXWH-AMT
020769         SET WS-USTX-ORIG-LOAN-FOUND   TO TRUE
020769     END-IF.
020769
020769 9225-GET-ORIG-LOAN-USTX-X.
020769     EXIT.
      *
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *  TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     MOVE SPACES                TO WWKDT-WORK-FIELDS.
025970     SET  WS-MAX-BROWSE-LINES-DEFAULT  TO TRUE.
025970     SET  MIR-RETRN-OK          TO TRUE.
025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      ******************************************************************
      *                      PROCESSING COPYBOOKS                      *
      ******************************************************************
      *
      *
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
026057 COPY CCPPIHSD.
       COPY XCPPEXIT.
       COPY XCPPINIT.
      *
      ******************************************************************
      *                      LINK COPYBOOKS                            *
      ******************************************************************
      *
025970 COPY XCPS1670.
       COPY CCPS2430.
018764*COPY CCCL2430.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL2430.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
       COPY CCPS5400.
      *
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
025970 COPY CCPS0620.
557668 COPY CCPL0620.
      *
025970 COPY XCPS0280.
       COPY XCPL0280.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1680.
005409 COPY XCPL1680.
      *
008455 COPY XCPL0290.
008455 COPY XCPS0290.
      *
      ******************************************************************
      *                     FILE HANDLING COPYBOOKS                    *
      ******************************************************************
      *
       COPY CCPNPOL.
      *
       COPY CCPVLHSD.
      *
       COPY CCPNLHST.
       COPY CCPVLHST.
013693 COPY CCPNUSTX.
      *
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *
      ******************************************************************
      *                  END OF PROGRAM CSOM0675                       *
      ******************************************************************
