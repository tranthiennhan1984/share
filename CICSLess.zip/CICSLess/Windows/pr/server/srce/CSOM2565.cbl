      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2565.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2565                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE COPY FUNCTION         **
      **            FOR THE IPRD AND IPDF TABLES                     **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020463**  6.4       INVESTOR PROFILES                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2565'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-CONSTANTS.
               10  WS-TWRK-KEY               PIC X(04)
                                             VALUE '2565'.
025970             88  WS-TWRK-KEY-DEFAULT   VALUE '2565'.

           05  WS-VARIABLES.
               10  WS-BUS-FCN-ID             PIC X(04).
                   88  WS-BUS-FCN-RETRIEVE   VALUE '2565'.
               10  WS-PRFLD-EFF-DT           PIC X(10).
               10  WS-PRFLD-SEQ-NUM          PIC 9(03).
               10  WS-PRFLD-EFF-DT-2         PIC X(10).
               10  WS-NEW-SEQ-NUM            PIC S9(03) COMP-3.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
       COPY XCWL8090.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWIPDF.
       COPY CCFRIPDF.
      /
       COPY CCFWIPRD.
       COPY CCFRIPRD.
      /
       COPY CCFWIPRO.
       COPY CCFRIPRO.
      /
       COPY CCWWLOCK.
      /
       COPY CCFWIPRE.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2565.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID
025970*                               TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-CLONE
                        THRU 2000-CLONE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2565'   TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000' TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *-----------
       2000-CLONE.
      *-----------

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  IPRO-2000-UPDATE-TWRK-TS
               THRU IPRO-2000-UPDATE-TWRK-TS-X.

           IF  WIPRO-IO-NOT-FOUND
      *MSG: INVESTOR PROFILE RECORD (@1) DOES NOT EXIST
               MOVE MIR-PRFL-ID
                                       TO WGLOB-MSG-PARM (1)
               MOVE 'CS25650001'
                                       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                                       TO TRUE
               GO TO 2000-CLONE-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG: 'PROCESS FAILED - RE-ENTER DATA AS ANOTHER PROCESS HAS
      *      UPDATED - TABLE (@1), KEY @2'
               MOVE 'XS00000303'
                                       TO WGLOB-MSG-REF-INFO
               MOVE 'IPRO'
                                       TO WGLOB-MSG-PARM (1)
               MOVE WIPRO-KEY
                                       TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-CLONE-X
           END-IF.

           PERFORM  7200-VALIDATE-KEY
               THRU 7200-VALIDATE-KEY-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               PERFORM  IPRO-3000-UNLOCK
                   THRU IPRO-3000-UNLOCK-X
               GO TO 2000-CLONE-X
           END-IF.

           PERFORM  IPRD-1000-READ
               THRU IPRD-1000-READ-X.

           IF  NOT WIPRD-IO-OK
      *MSG: SOURCE INVESTOR PROFILE (@1) DOES NOT EXIST
               MOVE 'CS25650001'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-PRFL-ID        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2000-CLONE-X
           END-IF.
           
      * IN CASE A PENDING RECORD DOES EXIST ON IPRD, COPY CANNOT BE DONE
      * BROWSE THE IPRD TO FIND THE ACTIVE RECORD.
      *     
           MOVE LOW-VALUES             TO WIPRE-KEY.
           MOVE MIR-PRFL-ID-2          TO WIPRE-PRFL-ID.
           SET WIPRE-PRFLD-STAT-PEND   TO TRUE.
 
           MOVE WIPRE-KEY              TO WIPRE-ENDBR-KEY.
 
           PERFORM  IPRE-1000-BROWSE
               THRU IPRE-1000-BROWSE-X.
      
           IF WIPRE-IO-OK
               PERFORM  IPRE-2000-READ-NEXT
                   THRU IPRE-2000-READ-NEXT-X
           END-IF.
           
           IF WIPRE-IO-OK
      *MSG: PENDING INVESTOR PROFILE DETAIL RECORD ALREADY 
      *     EXISTS : CANNOT COPY
               MOVE 'CS25650011'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2000-CLONE-X
           END-IF.
           
           PERFORM  IPRE-3000-END-BROWSE
               THRU IPRE-3000-END-BROWSE-X.
 
      *
      *  MOVE THE DETAIL DATA FROM THE PROFILE TABLE
      *
           PERFORM  8000-GET-NEXT-DEST-SEQ
               THRU 8000-GET-NEXT-DEST-SEQ-X.

           PERFORM  8200-COPY-IPRD-RECORD
               THRU 8200-COPY-IPRD-RECORD-X.

           IF  WGLOB-RETURN-ERROR
               PERFORM  IPRO-3000-UNLOCK
                   THRU IPRO-3000-UNLOCK-X
               GO TO 2000-CLONE-X
           END-IF.

           PERFORM  8100-COPY-IPDF-RECORDS
               THRU 8100-COPY-IPDF-RECORDS-X.

           IF  WGLOB-RETURN-ERROR
               PERFORM  IPRO-3000-UNLOCK
                   THRU IPRO-3000-UNLOCK-X
               GO TO 2000-CLONE-X
           END-IF.

           PERFORM  IPRO-2000-REWRITE
               THRU IPRO-2000-REWRITE-X.

      *MSG: RECORD CREATED SUCCESSFULLY - CONTINUE

           MOVE 'CS25650010'           TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
               
               
      *  UPDATE THE TIMESTAMP FOR LOGICAL LOCKING

           PERFORM  IPRO-1000-READ-TWRK-TS
               THRU IPRO-1000-READ-TWRK-TS-X.

       2000-CLONE-X.
           EXIT.

      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WIPRD-KEY.
           MOVE MIR-PRFL-ID            TO WIPRD-PRFL-ID.
           MOVE MIR-PRFL-ID            TO WIPRO-PRFL-ID.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *------------------
       7200-VALIDATE-KEY.
      *------------------

           IF  MIR-PRFL-ID = SPACE
      *MSG: SOURCE INVESTOR PROFILE ID (@1) MUST BE VALID
               MOVE 'CS25650002'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-PRFL-ID        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-PRFLD-EFF-DT       TO L1640-EXTERNAL-DATE.
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                       TO WIPRD-PRFLD-EFF-DT
               MOVE L1640-INTERNAL-DATE
                                       TO WS-PRFLD-EFF-DT
           ELSE
      *MSG: SOURCE INVESTOR PROFILE EFFECTIVE DATE MUST BE VALID
               MOVE 'CS25650003'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-PRFLD-SEQ-NUM      TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-PRFLD-SEQ-NUM
                                       TO L0280-INPUT-SIZE.
           MOVE LENGTH OF MIR-PRFLD-SEQ-NUM
                                       TO L0280-LENGTH.
           MOVE ZERO                   TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED
                                       TO TRUE.
           SET L0280-SPACES-PERMITTED  TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT       TO WIPRD-PRFLD-SEQ-NUM
               MOVE L0280-OUTPUT       TO WS-PRFLD-SEQ-NUM
           ELSE
      *MSG: SOURCE SEQUENCE NUMBER MUST BE VALID
               MOVE 'CS25650004'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  MIR-PRFL-ID-2 = SPACE
      *MSG: DESTINATION INVESTOR PROFILE ID (@1) MUST BE VALID
               MOVE 'CS25650005'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-PRFL-ID        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-PRFL-ID-2          TO WIPRO-PRFL-ID.
           PERFORM  IPRO-1000-READ
               THRU IPRO-1000-READ-X.

           IF  NOT WIPRO-IO-OK
      *MSG: DESTINATION INVESTOR PROFILE ID (@1) MUST BE VALID
               MOVE MIR-PRFL-ID        TO WGLOB-MSG-PARM (1)
               MOVE 'CS25650005'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-PRFLD-EFF-DT-2       TO L1640-EXTERNAL-DATE.
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                       TO WS-PRFLD-EFF-DT-2
           ELSE
      *MSG: DESTINATION INVESTOR PROFILE EFFECTIVE DATE MUST BE VALID
               MOVE 'CS25650006'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  RIPRO-PRFL-XPRY-DT NOT = WWKDT-ZERO-DT
               IF  WS-PRFLD-EFF-DT-2 > RIPRO-PRFL-XPRY-DT
      *MSG: COPY DISALLOWED, EFFECTIVE DATE OF DESTINATION RECORD LATER
      *     THAN EXPIRY DATE
                  MOVE 'CS25650012'       TO WGLOB-MSG-REF-INFO
                  PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF   
           END-IF.

           IF MIR-PRFL-ID-2 = MIR-PRFL-ID
              IF  WS-PRFLD-EFF-DT-2 < WS-PRFLD-EFF-DT
      *MSG: COPY DISALLOWED, EFFECTIVE DATE OF DESTINATION RECORD MUST
      * BE >= EFFECTIVE DATE OF CURRENT RECORD
                   MOVE 'CS25650013'       TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
              END-IF         
           END-IF.

       7200-VALIDATE-KEY-X.
           EXIT.
      /
      *-----------------------
       8000-GET-NEXT-DEST-SEQ.
      *-----------------------

           MOVE MIR-PRFL-ID-2          TO WIPRD-PRFL-ID.
           MOVE WWKDT-HIGH-DT          TO WIPRD-PRFLD-EFF-DT.
           MOVE 999                    TO WIPRD-PRFLD-SEQ-NUM.

           MOVE WIPRD-KEY              TO WIPRD-ENDBR-KEY.
           MOVE WWKDT-LOW-DT           TO WIPRD-ENDBR-PRFLD-EFF-DT.
           MOVE ZERO                   TO WIPRD-ENDBR-PRFLD-SEQ-NUM.

           PERFORM  IPRD-1000-BROWSE-PREV
               THRU IPRD-1000-BROWSE-PREV-X.

           IF WIPRD-IO-OK
               PERFORM  IPRD-2000-READ-PREV
                   THRU IPRD-2000-READ-PREV-X
           END-IF.

           IF  WIPRD-IO-OK
               IF MIR-PRFL-ID-2 = RIPRD-PRFL-ID
               AND WS-PRFLD-EFF-DT-2 = RIPRD-PRFLD-EFF-DT
                   COMPUTE WS-NEW-SEQ-NUM = RIPRD-PRFLD-SEQ-NUM + 1
               ELSE
                   MOVE 1                   TO WS-NEW-SEQ-NUM
               END-IF
               
               IF  WS-PRFLD-EFF-DT-2 < RIPRD-PRFLD-EFF-DT
      *MSG: COPY DISALLOWED, EFFECTIVE DATE OF DESTINATION RECORD MUST 
      *     BE >= EFFECTIVE DATE OF CURRENT RECORD
                   MOVE 'CS25650013'       TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR  TO TRUE
              END-IF
           ELSE
              MOVE 1                   TO WS-NEW-SEQ-NUM
           END-IF.

           PERFORM  IPRD-3000-END-BROWSE-PREV
               THRU IPRD-3000-END-BROWSE-PREV-X.

       8000-GET-NEXT-DEST-SEQ-X.
           EXIT.
      /
      *-----------------------
       8100-COPY-IPDF-RECORDS.
      *-----------------------

           MOVE LOW-VALUE              TO WIPDF-KEY.
           MOVE MIR-PRFL-ID            TO WIPDF-PRFL-ID.
           MOVE WS-PRFLD-EFF-DT        TO WIPDF-PRFLD-EFF-DT.
           MOVE WS-PRFLD-SEQ-NUM       TO WIPDF-PRFLD-SEQ-NUM.
           MOVE ZERO                   TO WIPDF-PRFLDF-SEQ-NUM.

           MOVE WIPDF-KEY              TO WIPDF-ENDBR-KEY.
           MOVE 999                    TO WIPDF-ENDBR-PRFLDF-SEQ-NUM.
           
           PERFORM  IPDF-1000-BROWSE
               THRU IPDF-1000-BROWSE-X.

           PERFORM  IPDF-2000-READ-NEXT
               THRU IPDF-2000-READ-NEXT-X.

           IF  NOT WIPDF-IO-OK
      *MSG: NO FUND RECORDS FOUND TO COPY
               MOVE 'CS25650009'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  8150-CREATE-IPDF-REC
               THRU 8150-CREATE-IPDF-REC-X
               UNTIL  NOT WIPDF-IO-OK.

           PERFORM  IPDF-3000-END-BROWSE
               THRU IPDF-3000-END-BROWSE-X.

       8100-COPY-IPDF-RECORDS-X.
           EXIT.
      /
      *---------------------
       8150-CREATE-IPDF-REC.
      *---------------------

           MOVE MIR-PRFL-ID-2          TO WIPDF-PRFL-ID.
           MOVE WS-PRFLD-EFF-DT-2      TO WIPDF-PRFLD-EFF-DT.
           MOVE WS-NEW-SEQ-NUM         TO WIPDF-PRFLD-SEQ-NUM.
           MOVE RIPDF-PRFLDF-SEQ-NUM   TO WIPDF-PRFLDF-SEQ-NUM.

           MOVE WIPDF-KEY              TO RIPDF-KEY.

           PERFORM  IPDF-1000-WRITE
               THRU IPDF-1000-WRITE-X.

           IF  NOT WIPDF-IO-OK
      *MSG: NEW INVESTOR PROFILE FUND DETAIL RECORD CAN NOT BE CREATED
               MOVE 'CS25650007'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 8150-CREATE-IPDF-REC-X
           END-IF.

           PERFORM  IPDF-2000-READ-NEXT
               THRU IPDF-2000-READ-NEXT-X.

       8150-CREATE-IPDF-REC-X.
           EXIT.
      /
      *----------------------
       8200-COPY-IPRD-RECORD.
      *----------------------

           MOVE MIR-PRFL-ID-2          TO WIPRD-PRFL-ID.
           MOVE WS-PRFLD-EFF-DT-2      TO WIPRD-PRFLD-EFF-DT.
           MOVE WS-NEW-SEQ-NUM         TO WIPRD-PRFLD-SEQ-NUM.

           MOVE WIPRD-KEY              TO RIPRD-KEY.
           
           SET RIPRD-PRFLD-STAT-PEND   TO TRUE.
           MOVE WWKDT-ZERO-DT          TO RIPRD-PRFLD-STAT-CHNG-DT.
           MOVE WWKDT-ZERO-DT          TO RIPRD-PRFLD-POL-CHNG-DT.

           PERFORM  IPRD-1000-WRITE
               THRU IPRD-1000-WRITE-X.

           IF  NOT WIPRD-IO-OK
      *MSG: NEW INVESTOR PROFILE DETAIL RECORD CAN NOT BE CREATED
               MOVE 'CS25650008'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

       8200-COPY-IPRD-RECORD-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-VARIABLES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WWKDT-WORK-FIELDS.
025970     SET  MIR-RETRN-OK          TO  TRUE.
025970     SET  WS-TWRK-KEY-DEFAULT   TO  TRUE.   
025970     MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  IPRO
                                '$VAR2'   BY 'IPRO'.
       COPY XCPL8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNIPRO.
       COPY CCPUIPRO.
       COPY CCPAIPRD.
       COPY CCPNIPRD.
       COPY CCPVIPRD.
       COPY CCPAIPDF.
       COPY CCPBIPDF.
       COPY CCPBIPRE.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM CSOM2565                        **
      *****************************************************************
