      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM0290.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM0290                                         **
      **  REMARKS:  TTAB: MAINTAIN TRANSLATE TABLE.                  **
      **            THIS MODULE PERFORMS THE TABLE MAINTENANCE       **
      **            FUNCTIONS FOR THE TRANSLATE TABLE.               **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557659**  5.5       DATA ARCHITECTURE MODIFICATIONS                  **
557660**  5.5       CODE CLEANUP/STANDARDIZATION                     **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016440**  6.2       COMBINE NB TO ADMIN - ONLINE REQUIREMENTS        **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0290'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.


025970*01  WS-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'TTAB'.

016537*COPY XCWWWKDT.
       COPY XCWEBLCH.
       01  WS-PGM-WORK-AREA.
           05  WS-EDIT-CHECKS.
               10  WS-BUS-FCN-ID            PIC X(04).
                   88  WS-BUS-FCN-VALID     VALUE '0290' '0291'
                                                  '0292' '0293'
                                                  '0294'.
                   88  WS-BUS-FCN-RETRIEVE  VALUE '0290'.
                   88  WS-BUS-FCN-CREATE    VALUE '0291'.
                   88  WS-BUS-FCN-UPDATE    VALUE '0292'.
                   88  WS-BUS-FCN-DELETE    VALUE '0293'.
                   88  WS-BUS-FCN-LIST      VALUE '0294'.
      *
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '0290'.
      *
           05  WS-VALIDATE-FAIL-SW          PIC X(01).
               88  VALIDATE-FAILED          VALUE 'Y'.
           05  WS-INQUIRY-SW                PIC X.
               88  INQ-REC-FOUND            VALUE 'Y'.
               88  INQ-REC-NOT-FOUND        VALUE 'N'.
      *
016548*    05  WS-LINE                      PIC S9(04) COMP.
016548     05  WS-LINE                      PIC S9(04) BINARY.
016548*    05  WS-MAX-ARRAY-LINES           PIC S9(04) COMP VALUE +12.
025970*    05  WS-MAX-ARRAY-LINES           PIC S9(04) BINARY VALUE +12.

025970/
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-DEFAULT-TRANS-NAME               VALUE 'TTAB'.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULKT-TWRK-KEY                VALUE '0290'.
025970     05  WS-MAX-ARRAY-LINES           PIC S9(04) BINARY.
025970         88  WS-DEFAULT-MAX-ARRAY-LINES          VALUE +12.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
014221 COPY CCWWLOCK.
014221 COPY XCWL8090.
      /
       COPY NCFWTTAB.
       COPY NCFRTTAB.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /

       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

      /
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0290.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      **********************
       2000-PROCESS-REQUEST.
      **********************
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
025970*    SET  MIR-RETRN-OK          TO TRUE.

           IF  NOT WS-BUS-FCN-VALID
               SET MIR-RETRN-INVALD-RQST TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      *    PROCESS SCREEN FUNCTIONS
      *

557660     EVALUATE TRUE
               WHEN WS-BUS-FCN-RETRIEVE
                   PERFORM  3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X
557660         WHEN WS-BUS-FCN-LIST
                   PERFORM  3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X
557660         WHEN WS-BUS-FCN-CREATE
                   PERFORM  4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X
557660         WHEN WS-BUS-FCN-UPDATE
                   PERFORM  5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X
557660         WHEN WS-BUS-FCN-DELETE
                   PERFORM  6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X
557660     END-EVALUATE.
      *
       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      ****************************************************************
      * RETRIEVE PROCESSING:  SETUP RECORD KEYS, READ FILE, AND      *
      * RETURN RECORD INFORMATION.                                   *
      ****************************************************************
       3000-PROCESS-RETRIEVE.
      *
           PERFORM  7100-BUILD-TTAB-KEY
               THRU 7100-BUILD-TTAB-KEY-X.

014221*    PERFORM TTAB-1000-READ
014221*       THRU TTAB-1000-READ-X.

014221     PERFORM TTAB-1000-READ-TWRK-TS
014221        THRU TTAB-1000-READ-TWRK-TS-X.

           IF WTTAB-IO-NOT-FOUND
               MOVE WTTAB-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

           ELSE
               MOVE 1                 TO WS-LINE
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X

557660     END-IF.
      *
       3000-PROCESS-RETRIEVE-X.
           EXIT.

      /
      ****************************************************************
      * INQUIRY PROCESSING:  SETUP BROWSE KEYS, BEGIN BROWSE, AND    *
      * LOAD DATA ARRAY UNTIL END-OF-FILE OR SCREEN IS FULL.         *
      ****************************************************************
       3500-PROCESS-LIST.
      *
           IF MIR-ETBL-TYP-ID = SPACES
               MOVE 'NS02900008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
557660     END-IF.

           MOVE 'N'                   TO WS-INQUIRY-SW.
           MOVE LOW-VALUES            TO WTTAB-KEY.
           MOVE HIGH-VALUES           TO WTTAB-ENDBR-KEY.
           MOVE MIR-ETBL-TYP-ID       TO WTTAB-ETBL-TYP-ID
                                          WTTAB-ENDBR-ETBL-TYP-ID.
           IF MIR-ETBL-VALU-ID NOT = SPACES
               MOVE MIR-ETBL-VALU-ID  TO WTTAB-ETBL-VALU-ID
557660     END-IF.
      *
           PERFORM TTAB-1000-BROWSE
              THRU TTAB-1000-BROWSE-X.
      *
      *
      *
           IF  NOT WTTAB-IO-EOF
               PERFORM  TTAB-2000-READ-NEXT
                   THRU TTAB-2000-READ-NEXT-X
               MOVE 1                 TO WS-LINE
               PERFORM  3550-DISPLAY-RECORD
                   THRU 3550-DISPLAY-RECORD-X
                   UNTIL WTTAB-IO-EOF
                      OR (WS-LINE > WS-MAX-ARRAY-LINES)
557660     END-IF.

           IF  INQ-REC-NOT-FOUND
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3500-PROCESS-LIST-X
557660     END-IF.

           IF WTTAB-IO-EOF
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE RTTAB-ETBL-VALU-ID   TO MIR-ETBL-VALU-ID
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  TTAB-3000-END-BROWSE
               THRU TTAB-3000-END-BROWSE-X.
      *
       3500-PROCESS-LIST-X.
           EXIT.
      /
557660 3550-DISPLAY-RECORD.
      *
016440*    IF  (MIR-TTAB-ADMIN-APPL-ID = SPACES) OR
016440     IF  (MIR-TTBL-SYS-ID = SPACES) OR
557659*        (RTTAB-APPL-ID = MIR-TTAB-ADMIN-APPL-ID)
016440*        (RTTAB-TTAB-ADMIN-APPL-ID = MIR-TTAB-ADMIN-APPL-ID)
016440         (RTTAB-TTBL-SYS-ID = MIR-TTBL-SYS-ID)
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
               MOVE 'Y'               TO WS-INQUIRY-SW
               ADD 1    TO WS-LINE
557660     END-IF.

           PERFORM  TTAB-2000-READ-NEXT
               THRU TTAB-2000-READ-NEXT-X.
      *
557660 3550-DISPLAY-RECORD-X.
           EXIT.
      *
      /
      ****************************************************************
      * CREATE PROCESSING:  CHECK IF RECORD DOES NOT EXIST, INIT    *
      * NEW RECORD AND ALLOW USER TO MODIFY.                        *
      ****************************************************************
       4000-PROCESS-CREATE.
      *
           PERFORM  7000-VALIDATE-CONTROL-FIELDS
               THRU 7000-VALIDATE-CONTROL-FIELDS-X.

           IF VALIDATE-FAILED
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

           PERFORM  7100-BUILD-TTAB-KEY
               THRU 7100-BUILD-TTAB-KEY-X.

           PERFORM TTAB-1000-READ
              THRU TTAB-1000-READ-X.

           IF WTTAB-IO-OK
               MOVE WTTAB-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           ELSE
               PERFORM  TTAB-1000-CREATE
                   THRU TTAB-1000-CREATE-X
               PERFORM  TTAB-1000-WRITE
                   THRU TTAB-1000-WRITE-X
014221         PERFORM  TTAB-1000-READ-TWRK-TS
014221             THRU TTAB-1000-READ-TWRK-TS-X
               MOVE 'XS00000004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WS-LINE
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
557660     END-IF.

      *
       4000-PROCESS-CREATE-X.
           EXIT.
      /
      ****************************************************************
      * MAINTAIN PROCESSING                                         *
      ****************************************************************
       5000-PROCESS-UPDATE.
      *
           IF MIR-ETBL-TYP-ID = 'TTAB'
               MOVE 'NS02900009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.
      *
           PERFORM  7100-BUILD-TTAB-KEY
               THRU 7100-BUILD-TTAB-KEY-X.

014221*    PERFORM TTAB-1000-READ-FOR-UPDATE
014221*       THRU TTAB-1000-READ-FOR-UPDATE-X.

014221     PERFORM TTAB-2000-UPDATE-TWRK-TS
014221        THRU TTAB-2000-UPDATE-TWRK-TS-X.

           IF WTTAB-IO-NOT-FOUND
               MOVE WTTAB-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               GO TO 5000-PROCESS-UPDATE-X
557660     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'TTAB'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WTTAB-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF MIR-TTBL-VALU-TXT-T (1) = SPACES
               MOVE RTTAB-TTBL-VALU-TXT
                                      TO MIR-TTBL-VALU-TXT-T (1)
           ELSE
               IF MIR-TTBL-VALU-TXT-T (1) = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-TTBL-VALU-TXT-T (1)
557660         END-IF
557660     END-IF.

           MOVE MIR-TTBL-VALU-TXT-T (1)
                                      TO RTTAB-TTBL-VALU-TXT.

           PERFORM  TTAB-2000-REWRITE
               THRU TTAB-2000-REWRITE-X.

014221     PERFORM  TTAB-1000-READ-TWRK-TS
014221         THRU TTAB-1000-READ-TWRK-TS-X.

           MOVE 'XS00000007'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

      *
       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      ****************************************************************
      * DELETE PROCESSING                                            *
      ****************************************************************
       6000-PROCESS-DELETE.
      *
           PERFORM  7100-BUILD-TTAB-KEY
               THRU 7100-BUILD-TTAB-KEY-X.

014221*    PERFORM TTAB-1000-READ-FOR-UPDATE
014221*       THRU TTAB-1000-READ-FOR-UPDATE-X.

014221     PERFORM TTAB-2000-UPDATE-TWRK-TS
014221        THRU TTAB-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'TTAB'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WTTAB-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF WTTAB-IO-OK
               PERFORM  TTAB-1000-DELETE
                   THRU TTAB-1000-DELETE-X
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           ELSE
               MOVE WTTAB-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
557660     END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
       6000-PROCESS-DELETE-X.
           EXIT.
      /
       7000-VALIDATE-CONTROL-FIELDS.
      *
           MOVE 'N'                   TO WS-VALIDATE-FAIL-SW.

557660     EVALUATE TRUE
557660         WHEN MIR-ETBL-TYP-ID = SPACES
                   MOVE 'NS02900001'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'Y'           TO WS-VALIDATE-FAIL-SW
557660         WHEN MIR-ETBL-TYP-ID = 'TTAB'
      ***          DO NOT EDIT TYPE WHEN CREATING AN INDEX
557660             CONTINUE
557660         WHEN OTHER
                   MOVE MIR-ETBL-TYP-ID
                                      TO WEDIT-ETBL-VALU-ID
                   PERFORM  EDIT-1000-EDIT-TYPE
                       THRU EDIT-1000-EDIT-TYPE-X
                   IF WEDIT-IO-OK
034802*                NEXT SENTENCE
034802                 CONTINUE
                   ELSE
                       MOVE MIR-ETBL-TYP-ID
                                      TO WGLOB-MSG-PARM (1)
                       MOVE 'NS02900002'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                       MOVE 'Y'       TO WS-VALIDATE-FAIL-SW
557660             END-IF
557660     END-EVALUATE.

           IF MIR-ETBL-TYP-ID = 'TTAB'
               MOVE 'EDIT'            TO WEDIT-ETBL-TYP-ID
           ELSE
               MOVE MIR-ETBL-TYP-ID   TO WEDIT-ETBL-TYP-ID
557660     END-IF.
           MOVE MIR-ETBL-VALU-ID      TO WEDIT-ETBL-VALU-ID.
           MOVE WGLOB-EDIT-LANG       TO WEDIT-ETBL-LANG-CD.
           PERFORM  EDIT-1000-READ
               THRU EDIT-1000-READ-X.
           IF WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE 'Y'               TO WS-VALIDATE-FAIL-SW
               MOVE MIR-ETBL-VALU-ID  TO WGLOB-MSG-PARM (2)
               MOVE 'NS02900004'      TO WGLOB-MSG-REF-INFO
               IF MIR-ETBL-TYP-ID = 'TTAB'
                   MOVE 'EDIT'        TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE MIR-ETBL-TYP-ID
                                      TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.

016440*    MOVE MIR-TTAB-ADMIN-APPL-ID  TO WEDIT-ETBL-VALU-ID.
016440     MOVE MIR-TTBL-SYS-ID  TO WEDIT-ETBL-VALU-ID.
           PERFORM  ADMN-1000-EDIT-ADMIN-SYSTEM
               THRU ADMN-1000-EDIT-ADMIN-SYSTEM-X.

           IF WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
016440*        MOVE MIR-TTAB-ADMIN-APPL-ID
016440         MOVE MIR-TTBL-SYS-ID
                                      TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000109'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-VALIDATE-FAIL-SW
557660     END-IF.
      *
       7000-VALIDATE-CONTROL-FIELDS-X.
           EXIT.
      /
       7100-BUILD-TTAB-KEY.
      *
           MOVE MIR-ETBL-TYP-ID       TO WTTAB-ETBL-TYP-ID.
           MOVE MIR-ETBL-VALU-ID      TO WTTAB-ETBL-VALU-ID.
557659*    MOVE MIR-TTAB-ADMIN-APPL-ID   TO WTTAB-APPL-ID.
016440*    MOVE MIR-TTAB-ADMIN-APPL-ID   TO WTTAB-TTAB-ADMIN-APPL-ID.
016440     MOVE MIR-TTBL-SYS-ID          TO WTTAB-TTBL-SYS-ID.

       7100-BUILD-TTAB-KEY-X.
           EXIT.
      /
       9100-BLANK-DATA-FIELDS.
      *
           PERFORM 9110-BLANK-LINE
              THRU 9110-BLANK-LINE-X
              VARYING WS-LINE FROM 1 BY 1
              UNTIL WS-LINE GREATER THAN 12.
      *
       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *
       9110-BLANK-LINE.
      *
           MOVE SPACES           TO  MIR-ETBL-TYP-ID-T (WS-LINE).
           MOVE SPACES           TO  MIR-ETBL-VALU-ID-T (WS-LINE).
           MOVE SPACES           TO  MIR-ETBL-DESC-TXT-T (WS-LINE).
016440*    MOVE SPACES           TO  MIR-TTAB-ADMIN-APPL-ID-T (WS-LINE).
016440     MOVE SPACES           TO  MIR-TTBL-SYS-ID-T (WS-LINE).
           MOVE SPACES           TO  MIR-TTBL-VALU-TXT-T (WS-LINE).
      *
       9110-BLANK-LINE-X.
           EXIT.
      /
       9200-MOVE-RECORD-TO-SCREEN.
      *
           MOVE RTTAB-ETBL-TYP-ID     TO MIR-ETBL-TYP-ID-T (WS-LINE).
           MOVE RTTAB-ETBL-VALU-ID    TO MIR-ETBL-VALU-ID-T (WS-LINE).
557659*    MOVE RTTAB-APPL-ID    TO MIR-TTAB-ADMIN-APPL-ID-T (WS-LINE).
016440*    MOVE RTTAB-TTAB-ADMIN-APPL-ID
016440*                          TO MIR-TTAB-ADMIN-APPL-ID-T (WS-LINE).
016440     MOVE RTTAB-TTBL-SYS-ID     TO MIR-TTBL-SYS-ID-T (WS-LINE).
           MOVE RTTAB-TTBL-VALU-TXT   TO MIR-TTBL-VALU-TXT-T (WS-LINE).

           IF RTTAB-ETBL-TYP-ID     = 'TTAB'
               MOVE 'EDIT'            TO WEDIT-ETBL-TYP-ID
           ELSE
               MOVE RTTAB-ETBL-TYP-ID TO WEDIT-ETBL-TYP-ID
557660     END-IF.
           MOVE RTTAB-ETBL-VALU-ID    TO WEDIT-ETBL-VALU-ID.
           MOVE WGLOB-USER-LANG       TO WEDIT-ETBL-LANG-CD.

           PERFORM  EDIT-1000-READ
               THRU EDIT-1000-READ-X.

           IF WEDIT-IO-OK
               MOVE REDIT-ETBL-DESC-TXT
                                      TO MIR-ETBL-DESC-TXT-T (WS-LINE)
           ELSE
               MOVE 'NS02900006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-2000-GET-MESSAGE
                   THRU 0260-2000-GET-MESSAGE-X
               MOVE WGLOB-MSG-TXT     TO MIR-ETBL-DESC-TXT-T (WS-LINE)
557660     END-IF.
      *
       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
       9300-SETUP-MSIN-REFERENCE.
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
      *
       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TRANS-NAME          TO TRUE.
025970     SET WS-DEFAULKT-TWRK-KEY           TO TRUE.
025970     SET WS-DEFAULT-MAX-ARRAY-LINES     TO TRUE.
023514
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPEADMN.
       COPY NCPEEDIT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY TTAB
014221                         '$VAR2' BY 'TTAB'.
      /
      ****************************************************************
      * GENERAL COPYBOOKS                                            *
      ****************************************************************
       COPY XCPPINIT.
       COPY XCPPEXIT.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNEDIT.
      /
       COPY NCPATTAB.
       COPY NCPBTTAB.
       COPY NCPNTTAB.
       COPY NCPUTTAB.
       COPY NCPXTTAB.
       COPY NCPCTTAB.
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM0290                     **
      *****************************************************************
