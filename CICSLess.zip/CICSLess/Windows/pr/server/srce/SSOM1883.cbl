      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM1883.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM1883                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE DELETE FUNCTION   **
      **            FOR THE FV TABLE                                 **
      **                                                             **
      **            THE DELETE WILL DELETE ALL UNIT TYPES            **
      **            FOR THE FUND                                     **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
021239**  6.4       FUND UNIT VALUE                                  **
024126**  6.5       LOCKING LOCKING                                  **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM1883'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-DELETE         VALUE '1883'.
           05  WS-FNDVL-EFF-DT               PIC X(10).
           05  WS-FNDVL-IDT-NUM              PIC X(07).
           05  WS-FV-REC-FOUND-SW            PIC X(01).
               88  WS-FV-REC-FOUND           VALUE 'Y'.
               88  WS-FV-REC-FOUND-NO        VALUE 'N'.
           05  WS-LAST-EFF-DT                PIC X(10).
024126     05  WS-FH-LOCK-SW                 PIC X(01).
024126         88  WS-FH-LOCKED              VALUE 'Y'.
024126         88  WS-FH-LOCKED-NO           VALUE 'N'.

       01  WS-CONSTANT-AREA.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970*                                      VALUE '1880'.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '1880'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY SCFWFH.
       COPY SCFRFH.

       COPY SCFWFVAA.
       COPY SCFWFV.
       COPY SCFRFV.

       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL1640.
       COPY XCWL1660.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM1883.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  2000-DELETE
                        THRU 2000-DELETE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE WPGWS-CRNT-PGM-ID
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *-------------
       2000-DELETE.
      *-------------

           PERFORM  2100-VALIDATE-DATA
               THRU 2100-VALIDATE-DATA-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
024126*        IF  MIR-DV-PRCES-STATE-CD = '3'
024126         IF  WS-FH-LOCKED
                   PERFORM  FH-3000-UNLOCK
                       THRU FH-3000-UNLOCK-X
               END-IF
               GO TO 2000-DELETE-X
           END-IF.

           IF  MIR-DV-PRCES-STATE-CD NOT = '3'
               GO TO 2000-DELETE-X
           END-IF.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  FVAA-1000-BROWSE
               THRU FVAA-1000-BROWSE-X.

           PERFORM  FVAA-2000-READ-NEXT
               THRU FVAA-2000-READ-NEXT-X.

           PERFORM
               UNTIL NOT WFVAA-IO-OK

               MOVE RFV-KEY            TO WFV-KEY

               PERFORM  FV-1000-READ-FOR-UPDATE
                   THRU FV-1000-READ-FOR-UPDATE-X

               PERFORM  9350-SETUP-FV-AUDIT-INFO
                   THRU 9350-SETUP-FV-AUDIT-INFO-X

               PERFORM  FV-1000-DELETE
                   THRU FV-1000-DELETE-X

               PERFORM  9350-SETUP-FV-AUDIT-INFO
                   THRU 9350-SETUP-FV-AUDIT-INFO-X

               PERFORM  FVAA-2000-READ-NEXT
                   THRU FVAA-2000-READ-NEXT-X

           END-PERFORM.

           PERFORM  FVAA-3000-END-BROWSE
               THRU FVAA-3000-END-BROWSE-X.

           PERFORM  2200-SET-FND-NXT-VALN-DT
               THRU 2200-SET-FND-NXT-VALN-DT-X.

       2000-DELETE-X.
           EXIT.

      *----------------------------
       2100-VALIDATE-DATA.
      *----------------------------

           PERFORM  2110-EDIT-FND-ID
               THRU 2110-EDIT-FND-ID-X.

           PERFORM  2120-EDIT-FNDVL-EFF-DT
               THRU 2120-EDIT-FNDVL-EFF-DT-X.

           PERFORM  2130-EDIT-FV-REC
               THRU 2130-EDIT-FV-REC-X.

       2100-VALIDATE-DATA-X.
           EXIT.

      *----------------------------
       2110-EDIT-FND-ID.
      *----------------------------

           MOVE MIR-FND-ID                  TO WFH-FND-ID.
024126     SET WS-FH-LOCKED-NO              TO TRUE.

           IF  MIR-DV-PRCES-STATE-CD = '3'
024126         SET WS-FH-LOCKED             TO TRUE
               PERFORM  FH-2000-UPDATE-TWRK-TS
                   THRU FH-2000-UPDATE-TWRK-TS-X
           ELSE
               PERFORM  FH-1000-READ-TWRK-TS
                   THRU FH-1000-READ-TWRK-TS-X
           END-IF.

           IF  WFH-IO-NOT-FOUND
024126         SET WS-FH-LOCKED-NO          TO TRUE
      *MSG: RECORD (@1) ON TABLE (@2) NOT FOUND. DELETE FAILED
               MOVE WFH-KEY                 TO WGLOB-MSG-PARM (1)
               MOVE 'FH'                    TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000010'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
           AND MIR-DV-PRCES-STATE-CD = '3'
024126         SET WS-FH-LOCKED-NO          TO TRUE
      *MSG: PROCESS FAILED - RE-ENTER DATA AS ANOTHER PROCESS HAS
      *     UPDATED - TABLE (@1), KEY @2
               MOVE 'XS00000303'            TO WGLOB-MSG-REF-INFO
               MOVE 'FH'                    TO WGLOB-MSG-PARM (1)
               MOVE WFH-KEY                 TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2110-EDIT-FND-ID-X.
           EXIT.

      *----------------------------
       2120-EDIT-FNDVL-EFF-DT.
      *----------------------------

           MOVE MIR-FNDVL-EFF-DT       TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      *MSG: INVALID FUND VALUATION DATE
               MOVE 'SS18830001'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2120-EDIT-FNDVL-EFF-DT-X
           END-IF.

           MOVE L1640-INTERNAL-DATE         TO WS-FNDVL-EFF-DT.

           MOVE WS-FNDVL-EFF-DT             TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE         TO WS-FNDVL-IDT-NUM.

           IF  WS-FNDVL-EFF-DT <= RFH-PREV-UNIT-ALLOC-DT
      *MSG: FV RECORD HAS BEEN USED TO ESTABLISH UNITS - CAN'T DELETE
               MOVE 'SS18830002'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2120-EDIT-FNDVL-EFF-DT-X.
           EXIT.

      *----------------------------
       2130-EDIT-FV-REC.
      *----------------------------

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2130-EDIT-FV-REC-X
           END-IF.

           MOVE LOW-VALUES           TO WFVAA-KEY.

           MOVE MIR-FND-ID           TO WFVAA-FND-ID.
           MOVE ZERO                 TO WFVAA-FNDVL-IDT-NUM.

           MOVE WFVAA-KEY            TO WFVAA-ENDBR-KEY.
           MOVE ALL '9'              TO WFVAA-ENDBR-FNDVL-IDT-NUM
           MOVE HIGH-VALUES          TO WFVAA-ENDBR-FNDVL-UNIT-TYP-CD.

           PERFORM  FVAA-1000-BROWSE
               THRU FVAA-1000-BROWSE-X.

           PERFORM  FVAA-2000-READ-NEXT
               THRU FVAA-2000-READ-NEXT-X.

           IF  NOT WFVAA-IO-OK
      *MSG: NO FV RECORDS EXIST FOR THIS FUND
               MOVE 'SS18830003'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF

           PERFORM  FVAA-3000-END-BROWSE
               THRU FVAA-3000-END-BROWSE-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2130-EDIT-FV-REC-X
           END-IF.

           IF  RFV-FNDVL-EFF-DT NOT = WS-FNDVL-EFF-DT
      *MSG: EFF. DATE MUST BE DATE OF MOST RECENT FV RECORD
               MOVE 'SS18830004'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2130-EDIT-FV-REC-X.
           EXIT.

      *----------------------------
       2200-SET-FND-NXT-VALN-DT.
      *----------------------------

           MOVE LOW-VALUES          TO WFVAA-KEY.

           MOVE MIR-FND-ID          TO WFVAA-FND-ID.
           MOVE ZERO                TO WFVAA-FNDVL-IDT-NUM.

           MOVE WFV-KEY             TO WFVAA-ENDBR-KEY.
           MOVE ALL '9'             TO WFVAA-ENDBR-FNDVL-IDT-NUM.
           MOVE HIGH-VALUES         TO WFVAA-ENDBR-FNDVL-UNIT-TYP-CD.

           PERFORM  FVAA-1000-BROWSE
               THRU FVAA-1000-BROWSE-X.

           PERFORM  FVAA-2000-READ-NEXT
               THRU FVAA-2000-READ-NEXT-X.

           SET WS-FV-REC-FOUND-NO           TO TRUE.
           MOVE WWKDT-LOW-DT                TO WS-LAST-EFF-DT.

           PERFORM
               UNTIL NOT WFVAA-IO-OK
               OR RFV-FNDVL-EFF-DT < WS-LAST-EFF-DT

               IF  RFV-PREV-FNDVL-IDT-NUM-N = WS-FNDVL-IDT-NUM
                   MOVE RFV-FNDVL-EFF-DT    TO WS-LAST-EFF-DT
                   SET WS-FV-REC-FOUND      TO TRUE
                   MOVE RFV-KEY             TO WFV-KEY
                   PERFORM  FV-1000-READ-FOR-UPDATE
                       THRU FV-1000-READ-FOR-UPDATE-X
                   PERFORM  9350-SETUP-FV-AUDIT-INFO
                       THRU 9350-SETUP-FV-AUDIT-INFO-X
                   MOVE ZERO                TO RFV-PREV-FNDVL-IDT-NUM-N
                   PERFORM  FV-2000-REWRITE
                       THRU FV-2000-REWRITE-X
                   PERFORM  9350-SETUP-FV-AUDIT-INFO
                       THRU 9350-SETUP-FV-AUDIT-INFO-X
               END-IF

               PERFORM  FVAA-2000-READ-NEXT
                   THRU FVAA-2000-READ-NEXT-X

           END-PERFORM.

           PERFORM  FVAA-3000-END-BROWSE
               THRU FVAA-3000-END-BROWSE-X.

           PERFORM  9360-SETUP-FH-AUDIT-INFO
               THRU 9360-SETUP-FH-AUDIT-INFO-X.

           IF  WS-FV-REC-FOUND
               MOVE WS-FNDVL-EFF-DT         TO RFH-FND-NXT-VALN-DT
           ELSE
               MOVE RFH-FND-CREAT-DT        TO RFH-FND-NXT-VALN-DT
           END-IF.

           MOVE RFH-FND-NXT-VALN-DT         TO MIR-FND-NXT-VALN-DT.

           PERFORM  FH-2000-REWRITE
               THRU FH-2000-REWRITE-X.

           PERFORM  9360-SETUP-FH-AUDIT-INFO
               THRU 9360-SETUP-FH-AUDIT-INFO-X.

       2200-SET-FND-NXT-VALN-DT-X.
           EXIT.

      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES           TO WFVAA-KEY.

           MOVE MIR-FND-ID           TO WFVAA-FND-ID.
           MOVE WS-FNDVL-IDT-NUM     TO WFVAA-FNDVL-IDT-NUM.

           MOVE WFVAA-KEY            TO WFVAA-ENDBR-KEY.
           MOVE HIGH-VALUE           TO WFVAA-ENDBR-FNDVL-UNIT-TYP-CD.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------
       9000-BLANK-DATA-FIELDS.
      *-----------------

           MOVE SPACE                       TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                     TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE         TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------
       9350-SETUP-FV-AUDIT-INFO.
      *----------------------

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM  FV-1000-CALL-AUDIT
                   THRU FV-1000-CALL-AUDIT-X
           END-IF.

       9350-SETUP-FV-AUDIT-INFO-X.
           EXIT.

      *----------------------
       9360-SETUP-FH-AUDIT-INFO.
      *----------------------

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM  FH-1000-CALL-AUDIT
                   THRU FH-1000-CALL-AUDIT-X
           END-IF.

       9360-SETUP-FH-AUDIT-INFO-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE MIR-OUTPUT-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

025970     SET WS-TWRK-KEY-DEFAULT     TO TRUE.
025970     MOVE SPACES                 TO WWKDT-WORK-FIELDS.
025970
       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  FH
                                '$VAR2'   BY 'FH'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
025970 COPY XCPS8090.
025970 COPY XCPS1640.
       COPY XCPL1640.

025970 COPY XCPS1660.
       COPY XCPL1660.

       COPY XCPL8090.

       COPY SCPLFH.
       COPY SCPLFV.

      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY SCPNFH.
       COPY SCPUFH.

       COPY SCPUFV.
       COPY SCPXFV.
       COPY SCPBFVAA.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM SSOM1883                        **
      *****************************************************************
