      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0171.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0171                                         **
      **  REMARKS:  GACC / ACPM - MANUAL POSTING OF ACCOUNTING       **
      **            ENTRIES TO THE GENERAL LEDGER.                   **
      **            THIS MODULE WILL CONTROL PROCESSING OF MANUAL    **
      **            POSTING OF GENERAL JOURNAL ACCOUNTING ENTRIES.   **
      **            THE PROCESS WILL HANDLE UPDATE OF PRIOR MONTHS'  **
      **            AND/OR YEARS' BALANCES (ACPM) OR THE CURRENT     **
      **            MONTHS' (GACC) POSTING OF MANUAL ENTRIES. THE    **
      **            ACCOUNTING ENTRIES WILL FIRST BE VALIDATED FOR   **
      **            ACCURACY AND IF VALID, WILL BE GENERATED.        **
      **                                                             **
      **  DOMAIN :  AC                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557696**  5.5       US TAX MISC WARNING MESSAGE                      **
557708**  5.5       CICS ABEND HANDLING                              **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010418**  5.6       MODIFICATIONS FOR MULTI-COMPANY                  **
567756**  5.6       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
013578**  6.0       ADD MIR-USER-SESN-CRCY-CD                        **
014590**  6.0       ARCHITECTURAL CHANGES                            **
016457**  6.2       ADD SNGL-SIDE-ENTR-IND                           **
016457**            RENAME FIELDS                                    **
016537**  6.2       CHANGE MIR-TRNXT-DT TO MIR-ACCT-TRXN-PRCES-DT    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
030743**  6.7       UNBALANCED ACCOUNTING FOR AGENT ACCOUNTING       **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0171'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.


       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-VALID              VALUE '1280' '1281'.
               88  WS-BUS-FCN-PRMACCT            VALUE '1280'.
               88  WS-BUS-FCN-CURACCT            VALUE '1281'.
016548*    05  ERROR-LINE-SCREEN             PIC 9(02) COMP.
025970*    05  ERROR-LINE-SCREEN             PIC 9(02) BINARY.
           05  WS-PIC-99                     PIC 9(02).
           05  HOLD-DATES.
               10  UP-LIMIT-DATE.
                   15  UP-LIMIT-YEAR         PIC 9(04).
                   15  FILLER                PIC X(01).
                   15  UP-LIMIT-MONTH        PIC 9(02).
                   15  FILLER                PIC X(01).
                   15  UP-LIMIT-DAY          PIC 9(02).
               10  LO-LIMIT-DATE.
                   15  LO-LIMIT-YEAR         PIC 9(04).
                   15  FILLER                PIC X(01).
                   15  LO-LIMIT-MONTH        PIC 9(02).
                   15  FILLER                PIC X(01).
                   15  LO-LIMIT-DAY          PIC 9(02).

557696     05  WS-ACCT.
557696         10  WS-ACCT-TYP               PIC X(01).
557696             88  WS-ACCT-TYP-COMM      VALUE '5'.
557696         10  WS-ACCT-NUM               PIC X(05).

           05  DATX.
               10  YR                        PIC 9(04).
               10  FILLER                    PIC X(01).
               10  MO                        PIC 9(02).
               10  FILLER                    PIC X(01).
               10  DY                        PIC 9(02).

       01  WS-WORK-AREA.
016548*    05  WS-SUB                        PIC S9(04) COMP.
016548     05  WS-SUB                        PIC S9(04) BINARY.
013578*    05  WS-MAX-LINES                  PIC S9(04) COMP VALUE +13.
016548*    05  WS-MAX-LINES                  PIC S9(04) COMP VALUE +10.
025970*    05  WS-MAX-LINES                  PIC S9(04)
025970*                                      BINARY VALUE +10.
008455*    05  WS-DISPLAY-AMT.
008455*        10  WS-AMT                    PIC 9(09).99.
025970 01  WS-CONSTANTS.
025970     05 WS-MAX-LINES                   PIC S9(04) BINARY.
025970        88 WS-MAX-LINES-DEFAULT        VALUE +10.
025970     05 ERROR-LINE-SCREEN              PIC S9(02) BINARY.
025970        88 ERROR-LINE-SCREEN-DEFAULT   VALUE +1.
      /
      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
016537*COPY CCWWINDX.
      /
       COPY XCWWWKDT.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
028298 COPY CCWL2626.
       COPY CCWL7070.
      /
557696 COPY CCWL4180.
      /
       COPY XCWL0280.
      /
008455 COPY XCWL0290.
008455/
       COPY XCWL1640.
      /
013578*COPY XCWL2510.
      /
       COPY XCWLDTLK.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
       COPY CCWLPGA.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0171.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  0200-PROCESS-REQUEST
               THRU 0200-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *--------------------------
       0200-PROCESS-REQUEST.
      *--------------------------

      *
      * CHECK THE VERIFY STEP RESPONSE.  IF RESPONSE IS OTHER THAN
      * 'YES' DETERMINE THE MESSAGE TO BE PRODUCED AND EXIT ROUTINE.
      *

008455     PERFORM 0290-1000-BUILD-PARM-INFO
008455        THRU 0290-1000-BUILD-PARM-INFO-X.
008455
           SET MIR-RETRN-OK           TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           IF  NOT WS-BUS-FCN-VALID
               SET MIR-RETRN-INVALD-RQST
                                      TO TRUE
               GO TO 0200-PROCESS-REQUEST-X
           END-IF.

013578     MOVE WGLOB-CURRENCY-CODE   TO MIR-USER-SESN-CRCY-CD.
013578
013578*    PERFORM 2510-1000-BUILD-PARM-INFO
013578*        THRU 2510-1000-BUILD-PARM-INFO-X.
013578*
      * INITIALIZE THE L7070 PARAMETER AREA:
      *
           MOVE SPACES                TO LPGA-PARM-INFO.
           INITIALIZE LPGA-PARM-INFO.

           PERFORM  7070-1000-BUILD-PARM-INFO
               THRU 7070-1000-BUILD-PARM-INFO-X.

      *
      * INITIALIZE FIELDS REQUIRED FOR PROCESSING
      *

016457*    MOVE MIR-DV-ACCT-DESC-TXT  TO L7070-DESCR.
016457     MOVE MIR-ACCT-DESC-TXT     TO L7070-DESCR.
016457     MOVE MIR-SNGL-SIDE-ENTR-IND
016457                                TO L7070-SNGL-SIDE-ENTR-IND.
016457*    MOVE MIR-DV-CHQ-VCHR-NUM   TO L7070-VOUCHER.
016457     MOVE MIR-CHQ-VCHR-ID       TO L7070-VOUCHER.
           MOVE MIR-POL-ID            TO L7070-POL-ID.
025970*    MOVE +1                    TO ERROR-LINE-SCREEN.
           MOVE ZERO                  TO WGLOB-MSG-ERROR-SW.

      *
      * VALIDATE ALL THE DATA FIELDS THAT HAVE BEEN ENTERED
      *

           PERFORM  1000-VALIDATE-KEY-FIELDS
               THRU 1000-VALIDATE-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW = 1
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 0200-PROCESS-REQUEST-X
           END-IF.

      *
      * EDIT AND/OR PROCESS TRANSACTION
      *

           PERFORM  2000-EDIT-PRCES-TRANSACTION
               THRU 2000-EDIT-PRCES-TRANSACTION-X.

       0200-PROCESS-REQUEST-X.
           EXIT.
      /
      *-------------------------
       1000-VALIDATE-KEY-FIELDS.
      *-------------------------

           PERFORM  1100-VALIDATE-DATE
               THRU 1100-VALIDATE-DATE-X.

      *
      * BUILD DETAIL INPUT ACCOUNTING ENTRIES TO BE PASSED TO THE
      * FUNCTION DRIVER CSLF7070
      *

           PERFORM  1200-BUILD-DTL-LINES
               THRU 1200-BUILD-DTL-LINES-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-LINES.

       1000-VALIDATE-KEY-FIELDS-X.
           EXIT.
      /
      *-------------------
       1100-VALIDATE-DATE.
      *-------------------

016537*    MOVE MIR-TRNXT-DT          TO L1640-EXTERNAL-DATE.
016537     MOVE MIR-ACCT-TRXN-PRCES-DT TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           MOVE L1640-INTERNAL-DATE   TO L7070-EFF-DT.
           MOVE WGLOB-PROCESS-DATE    TO DATX.

           IF  L1640-NOT-VALID
      *MSG: ENTER DATE IN CORRECT FORMAT
               MOVE 'CS00000036'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF  WS-BUS-FCN-CURACCT
                   PERFORM  1110-VRFY-GACC-DATE
                       THRU 1110-VRFY-GACC-DATE-X
               ELSE
                   PERFORM  1120-VRFY-ACPM-DATE
                       THRU 1120-VRFY-ACPM-DATE-X
               END-IF
           END-IF.

       1100-VALIDATE-DATE-X.
           EXIT.
      /
      *--------------------
       1110-VRFY-GACC-DATE.
      *--------------------

           IF  L1640-YYYY-1 NOT = YR
           OR  L1640-MM-1   NOT = MO
      *MSG: DATE MUST BE IN CURRENT MONTH AND CURRENT YEAR
               MOVE 'CS01710008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF  L1640-INTERNAL-DATE > WGLOB-PROCESS-DATE
      *MSG: DATE CANNOT BE IN THE FUTURE
                   MOVE 'CS01710011'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       1110-VRFY-GACC-DATE-X.
           EXIT.
      /
      *--------------------
       1120-VRFY-ACPM-DATE.
      *--------------------

           MOVE WGLOB-PROCESS-DATE    TO   UP-LIMIT-DATE.
           MOVE WGLOB-PROCESS-DATE    TO   LO-LIMIT-DATE.
           MOVE 31                    TO   UP-LIMIT-DAY.
           SUBTRACT 1                 FROM UP-LIMIT-MONTH.
           SUBTRACT 1                 FROM LO-LIMIT-YEAR.
           MOVE 01                    TO   LO-LIMIT-MONTH.
           MOVE 01                    TO   LO-LIMIT-DAY.

           IF  L7070-EFF-DT < LO-LIMIT-DATE
      *MSG: DATE IS PRIOR TO JANUARY 1 OF LAST YEAR.  RE-ENTER
               MOVE 'CS01710015'      TO   WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF  L7070-EFF-DT > UP-LIMIT-DATE
      *MSG: DATE MUST BE PRIOR TO THE CURRENT MONTH.  RE-ENTER
                   MOVE 'CS01710016'  TO   WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       1120-VRFY-ACPM-DATE-X.
           EXIT.
      /
      *---------------------
       1200-BUILD-DTL-LINES.
      *---------------------

      *
      * BUILD L7070 DETAIL INFORMATION
      *

           MOVE MIR-ACCT-BASE-ID-T (WS-SUB)
                                      TO L7070-ACCT (WS-SUB).
010418     MOVE MIR-SBSDRY-CO-ID-T (WS-SUB)
                                      TO L7070-SBSDRY-CO-ID (WS-SUB).
           MOVE MIR-PLAN-ID-T (WS-SUB)
                                      TO L7070-PLAN-ID (WS-SUB).
           MOVE MIR-BR-OR-DEPT-ID-T (WS-SUB)
                                      TO L7070-BRC-DEP (WS-SUB).
           MOVE MIR-ACCT-ISS-LOC-CD-T (WS-SUB)
                                      TO L7070-ISSUE-LOC (WS-SUB).
           MOVE MIR-ACCT-CRNT-LOC-CD-T (WS-SUB)
                                      TO L7070-CURR-LOC (WS-SUB).
010418*    MOVE MIR-LOB-T (WS-SUB)        TO L7070-LOB (WS-SUB).
           MOVE MIR-AGT-ID-T (WS-SUB) TO L7070-AGENT (WS-SUB).
016457*    MOVE MIR-DV-AGT-REASN-CD-T (WS-SUB)
016457     MOVE MIR-COMM-TRXN-REASN-CD-T (WS-SUB)
                                      TO L7070-REASON (WS-SUB).
016457*    MOVE MIR-DV-ACCT-DESC-TXT-T (WS-SUB)
016457     MOVE MIR-ACCT-DESC-TXT-T (WS-SUB)
                                      TO L7070-DTL-DESCR (WS-SUB).

      *
      * VALIDATE THE DEBIT AMOUNT ENTERED ON THE DETAIL LINE
      *

           SET L0280-SIGN-NOT-PERMITTED
                                      TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                         TO L0280-LENGTH.
008455*    MOVE +12                       TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-DV-TRNXT-DR-AMT-T (WS-SUB)
008455                                TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           MOVE MIR-DV-TRNXT-DR-AMT-T (WS-SUB)
                                      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
               MOVE ZEROS             TO L7070-DEBIT-N (WS-SUB)
               MOVE WS-SUB            TO WS-PIC-99
               MOVE WS-PIC-99         TO WGLOB-MSG-PARM (1)
      *MSG: DATA ON LINE @1 MUST BE NUMERIC
               MOVE 'CS01710013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO L7070-DEBIT-N (WS-SUB)
008455*        MOVE L0280-OUTPUT-DOLLAR   TO WS-AMT
008455*        MOVE WS-DISPLAY-AMT    TO MIR-DV-ACCT-TRXN-AMT-T (WS-SUB)
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-TRNXT-DR-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X 
008455         MOVE L0290-OUTPUT-DATA TO
008455                             MIR-DV-TRNXT-DR-AMT-T (WS-SUB)
           END-IF.

      *
      * VALIDATE THE CREDIT AMOUNT ENTERED ON THE DETAIL LINE
      *

           SET L0280-SIGN-NOT-PERMITTED
                                      TO TRUE.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 9                         TO L0280-LENGTH.
008455*    MOVE +12                       TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-DV-TRNXT-CR-AMT-T (WS-SUB)
008455                                TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.
           MOVE MIR-DV-TRNXT-CR-AMT-T (WS-SUB)
                                      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
               MOVE ZEROS             TO L7070-CREDIT-N (WS-SUB)
               MOVE WS-SUB            TO WS-PIC-99
               MOVE WS-PIC-99         TO WGLOB-MSG-PARM (1)
      *MSG: DATA ON LINE @1 MUST BE NUMERIC
               MOVE 'CS01710013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-DOLLAR
                                      TO L7070-CREDIT-N (WS-SUB)
008455*        MOVE L0280-OUTPUT-DOLLAR   TO WS-AMT
008455*        MOVE WS-DISPLAY-AMT    TO MIR-DV-ACCT-TRXN-AMT-T (WS-SUB)
               MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-DV-TRNXT-CR-AMT-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO
008455                            MIR-DV-TRNXT-CR-AMT-T (WS-SUB)
           END-IF.

      *
      * VALUE THE DESCRIPTION DETAILS
      *

           IF  L7070-DTL-DESCR (WS-SUB) = SPACES
           AND (L7070-DEBIT-N (WS-SUB) NOT = ZERO
           OR   L7070-CREDIT-N (WS-SUB) NOT = ZERO)
016457*        IF  MIR-DV-ACCT-DESC-TXT > SPACES
016457*            MOVE MIR-DV-ACCT-DESC-TXT
016457         IF  MIR-ACCT-DESC-TXT > SPACES
016457             MOVE MIR-ACCT-DESC-TXT
                                      TO L7070-DTL-DESCR (WS-SUB)
               END-IF
           END-IF.


       1200-BUILD-DTL-LINES-X.
           EXIT.
      /
      *----------------------------
       2000-EDIT-PRCES-TRANSACTION.
      *----------------------------

      *
      * CALL MODULE CSLF7070 TO DO FURTHER EDIT AND/OR PROCESS OF THE
      * TRANSACTION
      *

           IF  WS-BUS-FCN-CURACCT
               SET L7070-TRXN-ORIG-GACC
                                      TO TRUE
           ELSE
               SET L7070-TRXN-ORIG-ACPM
                                      TO TRUE
           END-IF.

           IF  MIR-DV-PRCES-STATE-CD NOT = '3'
               SET L7070-PRCES-TYP-EDIT-ONLY
                                      TO TRUE
           END-IF.

           MOVE WS-MAX-LINES          TO L7070-MAX-LINES.
           PERFORM  7070-1000-GNRL-ACCT
               THRU 7070-1000-GNRL-ACCT-X.

      *
      * UPON RETURN IF ERROR IS ENCOUNTERED, EXIT ROUTINE
      *

           IF  NOT L7070-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 2000-EDIT-PRCES-TRANSACTION-X
           END-IF.

030743     IF  L7070-EFF-DATE-OVERRIDE
030743*MSG: DATE OVERWRITTEN BY PROCESSING DATE FOR AGENT ACCOUNTING
030743         MOVE 'CS01710018'       TO WGLOB-MSG-REF-INFO
030743         PERFORM  0260-1000-GENERATE-MESSAGE
030743             THRU 0260-1000-GENERATE-MESSAGE-X
030743         MOVE WGLOB-PROCESS-DATE TO L1640-INTERNAL-DATE
030743         PERFORM  1640-8000-INTERNAL-TO-MIR
030743             THRU 1640-8000-INTERNAL-TO-MIR-X
030743         MOVE L1640-EXTERNAL-DATE  TO MIR-ACCT-TRXN-PRCES-DT
030743     END-IF.
      *
      * SET THE APPROPRIATE MESSAGES AND SCREEN ATTRIBUTES BASED ON THE
      * EDIT PASS OR VERIFY PASS
      *

           IF  MIR-DV-PRCES-STATE-CD NOT = '3'
      *MSG: PLEASE VERIFY TRANSACTION
               MOVE 'CS01710017'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557696         PERFORM  2100-MISC-WARN-MSG
557696             THRU 2100-MISC-WARN-MSG-X
557696             VARYING WS-SUB FROM +1 BY +1
557696             UNTIL WS-SUB > WS-MAX-LINES
           ELSE
      *MSG: ENTRY PROCESSED...CONTINUE
               MOVE 'CS01710005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2000-EDIT-PRCES-TRANSACTION-X.
           EXIT.

557696*-------------------
557696 2100-MISC-WARN-MSG.
557696*-------------------
557696
557696**************************************************************
557696*    IF THE COUNTRY AND CURRENCY FIELDS ARE 'US' THEN DISPLAY
557696*    THE INFORMATIONAL WARNING MESSAGE.
557696**************************************************************
557696
557696     MOVE MIR-ACCT-BASE-ID-T (WS-SUB)
                                      TO WS-ACCT.
557696
557696     IF  WS-ACCT-TYP-COMM
557696     OR  MIR-AGT-ID-T (WS-SUB) NOT = SPACES
557696         PERFORM  4180-1000-BUILD-PARM-INFO
557696            THRU  4180-1000-BUILD-PARM-INFO-X
557696         MOVE MIR-ACCT-BASE-ID-T (WS-SUB)
                                      TO L4180-ACCT-NUM
557696         MOVE MIR-AGT-ID-T (WS-SUB)
                                      TO L4180-AGT-NUM
557696         PERFORM  4180-1000-USTM-EDITS
557696            THRU  4180-1000-USTM-EDITS-X
557696     END-IF.
557696
557696 2100-MISC-WARN-MSG-X.
557696     EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  4180-0000-INIT-PARM-INFO
025970         THRU 4180-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7070-0000-INIT-PARM-INFO
025970         THRU 7070-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WS-WORK-AREA.
025970
025970     SET WS-MAX-LINES-DEFAULT      TO TRUE.
025970     SET ERROR-LINE-SCREEN-DEFAULT TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID           TO WS-BUS-FCN-ID.
025970
025970     MOVE WGLOB-PROCESS-DATE       TO DATX.
025970     MOVE WGLOB-PROCESS-DATE       TO UP-LIMIT-DATE.
025970     MOVE WGLOB-PROCESS-DATE       TO LO-LIMIT-DATE.
025970
025970     MOVE SPACES                   TO WWKDT-WORK-FIELDS.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
013578*COPY XCPS2510.
013578*
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
557696 COPY CCPS4180.
018764*COPY CCCL4180.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL4180.
      /
       COPY CCPS7070.
018764*COPY CCCL7070.
018764 COPY CCPL7070.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
008455 COPY XCPS0290.
008455 COPY XCPL0290.
008455/
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
013578*COPY XCCL2510.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0171                     **
      *****************************************************************



