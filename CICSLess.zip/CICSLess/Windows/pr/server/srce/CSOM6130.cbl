      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM6130.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM6130                                         **
      **  REMARKS:  ADDI - MAINTAIN CLIENT INCOME INFORMATION TABLE  **
      **                                                             **
      **            THIS MODULE PERFORMS TABLE MAINTENANCE FUNCTIONS **
      **            FOR THE CLIENT INCOME INFORMATION (CLII) TABLE.  **
      **            AN EXISTING CLIENT IS REQUIRED FOR ANY OPERATION **
      **            ON THE TABLE.                                    **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557667**  5.5       ORIGINAL FOR 5.5                                 **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
010383**  5.5.2     RESET FIELD ATTRIBUTES WHEN DUPLICATED REC       **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
013578**  6.0       REMOVE 3270 SUPPORT                              **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       FORMAT CLIENT FULL NAME                          **
014660**  6.0       REMOVE XCCPMEXT                                  **
014221**  6.2       LOGICAL LOCKING                                  **
016387**  6.2       REMOVE CLIENT CONSOLIDATION                      **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018763**  6.3       CODE CLEAN UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
018300**  6.4       INQUIRY DURING CLIENT CLEAR CASING               **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
027252**  6.6       MODIFICATION OF THE INCOME MODE CODE WHEN INCOME **
027252**  6.6       AMOUNT IS MORE THAN ZERO.                        **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM6130'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.
      /
      /
014590*COPY XCWL0030.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
016537*COPY XCWTATRB.
      /
       COPY XCWEBLCH.
      /
016537*COPY CCWWINDX.
      /
025970 01  WS-CONSTANTS.
025970     05  WS-MAX-BROWSE-LINES          PIC S9(4)  BINARY.
025970         88  WS-MAX-BROWSE-LINES-DEFAULT         VALUE +12.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT                 VALUE '1060'.

       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12  COMP.
025970*    05  WS-MAX-BROWSE-LINES        PIC S9(4)  VALUE +12 BINARY.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-RETRIEVE                 VALUE '1060'.
               88  WS-BUS-FCN-CREATE                   VALUE '1061'.
               88  WS-BUS-FCN-UPDATE                   VALUE '1062'.
               88  WS-BUS-FCN-DELETE                   VALUE '1063'.
               88  WS-BUS-FCN-LIST                     VALUE '1064'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '1060'.
           05  WS-TEST-MODE                 PIC X(01).
               88  WS-MODE-VALID                       VALUE
                   'A' 'M' ' '.
               88  WS-TEST-ANNUAL                      VALUE 'A'.
               88  WS-TEST-MONTHLY                     VALUE 'M'.
               88  WS-TEST-NA                          VALUE ' '.
008455*    05  WS-PIC-9-13                  PIC 9(13).
008455*    05  WS-PIC-Z-13                  PIC Z(12)9.
008455*    05  WS-PIC-9-15                  PIC 9(15).
008455*    05  WS-PIC-Z-15                  PIC Z(14)9.
           05  WS-CLII-KEY-DISPLAY.
               10  WS-CLII-KEY-CLI-NO       PIC X(10).
               10  FILLER                   PIC X(01)  VALUE SPACES.
013578         10  WS-CLII-KEY-EFF-DT       PIC X(10).
013578*        10  WS-CLII-KEY-EFF-DT       PIC X(09).
           05  WS-HOLD-CLSNM                PIC X(75)  VALUE SPACES.
      /
      *****************************************************************
      *  LINKAGE COPYBOOKS                                            *
      *****************************************************************

       COPY CCWL0620.
028298 COPY CCWL2626.
      /
       COPY CCWL2435.
      /
       COPY XCWL0280.
      /
008455 COPY XCWL0290.
      /
014221 COPY XCWL8090.
       COPY XCWWWKDT.
      /
       COPY XCWLDTLK.
      /
       COPY XCWL1640.
      /
013578*COPY XCWL5490.
      /
       COPY CCWL5600.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
014221 COPY CCFRCLI.
014221 COPY CCFWCLI.
014221/
       COPY CCFRCLII.
       COPY CCFWCLII.
      /
016537*COPY CCFREDIT.
016537*COPY CCFWEDIT.
      /
      *****************************************************************
      *  INPUT PARAMETER INFORMATION                                  *
      *****************************************************************
      /
014221 COPY CCWWLOCK.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM6130.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      /
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM ABND-1000-HANDLE-ABEND
026070*       THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM INIT-1000-INITIALIZE
              THRU INIT-1000-INITIALIZE-X.

           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM EXIT-1000-FINALIZE
              THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------

           MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
           SET MIR-RETRN-OK                TO TRUE.

008455     PERFORM 0290-1000-BUILD-PARM-INFO
008455        THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  8000-CHECK-KEY-FIELDS
               THRU 8000-CHECK-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
           OR  NOT WGLOB-GOOD-RETURN
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  5600-0000-INIT-PARM-INFO
               THRU 5600-0000-INIT-PARM-INFO-X.

           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID                  TO L5600-CLI-ID.
016387*
016387*    IF WS-BUS-FCN-RETRIEVE
016387*    OR WS-BUS-FCN-LIST
016387*        SET L5600-GEN-CNSLDT-MSG-WARN TO TRUE
016387*    END-IF.

018300     IF  WS-BUS-FCN-RETRIEVE
018300     OR  WS-BUS-FCN-LIST
018300         SET L5600-INQ-INFO-ONLY     TO TRUE
018300     END-IF.

           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X

           IF L5600-CCAS-ACCS-RESTRICTED
              IF  WS-BUS-FCN-RETRIEVE
              OR  WS-BUS-FCN-LIST
                  SET L5600-CCAS-ACCS-WARNING  TO TRUE
              END-IF
           END-IF.

           IF L5600-CNFD-ACCS-RESTRICTED
           OR L5600-CCAS-ACCS-RESTRICTED
016387*    OR L5600-CNSLDT-ACCS-RESTRICTED
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                   PERFORM  3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                   PERFORM  3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                   PERFORM  4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                   PERFORM  5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                   PERFORM  6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

           END-EVALUATE.


       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------

014221     MOVE MIR-CLI-ID             TO WCLI-CLI-ID
014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.
           
           MOVE MIR-CLI-ID             TO WCLII-CLI-ID
013578                                    WS-CLII-KEY-CLI-NO.
           MOVE MIR-CLI-INCM-EFF-DT    TO L1640-EXTERNAL-DATE
013578                                    WS-CLII-KEY-EFF-DT.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE    TO WCLII-CLI-INCM-EFF-DT.
           PERFORM  CLII-1000-READ
               THRU CLII-1000-READ-X.
           IF WCLII-IO-NOT-FOUND
      *MSG:    'NO INCOME INFORMATION FOUND (@1)'
               MOVE WS-CLII-KEY-DISPLAY    TO WGLOB-MSG-PARM (1)
               MOVE 'CS61300001'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
013578         SET MIR-RETRN-RQST-FAILED   TO TRUE
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           ELSE
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *-------------------
       3500-PROCESS-LIST.
      *-------------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           MOVE +1                         TO WS-SUB.

           PERFORM  3520-BROWSE-CLII
               THRU 3520-BROWSE-CLII-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      *-----------------
       3520-BROWSE-CLII.
      *-----------------

           MOVE LOW-VALUES                 TO WCLII-KEY.
           MOVE MIR-CLI-ID                 TO WCLII-CLI-ID
                                              WCLII-ENDBR-CLI-ID.

           IF MIR-CLI-INCM-EFF-DT = SPACES
               MOVE WWKDT-HIGH-DT          TO WCLII-CLI-INCM-EFF-DT
           ELSE
               MOVE MIR-CLI-INCM-EFF-DT    TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT                                    
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X                                 
020462         PERFORM 1640-7000-MIR-TO-INT                                         
020462            THRU 1640-7000-MIR-TO-INT-X                                      
               MOVE L1640-INTERNAL-DATE    TO WCLII-CLI-INCM-EFF-DT
           END-IF.
           MOVE WWKDT-LOW-DT
                   TO WCLII-ENDBR-CLI-INCM-EFF-DT.

           PERFORM  3530-BROWSE-CLII-LOOP
               THRU 3530-BROWSE-CLII-LOOP-X.

       3520-BROWSE-CLII-X.
           EXIT.

      *----------------------
       3530-BROWSE-CLII-LOOP.
      *----------------------

           PERFORM  CLII-1000-BROWSE-PREV
               THRU CLII-1000-BROWSE-PREV-X.

           IF WCLII-IO-EOF
      *MSG:    'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3530-BROWSE-CLII-LOOP-X
           END-IF.

           PERFORM  CLII-2000-READ-PREV
               THRU CLII-2000-READ-PREV-X.

           IF WCLII-IO-EOF
               PERFORM  CLII-3000-END-BROWSE-PREV
                   THRU CLII-3000-END-BROWSE-PREV-X
      *MSG:        'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3530-BROWSE-CLII-LOOP-X
           END-IF.

           PERFORM  3535-BROWSE-CLII-READ
               THRU 3535-BROWSE-CLII-READ-X
              UNTIL WS-SUB > WS-MAX-BROWSE-LINES
                 OR WCLII-IO-EOF.

           PERFORM  3540-BROWSE-CLII-FINISH
               THRU 3540-BROWSE-CLII-FINISH-X.

       3530-BROWSE-CLII-LOOP-X.
           EXIT.

      *----------------------
       3535-BROWSE-CLII-READ.
      *----------------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
           ADD 1                       TO WS-SUB.

           PERFORM  CLII-2000-READ-PREV
               THRU CLII-2000-READ-PREV-X.

       3535-BROWSE-CLII-READ-X.
           EXIT.

      *------------------------
       3540-BROWSE-CLII-FINISH.
      *------------------------

           IF WCLII-IO-EOF
      *MSG:    'END OF LIST'
               MOVE 'XS00000015'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
      *MSG:    '** TO VIEW MORE DATA PRESS ENTER **'
               MOVE 'XS00000014'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE RCLII-CLI-INCM-EFF-DT TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT                                    
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X                                 
020462         PERFORM 1640-8000-INTERNAL-TO-MIR                                    
020462            THRU 1640-8000-INTERNAL-TO-MIR-X                                 
               MOVE L1640-EXTERNAL-DATE TO MIR-CLI-INCM-EFF-DT
           END-IF.

           PERFORM  CLII-3000-END-BROWSE-PREV
               THRU CLII-3000-END-BROWSE-PREV-X.

       3540-BROWSE-CLII-FINISH-X.
           EXIT.
      /
      *-------------------
       4000-PROCESS-CREATE.
      *-------------------

           MOVE MIR-CLI-ID                 TO WCLII-CLI-ID.
           MOVE MIR-CLI-INCM-EFF-DT        TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT                                    
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.                                 
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE        TO WCLII-CLI-INCM-EFF-DT.

           PERFORM  CLII-1000-READ
               THRU CLII-1000-READ-X.
           IF WCLII-IO-OK
               MOVE WCLII-KEY              TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'           TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM 9200-MOVE-RECORD-TO-SCREEN
                  THRU 9200-MOVE-RECORD-TO-SCREEN-X

               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  CLII-1000-CREATE
               THRU CLII-1000-CREATE-X.
           PERFORM  CLII-1000-WRITE
               THRU CLII-1000-WRITE-X.

014221     MOVE MIR-CLI-ID                 TO WCLI-CLI-ID.
014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

      **MSG:  'RECORD CREATED - CONTINUE'
           MOVE 'XS00000004'               TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------
014221     MOVE MIR-CLI-ID                 TO WCLI-CLI-ID.
014221     PERFORM  CLI-2000-UPDATE-TWRK-TS
014221         THRU CLI-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABEL @1, KEY @2,
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'CLI'               TO WGLOB-MSG-PARM (01)
014221         MOVE WCLI-KEY            TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

014221     IF  NOT WCLI-IO-OK
014221*MSG: 'RECORD LOST IN MAINTAIN (@1) - CONTACT SYSTEMS'
014221         MOVE WCLI-KEY           TO WGLOB-MSG-PARM (1)
014221         MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           MOVE MIR-CLI-ID                 TO WCLII-CLI-ID
013578                                        WS-CLII-KEY-CLI-NO.
           MOVE MIR-CLI-INCM-EFF-DT        TO L1640-EXTERNAL-DATE
013578                                        WS-CLII-KEY-EFF-DT.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE        TO WCLII-CLI-INCM-EFF-DT.

           PERFORM  CLII-1000-READ-FOR-UPDATE
               THRU CLII-1000-READ-FOR-UPDATE-X.

           IF WCLII-IO-NOT-FOUND
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
      *MSG:    'LOST RECORD @1 IN MAINTAIN - CONTACT SYSTEMS'
               MOVE WS-CLII-KEY-DISPLAY    TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  CLI-3000-UNLOCK
014221             THRU CLI-3000-UNLOCK-X                  
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  5300-MAINTAIN-EDITS
               THRU 5300-MAINTAIN-EDITS-X.

           PERFORM  5400-CROSS-EDITS
               THRU 5400-CROSS-EDITS-X.

           PERFORM  CLII-2000-REWRITE
               THRU CLII-2000-REWRITE-X.
               
014221     PERFORM  CLI-2000-REWRITE
014221         THRU CLI-2000-REWRITE-X.
014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
      *MSG:    'RECORD UPDATED'
               MOVE 'XS00000008'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
           ELSE
      *MSG:    'MAINTENANCE COMPLETED - CONTINUE'
               MOVE 'XS00000007'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *--------------------
       5300-MAINTAIN-EDITS.
      *--------------------

           PERFORM 5310-EDIT-EARN-INCM
              THRU 5310-EDIT-EARN-INCM-X.

           PERFORM 5320-EDIT-EARN-INCM-MODE-CD
              THRU 5320-EDIT-EARN-INCM-MODE-CD-X.

           PERFORM 5330-EDIT-OTHR-INCM
              THRU 5330-EDIT-OTHR-INCM-X.

           PERFORM 5340-EDIT-OTHR-INCM-MODE-CD
              THRU 5340-EDIT-OTHR-INCM-MODE-CD-X.

           PERFORM 5350-EDIT-NET-WRTH-AMT
              THRU 5350-EDIT-NET-WRTH-AMT-X.

       5300-MAINTAIN-EDITS-X.
           EXIT.
      /
      *--------------------
       5310-EDIT-EARN-INCM.
      *--------------------

           IF MIR-CLI-EARN-INCM-AMT = SPACES
008455*        MOVE RCLII-CLI-EARN-INCM-AMT TO WS-PIC-9-13
008455*        MOVE WS-PIC-9-13            TO MIR-CLI-EARN-INCM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                     RCLII-CLI-EARN-INCM-AMT * 1
020874         MOVE RCLII-CLI-EARN-INCM-AMT TO L0290-INPUT-V00
008455         MOVE 0                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CLI-EARN-INCM-AMT
                                           TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA      TO MIR-CLI-EARN-INCM-AMT

               GO TO 5310-EDIT-EARN-INCM-X
           END-IF.

           IF MIR-CLI-EARN-INCM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE 0                      TO WS-PIC-9-13
008455*        MOVE WS-PIC-9-13            TO MIR-CLI-EARN-INCM-AMT
020874*        MOVE 0                      TO L0290-INPUT-NUMBER
020874         MOVE ZEROS                  TO L0290-INPUT-V00
008455         MOVE 0                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CLI-EARN-INCM-AMT
                                           TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA      TO MIR-CLI-EARN-INCM-AMT
           END-IF.

           MOVE 'N'                        TO L0280-SIGN-IND.
           MOVE 0                          TO L0280-PRECISION.
008455*    MOVE 13                         TO L0280-LENGTH.
008455*    MOVE 13                         TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CLI-EARN-INCM-AMT
                                           TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 0.
           MOVE MIR-CLI-EARN-INCM-AMT      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF NOT L0280-OK
      *MSG: 'EARNED INCOME MUST BE VALID NUMERIC'
               MOVE 'CS61300008'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5310-EDIT-EARN-INCM-X
           ELSE
               MOVE L0280-OUTPUT-V00       TO RCLII-CLI-EARN-INCM-AMT
008455*        MOVE L0280-OUTPUT-V00       TO WS-PIC-9-13
008455*        MOVE WS-PIC-9-13            TO MIR-CLI-EARN-INCM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                     L0280-OUTPUT-V00 * 1
020874         MOVE L0280-OUTPUT-V00       TO L0290-INPUT-V00
008455         MOVE 0                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CLI-EARN-INCM-AMT
                                           TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA      TO MIR-CLI-EARN-INCM-AMT
           END-IF.

       5310-EDIT-EARN-INCM-X.
           EXIT.

      *----------------------------
       5320-EDIT-EARN-INCM-MODE-CD.
      *----------------------------

           IF MIR-EARN-INCM-MODE-CD = SPACES
              IF RCLII-CLI-EARN-INCM-AMT > 0
                 MOVE 'A'                  TO MIR-EARN-INCM-MODE-CD
                 MOVE MIR-EARN-INCM-MODE-CD
                                           TO RCLII-EARN-INCM-MODE-CD
                 GO TO 5320-EDIT-EARN-INCM-MODE-CD-X
              ELSE
                 MOVE RCLII-EARN-INCM-MODE-CD
                                           TO MIR-EARN-INCM-MODE-CD
                 GO TO 5320-EDIT-EARN-INCM-MODE-CD-X
              END-IF
           END-IF.
      *
           IF MIR-EARN-INCM-MODE-CD = RCLII-EARN-INCM-MODE-CD
               GO TO 5320-EDIT-EARN-INCM-MODE-CD-X
           END-IF.
      *
           IF MIR-EARN-INCM-MODE-CD = EBLCH-BLANK-FIELD-CHAR
027252*        MOVE SPACES         TO MIR-EARN-INCM-MODE-CD
027252        IF RCLII-CLI-EARN-INCM-AMT > 0
027252           SET WS-TEST-ANNUAL           TO TRUE
027252           MOVE WS-TEST-MODE            TO MIR-EARN-INCM-MODE-CD
027252        ELSE
027252           SET WS-TEST-NA               TO TRUE
027252           MOVE WS-TEST-MODE            TO MIR-EARN-INCM-MODE-CD
027252        END-IF
           END-IF.
      *
           MOVE MIR-EARN-INCM-MODE-CD      TO WS-TEST-MODE.
      *
           IF WS-MODE-VALID
               MOVE MIR-EARN-INCM-MODE-CD  TO RCLII-EARN-INCM-MODE-CD
           ELSE
               MOVE 'CS61300002'   TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
       5320-EDIT-EARN-INCM-MODE-CD-X.
           EXIT.

      *--------------------
       5330-EDIT-OTHR-INCM.
      *--------------------

           IF MIR-CLI-OTHR-INCM-AMT = SPACES
008455*        MOVE RCLII-CLI-OTHR-INCM-AMT TO WS-PIC-9-13
008455*        MOVE WS-PIC-9-13             TO MIR-CLI-OTHR-INCM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*                          RCLII-CLI-OTHR-INCM-AMT * 1
020874         MOVE RCLII-CLI-OTHR-INCM-AMT TO L0290-INPUT-V00
008455         MOVE 0                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CLI-OTHR-INCM-AMT
                                           TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA      TO MIR-CLI-OTHR-INCM-AMT
               GO TO 5330-EDIT-OTHR-INCM-X
           END-IF.

           IF MIR-CLI-OTHR-INCM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE 0                      TO WS-PIC-9-13
008455*        MOVE WS-PIC-9-13            TO MIR-CLI-OTHR-INCM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = 0
020874         MOVE ZEROS                  TO L0290-INPUT-V00
008455         MOVE 0                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CLI-OTHR-INCM-AMT
                                           TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA      TO MIR-CLI-OTHR-INCM-AMT
           END-IF.

           MOVE 'N'                        TO L0280-SIGN-IND.
           MOVE 0                          TO L0280-PRECISION.
008455*    MOVE 13                         TO L0280-LENGTH.
008455*    MOVE 13                         TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CLI-OTHR-INCM-AMT
                                           TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 0.
           MOVE MIR-CLI-OTHR-INCM-AMT      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF NOT L0280-OK
      *MSG:     'OTHER INCOME MUST BE VALID NUMERIC'
               MOVE 'CS61300009'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5330-EDIT-OTHR-INCM-X
           ELSE
               MOVE L0280-OUTPUT-V00       TO RCLII-CLI-OTHR-INCM-AMT
008455*        MOVE L0280-OUTPUT-V00       TO WS-PIC-9-13
008455*        MOVE WS-PIC-9-13            TO MIR-CLI-OTHR-INCM-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = L0280-OUTPUT-V00 * 1
020874         MOVE L0280-OUTPUT-V00       TO L0290-INPUT-V00
008455         MOVE 0                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CLI-OTHR-INCM-AMT
                                           TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA      TO MIR-CLI-OTHR-INCM-AMT
           END-IF.
       5330-EDIT-OTHR-INCM-X.
           EXIT.
      /

      *----------------------------
       5340-EDIT-OTHR-INCM-MODE-CD.
      *----------------------------

           IF MIR-OTHR-INCM-MODE-CD = SPACES
              IF RCLII-CLI-OTHR-INCM-AMT > 0
                 MOVE 'A'                  TO MIR-OTHR-INCM-MODE-CD
                 MOVE MIR-OTHR-INCM-MODE-CD
                                           TO RCLII-OTHR-INCM-MODE-CD
                 GO TO 5340-EDIT-OTHR-INCM-MODE-CD-X
              ELSE
                 MOVE RCLII-OTHR-INCM-MODE-CD TO MIR-OTHR-INCM-MODE-CD
                 GO TO 5340-EDIT-OTHR-INCM-MODE-CD-X
              END-IF
           END-IF.
      *
           IF MIR-OTHR-INCM-MODE-CD = RCLII-OTHR-INCM-MODE-CD
               GO TO 5340-EDIT-OTHR-INCM-MODE-CD-X
           END-IF.
      *
           IF MIR-OTHR-INCM-MODE-CD = SPACES
               MOVE RCLII-OTHR-INCM-MODE-CD TO MIR-OTHR-INCM-MODE-CD
               GO TO 5340-EDIT-OTHR-INCM-MODE-CD-X
           END-IF.
      *
           IF MIR-OTHR-INCM-MODE-CD = EBLCH-BLANK-FIELD-CHAR
027252*        MOVE SPACES          TO MIR-OTHR-INCM-MODE-CD
027252        IF RCLII-CLI-OTHR-INCM-AMT > 0
027252           SET WS-TEST-ANNUAL           TO TRUE
027252           MOVE WS-TEST-MODE            TO MIR-OTHR-INCM-MODE-CD
027252        ELSE
027252           SET WS-TEST-NA               TO TRUE
027252           MOVE WS-TEST-MODE            TO MIR-OTHR-INCM-MODE-CD
027252        END-IF
           END-IF.
      *
           MOVE MIR-OTHR-INCM-MODE-CD      TO WS-TEST-MODE.
      *
           IF WS-MODE-VALID
               MOVE MIR-OTHR-INCM-MODE-CD  TO RCLII-OTHR-INCM-MODE-CD
           ELSE
               MOVE 'CS61300002'    TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
       5340-EDIT-OTHR-INCM-MODE-CD-X.
           EXIT.
      *
      *-----------------------
       5350-EDIT-NET-WRTH-AMT.
      *-----------------------

           IF MIR-CLI-NET-WRTH-AMT = SPACES
008455*        MOVE RCLII-CLI-NET-WRTH-AMT  TO WS-PIC-9-15
008455*        MOVE WS-PIC-9-15             TO MIR-CLI-NET-WRTH-AMT
020874*        COMPUTE L0290-INPUT-NUMBER =  RCLII-CLI-NET-WRTH-AMT
020874         MOVE RCLII-CLI-NET-WRTH-AMT TO L0290-INPUT-V00
008455         MOVE 0                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CLI-NET-WRTH-AMT
                                           TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA      TO MIR-CLI-NET-WRTH-AMT
               GO TO 5350-EDIT-NET-WRTH-AMT-X
           END-IF.

           IF MIR-CLI-NET-WRTH-AMT = EBLCH-BLANK-FIELD-CHAR
008455*        MOVE 0                      TO WS-PIC-9-15
008455*        MOVE WS-PIC-9-15            TO MIR-CLI-NET-WRTH-AMT
020874*        COMPUTE L0290-INPUT-NUMBER =  0
020874         MOVE ZEROS                  TO L0290-INPUT-V00
008455         MOVE 0                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CLI-NET-WRTH-AMT
                                           TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA      TO MIR-CLI-NET-WRTH-AMT
           END-IF.

           MOVE 'N'                        TO L0280-SIGN-IND.
           MOVE 0                          TO L0280-PRECISION.
008455*    MOVE 15                         TO L0280-LENGTH.
008455*    MOVE 15                         TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-CLI-NET-WRTH-AMT
                                           TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 0.
           MOVE MIR-CLI-NET-WRTH-AMT       TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF NOT L0280-OK
      *MSG:     'NET WORTH MUST BE VALID NUMERIC'
               MOVE 'CS61300003'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L0280-OUTPUT-V00       TO RCLII-CLI-NET-WRTH-AMT
008455*        MOVE L0280-OUTPUT-V00       TO WS-PIC-9-13
008455*        MOVE WS-PIC-9-13            TO MIR-CLI-NET-WRTH-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = L0280-OUTPUT-V00
020874         MOVE L0280-OUTPUT-V00       TO L0290-INPUT-V00
008455         MOVE 0                      TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CLI-NET-WRTH-AMT
                                           TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA      TO MIR-CLI-NET-WRTH-AMT
           END-IF.

       5350-EDIT-NET-WRTH-AMT-X.
           EXIT.
      /
      *-----------------
       5400-CROSS-EDITS.
      *-----------------

           IF  RCLII-EARN-INCM-MODE-CD NOT = SPACES
           AND RCLII-CLI-EARN-INCM-AMT = 0
      *MSG:   'EARNED INCOME MUST BE GREATER THAN ZERO'
               MOVE 'CS61300004'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  RCLII-OTHR-INCM-MODE-CD NOT = SPACES
           AND RCLII-CLI-OTHR-INCM-AMT = 0
      *MSG:   'OTHER INCOME MUST BE GREATER THAN ZERO'
               MOVE 'CS61300005'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5400-CROSS-EDITS-X.
           EXIT.
      /
      *--------------------
       6000-PROCESS-DELETE.
      *--------------------

014221     MOVE MIR-CLI-ID                 TO WCLI-CLI-ID
014221     PERFORM  CLI-2000-UPDATE-TWRK-TS
014221         THRU CLI-2000-UPDATE-TWRK-TS-X
014221     IF WCLI-IO-NOT-FOUND
014221* MSG: 'CLIENT NOT ON CLIENT FILE'
014221        MOVE 'XS00000058'            TO WGLOB-MSG-REF-INFO 
014221        MOVE WCLI-CLI-ID             TO WGLOB-MSG-PARM (1)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABEL @1, KEY @2,
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'CLI'               TO WGLOB-MSG-PARM (01)
014221         MOVE WCLI-KEY            TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.


           MOVE MIR-CLI-ID                 TO WCLII-CLI-ID
                                              WS-CLII-KEY-CLI-NO.
           MOVE MIR-CLI-INCM-EFF-DT        TO L1640-EXTERNAL-DATE
                                              WS-CLII-KEY-EFF-DT.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE        TO WCLII-CLI-INCM-EFF-DT.

           PERFORM  CLII-1000-READ-FOR-UPDATE
               THRU CLII-1000-READ-FOR-UPDATE-X.

           IF WCLII-IO-OK
               PERFORM  CLII-1000-DELETE
                   THRU CLII-1000-DELETE-X
      *MSG:  'DELETE COMPLETED - CONTINUE'
               MOVE 'XS00000011'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  CLI-2000-REWRITE
014221             THRU CLI-2000-REWRITE-X
014221         PERFORM  CLI-1000-READ-TWRK-TS
014221             THRU CLI-1000-READ-TWRK-TS-X  
           ELSE
      *MSG:  'RECORD @1 LOST IN DELETE - CONTACT SYSTEMS'
               MOVE WS-CLII-KEY-DISPLAY    TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  CLI-3000-UNLOCK
014221             THRU CLI-3000-UNLOCK-X
           END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *----------------------
       8000-CHECK-KEY-FIELDS.
      *----------------------
      *
      * CHECK FOR VALID CLIENT NO, AND VERIFY ACCESS IS ALLOWED
      * ----------------------------------------------------
      * IF INVALID CLIENT, WGLOB-MSG-ERROR-SW WILL BE SET > 0 BY
      * 0260-1000-GENERATE-MESSAGE. IF ACCESS IS NOT ALLOWED,
      * WGLOB-RETURN-CODE IS SET (WGLOB-MSG-ERROR-SW IS RESET TO ZERO
      * BY POLICY ACCESS VERIFICATION MODULE).
      *
           PERFORM  8100-EDIT-CLI-ID
               THRU 8100-EDIT-CLI-ID-X.

           PERFORM  8200-EDIT-EFF-DT
               THRU 8200-EDIT-EFF-DT-X.
      *
       8000-CHECK-KEY-FIELDS-X.
           EXIT.
      /
      *-----------------
       8100-EDIT-CLI-ID.
      *-----------------

           MOVE SPACE                      TO MIR-DV-INSRD-CLI-NM
                                              WS-HOLD-CLSNM.
           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID                  TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.

           IF L2435-RETRN-CLI-NOT-FOUND
      *MSG:   'CLIENT RECORD (@1) NOT FOUND'
               MOVE 'XS00000058'           TO WGLOB-MSG-REF-INFO
               MOVE L2435-CLI-ID           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8100-EDIT-CLI-ID-X
           END-IF.

           MOVE MIR-CLI-ID                 TO RCLII-CLI-ID.
           MOVE L2435-CLI-ENTR-GIV-NM      TO L0620-CLI-GIV-NM.
           MOVE L2435-CLI-ENTR-SUR-NM      TO L0620-CLI-SUR-NM.
014653     MOVE L2435-CLI-MID-INIT-NM      TO L0620-CLI-MID-INIT-NM.
014653     MOVE L2435-CLI-SFX-NM           TO L0620-CLI-SFX-NM.
           MOVE L2435-CLI-ENTR-CO-NM       TO L0620-CLI-CO-NM.
           MOVE L2435-CLI-SEX-CD           TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.

           MOVE L0620-SCREEN-NAME          TO MIR-DV-INSRD-CLI-NM
                                              WS-HOLD-CLSNM.
       8100-EDIT-CLI-ID-X.
           EXIT.
      /
      *-----------------
       8200-EDIT-EFF-DT.
      *-----------------

      *
      * BROWSE FROM SYSTEM DATE IF EFFECTIVE DATE IS BLANK
      *
           IF  WS-BUS-FCN-LIST AND
               MIR-CLI-INCM-EFF-DT = SPACES
               MOVE WGLOB-SYSTEM-DATE-INT  TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT                                    
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X                                 
020462         PERFORM 1640-8000-INTERNAL-TO-MIR                                    
020462            THRU 1640-8000-INTERNAL-TO-MIR-X 
               MOVE L1640-EXTERNAL-DATE    TO MIR-CLI-INCM-EFF-DT
               GO TO 8200-EDIT-EFF-DT-X
           END-IF
           MOVE MIR-CLI-INCM-EFF-DT        TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT                                    
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.                                 
020462     PERFORM  1640-7000-MIR-TO-INT
020462         THRU 1640-7000-MIR-TO-INT-X.
      *
           IF L1640-NOT-VALID
               MOVE MIR-CLI-INCM-EFF-DT    TO WGLOB-MSG-PARM (1)
               MOVE 'CS61300006'    TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8200-EDIT-EFF-DT-X
           END-IF.

      *    IF  NOT WS-ENTER-BROWSE AND
      *        L1640-INTERNAL-DATE > WGLOB-SYSTEM-DATE-INT
      * MSG : CANNOT CREATE INCOME INFORMATION IN THE FUTURE
      *        MOVE 'CS61300007'    TO WGLOB-MSG-REF-INFO
      *        PERFORM  0260-1000-GENERATE-MESSAGE
      *            THRU 0260-1000-GENERATE-MESSAGE-X
      *        GO TO 8200-EDIT-EFF-DT-X
      *    END-IF.

           IF  L1640-INTERNAL-DATE > WGLOB-SYSTEM-DATE-INT
      * MSG : INCOME INFORMATION CANNOT NOT IN FUTURE DATE
               MOVE 'CS61300010'    TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8200-EDIT-EFF-DT-X
           END-IF.

           MOVE L1640-INTERNAL-DATE TO RCLII-CLI-INCM-EFF-DT.

       8200-EDIT-EFF-DT-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                 TO MIR-CLI-INCM-EFF-DT-G.
           MOVE SPACES                 TO MIR-CLI-EARN-INCM-AMT-G.
           MOVE SPACES                 TO MIR-CLI-OTHR-INCM-AMT-G.
           MOVE SPACES                 TO MIR-EARN-INCM-MODE-CD-G.
           MOVE SPACES                 TO MIR-OTHR-INCM-MODE-CD-G.
           MOVE SPACES                 TO MIR-CLI-NET-WRTH-AMT-G.
           MOVE SPACES                 TO MIR-DV-INSRD-CLI-NM.
           MOVE SPACES                 TO MIR-CLI-EARN-INCM-AMT.
           MOVE SPACES                 TO MIR-CLI-OTHR-INCM-AMT.
           MOVE SPACES                 TO MIR-EARN-INCM-MODE-CD.
           MOVE SPACES                 TO MIR-OTHR-INCM-MODE-CD.
           MOVE SPACES                 TO MIR-CLI-NET-WRTH-AMT.
           MOVE WS-HOLD-CLSNM          TO MIR-DV-INSRD-CLI-NM.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST

                   MOVE RCLII-CLI-INCM-EFF-DT
                              TO L1640-INTERNAL-DATE
020462*            PERFORM 1640-2000-INTERNAL-TO-EXT                                    
020462*               THRU 1640-2000-INTERNAL-TO-EXT-X                                 
020462             PERFORM 1640-8000-INTERNAL-TO-MIR                                    
020462                THRU 1640-8000-INTERNAL-TO-MIR-X 
                   MOVE L1640-EXTERNAL-DATE
                              TO MIR-CLI-INCM-EFF-DT-T (WS-SUB)
008455*            MOVE RCLII-CLI-EARN-INCM-AMT TO WS-PIC-Z-13
008455*            MOVE WS-PIC-Z-13 TO MIR-CLI-EARN-INCM-AMT-T (WS-SUB)
020874*            COMPUTE L0290-INPUT-NUMBER =
020874*                               RCLII-CLI-EARN-INCM-AMT
020874             MOVE RCLII-CLI-EARN-INCM-AMT TO L0290-INPUT-V00
008455             MOVE 0                      TO L0290-PRECISION
020874*            SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE
008455             MOVE LENGTH OF MIR-CLI-EARN-INCM-AMT-T (WS-SUB)
008455                                         TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                              TO MIR-CLI-EARN-INCM-AMT-T (WS-SUB)

008455*            MOVE RCLII-CLI-OTHR-INCM-AMT TO WS-PIC-Z-13
008455*            MOVE WS-PIC-Z-13 TO MIR-CLI-OTHR-INCM-AMT-T (WS-SUB)
020874*            COMPUTE L0290-INPUT-NUMBER =
020874*                               RCLII-CLI-OTHR-INCM-AMT
020874             MOVE RCLII-CLI-OTHR-INCM-AMT TO L0290-INPUT-V00
008455             MOVE 0                      TO L0290-PRECISION
020874*            SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE
008455             MOVE LENGTH OF MIR-CLI-OTHR-INCM-AMT-T (WS-SUB)
008455                                        TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                            TO MIR-CLI-OTHR-INCM-AMT-T (WS-SUB)

                   MOVE RCLII-EARN-INCM-MODE-CD
                              TO MIR-EARN-INCM-MODE-CD-T (WS-SUB)
                   MOVE RCLII-OTHR-INCM-MODE-CD
                              TO MIR-OTHR-INCM-MODE-CD-T (WS-SUB)
008455*            MOVE RCLII-CLI-NET-WRTH-AMT  TO WS-PIC-Z-15
008455*            MOVE WS-PIC-Z-15  TO MIR-CLI-NET-WRTH-AMT-T (WS-SUB)
020874*            COMPUTE L0290-INPUT-NUMBER = RCLII-CLI-NET-WRTH-AMT
020874             MOVE RCLII-CLI-NET-WRTH-AMT TO L0290-INPUT-V00
008455             MOVE 0                      TO L0290-PRECISION
020874*            SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE
008455             MOVE LENGTH OF MIR-CLI-NET-WRTH-AMT-T (WS-SUB)
008455                                         TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                  TO MIR-CLI-NET-WRTH-AMT-T (WS-SUB)

               WHEN WS-BUS-FCN-UPDATE
                 OR WS-BUS-FCN-CREATE
                 OR WS-BUS-FCN-RETRIEVE
                 OR WS-BUS-FCN-DELETE

008455*            MOVE RCLII-CLI-EARN-INCM-AMT TO WS-PIC-9-13
008455*            MOVE WS-PIC-9-13             TO MIR-CLI-EARN-INCM-AMT
020874*            COMPUTE L0290-INPUT-NUMBER =
020874*                                RCLII-CLI-EARN-INCM-AMT
020874             MOVE RCLII-CLI-EARN-INCM-AMT TO L0290-INPUT-V00
008455             MOVE 0                      TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CLI-EARN-INCM-AMT
                              TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA      TO MIR-CLI-EARN-INCM-AMT

008455*            MOVE RCLII-CLI-OTHR-INCM-AMT TO WS-PIC-9-13
008455*            MOVE WS-PIC-9-13             TO MIR-CLI-OTHR-INCM-AMT
020874*            COMPUTE L0290-INPUT-NUMBER =
020874*                                RCLII-CLI-OTHR-INCM-AMT
020874             MOVE RCLII-CLI-OTHR-INCM-AMT TO L0290-INPUT-V00
008455             MOVE 0                      TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CLI-OTHR-INCM-AMT
                              TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA      TO MIR-CLI-OTHR-INCM-AMT

                   MOVE RCLII-EARN-INCM-MODE-CD
                              TO MIR-EARN-INCM-MODE-CD
                   MOVE RCLII-OTHR-INCM-MODE-CD
                              TO MIR-OTHR-INCM-MODE-CD
008455*            MOVE RCLII-CLI-NET-WRTH-AMT  TO WS-PIC-9-15
008455*            MOVE WS-PIC-9-15             TO MIR-CLI-NET-WRTH-AMT
020874*            COMPUTE L0290-INPUT-NUMBER =
020874*                                 RCLII-CLI-NET-WRTH-AMT
020874             MOVE RCLII-CLI-NET-WRTH-AMT TO L0290-INPUT-V00
008455             MOVE 0                      TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CLI-NET-WRTH-AMT
                              TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA      TO MIR-CLI-NET-WRTH-AMT

           END-EVALUATE.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                    TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE        TO WGLOB-REF-COMPANY-CODE.
           MOVE 'C'                       TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-CLI-ID                TO WGLOB-REF-CLIENT-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     MOVE SPACES                      TO WWKDT-WORK-FIELDS.
025970     SET WS-MAX-BROWSE-LINES-DEFAULT  TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT          TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
025970 COPY XCPS8090.
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0620.
      /
       COPY CCPS2435.
      /
018764*COPY CCCL2435.
018764 COPY CCPL2435.
      /
       COPY CCPS5600.
      /
018764*COPY CCCL5600.
018764 COPY CCPL5600.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CLI
014221                         '$VAR2' BY 'CLI'.
      /
013578*COPY XCCL5490.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
008455 COPY XCPL0290.
008455 COPY XCPS0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
014660*COPY XCPPMEXT.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
014221 COPY CCPNCLI.
014221 COPY CCPUCLI.
       COPY CCPACLII.
016537*COPY CCPBCLII.
       COPY CCPCCLII.
       COPY CCPNCLII.
       COPY CCPUCLII.
       COPY CCPVCLII.
       COPY CCPXCLII.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
018763*COPY XCCPHNDL.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM6130                     **
      *****************************************************************


