      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0234.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0234                                         **
      **  REMARKS:  THIS MODULE LISTS ALL PROCESSED CHEQUES          **
      **            FROM CHTX TABLE                                  **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      **  6.2       NEW                                              **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0234'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

021930*COPY CCWWINDX.
       COPY XCWEBLCH.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                           PIC X(04).
               88  WS-BUS-FCN-LIST                     VALUE '0234'.
           05  WS-SUB                                  PIC S9(4) BINARY.
025970*    05  WS-MAX-LIST-LINES                       PIC S9(4) BINARY
025970*                                                VALUE +100.
            05  WS-SBSDRY-CO-ID                        PIC X(02).
            05  WS-CHQ-DT                              PIC X(10).
            05  WS-FOUND-SW                            PIC X(01).
                88  WS-FOUND-START                     VALUE 'S'.
                88  WS-FOUND                           VALUE 'F'.
                
025970 01  WS-CONSTANT-FIELDS.
025970     05  WS-MAX-LIST-LINES                       PIC S9(4) BINARY.
               88  WS-MAX-LIST-LINES-DEFAULT           VALUE +100.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWCHTD.
       COPY CCFRCHTX.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
018764*COPY XCWLPTR.
       COPY XCWL0290.
       COPY XCWL1640.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM0234.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0234'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  2100-EDIT-INPUT
               THRU 2100-EDIT-INPUT-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  CHTD-1000-BROWSE
               THRU CHTD-1000-BROWSE-X.

           PERFORM  2010-GET-NEXT-CHTD
               THRU 2010-GET-NEXT-CHTD-X.

           IF  WCHTD-IO-EOF
               PERFORM  CHTD-3000-END-BROWSE
                   THRU CHTD-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND'
               MOVE 'CS02340003'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  2300-SET-UP-NEXT-MIR-KEY
               THRU 2300-SET-UP-NEXT-MIR-KEY-X.

           MOVE ZERO                       TO WS-SUB.
           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2200-BROWSE-CHTD
               THRU 2200-BROWSE-CHTD-X
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WCHTD-IO-EOF.

           IF  WCHTD-IO-EOF
      *MSG: 'END OF LIST'
               MOVE 'XS00000015'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS     TO TRUE
               PERFORM  2300-SET-UP-NEXT-MIR-KEY
                   THRU 2300-SET-UP-NEXT-MIR-KEY-X
           END-IF.

           PERFORM  CHTD-3000-END-BROWSE
               THRU CHTD-3000-END-BROWSE-X.


       2000-LIST-X.
           EXIT.

      *---------------------------
       2010-GET-NEXT-CHTD.
      *---------------------------

           SET WS-FOUND-START               TO TRUE.

           PERFORM
               UNTIL WCHTD-IO-EOF
               OR WS-FOUND

               PERFORM  CHTD-2000-READ-NEXT
                   THRU CHTD-2000-READ-NEXT-X

               IF  WCHTD-IO-OK
               AND (RCHTX-CHQ-STAT-CNCL
                OR  RCHTX-CHQ-STAT-OS
                OR  RCHTX-CHQ-STAT-PD
                OR  RCHTX-CHQ-STAT-NO-DATA)
                   SET WS-FOUND             TO TRUE
               END-IF

           END-PERFORM.


       2010-GET-NEXT-CHTD-X.
           EXIT.

      *----------------
       2100-EDIT-INPUT.
      *----------------

           PERFORM  2110-EDIT-CHQ-DT
               THRU 2110-EDIT-CHQ-DT-X.

           PERFORM  2120-EDIT-SBSDRY-CO-ID
               THRU 2120-EDIT-SBSDRY-CO-ID-X.

       2100-EDIT-INPUT-X.
           EXIT.


      *-------------------
       2110-EDIT-CHQ-DT.
      *-------------------

           IF  MIR-CHQ-DT = EBLCH-BLANK-FIELD-CHAR
           OR  MIR-CHQ-DT = SPACE
               MOVE WWKDT-LOW-DT          TO WS-CHQ-DT
               GO TO 2110-EDIT-CHQ-DT-X
           END-IF.

           MOVE MIR-CHQ-DT                TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               MOVE WWKDT-LOW-DT          TO WS-CHQ-DT
      *MSG: INVALID DATE
               MOVE 'CS02340001'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L1640-INTERNAL-DATE   TO WS-CHQ-DT
           END-IF.

       2110-EDIT-CHQ-DT-X.
           EXIT.

      *------------------------
       2120-EDIT-SBSDRY-CO-ID.
      *------------------------

           IF  MIR-SBSDRY-CO-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACE                 TO WS-SBSDRY-CO-ID
           ELSE
               MOVE MIR-SBSDRY-CO-ID      TO WS-SBSDRY-CO-ID
           END-IF.

       2120-EDIT-SBSDRY-CO-ID-X.
           EXIT.

      *-----------------
       2200-BROWSE-CHTD.
      *-----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  2010-GET-NEXT-CHTD
               THRU 2010-GET-NEXT-CHTD-X.

       2200-BROWSE-CHTD-X.
           EXIT.
      /

      *-------------------------
       2300-SET-UP-NEXT-MIR-KEY.
      *-------------------------

           MOVE RCHTX-CHQ-ID              TO MIR-CHQ-ID.
           MOVE RCHTX-SBSDRY-CO-ID        TO MIR-SBSDRY-CO-ID.

           MOVE RCHTX-CHQ-DT              TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE                 TO MIR-CHQ-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE   TO MIR-CHQ-DT
           END-IF.


       2300-SET-UP-NEXT-MIR-KEY-X.
           EXIT.

      *----------------
       7000-BUILD-KEYS.
      *----------------


           MOVE LOW-VALUES               TO WCHTD-KEY.
           MOVE MIR-CHQ-ID               TO WCHTD-CHQ-ID.
           MOVE WS-SBSDRY-CO-ID          TO WCHTD-SBSDRY-CO-ID.
           MOVE WS-CHQ-DT                TO WCHTD-CHQ-DT.

           MOVE HIGH-VALUES              TO WCHTD-ENDBR-KEY.
           MOVE WWKDT-HIGH-DT            TO WCHTD-ENDBR-CHQ-DT.


       7000-BUILD-KEYS-X.
           EXIT.

      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           IF  RCHTX-CHQ-STAT-CNCL
           OR  RCHTX-CHQ-STAT-OS
           OR  RCHTX-CHQ-STAT-PD
           OR  RCHTX-CHQ-STAT-NO-DATA
               CONTINUE
           ELSE
               GO TO 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           ADD +1                        TO WS-SUB.

           IF  WS-SUB > WS-MAX-LIST-LINES
               GO TO 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           MOVE RCHTX-CHQ-ID
           TO MIR-CHQ-ID-T (WS-SUB).

           MOVE RCHTX-SBSDRY-CO-ID
           TO MIR-SBSDRY-CO-ID-T (WS-SUB).

           MOVE RCHTX-CHQ-DT             TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           IF  L1640-NOT-VALID
               MOVE SPACE                TO MIR-CHQ-DT-T (WS-SUB)
           ELSE
               MOVE L1640-EXTERNAL-DATE  TO MIR-CHQ-DT-T (WS-SUB)
           END-IF.

           MOVE RCHTX-CHQ-MICR-NUM
           TO MIR-CHQ-MICR-NUM-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RCHTX-CHQ-AMT * 100.
020874     MOVE RCHTX-CHQ-AMT            TO L0290-INPUT-V02.
           MOVE +2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CHQ-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-LEAD-ZEROS-DISPLAY  TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
           TO MIR-CHQ-AMT-T (WS-SUB).

           MOVE RCHTX-CHQ-PAYE-1-TXT
           TO MIR-CHQ-PAYE-1-TXT-T (WS-SUB).

           MOVE RCHTX-CHQ-STAT-CD
           TO MIR-CHQ-STAT-CD-T (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  WS-WORKING-STORAGE.
025970
025970     MOVE SPACES TO  WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
025970     SET  WS-MAX-LIST-LINES-DEFAULT  TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.

025970 COPY XCPS1640.
       COPY XCPL1640.

       COPY XCPS0290.
       COPY XCPL0290.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBCHTD.
021930*COPY CCPNCHTD.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0234
      *****************************************************************
