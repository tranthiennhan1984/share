      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4903.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4903                                         **
      **  REMARKS:  THIS MODULE PROVIDES A LIST OF ALL POLICY AND    **
      **            COVERAGE AGENTS OF A POLICY                      **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      **  6.0       ORIGINAL - NEW FOR RELEASE 6.0                   **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
016051**  6.1       CHANGES FOR APPLICATION FLOW                     **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
015703**  6.4       REMOVE CCWLPGA                                   **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
024152**  6.5       PREVENT LOOPING IN CODESERVER                    **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
028789**  6.7       EXTERNAL AGENCY INTEGRATION - REAL TIME INFO.    **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4903'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

014590*COPY XCWL0030.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUSINESS-FUNCTION                PIC X(04).
               88  WS-BUSINESS-FUNCTION-LIST       VALUE '4903'.
016548*    05  WS-SUB                              PIC S9(04) COMP SYNC.
016548     05  WS-SUB                              PIC S9(04)
016548                                             BINARY SYNC.
016548*    05  WS-DUP-SUB                          PIC S9(04) COMP SYNC.
016548     05  WS-DUP-SUB                          PIC S9(04)
016548                                             BINARY SYNC.
025970*    05  WS-MAX-LIST-LINES                   PIC 9(02) VALUE 50.
025970     05  WS-MAX-LIST-LINES                   PIC 9(02).
016051     05  WS-AGT-ID                           PIC X(06).
           05  WS-DUPLICATE-AGT-ID-SW              PIC X(01).
               88  WS-AGT-ID-FOUND                 VALUE 'Y'.
               88  WS-AGT-ID-NOT-FOUND             VALUE 'N'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
016537*COPY CCWWFRMT.
016537*COPY XCWEBLCH.
016537*COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
016051 COPY CCFWPOL.
016051 COPY CCFRPOL.
      /
       COPY CCFWCVGA.
       COPY CCFRCVGA.
      /
016051 COPY CCFWPOLW.
016051 COPY CCFRPOLW.
      /
015703*COPY CCWLPGA.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
       COPY CCWL0083.
028789*COPY CCWL0620.
028298 COPY CCWL2626.
      /
028789*COPY NCWL2437.
028789*
016537*COPY XCWLDTLK.
018764*COPY XCWLPTR.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM4903.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUSINESS-FUNCTION.

           EVALUATE TRUE

               WHEN WS-BUSINESS-FUNCTION-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID           TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM4903'               TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

016051     MOVE +0                         TO  WS-SUB.

016051     PERFORM  2050-GET-POL-AGT
016051         THRU 2050-GET-POL-AGT-X.

016051     IF WS-SUB < WS-MAX-LIST-LINES
016051        CONTINUE
016051     ELSE
016051        SET WGLOB-MORE-DATA-EXISTS   TO  TRUE
016051        SET MIR-RETRN-OK             TO  TRUE
016051        GO TO 2000-LIST-X
016051     END-IF.

016051*    PERFORM  7000-BUILD-KEYS
016051*        THRU 7000-BUILD-KEYS-X.

016051     PERFORM  7000-BUILD-CVGA-KEYS
016051         THRU 7000-BUILD-CVGA-KEYS-X.

           PERFORM  CVGA-1000-BROWSE
               THRU CVGA-1000-BROWSE-X.

024152*    IF  NOT WCVGA-IO-OK
016051*MSG: NO RECORDS FOUND TO DISPLAY
016051*        MOVE 'XS00000034'            TO WGLOB-MSG-REF-INFO
016051*        PERFORM  0260-1000-GENERATE-MESSAGE
016051*            THRU 0260-1000-GENERATE-MESSAGE-X
016051*        SET MIR-RETRN-RQST-FAILED TO TRUE
024152*        GO TO 2000-LIST-X
024152*    END-IF.
024152*
           PERFORM  CVGA-2000-READ-NEXT
               THRU CVGA-2000-READ-NEXT-X.

           IF  WCVGA-IO-EOF
               PERFORM  CVGA-3000-END-BROWSE
                   THRU CVGA-3000-END-BROWSE-X
016051*MSG: NO RECORDS FOUND TO DISPLAY
016051*        MOVE 'XS00000034'            TO WGLOB-MSG-REF-INFO
016051*        PERFORM  0260-1000-GENERATE-MESSAGE
016051*            THRU 0260-1000-GENERATE-MESSAGE-X
016051*        SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-LIST-X
           END-IF.

016051*    PERFORM  2010-BROWSE-CVGA
016051*        THRU 2010-BROWSE-CVGA-X
016051     PERFORM  2100-BROWSE-CVGA
016051         THRU 2100-BROWSE-CVGA-X
016051*     VARYING WS-SUB FROM 1 BY 1
016051*       UNTIL WS-SUB > WS-MAX-LIST-LINES
016051        UNTIL WS-SUB = WS-MAX-LIST-LINES
016051           OR NOT WCVGA-IO-OK
                 OR WCVGA-IO-EOF.

           IF  WCVGA-IO-EOF
               CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
024152         MOVE RCVGA-CVG-NUM          TO MIR-CVG-NUM
024152         MOVE RCVGA-AGT-ID           TO MIR-AGT-ID
           END-IF.

           PERFORM  CVGA-3000-END-BROWSE
               THRU CVGA-3000-END-BROWSE-X.

           SET MIR-RETRN-OK                TO TRUE.

       2000-LIST-X.
           EXIT.
      /
016051*-----------------
016051 2050-GET-POL-AGT.
016051*-----------------

024152     IF  MIR-CVG-NUM NOT = SPACE
024152         GO TO 2050-GET-POL-AGT-X
024152     END-IF.
024152
016051     MOVE MIR-POL-ID                 TO  WPOL-POL-ID.

016051     PERFORM  POL-1000-READ
016051         THRU POL-1000-READ-X.

016051     MOVE RPOL-SERV-AGT-ID           TO  WS-AGT-ID.

016051     PERFORM  9200-MOVE-RECORD-TO-SCREEN
016051         THRU 9200-MOVE-RECORD-TO-SCREEN-X.

016051     PERFORM  7200-BUILD-POLW-KEYS
016051         THRU 7200-BUILD-POLW-KEYS-X.

016051     PERFORM  POLW-1000-BROWSE
016051         THRU POLW-1000-BROWSE-X.

016051     IF WPOLW-IO-OK
016051        PERFORM  POLW-2000-READ-NEXT
016051            THRU POLW-2000-READ-NEXT-X
016051        IF  WPOLW-IO-OK
016051            PERFORM  2055-BROWSE-POLW
016051                THRU 2055-BROWSE-POLW-X
016051                UNTIL  WS-SUB = WS-MAX-LIST-LINES
016051                OR  WPOLW-IO-EOF
016051                OR  NOT WPOLW-IO-OK
016051            PERFORM  POLW-3000-END-BROWSE
016051                THRU POLW-3000-END-BROWSE-X
016051        END-IF
016051     END-IF.

016051 2050-GET-POL-AGT-X.
016051     EXIT.
      /
016051*-----------------
016051 2055-BROWSE-POLW.
016051*----------------

016051     MOVE RPOLW-AGT-ID              TO  WS-AGT-ID.

016051     PERFORM  9200-MOVE-RECORD-TO-SCREEN
016051         THRU 9200-MOVE-RECORD-TO-SCREEN-X.

016051     PERFORM  POLW-2000-READ-NEXT
016051         THRU POLW-2000-READ-NEXT-X.

016051 2055-BROWSE-POLW-X.
016051     EXIT.
      /
      *-----------------
016051*2010-BROWSE-CVGA.
016051 2100-BROWSE-CVGA.
      *-----------------

016051     MOVE RCVGA-AGT-ID         TO  WS-AGT-ID.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  CVGA-2000-READ-NEXT
               THRU CVGA-2000-READ-NEXT-X.

016051*2010-BROWSE-CVGA-X.
016051 2100-BROWSE-CVGA-X.
           EXIT.
      /
      *----------------
016051*7000-BUILD-KEYS.
016051 7000-BUILD-CVGA-KEYS.
      *----------------
      *
      *  BUILD THE RECORD KEY FROM THE MIR FIELDS
      *
           MOVE LOW-VALUES          TO WCVGA-KEY.
           MOVE MIR-POL-ID          TO WCVGA-POL-ID.

024152     IF  MIR-CVG-NUM NOT = SPACE
024152         MOVE MIR-CVG-NUM     TO WCVGA-CVG-NUM
024152         MOVE MIR-AGT-ID      TO WCVGA-AGT-ID
024152     END-IF.
024152
           MOVE WCVGA-KEY           TO WCVGA-ENDBR-KEY.
           MOVE HIGH-VALUES         TO WCVGA-ENDBR-CVG-NUM.
           MOVE HIGH-VALUES         TO WCVGA-ENDBR-AGT-ID.

016051*7000-BUILD-KEYS-X.
016051 7000-BUILD-CVGA-KEYS-X.
           EXIT.
      /
016051*-------------------
016051 7200-BUILD-POLW-KEYS.
016051*--------------------

016051      MOVE LOW-VALUES          TO  WPOLW-KEY.
016051      MOVE HIGH-VALUES         TO  WPOLW-ENDBR-KEY.

016051      MOVE RPOL-POL-ID         TO  WPOLW-POL-ID.
016051      MOVE RPOL-POL-ID         TO  WPOLW-ENDBR-POL-ID.

016051 7200-BUILD-POLW-KEYS-X.
016051     EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES              TO MIR-DV-SBOX-CD-G.
           MOVE SPACES              TO MIR-DV-SBOX-DESC-TXT-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

016051     ADD +1                   TO  WS-SUB.
      *
      * CHECK WHETHER THE AGENT ID IS ALREADY LISTED OR NOT
      *
           IF  WS-SUB > 1
               SET WS-AGT-ID-NOT-FOUND  TO TRUE
               PERFORM  9210-CHECK-DUPLICATE-AGT-ID
                   THRU 9210-CHECK-DUPLICATE-AGT-ID-X
                VARYING WS-DUP-SUB FROM 1 BY 1
                  UNTIL WS-DUP-SUB = WS-SUB
                     OR WS-AGT-ID-FOUND
               IF  WS-AGT-ID-FOUND
                   COMPUTE WS-SUB  = WS-SUB - 1
                   GO TO 9200-MOVE-RECORD-TO-SCREEN-X
               END-IF
           END-IF.

016051*    MOVE RCVGA-AGT-ID        TO MIR-DV-SBOX-CD-T (WS-SUB).
016051     MOVE WS-AGT-ID           TO MIR-DV-SBOX-CD-T (WS-SUB).
      *
      * GET AND FORMAT THE AGENT NAME
      *
           PERFORM  0083-0000-INIT-PARM-INFO
               THRU 0083-0000-INIT-PARM-INFO-X.

016051*    MOVE RCVGA-AGT-ID        TO L0083-AGENT-ID.
028789*    MOVE WS-AGT-ID           TO L0083-AGENT-ID.
028789     MOVE WS-AGT-ID           TO L0083-AGT-ID (1).

           PERFORM  0083-1000-RETRIEVE-AGT-INFO
               THRU 0083-1000-RETRIEVE-AGT-INFO-X.

           IF  NOT L0083-RETRN-OK
028789     OR  L0083-AGT-NOTFND (1)
               MOVE SPACES          TO MIR-DV-SBOX-DESC-TXT-T (WS-SUB)
               GO TO 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

028789* AGENT NAME IS ALREADY FORMATTED
028789
028789     MOVE L0083-AGT-RES-NM-COMPRESSED (1)
028789                              TO MIR-DV-SBOX-DESC-TXT-T (WS-SUB).
028789*    MOVE L0083-AGT-CLI-ID    TO L2437-CLI-ID.
028789*
028789*    PERFORM  2437-1000-OBTAIN-CLI-INFO
028789*        THRU 2437-1000-OBTAIN-CLI-INFO-X.
028789*
028789*    IF  L2437-RETRN-OK
028789*        MOVE L2437-CLI-SEX-CD      TO L0620-CLI-SEX-CD
028789*        MOVE L2437-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
028789*        MOVE L2437-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
028789*        MOVE L2437-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
028789*        MOVE L2437-CLI-SFX-NM      TO L0620-CLI-SFX-NM
028789*        MOVE L2437-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
028789*        PERFORM  0620-1000-FORMAT-SCREEN-NAME
028789*            THRU 0620-1000-FORMAT-SCREEN-NAME-X
028789*        MOVE L0620-SCREEN-NAME     TO MIR-DV-SBOX-DESC-TXT-T
028789*                                      (WS-SUB)
028789*    ELSE
028789*        MOVE SPACES                TO MIR-DV-SBOX-DESC-TXT-T
028789*                                      (WS-SUB)
028789*    END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *----------------------------
       9210-CHECK-DUPLICATE-AGT-ID.
      *----------------------------

016051*    IF  RCVGA-AGT-ID = MIR-DV-SBOX-CD-T (WS-DUP-SUB)
016051     IF  WS-AGT-ID    = MIR-DV-SBOX-CD-T (WS-DUP-SUB)
               SET WS-AGT-ID-FOUND        TO TRUE
           END-IF.

       9210-CHECK-DUPLICATE-AGT-ID-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.
      *
      * FOR POLICY RELATED TRANSACTION
      *
           SET  WGLOB-REF-POLICY          TO TRUE.

           MOVE MIR-POL-ID                TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970     PERFORM  0083-0000-INIT-PARM-INFO
025970         THRU 0083-0000-INIT-PARM-INFO-X.
025970
028789*    PERFORM  0620-0000-INIT-PARM-INFO
028789*        THRU 0620-0000-INIT-PARM-INFO-X.
028789*
028789*    PERFORM  2437-0000-INIT-PARM-INFO
028789*        THRU 2437-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     INITIALIZE WS-WORKING-STORAGE.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUSINESS-FUNCTION.
023514     COMPUTE WS-MAX-LIST-LINES = LENGTH OF MIR-DV-SBOX-CD-G
023514                               / LENGTH OF MIR-DV-SBOX-CD-T (1).
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
      /
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
      /
       COPY CCPS0083.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
      /
018764*COPY CCCL0083.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL0083.
      /
028789*COPY CCPS0620.
028789*COPY CCPL0620.
028789*
018764*COPY NCCL2437.
028789*COPY NCPS2437.
028789*COPY NCPL2437.
028789*
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
      /
016051 COPY CCPNPOL.
       COPY CCPBCVGA.
016051 COPY CCPBPOLW.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM4903                     **
      *****************************************************************
