      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. CSOM7824.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7824                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE POLP TABLE                               **
      **                                                             **
      **            DEFERRED ACTIVITY                                **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020464**  6.4       FUND MGMT PROCESSING FOR PENDING & DEFER ACTIVITY**
023112**  6.5       CASH FLOW DESTINATION INSTRUCTIONS               **
023437**  6.5       WITHHOLDING AS PERCENTAGE OR FLAT AMOUNT         **
021657**  6.6       CORRECT FIELD NAMES IN MIR COPYBOOKS             **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7824'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                         PIC  X(04).
               88  WS-BUS-FCN-LIST                   VALUE '7824'.
           05  WS-POL-PAYO-EFF-DT                    PIC  X(10).
023437*    05  WS-CDI-TYP-CD                         PIC  X(01).
023437     05  WS-CDI-TYP-CD                         PIC  X(02).
               88  WS-CDI-TYP-TRMN                   VALUE
023437*            'B' 'D' 'E' 'G' 'H' 'J' 'K'.
023437             'B ' 'D ' 'E ' 'G ' 'H ' 'J ' 'K '.

               88  WS-CDI-TYP-SURR                   VALUE
023437*            'B', 'D', 'E', 'G', 'H', 'J',
023437*            'K', 'L', 'N', 'T', 'W'.
023437             'B ', 'D ', 'E ', 'G ', 'H ', 'J ',
023437             'K ', 'L ', 'N ', 'T ', 'W '.

               88  WS-CDI-TYP-NON-SURR               VALUE
023437*                                     'M'.
023437                                      'M '.
           05  I                                     PIC S9(04)
                                                     BINARY.
           05  WS-SUB                                PIC S9(04)
                                                     BINARY.
           05  WS-MAX-LIST-LINES                     PIC S9(04)
                                                     BINARY.
           05  WS-POL-PAYO-NUM                       PIC S9(05)
                                                     COMP-3.
           05  WS-DEFR-IN-AMT                        PIC S9(13)V9(02)
                                                     COMP-3.
           05  WS-DEFR-OUT-AMT                       PIC S9(13)V9(02)
                                                     COMP-3.
       01  WS-CONSTANT-AREA.
           05  FILLER                                PIC  X(01).

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCWWCVGS.
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFWPOLY.
       COPY CCFRPOLP.
      /
       COPY CCFWCDSI.
       COPY CCFRCDSI.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWLDTLK.
      /
       COPY CCWL5400.
      /
       COPY XCWL0280.
      /
       COPY XCWL0290.
      /
       COPY XCWL1640.
      /
       COPY XCWL1660.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7824.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID        TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7824'            TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'          TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *---------------------------
       2000-LIST.
      *---------------------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  8010-VALIDATE-KEY-FIELDS
               THRU 8010-VALIDATE-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  7000-BUILD-POLP-KEYS
               THRU 7000-BUILD-POLP-KEYS-X.

           PERFORM  POLY-1000-BROWSE-PREV
               THRU POLY-1000-BROWSE-PREV-X.

           PERFORM  POLY-2000-READ-PREV
               THRU POLY-2000-READ-PREV-X.

           IF  WPOLY-IO-EOF
               PERFORM  POLY-3000-END-BROWSE-PREV
                   THRU POLY-3000-END-BROWSE-PREV-X
      *MSG: 'NO DEFER RECORDS TO DISPLAY'
               MOVE 'CS78240003'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  2100-PRCES-DEFR-ACTV
               THRU 2100-PRCES-DEFR-ACTV-X
               UNTIL WS-SUB > WS-MAX-LIST-LINES
                  OR WPOLY-IO-EOF.

           IF  WPOLY-IO-EOF
               CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               MOVE 0                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-POL-PAYO-NUM
                                          TO L0290-MAX-OUT-LEN
               COMPUTE  L0290-INPUT-V00
                     =  100000
                     -  RPOLP-POL-PAYO-NUM
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA     TO MIR-POL-PAYO-NUM

           END-IF.

           PERFORM  POLY-3000-END-BROWSE-PREV
               THRU POLY-3000-END-BROWSE-PREV-X.

       2000-LIST-X.
           EXIT.


      *---------------------------
       2100-PRCES-DEFR-ACTV.
      *---------------------------
      *
      * DETAIL INFORMATION RELATED TO A DEFERRED ACTIVITY
      *

           IF  NOT RPOLP-POL-PAYO-TYP-SCHED-ACTV
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.


           PERFORM  POLY-2000-READ-PREV
               THRU POLY-2000-READ-PREV-X.

       2100-PRCES-DEFR-ACTV-X.
           EXIT.


      /
      *---------------------------
       7000-BUILD-POLP-KEYS.
      *---------------------------

           MOVE HIGH-VALUES             TO WPOLY-KEY.
           MOVE MIR-POL-ID              TO WPOLY-POL-ID.
           MOVE WS-POL-PAYO-NUM         TO WPOLY-POL-PAYO-NUM.
           MOVE WS-POL-PAYO-EFF-DT      TO WPOLY-POL-PAYO-EFF-DT.

           MOVE LOW-VALUES              TO WPOLY-ENDBR-KEY.
           MOVE MIR-POL-ID              TO WPOLY-ENDBR-POL-ID.
           MOVE 1                       TO WPOLY-ENDBR-POL-PAYO-NUM.
           MOVE WWKDT-LOW-DT            TO WPOLY-ENDBR-POL-PAYO-EFF-DT.

       7000-BUILD-POLP-KEYS-X.
           EXIT.


      /
      *---------------------------
       7100-BUILD-CDSI-KEYS.
      *---------------------------

           MOVE RPOLP-POL-ID              TO WCDSI-POL-ID.
           MOVE RPOLP-POL-PAYO-EFF-DT     TO L1660-INTERNAL-DATE.

           PERFORM 1660-2000-CONVERT-INT-TO-INV
              THRU 1660-2000-CONVERT-INT-TO-INV-X.

           MOVE L1660-INVERTED-DATE       TO WCDSI-CDI-EFF-IDT-NUM.
           MOVE RPOLP-POL-PAYO-TYP-CD     TO WCDSI-CDI-TYP-CD.
           MOVE RPOLP-POL-PAYO-NUM        TO WCDSI-POL-PAYO-NUM.
023112     MOVE +001                      TO WCDSI-CDI-SEQ-NUM.
           MOVE ZERO                      TO WCDSI-CDI-ALLOC-NUM.

           MOVE WCDSI-KEY                 TO WCDSI-ENDBR-KEY.
           MOVE +999                      TO WCDSI-ENDBR-CDI-ALLOC-NUM.

       7100-BUILD-CDSI-KEYS-X.
           EXIT.


      /
      *---------------------------
       8010-VALIDATE-KEY-FIELDS.
      *---------------------------

           PERFORM  8011-EDIT-POL-ID
               THRU 8011-EDIT-POL-ID-X.

           PERFORM  8012-EDIT-POL-PAYO-NUM
               THRU 8012-EDIT-POL-PAYO-NUM-X.

           PERFORM  8013-EDIT-EFF-DT
               THRU 8013-EDIT-EFF-DT-X.

       8010-VALIDATE-KEY-FIELDS-X.
           EXIT.

      *---------------------------
       8011-EDIT-POL-ID.
      *---------------------------
      *
      * CHECK POLICY EXISTS
      *
           IF  MIR-POL-ID-BASE  = SPACES
           AND MIR-POL-ID-SFX   = SPACES
      *MSG: POLICY NUMBER IS REQUIRED
               MOVE 'CS78240001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8011-EDIT-POL-ID-X
           END-IF.

           MOVE MIR-POL-ID               TO WPOL-POL-ID.

      *  UPDATE GROUP LEVEL TIMESTAMP FOR LOGICAL LOCKING

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD NOT FOUND
               MOVE 'XS00000001'         TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY             TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8011-EDIT-POL-ID-X
           END-IF.

      *
      * CHECK POLICY CONFIDENTIAL AND SECURITY ARE SATISFIED
      *

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-STAT-MSG-NOT-REQD   TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

       8011-EDIT-POL-ID-X.
           EXIT.

      *---------------------------
       8012-EDIT-POL-PAYO-NUM.
      *---------------------------
      *
      *  CHECK PAYOUT NUMBER
      *

           IF  MIR-POL-PAYO-NUM = SPACES
           OR  MIR-POL-PAYO-NUM = '00000'
               MOVE 99999            TO WS-POL-PAYO-NUM
               GO TO 8012-EDIT-POL-PAYO-NUM-X
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE 0                    TO L0280-PRECISION.
           MOVE LENGTH OF MIR-POL-PAYO-NUM
                                     TO L0280-INPUT-SIZE.

           COMPUTE  L0280-LENGTH
                 =  L0280-INPUT-SIZE.

           MOVE MIR-POL-PAYO-NUM     TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG: INVALID PAYOUT NUMBER
               MOVE 'CS78240002'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                TO WGLOB-MSG-ERROR-SW
               GO TO 8012-EDIT-POL-PAYO-NUM-X
           END-IF.

           COMPUTE  WS-POL-PAYO-NUM
                 =  100000
                 -  L0280-OUTPUT-V00.

       8012-EDIT-POL-PAYO-NUM-X.
           EXIT.

      *---------------------------
       8013-EDIT-EFF-DT.
      *---------------------------
      *
      *  CHECK EFFECTIVE DATE
      *

021657*    IF  MIR-DV-START-DT = SPACES
021657     IF  MIR-DV-STRT-DT = SPACES
               MOVE WWKDT-HIGH-DT        TO WS-POL-PAYO-EFF-DT
               GO TO 8013-EDIT-EFF-DT-X
           END-IF.

021657*    MOVE MIR-DV-START-DT          TO L1640-EXTERNAL-DATE.
021657     MOVE MIR-DV-STRT-DT           TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE  TO WS-POL-PAYO-EFF-DT
           ELSE
               MOVE 'XS00000036'         TO WGLOB-MSG-REF-INFO
021657*        MOVE MIR-DV-START-DT      TO WGLOB-MSG-PARM (1)
021657         MOVE MIR-DV-STRT-DT       TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
           END-IF.

       8013-EDIT-EFF-DT-X.
           EXIT.


      /
      *---------------------------
       9000-BLANK-DATA-FIELDS.
      *---------------------------

           MOVE SPACES                 TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.


      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------
      *
      * GET DEFERRED ACTIVIITY INSTRUCTIONS
      *

           MOVE ZEROES           TO WS-DEFR-IN-AMT.
           MOVE ZEROES           TO WS-DEFR-OUT-AMT.

           PERFORM  7100-BUILD-CDSI-KEYS
               THRU 7100-BUILD-CDSI-KEYS-X.

           PERFORM  CDSI-1000-BROWSE
               THRU CDSI-1000-BROWSE-X.

           PERFORM  CDSI-2000-READ-NEXT
               THRU CDSI-2000-READ-NEXT-X.

           PERFORM  9210-ACUM-CDSI
               THRU 9210-ACUM-CDSI-X
               UNTIL NOT WCDSI-IO-OK.

           PERFORM  CDSI-3000-END-BROWSE
               THRU CDSI-3000-END-BROWSE-X.

           ADD +1                     TO WS-SUB.

           MOVE 0                     TO L0290-PRECISION
           MOVE LENGTH OF MIR-POL-PAYO-NUM-T (WS-SUB)
                                      TO L0290-MAX-OUT-LEN

           COMPUTE  L0290-INPUT-V00
                 =  100000
                 -  RPOLP-POL-PAYO-NUM

           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X

           MOVE L0290-OUTPUT-DATA     TO MIR-POL-PAYO-NUM-T (WS-SUB).
           MOVE RPOLP-POL-PAYO-EFF-DT TO L1640-INTERNAL-DATE.

           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE
                              TO MIR-POL-PAYO-EFF-DT-T (WS-SUB).

           MOVE RPOLP-POL-PAYO-TYP-CD
                              TO MIR-POL-PAYO-TYP-CD-T (WS-SUB).

           COMPUTE  L0290-INPUT-V02
                 =  WS-DEFR-IN-AMT
                 +  WS-DEFR-OUT-AMT.

           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-POL-PAYO-TOT-AMT-T (WS-SUB)
                                        TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY       TO TRUE.

           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA
                              TO MIR-DV-POL-PAYO-TOT-AMT-T (WS-SUB).
           MOVE RPOLP-POL-PAYO-STAT-CD
                              TO MIR-POL-PAYO-STAT-CD-T    (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.


      /
      *---------------------------
       9210-ACUM-CDSI.
      *---------------------------

           MOVE RCDSI-CDI-TYP-CD           TO WS-CDI-TYP-CD.

           PERFORM  9220-ACCUM-TOT
               THRU 9220-ACCUM-TOT-X.

           PERFORM  CDSI-2000-READ-NEXT
               THRU CDSI-2000-READ-NEXT-X.

       9210-ACUM-CDSI-X.
           EXIT.


      *---------------------------
       9220-ACCUM-TOT.
      *---------------------------
      *
      * ACCUMULATE THE SET OF INSTRUCTIONS (CDSI), CHECK THE TYPE OF
      * ALLOCATION INSTRUCTION TO DETERMINE CDSI TO INCLUDE IN TOTAL
      * AS IT ENSURES A NET RESULT OF ZERO IS NOT PRODUCED
      *
            IF  RCDSI-DEST-CVG-NUM   = SPACES
            OR  RCDSI-DEST-CVG-NUM-N = ZEROES
                CONTINUE
            ELSE
                IF  RCDSI-DEST-CVG-NUM-N > ZEROES
                AND WCVGS-CVG-COLFND (RCDSI-DEST-CVG-NUM-N)
                    GO TO 9220-ACCUM-TOT-X
                END-IF
            END-IF.

           EVALUATE TRUE

              WHEN WS-CDI-TYP-SURR
      *
      * MONEY COMING OUT OF THE POLICY
      *
                    IF  RCDSI-CDI-ALLOC-AMT < ZERO
                        ADD RCDSI-CDI-ALLOC-AMT TO WS-DEFR-OUT-AMT
                    END-IF

              WHEN WS-CDI-TYP-NON-SURR
      *
      * MONEY GOING INTO THE POLICY
      *
                    IF  RCDSI-DEST-CVG-NUM-N = ZEROES
                        GO TO 9220-ACCUM-TOT-X
                    END-IF

                    IF  RCDSI-CDI-ALLOC-AMT > ZERO
                        ADD RCDSI-CDI-ALLOC-AMT TO WS-DEFR-IN-AMT
                    END-IF

           END-EVALUATE.

       9220-ACCUM-TOT-X.
           EXIT.


      /
      *---------------------------
       9300-SETUP-MSIN-REFERENCE.
      *---------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

           SET  WGLOB-REF-POLICY       TO TRUE.
           MOVE MIR-POL-ID             TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.


      /
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.

           MOVE MIR-BUS-FCN-ID         TO WS-BUS-FCN-ID.

      *
      *  SET THE NUMBER OF LIST LINES USING MIR FIELD OCCURENCES
      *
           COMPUTE  WS-MAX-LIST-LINES
                 =  LENGTH OF MIR-POL-PAYO-NUM-G
                 /  LENGTH OF MIR-POL-PAYO-NUM-T (1).

025970     MOVE SPACES TO WWKDT-WORK-FIELDS.
025970
       9990-INIT-WORKING-STORAGE-X.
           EXIT.


      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY NCPPCVGS.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY CCPS5400.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL5400.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
025970 COPY XCPS1660.
       COPY XCPL1660.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
      /
       COPY CCPNCVG.
      /
       COPY CCPVPOLY.
      /
       COPY CCPBCDSI.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM7824                     **
      *****************************************************************
