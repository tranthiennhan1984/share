      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM1870.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM1870                                         **
      **  REMARKS:  AMEX-AMENDMENTS, ENDORSEMENTS AND EXCLUSION      **
      **            MAINTENANCE                                      **
      **                                                             **
      **            THIS MODULE PERFORMS TABLE MAINTENANCE FUNCTIONS **
      **            FOR THE AMEX TABLE.  AMENDMENTS, ENDORSEMENTS    **
      **            AND EXCLUSIONS ON A POLICY ARE MAINTAINED.  A    **
      **            DOCUMENT NAME IS ASSOCIATED WITH EACH AMEX       **
      **            RECORD AND A PRINT INDICATOR IS USED TO CONTROL  **
      **            THE PRINTING OF THE CORRESPONDING DOCUMENTS      **
      **            DURING THE POLICY ISSUE PROCESS.  WHENEVER A     **
      **            AMEX IS CREATED A CORRESPONDING ISSUE            **
      **            REQUIREMENT IS CREATED.                          **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP/STANDARDIZATION, MOVE BROWSE        **
557708**  5.5       HANDLE CICS ABEND                                **
008445**  5.5.2     GENERATE MIR FROM TECH ARCH DATA BASE            **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       SET COMMENT FIELD LENGTH                         **
010418**  5.6       ADD SUB-COMPANY-CODE FIELD                       **
014455**  5.6A      NEW FOR RELEASE 5.6A                             **
012624**  6.0       POLICY ACCESS VERIFICATION CHANGES               **
013578**  6.0       ELIMINATE SUPPORT OF CHARACTER INTERFACE         **
014588**  6.0       MIR CHANGES                                      **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
015543**  6.0       CODE CLEANUP                                     **
015648**  6.0       HANDLING MIR DELETE CHARACTER                    **
014221**  6.2       LOGICAL LOCKING                                  **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019982**  6.3       PCR FOR IIAB PLATFORM                            **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
023201**  6.7       AMENDMENT RECORDS INACCESSIBLE WITH REISSUE      **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM1870'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
013578*    05  WS-TRANS-NAME                PIC X(04)  VALUE 'AMEX'.
013578*    05  WS-SW-VALID-FUNCTION         PIC X(1)   VALUE SPACES.
013578*        88  WS-VALID-FUNCTION        VALUE 'I' 'B' 'C' 'D' 'M'.
013578     05  WS-BUS-FCN-ID                PIC X(04).
013578         88  WS-BUS-FCN-RETRIEVE      VALUE '1580'.
013578         88  WS-BUS-FCN-CREATE        VALUE '1581'.
013578         88  WS-BUS-FCN-UPDATE        VALUE '1582'.
013578         88  WS-BUS-FCN-DELETE        VALUE '1583'.
013578         88  WS-BUS-FCN-LIST          VALUE '1584'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '1580'.
           05  WS-VALID-CROSS-EDITS-SW      PIC X(1)   VALUE SPACES.
               88  WS-VALID-CROSS-EDITS     VALUE 'Y'.
           05  WS-VALID-INPUT-SW            PIC X(1)   VALUE SPACES.
               88  WS-VALID-INPUT           VALUE 'Y'.
               88  WS-INVALID-INPUT         VALUE 'N'.
           05  WS-SW-CLIENT-VERIFY          PIC X(1)   VALUE SPACES.
               88  WS-CLIENT-VERIFY         VALUE 'Y'.
           05  WS-HOLD-IO-STATUS            PIC 9(01)  VALUE ZERO.
               88  WS-HOLD-IO-STATUS-OK     VALUE ZERO.
016548*    05  WS-MAX-DETAIL-LINES          PIC S9(4)  COMP
025970*    05  WS-MAX-DETAIL-LINES          PIC S9(4)  BINARY
025970*                                                VALUE +10.
016548*    05  WS-MAX-SUMMARY-LINES         PIC S9(4)  COMP
025970*    05  WS-MAX-SUMMARY-LINES         PIC S9(4)  BINARY
025970*                                                VALUE +12.
016548*    05  I                            PIC S9(4)  COMP.
016548     05  I                            PIC S9(4)  BINARY.
016548*    05  WS-TEMP                      PIC S9(4)  COMP.
016548     05  WS-TEMP                      PIC S9(4)  BINARY.
016548*    05  WS-IND                       PIC S9(4)  COMP.
016548     05  WS-IND                       PIC S9(4)  BINARY.
016548*    05  WS-LINE                      PIC S9(4)  COMP.
016548     05  WS-LINE                      PIC S9(4)  BINARY.
016548*    05  WS-DEST                      PIC S9(4)  COMP.
016548     05  WS-DEST                      PIC S9(4)  BINARY.
           05  WS-NUM-2-0                   PIC 9(02)  VALUE ZEROS.
010311     05  WS-COMMENT-TABLE             PIC X(790).
010311     05  FILLER REDEFINES WS-COMMENT-TABLE.
010311         10  WS-COMMENT-CHAR          PIC X     OCCURS 790.

025970*
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                 VALUE '1580'.
025970     05  WS-MAX-DETAIL-LINES          PIC S9(4)  BINARY.
025970         88  WS-DEFAULT-MAX-DETAIL-LINES         VALUE +10.
025970     05  WS-MAX-SUMMARY-LINES         PIC S9(4)  BINARY.
025970         88  WS-DEFAULT-MAX-SUMMARY-LINES        VALUE +12.
      *
       COPY XCWWWKDT.
       COPY XCWEBLCH.
014221 COPY CCWWLOCK.
      *
      *
      *  FILE AREA
      *
       COPY NCFWAMEX.
       COPY NCFRAMEX.
      *
       COPY CCFWCVG.
       COPY CCFRCVG.
      *
023447*COPY NCFWDOCM.
023447*COPY NCFRDOCM.
023447 COPY XCFWDOCM.
023447 COPY XCFRDOCM.
      *
       COPY CCFWPOL.
       COPY CCFRPOL.
      *
       COPY CCFWRL.
       COPY CCFRRL.
      *
      *
      *  PARAMETER AREA
      *
028298 COPY CCWL2626.
       COPY CCWL5400.
      *
       COPY NCWL0080.
      *
016440 COPY CCWL2222.
      *
       COPY NCWL2437.
      *
       COPY XCWLDTLK.
      *
       COPY XCWL0280.
      *
020874 COPY XCWL0290.
      *
       COPY XCWL1640.
      *
014221 COPY XCWL8090.
      *
      *
      *  COMM AREA
      *
014588*COPY CCWCCOMM.
014588*COPY NCWC1870.
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM1870.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

015648     INSPECT MIR-PARM-AREA REPLACING ALL '*' BY ' '.

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.

      *----------------------------------------------------------------
      * NORMAL PROCESSING: CHECK SECURITY PERMISSION &
      * DISTRIBUTE CONTROL TO APPROPRIATE PROCESSING ROUTINE.
      *----------------------------------------------------------------
       2000-PROCESS-REQUEST.
      *
      * INITIALISE VARIABLES NEEDED FOR THIS TRANSACTION
      *
020874     PERFORM  0290-1000-BUILD-PARM-INFO
020874         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2050-INITIALISE
               THRU 2050-INITIALISE-X.

           IF  WS-BUS-FCN-CREATE
               PERFORM  4000-PROCESS-CREATE
                   THRU 4000-PROCESS-CREATE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           PERFORM  2200-VALIDATE-CONTROL-FIELD
               THRU 2200-VALIDATE-CONTROL-FIELD-X.
           IF  WS-INVALID-INPUT
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  WS-BUS-FCN-RETRIEVE
               PERFORM  3000-PROCESS-RETRIEVE
                   THRU 3000-PROCESS-RETRIEVE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  WS-BUS-FCN-LIST
               PERFORM  3500-PROCESS-LIST
                   THRU 3500-PROCESS-LIST-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

023201*    IF  RPOL-POL-SUSPENDED
023201*        MOVE 'XS00000240'      TO WGLOB-MSG-REF-INFO
023201*        PERFORM  0260-1000-GENERATE-MESSAGE
023201*            THRU 0260-1000-GENERATE-MESSAGE-X
023201*        GO TO 2000-PROCESS-REQUEST-X
023201*    END-IF.

           IF  L5400-STAT-ACCS-RESTRICTED
012624*    OR  L5400-CTL-ACCS-RESTRICTED
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF  WS-BUS-FCN-UPDATE
               PERFORM  5000-PROCESS-UPDATE
                   THRU 5000-PROCESS-UPDATE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  WS-BUS-FCN-DELETE
               PERFORM  6000-PROCESS-DELETE
                   THRU 6000-PROCESS-DELETE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *----------------------------------------------------------------
      * INITIALISE: INITIALISE MISCELLANEOUS VARIABLES NEEDED FOR
      * PROCESSING IN THIS TRANSACTION.
      *----------------------------------------------------------------
       2050-INITIALISE.
      *
      * INITIALISE WORK VARIABLES
      *
           MOVE '0'            TO WGLOB-RETURN-CODE.
019982     INITIALIZE          L2222-PARM-INFO.
      *
      * SET UP MESSAGE VARIABLES
      *
           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID TO WS-BUS-FCN-ID.

       2050-INITIALISE-X.
           EXIT.

      *----------------------------------------------------------------
      * VALIDATE CONTROL FIELDS: EDIT DATE TO ENSURE IT IS IN VALID F
      *----------------------------------------------------------------
       2200-VALIDATE-CONTROL-FIELD.

           SET WS-VALID-INPUT TO TRUE.

           PERFORM  4110-EDIT-POLICY
               THRU 4110-EDIT-POLICY-X.

           PERFORM  4130-EDIT-SEQUENCE-NUMBER
               THRU 4130-EDIT-SEQUENCE-NUMBER-X.

       2200-VALIDATE-CONTROL-FIELD-X.
           EXIT.

      *----------------------------------------------------------------
      * INQUIRY PROCESSING
      *----------------------------------------------------------------
       3000-PROCESS-RETRIEVE.

           SET WS-VALID-INPUT         TO TRUE.
           MOVE WS-MAX-DETAIL-LINES   TO WS-LINE.

           PERFORM  8000-BUILD-AMEX-KEY
               THRU 8000-BUILD-AMEX-KEY-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

014221     MOVE MIR-POL-ID-BASE           TO WPOL-POL-ID-BASE.
014221     MOVE MIR-POL-ID-SFX            TO WPOL-POL-ID-SFX.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           PERFORM  AMEX-1000-READ
               THRU AMEX-1000-READ-X.

      *
      * RECORD NOT FOUND, CANNOT INQUIRE
      *
           IF  NOT WAMEX-IO-OK
      ***      MESSAGE (S) 'AMENDMENT/EXCLUSION RECORD NOT FOUND (@1)'
               MOVE 'NS18700005'      TO WGLOB-MSG-REF-INFO
               MOVE WAMEX-KEY         TO WGLOB-MSG-PARM (1)
           ELSE
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
                 EXIT.

      *----------------------------------------------------------------
      * SET LIST START: DETERMINE THE KEY TO USE FOR THE START OF
      * BROWSE PROCESSING
      *----------------------------------------------------------------
       3200-SET-LIST-START.

      *
      * BUILD DEFAULT AMEX KEY
      *
           PERFORM  8000-BUILD-AMEX-KEY
               THRU 8000-BUILD-AMEX-KEY-X.
      *
      * SET UP END LIST KEY
      *
           MOVE WAMEX-KEY             TO WAMEX-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WAMEX-ENDBR-AMEX-REC-TYP-CD.
           MOVE HIGH-VALUES           TO WAMEX-ENDBR-AMEX-SEQ-NUM.

       3200-SET-LIST-START-X.
           EXIT.

      *----------------------------------------------------------------
      * NEXT PAGE: INQUIRE FOR THE NEXT PAGE OF DATA
      *----------------------------------------------------------------
       3300-NEXT-PAGE.
      *
      * BEGIN FILLING DATA ON THE FIRST DISPLAY LINE.
      *
           MOVE +1                    TO WS-LINE.
      *
      * BEGIN BROWSE
      *
           PERFORM  AMEX-1000-BROWSE
               THRU AMEX-1000-BROWSE-X.
      *
      * READ FIRST RECORD
      * STORE THE STATUS CODE BECAUSE THE BROWSE WILL RESET IT.
      *
           IF  WAMEX-IO-OK
               PERFORM  AMEX-2000-READ-NEXT
                   THRU AMEX-2000-READ-NEXT-X
               MOVE WAMEX-IO-STATUS   TO WS-HOLD-IO-STATUS
               IF  WAMEX-IO-EOF
                   PERFORM  AMEX-3000-END-BROWSE
                       THRU AMEX-3000-END-BROWSE-X
557660         END-IF
557660     END-IF.
      *
      * IF NO DATA EXISTS FOR THE CURRENT KEY PUT OUT A MESSAGE
      *
           IF  NOT WAMEX-IO-OK
           OR  NOT WS-HOLD-IO-STATUS-OK
      ***      MESSAGE (I) "NO RECORDS FOUND TO DISPLAY"
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3300-NEXT-PAGE-X
557660     END-IF.
      *
      * UPDATE THE KEYS WHEN THE FIRST RECORD IS READ
      *
           IF  WAMEX-IO-OK
               PERFORM  9250-UPDATE-SCREEN-KEYS
                   THRU 9250-UPDATE-SCREEN-KEYS-X
557660     END-IF.
      *
      * DISPLAY THE DATA ON THE SCREEN IN A DETAIL OR SUMMARY FORMAT
      *
           IF  WS-BUS-FCN-RETRIEVE
               PERFORM  3310-DISPLAY-RECORD-NEXT
                   THRU 3310-DISPLAY-RECORD-NEXT-X
               MOVE +2                TO WS-LINE
           ELSE
               PERFORM  3310-DISPLAY-RECORD-NEXT
                   THRU 3310-DISPLAY-RECORD-NEXT-X
                        VARYING WS-LINE FROM WS-LINE BY +1
                        UNTIL WAMEX-IO-EOF
                           OR WS-LINE > WS-MAX-SUMMARY-LINES
557660     END-IF.
      *
      * COMPLETION MESSAGE
      *
           IF  WAMEX-IO-OK
      ***      MESSAGE (I) "** TO VIEW MORE DATA PRESS ENTER **"
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9250-UPDATE-SCREEN-KEYS
                   THRU 9250-UPDATE-SCREEN-KEYS-X
           ELSE
               IF  WS-LINE > 1
                   MOVE 'XS00000015'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      ***          MESSAGE (I) "NO RECORDS FOUND TO DISPLAY".
                   MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
557660         END-IF
557660     END-IF.
      *
      * FINISH BROWSE
      *
           PERFORM  AMEX-3000-END-BROWSE
               THRU AMEX-3000-END-BROWSE-X.

       3300-NEXT-PAGE-X.
           EXIT.

      *----------------------------------------------------------------
      * INQUIRY - DISPLAY RECORD NEXT:               INPUT: WS-LINE
      * DISPLAY THE CURRENT RECORD ONTO THE SCREEN DATA LINE GIVEN BY
      * WS-LINE AND RETRIEVE THE NEXT RECORD.
      *----------------------------------------------------------------
       3310-DISPLAY-RECORD-NEXT.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  AMEX-2000-READ-NEXT
               THRU AMEX-2000-READ-NEXT-X.

       3310-DISPLAY-RECORD-NEXT-X.
           EXIT.

      *----------------------------------------------------------------
      * BROWSE PROCESSING:
      *----------------------------------------------------------------
       3500-PROCESS-LIST.

           SET WS-VALID-INPUT TO TRUE.
      *
      * SET SCREEN TO USE FOR THE INQUIRE
      *
           MOVE WS-MAX-SUMMARY-LINES TO WS-LINE.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      *
      * DETERMINE KEY TO USE FOR START OF BROWSE PROCESSING
      *
           PERFORM  3200-SET-LIST-START
               THRU 3200-SET-LIST-START-X.
      *
      * DISPLAY SCREEN
      *
           PERFORM  3300-NEXT-PAGE
               THRU 3300-NEXT-PAGE-X.

       3500-PROCESS-LIST-X.
           EXIT.

      *----------------------------------------------------------------
      * CREATE PROCESSING: CHECK RECORD DOES NOT EXIST, INIT NEW RECO
      * AND ALLOW USER TO MODIFY.
      *----------------------------------------------------------------
       4000-PROCESS-CREATE.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      *** CHECK CONTROL FIELDS.
           PERFORM  4100-EDIT-KEY-FIELDS
               THRU 4100-EDIT-KEY-FIELDS-X.
           IF  WS-INVALID-INPUT
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

012624*    IF  L5400-CTL-ACCS-RESTRICTED
012624*        GO TO 4000-PROCESS-CREATE-X
012624*    END-IF.
023201*    IF  RPOL-POL-SUSPENDED
023201*        MOVE 'XS00000240'      TO WGLOB-MSG-REF-INFO
023201*        PERFORM  0260-1000-GENERATE-MESSAGE
023201*            THRU 0260-1000-GENERATE-MESSAGE-X
023201*        GO TO 4000-PROCESS-CREATE-X
023201*    END-IF.


016440* AMEX RECORDS WILL BE ALLOWED TO BE CREATED ON INFORCE POLICIES
016440* WITH PENDING COVERAGES.  CALL NEW ROUTINE TO DETERMINE IF
016440* PENDING COVERAGES EXIST ON AN INFORCE POLICY.

016440     IF RPOL-POL-STAT-IN-FORCE
016440        PERFORM  2222-1000-BUILD-PARM-INFO
016440            THRU 2222-1000-BUILD-PARM-INFO-X
016440        MOVE RPOL-POL-ID        TO L2222-POL-ID
016440        PERFORM 2222-1000-FIND-PEND-CVG
016440           THRU 2222-1000-FIND-PEND-CVG-X
016440     END-IF.


      *
016440* CANNOT ADD TO A SETTLED POLICY WITH SETTLED COVERAGES
      *
           IF  RPOL-POL-STAT-IN-FORCE
016440     AND L2222-INFORCE-POL-INFORCE-CVG
      ***      MESSAGE (S) 'RECORD NOT CREATED.  POLICY SETTLED
016440***      AND COVERAGES SETTLED'
               MOVE 'NS18700015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.
      *
      * ATTEMPT TO READ THE RECORD
      *
           PERFORM  8000-BUILD-AMEX-KEY
               THRU 8000-BUILD-AMEX-KEY-X.
           PERFORM  AMEX-1000-READ
               THRU AMEX-1000-READ-X.
      *
      * CANNOT CREATE RECORD, THE RECORD ALREADY EXISTS
      *
           IF  WAMEX-IO-OK
      ***      MESSAGE (S) 'RECORD ALREADY EXISTS (@1)'
               MOVE WAMEX-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
557660     END-IF.
      *
      * CREATE NEW RECORD
      *
           PERFORM  AMEX-1000-CREATE
               THRU AMEX-1000-CREATE-X.

           MOVE WGLOB-SYSTEM-DATE-INT TO RAMEX-AMEX-TRXN-DT.

010311     PERFORM  8100-SET-COMMENT-LENGTH
010311         THRU 8100-SET-COMMENT-LENGTH-X.

           PERFORM  AMEX-1000-WRITE
               THRU AMEX-1000-WRITE-X.
      ***  MESSAGE (I) "RECORD CREATED - CONTINUE".
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

014221     MOVE MIR-POL-ID-BASE           TO WPOL-POL-ID-BASE.
014221     MOVE MIR-POL-ID-SFX            TO WPOL-POL-ID-SFX.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

      *
      * GENERATE A SETTLE REQUIREMENT
      *
           IF  RAMEX-AMEX-REC-TYP-AMENDMENT
               PERFORM  4200-GENERATE-REQUIREMENT
                   THRU 4200-GENERATE-REQUIREMENT-X
557660     END-IF.
      *
      * SWITCH TO DETAIL SCREEN FOR MAINTAIN PROCESSING
      *
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
      ***  MESSAGE (I) "MAINTAIN DETAILS".
           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-PROCESS-CREATE-X.
           EXIT.

      *----------------------------------------------------------------
      * EDIT KEY FIELDS: CHECK VALIDITY OF ALL KEY FIELDS TO ENSURE T
      * ALL NEW RECORDS ARE CREATED WITH VALID KEYS.
      *----------------------------------------------------------------
       4100-EDIT-KEY-FIELDS.

           SET WS-VALID-INPUT TO TRUE.

           PERFORM  4110-EDIT-POLICY
               THRU 4110-EDIT-POLICY-X.

           PERFORM  4120-EDIT-RECORD-TYPE
               THRU 4120-EDIT-RECORD-TYPE-X.

           PERFORM  4130-EDIT-SEQUENCE-NUMBER
               THRU 4130-EDIT-SEQUENCE-NUMBER-X.

       4100-EDIT-KEY-FIELDS-X.
           EXIT.

      *----------------------------------------------------------------
      * EDIT POLICY: MUST BE ON POLICY FILE AND THE USER MUST HAVE
      * BRANCH SECURITY TO LOOK AT THIS POLICY
      *----------------------------------------------------------------
       4110-EDIT-POLICY.

           MOVE MIR-POL-ID-BASE           TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX            TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
      ***      MESSAGE (S) 'POLICY NOT ON POLICY FILE'
               SET WS-INVALID-INPUT   TO TRUE
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID       TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4110-EDIT-POLICY-X
557660     END-IF.

016440*    IF  RPOL-POL-APPL-CTL-ADMIN
016440*        SET WS-INVALID-INPUT   TO TRUE
016440*        MOVE 'XS00000239'      TO WGLOB-MSG-REF-INFO
016440*        PERFORM  0260-1000-GENERATE-MESSAGE
016440*            THRU 0260-1000-GENERATE-MESSAGE-X
016440*    END-IF.

012624* IF BFID INDICATES A LIST FUNCTION, BYPASS POLICY ACCESS EDIT.
012624     IF  WS-BUS-FCN-LIST
012624         GO TO 4110-EDIT-POLICY-X
012624     END-IF.

      *
      * CHECK BRANCH SECURITY
      *

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
               SET WS-INVALID-INPUT TO TRUE
               GO TO 4110-EDIT-POLICY-X
           END-IF.

       4110-EDIT-POLICY-X.
           EXIT.

      *----------------------------------------------------------------
      * EDIT RECORD TYPE: CHECK FOR VALID RECORD TYPE
      *----------------------------------------------------------------
       4120-EDIT-RECORD-TYPE.

           IF  MIR-AMEX-REC-TYP-CD NOT = 'AM'
           AND MIR-AMEX-REC-TYP-CD NOT = 'EN'
           AND MIR-AMEX-REC-TYP-CD NOT = 'EX'
      ***      MESSAGE (S) ' RECORD TYPE INVALID. VALID VALUES ARE @1'
               SET WS-INVALID-INPUT   TO TRUE
               MOVE 'NS18700002'      TO WGLOB-MSG-REF-INFO
               MOVE 'AM, EN, EX'      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4120-EDIT-RECORD-TYPE-X.
           EXIT.

      *----------------------------------------------------------------
      * EDIT RECORD SEQUENCE: CHECK FOR NUMERIC VALUE
      *----------------------------------------------------------------
       4130-EDIT-SEQUENCE-NUMBER.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZEROES                TO L0280-PRECISION.
           MOVE '2'                   TO L0280-LENGTH.
           MOVE MIR-AMEX-SEQ-NUM      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
           AND L0280-OUTPUT > ZERO
020874*        MOVE L0280-OUTPUT      TO WS-NUM-2-0
020874*        MOVE WS-NUM-2-0        TO MIR-AMEX-SEQ-NUM
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-AMEX-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-AMEX-SEQ-NUM
           ELSE
      ***      MESSAGE (S) 'RECORD SEQUENCE MUST BE NUMERIC'
               SET WS-INVALID-INPUT   TO TRUE
               MOVE 'NS18700003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       4130-EDIT-SEQUENCE-NUMBER-X.
           EXIT.

      *----------------------------------------------------------------
      * GENERATE REQUIREMENT: GENERATE A SETTLE REQUIREMENT FOR THE
      * POLICY
      *----------------------------------------------------------------
       4200-GENERATE-REQUIREMENT.
      *
      * SET UP INPUT PARAMETERS TO THE REQUIREMENT WRITE WORKER MODULE
      *
           PERFORM  0080-1000-BUILD-PARM-INFO
               THRU 0080-1000-BUILD-PARM-INFO-X.

           SET L0080-POLICY-LEVEL     TO TRUE.
           MOVE RPOL-POL-ID           TO L0080-POL-ID.
           MOVE ZERO                  TO L0080-COVERAGE-NUMBER.
           MOVE 'AMEND'               TO L0080-REQIR-CODE.
           SET L0080-REQIR-STAT-SUGG-ISS-RQIR TO TRUE.

           PERFORM  0080-4000-WRITE
               THRU 0080-4000-WRITE-X.

           IF  L0080-RETRN-OK
               IF  L0080-RSLT-NOT-FOUND
      * MSG: AMENDMENT SETTLE REQUIREMENT NOT GENERATED
                   MOVE 'NS18700004'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU  0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       4200-GENERATE-REQUIREMENT-X.
           EXIT.

      *----------------------------------------------------------------
      * MAINTAIN PROCESSING:
      *----------------------------------------------------------------
       5000-PROCESS-UPDATE.

           PERFORM  5200-PROCESS-UPDATE
               THRU 5200-PROCESS-UPDATE-X.

       5000-PROCESS-UPDATE-X.
           EXIT.

      *----------------------------------------------------------------
      * FETCH AND LOCK RECORD, EDIT INCOMING DATA FIELDS, AND UPDATE
      *----------------------------------------------------------------
       5200-PROCESS-UPDATE.
      *

014221     MOVE MIR-POL-ID-BASE           TO WPOL-POL-ID-BASE.
014221     MOVE MIR-POL-ID-SFX            TO WPOL-POL-ID-SFX.

014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  WPOL-IO-NOT-FOUND
014221*MSG:  'POLICY NOT ON POLICY FILE'
014221         SET WS-INVALID-INPUT    TO TRUE
014221         MOVE 'XS00000070'       TO WGLOB-MSG-REF-INFO
014221         MOVE WPOL-POL-ID        TO WGLOB-MSG-PARM (01)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5200-PROCESS-UPDATE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
014221         SET WS-INVALID-INPUT    TO  TRUE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'POL'              TO WGLOB-MSG-PARM (01)
014221         MOVE WPOL-KEY           TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5200-PROCESS-UPDATE-X
014221     END-IF.


      * READ AMEX RECORD TO UPDATE
      *
           PERFORM  8000-BUILD-AMEX-KEY
               THRU 8000-BUILD-AMEX-KEY-X.
           PERFORM  AMEX-1000-READ-FOR-UPDATE
               THRU AMEX-1000-READ-FOR-UPDATE-X.

      *
      * RECORD NOT FOUND, CANNOT UPDATE
      *
           IF  NOT WAMEX-IO-OK
      ***      MESSAGE (S) "LOST RECORD IN MAINTAIN (@1) - CONTACT SYSTE
               MOVE WAMEX-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
014221         PERFORM  POL-3000-UNLOCK
014221             THRU POL-3000-UNLOCK-X
               GO TO 5200-PROCESS-UPDATE-X
557660     END-IF.
      *
      * EDIT THE DATA ENTERED
      *
           PERFORM  5300-EDIT-DATA-FIELDS
               THRU 5300-EDIT-DATA-FIELDS-X.
           PERFORM  5400-DATA-CROSS-EDITS
               THRU 5400-DATA-CROSS-EDITS-X.

010311     PERFORM  8100-SET-COMMENT-LENGTH
010311         THRU 8100-SET-COMMENT-LENGTH-X.

           PERFORM  AMEX-2000-REWRITE
               THRU AMEX-2000-REWRITE-X.

014221     PERFORM  POL-2000-REWRITE
014221         THRU POL-2000-REWRITE-X.

           IF  WS-VALID-INPUT
557660     AND WS-VALID-CROSS-EDITS
      ***      MESSAGE (I) "MAINTENANCE COMPLETED - CONTINUE"
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      ***      MESSAGE (I) "RECORD UPDATED".
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       5200-PROCESS-UPDATE-X.
           EXIT.

      *----------------------------------------------------------------
      * FIELD EDITS: CHECK VALIDITY OF ALL DATA FIELDS.
      *----------------------------------------------------------------
       5300-EDIT-DATA-FIELDS.

           SET WS-VALID-INPUT TO TRUE.

           PERFORM  5310-EDIT-COVERAGE
               THRU 5310-EDIT-COVERAGE-X.

           PERFORM  5320-EDIT-CLIENT
               THRU 5320-EDIT-CLIENT-X.

           PERFORM  5330-EDIT-DOCUMENT
               THRU 5330-EDIT-DOCUMENT-X.

           PERFORM  5340-EDIT-PRINT-IND
               THRU 5340-EDIT-PRINT-IND-X.

           PERFORM  5350-EDIT-RETENTION-IND
               THRU 5350-EDIT-RETENTION-IND-X.

           PERFORM  5360-EDIT-COMMENTS
               THRU 5360-EDIT-COMMENTS-X.

       5300-EDIT-DATA-FIELDS-X.
           EXIT.

      *----------------------------------------------------------------
      * EDIT COVERAGE NUMBER: MUST BE NUMERIC, AND COVERAGE MUST
      * EXIST ON THE POLICY
      *----------------------------------------------------------------
       5310-EDIT-COVERAGE.

           IF  MIR-CVG-NUM = SPACES
               MOVE RAMEX-CVG-NUM     TO MIR-CVG-NUM
               GO TO 5310-EDIT-COVERAGE-X
557660     END-IF.

           IF  MIR-CVG-NUM = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RAMEX-CVG-NUM
               MOVE SPACES            TO MIR-CVG-NUM
               GO TO 5310-EDIT-COVERAGE-X
557660     END-IF.
      *
      * COVERAGE NUMBER MUST BE NUMERIC
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE ZEROES                TO L0280-PRECISION.
           MOVE '2'                   TO L0280-LENGTH.
           MOVE MIR-CVG-NUM           TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
020874*        MOVE L0280-OUTPUT      TO WS-NUM-2-0
020874*        MOVE WS-NUM-2-0        TO MIR-CVG-NUM
020874         MOVE L0280-OUTPUT      TO L0290-INPUT-V00
020874         MOVE 0                 TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CVG-NUM
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA TO MIR-CVG-NUM
           ELSE
      ***      MESSAGE (S) 'COVERAGE NUMBER MUST BE NUMERIC'
               SET WS-INVALID-INPUT   TO TRUE
               MOVE 'NS18700006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5310-EDIT-COVERAGE-X
557660     END-IF.
      *
      * COVERAGE MUST EXIST ON THE POLICY
      *
           MOVE MIR-POL-ID-BASE       TO WCVG-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WCVG-POL-ID-SFX.
           MOVE MIR-CVG-NUM           TO WCVG-CVG-NUM.

           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X.
           IF  WCVG-IO-OK
               MOVE MIR-CVG-NUM       TO RAMEX-CVG-NUM
           ELSE
      ***      MESSAGE (S) 'COVERAGE RECORD NOT FOUND (@1)'
               SET WS-INVALID-INPUT   TO TRUE
               MOVE 'NS18700007'      TO WGLOB-MSG-REF-INFO
               MOVE WCVG-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5310-EDIT-COVERAGE-X
557660     END-IF.

       5310-EDIT-COVERAGE-X.
           EXIT.

      *----------------------------------------------------------------
      * EDIT CLIENT NUMBER - MUST BE ON CLIENT FILE AND BE ATTACHED
      * TO THE POLICY OR COVERAGE RECORD
      *----------------------------------------------------------------
       5320-EDIT-CLIENT.

           IF  MIR-CLI-ID = SPACES
               MOVE RAMEX-CLI-ID      TO MIR-CLI-ID
               GO TO 5320-EDIT-CLIENT-X
557660     END-IF.

           IF  MIR-CLI-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RAMEX-CLI-ID
               MOVE SPACES            TO MIR-CLI-ID
               GO TO 5320-EDIT-CLIENT-X
557660     END-IF.
      *
      * CHECK NAME AND ADDRESS FILE
      *
           MOVE MIR-CLI-ID            TO L2437-CLI-ID.

           PERFORM  2437-1000-OBTAIN-CLI-INFO
               THRU 2437-1000-OBTAIN-CLI-INFO-X.

           IF  L2437-RETRN-OK
               MOVE MIR-CLI-ID        TO RAMEX-CLI-ID
           ELSE
      * MSG: CLIENT NOT ON NAME AND ADDRESS FILE
               SET WS-INVALID-INPUT   TO TRUE
               MOVE 'NS18700008'      TO WGLOB-MSG-REF-INFO

               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

               GO TO 5320-EDIT-CLIENT-X

           END-IF.

       5320-EDIT-CLIENT-X.
           EXIT.

      *----------------------------------------------------------------
      * EDIT DOCUMENT: MUST BE ON DOCUMENT FILE
      *----------------------------------------------------------------
       5330-EDIT-DOCUMENT.

           IF  MIR-DOC-ID = SPACES
               MOVE RAMEX-DOC-ID      TO MIR-DOC-ID
557660     END-IF.

           IF  MIR-DOC-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RAMEX-DOC-ID
               MOVE SPACES            TO MIR-DOC-ID
557660     END-IF.

           IF  MIR-DOC-ID = SPACES
               SET WS-INVALID-INPUT   TO TRUE
               MOVE 'NS18700014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5330-EDIT-DOCUMENT-X
557660     END-IF.
      *
      * BROWSE DOCUMENT FILE TO MAKE SURE DOCUMENT EXISTS
      *
           MOVE MIR-DOC-ID            TO WDOCM-DOC-ID.
023447*    MOVE LOW-VALUES            TO WDOCM-DOC-LANG-CD.
023447*    MOVE WDOCM-KEY             TO WDOCM-ENDBR-KEY.
023447*    MOVE HIGH-VALUES           TO WDOCM-ENDBR-DOC-LANG-CD.

023447     PERFORM  DOCM-2000-READ-INDEX
023447         THRU DOCM-2000-READ-INDEX-X.

023447*    PERFORM  DOCM-1000-BROWSE
023447*        THRU DOCM-1000-BROWSE-X.
023447*    IF  WDOCM-IO-EOF
023447     IF WDOCM-IO-NOT-FOUND
      ***      MESSAGE (S) 'DOCUMENT MASTER RECORD NOT FOUND (@1)'
               SET WS-INVALID-INPUT   TO TRUE
               MOVE 'NS18700009'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-DOC-ID        TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
023447*013578         PERFORM  DOCM-3000-END-BROWSE
023447*013578             THRU DOCM-3000-END-BROWSE-X
               GO TO 5330-EDIT-DOCUMENT-X
023447     ELSE
023447         MOVE MIR-DOC-ID        TO RAMEX-DOC-ID
557660     END-IF.

023447*           PERFORM  DOCM-2000-READ-NEXT
023447*               THRU DOCM-2000-READ-NEXT-X.
023447*           IF  WDOCM-IO-OK
023447*               MOVE MIR-DOC-ID        TO RAMEX-DOC-ID
023447*           ELSE
023447****    MESSAGE (S) 'DOCUMENT MASTER RECORD NOT FOUND (@1)'
023447*               SET WS-INVALID-INPUT   TO TRUE
023447*               MOVE 'NS18700009'      TO WGLOB-MSG-REF-INFO
023447*               MOVE MIR-DOC-ID        TO WGLOB-MSG-PARM (1)
023447*               PERFORM  0260-1000-GENERATE-MESSAGE
023447*                   THRU 0260-1000-GENERATE-MESSAGE-X
023447*557660     END-IF.

023447*    PERFORM  DOCM-3000-END-BROWSE
023447*        THRU DOCM-3000-END-BROWSE-X.

       5330-EDIT-DOCUMENT-X.
           EXIT.

      *----------------------------------------------------------------
      * EDIT PRINT INDICATOR: MUST BE A VALID VALUE
      *----------------------------------------------------------------
       5340-EDIT-PRINT-IND.

           IF  MIR-AMEX-PRT-IND = SPACES
               MOVE RAMEX-AMEX-PRT-IND               TO MIR-AMEX-PRT-IND
557660     END-IF.

           IF  MIR-AMEX-PRT-IND = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RAMEX-AMEX-PRT-IND
               MOVE SPACES            TO MIR-AMEX-PRT-IND
557660     END-IF.

           IF  MIR-AMEX-PRT-IND NOT = 'Y'
           AND MIR-AMEX-PRT-IND NOT = 'N'
      ***      MESSAGE (S) 'PRINT INDICATOR INVALID. VALID VALUES ARE @1
               MOVE 'Y, N'            TO WGLOB-MSG-PARM (1)
               SET WS-INVALID-INPUT   TO TRUE
               MOVE 'NS18700010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5340-EDIT-PRINT-IND-X
557660     END-IF.

           MOVE MIR-AMEX-PRT-IND  TO RAMEX-AMEX-PRT-IND.

       5340-EDIT-PRINT-IND-X.
           EXIT.

      *----------------------------------------------------------------
      * EDIT RETENTION INDICATOR: MUST BE A VALID VALUE
      *----------------------------------------------------------------
       5350-EDIT-RETENTION-IND.

           IF  MIR-AMEX-REC-RETEN-CD = SPACES
               MOVE RAMEX-AMEX-REC-RETEN-CD
                                      TO MIR-AMEX-REC-RETEN-CD
557660     END-IF.

           IF  MIR-AMEX-REC-RETEN-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO RAMEX-AMEX-REC-RETEN-CD
               MOVE SPACES            TO MIR-AMEX-REC-RETEN-CD
557660     END-IF.

           IF  MIR-AMEX-REC-RETEN-CD NOT = 'T'
           AND MIR-AMEX-REC-RETEN-CD NOT = 'P'
      ***      MESSAGE (S) 'RETENTION INDICATOR INVALID. VALID VALUES AR
               MOVE 'T, P'            TO WGLOB-MSG-PARM (1)
               SET WS-INVALID-INPUT   TO TRUE
               MOVE 'NS18700011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5350-EDIT-RETENTION-IND-X
557660     END-IF.

           MOVE MIR-AMEX-REC-RETEN-CD TO RAMEX-AMEX-REC-RETEN-CD.

       5350-EDIT-RETENTION-IND-X.
           EXIT.

      *----------------------------------------------------------------
      * EDIT COMMENT - PROCESS ALL COMMENT LINES
      *----------------------------------------------------------------
       5360-EDIT-COMMENTS.

           PERFORM  5361-EDIT-COMMENT-L
               THRU 5361-EDIT-COMMENT-L-X
            VARYING WS-IND FROM 1 BY 1
              UNTIL WS-IND > WS-MAX-DETAIL-LINES.

       5360-EDIT-COMMENTS-X.
           EXIT.

      *----------------------------------------------------------------
      * EDIT COMMENT LOOP: ANYTHING IS VALID
      *----------------------------------------------------------------
       5361-EDIT-COMMENT-L.

010311*    IF  MIR-AMEX-COMNT-INFO-T (WS-IND) = SPACES
010311*        MOVE RAMEX-AMEX-COMNT-TXT (WS-IND)
010311*                              TO MIR-AMEX-COMNT-INFO-T (WS-IND)
010311*        GO TO 5361-EDIT-COMMENT-L-X
010311*    END-IF.

           IF  MIR-AMEX-COMNT-INFO-T (WS-IND) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-AMEX-COMNT-INFO-T (WS-IND)
557660     END-IF.

           MOVE MIR-AMEX-COMNT-INFO-T (WS-IND)
                                      TO RAMEX-AMEX-COMNT-TXT (WS-IND).

       5361-EDIT-COMMENT-L-X.
           EXIT.

      *----------------------------------------------------------------
      * DATA CROSS EDITS: CROSS EDIT DATA STORED ON THE RECORD
      *----------------------------------------------------------------
       5400-DATA-CROSS-EDITS.

           MOVE 'Y'                   TO WS-VALID-CROSS-EDITS-SW.

           PERFORM  5410-CLIENT-VERIFY
               THRU 5410-CLIENT-VERIFY-X.

       5400-DATA-CROSS-EDITS-X.
557660     EXIT.

      *----------------------------------------------------------------
      * CLIENT VERIFY: CHECK THE COVERAGE AND/OR POLICY TO MAKE SURE
      * THE CLIENT SPECIFIED IS ASSOCIATED WITH THE POLICY
      *----------------------------------------------------------------
       5410-CLIENT-VERIFY.

           IF  RAMEX-CLI-ID = SPACES
               GO TO 5410-CLIENT-VERIFY-X
557660     END-IF.

           MOVE 'N'                   TO WS-SW-CLIENT-VERIFY.
      *
      * CHECK IF CLIENT IS FOUND ON THE COVERAGE
      *
           PERFORM  5411-CHECK-COVERAGE
               THRU 5411-CHECK-COVERAGE-X.
           IF  WS-CLIENT-VERIFY
               GO TO 5410-CLIENT-VERIFY-X
557660     END-IF.
      *
      * CHECK IF CLIENT IS FOUND ON THE POLICY
      *
           PERFORM  5412-CHECK-POLICY
               THRU 5412-CHECK-POLICY-X.
           IF  WS-CLIENT-VERIFY
               GO TO 5410-CLIENT-VERIFY-X
557660     END-IF.
      *
      * CLIENT NOT FOUND ANYWHERE
      *
      ***  MESSAGE (S) 'CLIENT NOT FOUND ON POLICY OR COVERAGE'.
           MOVE 'N'                   TO WS-VALID-CROSS-EDITS-SW.
           MOVE 'NS18700012'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       5410-CLIENT-VERIFY-X.
           EXIT.

      *----------------------------------------------------------------
      * CHECK COVERAGE: CHECK TO SEE IF THE CLIENT IS AN INSURED ON
      * THE SPECIFIED COVERAGE
      *----------------------------------------------------------------
       5411-CHECK-COVERAGE.

           IF  RAMEX-CVG-NUM = SPACES
               GO TO 5411-CHECK-COVERAGE-X
557660     END-IF.

           MOVE SPACES                TO WRL-KEY.
016440*    MOVE 'NEWBUS'              TO WRL-REL-SYS-ID.
016440     MOVE WGLOB-SYS-CTL-ID      TO WRL-REL-SYS-ID.
           MOVE RAMEX-POL-ID          TO WRL-REL-SYS-REF-POL-ID.
           MOVE MIR-CLI-ID            TO WRL-CLI-ID.
           MOVE RAMEX-CVG-NUM         TO WRL-REL-SYS-REF-CVG-NUM.
           MOVE 'I'                   TO WRL-REL-TYP-CD.

           PERFORM  RL-1000-READ
               THRU RL-1000-READ-X.
           IF  WRL-IO-OK
               MOVE 'Y'               TO WS-SW-CLIENT-VERIFY
557660     END-IF.

       5411-CHECK-COVERAGE-X.
           EXIT.

      *----------------------------------------------------------------
      * CHECK POLICY: CHECK TO SEE IF THE CLIENT HAS ANY RELATIONSHIP
      * TO THE POLICY
      *----------------------------------------------------------------
       5412-CHECK-POLICY.

           MOVE SPACES                TO WRL-KEY.
016440*    MOVE 'NEWBUS'              TO WRL-REL-SYS-ID.
016440     MOVE WGLOB-SYS-CTL-ID      TO WRL-REL-SYS-ID.
           MOVE MIR-CLI-ID            TO WRL-CLI-ID.
           MOVE RAMEX-POL-ID          TO WRL-REL-SYS-REF-POL-ID.
           MOVE ZEROES                TO WRL-REL-SYS-REF-CVG-NUM.
           MOVE WRL-KEY               TO WRL-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WRL-ENDBR-REL-TYP-CD.

           PERFORM  RL-1000-BROWSE
               THRU RL-1000-BROWSE-X.
           IF  WRL-IO-EOF
               GO TO 5412-CHECK-POLICY-X
557660     END-IF.

           PERFORM  RL-2000-READ-NEXT
               THRU RL-2000-READ-NEXT-X.

           IF  WRL-IO-OK
               MOVE 'Y'               TO WS-SW-CLIENT-VERIFY
557660     END-IF.

           PERFORM  RL-3000-END-BROWSE
               THRU RL-3000-END-BROWSE-X.

       5412-CHECK-POLICY-X.
           EXIT.

      *----------------------------------------------------------------
      * DELETE PROCESSING:
      *----------------------------------------------------------------
       6000-PROCESS-DELETE.

               PERFORM  6200-PROCESS-DELETE
                   THRU 6200-PROCESS-DELETE-X.

557660 6000-PROCESS-DELETE-X.
           EXIT.

      *----------------------------------------------------------------
      * DELETE PROCESSING:
      * DELETE IS VERIFIED, DELETE THE RECORD.
      *----------------------------------------------------------------
       6200-PROCESS-DELETE.

014221     MOVE MIR-POL-ID-BASE           TO WPOL-POL-ID-BASE.
014221     MOVE MIR-POL-ID-SFX            TO WPOL-POL-ID-SFX.

014221     PERFORM  POL-2000-UPDATE-TWRK-TS
014221         THRU POL-2000-UPDATE-TWRK-TS-X.

014221     IF  WPOL-IO-NOT-FOUND
014221*MSG:  'POLICY NOT ON POLICY FILE'
014221         SET WS-INVALID-INPUT    TO TRUE
014221         MOVE 'XS00000070'       TO WGLOB-MSG-REF-INFO
014221         MOVE WPOL-POL-ID        TO WGLOB-MSG-PARM (01)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6200-PROCESS-DELETE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*     PROCESS NOT COMPLETE
014221         SET WS-INVALID-INPUT    TO  TRUE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'POL'              TO WGLOB-MSG-PARM (01)
014221         MOVE WPOL-KEY           TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6200-PROCESS-DELETE-X
014221     END-IF.

           PERFORM  8000-BUILD-AMEX-KEY
               THRU 8000-BUILD-AMEX-KEY-X.

           PERFORM  AMEX-1000-READ-FOR-UPDATE
               THRU AMEX-1000-READ-FOR-UPDATE-X.

           IF  NOT WAMEX-IO-OK
      ***     MESSAGE (S) "LOST RECORD IN DELETE (@1) - CONTACT SYSTEMS
               MOVE WAMEX-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  POL-3000-UNLOCK
014221             THRU POL-3000-UNLOCK-X
               GO TO 6200-PROCESS-DELETE-X
557660     END-IF.

           PERFORM  AMEX-1000-DELETE
               THRU AMEX-1000-DELETE-X.

014221     PERFORM  POL-2000-REWRITE
014221         THRU POL-2000-REWRITE-X.

      *
      * CANCEL AMENDMENT SETTLE REQUIREMENT
      *
           IF  RAMEX-AMEX-REC-TYP-AMENDMENT
               PERFORM  6210-CANCEL-REQUIREMENT
                   THRU 6210-CANCEL-REQUIREMENT-X
557660     END-IF.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

      ***  MESSAGE (I) "DELETE COMPLETE - CONTINUE".
           MOVE 'XS00000011'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       6200-PROCESS-DELETE-X.
           EXIT.

      *----------------------------------------------------------------
      * CANCEL REQUIREMENT: CANCEL THE OUTSTANDING AMENDMENT
      * REQUIREMENT WHEN THE AMENDMENT IS REMOVED FROM THE POLICY
      *----------------------------------------------------------------
       6210-CANCEL-REQUIREMENT.
      *
      * SET UP INPUT PARAMETERS TO THE REQUIREMENT WRITE WORKER MODULE
      *
           PERFORM  0080-1000-BUILD-PARM-INFO
               THRU 0080-1000-BUILD-PARM-INFO-X.

           SET L0080-POLICY-LEVEL     TO TRUE.
           MOVE RPOL-POL-ID           TO L0080-POL-ID.
           MOVE ZERO                  TO L0080-COVERAGE-NUMBER.
           MOVE 'AMEND'               TO L0080-REQIR-CODE.
           SET L0080-REQIR-STAT-CANCELLED   TO TRUE.

           PERFORM  0080-4000-WRITE
               THRU 0080-4000-WRITE-X.

           IF  L0080-RETRN-OK
               IF  L0080-RSLT-NOT-FOUND
      * MSG: AMENDMENT SETTLE REQUIREMENT NOT CANCELLED
                   MOVE 'NS18700013'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

       6210-CANCEL-REQUIREMENT-X.
           EXIT.

      *----------------------------------------------------------------
      * BUILD AMEX READ KEY.
      *----------------------------------------------------------------
       8000-BUILD-AMEX-KEY.

           MOVE MIR-POL-ID-BASE       TO WAMEX-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WAMEX-POL-ID-SFX.
           MOVE MIR-AMEX-REC-TYP-CD   TO WAMEX-AMEX-REC-TYP-CD.
           MOVE MIR-AMEX-SEQ-NUM      TO WAMEX-AMEX-SEQ-NUM.

       8000-BUILD-AMEX-KEY-X.
           EXIT.

010311*----------------------------------------------------------------
010311 8100-SET-COMMENT-LENGTH.
010311*----------------------------------------------------------------
010311
010311     MOVE RAMEX-AMEX-COMNT-INFO-TXT TO WS-COMMENT-TABLE.
010311
010311     PERFORM
010311     VARYING I FROM 790 BY -1
010311       UNTIL I = ZERO
010311          OR WS-COMMENT-CHAR (I) NOT = SPACE
015543         CONTINUE
010311     END-PERFORM.
010311
010311     MOVE I TO RAMEX-AMEX-COMNT-INFO-LEN.
010311
010311 8100-SET-COMMENT-LENGTH-X.
010311     EXIT.

      *----------------------------------------------------------------
      * BLANK DATA FIELDS: SET EACH DATA (NON-KEY AND NON-CONTROL) FI
      * THE CURRENT TPI SCREEN TO SPACES.
      *----------------------------------------------------------------
       9100-BLANK-DATA-FIELDS.

           IF  WS-BUS-FCN-LIST
               PERFORM  9110-BLANK-SUMMARY-SCREEN
                   THRU 9110-BLANK-SUMMARY-SCREEN-X
           ELSE
               PERFORM  9120-BLANK-DETAIL-SCREEN
                   THRU 9120-BLANK-DETAIL-SCREEN-X
557660     END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.

      *----------------------------------------------------------------
      * BLANK SUMMARY SCREEN: SET EACH DATA FIELD TO SPACES
      *----------------------------------------------------------------
       9110-BLANK-SUMMARY-SCREEN.

           MOVE SPACES                TO MIR-AMEX-REC-TYP-CD-G.
           MOVE SPACES                TO MIR-AMEX-SEQ-NUM-G.
           MOVE SPACES                TO MIR-CVG-NUM-G.
           MOVE SPACES                TO MIR-CLI-ID-G.
           MOVE SPACES                TO MIR-DOC-ID-G.
           MOVE SPACES                TO MIR-AMEX-PRT-IND-G.
           MOVE SPACES                TO MIR-AMEX-REC-RETEN-CD-G.
           MOVE SPACES                TO MIR-AMEX-TRXN-DT-G.

       9110-BLANK-SUMMARY-SCREEN-X.
           EXIT.

      *----------------------------------------------------------------
      * BLANK DETAIL SCREEN: BLANK ALL DATA FIELDS ON DETAIL SCREEN
      *----------------------------------------------------------------
       9120-BLANK-DETAIL-SCREEN.

013578*    MOVE SPACES                TO MIR-AMEX-REC-TYP-CD.
013578*    MOVE SPACES                TO MIR-AMEX-SEQ-NUM.
           MOVE SPACES                TO MIR-CVG-NUM.
           MOVE SPACES                TO MIR-CLI-ID.
           MOVE SPACES                TO MIR-DOC-ID.
           MOVE SPACES                TO MIR-AMEX-PRT-IND.
           MOVE SPACES                TO MIR-AMEX-REC-RETEN-CD.
           MOVE SPACES                TO MIR-AMEX-TRXN-DT.

           MOVE SPACES                TO MIR-AMEX-COMNT-INFO-G.

       9120-BLANK-DETAIL-SCREEN-X.
           EXIT.

      *----------------------------------------------------------------
      * RECORD TO SCREEN:
      *----------------------------------------------------------------
       9200-MOVE-RECORD-TO-SCREEN.

           IF  WS-BUS-FCN-LIST
               PERFORM  9210-MOVE-RECORD-TO-SCREEN-1
                   THRU 9210-MOVE-RECORD-TO-SCREEN-1-X
           ELSE
               PERFORM  9220-MOVE-RECORD-TO-SCREEN-2
                   THRU 9220-MOVE-RECORD-TO-SCREEN-2-X
557660     END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      *----------------------------------------------------------------
      * RECORD TO SCREEN 1:                          INPUT: WS-LINE
      * SHIFT DATA FROM RECORD BUFFER TO THE SCREEN DISPLAY LINE GIVE
      * THE INPUT ITEM WS-LINE.
      *----------------------------------------------------------------
       9210-MOVE-RECORD-TO-SCREEN-1.
      *
      * LOAD SCREEN LINE
      *
           MOVE RAMEX-AMEX-REC-TYP-CD
                                   TO MIR-AMEX-REC-TYP-CD-T (WS-LINE).
           MOVE RAMEX-AMEX-SEQ-NUM    TO MIR-AMEX-SEQ-NUM-T (WS-LINE).
           MOVE RAMEX-CVG-NUM         TO MIR-CVG-NUM-T (WS-LINE).
           MOVE RAMEX-CLI-ID          TO MIR-CLI-ID-T (WS-LINE).
           MOVE RAMEX-DOC-ID          TO MIR-DOC-ID-T (WS-LINE).
           MOVE RAMEX-AMEX-PRT-IND    TO MIR-AMEX-PRT-IND-T (WS-LINE).
           MOVE RAMEX-AMEX-REC-RETEN-CD
                                 TO MIR-AMEX-REC-RETEN-CD-T (WS-LINE).
           MOVE RAMEX-AMEX-TRXN-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-AMEX-TRXN-DT-T (WS-LINE).

       9210-MOVE-RECORD-TO-SCREEN-1-X.
           EXIT.

      *----------------------------------------------------------------
      * MOVE RECORD TO SCREEN 2:
      * SHIFT DATA FROM RECORD BUFFER TO THE SCREEN DISPLAY IN PREPARTN
      * FOR CREATE, MAINTAIN OR DELETE.
      *----------------------------------------------------------------
       9220-MOVE-RECORD-TO-SCREEN-2.

           MOVE RAMEX-AMEX-REC-TYP-CD TO MIR-AMEX-REC-TYP-CD.
           MOVE RAMEX-AMEX-SEQ-NUM    TO MIR-AMEX-SEQ-NUM.
           MOVE RAMEX-CVG-NUM         TO MIR-CVG-NUM.
           MOVE RAMEX-CLI-ID          TO MIR-CLI-ID.
           MOVE RAMEX-DOC-ID          TO MIR-DOC-ID.
           MOVE RAMEX-AMEX-PRT-IND    TO MIR-AMEX-PRT-IND.
           MOVE RAMEX-AMEX-REC-RETEN-CD
                                      TO MIR-AMEX-REC-RETEN-CD.
           MOVE RAMEX-AMEX-TRXN-DT    TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-AMEX-TRXN-DT.

010311*    MOVE RAMEX-AMEX-COMNT-INFO-TXT TO MIR-AMEX-G.
010311     IF  RAMEX-AMEX-COMNT-INFO-LEN = ZEROS
010311         MOVE SPACES             TO MIR-AMEX-COMNT-INFO-G
010311     ELSE
010311         MOVE RAMEX-AMEX-COMNT-INFO-TXT
010311                                (1:RAMEX-AMEX-COMNT-INFO-LEN)
010311                                TO MIR-AMEX-COMNT-INFO-G
010311     END-IF.

       9220-MOVE-RECORD-TO-SCREEN-2-X.
           EXIT.

      *----------------------------------------------------------------
      * UPDATE SCREEN KEYS FROM RECORD:
      * UPDATE THE SCREEN KEYS FROM THE RECORD BUFFER FOR LIST-TYPE
      * INQUIRIES FOR PAGING.
      *----------------------------------------------------------------
       9250-UPDATE-SCREEN-KEYS.

           MOVE RAMEX-AMEX-REC-TYP-CD TO MIR-AMEX-REC-TYP-CD.
           MOVE RAMEX-AMEX-SEQ-NUM    TO MIR-AMEX-SEQ-NUM.

       9250-UPDATE-SCREEN-KEYS-X.
           EXIT.

      *----------------------------------------------------------------
      * SET REFERENCE: MOVE DATA WHICH IDENTIFIES THE OBJECT THAT IS
      * WORKED ON TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING.
      *----------------------------------------------------------------
       9300-SETUP-MSIN-REFERENCE.

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0080-0000-INIT-PARM-INFO
025970         THRU 0080-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2222-0000-INIT-PARM-INFO
025970         THRU 2222-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2437-0000-INIT-PARM-INFO
025970         THRU 2437-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-MAX-DETAIL-LINES    TO TRUE.
025970     SET WS-DEFAULT-MAX-SUMMARY-LINES   TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.
025970     MOVE SPACES                       TO WWKDT-WORK-FIELDS.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      ****************************************************************
      * LINK PROCESSING COPYBOOKS                                    *
      ****************************************************************
      *
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      *
025970 COPY XCPS8090.
       COPY CCPSPGA.
      *
       COPY CCPS5400.
      *
       COPY NCPS0080.
      *
018764*COPY NCCL0080.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY NCPL0080.
      *
018764*COPY CCCL2222.
018764 COPY CCPL2222.
016440 COPY CCPS2222.
      *
018764*COPY NCCL2437.
025970 COPY NCPS2437.
018764 COPY NCPL2437.
      *
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      *
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
025970 COPY XCPS0280.
       COPY XCPL0280.
      *
020874 COPY XCPL0290.
020874 COPY XCPS0290.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
      *
      *
      *  MESSAGE PROCESSING
      *
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
014660*COPY XCPPMEXT.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
      *
       COPY CCPNPOL.
014221 COPY CCPUPOL.
      *
       COPY CCPNCVG.
      *
       COPY NCPAAMEX.
      *
       COPY NCPBAMEX.
      *
       COPY NCPNAMEX.
      *
       COPY NCPUAMEX.
      *
016537*COPY NCPVAMEX.
      *
       COPY NCPXAMEX.
      *
       COPY NCPCAMEX.
      *
023447*COPY NCPBDOCM.
023447 COPY XCPNDOCM.
      *
       COPY CCPBRL.
      *
       COPY CCPNRL.
      *
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM1870                     **
      *****************************************************************
