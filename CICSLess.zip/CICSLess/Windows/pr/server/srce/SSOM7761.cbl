      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM7761.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM7761                                         **
      **  REMARKS:  FUTP - FUND UNIT TYPE CREATE                     **
      **            THIS MODULE CREATES THE FUTP TABLE               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      **                                                             **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
021239**  6.4       FUND UNIT VALUE                                  **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM7761'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-CREATE        VALUE '7761'.

       01  WS-CONSTANT-AREA.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '7760'.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '7760'.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************

       COPY CCWWLOCK.

      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY SCFRFUTP.
       COPY SCFWFUTP.
      /
       COPY SCFRFH.
       COPY SCFWFH.
      /
       COPY CCFREDIT.
       COPY CCFWEDIT.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
       COPY XCWL8090.

      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM7761.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------


           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-CREATE
                        THRU 2000-CREATE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'SSOM7761'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-CREATE.
      *------------

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED       TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  7000-BUILD-KEY
               THRU 7000-BUILD-KEY-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED       TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  FUTP-1000-READ
               THRU FUTP-1000-READ-X.

           IF  WFUTP-IO-OK
      *MSG: 'RECORD @1 ALREADY EXISTS'
               MOVE 'XS00000003'  TO WGLOB-MSG-REF-INFO
               MOVE WFUTP-KEY     TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1             TO WGLOB-MSG-ERROR-SW
               GO TO 2000-CREATE-X
           END-IF.


           PERFORM  FUTP-1000-CREATE
               THRU FUTP-1000-CREATE-X.

           PERFORM  FUTP-1000-WRITE
               THRU FUTP-1000-WRITE-X.

           MOVE WFUTP-FND-ID        TO WFH-FND-ID.
           PERFORM  FH-1000-READ-TWRK-TS
               THRU FH-1000-READ-TWRK-TS-X.


       2000-CREATE-X.
           EXIT.
      /
      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------

           PERFORM  4110-EDIT-FND-ID
               THRU 4110-EDIT-FND-ID-X.

           PERFORM  4120-EDIT-FND-UNIT-TYP
               THRU 4120-EDIT-FND-UNIT-TYP-X.

       2100-VALIDATE-KEYS-X.
           EXIT.


      *-----------------
       4110-EDIT-FND-ID.
      *-----------------

           MOVE MIR-FND-ID          TO WFH-FND-ID.

           PERFORM  FH-1000-READ
               THRU FH-1000-READ-X.

           IF NOT WFH-IO-OK
      *MSG:    INVALID FUND (@1)
               MOVE 'XS00000346'  TO WGLOB-MSG-REF-INFO
               MOVE MIR-FND-ID    TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1             TO WGLOB-MSG-ERROR-SW
           END-IF.

       4110-EDIT-FND-ID-X.
           EXIT.


      *----------------------
       4120-EDIT-FND-UNIT-TYP.
      *----------------------

           MOVE MIR-FND-UNIT-TYP-CD    TO WEDIT-ETBL-VALU-ID.

           PERFORM  UVTP-1000-EDIT
               THRU UVTP-1000-EDIT-X.

           IF  WEDIT-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *MSG: 'FUND UNIT TYPE MUST BE IN EDIT TYPE 'UVTYP''
               MOVE 'SS77610001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                 TO WGLOB-MSG-ERROR-SW
           END-IF.

       4120-EDIT-FND-UNIT-TYP-X.
           EXIT.
      /
      *---------------
       7000-BUILD-KEY.
      *---------------

           MOVE MIR-FND-ID            TO WFUTP-FND-ID.
           MOVE MIR-FND-UNIT-TYP-CD   TO WFUTP-FND-UNIT-TYP-CD.

       7000-BUILD-KEY-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

           MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
025970     SET WS-TWRK-KEY-DEFAULT      TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPEUVTP.
      /
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY FH
                                '$VAR2' BY 'FH'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
       COPY XCPL0260.
025970 COPY XCPS8090.
      /
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY SCPNFH.
       COPY SCPUFH.
       COPY CCPNEDIT.
      /
       COPY SCPAFUTP.
       COPY SCPCFUTP.
       COPY SCPNFUTP.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      *                  END OF PROGRAM SSOM7761                      *
      *****************************************************************
