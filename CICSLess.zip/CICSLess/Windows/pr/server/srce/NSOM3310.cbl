      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM3310.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM3310                                         **
      **  REMARKS:  PROCESS DRIVER FOR RSCL TRANSACTION:  MAINTAIN   **
      **            SUB-COMPANY CLIENT RELATIONSHIP SCREEN.          **
      **            THIS PROGRAM ALLOWS THE USER TO INQUIRE, BROWSE  **
      **            MODIFY, ADD, AND DELETE SUB COMPANY CLIENT       **
      **            RELATIONSHIPS FOR A GIVEN COMPANY/SUBCOMPANY     **
      **            AND LANGUAGE.                                    **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
010418**  5.6       INITIAL SYSTEM DESIGN                            **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       MESSAGE SUPPORT - REMOVAL OF XCPPMEXT            **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /

       ENVIRONMENT DIVISION.

       CONFIGURATION SECTION.
      /
       DATA DIVISION.

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM3310'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  I                            PIC S9(4)  VALUE ZERO COMP.
016548     05  I                            PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12  COMP.
025970*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12
025970*                                     BINARY.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUES '1670' '1671'
                                                   '1672' '1673'
                                                   '1674'.
               88  WS-BUS-FCN-RETRIEVE                 VALUE '1670'.
               88  WS-BUS-FCN-CREATE                   VALUE '1671'.
               88  WS-BUS-FCN-UPDATE                   VALUE '1672'.
               88  WS-BUS-FCN-DELETE                   VALUE '1673'.
               88  WS-BUS-FCN-LIST                     VALUE '1674'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '1670'.
      /
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                 VALUE '1670'.
025970     05  WS-MAX-BROWSE-LINES          PIC S9(4) BINARY.
025970         88  WS-DEFAULT-MAX-BR-LINES             VALUE +12.
      /
016537*COPY XCWEBLCH.
      /
       COPY CCWL2435.
016537*COPY CCWL0620.
028298 COPY CCWL2626.
014221 COPY CCWWLOCK.
014221 COPY XCWL8090.
      /
      ***************************************************************
      * SUB-COMPANY CLIENT RELATIONSHIP WORK AREA
      ***************************************************************
       COPY CCFRSCCL.
       COPY CCFWSCCL.
      /
      ***************************************************************
      * SUB-COMPANY PROFILE WORK AREA
      ***************************************************************
       COPY CCFRSCOM.
       COPY CCFWSCOM.
      /
      ***************************************************************
      * MISC WORK AREA
      ***************************************************************
021930*COPY CCFWCLI.
021930*COPY CCFRCLI.
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
      *******************
       LINKAGE   SECTION.
      *******************

CVMQ71 COPY XCWWDFHQ.
      /
       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY NCWM3310.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      ****************
       0000-MAINLINE.
      ****************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

025970*    SET MIR-RETRN-OK               TO  TRUE.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM EXIT-1000-FINALIZE
              THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
             GOBACK.

      *********************
       2000-PROCESS-REQUEST.
      **********************

           PERFORM 9300-SETUP-MSIN-REFERENCE
              THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      *    MOVE ENTER CODE TO A WORK FIELD, AND DECIDE WHICH SCREEN TO
      *    DISPLAY.
      *
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           IF WGLOB-MSG-ERROR-SW > ZERO
              GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF WS-BUS-FCN-RETRIEVE
           OR WS-BUS-FCN-UPDATE
           OR WS-BUS-FCN-DELETE
              PERFORM 2110-CHECK-SCCL
                 THRU 2110-CHECK-SCCL-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
              GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM 3500-PROCESS-LIST
                       THRU 3500-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM 4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM 5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM 6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

           WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                   MOVE 'XS00000237'         TO  WGLOB-MSG-REF-INFO
                   MOVE MIR-BUS-FCN-ID       TO  WGLOB-MSG-PARM (1)
                   MOVE 'NSOM3310'           TO  WGLOB-MSG-PARM (2)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-INVALD-RQST     TO  TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /

      ****************************************************************
      *   CHECK SCCL:
      *   ENSURE THAT THE SUB-COMPANY CLIENT RELATIONSHIP ROW EXISTS
      ****************************************************************
      *****************
       2110-CHECK-SCCL.
      *****************

           MOVE WGLOB-REF-COMPANY-CODE   TO WSCCL-CO-ID.
           MOVE MIR-SBSDRY-CO-ID         TO WSCCL-SBSDRY-CO-ID.
           MOVE MIR-LANG-CD              TO WSCCL-LANG-CD.

           PERFORM 8100-READ-SCCL-INFO
              THRU 8100-READ-SCCL-INFO-X.

       2110-CHECK-SCCL-X.
           EXIT.
      /
      **********************
       3000-PROCESS-RETRIEVE.
      **********************

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.
      *MSG:'INQUIRE COMPLETED - CONTINUE'
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *************
       3500-PROCESS-LIST.
      *************

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           MOVE LOW-VALUES            TO WSCCL-KEY.
           MOVE HIGH-VALUES           TO WSCCL-ENDBR-KEY.

           MOVE WGLOB-REF-COMPANY-CODE        TO WSCCL-CO-ID.
           MOVE WGLOB-REF-COMPANY-CODE        TO WSCCL-ENDBR-CO-ID.

           IF MIR-SBSDRY-CO-ID GREATER SPACES
              MOVE MIR-SBSDRY-CO-ID   TO WSCCL-SBSDRY-CO-ID
           END-IF.

           IF MIR-LANG-CD GREATER SPACES
              MOVE MIR-LANG-CD        TO WSCCL-LANG-CD
           END-IF.

           PERFORM SCCL-1000-BROWSE
              THRU SCCL-1000-BROWSE-X

           PERFORM SCCL-2000-READ-NEXT
              THRU SCCL-2000-READ-NEXT-X.

           IF NOT WSCCL-IO-OK
           OR WSCCL-IO-EOF
      *MSG:    'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM SCCL-3000-END-BROWSE
                  THRU SCCL-3000-END-BROWSE-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           IF WSCCL-IO-OK
      *MSG:    TO VIEW MORE DATA PRESS ENTER'
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:    'END OF FILE REACHED'
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM SCCL-3000-END-BROWSE
              THRU SCCL-3000-END-BROWSE-X.

       3500-PROCESS-LIST-X.
           EXIT.
      /
      ********************
       4000-PROCESS-CREATE.
      ********************

           PERFORM 9100-BLANK-DATA-FIELDS
              THRU 9100-BLANK-DATA-FIELDS-X.

           MOVE WGLOB-REF-COMPANY-CODE   TO WSCCL-CO-ID.
           MOVE MIR-SBSDRY-CO-ID         TO WSCCL-SBSDRY-CO-ID.
           MOVE MIR-LANG-CD              TO WSCCL-LANG-CD.

           PERFORM SCCL-1000-READ
              THRU SCCL-1000-READ-X.

           IF  WSCCL-IO-OK
               MOVE WSCCL-KEY         TO WGLOB-MSG-PARM (1)
      *MSG:    RECORD (@1) ALREADY EXISTS'
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

      *

      ***  SUB-COMPANY CLIENT RELATIONSHIP KEY EDITS.
      *
           PERFORM 4100-EDIT-KEY-FIELDS
              THRU 4100-EDIT-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

      *
      ***  CREATE RECORD AND SWITCH TO MAINTAIN MODE.
      *
           PERFORM SCCL-1000-CREATE
              THRU SCCL-1000-CREATE-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM SCCL-1000-WRITE
              THRU SCCL-1000-WRITE-X.

014221     PERFORM SCCL-1000-READ-TWRK-TS
014221        THRU SCCL-1000-READ-TWRK-TS-X.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /

      **********************
       4100-EDIT-KEY-FIELDS.
      **********************

      *
      ***  SUB-COMPANY CLIENT RELATIONSHIP KEY EDITS.
      *
           MOVE MIR-SBSDRY-CO-ID      TO WSCOM-SBSDRY-CO-ID.

           PERFORM  SCOM-1000-READ
               THRU SCOM-1000-READ-X.

           IF  WSCOM-IO-OK
               CONTINUE
           ELSE
      *MSG:    SUB-COMPANY MUST BE ON SUB-COMPANY PROFILE
               MOVE 'NS33100001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4100-EDIT-KEY-FIELDS-X
           END-IF.

           MOVE MIR-LANG-CD           TO WGLOB-EDIT-LANG.

           PERFORM LANG-2000-EDIT
              THRU LANG-2000-EDIT-X.

           IF  WEDIT-IO-OK
               CONTINUE
           ELSE
      *MSG:    LANGUAGE MUST BE VALID IN EDIT TYPE 'LANG'
               MOVE 'NS33100002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4100-EDIT-KEY-FIELDS-X.
           EXIT.
      /

      ***************************************************************
      *    MAINTAIN PROCESSING:                                     *
      *        FORCE = 1: USER HAS ENTERED KEY DETAILS              *
      *        FORCE = 2: USER HAS MODIFIED DATA FIELDS             *
      ***************************************************************
      ********************
       5000-PROCESS-UPDATE.
      ********************

014221*    PERFORM SCCL-1000-READ-FOR-UPDATE
014221*       THRU SCCL-1000-READ-FOR-UPDATE-X.

014221     PERFORM SCCL-2000-UPDATE-TWRK-TS
014221        THRU SCCL-2000-UPDATE-TWRK-TS-X.


014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'SCCL'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WSCCL-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF  NOT WSCCL-IO-OK
               SET MIR-RETRN-RQST-FAILED    TO  TRUE
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           PERFORM 5300-EDIT-SCCL-SCREEN-DATA
              THRU 5300-EDIT-SCCL-SCREEN-DATA-X.

           IF  WGLOB-MSG-ERROR-SW = 0
               MOVE MIR-CLI-ID        TO RSCCL-CLI-ID
               PERFORM SCCL-2000-REWRITE
                  THRU SCCL-2000-REWRITE-X
014221         PERFORM SCCL-1000-READ-TWRK-TS
014221            THRU SCCL-1000-READ-TWRK-TS-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW = 0
      *MSG:    MAINTENANCE COMPLETE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.

      /
      ****************************
       5300-EDIT-SCCL-SCREEN-DATA.
      ****************************

           IF  MIR-CLI-ID = SPACES
               MOVE RSCCL-CLI-ID      TO MIR-CLI-ID
           END-IF.

           PERFORM 2435-1000-BUILD-PARM-INFO
              THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID            TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.

           IF NOT L2435-RETRN-OK
               MOVE 'NS33100003'      TO WGLOB-MSG-REF-INFO
      *MSG: CLIENT MUST EXIST ON BIOP
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


       5300-EDIT-SCCL-SCREEN-DATA-X.
           EXIT.
      /
      *****************************************************************
      *   DELETE PROCESSING:                                          *
      *       FORCE = 1: USER HAS ENTERED KEY DETAILS.                *
      *       FORCE = 9: USER HAS VERIFIED DELETE REQUEST.            *
      *****************************************************************
      *************
       6000-PROCESS-DELETE.
      *************

           MOVE WGLOB-REF-COMPANY-CODE                   TO WSCCL-CO-ID.
           MOVE MIR-SBSDRY-CO-ID      TO WSCCL-SBSDRY-CO-ID.
           MOVE MIR-LANG-CD           TO WSCCL-LANG-CD.

014221*    PERFORM SCCL-1000-READ-FOR-UPDATE
014221*       THRU SCCL-1000-READ-FOR-UPDATE-X

014221     PERFORM SCCL-2000-UPDATE-TWRK-TS
014221        THRU SCCL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'SCCL'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WSCCL-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF  WSCCL-IO-OK
               PERFORM SCCL-1000-DELETE
                  THRU SCCL-1000-DELETE-X
               IF WSCCL-IO-OK
      *MSG:       DELETE COMPLETED MESSAGE
                  MOVE 'XS00000011'   TO WGLOB-MSG-REF-INFO
               ELSE
      *MSG:       RECORD (@1) LOST IN DELETE
                  MOVE WSCCL-KEY      TO WGLOB-MSG-PARM (1)
                  MOVE 'XS00000010'   TO WGLOB-MSG-REF-INFO
               END-IF
           ELSE
      *MSG:    RECORD (@1) LOST IN DELETE
               MOVE WSCCL-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM 0260-1000-GENERATE-MESSAGE
              THRU 0260-1000-GENERATE-MESSAGE-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *********************
       8100-READ-SCCL-INFO.
      *********************

           IF  RSCCL-CO-ID     = WSCCL-CO-ID
           AND RSCCL-SBSDRY-CO-ID = WSCCL-SBSDRY-CO-ID
           AND RSCCL-LANG-CD   = WSCCL-LANG-CD
               GO TO 8100-READ-SCCL-INFO-X
           END-IF.

014221*    PERFORM SCCL-1000-READ
014221*       THRU SCCL-1000-READ-X.

014221     IF WS-BUS-FCN-RETRIEVE
014221        PERFORM SCCL-1000-READ-TWRK-TS
014221           THRU SCCL-1000-READ-TWRK-TS-X
014221     ELSE
014221        PERFORM  SCCL-1000-READ
014221            THRU SCCL-1000-READ-X
014221     END-IF.


           IF WSCCL-IO-NOT-FOUND
      *MSG:    "RECORD NOT FOUND"
               MOVE WSCCL-KEY         TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM 9100-BLANK-DATA-FIELDS
                  THRU 9100-BLANK-DATA-FIELDS-X
           END-IF.

       8100-READ-SCCL-INFO-X.
           EXIT.
      /
      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
      ***********************
       9100-BLANK-DATA-FIELDS.
      ***********************

           IF WS-BUS-FCN-LIST
               MOVE SPACES            TO MIR-SBSDRY-CO-ID-G
               MOVE SPACES            TO MIR-LANG-CD-G
               MOVE SPACES            TO MIR-CLI-ID-G
           ELSE
               MOVE SPACES            TO MIR-CLI-ID
           END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      *****************************************************************
      ****************************
       9200-MOVE-RECORD-TO-SCREEN.
      ****************************

           IF WS-BUS-FCN-LIST
               PERFORM 9210-MOVE-SCCL-TO-SCRN-1
                  THRU 9210-MOVE-SCCL-TO-SCRN-1-X
                VARYING I FROM 1 BY 1
                  UNTIL I > WS-MAX-BROWSE-LINES
                     OR WSCCL-IO-EOF

               IF  NOT WSCCL-IO-EOF
                   MOVE RSCCL-CO-ID   TO MIR-CO-ID
                   MOVE RSCCL-SBSDRY-CO-ID
                                      TO MIR-SBSDRY-CO-ID
                   MOVE RSCCL-LANG-CD TO MIR-LANG-CD
               END-IF

               IF  WSCCL-IO-EOF
               AND MIR-SBSDRY-CO-ID-T (1) NOT = SPACES
                   MOVE MIR-SBSDRY-CO-ID-T (1)
                                      TO MIR-SBSDRY-CO-ID
                   MOVE MIR-LANG-CD-T (1)
                                      TO MIR-LANG-CD
               END-IF
           ELSE
               MOVE RSCCL-SBSDRY-CO-ID               TO MIR-SBSDRY-CO-ID
               MOVE RSCCL-LANG-CD     TO MIR-LANG-CD
               MOVE RSCCL-CLI-ID      TO MIR-CLI-ID
           END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      /
      **************************
       9210-MOVE-SCCL-TO-SCRN-1.
      **************************

           MOVE RSCCL-SBSDRY-CO-ID    TO MIR-SBSDRY-CO-ID-T  (I).
           MOVE RSCCL-LANG-CD         TO MIR-LANG-CD-T  (I).
           MOVE RSCCL-CLI-ID          TO MIR-CLI-ID-T  (I).


           PERFORM SCCL-2000-READ-NEXT
              THRU SCCL-2000-READ-NEXT-X.

       9210-MOVE-SCCL-TO-SCRN-1-X.
           EXIT.
      /
      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *       TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
      ***************************
       9300-SETUP-MSIN-REFERENCE.
      ***************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
023514     INITIALIZE                         WS-WORKING-STORAGE.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-MAX-BR-LINES        TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ******************************************************************
      *                      PROCESSING COPYBOOKS                      *
      ******************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY SCCL
014221                         '$VAR2' BY 'SCCL'.
014660*COPY XCPPMEXT.
016537*COPY CCPNCLI.
       COPY CCPELANG.
      ******************************************************************
      *                      LINK COPYBOOKS                            *
      ******************************************************************
018764*COPY XCCL0260.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
016537*COPY CCPL0620.

018764*COPY CCCL2435.
018764 COPY CCPL2435.
025970 COPY XCPS8090.
       COPY CCPS2435.
      /
      ******************************************************************
      *                     FILE HANDLING COPYBOOKS                    *
      ******************************************************************
       COPY CCPNSCOM.
       COPY CCPNEDIT.
       COPY CCPASCCL.
       COPY CCPNSCCL.
       COPY CCPBSCCL.
       COPY CCPCSCCL.
       COPY CCPUSCCL.
       COPY CCPXSCCL.
      /
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      ******************************************************************
      *                  END OF PROGRAM NSOM3310                       *
      ******************************************************************
