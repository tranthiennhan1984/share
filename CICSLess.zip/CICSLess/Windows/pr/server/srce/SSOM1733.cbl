      *
      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM1733.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM1733                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE RETRIEVE FUNCTION     **
      **            FOR THE FA TABLE                                 **
      **                                                             **
      **  DOMAIN :  CV                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016679**  6.0       DESCRIPTION                                      **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020618**  6.4       INITIALIZATION                                   **
020237**  6.4       MATCH FA WORK KEY WITH FA KEY                    **
021311**  6.4       MULTI-PLATFORM SUPPORT                           **
020469**  6.4       MULTI-CURRENCY FUND PROCESSING                   **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023339**  6.5       WORKING STORAGE INITIALIZATION                   **
025388**  6.6       DATABASE CLEANUP                                 **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM1733'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

018764*COPY XCWLPTR.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-RETRIEVE       VALUE '1733'.

       01  WS-WORK-AREAS.
           05  EDIT-ZZ9-9999                  PIC ZZ9.9999.
           05  EDIT-SZZ9-999999              PIC ---9.9(06).
           05  EDIT-999                      PIC 999.
           05  HOLD-EFFDT                PIC X(10).
           05  EFFDT-I                   PIC X(10).
           05  HOLD-TRN                  PIC X(3).
           05  WS-NUM-ERR-SW            PIC X.
               88  NO-NUM-ERR               VALUE 'N'.
               88  NUM-ERR-OCCURRED         VALUE 'Y'.
           05  HOLD-SEQ-X                PIC 9(3).
           05  HOLD-SEQ-NUM              PIC 9(3).
       01  KEY-WORK-AREAS.
           05  WK-SEQ                        PIC 9(3).
           05  WK-NEXT-FUND                  PIC X(5).
           05  WK-FA-HIGH-KEY.
               10  FILLER                    PIC X(14).
               10  WK-FA-HIGH-EFF-DT         PIC 9(7).
020237*        10  WK-FA-HIGH-SEQ-NUM        PIC S9(4).
020237         10  WK-FA-HIGH-SEQ-NUM        PIC S9(4) BINARY.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      *
026057 COPY CCWWIHSD.
       COPY XCWWWKDT.
       COPY XCWEBLCH.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY SCFWFA.
       COPY SCFRFA.
       COPY SCFWFC.
       COPY SCFRFC.
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
       COPY CCWL5400.
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL0290.
021930*COPY CCWL0620.
       COPY XCWL1640.
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM1733.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

021311     PERFORM  9990-INIT-WORKING-STORAGE
021311         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

020618     MOVE HIGH-VALUES TO RFA-REC-INFO.
           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.


      *
      *  VALIDATE / CHECK POLICY ACCESS
      *
           PERFORM  2100-VALIDATE-POLICY
               THRU 2100-VALIDATE-POLICY-X.

           IF  WGLOB-RETURN-ERROR
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 1000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2200-NOW-GET-FUND
               THRU 2200-NOW-GET-FUND-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 1000-PROCESS-REQUEST-X
           END-IF.


           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'SSOM1733'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *-------------
       2000-RETRIEVE.
      *-------------
      *
020469     MOVE RPOL-POL-CRCY-CD       TO MIR-CIA-CRCY-CD.
020469
           MOVE MIR-CIA-EFF-DT        TO HOLD-EFFDT.
           MOVE MIR-CIA-TYP-CD        TO HOLD-TRN.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 3                     TO L0280-LENGTH.
           MOVE MIR-CIA-SEQ-NUM       TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-CIA-SEQ-NUM   TO L0280-INPUT-SIZE.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF L0280-OK
               MOVE L0280-OUTPUT      TO HOLD-SEQ-X
           ELSE
               SET  NUM-ERR-OCCURRED  TO TRUE
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           MOVE HOLD-EFFDT            TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO EFFDT-I
               MOVE HOLD-EFFDT        TO MIR-CIA-EFF-DT
           ELSE
               MOVE WWKDT-ZERO-DT     TO EFFDT-I
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE EFFDT-I               TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  4000-FIND-FA-RECORD
               THRU 4000-FIND-FA-RECORD-X.

020618*    IF  WFA-IO-NOT-FOUND
020618     IF  WGLOB-RETURN-ERROR
      *MSG: RECORD @1 NOT FOUND
               MOVE WFA-KEY
                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           IF WGLOB-RETURN-ERROR
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  4400-PROCESS-TRAN
               THRU 4400-PROCESS-TRAN-X.

           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X.

       2000-RETRIEVE-X.
           EXIT.

      /
      *---------------------
       2100-VALIDATE-POLICY.
      *---------------------

           MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID.
           MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
      *MSG: POLICY NOT IN FILE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 2100-VALIDATE-POLICY-X
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
           SET  L5400-STAT-MSG-NOT-REQD TO TRUE.
           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-CNFD-ACCS-RESTRICTED
           OR  NOT L5400-RETRN-OK
               SET WGLOB-RETURN-ERROR   TO TRUE
           END-IF.

       2100-VALIDATE-POLICY-X.
           EXIT.
      /
      *------------------
       2200-NOW-GET-FUND.
      *------------------

           MOVE RPOL-POL-ID           TO WFC-POL-ID.
023339*    MOVE MIR-CVG-NUM           TO WFC-CVG-NUM.
023339*
023339     SET L0280-SIGN-NOT-PERMITTED   TO TRUE.
023339     SET L0280-SPACES-PERMITTED     TO TRUE.
023339     MOVE ZERO                      TO L0280-PRECISION.
023339     MOVE LENGTH OF MIR-CVG-NUM     TO L0280-LENGTH.
023339     MOVE LENGTH OF MIR-CVG-NUM     TO L0280-INPUT-SIZE.
023339     MOVE MIR-CVG-NUM               TO L0280-INPUT-DATA.
023339
023339     PERFORM  0280-1000-NUMERIC-EDIT
023339         THRU 0280-1000-NUMERIC-EDIT-X.
023339
023339     IF  L0280-OK
023339         MOVE L0280-OUTPUT-V00      TO WFC-CVG-NUM-N
023339     ELSE
023339         MOVE ZERO                  TO WFC-CVG-NUM-N
023339     END-IF.
023339
           PERFORM  FC-1000-READ
               THRU FC-1000-READ-X.

           IF NOT WFC-IO-OK
               MOVE 'SS17330001'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2200-NOW-GET-FUND-X.
           EXIT.
      /
      *-------------------------
       4000-FIND-FA-RECORD.
      *-------------------------

           IF EFFDT-I = WWKDT-ZERO-DT
               MOVE 'SS17330003'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-FIND-FA-RECORD-X
           END-IF.

           MOVE EFFDT-I                TO L1660-INTERNAL-DATE.
           PERFORM 1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE    TO WFA-CIA-IDT-NUM-N.

           MOVE RFC-POL-ID             TO WFA-POL-ID.
           MOVE RFC-CVG-NUM-N          TO WFA-CVG-NUM-N.
           MOVE RFC-INV-CVG-STAT-CD    TO MIR-CFN-STAT-CD.

           IF WFA-COMPANY-REQUIRED
               MOVE WGLOB-COMPANY-CODE TO WFA-CO-ID
           ELSE
               MOVE SPACES             TO WFA-CO-ID
           END-IF.

           COMPUTE WK-SEQ = 1000 - HOLD-SEQ-X.
           MOVE WK-SEQ                TO WFA-CIA-SEQ-NUM.
           MOVE WFA-KEY               TO WK-FA-HIGH-KEY.
           MOVE +999                  TO WK-FA-HIGH-SEQ-NUM.
           MOVE WK-FA-HIGH-KEY        TO WFA-ENDBR-KEY.

           IF MIR-CIA-TYP-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CIA-TYP-CD
           END-IF.

           PERFORM  FA-1000-BROWSE
               THRU FA-1000-BROWSE-X.

           IF WFA-IO-EOF
              MOVE 'SS17330007'  TO WGLOB-MSG-REF-INFO
              PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
020618        SET WGLOB-RETURN-ERROR   TO TRUE
              GO TO 4000-FIND-FA-RECORD-X
           END-IF.

020618     MOVE HIGH-VALUE            TO RFA-CIA-TYP-CD.
           PERFORM  4010-FA-READ-RECORD-LOOP
               THRU 4010-FA-READ-RECORD-LOOP-X
                  UNTIL NOT WFA-IO-OK
                     OR MIR-CIA-TYP-CD = RFA-CIA-TYP-CD.

           PERFORM  FA-3000-END-BROWSE
               THRU FA-3000-END-BROWSE-X.

       4000-FIND-FA-RECORD-X.
           EXIT.
      /
      *-------------------------
       4010-FA-READ-RECORD-LOOP.
      *-------------------------

           PERFORM  FA-2000-READ-NEXT
               THRU FA-2000-READ-NEXT-X.

           IF MIR-CIA-TYP-CD = SPACES
              MOVE RFA-CIA-TYP-CD      TO MIR-CIA-TYP-CD
           END-IF.

           IF NOT WFA-IO-OK
              MOVE 'SS17330007'  TO WGLOB-MSG-REF-INFO
              PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              SET WGLOB-RETURN-ERROR   TO TRUE
              GO TO 4010-FA-READ-RECORD-LOOP-X
           END-IF.

       4010-FA-READ-RECORD-LOOP-X.
           EXIT.
      /
      *--------------------
       4400-PROCESS-TRAN.
      *--------------------

           IF WFA-IO-EOF
               MOVE 'SS17330004'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4400-PROCESS-TRAN-X
           END-IF.
           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 4400-PROCESS-TRAN-X
           END-IF.

           MOVE RFA-CIA-PRCES-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CIA-PRCES-DT.
           MOVE RFA-CIA-REVRS-PRCES-DT           TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CIA-REVRS-PRCES-DT.

020874*    COMPUTE L0290-INPUT-NUMBER = RFA-CVG-GUAR-VALU-AMT * 100.
020874     MOVE RFA-CVG-GUAR-VALU-AMT TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-GUAR-VALU-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CVG-GUAR-VALU-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RFA-CIA-CLI-TRXN-AMT * 100.
020874     MOVE RFA-CIA-CLI-TRXN-AMT  TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CIA-CLI-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CIA-CLI-TRXN-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RFA-CIA-LOAD-AMT * 100.
020874     MOVE RFA-CIA-LOAD-AMT      TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CIA-LOAD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RFA-CIA-FND-TRXN-AMT * 100.
020874     MOVE RFA-CIA-FND-TRXN-AMT  TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CIA-FND-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CIA-FND-TRXN-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RFA-CIA-SHRT-AMT * 100.
020874     MOVE RFA-CIA-SHRT-AMT      TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CIA-SHRT-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CIA-SHRT-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RFA-CVG-SHRT-LTD-AMT * 100.
020874     MOVE RFA-CVG-SHRT-LTD-AMT  TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-SHRT-LTD-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CVG-SHRT-LTD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RFA-CVG-PMT-LTD-AMT * 100.
020874     MOVE RFA-CVG-PMT-LTD-AMT   TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-PMT-LTD-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CVG-PMT-LTD-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RFA-CVG-SURR-LTD-AMT * 100.
020874     MOVE RFA-CVG-SURR-LTD-AMT  TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-SURR-LTD-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CVG-SURR-LTD-AMT.


       4400-PROCESS-TRAN-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------
      *

           MOVE LOW-VALUES            TO WFA-KEY.
023339*    MOVE MIR-CVG-NUM           TO WFA-CVG-NUM.
023339     MOVE WFC-CVG-NUM           TO WFA-CVG-NUM.
           MOVE MIR-POL-ID-BASE       TO WFA-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WFA-POL-ID-SFX.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------
       9000-BLANK-DATA-FIELDS.
      *-----------------

           MOVE SPACES                 TO MIR-CFN-STAT-CD.
           MOVE SPACES                 TO MIR-CIA-ALLOC-CD.
           MOVE SPACES                 TO MIR-CIA-CLI-TRXN-AMT.
           MOVE SPACES                 TO MIR-CIA-FND-TRXN-AMT.
           MOVE SPACES                 TO MIR-CIA-LOAD-FORCE-IND.
           MOVE SPACES                 TO MIR-CIA-LOAD-AMT.
           MOVE SPACES                 TO MIR-CIA-PRCES-DT.
           MOVE SPACES                 TO MIR-CIA-REASN-CD.
025388*    MOVE SPACES                 TO MIR-CIA-REG-FND-SRC-CD.
025388     SET  MIR-CIA-REG-FND-REG-CONTRB  TO TRUE.
           MOVE SPACES                 TO MIR-CIA-REVRS-PRCES-DT.
           MOVE SPACES                 TO MIR-CIA-REVRS-REASN-CD.
           MOVE SPACES                 TO MIR-CIA-SHRT-AMT.
           MOVE SPACES                 TO MIR-CVG-SHRT-LTD-AMT.
           MOVE SPACES                 TO MIR-CIA-SRC-DEST-CD.
           MOVE SPACES                 TO MIR-CIA-UNIT-STAT-CD.
           MOVE SPACES                 TO MIR-CVG-PMT-LTD-AMT.
           MOVE SPACES                 TO MIR-GUAR-VALU-ESTB-IND.
           MOVE SPACES                 TO MIR-CVG-GUAR-VALU-AMT.
           MOVE SPACES                 TO MIR-PEND-DPOS-INT-PCT.
           MOVE SPACES                 TO MIR-CVG-SURR-LTD-AMT.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9200-MOVE-RECORD-TO-MIR.
      *--------------------------

020874*    COMPUTE HOLD-SEQ-NUM = 1000 - RFA-CIA-SEQ-NUM.
020874*    MOVE HOLD-SEQ-NUM           TO MIR-CIA-SEQ-NUM.
020874     COMPUTE L0290-INPUT-V00  =  1000 - RFA-CIA-SEQ-NUM.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CIA-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA   TO MIR-CIA-SEQ-NUM.
           MOVE RFA-CIA-UNIT-STAT-CD   TO MIR-CIA-UNIT-STAT-CD.
           IF RFA-CIA-TYP-CD = LOW-VALUES
               MOVE SPACES             TO MIR-CIA-TYP-CD
           ELSE
               MOVE RFA-CIA-TYP-CD     TO MIR-CIA-TYP-CD
           END-IF.
           MOVE RFA-CIA-REASN-CD       TO MIR-CIA-REASN-CD.
           MOVE RFA-CIA-REVRS-REASN-CD TO MIR-CIA-REVRS-REASN-CD.

           MOVE RFA-CIA-SRC-DEST-CD    TO MIR-CIA-SRC-DEST-CD.
           MOVE RFA-CIA-REG-FND-SRC-CD TO MIR-CIA-REG-FND-SRC-CD.
           MOVE RFA-CIA-ALLOC-CD       TO MIR-CIA-ALLOC-CD.
020874*    MOVE RFA-PEND-DPOS-INT-PCT  TO EDIT-SZZ9-999999.
020874*    MOVE EDIT-SZZ9-999999       TO MIR-PEND-DPOS-INT-PCT.
020874     MOVE RFA-PEND-DPOS-INT-PCT TO L0290-INPUT-V06.
020874     MOVE 6                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-PEND-DPOS-INT-PCT
020874                                TO L0290-MAX-OUT-LEN.
020874     SET L0290-SIGN-DISPLAY     TO TRUE.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-PEND-DPOS-INT-PCT.
           MOVE RFA-GUAR-VALU-ESTB-IND TO MIR-GUAR-VALU-ESTB-IND.
           MOVE RFA-CIA-LOAD-FORCE-IND TO MIR-CIA-LOAD-FORCE-IND.


       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           SET  WGLOB-REF-POLICY       TO TRUE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                    TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE        TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX         TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      /
021311*--------------------------
021311 9990-INIT-WORKING-STORAGE.
021311*--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
021311
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WS-WORK-AREAS.
025970     INITIALIZE KEY-WORK-AREAS.
025970     MOVE SPACE                      TO WWKDT-WORK-FIELDS.
025970
021311 9990-INIT-WORKING-STORAGE-X.
021311     EXIT.
021311/
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
026057 COPY CCPPIHSD.
       COPY XCPPEXIT.
       COPY XCPPINIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************

025970 COPY XCPS1670.
       COPY CCPS5400.
018764*COPY CCCL5400.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL5400.
021930*COPY CCPL0620.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL0290.
       COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY SCPBFA.
       COPY CCPNPOL.
021930*COPY SCPNFA.
       COPY SCPNFC.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM SSOM1733 **
      *****************************************************************
