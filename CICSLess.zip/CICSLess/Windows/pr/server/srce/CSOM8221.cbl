      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM8221.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM8221                                         **
      **  REMARKS:  SURRENDER BY AMOUNT                              **
      **                                                             **
      **            THIS MODULE IS USED TO PROCESS SURRENDERS FOR    **
      **            CASH VALUE ANNUITIES AND SEGREGATED FUNDS WHEN   **
      **            SURRENDER AMOUNT IS SPECIFIED.  THESE TRANSACT-  **
      **            IONS ARE PROCESSED AT THE POLICY LEVEL.          **
      **                                                             **
      **            THIS PROCESS DRIVER HANDLE BOTH CURRENT AND      **
      **            FUTURE DATED SURRENDER.                          **
      **                                                             **
      **  DOMAIN :  CV                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020478**  6.6       FUTURE DATED TRANSACTION                         **
028262**  6.7       GLOBAL MESSAGE ERROR INDICATOR                   **
028788**  6.7       EXTERNAL AGENCY INTEGRATION - POLICY EVENTS      **
031034**  7.0       TAX COMPONENTIZATION                             **
031036**  7.0       EXEMPT STATUS MANAGEMENT                         **
031065**  7.0       FUND VALUE DISPLAY NO SIGN FOR NEGATIVE AMOUNT   **
029060**  7.1       MEC TWO YEAR LOOK BACK ON DECREASES PROVISION    **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *************************
       ENVIRONMENT DIVISION.
      *************************
       DATA DIVISION.
       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM8221'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

       COPY XCWEBLCH.

       COPY CCWWINDX.

       COPY CCWWLOCK.

       COPY XCWWWKDT.

       01  WS-WORK-FIELDS.
           05  WS-POL-CRCY-CD                PIC X(02)  VALUE SPACES.
           05  WS-SWITCHES.
               10  WS-REDO-SW                PIC X(01).
                   88  WS-REDO-OK                       VALUE 'Y'.
                   88  WS-REDO-NOT-OK                   VALUE 'N'.
           05  WS-EDIT-CHECKS.
               10  WS-BUS-FCN-ID             PIC X(04).
                   88  WS-BUS-FCN-ID-VALID              VALUE '1142'
                                                              '8221'.
                   88  WS-BUS-FCN-SURR                  VALUE '1142'.
                   88  WS-BUS-FCN-FUTURE-DATED-SURR     VALUE '8221'.
           05  WS-BASIC-EDIT-SW              PIC X(01).
               88  WS-BASIC-EDIT-OK                     VALUE 'Y'.
               88  WS-BASIC-EDIT-FAILED                 VALUE 'N'.
           05  WS-POL-ID.
               10  WS-POLNO                  PIC X(09).
               10  WS-SUFF                   PIC X(01).
           05  WS-EFF-DT                     PIC X(10).
           05  WS-WORK-AMT                   PIC S9(13)V99 COMP-3.
           05  WS-WORK-PCT                   PIC S9(3)V9(4) COMP-3.
           05  WS-CVG-NUM                    PIC S9(04) BINARY.

       COPY CCWL0201.

       COPY CCWL0289.

       COPY CCWL0620.

       COPY CCWL2430.

       COPY CCWL2626.

       COPY CCWL4750.

       COPY CCWL4780.

       COPY CCWL5400.

       COPY CCWL8231.

       COPY CCWLPGA.

031034*COPY CCWLPGAL.

       COPY FCWL8140.

       COPY FCWL8180.

       COPY FCWL8200.

       COPY FCWLFUND.

036742*COPY XCWL0035.

       COPY XCWL0280.

       COPY XCWL0290.

       COPY XCWL1640.

       COPY XCWL8090.

       COPY XCWL8640.

       COPY XCWLDTLK.

       COPY CCFWPOL.
       COPY CCFRPOL.
       COPY CCFHPOL.

           EXEC SQL INCLUDE CCFWPORQ END-EXEC.
           EXEC SQL INCLUDE CCFRPORQ END-EXEC.

       COPY CCFWCVG.
       COPY CCFRCVG.
       COPY CCWWCVGS.

       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM8221.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           MOVE  MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.

           EVALUATE  TRUE

              WHEN  WS-BUS-FCN-SURR
              WHEN  WS-BUS-FCN-FUTURE-DATED-SURR
                    PERFORM  2000-PROCESS-REQUEST
                        THRU 2000-PROCESS-REQUEST-X

              WHEN  OTHER
                     SET  MIR-RETRN-INVALD-RQST
                                             TO TRUE
                     MOVE MIR-RETRN-CD       TO WGLOB-ERR-RETRN-CD
                     PERFORM  0030-5000-LOGIC-ERROR
                         THRU 0030-5000-LOGIC-ERROR-X

           END-EVALUATE.

           IF  WS-BASIC-EDIT-FAILED
           OR  WS-BUS-FCN-SURR
               MOVE 'N'                  TO MIR-DV-ENBL-FTL-OVRID-IND
           ELSE
               IF  WGLOB-MSG-ERROR-SW > ZERO
                   MOVE 'Y'              TO MIR-DV-ENBL-FTL-OVRID-IND
028262             SET MIR-RETRN-ERROR-OVRID
028262                                   TO TRUE
               ELSE
                   MOVE 'N'              TO MIR-DV-ENBL-FTL-OVRID-IND
               END-IF
           END-IF.

           PERFORM  FPCK-1000-CHECK-POLICY
               THRU FPCK-1000-CHECK-POLICY-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.

      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-POL-ID-BASE              TO WS-POLNO.
           MOVE MIR-POL-ID-SFX               TO WS-SUFF.
           MOVE WS-POL-ID                    TO WPOL-POL-ID.

           IF  NOT MIR-DV-PRCES-STATE-CD = '3'
               PERFORM  POL-1000-READ-TWRK-TS
                   THRU POL-1000-READ-TWRK-TS-X
           ELSE
               PERFORM  POL-2000-UPDATE-TWRK-TS
                   THRU POL-2000-UPDATE-TWRK-TS-X
               IF  MIR-RETRN-TS-MISMATCH
      * MSG: TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
      *      NOT COMPLETE
                   SET WS-BASIC-EDIT-FAILED  TO TRUE
                   MOVE 'XS00000303'         TO WGLOB-MSG-REF-INFO
                   MOVE 'POL'                TO WGLOB-MSG-PARM (01)
                   MOVE WPOL-KEY             TO WGLOB-MSG-PARM (02)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                    GO TO 2000-PROCESS-REQUEST-X
               ELSE
                    IF  WPOL-IO-OK
                        PERFORM  POL-3000-UNLOCK
                            THRU POL-3000-UNLOCK-X
                    END-IF
               END-IF
           END-IF.

           IF  NOT WPOL-IO-OK
               SET WS-BASIC-EDIT-FAILED      TO TRUE
      * MSG:  POLICY NOT IN FILE
               MOVE 'CS00000019'             TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM 5400-1000-BUILD-PARM-INFO
              THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-CRCY-MSG-REQD           TO TRUE.

           PERFORM 5400-1000-POL-CHK
              THRU 5400-1000-POL-CHK-X.

           IF L5400-CNFD-ACCS-RESTRICTED
           OR L5400-CRCY-ACCS-RESTRICTED
           OR L5400-BRCH-ACCS-RESTRICTED
           OR L5400-STAT-ACCS-RESTRICTED
               SET WS-BASIC-EDIT-FAILED      TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM CVGS-1000-LOAD-CVGS-ARRAY
              THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF  NOT RPOL-POL-STAT-IN-FORCE
               SET WS-BASIC-EDIT-FAILED      TO TRUE
      *MSG: POLICY MUST BE IN FORCE TO PROCESS
               MOVE 'XS00000238'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           MOVE RPOL-POL-ID                  TO L2430-POL-ID.
           MOVE ZERO                         TO I.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF L2430-RETRN-OK
               INITIALIZE                    L0620-INPUT-PARM-INFO
               IF L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM
                                             TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM
                                             TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM
                                             TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM     TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD         TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME        TO MIR-DV-OWN-CLI-NM
           ELSE
               SET WS-BASIC-EDIT-FAILED      TO TRUE
               MOVE SPACES                   TO MIR-DV-OWN-CLI-NM
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           MOVE MIR-CIA-EFF-DT               TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X

           IF  L1640-NOT-VALID
               SET WS-BASIC-EDIT-FAILED      TO TRUE
      *MSG: INVALID EFFECTIVE DATE - REENTER
               MOVE 'CS82210001'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-PROCESS-REQUEST-X
           ELSE
               MOVE L1640-INTERNAL-DATE      TO WS-EFF-DT
           END-IF.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

031034*    PERFORM  PGAL-0000-INIT-PARM-INFO
031034*        THRU PGAL-0000-INIT-PARM-INFO-X.

           PERFORM  2200-INITIALIZE-WORK-AREAS
               THRU 2200-INITIALIZE-WORK-AREAS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  3000-PROCESS-SURRENDER
               THRU 3000-PROCESS-SURRENDER-X.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *---------------------------
       2200-INITIALIZE-WORK-AREAS.
      *---------------------------

           MOVE RPOL-POL-CRCY-CD             TO WS-POL-CRCY-CD.

           PERFORM 8200-1000-BUILD-PARM-INFO
              THRU 8200-1000-BUILD-PARM-INFO-X.
           MOVE WS-EFF-DT                    TO L8200-EFF-DT.
031036     SET L8200-CDI-TYP-PART-SUR        TO TRUE.

           PERFORM 8200-1000-INIT-INSTR
              THRU 8200-1000-INIT-INSTR-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET WS-BASIC-EDIT-FAILED      TO TRUE
               GO TO 2200-INITIALIZE-WORK-AREAS-X
           END-IF.

           PERFORM  8180-1000-BUILD-PARM-INFO
               THRU 8180-1000-BUILD-PARM-INFO-X.
           MOVE WS-EFF-DT                    TO L8180-EFF-DT.
           PERFORM  8180-1000-CALC-FUND-VAL
               THRU 8180-1000-CALC-FUND-VAL-X.

           SET LFUND-ACTV-PARTIAL-SURRENDER  TO TRUE.

       2200-INITIALIZE-WORK-AREAS-X.
           EXIT.

      *-----------------------
       3000-PROCESS-SURRENDER.
      *-----------------------

           EVALUATE TRUE
               WHEN MIR-DV-PRCES-STATE-CD = '1'
                   PERFORM 3100-PROCESS-SURRENDER-1
                      THRU 3100-PROCESS-SURRENDER-1-X
               WHEN MIR-DV-PRCES-STATE-CD = '2'
                   PERFORM 3200-PROCESS-SURRENDER-2
                      THRU 3200-PROCESS-SURRENDER-2-X
               WHEN MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM 3400-PROCESS-SURRENDER-3
                      THRU 3400-PROCESS-SURRENDER-3-X
           END-EVALUATE.

       3000-PROCESS-SURRENDER-X.
           EXIT.

      *-------------------------
       3100-PROCESS-SURRENDER-1.
      *-------------------------

           PERFORM  8231-1000-BUILD-PARM-INFO
               THRU 8231-1000-BUILD-PARM-INFO-X.

           PERFORM  5000-FILL-INPUT-DATA-1
               THRU 5000-FILL-INPUT-DATA-1-X.

           IF  WS-BUS-FCN-SURR
               PERFORM  8231-1000-EDIT-CURR-SURR-1
                   THRU 8231-1000-EDIT-CURR-SURR-1-X
           ELSE
               PERFORM  8231-2000-EDIT-FUTURE-SURR-1
                   THRU 8231-2000-EDIT-FUTURE-SURR-1-X
           END-IF.

           IF  L8231-RETRN-EDIT-ERROR
               SET WS-BASIC-EDIT-FAILED   TO TRUE
           END-IF.

           IF  NOT L8231-RETRN-OK
               GO TO 3100-PROCESS-SURRENDER-1-X
           END-IF.

           PERFORM  6000-DISPLAY-SURR-COMMON
               THRU 6000-DISPLAY-SURR-COMMON-X.

           PERFORM  6200-DISPLAY-SURR-FUND
               THRU 6200-DISPLAY-SURR-FUND-X
               VARYING JJ FROM 1 BY 1
                 UNTIL JJ > LFUND-FND-CTR.

           IF  WS-BUS-FCN-FUTURE-DATED-SURR
      *MSG: VALUES SHOWN ARE CALCULATED AS OF THE CURRENT PROCESSING
      *     DATE
               MOVE 'CS82210001'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3100-PROCESS-SURRENDER-1-X.
           EXIT.

      *-------------------------
       3200-PROCESS-SURRENDER-2.
      *-------------------------

           PERFORM  8231-1000-BUILD-PARM-INFO
               THRU 8231-1000-BUILD-PARM-INFO-X.

           IF  WS-BUS-FCN-FUTURE-DATED-SURR
           AND MIR-DV-FTL-MSG-OVRID-IND = 'Y'
               SET L8231-FUTURE-OVERRIDE     TO TRUE

               PERFORM  3250-OVERRIDE-MIR
                   THRU 3250-OVERRIDE-MIR-X

           END-IF.

           PERFORM  5200-FILL-INPUT-FUND-DATA
               THRU 5200-FILL-INPUT-FUND-DATA-X.

           IF  WS-BUS-FCN-SURR
               PERFORM  8231-3000-EDIT-CURR-SURR-2
                   THRU 8231-3000-EDIT-CURR-SURR-2-X
           ELSE
               PERFORM  8231-4000-EDIT-FUTURE-SURR-2
                   THRU 8231-4000-EDIT-FUTURE-SURR-2-X
           END-IF.

           IF  L8231-RETRN-EDIT-ERROR
               SET WS-BASIC-EDIT-FAILED   TO TRUE
           ELSE
               IF  L8231-RETRN-ERROR
                   GO TO 3200-PROCESS-SURRENDER-2-X
               END-IF
           END-IF.

           IF  NOT WS-BUS-FCN-SURR
      *MSG: YOU ARE ABOUT TO SCHEDULE A FUTURE DATED WITHDRAWAL REQUEST
               MOVE 'CS82210002'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

      *MSG: ANY FINANCIAL ACTIVITIES THAT OCCUR PRIOR TO THE FUTURE
      *     DATE MAY AFFECT THE PROCESSING OF THE FUTURE DATED ACTIVITY
               MOVE 'CS82210003'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

      *MSG: WITHDRAWAL CHARGES MAY APPLY.  CHARGES WILL BE CALCULATED
      *     AT THE TIME THE FUTURE DATED ACTIVITY IS PROCESSED
               MOVE 'CS82210004'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  WS-BUS-FCN-FUTURE-DATED-SURR
           AND MIR-DV-FTL-MSG-OVRID-IND = 'Y'
               GO TO 3200-PROCESS-SURRENDER-2-X
           END-IF.

           PERFORM  6000-DISPLAY-SURR-COMMON
               THRU 6000-DISPLAY-SURR-COMMON-X.

           PERFORM  6200-DISPLAY-SURR-FUND
               THRU 6200-DISPLAY-SURR-FUND-X
               VARYING JJ FROM +1 BY +1
                 UNTIL JJ > LFUND-FND-CTR.

           PERFORM  6400-DISPLAY-TAX-INFO
               THRU 6400-DISPLAY-TAX-INFO-X.

           IF  WS-BUS-FCN-FUTURE-DATED-SURR
      *MSG: VALUES SHOWN ARE CALCULATED AS OF THE CURRENT PROCESSING
      *     DATE
               MOVE 'CS82210001'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3200-PROCESS-SURRENDER-2-X.
           EXIT.

      *-------------------
       3250-OVERRIDE-MIR.
      *-------------------

           MOVE ZERO                     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CIA-LOAD-AMT.

029060*    IF  MIR-FED-TAXWH-CALC-CD = 'C'
029060*    OR  MIR-FED-TAXWH-CALC-CD = 'B'
029060
029060     IF  MIR-FTAXWH-RQST-CD = 'C'
029060     OR  MIR-FTAXWH-RQST-CD = 'B'
               MOVE ZERO                 TO L0290-INPUT-V02
               MOVE 2                    TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-FED-TAXWH-RQST-AMT
029060*                                  TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-FTAXWH-RQST-AMT
029060                                   TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA    TO MIR-FED-TAXWH-RQST-AMT
029060         MOVE L0290-OUTPUT-DATA    TO MIR-FTAXWH-RQST-AMT

               MOVE ZERO                 TO L0290-INPUT-V02
               MOVE 4                    TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-FED-TAXWH-RQST-PCT
029060*                                  TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-FTAXWH-RQST-PCT
029060                                   TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA    TO MIR-FED-TAXWH-RQST-PCT
029060         MOVE L0290-OUTPUT-DATA    TO MIR-FTAXWH-RQST-PCT
           END-IF.

029060*    IF  MIR-LTAXWH-CALC-CD = 'C'
029060*    OR  MIR-LTAXWH-CALC-CD = 'B'
029060
029060     IF  MIR-LTAXWH-RQST-CD = 'C'
029060     OR  MIR-LTAXWH-RQST-CD = 'B'
               MOVE ZERO                 TO L0290-INPUT-V02
               MOVE 2                    TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060*                                  TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
029060                                   TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA    TO MIR-LTAXWH-FLAT-AMT
029060         MOVE L0290-OUTPUT-DATA    TO MIR-LTAXWH-RQST-AMT

               MOVE ZERO                 TO L0290-INPUT-V02
               MOVE 4                    TO L0290-PRECISION
029060*        MOVE LENGTH OF MIR-LTAXWH-PCT
029060*                                  TO L0290-MAX-OUT-LEN
029060         MOVE LENGTH OF MIR-LTAXWH-RQST-PCT
029060                                   TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
029060*        MOVE L0290-OUTPUT-DATA    TO MIR-LTAXWH-PCT
029060         MOVE L0290-OUTPUT-DATA    TO MIR-LTAXWH-RQST-PCT
           END-IF.

           MOVE ZERO                     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-POL-TAX-ACB-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-TAX-ACB-AMT.

           MOVE ZERO                     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-GRS-DSTRB-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-GRS-DSTRB-AMT.

           MOVE ZERO                     TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-TAXBL-GRS-DSTRB-AMT
                                         TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-TAXBL-GRS-DSTRB-AMT.


      *MSG: CHARGES, TAX AND DISTRIBUTION AMOUNTS CANNOT BE CALCULATED
      *     DUE TO FUTURE DATING
           MOVE 'CS82210005'             TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3250-OVERRIDE-MIR-X.
           EXIT.

      *-------------------------
       3400-PROCESS-SURRENDER-3.
      *-------------------------

           PERFORM  8231-1000-BUILD-PARM-INFO
               THRU 8231-1000-BUILD-PARM-INFO-X.

           PERFORM  5200-FILL-INPUT-FUND-DATA
               THRU 5200-FILL-INPUT-FUND-DATA-X.

           IF  WS-BUS-FCN-SURR
               PERFORM  3420-PROCESS-CURR-SURR-3
                   THRU 3420-PROCESS-CURR-SURR-3-X
           ELSE
               PERFORM  3440-PROCESS-FUTURE-SURR-3
                   THRU 3440-PROCESS-FUTURE-SURR-3-X
           END-IF.

       3400-PROCESS-SURRENDER-3-X.
           EXIT.

      *-------------------------
       3420-PROCESS-CURR-SURR-3.
      *-------------------------

           PERFORM  8231-5000-EDIT-CURR-SURR-3
               THRU 8231-5000-EDIT-CURR-SURR-3-X.

           IF  NOT L8231-RETRN-OK
      *MSG: INCOMPETE TRANSACTION
               MOVE 'CS82210006'              TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3420-PROCESS-CURR-SURR-3-X
           END-IF.

           PERFORM  3460-AUTO-REDO
               THRU 3460-AUTO-REDO-X.

           IF  WS-REDO-NOT-OK
               GO TO 3420-PROCESS-CURR-SURR-3-X
           END-IF.

           PERFORM  8600-INVOKE-UNDO
               THRU 8600-INVOKE-UNDO-X.

           IF  NOT WGLOB-GOOD-RETURN
               GO TO 3420-PROCESS-CURR-SURR-3-X
           END-IF.

031034*    PERFORM  PGAL-0000-INIT-PARM-INFO
031034*        THRU PGAL-0000-INIT-PARM-INFO-X.

           PERFORM  3422-BUILD-8140-LINKAGE
               THRU 3422-BUILD-8140-LINKAGE-X.

           PERFORM  3424-ELIMINATE-UNUSED-FUNDS
               THRU 3424-ELIMINATE-UNUSED-FUNDS-X.

028788     SET L8140-AGT-COMM-RQST            TO TRUE.

           PERFORM  8140-1000-PRCES-SURR
               THRU 8140-1000-PRCES-SURR-X.

           IF  L8140-RETRN-OK
               PERFORM  8500-UPDATE-POLICY-AND-CVGS
                   THRU 8500-UPDATE-POLICY-AND-CVGS-X
      * MSG: TRANSACTION PROCESSED SUCCESSFULLY
               MOVE 'CS82210007'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
      *MSG: INCOMPETE TRANSACTION
               MOVE 'CS82210006'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  8100-RESET-DEFAULTS
               THRU 8100-RESET-DEFAULTS-X.

       3420-PROCESS-CURR-SURR-3-X.
           EXIT.

      *------------------------
       3422-BUILD-8140-LINKAGE.
      *------------------------

           PERFORM 8140-1000-BUILD-PARM-INFO
              THRU 8140-1000-BUILD-PARM-INFO-X.

           SET L8140-ALLOC-BY-AMOUNT         TO TRUE.
           SET L8140-LTAXWH-DISB-NONP        TO TRUE.
           SET L8140-DEFR-ALLOWED            TO TRUE.
           SET L8140-MSG-SUPPRESS            TO TRUE.
           SET L8140-REDO-WARNING            TO TRUE.
           SET L8140-SURR-TAX-OVRID-NONE     TO TRUE.
           SET L8140-TRXN-WTHDR              TO TRUE.
           SET L8140-CONFIRM-STATE           TO TRUE.
           SET L8140-PRCES-TYP-ALL           TO TRUE.

           IF  NOT RPOL-POL-PNSN-QUALF-NONE
               SET L8140-SURR-TAX-OVRID-NORM TO TRUE
           END-IF.

           MOVE WS-EFF-DT                    TO L8140-EFF-DT.
           MOVE L8231-CIA-REASN-CD           TO L8140-REASN-CD.
           MOVE L8231-DV-POL-SURR-AMT-R      TO L8140-SURR-AMOUNT.
           MOVE WS-EFF-DT                    TO L8140-EFF-DT.
           MOVE L8231-CLI-ID                 TO L8140-CLI-ID.
           MOVE L8231-CLI-BNK-ACCT-NUM       TO L8140-CLI-BNK-ACCT-NUM.
029060*    MOVE L8231-LTAXWH-CALC-CD         TO L8140-LTAXWH-CALC-CD.
           MOVE L8231-SUPRES-CNFRM-IND       TO L8140-SUPR-CONF-IND.
           MOVE L8231-DV-REDC-FACE-IND       TO L8140-REDC-FACE-IND.
           MOVE L8231-CIA-SRC-DEST-CD        TO L8140-DEST-CD.
029060*    MOVE L8231-LTAXWH-PCT-R           TO L8140-LTAXWH-PCT.
029060*    MOVE L8231-FED-TAXWH-RQST-AMT-R   TO L8140-FED-TAXWH-AMT.
029060*
029060*    IF  NOT L8140-LTAXWH-CALC
029060*       MOVE ZEROES                    TO L8140-LTAXWH-FLAT-AMT
029060*    ELSE
029060*       MOVE L8231-LTAXWH-FLAT-AMT-R   TO L8140-LTAXWH-FLAT-AMT
029060*    END-IF.

       3422-BUILD-8140-LINKAGE-X.
           EXIT.

      *----------------------------
       3424-ELIMINATE-UNUSED-FUNDS.
      *----------------------------

           MOVE ZERO                         TO JJ.
           PERFORM
               VARYING J FROM 1 BY 1
               UNTIL   J > LFUND-FND-CTR
               IF  LFUND-ALLOC-AMT (J) = ZERO
               AND LFUND-ALLOC-PCT (J) = ZERO
               AND LFUND-ALLOC-UNIT-QTY (J) = ZERO
                   CONTINUE
               ELSE
                   ADD +1                    TO JJ
                   MOVE LFUND-FND-INFO (J)
                                             TO LFUND-FND-INFO (JJ)
               END-IF
           END-PERFORM.

           MOVE JJ                           TO LFUND-FND-CTR.

       3424-ELIMINATE-UNUSED-FUNDS-X.
           EXIT.

      *---------------------------
       3440-PROCESS-FUTURE-SURR-3.
      *---------------------------

           IF  WS-BUS-FCN-FUTURE-DATED-SURR
           AND MIR-DV-FTL-MSG-OVRID-IND = 'Y'
               SET L8231-FUTURE-OVERRIDE     TO TRUE
           END-IF.

           PERFORM  8231-6000-EDIT-FUTURE-SURR-3
               THRU 8231-6000-EDIT-FUTURE-SURR-3-X


           IF  L8231-RETRN-ERROR
               GO TO 3440-PROCESS-FUTURE-SURR-3-X
           END-IF.

           PERFORM  3460-AUTO-REDO
               THRU 3460-AUTO-REDO-X.

           IF  L4780-RETRN-ERROR
               GO TO 3440-PROCESS-FUTURE-SURR-3-X
           END-IF.

           MOVE MIR-POL-ID                   TO WPORQ-POL-ID.
036742*    PERFORM  0035-5000-TIMESTAMP
036742*        THRU 0035-5000-TIMESTAMP-X.
036742*
036742*    MOVE L0035-TIMESTAMP              TO WPORQ-POL-RQST-CREAT-TS.
036742     MOVE WS-EFF-DT                    TO WPORQ-POL-RQST-EFF-DT
036742
           PERFORM  PORQ-1000-CREATE
               THRU PORQ-1000-CREATE-X

036742*    MOVE WS-EFF-DT                    TO RPORQ-POL-RQST-EFF-DT
           SET RPORQ-POL-RQST-TYP-WTHDR-PSUR TO TRUE.
           SET RPORQ-POL-RQST-STAT-PEND      TO TRUE.
           MOVE MIR-BUS-FCN-ID               TO RPORQ-BUS-FCN-ID.
           MOVE WGLOB-USER-ID                TO RPORQ-USER-ID.
           MOVE LENGTH OF MIR-PARM-AREA
                                      TO RPORQ-POL-RQST-MSG-INFO-LENGTH
           MOVE MIR-PARM-AREA         TO RPORQ-POL-RQST-MSG-INFO-DATA
                                      (1:RPORQ-POL-RQST-MSG-INFO-LENGTH)

           PERFORM  PORQ-1000-WRITE
               THRU PORQ-1000-WRITE-X.

      *MSG: FUTURE DATED WITHDRAWAL REQUEST HAS BEEN SCHEDULED.  VIEW
      *     DETAILS ON FUTURE DATED POLICY ACTIVITY BUSINESS PROCESS.
            MOVE 'CS82210008'                TO WGLOB-MSG-REF-INFO
            PERFORM  0260-1000-GENERATE-MESSAGE
                THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  8720-SET-POL-NXT-ACTV
               THRU 8720-SET-POL-NXT-ACTV-X.
           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.
           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

       3440-PROCESS-FUTURE-SURR-3-X.
           EXIT.

      *----------------
       3460-AUTO-REDO.
      *----------------

           SET WS-REDO-OK                    TO TRUE.

           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.
           IF  NOT WPOL-IO-OK
      *MSG: POLICY NOT IN FILE
               MOVE 'CS00000019'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WS-REDO-NOT-OK            TO TRUE
               GO TO 3460-AUTO-REDO-X
           END-IF.
           MOVE RPOL-REC-INFO                TO HPOL-REC-INFO.

           PERFORM  0289-1000-INIT-PARM-INFO
               THRU 0289-1000-INIT-PARM-INFO-X.

           MOVE WS-EFF-DT                    TO L0289-PROC-EFF-DT.
           MOVE WS-EFF-DT                    TO L0289-LO-PAC-DT.
           MOVE WS-EFF-DT                    TO L0289-LO-CRC-DT.
           MOVE WS-EFF-DT                    TO L0289-LO-DD2-DT.

           PERFORM  0289-1000-OBTAIN-NXT-ACTV
               THRU 0289-1000-OBTAIN-NXT-ACTV-X.

           IF  L0289-RETRN-OK
               MOVE L0289-NXT-ACTV-TYP-CD    TO RPOL-NXT-ACTV-TYP-CD
               MOVE L0289-NXT-ACTV-DT        TO RPOL-POL-NXT-ACTV-DT
           ELSE
               MOVE 'RSH'                    TO RPOL-NXT-ACTV-TYP-CD
               MOVE WGLOB-PROCESS-DATE       TO RPOL-POL-NXT-ACTV-DT
           END-IF.

           IF (RPOL-POL-NXT-ACTV-DT > WWKDT-ZERO-DT
           AND RPOL-POL-NXT-ACTV-DT > WGLOB-PROCESS-DATE)
               CONTINUE
           ELSE
               PERFORM  8550-INVOKE-REDO
                   THRU 8550-INVOKE-REDO-X
           END-IF.

       3460-AUTO-REDO-X.
           EXIT.

      *-----------------------
       5000-FILL-INPUT-DATA-1.
      *-----------------------

           MOVE MIR-CIA-EFF-DT            TO L8231-CIA-EFF-DT.
           MOVE MIR-DV-POL-SURR-AMT       TO L8231-DV-POL-SURR-AMT.
           MOVE MIR-DV-REDC-FACE-IND      TO L8231-DV-REDC-FACE-IND.
029060*    MOVE MIR-LTAXWH-CALC-CD        TO L8231-LTAXWH-CALC-CD.
029060*    MOVE MIR-LTAXWH-PCT            TO L8231-LTAXWH-PCT.
029060*    MOVE MIR-LTAXWH-FLAT-AMT       TO L8231-LTAXWH-FLAT-AMT.
029060*    MOVE MIR-FED-TAXWH-CALC-CD     TO L8231-FED-TAXWH-CALC-CD.
029060*    MOVE MIR-FED-TAXWH-RQST-PCT    TO L8231-FED-TAXWH-RQST-PCT.
029060*    MOVE MIR-FED-TAXWH-RQST-AMT    TO L8231-FED-TAXWH-RQST-AMT.
029060     MOVE MIR-LTAXWH-RQST-CD        TO L8231-LTAXWH-RQST-CD.
029060     MOVE MIR-LTAXWH-RQST-PCT       TO L8231-LTAXWH-RQST-PCT.
029060     MOVE MIR-LTAXWH-RQST-AMT       TO L8231-LTAXWH-RQST-AMT.
029060     MOVE MIR-FTAXWH-RQST-CD        TO L8231-FTAXWH-RQST-CD.
029060     MOVE MIR-FTAXWH-RQST-PCT       TO L8231-FTAXWH-RQST-PCT.
029060     MOVE MIR-FTAXWH-RQST-AMT       TO L8231-FTAXWH-RQST-AMT.
           MOVE MIR-SUPRES-CNFRM-IND      TO L8231-SUPRES-CNFRM-IND.
           MOVE MIR-CIA-REASN-CD          TO L8231-CIA-REASN-CD.
           MOVE MIR-CIA-SRC-DEST-CD       TO L8231-CIA-SRC-DEST-CD.
           MOVE MIR-CLI-ID                TO L8231-CLI-ID.
           MOVE MIR-CLI-BNK-ACCT-NUM      TO L8231-CLI-BNK-ACCT-NUM.
           MOVE MIR-CIA-LOAD-AMT          TO L8231-CIA-LOAD-AMT.
           MOVE L2430-CLI-TXEMP-CD        TO L8231-CLI-TXEMP-CD.

       5000-FILL-INPUT-DATA-1-X.
           EXIT.

      *--------------------------
       5200-FILL-INPUT-FUND-DATA.
      *--------------------------

           PERFORM  5000-FILL-INPUT-DATA-1
               THRU 5000-FILL-INPUT-DATA-1-X.

           PERFORM
               VARYING J FROM +1 BY +1
                 UNTIL J > LFUND-FND-CTR
                 MOVE MIR-DV-FROM-FND-AMT-T (J)
                                          TO L8231-DV-FROM-FND-AMT-T (J)
           END-PERFORM.

       5200-FILL-INPUT-FUND-DATA-X.
           EXIT.

      *------------------------
       6000-DISPLAY-SURR-COMMON.
      *------------------------

           MOVE L8231-CIA-REASN-CD           TO MIR-CIA-REASN-CD.
           MOVE L8231-CIA-SRC-DEST-CD        TO MIR-CIA-SRC-DEST-CD.
           MOVE L8231-SUPRES-CNFRM-IND       TO MIR-SUPRES-CNFRM-IND.
           MOVE L8231-DV-REDC-FACE-IND       TO MIR-DV-REDC-FACE-IND.

           MOVE L8231-DV-POL-SURR-AMT-R      TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-POL-SURR-AMT
                                             TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO MIR-DV-POL-SURR-AMT.

           IF  MIR-DV-PRCES-STATE-CD = '1'
               MOVE ZEROS                    TO MIR-CIA-LOAD-AMT
               MOVE MIR-CIA-LOAD-AMT         TO L0280-INPUT-DATA
               SET L0280-SIGN-NOT-PERMITTED  TO TRUE
               MOVE 2                        TO L0280-PRECISION
               MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                             TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                    - L0280-PRECISION
                                    - 1
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   MOVE L0280-OUTPUT         TO L0290-INPUT-NUMBER
                   MOVE 2                    TO L0290-PRECISION
                   MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                             TO L0290-MAX-OUT-LEN
                   PERFORM  0290-2000-FORMAT-FOR-MIR
                       THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA    TO MIR-CIA-LOAD-AMT
               END-IF
           ELSE
               MOVE L8231-CIA-LOAD-AMT-R     TO L0290-INPUT-V02
               MOVE 2                        TO L0290-PRECISION
               MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                             TO L0290-MAX-OUT-LEN
               PERFORM  0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA        TO MIR-CIA-LOAD-AMT
           END-IF.

029060*    MOVE L8231-CDA-FED-TAXWH-AMT-R    TO L0290-INPUT-V02.
029060     MOVE L8231-FTAXWH-AMT-R           TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
029060*                                      TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-AMT     TO L0290-MAX-OUT-LEN.
029060
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
029060
029060*    MOVE L0290-OUTPUT-DATA            TO MIR-CDA-FED-TAXWH-AMT.
029060     MOVE L0290-OUTPUT-DATA            TO MIR-FTAXWH-AMT.

029060*    MOVE L8231-FED-TAXWH-CALC-CD      TO MIR-FED-TAXWH-CALC-CD.
029060     MOVE L8231-FTAXWH-RQST-CD         TO MIR-FTAXWH-RQST-CD.

029060*    MOVE L8231-FED-TAXWH-RQST-AMT-R   TO L0290-INPUT-V02.
029060     MOVE L8231-FTAXWH-RQST-AMT-R      TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-RQST-AMT
029060*                                      TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-RQST-AMT
029060                                       TO L0290-MAX-OUT-LEN.
029060
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
029060               
029060*    MOVE L0290-OUTPUT-DATA            TO MIR-FED-TAXWH-RQST-AMT.
029060     MOVE L0290-OUTPUT-DATA            TO MIR-FTAXWH-RQST-AMT.

029060*    MOVE L8231-FED-TAXWH-RQST-PCT-R   TO L0290-INPUT-V02.
029060     MOVE L8231-FTAXWH-RQST-PCT-R      TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-RQST-PCT
029060*                                      TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-RQST-PCT
029060                                       TO L0290-MAX-OUT-LEN.
029060
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
029060               
029060*    MOVE L0290-OUTPUT-DATA            TO MIR-FED-TAXWH-RQST-PCT.
029060     MOVE L0290-OUTPUT-DATA            TO MIR-FTAXWH-RQST-PCT.

029060*    MOVE L8231-LTAXWH-FLAT-AMT-R      TO L0290-INPUT-V02.
029060     MOVE L8231-LTAXWH-RQST-AMT-R      TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060*                                      TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
029060                                       TO L0290-MAX-OUT-LEN.
029060
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
029060               
029060*    MOVE L0290-OUTPUT-DATA            TO MIR-CDA-LTAXWH-AMT.
029060     MOVE L0290-OUTPUT-DATA            TO MIR-LTAXWH-AMT.


029060*    MOVE L8231-LTAXWH-PCT-R           TO L0290-INPUT-V02.
029060     MOVE L8231-LTAXWH-RQST-PCT-R      TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-PCT     TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-PCT
029060                                       TO L0290-MAX-OUT-LEN.
029060
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
029060               
029060*    MOVE  L0290-OUTPUT-DATA           TO MIR-LTAXWH-PCT.
029060     MOVE  L0290-OUTPUT-DATA           TO MIR-LTAXWH-RQST-PCT.

           MOVE L8231-CLI-ID                 TO MIR-CLI-ID.
           MOVE L8231-CLI-BNK-ACCT-NUM       TO MIR-CLI-BNK-ACCT-NUM.

       6000-DISPLAY-SURR-COMMON-X.
           EXIT.

      *----------------------
       6200-DISPLAY-SURR-FUND.
      *----------------------

           PERFORM 8000-DISPLAY-FUND-KEYS
              THRU 8000-DISPLAY-FUND-KEYS-X.

           MOVE LFUND-ALLOC-AMT (JJ)         TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (1)
                                             TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO MIR-DV-FROM-FND-AMT-T
                                                (JJ).

           IF L8180-CFN-CV-AMT (JJ) = ZERO
               MOVE ZERO                     TO WS-WORK-PCT
           ELSE
               COMPUTE WS-WORK-AMT = LFUND-ALLOC-AMT (JJ) * -1
               COMPUTE WS-WORK-PCT = (WS-WORK-AMT
                                   / L8180-CFN-POL-CRCY-CV-AMT (JJ))
                                   * 100
           END-IF.

           MOVE WS-WORK-PCT                  TO L0290-INPUT-V04.
           MOVE 4                            TO L0290-PRECISION .
           MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (JJ)
                                             TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO MIR-FIA-OUT-ALLOC-PCT-T
                                                (JJ).

           MOVE ZEROES                       TO L0290-INPUT-V04
           MOVE 4                            TO L0290-PRECISION
           MOVE LENGTH OF MIR-FIA-VALU-SURR-PCT-T (JJ)
                                             TO L0290-MAX-OUT-LEN
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO MIR-FIA-VALU-SURR-PCT-T
                                                (JJ).

       6200-DISPLAY-SURR-FUND-X.
           EXIT.
      /
      *-----------------------
       6400-DISPLAY-TAX-INFO.
      *-----------------------

           MOVE L8231-DV-POL-TAX-ACB-AMT-R   TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-POL-TAX-ACB-AMT
                                             TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO MIR-DV-POL-TAX-ACB-AMT.

           MOVE L8231-DV-TAXBL-GRS-DSTRB-AMT-R
                                             TO L0290-INPUT-V02.
           MOVE 2                 TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-TAXBL-GRS-DSTRB-AMT
                                             TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA         TO MIR-DV-TAXBL-GRS-DSTRB-AMT.

           MOVE L8231-DV-GRS-DSTRB-AMT-R     TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-GRS-DSTRB-AMT
                                             TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO MIR-DV-GRS-DSTRB-AMT.

       6400-DISPLAY-TAX-INFO-X.
           EXIT.
      /
      *-----------------------
       8000-DISPLAY-FUND-KEYS.
      *-----------------------

           MOVE LFUND-FND-ID (JJ)            TO L8640-FND-ID.

           PERFORM  8640-1000-GET-FND-CRCY-CD
               THRU 8640-1000-GET-FND-CRCY-CD-X.

           IF  L8640-RETRN-OK
               MOVE L8640-FND-CRCY-CD        TO MIR-FIA-CRCY-CD-T (JJ)
           ELSE
               MOVE SPACES                   TO MIR-FIA-CRCY-CD-T (JJ)
      * CASHFLOW TYPE PRODUCTS WILL BY DEFINITION HAVE LFUND-FND-ID (JJ)
      * SET TO SPACES
               IF  LFUND-FND-ID (JJ) = SPACES
                   MOVE WS-POL-CRCY-CD       TO MIR-FIA-CRCY-CD-T (JJ)
               END-IF
           END-IF.

      *    FOR EACH OF THE FUNDS MOVE THE POLICY CURRENCY CODE TO MIR

           MOVE WS-POL-CRCY-CD               TO MIR-CIA-CRCY-CD-T (JJ).
           MOVE LFUND-CVG-NUM (JJ)           TO MIR-CVG-NUM-T (JJ).
           MOVE LFUND-FND-ID (JJ)            TO MIR-FND-ID-T (JJ).
           COMPUTE L0290-INPUT-V02
                  =  L8180-CFN-CV-AMT (JJ)
                  + L8180-CFN-DEFR-IN-AMT (JJ)
                  + L8180-CFN-DEFR-OUT-AMT (JJ).
           MOVE 2                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-CFN-APROX-AMT-T (1)
                                             TO L0290-MAX-OUT-LEN.
031065*    SET L0290-SIGN-POS-DISPLAY        TO TRUE.
031065     SET L0290-SIGN-DISPLAY            TO TRUE.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO MIR-DV-CFN-APROX-AMT-T
                                                (JJ).

           COMPUTE  L0290-INPUT-NUMBER
                 = (L8180-CFN-POL-CRCY-CV-AMT (JJ)
                 +  L8180-CFN-POL-DEFR-IN-AMT     (JJ)
                 +  L8180-CFN-POL-DEFR-OUT-AMT    (JJ))
                 *  100.
           MOVE 2                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-FIA-POL-CRCY-AMT-T (1)
                                             TO L0290-MAX-OUT-LEN.
031065*    SET L0290-SIGN-POS-DISPLAY        TO TRUE.
031065     SET L0290-SIGN-DISPLAY            TO TRUE.
           PERFORM  0290-1000-NUMERIC-FORMAT
               THRU 0290-1000-NUMERIC-FORMAT-X.
           MOVE L0290-OUTPUT-DATA         TO MIR-DV-FIA-POL-CRCY-AMT-T
                                                (JJ).

           MOVE LFUND-CVG-NUM-N (JJ)         TO I.
           MOVE WCVGS-PLAN-ID (I)            TO MIR-PLAN-ID-T (JJ).

           PERFORM 8010-DISPLAY-FUND-UNITS
              THRU 8010-DISPLAY-FUND-UNITS-X.
           PERFORM 8020-GET-FUND-DESCRIPTION
              THRU 8020-GET-FUND-DESCRIPTION-X.

       8000-DISPLAY-FUND-KEYS-X.
           EXIT.

      *--------------------------
       8010-DISPLAY-FUND-UNITS.
      *--------------------------

           MOVE L8180-CFN-UNIT-QTY (JJ)      TO L0290-INPUT-V06.
           MOVE 6                            TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FIA-UNIT-CUM-QTY-T (JJ)
                                             TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-POS-DISPLAY        TO TRUE.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO MIR-FIA-UNIT-CUM-QTY-T
                                                (JJ).

       8010-DISPLAY-FUND-UNITS-X.
           EXIT.

      *--------------------------
       8020-GET-FUND-DESCRIPTION.
      *--------------------------

           IF  MIR-CVG-NUM-T (JJ) = SPACE
           AND MIR-FND-ID-T (JJ) = SPACE
               GO TO 8020-GET-FUND-DESCRIPTION-X
           END-IF.

           IF MIR-FND-ID-T (JJ) = SPACE
               MOVE MIR-PLAN-ID-T (JJ)       TO WEDIT-ETBL-VALU-ID
               PERFORM PLAN-2000-DESC
                  THRU PLAN-2000-DESC-X
               MOVE REDIT-ETBL-DESC-TXT      TO MIR-DV-FND-DESC-TXT-T
                                                (JJ)
           ELSE
               MOVE MIR-FND-ID-T (JJ)        TO WEDIT-ETBL-VALU-ID
               PERFORM SGFD-2000-DESC
                  THRU SGFD-2000-DESC-X
               MOVE REDIT-ETBL-DESC-TXT      TO MIR-DV-FND-DESC-TXT-T
                                                (JJ)
           END-IF.

       8020-GET-FUND-DESCRIPTION-X.
           EXIT.

      *-------------------
       8100-RESET-DEFAULTS.
      *-------------------

           MOVE WGLOB-PROCESS-DATE           TO L1640-INTERNAL-DATE.
           PERFORM 1640-8000-INTERNAL-TO-MIR
              THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE          TO MIR-CIA-EFF-DT.

           MOVE  ZERO                        TO L0290-INPUT-V02
           MOVE  2                           TO L0290-PRECISION
           MOVE LENGTH OF MIR-DV-POL-SURR-AMT
                                             TO L0290-MAX-OUT-LEN
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO MIR-DV-POL-SURR-AMT

           MOVE  ZERO                        TO L0290-INPUT-V02
           MOVE  2                           TO L0290-PRECISION
           MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                             TO L0290-MAX-OUT-LEN
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA            TO MIR-CIA-LOAD-AMT

           MOVE SPACES                       TO MIR-DV-OWN-CLI-NM
           MOVE SPACES                       TO MIR-CIA-REASN-CD.
           MOVE 'N'                          TO MIR-DV-REDC-FACE-IND.
029060*    MOVE 'C'                          TO MIR-LTAXWH-CALC-CD.
029060     MOVE 'C'                          TO MIR-LTAXWH-RQST-CD.
           MOVE 'N'                          TO MIR-SUPRES-CNFRM-IND.
           MOVE 'D'                          TO MIR-CIA-SRC-DEST-CD.

           MOVE ZERO                         TO L0290-INPUT-V02.
029060*    MOVE LENGTH OF MIR-LTAXWH-PCT     TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-PCT
029060                                       TO L0290-MAX-OUT-LEN.
           MOVE 2                            TO L0290-PRECISION.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE L0290-OUTPUT-DATA            TO MIR-LTAXWH-PCT.
029060     MOVE L0290-OUTPUT-DATA            TO MIR-LTAXWH-RQST-PCT.

           MOVE ZERO                         TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-LTAXWH-FLAT-AMT
029060*                                      TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-LTAXWH-RQST-AMT
029060                                       TO L0290-MAX-OUT-LEN.
029060
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
029060              
029060*    MOVE L0290-OUTPUT-DATA            TO MIR-LTAXWH-FLAT-AMT.
029060     MOVE L0290-OUTPUT-DATA            TO MIR-LTAXWH-RQST-AMT.

           MOVE ZERO                         TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-CDA-FED-TAXWH-AMT
029060*                                      TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-AMT     TO L0290-MAX-OUT-LEN.
029060
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
029060              
029060*    MOVE L0290-OUTPUT-DATA            TO MIR-CDA-FED-TAXWH-AMT.
029060     MOVE L0290-OUTPUT-DATA            TO MIR-FTAXWH-AMT.

           MOVE ZERO                         TO L0290-INPUT-V02.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-RQST-PCT
029060*                                      TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-RQST-PCT
029060                                       TO L0290-MAX-OUT-LEN.
           MOVE 2                            TO L0290-PRECISION.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
029060*    MOVE L0290-OUTPUT-DATA            TO MIR-FED-TAXWH-RQST-PCT.
029060     MOVE L0290-OUTPUT-DATA            TO MIR-FTAXWH-RQST-PCT.

           MOVE ZERO                         TO L0290-INPUT-V02.
           MOVE 2                            TO L0290-PRECISION.
029060*    MOVE LENGTH OF MIR-FED-TAXWH-RQST-AMT
029060*                                      TO L0290-MAX-OUT-LEN.
029060     MOVE LENGTH OF MIR-FTAXWH-RQST-AMT
029060                                       TO L0290-MAX-OUT-LEN.
029060
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
029060              
029060*    MOVE L0290-OUTPUT-DATA            TO MIR-FED-TAXWH-RQST-AMT.
029060     MOVE L0290-OUTPUT-DATA            TO MIR-FTAXWH-RQST-AMT.

       8100-RESET-DEFAULTS-X.
           EXIT.

      *----------------------------
       8500-UPDATE-POLICY-AND-CVGS.
      *----------------------------

           PERFORM  8720-SET-POL-NXT-ACTV
               THRU 8720-SET-POL-NXT-ACTV-X.
           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.
           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL I > RPOL-POL-CVG-REC-CTR-N
               MOVE I                        TO WCVG-CVG-NUM-N
               PERFORM CVG-1000-READ-FOR-UPDATE
                  THRU CVG-1000-READ-FOR-UPDATE-X
               IF RCVG-CVG-INFO = WCVGS-CVG-INFO (I)
                   PERFORM CVG-3000-UNLOCK
                      THRU CVG-3000-UNLOCK-X
               ELSE
                   MOVE WCVGS-CVG-INFO (I)   TO RCVG-CVG-INFO
                   PERFORM CVG-2000-REWRITE
                      THRU CVG-2000-REWRITE-X
               END-IF
           END-PERFORM.

       8500-UPDATE-POLICY-AND-CVGS-X.
           EXIT.

      *----------------
       8550-INVOKE-REDO.
      *-----------------

           IF  NOT RPOL-POL-STAT-IN-FORCE
               GO TO 8550-INVOKE-REDO-X
           END-IF.

           PERFORM  4780-1000-BUILD-PARM-INFO
               THRU 4780-1000-BUILD-PARM-INFO-X.
           SET L4780-REDO-WARNING            TO TRUE.
           SET L4780-MSG-SUPPRESS            TO TRUE.

           IF  WS-BUS-FCN-SURR
               MOVE WS-EFF-DT                TO L4780-EFF-DT
           ELSE
               MOVE WGLOB-PROCESS-DATE       TO L4780-EFF-DT
           END-IF.

           MOVE RPOL-PREV-BTCH-PRCES-DT      TO L4780-LAST-PROCESS-DATE.
           SET L4780-PRCES-INCLUSIVE         TO TRUE.

           PERFORM  4780-1000-GET-NEXT-ACT-DT
               THRU 4780-1000-GET-NEXT-ACT-DT-X.

           EVALUATE  TRUE
               WHEN L4780-RETRN-ERROR
               WHEN L4780-RETRN-INVALID-REQUEST
                    SET WS-REDO-NOT-OK       TO TRUE
                    PERFORM  POL-3000-UNLOCK
                        THRU POL-3000-UNLOCK-X
               WHEN  (L4780-RETRN-OK
               AND L4780-ACTIVITY-DUE
               AND L4780-REDO-ALLOW)
                   PERFORM  POL-3000-UNLOCK
                       THRU POL-3000-UNLOCK-X
                   IF  WS-BUS-FCN-SURR
                       MOVE WS-EFF-DT        TO L0201-EFF-DT
                   ELSE
                      MOVE WGLOB-PROCESS-DATE
                                             TO L0201-EFF-DT
                   END-IF
                   SET L0201-AUTO-REDO       TO TRUE

                   PERFORM  0201-1000-AUTO-PROCESSING
                       THRU 0201-1000-AUTO-PROCESSING-X
                   PERFORM  8720-SET-POL-NXT-ACTV
                       THRU 8720-SET-POL-NXT-ACTV-X

                   MOVE RPOL-REC-INFO        TO HPOL-REC-INFO
                   PERFORM  POL-1000-READ-FOR-UPDATE
                       THRU POL-1000-READ-FOR-UPDATE-X

                   MOVE HPOL-REC-INFO        TO RPOL-REC-INFO
                   PERFORM  POL-2000-REWRITE
                       THRU POL-2000-REWRITE-X
                       PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
                           THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
                       PERFORM  POL-1000-READ-TWRK-TS
                           THRU POL-1000-READ-TWRK-TS-X

                   IF  L0201-RETRN-OK
                   OR  WS-BUS-FCN-FUTURE-DATED-SURR
                       PERFORM  POL-1000-READ-FOR-UPDATE
                           THRU POL-1000-READ-FOR-UPDATE-X
                   END-IF

                   IF  L0201-RETRN-OK
                       MOVE 'XS00000307'     TO  WGLOB-MSG-REF-INFO
      *MSG: 'AUTO REDO PROCESSING COMPLETED
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                   ELSE
                       SET WS-REDO-NOT-OK    TO TRUE
                       IF  NOT L0201-INCOMPLETE-DUE-ACTV
                           MOVE 'XS00000308' TO WGLOB-MSG-REF-INFO
      *MSG: PROBLEM IN AUTO REDO PROCESSING
                           PERFORM  0260-1000-GENERATE-MESSAGE
                               THRU 0260-1000-GENERATE-MESSAGE-X
                       END-IF
                   END-IF
           END-EVALUATE.

       8550-INVOKE-REDO-X.
           EXIT.

      *-----------------
       8600-INVOKE-UNDO.
      *-----------------

           PERFORM  4750-1000-BUILD-PARM-INFO
               THRU 4750-1000-BUILD-PARM-INFO-X.
           SET L4750-FCN-DRVR-SECONDARY      TO TRUE.
           IF  WS-BUS-FCN-SURR
               MOVE WS-EFF-DT                TO L4750-EFF-DT
           ELSE
               MOVE WGLOB-PROCESS-DATE       TO L4750-EFF-DT
           END-IF.
           MOVE MIR-SUPRES-CNFRM-IND         TO L4750-SUPP-CONF-CD.
           SET  L4750-PRCES-EXCLUSIVE        TO TRUE

      *  UNLOCK POLICY PRIOR TO UNDO

           PERFORM  POL-3000-UNLOCK
               THRU POL-3000-UNLOCK-X.

           PERFORM  4750-1000-UNDO-PROCESSING
               THRU 4750-1000-UNDO-PROCESSING-X.

           IF  NOT L4750-RETRN-OK
               SET MIR-RETRN-EDIT-ERROR      TO TRUE
               SET WGLOB-RETURN-ERROR        TO TRUE
           END-IF.

           IF  WGLOB-RETURN-ERROR
           AND L4750-POL-UPDATE-NOT-REQD
               GO TO 8600-INVOKE-UNDO-X
           END-IF.

      *  LOCK POLICY AGAIN IN ORDER TO DO UPDATES
      *  SAVE POLICY INFO TO RESTORE AFTER READ FOR UPDATE

           MOVE  RPOL-REC-INFO               TO  HPOL-REC-INFO.
           MOVE  RPOL-KEY                    TO  WPOL-KEY.
           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.
           MOVE HPOL-REC-INFO                TO  RPOL-REC-INFO.

           IF  L4750-POL-UPDATE-REQD

               PERFORM  8700-UPDATE-POL-CVG
                   THRU 8700-UPDATE-POL-CVG-X

               IF  WGLOB-GOOD-RETURN
                   MOVE  RPOL-KEY            TO  WPOL-KEY
                   PERFORM  POL-1000-READ-FOR-UPDATE
                       THRU POL-1000-READ-FOR-UPDATE-X
               END-IF

           END-IF.

       8600-INVOKE-UNDO-X.
           EXIT.

      *--------------------
       8700-UPDATE-POL-CVG.
      *--------------------

           PERFORM  8720-SET-POL-NXT-ACTV
               THRU 8720-SET-POL-NXT-ACTV-X.
           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.
           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.
           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

       8700-UPDATE-POL-CVG-X.
           EXIT.

      *-----------------------
       8720-SET-POL-NXT-ACTV.
      *-----------------------

           PERFORM  0289-1000-INIT-PARM-INFO
               THRU 0289-1000-INIT-PARM-INFO-X
           MOVE WS-EFF-DT                    TO L0289-LO-PAC-DT
           MOVE WS-EFF-DT                    TO L0289-LO-CRC-DT
           MOVE WS-EFF-DT                    TO L0289-LO-DD2-DT.
           MOVE WS-EFF-DT                    TO L0289-PROC-EFF-DT
           PERFORM  0289-1000-OBTAIN-NXT-ACTV
               THRU 0289-1000-OBTAIN-NXT-ACTV-X
           IF  L0289-RETRN-OK
                MOVE L0289-NXT-ACTV-TYP-CD   TO RPOL-NXT-ACTV-TYP-CD
                MOVE L0289-NXT-ACTV-DT       TO RPOL-POL-NXT-ACTV-DT
            ELSE
                MOVE 'RSH'                   TO RPOL-NXT-ACTV-TYP-CD
                MOVE WGLOB-PROCESS-DATE      TO RPOL-POL-NXT-ACTV-DT
            END-IF.

       8720-SET-POL-NXT-ACTV-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                     TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE         TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX          TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0201-0000-INIT-PARM-INFO
               THRU 0201-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  0289-0000-INIT-PARM-INFO
               THRU 0289-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           PERFORM  0620-0000-INIT-PARM-INFO
               THRU 0620-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

           PERFORM  2430-0000-INIT-PARM-INFO
               THRU 2430-0000-INIT-PARM-INFO-X.

           PERFORM  2626-0000-INIT-PARM-INFO
               THRU 2626-0000-INIT-PARM-INFO-X.

           PERFORM  4750-0000-INIT-PARM-INFO
               THRU 4750-0000-INIT-PARM-INFO-X.

           PERFORM  4780-0000-INIT-PARM-INFO
               THRU 4780-0000-INIT-PARM-INFO-X.

           PERFORM  5400-0000-INIT-PARM-INFO
               THRU 5400-0000-INIT-PARM-INFO-X.

           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           PERFORM  8140-0000-INIT-PARM-INFO
               THRU 8140-0000-INIT-PARM-INFO-X.

           PERFORM  8180-0000-INIT-PARM-INFO
               THRU 8180-0000-INIT-PARM-INFO-X.

           PERFORM  8200-0000-INIT-PARM-INFO
               THRU 8200-0000-INIT-PARM-INFO-X.

           PERFORM  8231-0000-INIT-PARM-INFO
               THRU 8231-0000-INIT-PARM-INFO-X.

           PERFORM  8640-0000-INIT-PARM-INFO
               THRU 8640-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORK-FIELDS.
           INITIALIZE LFUND-FND-CTR.
           INITIALIZE LFUND-ACTV-CD.
           INITIALIZE FREQUENTLY-USED-INDICES.

           INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
           INITIALIZE WLOCK-TWRK-OTHER-INFO.

           PERFORM
               VARYING I FROM +1 BY +1
               UNTIL I > LFUND-FND-MAX-CTR
                   INITIALIZE LFUND-FND-INFO (I)
           END-PERFORM.

           SET WS-BASIC-EDIT-OK              TO TRUE.
           MOVE SPACES                       TO WWKDT-WORK-FIELDS.
           MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      ****************************************************************
      *   PROCESSING COPYBOOKS
      ****************************************************************

       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY CCPPFPCK.
       COPY NCPPCVGR.
       COPY NCPPCVGS.

       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                                  '$VAR2' BY 'POL'.

       COPY XCPPINIT.
       COPY XCPPEXIT.

       COPY CCPEPLAN.
       COPY CCPESGFD.
      /
      ****************************************************************
      *   LINKAGE COPYBOOKS
      ****************************************************************

       COPY XCPS8090.
       COPY XCPS8640.
       COPY CCPS0201.
       COPY CCPL0201.

       COPY CCPS0289.
       COPY CCPL0289.

       COPY CCPS0620.
       COPY CCPL0620.

       COPY CCPS2430.
       COPY CCPL2430.

       COPY CCPS2626.
       COPY CCPL2626.

       COPY CCPS4750.
       COPY CCPL4750.

       COPY CCPS4780.
       COPY CCPL4780.

       COPY CCPS5400.
       COPY CCPL5400.

       COPY CCPS8231.
       COPY CCPL8231.

       COPY CCPSPGA.

031034*COPY CCPSPGAL.

       COPY FCPS8140.
       COPY FCPL8140.

       COPY FCPS8200.
       COPY FCPL8200.

       COPY FCPS8180.
       COPY FCPL8180.

036742*COPY XCPL0035.

       COPY XCPL0260.

       COPY XCPS0280.
       COPY XCPL0280.

       COPY XCPS0290.
       COPY XCPL0290.

       COPY XCPS1640.
       COPY XCPL1640.

       COPY XCPL8090.

       COPY XCPL8640.
      /
      *****************************************************************
      *   FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.

       COPY CCPAPORQ.
       COPY CCPCPORQ.

       COPY CCPNCVG.

       COPY CCPUCVG.

       COPY CCPNEDIT.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************

       COPY XCCP0030.

       COPY XCCPERR.

      *****************************************************************
      **                 END OF PROGRAM CSOM8221                     **
      *****************************************************************
