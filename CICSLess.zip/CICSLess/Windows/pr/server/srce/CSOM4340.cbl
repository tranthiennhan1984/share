      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4340.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4340                                         **
      **  REMARKS:  DIVH - BONUS/DIVIDEND HISTORY                    **
      **            THIS MODULE PROVIDES A HISTORY OF THE ANNUAL     **
      **            BONUS/DIVIDENDS WHICH HAVE BEEN MADE ON COVERAGE.**
      **            DETAIL INFORMATION ON ANY ONE HISTORY RECORD MAY **
      **            BE ACCESSED.                                     **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
013924**  5.6A      NEW FOR RELEASE 5.6A - ANNUAL BONUS              **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
016016**  6.3       FUND BONUS (6.1.1E)                              **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
015705**  6.4       NAME FORMATTING                                  **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023436**  6.5       UNDO/REDO OF ANNIVERSARY PROCESSING              **
023443**  6.5       DIRECT LOAN RECOGNITION FOR DIVIDENDS            **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
029716**  7.1       DIVIDEND ON DEPOSIT AVERAGE BALANCE              **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4340'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

025970 01  WS-CONSTANT-AREA.
025970     05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12
025970                                      BINARY.
025970         88  WS-MAX-BROWSE-LINES-DEFAULT         VALUE +12.
025970     05  WS-MAX-CDSD-LINES            PIC S9(4)  VALUE +10
025970                                      BINARY.
025970         88  WS-MAX-CDSD-LINES-DEFAULT           VALUE +10.
025970     05  WS-TWRK-KEY                  PIC X(04)
025970                                      VALUE '1570'.
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '1570'.
025970
       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  I                            PIC S9(4)  VALUE ZERO COMP.
016548     05  I                            PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12  COMP.
025970*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +12
025970*                                     BINARY.
025970*    05  WS-MAX-CDSD-LINES            PIC S9(4)  VALUE +10
025970*                                     BINARY.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-RETRIEVE      VALUE '1760'.
               88  WS-BUS-FCN-LIST          VALUE '1764'.
016016         88  WS-BUS-FCN-ERROR         VALUE '1765'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '1570'.
           05  WS-PIC-XXX.
               10  WS-PIC-999                   PIC 999.
           05  WS-POL-ID.
               10  WS-POL-ID-BASE           PIC X(09).
               10  WS-POL-ID-SFX            PIC X(01).
           05  WS-DECLARE-TYPE              PIC X(01).
016016*        88  WS-DECLARE-TYPE-VALID    VALUE 'D' 'B'.
016016         88  WS-DECLARE-TYPE-VALID    VALUE 'D' 'B' 'I' 'F'.
016016         88  WS-BON-DIV-TYP-FND       VALUE 'F'.
016016         88  WS-BON-DIV-TYP-INT       VALUE 'I'.
           05  WS-COVERAGE-NUM              PIC 9(02).
           05  WS-EFF-DT                    PIC X(10).
           05  WS-SWITCHES.
               10  WS-VALIDATE-FAIL-SW      PIC X(01).
                   88  VALIDATE-FAILED      VALUE 'Y'.
                   88  VALIDATE-OK          VALUE 'N'.
023436     05  WS-CDA-SEQ-NUM               PIC X(02).
023436     05  WS-CDA-SEQ-NUM-N             REDEFINES
023436         WS-CDA-SEQ-NUM               PIC S9(03)  COMP-3.
      /
018763**************************************************************
018763* WORKING STORAGE PARAMETER AREA
018763***************************************************************
      /
018763 COPY CCWWLOCK.
026057 COPY CCWWIHSD.
      /
028298 COPY CCWL2626.
       COPY CCWL5400.
      /
       COPY CCWL2430.
       COPY CCWL0620.
016016 COPY CCWL8935.
      /
      * LINKAGE TO PCL SET UP MODULE
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
018763 COPY XCWL8090.
      /
      * DATE MANIPULATION WORK AREAS
       COPY XCWLDTLK.
       COPY XCWWWKDT.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCFWBNDV.
       COPY CCFRBNDV.
      /
       COPY CCFWBNDD.
      /
023436 COPY CCFRCDSD.
023436 COPY CCFWCDSD.
      /
      *******************
       LINKAGE   SECTION.
      *******************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM4340.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *---------------
       0000-MAIN-LINE.
      *---------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAIN-LINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

025970*    SET  MIR-RETRN-OK      TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID    TO WS-BUS-FCN-ID.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

      *
      * MOVE ENTER CODE TO A WORK FIELD, AND DECIDE WHICH SCREEN TO
      * DISPLAY.
      *
           PERFORM  2100-VALIDATE-CONTROL-FIELDS
               THRU 2100-VALIDATE-CONTROL-FIELDS-X.
           IF  VALIDATE-FAILED
018763         IF  WS-BUS-FCN-RETRIEVE
018763         OR  WS-BUS-FCN-LIST
018763         OR  (WS-BUS-FCN-ERROR
018763         AND  MIR-RETRN-TS-MISMATCH)
018763             CONTINUE
018763         ELSE
018763             PERFORM  POL-3000-UNLOCK
018763                 THRU POL-3000-UNLOCK-X
018763         END-IF
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM 4000-PROCESS-LIST
                       THRU 4000-PROCESS-LIST-X
016016
016016         WHEN WS-BUS-FCN-ERROR
016016              PERFORM 5000-PROCESS-ERROR
016016                 THRU 5000-PROCESS-ERROR-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *-----------------------------
       2100-VALIDATE-CONTROL-FIELDS.
      *-----------------------------

           SET VALIDATE-OK TO TRUE.

           PERFORM  2110-CHECK-POLICY
               THRU 2110-CHECK-POLICY-X.

           PERFORM  2120-CHECK-DECLARE-TYPE
               THRU 2120-CHECK-DECLARE-TYPE-X.

           PERFORM  2125-CHECK-COVERAGE-NUM
               THRU 2125-CHECK-COVERAGE-NUM-X.

           PERFORM  2130-CHECK-EFFECT-DT
               THRU 2130-CHECK-EFFECT-DT-X.

           PERFORM  2140-CHECK-SEQ
               THRU 2140-CHECK-SEQ-X.

       2100-VALIDATE-CONTROL-FIELDS-X.
           EXIT.
      /
      *
      * CHECK POLICY:
      * ENSURE THAT THE POLICY EXISTS, THAT CONFIDENTIAL CHECKS ARE
      * SATISFIED, AND THAT BRANCH SECURITY IS SATISFIED.
      *
      *------------------
       2110-CHECK-POLICY.
      *------------------

           IF  MIR-POL-ID-BASE = SPACES
           AND MIR-POL-ID-SFX  = SPACES
      *MSG: POLICY NUMBER IS REQUIRED
               MOVE 'CS43400001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET VALIDATE-FAILED    TO TRUE
               GO TO 2110-CHECK-POLICY-X
           END-IF.

           MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.

018763* FOLLOWING CHANGES ARE FOR LOGICAL LOCKING

018763*    PERFORM  POL-1000-READ
018763*        THRU POL-1000-READ-X.

018763     EVALUATE  TRUE
018763        WHEN  WS-BUS-FCN-RETRIEVE
018763              PERFORM  POL-1000-READ-TWRK-TS
018763                  THRU POL-1000-READ-TWRK-TS-X
018763        WHEN  WS-BUS-FCN-ERROR
018763              PERFORM  POL-2000-UPDATE-TWRK-TS
018763                  THRU POL-2000-UPDATE-TWRK-TS-X
018763              IF  MIR-RETRN-TS-MISMATCH
018763*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
018763*  NOT COMPLETE
018763                  MOVE 'XS00000303'        TO WGLOB-MSG-REF-INFO
018763                  MOVE 'POL'               TO WGLOB-MSG-PARM (01)
018763                  MOVE WPOL-KEY            TO WGLOB-MSG-PARM (02)
018763                  PERFORM  0260-1000-GENERATE-MESSAGE
018763                      THRU 0260-1000-GENERATE-MESSAGE-X
018763                  SET VALIDATE-FAILED        TO TRUE
018763                  GO TO 2110-CHECK-POLICY-X
018763              END-IF
018763        WHEN  WS-BUS-FCN-LIST
018763              PERFORM  POL-1000-READ
018763                  THRU POL-1000-READ-X
018763     END-EVALUATE.

           IF  WPOL-IO-NOT-FOUND
               MOVE MIR-POL-ID-BASE   TO WS-POL-ID-BASE
               MOVE MIR-POL-ID-SFX    TO WS-POL-ID-SFX
               MOVE WS-POL-ID         TO WGLOB-MSG-PARM (1)
      *MSG: POLICY (@1) DOES NOT EXIST
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET VALIDATE-FAILED    TO TRUE
               GO TO 2110-CHECK-POLICY-X
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-STAT-MSG-NOT-REQD       TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF L5400-RETRN-OK
               IF L5400-CNFD-ACCS-RESTRICTED
               OR L5400-BRCH-ACCS-RESTRICTED
                   SET VALIDATE-FAILED       TO TRUE
                   GO TO 2110-CHECK-POLICY-X
               END-IF
           END-IF.

       2110-CHECK-POLICY-X.
           EXIT.
      /
      *
      * FORMAT DECLARATION TYPE:
      * ENSURE THAT THE SUPPLIED PAYOUT NUMBER IS NUMERIC.
      *
      *----------------------
       2120-CHECK-DECLARE-TYPE.
      *----------------------

           MOVE MIR-BON-DIV-TYP-CD    TO WS-DECLARE-TYPE.

           IF NOT WS-DECLARE-TYPE-VALID
016016*MSG: DECLARATION TYPE MUST BE 'B' OR 'D'
016016*MSG: DECLARATION TYPE MUST BE 'B', 'D', 'I' OR 'F'
              MOVE 'CS43400002'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              SET VALIDATE-FAILED    TO TRUE
           END-IF.

016016     IF  NOT WS-BON-DIV-TYP-FND
016016     AND MIR-FND-ID NOT = SPACES
016016*MSG: FUND ID ONLY FOR RECORD TYPE FUND
016016         MOVE 'CS43400009'      TO WGLOB-MSG-REF-INFO
016016         PERFORM  0260-1000-GENERATE-MESSAGE
016016             THRU 0260-1000-GENERATE-MESSAGE-X
016016         SET VALIDATE-FAILED    TO TRUE
018763         GO TO 2120-CHECK-DECLARE-TYPE-X
016016     END-IF.
016016
       2120-CHECK-DECLARE-TYPE-X.
           EXIT.
      /

      *----------------------
       2125-CHECK-COVERAGE-NUM.
      *----------------------

           IF MIR-CVG-NUM = SPACES
               GO TO 2125-CHECK-COVERAGE-NUM-X
           END-IF.


           EVALUATE TRUE

             WHEN WPOL-IO-OK

               MOVE 'N'               TO L0280-SIGN-IND
               MOVE 2                 TO L0280-LENGTH
               MOVE 0                 TO L0280-PRECISION
               MOVE 2                 TO L0280-INPUT-SIZE
               MOVE MIR-CVG-NUM       TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X

               IF  L0280-OK

                   IF  L0280-OUTPUT > RPOL-POL-CVG-REC-CTR-N
                       SET VALIDATE-FAILED    TO TRUE
      *MSG: COVERAGE RECORD DOES NOT EXIST
                       MOVE 'CS43400003'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                   ELSE
020874*                MOVE L0280-OUTPUT
020874*                               TO WS-COVERAGE-NUM
020874*                MOVE WS-COVERAGE-NUM
020874*                               TO MIR-CVG-NUM
020874                 MOVE L0280-OUTPUT   TO L0290-INPUT-V00
020874                 MOVE 0              TO L0290-PRECISION
020874                 MOVE LENGTH OF MIR-CVG-NUM
020874                                TO L0290-MAX-OUT-LEN
020874                 PERFORM 0290-2000-FORMAT-FOR-MIR
020874                    THRU 0290-2000-FORMAT-FOR-MIR-X
020874                 MOVE L0290-OUTPUT-DATA     TO MIR-CVG-NUM
                   END-IF

               ELSE
                   SET  VALIDATE-FAILED         TO TRUE
      *MSG: COVERAGE COVERAGE NUMBER MUST BE NUMERIC
                   MOVE 'CS43400004'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF

             WHEN OTHER
                  GO TO 2125-CHECK-COVERAGE-NUM-X


           END-EVALUATE.


       2125-CHECK-COVERAGE-NUM-X.
           EXIT.
      /
      *---------------------
       2130-CHECK-EFFECT-DT.
      *---------------------

018763*    IF  MIR-BON-DIV-IDT-NUM= SPACES
018763     IF  MIR-BON-DIV-IDT-NUM = SPACES
               MOVE WWKDT-HIGH-DT     TO WS-EFF-DT
               GO TO 2130-CHECK-EFFECT-DT-X
           END-IF.

           MOVE MIR-BON-DIV-IDT-NUM   TO L1640-EXTERNAL-DATE.

020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO WS-EFF-DT
           ELSE
      *MSG: DECLARATION DATE MUST BE VALID OR BLANK
               MOVE 'CS43400005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET VALIDATE-FAILED    TO TRUE
026057         GO TO 2130-CHECK-EFFECT-DT-X
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057     MOVE WS-EFF-DT              TO WIHSD-EFF-DT.
026057     IF  WS-BUS-FCN-RETRIEVE
026057     OR  WS-BUS-FCN-LIST
026057         PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057             THRU IHSD-1000-CHK-IHSD-INQUIRY-X
026057     ELSE
026057         PERFORM  IHSD-2000-CHK-IHSD-PROCESS
026057             THRU IHSD-2000-CHK-IHSD-PROCESS-X
026057     END-IF.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057        SET VALIDATE-FAILED    TO TRUE
026057     END-IF.

       2130-CHECK-EFFECT-DT-X.
           EXIT.
      /
      *---------------
       2140-CHECK-SEQ.
      *---------------

           IF MIR-BON-DIV-SEQ-NUM = SPACES
               MOVE 000               TO MIR-BON-DIV-SEQ-NUM
               GO TO 2140-CHECK-SEQ-X
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.
           MOVE MIR-BON-DIV-SEQ-NUM   TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
020874*         MOVE L0280-OUTPUT     TO WS-PIC-999
020874*         MOVE WS-PIC-999       TO MIR-BON-DIV-SEQ-NUM
020874          MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874          MOVE 0                     TO L0290-PRECISION
020874          MOVE LENGTH OF MIR-BON-DIV-SEQ-NUM
020874                                     TO L0290-MAX-OUT-LEN
020874          PERFORM 0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
020874          MOVE L0290-OUTPUT-DATA     TO MIR-BON-DIV-SEQ-NUM

           ELSE
      *MSG: SEQUENCE NUMBER MUST BE NUMERIC
               MOVE 'CS43400006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET VALIDATE-FAILED    TO TRUE
           END-IF.

       2140-CHECK-SEQ-X.
           EXIT.
      /
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------
016016*
016016* ON RETRIEVE, FUND TYPE MUST HAVE FUND ID
016016*
016016     IF  WS-BON-DIV-TYP-FND
016016     AND MIR-FND-ID = SPACES
016016*MSG: RECORD TYPE FUND MUST HAVE FUND ID
016016         MOVE 'CS43400010'      TO WGLOB-MSG-REF-INFO
016016         PERFORM  0260-1000-GENERATE-MESSAGE
016016             THRU 0260-1000-GENERATE-MESSAGE-X
016016         GO TO 3000-PROCESS-RETRIEVE-X
016016     END-IF.
016016
      *
      * RETRIEVE THE COVERAGE NUMBER FOR THE REQUESTED PAYOUT.
      *
           PERFORM  8000-BUILD-BNDV-KEY
               THRU 8000-BUILD-BNDV-KEY-X.

           PERFORM  BNDV-1000-READ
               THRU BNDV-1000-READ-X.

           IF  WBNDV-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      * MSG: ANNUAL BONUS DOES NOT EXIST FOR (@1)
               IF MIR-BON-DIV-TYP-CD = 'B'
                 MOVE 'CS43400007'    TO WGLOB-MSG-REF-INFO
               ELSE
      * MSG: DIVDEND RECORD DOES NOT EXIST FOR (@1)
                 MOVE 'CS43400008'    TO WGLOB-MSG-REF-INFO
               END-IF
               MOVE WBNDV-POL-ID      TO WGLOB-MSG-PARM (01)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  9200-LOAD-SCREEN
               THRU 9200-LOAD-SCREEN-X.

      * MSG: 'INQUIRE COMPLETED - CONTINUE'
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.

      *------------------
       4000-PROCESS-LIST.
      *------------------

           PERFORM  8510-SET-UP-BNDD-BR-KEY
               THRU 8510-SET-UP-BNDD-BR-KEY-X

           PERFORM  BNDD-1000-BROWSE
               THRU BNDD-1000-BROWSE-X.

           IF NOT WBNDD-IO-OK
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-LIST-X
           END-IF.

           PERFORM  BNDD-2000-READ-NEXT
               THRU BNDD-2000-READ-NEXT-X.

           IF NOT WBNDD-IO-OK
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-LIST-X
           END-IF.

           PERFORM  9200-LOAD-SCREEN
               THRU 9200-LOAD-SCREEN-X.

           IF WBNDD-IO-OK
      *MSG: TO VIEW MORE DATA PRESS ENTER
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG: 'INQUIRE COMPLETED - CONTINUE'
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

      *  FINISH BROWSE:
      *
           PERFORM  BNDD-3000-END-BROWSE
               THRU BNDD-3000-END-BROWSE-X.

       4000-PROCESS-LIST-X.
           EXIT.
016016
016016*-------------------
016016 5000-PROCESS-ERROR.
016016*-------------------
016016
016016* FUND TYPE MUST HAVE FUND ID
016016
016016     IF  WS-BON-DIV-TYP-FND
016016     AND MIR-FND-ID = SPACES
016016*MSG: RECORD TYPE FUND MUST HAVE FUND ID
016016         MOVE 'CS43400010'        TO WGLOB-MSG-REF-INFO
016016         PERFORM  0260-1000-GENERATE-MESSAGE
016016             THRU 0260-1000-GENERATE-MESSAGE-X
018763         PERFORM  POL-3000-UNLOCK
018763             THRU POL-3000-UNLOCK-X
016016         GO TO 5000-PROCESS-ERROR-X
016016     END-IF.
016016
016016* VALIDATE THE TYPE OF BONUS - MUST BE INTEREST OR FUND
016016
016016     IF  WS-BON-DIV-TYP-FND
016016     OR  WS-BON-DIV-TYP-INT
016016         CONTINUE
016016     ELSE
016016*MSG: BONUS TYPE MUST BE INTEREST OR FUND
016016         MOVE 'CS43400011'        TO WGLOB-MSG-REF-INFO
016016         PERFORM  0260-1000-GENERATE-MESSAGE
016016             THRU 0260-1000-GENERATE-MESSAGE-X
018763         PERFORM  POL-3000-UNLOCK
018763             THRU POL-3000-UNLOCK-X
016016         GO TO 5000-PROCESS-ERROR-X
016016     END-IF.
016016
016016* CALL UTILITY MODULE TO UPDATE STATUS FROM REVERSED TO ERROR
016016
016016     PERFORM  8935-1000-BUILD-PARM-INFO
016016         THRU 8935-1000-BUILD-PARM-INFO-X.
016016
016016     MOVE MIR-POL-ID              TO L8935-POL-ID.
016016     MOVE MIR-CVG-NUM             TO L8935-CVG-NUM.
016016     MOVE MIR-BON-DIV-TYP-CD      TO L8935-TYP-CD.
016016     MOVE WS-EFF-DT               TO L8935-DCLR-DT.
016016
016016     MOVE MIR-BON-DIV-SEQ-NUM     TO WS-PIC-999.
016016     COMPUTE L8935-SEQ-NUM = 1000 - WS-PIC-999.
016016
016016     IF  WS-BON-DIV-TYP-FND
016016         MOVE MIR-FND-ID     TO L8935-FND-ID
016016     ELSE
016016         MOVE SPACES              TO L8935-FND-ID
016016     END-IF.
016016
016016     PERFORM  8935-2000-ERROR-BNDV
016016         THRU 8935-2000-ERROR-BNDV-X.
016016
016016     IF  L8935-RETRN-ERROR
018763         PERFORM  POL-3000-UNLOCK
018763             THRU POL-3000-UNLOCK-X
016016         GO TO 5000-PROCESS-ERROR-X
018763     ELSE
018763         PERFORM  POL-2000-REWRITE
018763             THRU POL-2000-REWRITE-X
018763         PERFORM  POL-1000-READ-TWRK-TS
018763             THRU POL-1000-READ-TWRK-TS-X
016016     END-IF.
016016
016016     MOVE L8935-STAT-CD TO MIR-BON-DIV-STAT-CD.
016016     MOVE L8935-FND-ID  TO MIR-FND-ID.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            L8935-TRXN-AMT * 100.
020874     MOVE L8935-TRXN-AMT    TO L0290-INPUT-V02.
016016     MOVE 2                 TO L0290-PRECISION.
016016     MOVE LENGTH OF MIR-BON-DIV-TRXN-AMT
016016                            TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
016016     SET L0290-SIGN-DISPLAY        TO TRUE.
016016     SET L0290-SIGN-FLOAT          TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
016016     MOVE L0290-OUTPUT-DATA        TO MIR-BON-DIV-TRXN-AMT.
016016
016016     MOVE L8935-EFF-DT             TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
016016     MOVE L1640-EXTERNAL-DATE      TO MIR-EFF-IDT-NUM.
016016
016016     PERFORM  2430-1000-BUILD-PARM-INFO
016016         THRU 2430-1000-BUILD-PARM-INFO-X.
016016
016016     PERFORM  2430-2100-GET-OWNER
016016         THRU 2430-2100-GET-OWNER-X.
016016     IF NOT L2430-RELATIONSHIP-FOUND
016016         MOVE SPACES            TO MIR-DV-OWN-CLI-NM
016016     ELSE
016016         INITIALIZE L0620-INPUT-PARM-INFO
016016         IF L2430-CLI-SEX-COMPANY
016016             MOVE L2430-CLI-ENTR-CO-NM
016016                                TO L0620-CLI-CO-NM
016016         ELSE
016016             MOVE L2430-CLI-ENTR-GIV-NM
016016                                TO L0620-CLI-GIV-NM
016016             MOVE L2430-CLI-ENTR-SUR-NM
016016                                TO L0620-CLI-SUR-NM
015705             MOVE L2430-CLI-MID-INIT-NM
015705                                TO  L0620-CLI-MID-INIT-NM
015705             MOVE L2430-CLI-SFX-NM
015705                                TO L0620-CLI-SFX-NM
016016         END-IF
016016         MOVE L2430-CLI-SEX-CD  TO L0620-CLI-SEX-CD
016016
016016         PERFORM  0620-1000-FORMAT-SCREEN-NAME
016016             THRU 0620-1000-FORMAT-SCREEN-NAME-X
016016
016016         MOVE L0620-SCREEN-NAME TO MIR-DV-OWN-CLI-NM
016016     END-IF.
016016
016016 5000-PROCESS-ERROR-X.
016016     EXIT.

      * PARAGRAPH TO PROCESS BROWSE ENTER CODE

      /
      *------------------
       8000-BUILD-BNDV-KEY.
      *------------------

           MOVE SPACES                TO WBNDV-KEY.
           MOVE MIR-POL-ID-BASE       TO WBNDV-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WBNDV-POL-ID-SFX.
           MOVE MIR-BON-DIV-TYP-CD    TO WBNDV-BON-DIV-TYP-CD.
           MOVE MIR-CVG-NUM           TO WBNDV-CVG-NUM.

           MOVE WS-EFF-DT             TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
              THRU  1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE   TO WBNDV-BON-DIV-IDT-NUM.

           IF  MIR-BON-DIV-SEQ-NUM = SPACES
           OR  MIR-BON-DIV-SEQ-NUM = '000'
               MOVE 001               TO WBNDV-BON-DIV-SEQ-NUM
           ELSE
               MOVE MIR-BON-DIV-SEQ-NUM
                                      TO WS-PIC-999
               COMPUTE WBNDV-BON-DIV-SEQ-NUM = 1000 - WS-PIC-999
           END-IF.
018763*    MOVE MIR-FND-ID       TO WBNDV-FND-ID.

       8000-BUILD-BNDV-KEY-X.
           EXIT.
      /
      *-----------------------
       8510-SET-UP-BNDD-BR-KEY.
      *-----------------------


           MOVE SPACES                TO WBNDD-KEY.
           MOVE MIR-POL-ID-BASE       TO WBNDD-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WBNDD-POL-ID-SFX.
           MOVE MIR-BON-DIV-TYP-CD    TO WBNDD-BON-DIV-TYP-CD.
           IF   MIR-CVG-NUM EQUAL SPACES
           OR   MIR-CVG-NUM = '00'
                MOVE LOW-VALUES       TO WBNDD-CVG-NUM
           ELSE
                MOVE MIR-CVG-NUM      TO WBNDD-CVG-NUM
           END-IF.

           MOVE WS-EFF-DT             TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
              THRU  1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE   TO WBNDD-BON-DIV-IDT-NUM.


           IF  MIR-BON-DIV-SEQ-NUM = SPACES
           OR  MIR-BON-DIV-SEQ-NUM = '000'
               MOVE 001               TO WBNDD-BON-DIV-SEQ-NUM
           ELSE
               MOVE MIR-BON-DIV-SEQ-NUM
                                      TO WS-PIC-999
               COMPUTE WBNDD-BON-DIV-SEQ-NUM = 1000 - WS-PIC-999
           END-IF.


           MOVE WBNDD-KEY             TO WBNDD-ENDBR-KEY.

           IF MIR-CVG-NUM EQUAL SPACES
           OR MIR-CVG-NUM = '00'
              MOVE HIGH-VALUES        TO WBNDD-ENDBR-CVG-NUM
           END-IF.

           MOVE HIGH-VALUES           TO WBNDD-ENDBR-BON-DIV-IDT-NUM.
           MOVE '999'                 TO WBNDD-ENDBR-BON-DIV-SEQ-NUM.

       8510-SET-UP-BNDD-BR-KEY-X.
           EXIT.
      /
      /
      *
      *  SET EACH NON-KEY FIELD TO SPACES
      *
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           IF WS-BUS-FCN-LIST
               MOVE SPACES            TO MIR-CVG-NUM-G
               MOVE SPACES            TO MIR-BON-DIV-TYP-CD-G
               MOVE SPACES            TO MIR-BON-DIV-IDT-NUM-G
               MOVE SPACES            TO MIR-BON-DIV-SEQ-NUM-G
               MOVE SPACES            TO MIR-BON-DIV-STAT-CD-G
               MOVE SPACES            TO MIR-BON-DIV-TRXN-CD-G
               MOVE SPACES            TO MIR-BON-DIV-PUA-AMT-G
016016         MOVE SPACES            TO MIR-FND-ID-G
           ELSE
               MOVE SPACES            TO MIR-BON-DIV-STAT-CD
               MOVE SPACES            TO MIR-BON-DIV-TRXN-AMT
               MOVE SPACES            TO MIR-BON-DIV-TRXN-CD
               MOVE SPACES            TO MIR-BON-DIV-PUA-AMT
               MOVE SPACES            TO MIR-EFF-IDT-NUM
016016         MOVE SPACES            TO MIR-FND-ID
023436         MOVE SPACES            TO MIR-CDAD-PAYO-MTHD-CD-G
023436         MOVE SPACES            TO MIR-CDA-EFF-DT-G
023436         MOVE SPACES            TO MIR-CDAD-TRXN-AMT-G
           END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *
      *  MOVE FILE VALUES TO THE SCREEN.
      *
      *-----------------
       9200-LOAD-SCREEN.
      *-----------------

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.
           IF NOT L2430-RELATIONSHIP-FOUND
               MOVE SPACES            TO MIR-DV-OWN-CLI-NM
           ELSE
               INITIALIZE L0620-INPUT-PARM-INFO
               IF L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
015705             MOVE L2430-CLI-MID-INIT-NM
015705                                TO L0620-CLI-MID-INIT-NM
015705             MOVE L2430-CLI-SFX-NM
015705                                TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD  TO L0620-CLI-SEX-CD

               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X

               MOVE L0620-SCREEN-NAME TO MIR-DV-OWN-CLI-NM
           END-IF.

           IF WS-BUS-FCN-LIST
               PERFORM  9210-MOVE-DIVH-TO-SCRN
                   THRU 9210-MOVE-DIVH-TO-SCRN-X
                   VARYING I FROM +1 BY +1
                   UNTIL I > WS-MAX-BROWSE-LINES
                   OR WBNDD-IO-EOF

               IF WBNDD-IO-EOF
               AND MIR-BON-DIV-SEQ-NUM-T (1) NOT = SPACES
                   MOVE MIR-BON-DIV-SEQ-NUM-T (1)
                                      TO MIR-BON-DIV-SEQ-NUM
               END-IF

               IF I > WS-MAX-BROWSE-LINES

                   MOVE RBNDV-CVG-NUM TO MIR-CVG-NUM

                   MOVE RBNDV-BON-DIV-TYP-CD
                                      TO MIR-BON-DIV-TYP-CD

                   MOVE RBNDV-BON-DIV-IDT-NUM
                                      TO L1660-INVERTED-DATE
                   PERFORM  1660-3000-CONVERT-INV-TO-INT
                       THRU 1660-3000-CONVERT-INV-TO-INT-X
                   MOVE L1660-INTERNAL-DATE
                                      TO L1640-INTERNAL-DATE
020462*            PERFORM  1640-2000-INTERNAL-TO-EXT
020462*                THRU 1640-2000-INTERNAL-TO-EXT-X
020462             PERFORM  1640-8000-INTERNAL-TO-MIR
020462                 THRU 1640-8000-INTERNAL-TO-MIR-X
                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-BON-DIV-IDT-NUM
020874*            COMPUTE WS-PIC-999 =
020874*                            1000 - RBNDV-BON-DIV-SEQ-NUM
020874*            MOVE WS-PIC-999    TO MIR-BON-DIV-SEQ-NUM
020874             COMPUTE L0290-INPUT-V00  =
020874                             1000 - RBNDV-BON-DIV-SEQ-NUM
020874             MOVE 0                     TO L0290-PRECISION
020874             MOVE LENGTH OF MIR-BON-DIV-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
020874             MOVE L0290-OUTPUT-DATA   TO MIR-BON-DIV-SEQ-NUM
016016             MOVE RBNDV-FND-ID  TO MIR-FND-ID
               END-IF
           ELSE
               MOVE RBNDV-BON-DIV-STAT-CD
                                      TO MIR-BON-DIV-STAT-CD
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             RBNDV-BON-DIV-TRXN-AMT * 100
023443         MOVE RBNDV-DLR-REDC-APP-AMT  TO L0290-INPUT-V02
023443         MOVE 2                       TO L0290-PRECISION
023443         MOVE LENGTH OF MIR-DLR-REDC-APP-AMT
023443                                      TO L0290-MAX-OUT-LEN
023443         SET L0290-SIGN-DISPLAY       TO TRUE
023443         SET L0290-SIGN-FLOAT         TO TRUE
023443         PERFORM 0290-2000-FORMAT-FOR-MIR
023443            THRU 0290-2000-FORMAT-FOR-MIR-X
023443         MOVE L0290-OUTPUT-DATA       TO MIR-DLR-REDC-APP-AMT
020874         MOVE RBNDV-BON-DIV-TRXN-AMT  TO L0290-INPUT-V02
               MOVE 2                 TO L0290-PRECISION
               MOVE LENGTH OF MIR-BON-DIV-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE
               SET L0290-SIGN-DISPLAY        TO TRUE
               SET L0290-SIGN-FLOAT          TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-BON-DIV-TRXN-AMT
               MOVE RBNDV-BON-DIV-TRXN-CD
                                      TO MIR-BON-DIV-TRXN-CD
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             RBNDV-BON-DIV-PUA-AMT  * 100
020874         MOVE RBNDV-BON-DIV-PUA-AMT  TO L0290-INPUT-V02
               MOVE 2                 TO L0290-PRECISION
               MOVE LENGTH OF MIR-BON-DIV-PUA-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA TO MIR-BON-DIV-PUA-AMT
               MOVE RBNDV-EFF-IDT-NUM TO L1660-INVERTED-DATE
               PERFORM  1660-3000-CONVERT-INV-TO-INT
                  THRU  1660-3000-CONVERT-INV-TO-INT-X
               MOVE L1660-INTERNAL-DATE
                                      TO L1640-INTERNAL-DATE
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-EFF-IDT-NUM
016016         MOVE RBNDV-FND-ID      TO MIR-FND-ID

029716         MOVE RBNDV-PREV-DOD-AVB-AMT  TO L0290-INPUT-V02
029716         MOVE 2                 TO L0290-PRECISION
029716         MOVE LENGTH OF MIR-PREV-DOD-AVB-AMT
029716                                TO L0290-MAX-OUT-LEN
029716         SET L0290-SIGN-DISPLAY        TO TRUE
029716         SET L0290-SIGN-FLOAT          TO TRUE
029716         PERFORM 0290-2000-FORMAT-FOR-MIR
029716            THRU 0290-2000-FORMAT-FOR-MIR-X
029716         MOVE L0290-OUTPUT-DATA TO MIR-PREV-DOD-AVB-AMT
029716
023436         IF  RBNDV-BON-DIV-TYP-DIV
023436             PERFORM  9220-GET-CDSD-DATA
023436                 THRU 9220-GET-CDSD-DATA-X
023436         END-IF

           END-IF.

       9200-LOAD-SCREEN-X.
           EXIT.
      /
      *-----------------------
       9210-MOVE-DIVH-TO-SCRN.
      *-----------------------

           MOVE RBNDV-CVG-NUM         TO MIR-CVG-NUM-T (I).

           MOVE RBNDV-BON-DIV-TYP-CD  TO MIR-BON-DIV-TYP-CD-T (I).

           MOVE RBNDV-BON-DIV-IDT-NUM TO L1660-INVERTED-DATE.
           PERFORM  1660-3000-CONVERT-INV-TO-INT
               THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE   TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM  1640-8000-INTERNAL-TO-MIR
020462         THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-BON-DIV-IDT-NUM-T (I).


020874*    COMPUTE WS-PIC-999 = 1000 - RBNDV-BON-DIV-SEQ-NUM.
020874*    MOVE WS-PIC-999            TO MIR-BON-DIV-SEQ-NUM-T (I).
020874     COMPUTE L0290-INPUT-V00  =  1000 - RBNDV-BON-DIV-SEQ-NUM.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-BON-DIV-SEQ-NUM-T (I)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA   TO MIR-BON-DIV-SEQ-NUM-T (I).
           IF I = 1
              MOVE WS-PIC-XXX         TO MIR-BON-DIV-SEQ-NUM
           END-IF.

           MOVE RBNDV-BON-DIV-STAT-CD TO MIR-BON-DIV-STAT-CD-T (I).
           MOVE RBNDV-BON-DIV-TRXN-CD TO MIR-BON-DIV-TRXN-CD-T (I).

020874*    COMPUTE L0290-INPUT-NUMBER =
020874*            RBNDV-BON-DIV-PUA-AMT  * 100
020874     MOVE RBNDV-BON-DIV-PUA-AMT TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION
           MOVE LENGTH OF MIR-BON-DIV-PUA-AMT-T
                                      TO L0290-MAX-OUT-LEN
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-BON-DIV-PUA-AMT-T (I).

016016     MOVE RBNDV-FND-ID          TO MIR-FND-ID-T (I).

           PERFORM  BNDD-2000-READ-NEXT
               THRU BNDD-2000-READ-NEXT-X.


       9210-MOVE-DIVH-TO-SCRN-X.
           EXIT.
023436/
023436*-------------------
023436 9220-GET-CDSD-DATA.
023436*-------------------
023436
023436     INITIALIZE                       WCDSD-KEY.
023436     MOVE WBNDV-POL-ID             TO WCDSD-POL-ID.
023436     MOVE WBNDV-BON-DIV-IDT-NUM    TO WCDSD-CDA-EFF-IDT-NUM.
023436
023436     EVALUATE TRUE
023436
023436         WHEN RBNDV-BON-DIV-TRXN-SURR
023436
023436              IF RBNDV-BON-DIV-PUA-AMT > ZERO
023436                  SET  WCDSD-CDA-TYP-PUA-SURR  TO TRUE
023436              ELSE
023436                  SET  WCDSD-CDA-TYP-DIV-WTHDR TO TRUE
023436              END-IF
023436
023436         WHEN RBNDV-BON-DIV-TRXN-DCLR
023436              SET  WCDSD-CDA-TYP-DIV       TO TRUE
023436
023436     END-EVALUATE.
023436
023436     MOVE RBNDV-CDA-SEQ-NUM        TO WCDSD-CDA-SEQ-NUM.
023436     MOVE +000                     TO WCDSD-POL-PAYO-NUM.
023436     MOVE +001                     TO WCDSD-CDAD-ALLOC-NUM.
023436
023436     MOVE HIGH-VALUES              TO WCDSD-ENDBR-KEY.
023436     MOVE WCDSD-KEY                TO WCDSD-ENDBR-KEY.
023436     MOVE +999                     TO WCDSD-ENDBR-CDAD-ALLOC-NUM.
023436*
023436     PERFORM  CDSD-1000-BROWSE
023436         THRU CDSD-1000-BROWSE-X.
023436
023436     IF NOT WCDSD-IO-OK
023436* MSG: CDSD NOT FOUND FOR LINKED TO BNDV FOR DIVIDEND
023436        MOVE 'CS43400012'      TO WGLOB-MSG-REF-INFO
023436        PERFORM  0260-1000-GENERATE-MESSAGE
023436            THRU 0260-1000-GENERATE-MESSAGE-X
023436        GO TO 9220-GET-CDSD-DATA-X
023436     END-IF.
023436
023436     PERFORM  CDSD-2000-READ-NEXT
023436         THRU CDSD-2000-READ-NEXT-X.
023436
023436     PERFORM  9230-LOAD-CDSD-DATA
023436         THRU 9230-LOAD-CDSD-DATA-X
023436     VARYING I FROM +1 BY +1
023436       UNTIL I > WS-MAX-CDSD-LINES
023436          OR WCDSD-IO-EOF.
023436*
023436     PERFORM  CDSD-3000-END-BROWSE
023436         THRU CDSD-3000-END-BROWSE-X.
023436
023436 9220-GET-CDSD-DATA-X.
023436     EXIT.
023436/
023436*--------------------
023436 9230-LOAD-CDSD-DATA.
023436*--------------------
023436
023436     IF WCDSD-IO-OK
023436        MOVE RCDSD-CDA-EFF-DT      TO L1640-INTERNAL-DATE
023436        PERFORM  1640-8000-INTERNAL-TO-MIR
023436            THRU 1640-8000-INTERNAL-TO-MIR-X
023436        MOVE L1640-EXTERNAL-DATE   TO MIR-CDA-EFF-DT-T (I)
023436*
023436        MOVE RCDSD-CDAD-TRXN-AMT   TO L0290-INPUT-V02
023436        MOVE 2                     TO L0290-PRECISION
023436        MOVE LENGTH OF MIR-CDAD-TRXN-AMT-T
023436                                   TO L0290-MAX-OUT-LEN
023436        PERFORM  0290-2000-FORMAT-FOR-MIR
023436            THRU 0290-2000-FORMAT-FOR-MIR-X
023436        MOVE L0290-OUTPUT-DATA     TO
023436                                   MIR-CDAD-TRXN-AMT-T (I)
023436*
023436        MOVE RCDSD-CDAD-PAYO-MTHD-CD
023436                                   TO
023436                               MIR-CDAD-PAYO-MTHD-CD-T (I)
023436     ELSE
023436* MSG: CDSD NOT FOUND FOR LINKED TO BNDV FOR DIVIDEND
023436        MOVE +10                   TO I
023436        MOVE 'CS43400012'          TO WGLOB-MSG-REF-INFO
023436        PERFORM  0260-1000-GENERATE-MESSAGE
023436            THRU 0260-1000-GENERATE-MESSAGE-X
023436     END-IF.
023436
023436     PERFORM  CDSD-2000-READ-NEXT
023436         THRU CDSD-2000-READ-NEXT-X.
023436
023436 9230-LOAD-CDSD-DATA-X.
023436     EXIT.
      /
      *
      * MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      * TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET WGLOB-REF-POLICY       TO TRUE.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8935-0000-INIT-PARM-INFO
025970         THRU 8935-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WWKDT-WORK-FIELDS.
025970     SET  WS-TWRK-KEY-DEFAULT         TO TRUE.
025970     SET  WS-MAX-BROWSE-LINES-DEFAULT TO TRUE.
025970     SET  WS-MAX-CDSD-LINES-DEFAULT   TO TRUE.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ******************************************************************
      *                      PROCESSING COPYBOOKS                      *
      ******************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

026057 COPY CCPPIHSD.
       COPY XCPPEXIT.
       COPY XCPPINIT.
014660*COPY XCPPMEXT.
018763 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
018763                         '$VAR2' BY 'POL'.
      /
025970 COPY XCPS1670.
025970 COPY XCPS8090.
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0620.
      /
      ******************************************************************
      *                      LINK COPYBOOKS                            *
      ******************************************************************
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      /
018764*COPY CCCL2430.
018764 COPY CCPL2430.
       COPY CCPS2430.
      /
018764*COPY CCCL8935.
018764 COPY CCPL8935.
016016 COPY CCPS8935.
016016/
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL0290.
       COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
021930*COPY XCPS8090.
      /
      ******************************************************************
      *                     FILE HANDLING COPYBOOKS                    *
      ******************************************************************
       COPY CCPNPOL.
018763 COPY CCPUPOL.
      /
       COPY CCPNBNDV.
      /
       COPY CCPBBNDD.
      /
023436 COPY CCPBCDSD.
023436
016537*COPY CCPVBNDD.
016537*COPY CCPNBNDD.
      /
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM4340                     **
      *****************************************************************


