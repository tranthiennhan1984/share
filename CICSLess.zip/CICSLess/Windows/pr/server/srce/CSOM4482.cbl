      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4482.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4482                                         **
      **  REMARKS:  PGAL - POLICY GAIN ALLOCATION UPDATE             **
      **            THIS MODULE UPDATES THE PGAL TABLE               **
      **  DOMAIN :  PR                                               **
      **                                                             **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
015290**  6.3       PRE & POST TEFRA PROCESSING ENHANCEMENTS         **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021311**  6.4       MULTI-PLATFORM SUPPORT                           **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4482'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

025970 01  WS-CONSTANT-AREA.
025970     05  WS-TWRK-KEY                  PIC X(04)
025970                                      VALUE '4480'.
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '4480'.
025970     05  WS-MAX-ALLOC-TYP             PIC S9(04) BINARY
025970                                      VALUE +9.
025970         88  WS-MAX-ALLOC-TYP-DEFAULT VALUE +9.
025970
       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-UPDATE        VALUE '4482'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '4480'.
           05  WS-SUB                       PIC S9(04) BINARY.
025970*    05  WS-MAX-ALLOC-TYP             PIC S9(04) BINARY
025970*                                     VALUE +9.
           05  WS-POL-ID.
               10  WS-POL-ID-BASE           PIC X(09).
               10  WS-POL-ID-SFX            PIC X(01).
           05  WS-EFF-DT                    PIC X(10).
           05  WS-SEQ-NUM                   PIC S9(03)       COMP-3.
           05  WS-TRXN-INFO                 OCCURS 9 TIMES.
               10  WS-PGAL-ALLOC-TYP-CD     PIC X(01).
               10  WS-TRXN-PRIN-AMT         PIC S9(13)V99    COMP-3.
               10  WS-TRXN-GAIN-AMT         PIC S9(13)V99    COMP-3.
               10  WS-TRXN-CHRG-AMT         PIC S9(13)V99    COMP-3.
           05  WS-NEW-TOT-AMT               PIC S9(13)V99    COMP-3.
           05  WS-OLD-TOT-AMT               PIC S9(13)V99    COMP-3.
           05  WS-TOT-PRIN-AMT              PIC S9(13)V99    COMP-3.
           05  WS-TOT-GAIN-AMT              PIC S9(13)V99    COMP-3.
           05  WS-TOT-CHRG-AMT              PIC S9(13)V99    COMP-3.
           05  WS-SAVE-TOT-PRIN-AMT         PIC S9(13)V99    COMP-3.
           05  WS-SAVE-TOT-GAIN-AMT         PIC S9(13)V99    COMP-3.
           05  WS-SAVE-TOT-CHRG-AMT         PIC S9(13)V99    COMP-3.
           05  WS-PGAL-CREATE-IND           PIC X(01).
               88  WS-PGAL-CREATE-NO        VALUE 'N'.
               88  WS-PGAL-CREATE-YES       VALUE 'Y'.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
      /
       COPY CCWWLOCK.
       COPY CCWWINDX.
026057 COPY CCWWIHSD.
026057 COPY XCWWWKDT.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFWPGAL.
       COPY CCFRPGAL.
       COPY CCFHPGAL.
       COPY CCFWPGAS.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
       COPY CCFRCVG.
       COPY CCFWCVG.
       COPY CCWWCVGS.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
020478 COPY CCWL2626.
       COPY CCWL7290.
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
021930*COPY XCWL1670.
021930*COPY XCWL1680.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
       COPY XCWL8090.
021930*COPY XCWEBLCH.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM4482.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

021311     PERFORM  9990-INIT-WORKING-STORAGE
021311         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

025970*    SET  MIR-RETRN-OK              TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.
021311*    MOVE MIR-POL-ID-BASE           TO WS-POL-ID-BASE.
021311*    MOVE MIR-POL-ID-SFX            TO WS-POL-ID-SFX.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM 5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM4482'       TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                                          TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------

           PERFORM  8000-BLANK-TRXN-AMT
               THRU 8000-BLANK-TRXN-AMT-X
               VARYING WS-SUB FROM +1 BY +1
                 UNTIL WS-SUB > WS-MAX-ALLOC-TYP.

021311     MOVE MIR-PGAL-SEQ-NUM          TO WS-SEQ-NUM.

           PERFORM  8200-BUILD-KEY
               THRU 8200-BUILD-KEY-X.

           PERFORM  5200-EDIT-KEY
               THRU 5200-EDIT-KEY-X.

           IF  WGLOB-RETURN-ERROR
               IF  MIR-RETRN-TS-MISMATCH
                   CONTINUE
               ELSE
                   PERFORM  POL-3000-UNLOCK
                       THRU POL-3000-UNLOCK-X
               END-IF
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

021311*    MOVE MIR-PGAL-SEQ-NUM          TO WS-SEQ-NUM.

           PERFORM  5300-GET-TRXN-TOT-AMT
               THRU 5300-GET-TRXN-TOT-AMT-X.

           IF HPGAL-PGAL-TRXN-STAT-HIST
           OR HPGAL-PGAL-TRXN-STAT-REVRS
      *MSG:  CANNOT UPDATE PGAL RECORD WITH REVERSED/HISTORY STATUS
               MOVE 'CS44820003'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR     TO TRUE
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.


           PERFORM  5400-EDIT-DATA
               THRU 5400-EDIT-DATA-X
               VARYING WS-SUB FROM +1 BY +1
                 UNTIL WS-SUB > WS-MAX-ALLOC-TYP
                    OR WGLOB-RETURN-ERROR.

           PERFORM  5350-CHECK-TOT-AMT
               THRU 5350-CHECK-TOT-AMT-X.

           IF  WGLOB-RETURN-ERROR
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.


           SET  WS-PGAL-CREATE-NO    TO TRUE.
           PERFORM  5600-UPDATE-PGAL-REC
               THRU 5600-UPDATE-PGAL-REC-X
               VARYING WS-SUB FROM +1 BY +1
                 UNTIL WS-SUB > WS-MAX-ALLOC-TYP
                    OR WGLOB-RETURN-ERROR.


           IF  NOT WGLOB-RETURN-ERROR
           AND HPGAL-PGAL-TRXN-STAT-ACTV
               PERFORM  5800-PGAL-ROLL-FRWD
                   THRU 5800-PGAL-ROLL-FRWD-X
           END-IF.


           IF  WGLOB-RETURN-ERROR
               PERFORM  POL-3000-UNLOCK
                   THRU POL-3000-UNLOCK-X
           ELSE
      *MSG: WARNING - MANUAL UPDATE MAY BE REQUIRED ON POLICY
      *               TAX UPDATE
               MOVE 'CS44820005'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  POL-2000-REWRITE
                   THRU POL-2000-REWRITE-X
               PERFORM  POL-1000-READ-TWRK-TS
                   THRU POL-1000-READ-TWRK-TS-X
           END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *---------------
       5200-EDIT-KEY.
      *---------------

           IF  WS-POL-ID   = SPACES
      *MSG:    POLICY ID IS REQUIRED
               MOVE 'CS44820001'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR     TO TRUE
               GO TO 5200-EDIT-KEY-X
           END-IF.

           MOVE WS-POL-ID                 TO WPOL-POL-ID.

           PERFORM  POL-2000-UPDATE-TWRK-TS
               THRU POL-2000-UPDATE-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG:  REQUESTED POLICY NOT FOUND
               MOVE 'CS44820002'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR     TO TRUE
               GO TO 5200-EDIT-KEY-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
      *     PROCESS NOT COMPLETE
               MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
               MOVE 'POL'                 TO WGLOB-MSG-PARM (01)
               MOVE WPOL-KEY              TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR     TO TRUE
               GO TO 5200-EDIT-KEY-X
           END-IF.

026057     IF  WGLOB-RETURN-ERROR
026057         GO TO 5200-EDIT-KEY-X
026057     END-IF.
026057
026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-EFF-DT                  TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-2000-CHK-IHSD-PROCESS
026057         THRU IHSD-2000-CHK-IHSD-PROCESS-X.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057        SET WGLOB-RETURN-ERROR     TO TRUE
026057         GO TO 5200-EDIT-KEY-X
026057     END-IF.


       5200-EDIT-KEY-X.
           EXIT.


      *---------------------
       5300-GET-TRXN-TOT-AMT.
      *---------------------

           MOVE ZEROS                 TO WS-TOT-PRIN-AMT.
           MOVE ZEROS                 TO WS-TOT-GAIN-AMT.
           MOVE ZEROS                 TO WS-TOT-CHRG-AMT.
           MOVE ZEROS                 TO WS-SAVE-TOT-PRIN-AMT.
           MOVE ZEROS                 TO WS-SAVE-TOT-GAIN-AMT.
           MOVE ZEROS                 TO WS-SAVE-TOT-CHRG-AMT.

           MOVE WS-POL-ID             TO WPGAS-POL-ID.
           MOVE MIR-PGAL-TRXN-TYP-CD  TO WPGAS-PGAL-TRXN-TYP-CD.
           MOVE WS-EFF-DT             TO WPGAS-PGAL-EFF-DT
           MOVE WS-SEQ-NUM            TO WPGAS-PGAL-SEQ-NUM.
           MOVE LOW-VALUES            TO WPGAS-PGAL-ALLOC-TYP-CD.
           MOVE WPGAS-KEY             TO WPGAS-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WPGAS-ENDBR-PGAL-ALLOC-TYP-CD.

           PERFORM  PGAS-1000-BROWSE
               THRU PGAS-1000-BROWSE-X.

           PERFORM  PGAS-2000-READ-NEXT
               THRU PGAS-2000-READ-NEXT-X.

           IF  NOT WPGAS-IO-OK
      *MSG:  REOCRD NOT FOUND
               MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
               MOVE WPGAL-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR     TO TRUE
               GO TO 5300-GET-TRXN-TOT-AMT-X
           ELSE
               MOVE RPGAL-REC-INFO      TO HPGAL-REC-INFO
               PERFORM  5310-RETRIEVE-ALLOC-REC
                   THRU 5310-RETRIEVE-ALLOC-REC-X
                   UNTIL NOT WPGAS-IO-OK
           END-IF.

           PERFORM  PGAS-3000-END-BROWSE
               THRU PGAS-3000-END-BROWSE-X.

       5300-GET-TRXN-TOT-AMT-X.
           EXIT.


      *------------------------
       5310-RETRIEVE-ALLOC-REC.
      *------------------------

           ADD RPGAL-PGAL-TRXN-PRIN-AMT  TO WS-SAVE-TOT-PRIN-AMT.
           ADD RPGAL-PGAL-TRXN-GAIN-AMT  TO WS-SAVE-TOT-GAIN-AMT.
           ADD RPGAL-PGAL-SURR-CHRG-AMT  TO WS-SAVE-TOT-CHRG-AMT.

           PERFORM  PGAS-2000-READ-NEXT
               THRU PGAS-2000-READ-NEXT-X.

       5310-RETRIEVE-ALLOC-REC-X.
           EXIT.


      *-------------------
       5350-CHECK-TOT-AMT.
      *-------------------

           IF  HPGAL-PGAL-TRXN-STAT-PEND
               PERFORM  5360-CHECK-TOT-AMT-PEND
                   THRU 5360-CHECK-TOT-AMT-PEND-X
               GO TO 5350-CHECK-TOT-AMT-X
           END-IF.

           MOVE ZERO                TO WS-NEW-TOT-AMT.
           MOVE ZERO                TO WS-OLD-TOT-AMT.

           ADD WS-TOT-PRIN-AMT      TO WS-NEW-TOT-AMT.
           ADD WS-TOT-GAIN-AMT      TO WS-NEW-TOT-AMT.
           ADD WS-SAVE-TOT-PRIN-AMT TO WS-OLD-TOT-AMT.
           ADD WS-SAVE-TOT-GAIN-AMT TO WS-OLD-TOT-AMT.

           IF  WS-NEW-TOT-AMT NOT = WS-OLD-TOT-AMT
      *MSG: TRANSACTION PRINCIPAL AND GAIN TOTAL NOT MATCH ORIGINAL
               MOVE 'CS44820006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

           IF  WS-TOT-CHRG-AMT NOT = WS-SAVE-TOT-CHRG-AMT
      *MSG: TRANSACTION FEE AMOUNT NOT MATCH ORIGINAL TOTAL
               MOVE 'CS44820008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

       5350-CHECK-TOT-AMT-X.
           EXIT.

      *-----------------------
       5360-CHECK-TOT-AMT-PEND.
      *------------------------

           MOVE ZERO                TO WS-NEW-TOT-AMT.
           MOVE ZERO                TO WS-OLD-TOT-AMT.

           ADD WS-TOT-PRIN-AMT      TO WS-NEW-TOT-AMT.
           ADD WS-TOT-GAIN-AMT      TO WS-NEW-TOT-AMT.
           ADD WS-SAVE-TOT-PRIN-AMT TO WS-OLD-TOT-AMT.
           ADD WS-SAVE-TOT-GAIN-AMT TO WS-OLD-TOT-AMT.

           IF  WS-NEW-TOT-AMT NOT = WS-OLD-TOT-AMT
      *MSG: PGAL PENDING, TRANSACTION PRINCIPAL AND GAIN TOTAL NOT
      *     MATCH ORIGINAL
               MOVE 'CS44820013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WGLOB-RETURN-ERROR TO TRUE
               END-IF
           END-IF.

           IF  WS-TOT-CHRG-AMT NOT = WS-SAVE-TOT-CHRG-AMT
      *MSG: PGAL PENDING, TRANSACTION FEE AMOUNT NOT MATCH ORIGINAL
      *     TOTAL
               MOVE 'CS44820014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET WGLOB-RETURN-ERROR TO TRUE
               END-IF
           END-IF.

       5360-CHECK-TOT-AMT-PEND-X.
           EXIT.

      /
      *--------------
       5400-EDIT-DATA.
      *--------------

           IF  MIR-PGAL-ALLOC-TYP-CD-T (WS-SUB) = SPACE
               GO TO 5400-EDIT-DATA-X
           END-IF.

           MOVE MIR-PGAL-ALLOC-TYP-CD-T (WS-SUB)
                                          TO WS-PGAL-ALLOC-TYP-CD
                                             (WS-SUB).

      * NUMERIC EDIT TRANSACTION PRINCIPAL AMOUNT

           IF  MIR-PGAL-TRXN-PRIN-AMT-T (WS-SUB) = SPACES
020874*        MOVE ZEROS                 TO L0290-INPUT-NUMBER
020874         MOVE ZEROS                 TO L0290-INPUT-V02
               SET L0290-SIGN-DISPLAY     TO TRUE
               SET L0290-SIGN-POS-DISPLAY TO TRUE
               MOVE 2                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-PGAL-TRXN-PRIN-AMT-T (WS-SUB)
                                          TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA
                                          TO MIR-PGAL-TRXN-PRIN-AMT-T
                                             (WS-SUB)
               MOVE ZEROS                 TO WS-TRXN-PRIN-AMT (WS-SUB)
           ELSE
               MOVE MIR-PGAL-TRXN-PRIN-AMT-T (WS-SUB)
                                          TO L0280-INPUT-DATA
               MOVE 'Y'                   TO L0280-SIGN-IND
               MOVE 2                     TO L0280-PRECISION
               MOVE LENGTH OF MIR-PGAL-TRXN-PRIN-AMT-T (WS-SUB)
                                          TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
                                      L0280-PRECISION - 1
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   MOVE L0280-OUTPUT-DOLLAR
                                          TO WS-TRXN-PRIN-AMT (WS-SUB)
               ELSE
      *MSG: TRANSACTION CONTRIBUTION AMOUNT NOT A VALID NUMERIC VALUE
                   MOVE 'CS44820010'      TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR TO TRUE
               END-IF
           END-IF.

      * NUMERIC EDIT TRANSACTION GAIN AMOUNT

           IF  MIR-PGAL-TRXN-GAIN-AMT-T (WS-SUB) = SPACES
020874*        MOVE ZEROS                 TO L0290-INPUT-NUMBER
020874         MOVE ZEROS                 TO L0290-INPUT-V02
               SET L0290-SIGN-DISPLAY     TO TRUE
               SET L0290-SIGN-POS-DISPLAY TO TRUE
               MOVE 2                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-PGAL-TRXN-GAIN-AMT-T (WS-SUB)
                                          TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA     TO MIR-PGAL-TRXN-GAIN-AMT-T
                                             (WS-SUB)
               MOVE ZEROS                 TO WS-TRXN-GAIN-AMT (WS-SUB)
           ELSE
               MOVE MIR-PGAL-TRXN-GAIN-AMT-T (WS-SUB)
                                          TO L0280-INPUT-DATA
               MOVE 'Y'                   TO L0280-SIGN-IND
               MOVE 2                     TO L0280-PRECISION
               MOVE LENGTH OF MIR-PGAL-TRXN-GAIN-AMT-T (WS-SUB)
                                          TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
                                      L0280-PRECISION - 1
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   MOVE L0280-OUTPUT-DOLLAR
                                          TO WS-TRXN-GAIN-AMT (WS-SUB)
               ELSE
      *MSG: TRANSACTION GAIN AMOUNT NOT A VALID NUMERIC VALUE
                   MOVE 'CS44820011'      TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR TO TRUE
               END-IF
           END-IF.

      * NUMERIC EDIT TRANSACTION FEE AMOUNT

           IF  MIR-PGAL-SURR-CHRG-AMT-T (WS-SUB) = SPACES
020874*        MOVE ZEROS                 TO L0290-INPUT-NUMBER
020874         MOVE ZEROS                 TO L0290-INPUT-V02
               SET L0290-SIGN-DISPLAY     TO TRUE
               SET L0290-SIGN-POS-DISPLAY TO TRUE
               MOVE 2                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-PGAL-SURR-CHRG-AMT-T (WS-SUB)
                                          TO L0290-MAX-OUT-LEN
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM  0290-2000-FORMAT-FOR-MIR
020874             THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA     TO MIR-PGAL-SURR-CHRG-AMT-T
                                             (WS-SUB)
               MOVE ZEROS                 TO WS-TRXN-CHRG-AMT (WS-SUB)
           ELSE
               MOVE MIR-PGAL-SURR-CHRG-AMT-T (WS-SUB)
                                          TO L0280-INPUT-DATA
               MOVE 'Y'                   TO L0280-SIGN-IND
               MOVE 2                     TO L0280-PRECISION
               MOVE LENGTH OF MIR-PGAL-SURR-CHRG-AMT-T (WS-SUB)
                                          TO L0280-INPUT-SIZE
               COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
                                      L0280-PRECISION - 1
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
                   MOVE L0280-OUTPUT-DOLLAR
                                          TO WS-TRXN-CHRG-AMT (WS-SUB)
               ELSE
      *MSG: TRANSACTION FEE AMOUNT NOT A VALID NUMERIC VALUE
                   MOVE 'CS44820012'      TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET WGLOB-RETURN-ERROR TO TRUE
               END-IF
           END-IF.

           ADD  WS-TRXN-PRIN-AMT (WS-SUB)  TO WS-TOT-PRIN-AMT.
           ADD  WS-TRXN-GAIN-AMT (WS-SUB)  TO WS-TOT-GAIN-AMT.
           ADD  WS-TRXN-CHRG-AMT (WS-SUB)  TO WS-TOT-CHRG-AMT.


       5400-EDIT-DATA-X.
           EXIT.
      /
      *---------------------------
       5600-UPDATE-PGAL-REC.
      *---------------------------

           IF  WS-PGAL-ALLOC-TYP-CD (WS-SUB) = SPACES
               GO TO 5600-UPDATE-PGAL-REC-X
           END-IF.

           PERFORM  8200-BUILD-KEY
               THRU 8200-BUILD-KEY-X.

           MOVE WS-PGAL-ALLOC-TYP-CD (WS-SUB)
                                          TO WPGAL-PGAL-ALLOC-TYP-CD.

           PERFORM  PGAL-1000-READ-FOR-UPDATE
               THRU PGAL-1000-READ-FOR-UPDATE-X.

           IF  NOT WPGAL-IO-OK
               PERFORM  5700-CREATE-PGAL-REC
                   THRU 5700-CREATE-PGAL-REC-X
           ELSE
               MOVE WS-TRXN-PRIN-AMT (WS-SUB)
                                          TO RPGAL-PGAL-TRXN-PRIN-AMT
               MOVE WS-TRXN-GAIN-AMT (WS-SUB)
                                          TO RPGAL-PGAL-TRXN-GAIN-AMT
               MOVE WS-TRXN-CHRG-AMT (WS-SUB)
                                          TO RPGAL-PGAL-SURR-CHRG-AMT
               PERFORM  PGAL-2000-REWRITE
                   THRU PGAL-2000-REWRITE-X
               IF  NOT WPGAL-IO-OK
                   SET WGLOB-RETURN-ERROR TO TRUE
               END-IF
           END-IF.

       5600-UPDATE-PGAL-REC-X.
           EXIT.

      *--------------------
       5700-CREATE-PGAL-REC.
      *--------------------

           IF  WS-TRXN-PRIN-AMT (WS-SUB) = ZERO
           AND WS-TRXN-GAIN-AMT (WS-SUB) = ZERO
           AND WS-TRXN-CHRG-AMT (WS-SUB) = ZERO
               GO TO 5700-CREATE-PGAL-REC-X
           END-IF.


           MOVE HPGAL-REC-INFO           TO RPGAL-REC-INFO.

           MOVE ZERO                     TO RPGAL-PGAL-OPN-PRIN-AMT.
           MOVE ZERO                     TO RPGAL-PGAL-OPN-GAIN-AMT.
           MOVE WS-PGAL-ALLOC-TYP-CD (WS-SUB)
                                         TO RPGAL-PGAL-ALLOC-TYP-CD.
           MOVE WS-TRXN-PRIN-AMT (WS-SUB)
                                         TO RPGAL-PGAL-TRXN-PRIN-AMT.
           MOVE WS-TRXN-GAIN-AMT (WS-SUB)
                                         TO RPGAL-PGAL-TRXN-GAIN-AMT.
           MOVE WS-TRXN-CHRG-AMT (WS-SUB)
                                         TO RPGAL-PGAL-SURR-CHRG-AMT.

           PERFORM  PGAL-1000-WRITE
               THRU PGAL-1000-WRITE-X.

           IF  NOT WPGAL-IO-OK
      *MSG: CANNOT CREATE PGAL RECORD
               MOVE 'CS44820009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 5700-CREATE-PGAL-REC-X
           END-IF.

           SET WS-PGAL-CREATE-YES     TO TRUE.

       5700-CREATE-PGAL-REC-X.
           EXIT.


      *--------------------
       5800-PGAL-ROLL-FRWD.
      *--------------------

           PERFORM  7290-0000-INIT-PARM-INFO
               THRU 7290-0000-INIT-PARM-INFO-X.

           SET L7290-PRCES-TYP-ALL   TO TRUE.
           MOVE WS-EFF-DT            TO L7290-PGAL-EFF-DT.
           MOVE WS-SEQ-NUM           TO L7290-PGAL-SEQ-NUM.

           PERFORM  7290-1000-PRCES-ROLL-FORWARD
               THRU 7290-1000-PRCES-ROLL-FORWARD-X.

           IF  NOT L7290-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

       5800-PGAL-ROLL-FRWD-X.
           EXIT.

      /
      *---------------------------
       8000-BLANK-TRXN-AMT.
      *---------------------------

           MOVE ZEROS                    TO WS-TRXN-PRIN-AMT (WS-SUB).
           MOVE ZEROS                    TO WS-TRXN-GAIN-AMT (WS-SUB).
           MOVE ZEROS                    TO WS-TRXN-CHRG-AMT (WS-SUB).

           MOVE SPACES                   TO WS-PGAL-ALLOC-TYP-CD
                                            (WS-SUB).

       8000-BLANK-TRXN-AMT-X.
           EXIT.
      /
      *---------------------------
       8200-BUILD-KEY.
      *---------------------------

           MOVE WS-POL-ID                TO WPOL-POL-ID.

           MOVE WS-POL-ID                TO WPGAL-POL-ID.

           MOVE MIR-PGAL-EFF-DT          TO L1640-EXTERNAL-DATE
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      * MSG: INVALID DATE
               MOVE 'XS00000036'         TO WGLOB-MSG-REF-INFO
               MOVE MIR-PGAL-EFF-DT      TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR    TO TRUE
           ELSE
               MOVE L1640-INTERNAL-DATE  TO WS-EFF-DT
           END-IF.

           MOVE WS-EFF-DT                TO WPGAL-PGAL-EFF-DT.
           MOVE WS-SEQ-NUM               TO WPGAL-PGAL-SEQ-NUM.

       8200-BUILD-KEY-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
021311*--------------------------
021311 9990-INIT-WORKING-STORAGE.
021311*--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
021311
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7290-0000-INIT-PARM-INFO
025970         THRU 7290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     SET  WS-TWRK-KEY-DEFAULT         TO TRUE.
025970     SET  WS-MAX-ALLOC-TYP-DEFAULT    TO TRUE.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
021311     MOVE MIR-POL-ID-BASE          TO WS-POL-ID-BASE.
021311     MOVE MIR-POL-ID-SFX           TO WS-POL-ID-SFX.
021311
021311 9990-INIT-WORKING-STORAGE-X.
021311     EXIT.
021311/
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
026057 COPY CCPPIHSD.
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
       COPY NCPPCVGS.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
025970 COPY XCPS1670.
025970 COPY XCPS8090.
       COPY CCPS7290.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
       COPY CCPL7290.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
021930*COPY XCPS8090.
       COPY XCPL8090.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
021930*COPY XCPL1680.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
021930*COPY CCPNPGAL.
       COPY CCPUPGAL.
       COPY CCPAPGAL.
       COPY CCPBPGAS.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
       COPY CCPNCVG.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM4482                     *
      ****************************************************************
