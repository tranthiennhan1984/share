      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM1213.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM1213                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE DELETE RECORD FUNCTION  **
      **            FOR THE RT TABLE                                 **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
012624**  6.0       DESCRIPTION                                      **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015543**  6.0       CODE CLEANUP                                     **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
012525**  6.3       POLICY TERM AND CESSATION AGE (6.1.1E)           **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM1213'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

014590*COPY XCWL0030.
      *
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-DELETE            VALUE '1213'.
025970*    05  WS-TWRK-KEY                      PIC X(04)
025970*                                         VALUE '1210'.

025970 01  WS-CONSTANT-FIELDS.
025970     05  WS-TWRK-KEY                      PIC X(04).  
025970         88  WS-TWRK-KEY-DEFAULT          VALUE '1210'. 

      *
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
016537*COPY XCWWWKDT.
014221 COPY CCWWLOCK.
      *
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      *
       COPY CCFWRT.
       COPY CCFRRT.
      *
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
018764*COPY XCWLPTR.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
014221 COPY XCWL8090.
      *
      *****************************************************************
      *  INPUT PARAMETER INFORMATION                                  *
      *****************************************************************
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM1213.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      *
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  2000-DELETE
                        THRU 2000-DELETE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID        TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM1213'            TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'          TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'          TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      *
      *--------------
       2000-DELETE.
      *--------------
      *
      *  THE RECORD MUST EXIST ON A DELETE
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF MIR-RETRN-EDIT-ERROR
               GO TO 2000-DELETE-X
           END-IF.

           PERFORM RT-1000-BROWSE
              THRU RT-1000-BROWSE-X.
           PERFORM RT-2000-READ-NEXT
              THRU RT-2000-READ-NEXT-X.

           IF WRT-IO-EOF
      *MSG: 'RECORD (@1) ON TABLE (@2) NOT FOUND. DELETE FAILED'
               MOVE WRT-KEY                TO WGLOB-MSG-PARM (1)
               MOVE 'TRT'                  TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000010'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED   TO TRUE
               PERFORM RT-3000-END-BROWSE
                  THRU RT-3000-END-BROWSE-X
               GO TO 2000-DELETE-X
           END-IF.

           PERFORM RT-3000-END-BROWSE
              THRU RT-3000-END-BROWSE-X.

014221     PERFORM RT-2000-UPDATE-TWRK-TS
014221        THRU RT-2000-UPDATE-TWRK-TS-X.

014221     IF  WRT-IO-NOT-FOUND
014221*MSG: RECORD (@1) NOT FOUND
014221         MOVE WRT-KEY            TO WGLOB-MSG-PARM (1)
014221         MOVE 'RT'               TO WGLOB-MSG-PARM (2)
014221         MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 2000-DELETE-X
014221     END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
014221*     PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'       TO WGLOB-MSG-REF-INFO
014221         MOVE 'RT'               TO WGLOB-MSG-PARM (01)
014221         MOVE WRT-KEY            TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 2000-DELETE-X
014221     END-IF.

014221     PERFORM RT-3000-UNLOCK
014221        THRU RT-3000-UNLOCK-X.

           PERFORM RT-1000-DELETE-KEY-RANGE
              THRU RT-1000-DELETE-KEY-RANGE-X.

       2000-DELETE-X.
           EXIT.
      *
      *----------------
       7000-BUILD-KEYS.
      *----------------

           PERFORM 0290-1000-BUILD-PARM-INFO
              THRU 0290-1000-BUILD-PARM-INFO-X.
           MOVE LOW-VALUES             TO WRT-KEY.
           MOVE MIR-RTBL-DB-OPT-CD     TO WRT-RTBL-DB-OPT-CD.
           MOVE MIR-RTBL-JNT-LIFE-CD   TO WRT-RTBL-JNT-LIFE-CD.
           MOVE MIR-LOC-GR-ID          TO WRT-LOC-GR-ID.
           MOVE MIR-RTBL-PAR-CD        TO WRT-RTBL-PAR-CD.
           MOVE MIR-RTBL-PNSN-QUALF-CD TO WRT-RTBL-PNSN-QUALF-CD.
           MOVE MIR-RTBL-RT-TYP-CD     TO WRT-RTBL-RT-TYP-CD.
           MOVE MIR-RTBL-ID            TO WRT-RTBL-ID.
           MOVE MIR-RTBL-SEX-CD        TO WRT-RTBL-SEX-CD.
           MOVE MIR-RTBL-SMKR-CD       TO WRT-RTBL-SMKR-CD.
           MOVE MIR-RTBL-STBL-1-CD     TO WRT-RTBL-STBL-1-CD.
           MOVE MIR-RTBL-STBL-2-CD     TO WRT-RTBL-STBL-2-CD.
           MOVE MIR-RTBL-STBL-3-CD     TO WRT-RTBL-STBL-3-CD.
           MOVE MIR-RTBL-STBL-4-CD     TO WRT-RTBL-STBL-4-CD.

012525     MOVE MIR-RTBL-MAT-XPRY-DUR  TO L0280-INPUT-DATA.
012525     MOVE LENGTH OF MIR-RTBL-MAT-XPRY-DUR TO L0280-INPUT-SIZE.
012525     MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
012525     MOVE ZERO                   TO L0280-PRECISION.
012525     PERFORM 0280-1000-NUMERIC-EDIT
012525          THRU 0280-1000-NUMERIC-EDIT-X.
020874*    MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER.
020874     MOVE L0280-OUTPUT           TO L0290-INPUT-V00.
012525     MOVE LENGTH MIR-RTBL-MAT-XPRY-DUR TO L0290-MAX-OUT-LEN.
012525     MOVE ZERO                   TO L0290-PRECISION.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
012525     MOVE L0290-OUTPUT-DATA      TO WRT-RTBL-MAT-XPRY-DUR.

           MOVE MIR-DPOS-TRM-DY-DUR    TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-DPOS-TRM-DY-DUR TO L0280-INPUT-SIZE.
           MOVE ZERO                   TO L0280-PRECISION.
           MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
020874*    MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER.
020874     MOVE L0280-OUTPUT           TO L0290-INPUT-V00.
015543*    MOVE LENGTH MIR-DPOS-TRM-DY-DUR TO L0290-MAX-OUT-LEN.
015543     MOVE LENGTH OF MIR-DPOS-TRM-DY-DUR TO L0290-MAX-OUT-LEN.
           MOVE ZERO                   TO L0290-PRECISION.
020874*     PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO WRT-DPOS-TRM-DY-DUR.
           MOVE MIR-DPOS-TRM-MO-DUR    TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-DPOS-TRM-MO-DUR TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
           MOVE ZERO                   TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
020874*    MOVE L0280-OUTPUT           TO L0290-INPUT-NUMBER.
020874     MOVE L0280-OUTPUT           TO L0290-INPUT-V00.
015543*    MOVE LENGTH MIR-DPOS-TRM-MO-DUR TO L0290-MAX-OUT-LEN.
015543     MOVE LENGTH OF MIR-DPOS-TRM-MO-DUR TO L0290-MAX-OUT-LEN.
           MOVE ZERO                   TO L0290-PRECISION.
020874*     PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.

           MOVE L0290-OUTPUT-DATA      TO WRT-DPOS-TRM-MO-DUR.
      *
           IF MIR-RTBL-AGE = SPACE
               MOVE SPACE              TO WRT-RTBL-AGE
           ELSE
               MOVE MIR-RTBL-AGE       TO L0280-INPUT-DATA
               MOVE LENGTH OF MIR-RTBL-AGE TO L0280-INPUT-SIZE
               MOVE L0280-INPUT-SIZE   TO L0280-LENGTH
               MOVE ZERO               TO L0280-PRECISION
               PERFORM 0280-1000-NUMERIC-EDIT
                  THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
                   MOVE L0280-OUTPUT   TO WRT-RTBL-AGE-N
               ELSE
                   MOVE 'CS12130002'   TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-EDIT-ERROR TO TRUE
               END-IF
           END-IF.
      *
           MOVE MIR-RTBL-IDT-NUM       TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT                                    
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.                                 
020462     PERFORM 1640-7000-MIR-TO-INT                                         
020462        THRU 1640-7000-MIR-TO-INT-X.
      *
           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE TO L1660-INTERNAL-DATE
               PERFORM 1660-2000-CONVERT-INT-TO-INV
                  THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE TO WRT-RTBL-IDT-NUM-N
           ELSE
               MOVE 'CS12130001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.
      *
           MOVE MIR-RTBL-AGE-DUR       TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-RTBL-AGE-DUR TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
           MOVE ZERO                   TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT       TO WRT-RTBL-AGE-DUR
           ELSE
               MOVE 'CS12130002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.
      *
           MOVE WRT-KEY                TO WRT-ENDBR-KEY.
      *
           MOVE MIR-DV-END-RTBL-AGE-DUR TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-DV-END-RTBL-AGE-DUR TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE       TO L0280-LENGTH.
           MOVE ZERO                   TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.
      *
           IF L0280-OK
               MOVE L0280-OUTPUT       TO WRT-ENDBR-RTBL-AGE-DUR
           ELSE
               MOVE 'CS12130002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-EDIT-ERROR TO TRUE
           END-IF.

       7000-BUILD-KEYS-X.
           EXIT.

      *
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE     TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  WLOCK-TWRK-TIMESTAMP-INFO.
025970
025970     INITIALIZE  WLOCK-TWRK-OTHER-INFO.
025970     SET  WS-TWRK-KEY-DEFAULT        TO TRUE.
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY RT
014221                         '$VAR2' BY 'RT'.

034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      *
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPS0290.
       COPY XCPL0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBRT.
       COPY CCPGRT.
014221*
014221 COPY CCPNRT.
014221 COPY CCPURT.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM1213                     **
      *****************************************************************
