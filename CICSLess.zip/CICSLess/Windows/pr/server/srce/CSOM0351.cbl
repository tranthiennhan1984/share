      *****************************************************************
      **  MEMBER :  CSOM0351                                         **
      **  REMARKS:  PROCESS DRIVER FOR CLIENT FOLLOW-UP - HICL       **
      **            THIS MODULE HANDLES ALL TABLE MAINTENANCE        **
      **            FUNCTIONS FOR THE CLIENT HISTORY (CH) TABLE.     **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       STANDARDIZATION OF CODE STRUCTURE                **
557708**  5.5       MODIFICATIONS FOR CICS ABENDS HANDLING           **
008453**  5.5.2     MULTIPLE EXTERNAL DATE FORMATS                   **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010310**  5.6       REPLACE THE PREVIOUS BROWSE LOGIC BY MAX         **
010310**            FUNCTION FOR THE DETERMINATION OF THE LAST       **
010310**            SEQUENCE NUMBER.                                 **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016387**  6.2       CLIENT CONSOLIDATION REMOVAL                     **
016440**  6.2       COMBINE NB AND ADMIN - ONLINE REQUIREMENTS       **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020460**  6.4       DTCC/IPS CONNECTIVITY                            **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0351.

       COPY XCWWCRHT.
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************
      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0351'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                PIC X(04) VALUE 'HICL'.
           05  WS-FOUND-SW                  PIC X(01)
                                            VALUE 'N'.
               88  FOUND-IT                 VALUE 'Y'.
025970         88  WS-FOUND-NO              VALUE 'N'.               
           05  WS-EDIT-ERROR-SW             PIC X(01).
               88  WS-ALL-EDITS-OK          VALUE 'Y'.
               88  WS-EDITS-FAILED          VALUE 'N'.
025970*    05  WS-NO-MORE-SEQ-NO-SW         PIC X(01)
025970*                                     VALUE 'N'.
025970*        88  NO-MORE-SEQ-NO           VALUE 'Y'.
           05  WS-CONTROL-ERROR             PIC X(01)
                                            VALUE 'N'.
               88  SW-CONTROL-ERROR         VALUE 'Y'.
025970         88  WS-CONTROL-ERROR-NO      VALUE 'N'.               
           05  WS-IF-ANY-RECORDS-DISPLAYED  PIC X(01).
               88  WS-NO-RECORDS-DISPLAYED  VALUE 'N'.
               88  WS-RECORDS-DISPLAYED     VALUE 'Y'.
           05  WS-NEXT-REC-FOUND-SW         PIC X(01)
                                            VALUE 'N'.
               88  WS-NEXT-REC-NOT-FOUND    VALUE 'N'.
               88  WS-NEXT-REC-FOUND        VALUE 'Y'.

           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '1320' '1321' '1322'
                                                  '1323' '1324'.

               88  WS-BUS-FCN-INQUIRE       VALUE '1320'.
               88  WS-BUS-FCN-CREATE        VALUE '1321'.
               88  WS-BUS-FCN-UPDATE        VALUE '1322'.
               88  WS-BUS-FCN-DELETE        VALUE '1323'.
               88  WS-BUS-FCN-LIST          VALUE '1324'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '1320'.
008453*    05  WS-EXTERNAL-DATE             PIC X(9).
           05  WS-SEQ-COUNT                 PIC 99.
           05  WS-SUB                       PIC 99.
           05  WS-LINE-SUB                  PIC 99.
025970*    05  WS-PIC-Z9                    PIC Z9.
025970*        88  HOLD-BR-BROWSE           VALUE 'B'.
           05  WS-BROWSE-TYPE-CD            PIC X(01).
               88  BROWSE-BY-CLIENT         VALUE 'C'.
               88  BROWSE-BY-USERID         VALUE 'U'.
               88  BROWSE-BY-BOTH           VALUE 'B'.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4) COMP VALUE +11.
025970*    05  WS-MAX-BROWSE-LINES          PIC S9(4) BINARY VALUE +11.
           05  WS-FOLWUP-NOTE-TXT-G.
               10  WS-FOLWUP-NOTE-TXT-T     OCCURS 150
                                            PIC X(01).
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                PIC X(04).
025970         88  WS-TRANS-NAME-DEFAULT    VALUE 'HICL'.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '1320'.
025970     05  WS-MAX-BROWSE-LINES          PIC S9(04) BINARY.
025970         88  WS-MAX-BROWSE-LINES-DEFAULT         VALUE +11.
      *
       COPY XCWWWKDT.
      *
      *
028298 COPY CCWL2626.
       COPY XCWL0280.
      *
       COPY XCWEBLCH.
      *
       COPY CCFWCHUA.
       COPY CCFWCH.
       COPY CCFRCH.
014221 COPY CCFWCLI.
014221 COPY CCFRCLI.
016440 COPY CCFWPOL.
016440 COPY CCFRPOL.
      *
       COPY CCWL2435.
      *
014221 COPY CCWWLOCK.
      *
       COPY CCFWRL.
       COPY CCFRRL.
      *
020460 COPY CCWL3188.

016440 COPY CCWL5400.
       COPY CCWL5600.
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      *
       COPY XCWL0220.
      *
       COPY XCWL1640.
020460 COPY XCWL1646.
      *
014221 COPY XCWL8090.
      *
       COPY XCWLDTLK.
      *
       COPY CCFWEDIT.
       COPY CCFREDIT.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0351.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

       0000-MAINLINE.

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      *
      *-------------------
      *
      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.


025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           PERFORM  2100-VALIDATE-CTL-FIELDS
               THRU 2100-VALIDATE-CTL-FIELDS-X.

           IF  SW-CONTROL-ERROR
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF  WS-BUS-FCN-CREATE
               MOVE 'N'               TO WS-CONTROL-ERROR
               PERFORM  2200-VALIDATE-CLIENT
                   THRU 2200-VALIDATE-CLIENT-X
               IF  SW-CONTROL-ERROR
               OR  L5600-CNFD-ACCS-RESTRICTED
                   PERFORM  9100-BLANK-DATA-FIELDS
                       THRU 9100-BLANK-DATA-FIELDS-X
                   GO TO 2000-PROCESS-REQUEST-X
               END-IF
               PERFORM  4000-PROCESS-CREATE
                   THRU 4000-PROCESS-CREATE-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.


           IF  WS-BUS-FCN-INQUIRE
               PERFORM  3000-PROCESS-RETRIEVE
                   THRU 3000-PROCESS-RETRIEVE-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF  WS-BUS-FCN-UPDATE
               PERFORM  5000-PROCESS-UPDATE
                   THRU 5000-PROCESS-UPDATE-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF  WS-BUS-FCN-DELETE
               PERFORM  6000-PROCESS-DELETE
                   THRU 6000-PROCESS-DELETE-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF  WS-BUS-FCN-LIST
               PERFORM  7000-PROCESS-LIST
                   THRU 7000-PROCESS-LIST-X
           END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *-------------------------
       2100-VALIDATE-CTL-FIELDS.
      *-------------------------

           MOVE 'N'                   TO WS-CONTROL-ERROR.

           PERFORM  2200-VALIDATE-CLIENT
               THRU 2200-VALIDATE-CLIENT-X.

           PERFORM  2300-FORMAT-DATE
               THRU 2300-FORMAT-DATE-X.

           IF  WS-BUS-FCN-LIST
           AND MIR-USER-ID    > SPACES
           AND MIR-CLI-ID NOT > SPACES
           AND MIR-CLI-CNTCT-SEQ-NUM NOT = SPACES
               MOVE SPACES            TO MIR-CLI-CNTCT-SEQ-NUM
               MOVE 'CS03510014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  MIR-CLI-CNTCT-SEQ-NUM NOT = SPACES
               PERFORM  2400-FORMAT-SEQUENCE
                   THRU 2400-FORMAT-SEQUENCE-X
           END-IF.

           IF  MIR-USER-ID NOT = SPACES
               PERFORM  2500-EDIT-USER-ID
                   THRU 2500-EDIT-USER-ID-X
           END-IF.


       2100-VALIDATE-CTL-FIELDS-X.
           EXIT.
      *
      *---------------------
       2200-VALIDATE-CLIENT.
      *---------------------
      *
      * VALIDATE CLIENT - ENSURE THE CLIENT EXISTS AND CHECK FOR
      * CONFIDENTIALITY
      *
           IF  MIR-CLI-ID  = SPACES
           AND MIR-USER-ID > SPACES
           AND WS-BUS-FCN-LIST
               GO TO 2200-VALIDATE-CLIENT-X
           END-IF.

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID            TO L2435-CLI-ID.
           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.

           IF  L2435-RETRN-CLI-NOT-FOUND
               MOVE L2435-CLI-ID      TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000076'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-CONTROL-ERROR
               GO TO 2200-VALIDATE-CLIENT-X
           END-IF.

      *
      * INITIALIZE INPUT PARAMETERS
      *
           PERFORM  5600-0000-INIT-PARM-INFO
               THRU 5600-0000-INIT-PARM-INFO-X.

           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.

           MOVE L2435-CLI-ID          TO L5600-CLI-ID.
016387*    SET L5600-GEN-CNSLDT-MSG-WARN TO TRUE.
      *
      * CALL MODULE TO CHECK CLIENT ACCESS
      *
           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.

       2200-VALIDATE-CLIENT-X.
           EXIT.
      *
      *-----------------
       2300-FORMAT-DATE.
      *-----------------
      *
      * FORMAT DATE: ENSURE THAT THE SUPPLIED EFFECTIVE DATE
      * IS A VALID DATE
      *

      *
      * FOR A BROWSE MOVE CURRENT DATE IN IF DATE IS BLANK
      *
           IF  WS-BUS-FCN-LIST
           AND MIR-CLI-CNTCT-DT = SPACES
               MOVE WGLOB-PROCESS-DATE            TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CLI-CNTCT-DT
               GO TO 2300-FORMAT-DATE-X
           END-IF.

      *
      * CONVERT TO INTERNAL FORMAT
      *
           MOVE MIR-CLI-CNTCT-DT      TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO WCH-CLI-CNTCT-DT
           ELSE
               MOVE MIR-CLI-CNTCT-DT  TO WGLOB-MSG-PARM (1)
               MOVE 'CS03510001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-CONTROL-ERROR
           END-IF.

       2300-FORMAT-DATE-X.
           EXIT.
      *
      *---------------------
       2400-FORMAT-SEQUENCE.
      *---------------------
      *
      * FORMAT SEQUENCE NUMBER - ENSURE THE SUPPLIED SEQUENCE
      * NUMBER IS NUMERIC
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 2                     TO L0280-INPUT-SIZE.
           MOVE MIR-CLI-CNTCT-SEQ-NUM TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
557660         IF (L0280-OUTPUT < ZERO)
               OR (L0280-OUTPUT = ZERO)
                   MOVE MIR-CLI-CNTCT-SEQ-NUM
                                      TO WGLOB-MSG-PARM (1)
                   MOVE 'CS03510002'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   GO TO 2400-FORMAT-SEQUENCE-X
               END-IF
           ELSE
               MOVE MIR-CLI-CNTCT-SEQ-NUM
                                      TO WGLOB-MSG-PARM (1)
               MOVE 'CS03510003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE 'Y'                   TO WS-CONTROL-ERROR.

       2400-FORMAT-SEQUENCE-X.
           EXIT.
      *
      *------------------
       2500-EDIT-USER-ID.
      *------------------
      *
      * EDIT THE USER-ID ENTERED
      *
           MOVE MIR-USER-ID           TO L0220-USER-ID.
           MOVE WGLOB-COMPANY-CODE    TO L0220-COMPANY-CODE.

           PERFORM  0220-1000-VERIFY-USER-ID
               THRU 0220-1000-VERIFY-USER-ID-X.

           IF  L0220-USER-OK
               CONTINUE
           ELSE
      * MSG: INVALID USER ID (@1)
               MOVE 'CS03510005'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-USER-ID       TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-CONTROL-ERROR
               GO TO 2500-EDIT-USER-ID-X
           END-IF.

           IF  WS-BUS-FCN-LIST
               GO TO 2500-EDIT-USER-ID-X
           END-IF.

      * MSG: USER ID (@1) WILL BE IGNORED
           MOVE 'CS03510013'          TO WGLOB-MSG-REF-INFO.
           MOVE MIR-USER-ID           TO WGLOB-MSG-PARM (1).
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
           MOVE SPACES                TO MIR-USER-ID.

       2500-EDIT-USER-ID-X.
           EXIT.
      /
      *
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------
      *
      * INQUIRY PROCESSING: RETRIEVE RECORD AND DISPLAY
      *

014221     MOVE MIR-CLI-ID            TO WCLI-CLI-ID.

014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

           PERFORM  8000-BUILD-CH-KEY
               THRU 8000-BUILD-CH-KEY-X.

           PERFORM  CH-1000-READ
               THRU CH-1000-READ-X.

           IF  NOT WCH-IO-OK
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WCH-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           ELSE
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


       3000-PROCESS-RETRIEVE-X.
           EXIT.
      *
      *------------
       4000-PROCESS-CREATE.
      *------------
      *
      * CREATE PROCESSING:  TWO PASSES REQUIRED
      * CHECK FOR RECORD.  IF NOT FOUND CREATE RECORD AND
      * ALLOW USER TO MODIFY UNDER MAINTAIN PROCESSING
      *

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.


           PERFORM  4100-EDIT-KEY-FIELDS
               THRU 4100-EDIT-KEY-FIELDS-X.

           IF  SW-CONTROL-ERROR
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

      *
      * DETERMINE SEQUENCE NUMBER FOR NEW RECORD
      *
           PERFORM  4200-DETERMINE-SEQUENCE
               THRU 4200-DETERMINE-SEQUENCE-X.

           ADD 1                       TO WS-SEQ-COUNT.
           MOVE WS-SEQ-COUNT          TO WCH-CLI-CNTCT-SEQ-NUM.
           MOVE WS-SEQ-COUNT          TO MIR-CLI-CNTCT-SEQ-NUM.

      *
      * CREATE RECORD
      *
           PERFORM  8000-BUILD-CH-KEY
               THRU 8000-BUILD-CH-KEY-X.

           MOVE WCH-KEY               TO RCH-KEY.

           PERFORM  CH-1000-READ
               THRU CH-1000-READ-X.

           IF  WCH-IO-OK
               MOVE WCH-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

014221*    MOVE WGLOB-USER-ID         TO RCH-USER-ID.
014221     MOVE WGLOB-USER-ID         TO RCH-PREV-UPDT-USER-ID.
           MOVE WGLOB-USER-ID         TO RCH-FOLWUP-USER-ID.

           PERFORM  CH-1000-CREATE
               THRU CH-1000-CREATE-X.

           PERFORM  CH-1000-WRITE
               THRU CH-1000-WRITE-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

014221     MOVE MIR-CLI-ID            TO WCLI-CLI-ID.

014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.


       4000-PROCESS-CREATE-X.
           EXIT.
      *
      *---------------------
       4100-EDIT-KEY-FIELDS.
      *---------------------
      *
      * EDIT KEY FIELDS: CHECK VALIDITY OF ALL KEY FIELDS TO
      * ENSURE THAT ALL NEW RECORDS ARE CREATED WITH VALID KEYS
      *
           MOVE 'N'                   TO WS-CONTROL-ERROR.

      *
      * IF THERE IS A SEQUENCE NUMBER IGNORE IT
      *
           IF  MIR-CLI-CNTCT-SEQ-NUM NOT = SPACES
               MOVE SPACES            TO MIR-CLI-CNTCT-SEQ-NUM
               MOVE 'CS03510004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
      *
      * IF NO DATE DEFAULT SYSTEM DATE
      *
           IF  MIR-CLI-CNTCT-DT = SPACES
               MOVE WGLOB-PROCESS-DATE            TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CLI-CNTCT-DT
               MOVE L1640-INTERNAL-DATE
                                      TO WCH-CLI-CNTCT-DT
           ELSE
               PERFORM  2300-FORMAT-DATE
                   THRU 2300-FORMAT-DATE-X
           END-IF.

       4100-EDIT-KEY-FIELDS-X.
           EXIT.
      *
      *------------------------
       4200-DETERMINE-SEQUENCE.
      *------------------------
      *
      * RETRIEVE NEXT AVAILABLE SEQUENCE NUMBER
      *

      *
      *  PARAGRAPH REWRITTEN AND RESTRUCTURED
      *  WCH-CLI-CNTCT-DT ALREADY SET UP IN 4100 PARAGRAPH
      *
           MOVE MIR-CLI-ID            TO WCH-CLI-ID.
010310*    MOVE HIGH-VALUES            TO WCH-CLI-CNTCT-SEQ-NUM.
010310     MOVE LOW-VALUES            TO WCH-CLI-CNTCT-SEQ-NUM.
           MOVE WCH-KEY               TO WCH-ENDBR-KEY.
010310*    MOVE LOW-VALUES             TO WCH-ENDBR-CLI-CNTCT-SEQ-NUM.
010310     MOVE HIGH-VALUES           TO WCH-ENDBR-CLI-CNTCT-SEQ-NUM.
           MOVE 0                     TO WS-SEQ-COUNT.

010310*    PERFORM  CH-1000-BROWSE-PREV
010310*        THRU CH-1000-BROWSE-PREV-X.

010310     PERFORM  CH-2000-READ-MAX
010310         THRU CH-2000-READ-MAX-X.

           IF  NOT WCH-IO-OK
010310         MOVE +0                TO WS-SEQ-COUNT
               GO TO 4200-DETERMINE-SEQUENCE-X
           END-IF.

010310*    PERFORM  CH-2000-READ-PREV
010310*        THRU CH-2000-READ-PREV-X.

           IF  WCH-IO-OK
010310*        MOVE RCH-CLI-CNTCT-SEQ-NUM TO WS-SEQ-COUNT
010310         MOVE WCH-MAX-CLI-CNTCT-SEQ-NUM
                                      TO WS-SEQ-COUNT
           END-IF.

010310*    PERFORM  CH-3000-END-BROWSE-PREV
010310*        THRU CH-3000-END-BROWSE-PREV-X.

       4200-DETERMINE-SEQUENCE-X.
           EXIT.
      *

      *---------------------
       5000-PROCESS-UPDATE.
      *---------------------
      *
      *  MAINTAIN PROCESSING:
      *  EDIT INCOMING DATA FIELDS, AND GENERATE A SEQUENCE
      *  NUMBER IF A NEW RECORD.  UPDATE THE RECORD TO DISK
      *  UNLESS NEW RECORD AND INVALID STATUS.
      *
014221     MOVE MIR-CLI-ID            TO WCLI-CLI-ID.

014221     PERFORM  CLI-2000-UPDATE-TWRK-TS
014221         THRU CLI-2000-UPDATE-TWRK-TS-X.

014221     IF WCLI-IO-NOT-FOUND
014221*MSG: 'CLIENT RECORD (@1) NOT FOUND'
014221         SET SW-CONTROL-ERROR   TO TRUE
014221         MOVE 'XS00000058'      TO WGLOB-MSG-REF-INFO
014221         MOVE WCLI-CLI-ID       TO WGLOB-MSG-PARM (01)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

014221     IF MIR-RETRN-TS-MISMATCH
014221*MSG: 'TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*      PROCESS NOT COMPLETE'
014221         SET SW-CONTROL-ERROR   TO TRUE
014221         MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221         MOVE 'CLI'             TO WGLOB-MSG-PARM (01)
014221         MOVE WCLI-CLI-ID       TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  8000-BUILD-CH-KEY
               THRU 8000-BUILD-CH-KEY-X.

           PERFORM  CH-1000-READ-FOR-UPDATE
               THRU CH-1000-READ-FOR-UPDATE-X.

           IF  WCH-IO-NOT-FOUND
               MOVE WCH-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
014221         PERFORM  CLI-3000-UNLOCK
014221             THRU CLI-3000-UNLOCK-X
               MOVE 'N'               TO WS-EDIT-ERROR-SW
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.


           MOVE 'Y'                   TO WS-EDIT-ERROR-SW.

           PERFORM  5400-EDIT-DATA-FIELDS
               THRU 5400-EDIT-DATA-FIELDS-X.

014221*    MOVE WGLOB-USER-ID         TO RCH-USER-ID.
014221     MOVE WGLOB-USER-ID         TO RCH-PREV-UPDT-USER-ID.
           MOVE WGLOB-USER-ID         TO MIR-USER-ID.

           PERFORM  CH-2000-REWRITE
               THRU CH-2000-REWRITE-X.
014221     PERFORM  CLI-2000-REWRITE
014221         THRU CLI-2000-REWRITE-X.
014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

           IF  WS-ALL-EDITS-OK
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       5000-PROCESS-UPDATE-X.
           EXIT.
      *
      *----------------------
       5400-EDIT-DATA-FIELDS.
      *----------------------
      *
      * EDIT DATA FIELDS:
      * CHECK THE VALIDITY OF ALL THE MAINTAINABLE DATA FIELDS
      *
           PERFORM  5410-EDIT-ACTIVITY-CODE
               THRU 5410-EDIT-ACTIVITY-CODE-X.

           PERFORM  5420-EDIT-ACTIVITY-TYPE
               THRU 5420-EDIT-ACTIVITY-TYPE-X.

           PERFORM  5430-EDIT-RETENTION
               THRU 5430-EDIT-RETENTION-X.

           PERFORM  5440-EDIT-POLICY-NUMBER
               THRU 5440-EDIT-POLICY-NUMBER-X.

           PERFORM  5450-EDIT-FOLLOWUP-DATE
               THRU 5450-EDIT-FOLLOWUP-DATE-X.

           PERFORM  5460-EDIT-FOLLOWUP-USERID
               THRU 5460-EDIT-FOLLOWUP-USERID-X.

           PERFORM  5470-EDIT-FOLLOWUP-ACTION
               THRU 5470-EDIT-FOLLOWUP-ACTION-X.

           PERFORM  5480-EDIT-USER-COMMENTS
               THRU 5480-EDIT-USER-COMMENTS-X.

           PERFORM  5500-EDIT-PAAF-TS
               THRU 5500-EDIT-PAAF-TS-X.


       5400-EDIT-DATA-FIELDS-X.
           EXIT.
      *
      *------------------------
       5410-EDIT-ACTIVITY-CODE.
      *------------------------
      *
      * EDIT ACTIVITY CODE FROM EDIT TABLE
      *
           IF  MIR-CLI-CNTCT-TYP-CD = SPACES
               MOVE RCH-CLI-CNTCT-TYP-CD
                                      TO MIR-CLI-CNTCT-TYP-CD
           ELSE
               IF  MIR-CLI-CNTCT-TYP-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CLI-CNTCT-TYP-CD
                   MOVE SPACES        TO RCH-CLI-CNTCT-TYP-CD
               END-IF
           END-IF.

      *
      * SEARCH FOR ACTIVITY CODE ON EDIT - VALUE 'CHACT'
      *
           MOVE MIR-CLI-CNTCT-TYP-CD  TO WEDIT-ETBL-VALU-ID.

           PERFORM  CHAC-1000-EDIT
               THRU CHAC-1000-EDIT-X.

           IF  WEDIT-IO-NOT-FOUND
               MOVE 'CS03510006'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-CLI-CNTCT-TYP-CD
                                      TO WGLOB-MSG-PARM (1)
               MOVE 'N'               TO WS-EDIT-ERROR-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE REDIT-ETBL-VALU-ID           TO RCH-CLI-CNTCT-TYP-CD
013578*        MOVE SPACES            TO REDIT-ETBL-DESC-TXT
013578*        PERFORM  CHAC-2000-DESC
013578*            THRU CHAC-2000-DESC-X
013578*        MOVE REDIT-ETBL-DESC-TXT
013578*                               TO MIR-EDTTO-T (1)
           END-IF.

       5410-EDIT-ACTIVITY-CODE-X.
           EXIT.
      *
      *------------------------
       5420-EDIT-ACTIVITY-TYPE.
      *------------------------
      *
      * CLIENT ACTIVITY TYPE IS USER DEFINED (ALL VALUES VALID)
      *
           IF  MIR-CLI-CNTCT-SUB-CD = SPACES
               MOVE RCH-CLI-CNTCT-SUB-CD
                                      TO MIR-CLI-CNTCT-SUB-CD
           ELSE
               IF  MIR-CLI-CNTCT-SUB-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CLI-CNTCT-SUB-CD
               END-IF
           END-IF.

           MOVE MIR-CLI-CNTCT-SUB-CD  TO RCH-CLI-CNTCT-SUB-CD.

       5420-EDIT-ACTIVITY-TYPE-X.
           EXIT.
      *
      *--------------------
       5430-EDIT-RETENTION.
      *--------------------
      *
      * EDIT THE RETENTION
      *
           IF  MIR-CLI-CNTCT-RETEN-CD = SPACES
               MOVE RCH-CLI-CNTCT-RETEN-CD
                                      TO MIR-CLI-CNTCT-RETEN-CD
           ELSE
               IF  MIR-CLI-CNTCT-RETEN-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO RCH-CLI-CNTCT-RETEN-CD
                   MOVE SPACES        TO MIR-CLI-CNTCT-RETEN-CD
               END-IF
557660     END-IF.

           IF  (MIR-CLI-CNTCT-RETEN-CD = 'P')
           OR  (MIR-CLI-CNTCT-RETEN-CD = 'T')
               MOVE MIR-CLI-CNTCT-RETEN-CD
                                      TO RCH-CLI-CNTCT-RETEN-CD
           ELSE
               MOVE 'CS03510008'      TO WGLOB-MSG-REF-INFO
               MOVE 'N'               TO WS-EDIT-ERROR-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5430-EDIT-RETENTION-X.
           EXIT.
      *
      *------------------------
       5440-EDIT-POLICY-NUMBER.
      *------------------------
      *
      * VERIFY THE POLICY NUMBER IS VALID
      *
           IF  MIR-POL-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-POL-ID
               MOVE SPACES            TO RCH-POL-ID
               GO TO 5440-EDIT-POLICY-NUMBER-X
           END-IF.

      *
      * IF THERE IS A POLICY NUMBER IT MUST BE ON THE RL FILE
      *
           IF  MIR-POL-ID = SPACES
               MOVE RCH-POL-ID        TO MIR-POL-ID
               GO TO 5440-EDIT-POLICY-NUMBER-X
           ELSE
               MOVE LOW-VALUES        TO WRL-KEY-NUMBER
               MOVE HIGH-VALUES       TO WRL-ENDBR-KEY
               MOVE WCH-CLI-ID        TO WRL-CLI-ID
                                         WRL-ENDBR-CLI-ID
                                         RRL-CLI-ID
               PERFORM  RL-1000-BROWSE
                   THRU RL-1000-BROWSE-X
               PERFORM  5445-GET-POLICY
                   THRU 5445-GET-POLICY-X
                   UNTIL FOUND-IT
                   OR (NOT WRL-IO-OK)
               IF  FOUND-IT
                   MOVE  MIR-POL-ID   TO RCH-POL-ID
                   PERFORM  RL-3000-END-BROWSE
                       THRU RL-3000-END-BROWSE-X
               ELSE
                   MOVE 'N'           TO WS-EDIT-ERROR-SW
                   MOVE 'CS03510009'  TO WGLOB-MSG-REF-INFO
      *
      * MESSAGE - CLIENT UNRELATED TO POLICY
      *
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

016440     MOVE MIR-POL-ID            TO WPOL-POL-ID.
016440     PERFORM  POL-1000-READ
016440         THRU POL-1000-READ-X.
016440     IF  WPOL-IO-OK
016440         PERFORM  5400-1000-BUILD-PARM-INFO
016440             THRU 5400-1000-BUILD-PARM-INFO-X

016440         SET L5400-POL-XFER-INQ TO  TRUE

016440         PERFORM  5400-1000-POL-CHK
016440             THRU 5400-1000-POL-CHK-X

016440         IF  L5400-XFER-ACCS-RESTRICTED
016440             MOVE 'N'           TO WS-EDIT-ERROR-SW
016440         END-IF
016440     END-IF.


       5440-EDIT-POLICY-NUMBER-X.
           EXIT.
      *
      *----------------
       5445-GET-POLICY.
      *----------------
      *
      * IF POLICY NUMBER ENTERED SEARCH RELATIONSHIP FILE
      *
           PERFORM  RL-2000-READ-NEXT
               THRU RL-2000-READ-NEXT-X.

           IF  RRL-REL-SYS-REF-POL-ID EQUAL MIR-POL-ID
               MOVE 'Y'               TO WS-FOUND-SW
           END-IF.

       5445-GET-POLICY-X.
           EXIT.
      *
      *------------------------
       5450-EDIT-FOLLOWUP-DATE.
      *------------------------
      *
      * EDIT THE FOLLOW-UP DATE
      *
           IF  MIR-FOLWUP-DT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-FOLWUP-DT
               MOVE WWKDT-ZERO-DT     TO RCH-FOLWUP-DT
               GO TO 5450-EDIT-FOLLOWUP-DATE-X
           END-IF.

      *
      * IF THERE IS A DATE MAKE SURE THE FORMAT IS VALID
      *
           IF  MIR-FOLWUP-DT = SPACES
               MOVE RCH-FOLWUP-DT     TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-FOLWUP-DT
               GO TO 5450-EDIT-FOLLOWUP-DATE-X
           ELSE
               MOVE MIR-FOLWUP-DT     TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-NOT-VALID
                   MOVE 'N'           TO WS-EDIT-ERROR-SW
                   MOVE MIR-FOLWUP-DT TO WGLOB-MSG-PARM (1)
                   MOVE 'CS03510010'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   MOVE L1640-EXTERNAL-DATE
                                      TO MIR-FOLWUP-DT
      *
      * FOLLOW-UP DATE MUST BE LESS THAN ACTION DATE
      *
                   IF L1640-INTERNAL-DATE < RCH-CLI-CNTCT-DT
                       MOVE 'CS03510011'
                                      TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                       MOVE 'N'       TO WS-EDIT-ERROR-SW
                   ELSE
                       MOVE L1640-INTERNAL-DATE
                                      TO RCH-FOLWUP-DT
557660             END-IF
557660         END-IF
557660     END-IF.

       5450-EDIT-FOLLOWUP-DATE-X.
           EXIT.
      *
      *--------------------------
       5460-EDIT-FOLLOWUP-USERID.
      *--------------------------

      *
      *  EDIT THE USER-ID OF THE USER TO BE NOTIFIED ON THE
      *  FOLLOW-UP.  DEFAULTS FROM USER SIGNED ON AND MAY BE
      *  CHANGED.
      *

           IF  MIR-FOLWUP-USER-ID = SPACES
               MOVE RCH-FOLWUP-USER-ID             TO MIR-FOLWUP-USER-ID
               GO TO 5460-EDIT-FOLLOWUP-USERID-X
           ELSE
               IF  MIR-FOLWUP-USER-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE WGLOB-USER-ID TO MIR-FOLWUP-USER-ID
               END-IF
           END-IF.

           MOVE MIR-FOLWUP-USER-ID    TO L0220-USER-ID.
           MOVE WGLOB-COMPANY-CODE    TO L0220-COMPANY-CODE.

           PERFORM  0220-1000-VERIFY-USER-ID
               THRU 0220-1000-VERIFY-USER-ID-X.

           IF  L0220-USER-OK
               MOVE MIR-FOLWUP-USER-ID             TO RCH-FOLWUP-USER-ID
           ELSE
               MOVE 'CS03510012'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-FOLWUP-USER-ID             TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDIT-ERROR-SW
           END-IF.

       5460-EDIT-FOLLOWUP-USERID-X.
           EXIT.
      *
      *--------------------------
       5470-EDIT-FOLLOWUP-ACTION.
      *--------------------------
      *
      *  EDIT THE FOLLOW UP ACTION.  MUST EXIST ON THE EDIT
      *  TABLE WITH VALUE "CHFUA".
      *
           IF  MIR-FOLWUP-ACT-CD = SPACES
               MOVE RCH-FOLWUP-ACT-CD TO MIR-FOLWUP-ACT-CD
           ELSE
               IF  MIR-FOLWUP-ACT-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO RCH-FOLWUP-ACT-CD
                   MOVE SPACES        TO MIR-FOLWUP-ACT-CD
               END-IF
           END-IF.

      *
      * SEARCH FOR ACTIVITY CODE ON EDIT - VALUE 'CHFUA'
      *
           MOVE MIR-FOLWUP-ACT-CD     TO WEDIT-ETBL-VALU-ID.

           PERFORM  FPAC-1000-EDIT
               THRU FPAC-1000-EDIT-X.

           IF  WEDIT-IO-NOT-FOUND
               MOVE 'CS03510007'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-FOLWUP-ACT-CD TO WGLOB-MSG-PARM (1)
               MOVE 'N'               TO WS-EDIT-ERROR-SW
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE REDIT-ETBL-VALU-ID              TO RCH-FOLWUP-ACT-CD
013578*        MOVE SPACES            TO REDIT-ETBL-VALU-ID
013578*        PERFORM  FPAC-2000-DESC
013578*            THRU FPAC-2000-DESC-X
013578*        MOVE REDIT-ETBL-DESC-TXT
013578*                               TO MIR-EDTTO-T (2)
           END-IF.

       5470-EDIT-FOLLOWUP-ACTION-X.
           EXIT.
      *
      *------------------------
       5480-EDIT-USER-COMMENTS.
      *------------------------
      *
      * EDIT USER COMMENTS
      *
           IF  MIR-FOLWUP-NOTE-TXT           =  SPACES
               MOVE RCH-FOLWUP-NOTE-TXT
                                      TO MIR-FOLWUP-NOTE-TXT
               MOVE RCH-FOLWUP-NOTE-TXT TO WS-FOLWUP-NOTE-TXT-G
           END-IF.

           IF  WS-FOLWUP-NOTE-TXT-T (1)       =  EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-FOLWUP-NOTE-TXT
           END-IF.

           MOVE MIR-FOLWUP-NOTE-TXT   TO RCH-FOLWUP-NOTE-TXT.

       5480-EDIT-USER-COMMENTS-X.
           EXIT.
      *
      *
      *------------------
       5500-EDIT-PAAF-TS.
      *------------------

020460     IF  MIR-PAAFLD-GR-TS   = SPACES
020460     OR  MIR-PAAFLD-GR-TS   = WWKDT-ZERO-TS
020460         GO TO 5500-EDIT-PAAF-TS-X
020460     END-IF.

020460     PERFORM  1646-1000-BUILD-PARM-INFO
020460         THRU 1646-1000-BUILD-PARM-INFO-X.

020460     MOVE MIR-PAAFLD-GR-TS         TO L1646-TIMESTAMP.

020460     PERFORM  1646-1000-EDIT-TIMESTAMP
020460         THRU 1646-1000-EDIT-TIMESTAMP-X.

020460     IF  NOT L1646-EDIT-OK
020460*    MSG: INVALID TIMESTAMP
020460         MOVE 'CS03510017'         TO WGLOB-MSG-REF-INFO
020460         PERFORM  0260-1000-GENERATE-MESSAGE
020460             THRU 0260-1000-GENERATE-MESSAGE-X
020460         GO TO 5500-EDIT-PAAF-TS-X
020460     END-IF.

020460     PERFORM  3188-0000-INIT-PARM-INFO
020460         THRU 3188-0000-INIT-PARM-INFO-X.

020460     MOVE MIR-POL-ID               TO L3188-POL-ID.
020460     MOVE MIR-PAAFLD-GR-TS         TO L3188-PAAFLD-GR-TS.

020460     PERFORM  3188-3000-BR-EXIST
020460         THRU 3188-3000-BR-EXIST-X.

020460     IF L3188-RETRN-PAAF-NOT-FOUND
020460*    MSG:PAAF RECORD NOT FOUND.  CLIENT HISTORY TABLE WILL
020460*        NOT BE UPDATED WITH PAAF TIMESTAMP.
020460         MOVE 'CS03510018'         TO WGLOB-MSG-REF-INFO
020460         PERFORM  0260-1000-GENERATE-MESSAGE
020460             THRU 0260-1000-GENERATE-MESSAGE-X
020460         GO TO 5500-EDIT-PAAF-TS-X
020460     END-IF.

020460     MOVE MIR-PAAFLD-GR-TS         TO RCH-PAAFLD-GR-TS.

       5500-EDIT-PAAF-TS-X.
           EXIT.
      *
      *-------------------
       6000-PROCESS-DELETE.
      *-------------------
      *
      * DELETE-PROCESSING:
      *
014221     MOVE MIR-CLI-ID            TO WCLI-CLI-ID.

014221     PERFORM  CLI-2000-UPDATE-TWRK-TS
014221         THRU CLI-2000-UPDATE-TWRK-TS-X.

014221     IF WCLI-IO-NOT-FOUND
014221*MSG: 'CLIENT RECORD (@1) NOT FOUND'
014221         SET SW-CONTROL-ERROR   TO TRUE
014221         MOVE 'XS00000058'      TO WGLOB-MSG-REF-INFO
014221         MOVE WCLI-CLI-ID       TO WGLOB-MSG-PARM (01)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

014221     IF MIR-RETRN-TS-MISMATCH
014221*MSG: 'TIMESTAMP MISMATCH - TABLE (@1) KEY @2,
014221*      PROCESS NOT COMPLETE'
014221         SET SW-CONTROL-ERROR   TO TRUE
014221         MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221         MOVE 'CLI'             TO WGLOB-MSG-PARM (01)
014221         MOVE WCLI-CLI-ID       TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           PERFORM  2300-FORMAT-DATE
               THRU 2300-FORMAT-DATE-X.

           PERFORM  8000-BUILD-CH-KEY
               THRU 8000-BUILD-CH-KEY-X.

           PERFORM  CH-1000-READ-FOR-UPDATE
               THRU CH-1000-READ-FOR-UPDATE-X.

           IF  WCH-IO-NOT-FOUND
               MOVE WCH-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  CLI-3000-UNLOCK
014221             THRU CLI-3000-UNLOCK-X
               GO TO 6000-PROCESS-DELETE-X
           END-IF.

      *
      * DELETE RECORD
      *
           PERFORM  CH-1000-DELETE
               THRU CH-1000-DELETE-X.
014221     PERFORM  CLI-2000-REWRITE
014221         THRU CLI-2000-REWRITE-X.
014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

           MOVE 'XS00000011'          TO WGLOB-MSG-REF-INFO

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.




       6000-PROCESS-DELETE-X.
           EXIT.
      *
      *--------------------
      *
      *-----------------
       7000-PROCESS-LIST.
      *-----------------
      *
      * NEW BROWSE ROUTINE TO ADD THE USER-ID AS A BROWSE OPTION
      *


           PERFORM  8000-BUILD-CH-KEY
               THRU 8000-BUILD-CH-KEY-X.

           MOVE ZERO                  TO WGLOB-MSG-ERROR-SW.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 7000-PROCESS-LIST-X
           END-IF.

      * MOVE SPACES TO ALL MIR TABLE FIELDS USED IN BROWSE LINE

           PERFORM  9110-BLANK-SCR2-DATA-FIELDS
               THRU 9110-BLANK-SCR2-DATA-FIELDS-X.

           MOVE ZERO                  TO WCH-IO-STATUS.
           MOVE ZERO                  TO WCHUA-IO-STATUS.
           MOVE ZERO                  TO WS-SUB.
           MOVE 'N'                   TO WS-IF-ANY-RECORDS-DISPLAYED.

557660     IF  BROWSE-BY-CLIENT
           OR  BROWSE-BY-BOTH
               PERFORM  CH-1000-BROWSE-PREV
                   THRU CH-1000-BROWSE-PREV-X
           ELSE
               IF  BROWSE-BY-USERID
                   PERFORM  CHUA-1000-BROWSE
                       THRU CHUA-1000-BROWSE-X
               END-IF
           END-IF.

           IF  WCH-IO-EOF
           OR  WCHUA-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-PROCESS-LIST-X
           END-IF.

           IF  BROWSE-BY-CLIENT
           OR  BROWSE-BY-BOTH
               PERFORM  CH-2000-READ-PREV
                   THRU CH-2000-READ-PREV-X
           ELSE
               IF  BROWSE-BY-USERID
                   PERFORM  CHUA-2000-READ-NEXT
                       THRU CHUA-2000-READ-NEXT-X
               END-IF
           END-IF.

           IF  WCH-IO-EOF
           OR  WCHUA-IO-EOF
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-PROCESS-LIST-X
           END-IF.

           PERFORM  7010-PROCESS-LIST-READ
               THRU 7010-PROCESS-LIST-READ-X
               UNTIL WS-SUB > WS-MAX-BROWSE-LINES
               OR WCH-IO-EOF
               OR WCHUA-IO-EOF.

           IF  WCH-IO-EOF
           OR  WCHUA-IO-EOF
               CONTINUE
           ELSE
               IF  BROWSE-BY-BOTH
                   SET WS-NEXT-REC-NOT-FOUND TO TRUE
                   PERFORM  7010-PROCESS-LIST-READ
                       THRU 7010-PROCESS-LIST-READ-X
                       UNTIL WS-NEXT-REC-FOUND
                       OR WCH-IO-EOF
               END-IF
           END-IF.

           IF  WCH-IO-EOF
           OR  WCHUA-IO-EOF
               IF  WS-RECORDS-DISPLAYED
                   MOVE 'XS00000015'  TO WGLOB-MSG-REF-INFO
               ELSE
                   MOVE 'XS00000034'  TO WGLOB-MSG-REF-INFO
               END-IF
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS  TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU  0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  BROWSE-BY-CLIENT
           OR  BROWSE-BY-BOTH
               PERFORM  CH-3000-END-BROWSE-PREV
                   THRU CH-3000-END-BROWSE-PREV-X
           END-IF.

           IF  BROWSE-BY-USERID
               PERFORM  CHUA-3000-END-BROWSE
                   THRU CHUA-3000-END-BROWSE-X
           END-IF.

       7000-PROCESS-LIST-X.
           EXIT.
      *
      *-------------------------
       7010-PROCESS-LIST-READ.
      *-------------------------
      *
      * WHEN PROCESSING WITH THE USER-ID AND CLIENT-NO AT THE SAME
      * TIME IF THE RCH-CLI-ID IS NOT EQUAL TO CLI-ID IN THE SCREEN
      * SKIP THIS RECORD AND READ THE NEXT ONE IN THE FILE.
      *
           IF  BROWSE-BY-BOTH
               IF (RCH-CLI-ID = MIR-CLI-ID
               AND RCH-FOLWUP-USER-ID = MIR-USER-ID)
                  CONTINUE
               ELSE
                  PERFORM  7020-PROCESS-NEXT-READ
                      THRU 7020-PROCESS-NEXT-READ-X
                  GO TO 7010-PROCESS-LIST-READ-X
               END-IF
           END-IF.

           IF  WS-SUB > WS-MAX-BROWSE-LINES
           AND BROWSE-BY-BOTH
               SET WS-NEXT-REC-FOUND   TO TRUE
               GO TO 7010-PROCESS-LIST-READ-X
           END-IF.

           ADD 1                       TO WS-SUB.

           IF  WS-SUB > WS-MAX-BROWSE-LINES
               GO TO 7010-PROCESS-LIST-READ-X
           END-IF.

           IF  BROWSE-BY-USERID
               MOVE RCH-CLI-ID        TO L2435-CLI-ID
               PERFORM  2435-1000-OBTAIN-CLI-INFO
                   THRU 2435-1000-OBTAIN-CLI-INFO-X
      *
      * WHEN CLIENT EXISTS, CHECK THE CLIENT ACCESS
      *
               IF  L2435-RETRN-OK
                   PERFORM  7015-CHUA-CONFIDENTIAL
                       THRU 7015-CHUA-CONFIDENTIAL-X
               END-IF
           END-IF.

           PERFORM  9250-MOVE-TO-BROWSE-SCREEN
               THRU 9250-MOVE-TO-BROWSE-SCREEN-X.

           PERFORM  7020-PROCESS-NEXT-READ
               THRU 7020-PROCESS-NEXT-READ-X.

       7010-PROCESS-LIST-READ-X.
           EXIT.
      *
      *-----------------------
       7015-CHUA-CONFIDENTIAL.
      *-----------------------
      *
      * INITIALIZE INPUT PARAMETERS
      *
           PERFORM  5600-0000-INIT-PARM-INFO
               THRU 5600-0000-INIT-PARM-INFO-X.

           PERFORM  5600-1000-BUILD-PARM-INFO
               THRU 5600-1000-BUILD-PARM-INFO-X.

           MOVE L2435-CLI-ID          TO L5600-CLI-ID.
016387*    SET L5600-GEN-CNSLDT-MSG-WARN TO TRUE.
      *
      * CALL MODULE TO CHECK CLIENT CONFIDENTIALITY INDICATOR
      *
           PERFORM  5600-1000-CLI-CHK
               THRU 5600-1000-CLI-CHK-X.
      *
      * CLIENT IS NOT CONFIDENTIAL - EXIT
      *
           IF  L5600-CNFD-ACCS-ALLOW
               GO TO 7015-CHUA-CONFIDENTIAL-X
           END-IF.

      *
      *  CLIENT IS CONFIDENTIAL - CHECK IF USER HAS ACCESS
      *
           IF  L0220-CONFIDENTIAL-IND = 'B'
           OR  L0220-CONFIDENTIAL-IND = 'C'
               MOVE L2435-CLI-ID      TO WGLOB-MSG-PARM (1)
               MOVE RCH-FOLWUP-USER-ID             TO WGLOB-MSG-PARM (2)
               MOVE 'CS03510015'      TO WGLOB-MSG-REF-INFO
           ELSE
               MOVE RCH-FOLWUP-USER-ID             TO WGLOB-MSG-PARM (1)
               MOVE L2435-CLI-ID      TO WGLOB-MSG-PARM (2)
               MOVE 'CS03510016'      TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       7015-CHUA-CONFIDENTIAL-X.
           EXIT.
      *
      *-----------------------
       7020-PROCESS-NEXT-READ.
      *-----------------------

           IF  BROWSE-BY-CLIENT
           OR  BROWSE-BY-BOTH
               PERFORM  CH-2000-READ-PREV
                   THRU CH-2000-READ-PREV-X
           END-IF.

           IF  BROWSE-BY-USERID
               PERFORM  CHUA-2000-READ-NEXT
                   THRU CHUA-2000-READ-NEXT-X
           END-IF.

           IF  WCH-IO-EOF
           OR  WCHUA-IO-EOF
           OR  WS-SUB < WS-MAX-BROWSE-LINES
               GO TO 7020-PROCESS-NEXT-READ-X
           END-IF.

           IF  BROWSE-BY-CLIENT
      *
      * MOVE KEY FIELDS FOR CLIENT  TO MIR-FIELDS
      *
               MOVE RCH-CLI-CNTCT-DT  TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CLI-CNTCT-DT
               MOVE RCH-CLI-CNTCT-SEQ-NUM
                                      TO MIR-CLI-CNTCT-SEQ-NUM
           END-IF.

           IF  BROWSE-BY-BOTH
      *
      * MOVE KEY FIELDS FOR USRID   TO MIR-FIELDS
      *
               MOVE RCH-CLI-CNTCT-DT  TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CLI-CNTCT-DT
               MOVE RCH-CLI-CNTCT-SEQ-NUM
                                      TO MIR-CLI-CNTCT-SEQ-NUM
           END-IF.

           IF  BROWSE-BY-USERID
      *
      * MOVE KEY FIELDS FOR USRID   TO MIR-FIELDS
      *
               MOVE RCH-FOLWUP-DT     TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-CLI-CNTCT-DT
            END-IF.


       7020-PROCESS-NEXT-READ-X.
           EXIT.
      *
      *---------------------------
      *
      *------------------------
      *
      *-------------------------
      *
      *------------------
       8000-BUILD-CH-KEY.
      *------------------
      *
      * BUILD THE KEY TO READ THE CH FILE
      *

           IF  WS-BUS-FCN-LIST
               PERFORM  8100-SET-BROWSE-TYPE
                   THRU 8100-SET-BROWSE-TYPE-X
               PERFORM  8200-BUILD-BROWSE-KEY
                   THRU 8200-BUILD-BROWSE-KEY-X
           ELSE
               MOVE MIR-CLI-ID        TO WCH-CLI-ID
               MOVE MIR-CLI-CNTCT-DT  TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X
               MOVE L1640-INTERNAL-DATE
                                      TO WCH-CLI-CNTCT-DT
               MOVE MIR-CLI-CNTCT-SEQ-NUM
                                      TO WCH-CLI-CNTCT-SEQ-NUM
           END-IF.

       8000-BUILD-CH-KEY-X.
           EXIT.
      *
      *---------------------
       8100-SET-BROWSE-TYPE.
      *---------------------
      *
      * BROWSE BY CLIENT
      *

           IF  (MIR-CLI-ID     > SPACES
           AND MIR-USER-ID NOT > SPACES)
               MOVE 'C'               TO WS-BROWSE-TYPE-CD
           END-IF.

      *
      * BROWSE BY USERID WITHIN CLIENT
      *

           IF  (MIR-CLI-ID  > SPACES
           AND MIR-USER-ID  > SPACES)
               MOVE 'B'               TO WS-BROWSE-TYPE-CD
           END-IF.

      *
      * BROWSE BY USERID
      * DON'T FORGET THIS USES THE ALT INDEX
      *

           IF  (MIR-USER-ID   > SPACES
           AND MIR-CLI-ID NOT > SPACES)
               MOVE 'U'               TO WS-BROWSE-TYPE-CD
           END-IF.

       8100-SET-BROWSE-TYPE-X.
           EXIT.
      *
      *----------------------
       8200-BUILD-BROWSE-KEY.
      *----------------------

           IF  BROWSE-BY-CLIENT
           OR  BROWSE-BY-BOTH
               MOVE HIGH-VALUES       TO WCH-KEY
               MOVE MIR-CLI-ID        TO WCH-CLI-ID
               MOVE MIR-CLI-CNTCT-DT  TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X
               MOVE L1640-INTERNAL-DATE
                                      TO WCH-CLI-CNTCT-DT
               IF  MIR-CLI-CNTCT-SEQ-NUM = SPACES
                   MOVE 99            TO WCH-CLI-CNTCT-SEQ-NUM
               ELSE
                   MOVE MIR-CLI-CNTCT-SEQ-NUM
                                      TO WCH-CLI-CNTCT-SEQ-NUM
               END-IF
               MOVE WCH-KEY           TO WCH-ENDBR-KEY
               MOVE WWKDT-LOW-DT      TO WCH-ENDBR-CLI-CNTCT-DT
               MOVE LOW-VALUES        TO WCH-ENDBR-CLI-CNTCT-SEQ-NUM
           END-IF.

           IF  BROWSE-BY-USERID
               MOVE LOW-VALUES        TO WCHUA-KEY
               MOVE MIR-USER-ID       TO WCHUA-FOLWUP-USER-ID
               MOVE MIR-CLI-CNTCT-DT  TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X
               MOVE L1640-INTERNAL-DATE
                                      TO WCHUA-FOLWUP-DT
               MOVE MIR-CLI-ID      TO WCHUA-CLI-ID
               MOVE WCHUA-KEY         TO WCHUA-ENDBR-KEY
               MOVE WWKDT-HIGH-DT     TO WCHUA-ENDBR-FOLWUP-DT
               MOVE HIGH-VALUES       TO WCHUA-ENDBR-CLI-ID
           END-IF.

       8200-BUILD-BROWSE-KEY-X.
           EXIT.
      *
      *--------------------
      *
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------
      *
      * SET EACH NON-KEY FIELD TO SPACES
      *
               MOVE SPACES            TO MIR-CLI-CNTCT-TYP-CD
               MOVE SPACES            TO MIR-USER-ID
               MOVE SPACES            TO MIR-CLI-CNTCT-SUB-CD
               MOVE SPACES            TO MIR-CLI-CNTCT-RETEN-CD
               MOVE SPACES            TO MIR-POL-ID
013578*        MOVE SPACES            TO MIR-EDTTO-T (1)
013578*        MOVE SPACES            TO MIR-EDTTO-T (2)
               MOVE SPACES            TO MIR-FOLWUP-DT
               MOVE SPACES            TO MIR-FOLWUP-USER-ID
               MOVE SPACES            TO MIR-FOLWUP-ACT-CD
               MOVE SPACES            TO WS-FOLWUP-NOTE-TXT-T (1)
               MOVE SPACES            TO WS-FOLWUP-NOTE-TXT-T (2)
               MOVE SPACES            TO WS-FOLWUP-NOTE-TXT-T (3)
               GO TO 9100-BLANK-DATA-FIELDS-X

               PERFORM  9110-BLANK-SCR2-DATA-FIELDS
                   THRU 9110-BLANK-SCR2-DATA-FIELDS-X.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      *----------------------------
       9110-BLANK-SCR2-DATA-FIELDS.
      *----------------------------

           MOVE SPACES                TO MIR-CLI-ID-G.
           MOVE SPACES                TO MIR-CLI-CNTCT-DT-G.
           MOVE SPACES                TO MIR-CLI-CNTCT-SEQ-NUM-G.
           MOVE SPACES                TO MIR-CLI-CNTCT-TYP-CD-G.
           MOVE SPACES                TO MIR-CLI-CNTCT-SUB-CD-G.
           MOVE SPACES                TO MIR-CLI-CNTCT-RETEN-CD-G.
           MOVE SPACES                TO MIR-POL-ID-BASE-G.
           MOVE SPACES                TO MIR-POL-ID-SFX-G.
           MOVE SPACES                TO MIR-FOLWUP-USER-ID-G.
           MOVE SPACES                TO MIR-FOLWUP-DT-G.
           MOVE SPACES                TO MIR-FOLWUP-ACT-CD-G.
           MOVE SPACES                TO MIR-DV-FOLWUP-TXT-IND-G.

       9110-BLANK-SCR2-DATA-FIELDS-X.
           EXIT.
      *
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------
      *
      * MOVE FILE VALUES TO THE SCREEN
      *
           MOVE RCH-CLI-CNTCT-TYP-CD  TO MIR-CLI-CNTCT-TYP-CD.
013578*
013578* FIND THE ACTIVITY CODE DESCRIPTION FROM EDIT AND DISPLAY
013578*
013578*    MOVE RCH-CLI-CNTCT-TYP-CD  TO WEDIT-ETBL-VALU-ID.
013578*
013578*    PERFORM  CHAC-2000-DESC
013578*        THRU CHAC-2000-DESC-X.
013578*
013578*    IF  WEDIT-IO-OK
013578*        MOVE REDIT-ETBL-DESC-TXT
013578*                               TO MIR-EDTTO-T (1)
013578*    ELSE
013578*        MOVE SPACES            TO MIR-EDTTO-T (1)
013578*    END-IF.

014221*    MOVE RCH-USER-ID           TO MIR-USER-ID.
014221     MOVE RCH-PREV-UPDT-USER-ID TO MIR-USER-ID.
           MOVE RCH-CLI-CNTCT-SUB-CD  TO MIR-CLI-CNTCT-SUB-CD.
           MOVE RCH-CLI-CNTCT-RETEN-CD        TO MIR-CLI-CNTCT-RETEN-CD.
           MOVE RCH-POL-ID            TO MIR-POL-ID.

           MOVE RCH-FOLWUP-DT         TO L1640-INTERNAL-DATE.

020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           IF  L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-FOLWUP-DT
           ELSE
               MOVE SPACES            TO MIR-FOLWUP-DT
           END-IF.

           MOVE RCH-FOLWUP-USER-ID    TO MIR-FOLWUP-USER-ID.
           MOVE RCH-FOLWUP-ACT-CD     TO MIR-FOLWUP-ACT-CD.
      *
      * FIND FOLLOW UP ACTION DESCRIPTON ON EDIT TABLE AND DISPLAY
      *
013578*    MOVE RCH-FOLWUP-ACT-CD     TO WEDIT-ETBL-VALU-ID.
013578*
013578*    PERFORM  FPAC-2000-DESC
013578*        THRU FPAC-2000-DESC-X.
013578*
013578*    IF  WEDIT-IO-OK
013578*        MOVE REDIT-ETBL-DESC-TXT
013578*                               TO MIR-EDTTO-T (2)
013578*    ELSE
013578*        MOVE SPACES            TO MIR-EDTTO-T (2)
013578*    END-IF.

           MOVE RCH-FOLWUP-NOTE-TXT   TO MIR-FOLWUP-NOTE-TXT.

020460     IF  RCH-PAAFLD-GR-TS = WWKDT-ZERO-TS
020460         MOVE SPACES            TO MIR-PAAFLD-GR-TS
020460     ELSE
020460         MOVE RCH-PAAFLD-GR-TS  TO MIR-PAAFLD-GR-TS
020460     END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      *
      *---------------------------
       9250-MOVE-TO-BROWSE-SCREEN.
      *---------------------------

           MOVE 'Y'                   TO WS-IF-ANY-RECORDS-DISPLAYED.
           MOVE RCH-CLI-ID            TO MIR-CLI-ID-T (WS-SUB).

           MOVE RCH-CLI-CNTCT-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CLI-CNTCT-DT-T (WS-SUB).

           MOVE RCH-CLI-CNTCT-SEQ-NUM
                                    TO MIR-CLI-CNTCT-SEQ-NUM-T (WS-SUB).
           MOVE RCH-CLI-CNTCT-TYP-CD TO MIR-CLI-CNTCT-TYP-CD-T (WS-SUB).
           MOVE RCH-CLI-CNTCT-SUB-CD TO MIR-CLI-CNTCT-SUB-CD-T (WS-SUB).
           MOVE RCH-CLI-CNTCT-RETEN-CD
                                   TO MIR-CLI-CNTCT-RETEN-CD-T (WS-SUB).
           MOVE RCH-POL-ID-BASE       TO MIR-POL-ID-BASE-T (WS-SUB).
           MOVE RCH-POL-ID-SFX        TO MIR-POL-ID-SFX-T (WS-SUB).
           MOVE RCH-FOLWUP-USER-ID    TO MIR-FOLWUP-USER-ID-T (WS-SUB).

           MOVE RCH-FOLWUP-DT         TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-FOLWUP-DT-T (WS-SUB).

           MOVE RCH-FOLWUP-ACT-CD     TO MIR-FOLWUP-ACT-CD-T (WS-SUB).

           IF  RCH-FOLWUP-NOTE-TXT GREATER THAN SPACES
               MOVE 'Y'              TO MIR-DV-FOLWUP-TXT-IND-T (WS-SUB)
           ELSE
               MOVE 'N'              TO MIR-DV-FOLWUP-TXT-IND-T (WS-SUB)
           END-IF.

       9250-MOVE-TO-BROWSE-SCREEN-X.
           EXIT.
      *
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------
      *
      * MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *      TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *
           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'C'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-CLI-ID            TO WGLOB-REF-CLIENT-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0220-0000-INIT-PARM-INFO
025970         THRU 0220-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1646-0000-INIT-PARM-INFO
025970         THRU 1646-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  3188-0000-INIT-PARM-INFO
025970         THRU 3188-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

025970     SET WS-TRANS-NAME-DEFAULT  TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT    TO TRUE.
025970     SET WS-MAX-BROWSE-LINES-DEFAULT
025970                                TO TRUE.
025970     SET WS-FOUND-NO            TO TRUE.
025970     SET WS-CONTROL-ERROR-NO    TO TRUE.
025970     SET WS-NEXT-REC-NOT-FOUND  TO TRUE.
025970 
025970     MOVE SPACES                TO WWKDT-WORK-FIELDS.

025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      *
      ***********************************************
      *  PROCESSING COPYBOOKS
      ***********************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY CCPECHAC.
       COPY CCPEFPAC.
       COPY XCPPEXIT.
       COPY XCPPINIT.
014660*COPY XCPPMEXT.
018764*COPY CCCL5400.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL5400.
025970 COPY XCPS8090.
016440 COPY CCPS5400.
018764*COPY CCCL5600.
018764 COPY CCPL5600.
       COPY CCPS5600.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CLI
014221                         '$VAR2' BY 'CLI'.
      *
      ***********************************************
      *  LINKAGE COPYBOOKS
      ***********************************************
025970 COPY XCPS0280.
       COPY XCPL0280.
025970 COPY XCPS1640.
       COPY XCPL1640.
020460 COPY XCPL1646.
020460 COPY XCPS1646.
      *
018764*COPY XCCL8090.
018764 COPY XCPL8090.
018764*COPY XCCL0220.
025970 COPY XCPS0220.
018764 COPY XCPL0220.
018764*COPY CCCL2435.
018764 COPY CCPL2435.
       COPY CCPS2435.
      *
020460 COPY CCPS3188.
020460 COPY CCPL3188.
      *
      ***********************************************
      *  MESSAGE PROCESSING COPYBOOK
      ***********************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
      ***********************************************
      *  FILE I/O  COPYBOOKS
      ***********************************************
      *
       COPY CCPNEDIT.
      *
       COPY CCPCCH.
      *
       COPY CCPACH.
      *
       COPY CCPBCHUA.
      *
016537*COPY CCPBCH.
      *
       COPY CCPVCH.
      *
       COPY CCPNCH.
      *
       COPY CCPUCH.
      *
       COPY CCPXCH.
      *
010310 COPY CCPFCH.
      *
014221 COPY CCPNCLI.
014221 COPY CCPUCLI.
      *
       COPY CCPBRL.
016440 COPY CCPNPOL.
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM0351                     **
      *****************************************************************
