      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM1885.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM1885                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE NEXT VALUATION DATE     **
      **            CHANGE                                           **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
021239**  6.4       FUND UNIT VALUE                                  **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM1885'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-VNXTDT         VALUE '1885'.
           05  WS-FND-NXT-VALN-DT            PIC X(10).
           05  WS-FNDVL-EFF-DT               PIC X(10).
           05  WS-OVRID-SW                   PIC X(01).
               88  WS-OVRID                  VALUE 'Y'.

       01  WS-CONSTANT-AREA.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970*                                      VALUE '1880'.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '1880'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY SCFWFH.
       COPY SCFRFH.

       COPY SCFWFVAA.
       COPY SCFRFV.

       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL1640.
       COPY XCWL1670.
       COPY XCWL1680.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM1885.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-VNXTDT
                    PERFORM  2000-NXT-VALN-DT
                        THRU 2000-NXT-VALN-DT-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE WPGWS-CRNT-PGM-ID
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                     TO TRUE

           END-EVALUATE.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED    TO TRUE
           END-IF.

       1000-PROCESS-REQUEST-X.
           EXIT.

      *----------------------------
       2000-NXT-VALN-DT.
      *----------------------------

           PERFORM  2100-VALIDATE-DATA
               THRU 2100-VALIDATE-DATA-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               IF  MIR-DV-PRCES-STATE-CD = '3'
                   PERFORM  FH-3000-UNLOCK
                       THRU FH-3000-UNLOCK-X
               END-IF
               GO TO 2000-NXT-VALN-DT-X
           END-IF.

           IF  NOT MIR-DV-PRCES-STATE-CD = '3'
               GO TO 2000-NXT-VALN-DT-X
           END-IF.

           PERFORM  9350-SETUP-AUDIT-INFO
               THRU 9350-SETUP-AUDIT-INFO-X.

           MOVE WS-FND-NXT-VALN-DT          TO RFH-FND-NXT-VALN-DT.

      *MSG: FH RECORD UPDATED WITH NEXT VALUATION DATE
           MOVE 'SS18850001'                TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  FH-2000-REWRITE
               THRU FH-2000-REWRITE-X.

           PERFORM  9350-SETUP-AUDIT-INFO
               THRU 9350-SETUP-AUDIT-INFO-X.

           PERFORM  FH-1000-READ-TWRK-TS
               THRU FH-1000-READ-TWRK-TS-X.

       2000-NXT-VALN-DT-X.
           EXIT.

      *----------------------------
       2100-VALIDATE-DATA.
      *----------------------------

           PERFORM  2110-EDIT-FND-ID
               THRU 2110-EDIT-FND-ID-X.

           PERFORM  2120-EDIT-FND-NXT-VALN-DT
               THRU 2120-EDIT-FND-NXT-VALN-DT-X.

       2100-VALIDATE-DATA-X.
           EXIT.

      *----------------------------
       2110-EDIT-FND-ID.
      *----------------------------

           MOVE MIR-FND-ID                  TO WFH-FND-ID.

           IF  MIR-DV-PRCES-STATE-CD = '3'
               PERFORM  FH-2000-UPDATE-TWRK-TS
                   THRU FH-2000-UPDATE-TWRK-TS-X
           ELSE
               PERFORM  FH-1000-READ-TWRK-TS
                   THRU FH-1000-READ-TWRK-TS-X
           END-IF.

           IF  WFH-IO-NOT-FOUND
      *MSG: @1 RECORD (@2) NOT FOUND
               MOVE 'XS00000001'            TO WGLOB-MSG-REF-INFO
               MOVE 'FH'                    TO WGLOB-MSG-PARM (1)
               MOVE WFH-KEY                 TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2110-EDIT-FND-ID-X
           END-IF.

           IF  MIR-DV-PRCES-STATE-CD = '3'
           AND MIR-RETRN-TS-MISMATCH
      *MSG: TIMESTAMP MISMATCH - TABLE (@1) KEY (@2),
      *     PROCESS NOT COMPLETE
               MOVE 'XS00000303'            TO WGLOB-MSG-REF-INFO
               MOVE 'FH'                    TO WGLOB-MSG-PARM (1)
               MOVE WFH-FND-ID              TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2110-EDIT-FND-ID-X
           END-IF.

           MOVE RFH-FND-TYP-CD              TO MIR-FND-TYP-CD.

       2110-EDIT-FND-ID-X.
           EXIT.

      *----------------------------
       2120-EDIT-FND-NXT-VALN-DT.
      *----------------------------

           MOVE MIR-FND-NXT-VALN-DT         TO L1640-EXTERNAL-DATE.

           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      *MSG: INVALID NEXT FUND VALUATION DATE
               MOVE 'SS18850002'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2120-EDIT-FND-NXT-VALN-DT-X
           END-IF.

           MOVE L1640-INTERNAL-DATE   TO WS-FND-NXT-VALN-DT.

           MOVE LOW-VALUES            TO WFVAA-KEY.

           MOVE MIR-FND-ID            TO WFVAA-FND-ID.

           MOVE WFVAA-KEY             TO WFVAA-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WFVAA-ENDBR-FNDVL-IDT-NUM.
           MOVE HIGH-VALUES           TO WFVAA-ENDBR-FNDVL-UNIT-TYP-CD.

           PERFORM  FVAA-1000-BROWSE
               THRU FVAA-1000-BROWSE-X.

           PERFORM  FVAA-2000-READ-NEXT
               THRU FVAA-2000-READ-NEXT-X.

           IF  NOT WFVAA-IO-OK
      *MSG: @1 RECORD (@2) NOT FOUND
               MOVE 'XS00000001'            TO WGLOB-MSG-REF-INFO
               MOVE 'FV'                    TO WGLOB-MSG-PARM (1)
               MOVE MIR-FND-ID              TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  FVAA-3000-END-BROWSE
                   THRU FVAA-3000-END-BROWSE-X
               GO TO 2120-EDIT-FND-NXT-VALN-DT-X
           END-IF.

           MOVE RFV-FNDVL-EFF-DT            TO WS-FNDVL-EFF-DT.

           MOVE RFV-FNDVL-EFF-DT            TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE         TO MIR-FNDVL-EFF-DT.

           PERFORM  FVAA-3000-END-BROWSE
               THRU FVAA-3000-END-BROWSE-X.

           IF  WS-FND-NXT-VALN-DT <= WS-FNDVL-EFF-DT
               SET WS-OVRID                 TO TRUE
      *MSG: NEXT VALUATION DATE MUST BE GREATER THAN EFFECTIVE DATE
               MOVE 'SS18850003'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  WS-FND-NXT-VALN-DT <= RFH-PREV-UNIT-ALLOC-DT
               SET WS-OVRID                 TO TRUE
      *MSG: NEXT VALUATION DATE MUST BE GREATER THAN LAST ALLOCATION
      *     DATE
               MOVE 'SS18850004'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE WS-FND-NXT-VALN-DT         TO L1680-INTERNAL-2.
           MOVE WS-FNDVL-EFF-DT            TO L1680-INTERNAL-1.
           PERFORM  1680-2000-COMP-DAYS-BETWEEN
               THRU 1680-2000-COMP-DAYS-BETWEEN-X.
           COMPUTE L1680-NUMBER-OF-MONTHS = L1680-NUMBER-OF-MONTHS
                   + (L1680-NUMBER-OF-YEARS * 12).

           IF (L1680-NUMBER-OF-MONTHS > RFH-MAX-VALN-MO-DUR-N)
           OR ((L1680-NUMBER-OF-DAYS > RFH-MAX-VALN-DY-DUR-N) AND
               (L1680-NUMBER-OF-MONTHS = RFH-MAX-VALN-MO-DUR-N))
               SET WS-OVRID                 TO TRUE
      *MSG: TIME BETWEEN VALUATION DATES EXCEEDS MAX. VAL. PERIOD
               MOVE 'SS18850005'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF (L1680-NUMBER-OF-MONTHS < RFH-MIN-VALN-MO-DUR-N)
               OR ((L1680-NUMBER-OF-DAYS < RFH-MIN-VALN-DY-DUR-N)
               AND (L1680-TOTAL-DAYS < RFH-MIN-VALN-DY-DUR-N)
               AND (L1680-NUMBER-OF-MONTHS = RFH-MIN-VALN-MO-DUR-N))
               SET WS-OVRID                 TO TRUE
      *MSG: TIME BETWEEN VAL. DATES IS LESS THAN MIN. VAL. PERIOD
                   MOVE 'SS18850006'        TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
            END-IF

           IF  WS-OVRID
               MOVE 'Y'                     TO MIR-DV-PRCES-OVRID-IND
           END-IF.

       2120-EDIT-FND-NXT-VALN-DT-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                     TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE         TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------
       9350-SETUP-AUDIT-INFO.
      *----------------------

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM  FH-1000-CALL-AUDIT
                   THRU FH-1000-CALL-AUDIT-X
           END-IF.

       9350-SETUP-AUDIT-INFO-X.
           EXIT.
      /
      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE MIR-OUTPUT-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

025970     SET WS-TWRK-KEY-DEFAULT     TO TRUE.
025970
       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  FH
                                '$VAR2'   BY 'FH'.
       COPY XCPL8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
025970 COPY XCPS1670.
025970 COPY XCPS8090.
025970 COPY XCPS1640.
       COPY XCPL1640.

025970 COPY XCPS1680.
       COPY XCPL1680.

       COPY SCPLFH.

      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY SCPNFH.
       COPY SCPUFH.

       COPY SCPBFVAA.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM SSOM1885                        **
      *****************************************************************
