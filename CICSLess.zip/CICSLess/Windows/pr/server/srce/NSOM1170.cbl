       IDENTIFICATION DIVISION.
       PROGRAM-ID. NSOM1170.
       COPY XCWWCRHT.
      *****************************************************************
      **  MEMBER :  NSOM1170                                         **
      **  REMARKS:  UCON - MAINTAIN UNDERWRITER WORKSHEETS.          **
      **            THIS MODULE MAINTAINS THE UNDERWRITERS WORKSHEETS**
      **            VIA THE UCON TRANSACTION.  THE UNDERWRITER CAN   **
      **            RECORD AND REVIEW CONFIDENTIAL INFORMATION FOR A **
      **            CLIENT AS WELL AS MIB CODES RETURNED.            **
      **                                                             **
      **  DOMAIN :  UW                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557667**  5.5       ADDITIONAL CLIENT INFO                           **
557698**  5.5       MIXED-CASE SUPPORT                               **
557708**  5.5       ABEND HANDLING                                   **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       REMOVE UNUSED FIELDS                             **
010418**  5.6       SET UP SUBSIDIARY COMPANY ID                     **
012624**  6.0       GLOBAL SECURITY CHANGES                          **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015508**  6.0       CLIENT ENHANCEMENTS FOR JAPAN                    **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
017418**  6.2       MAX. OCC. FOR MIB RECORD                         **
018732**  6.3       CLIENT RETRIEVAL ENHANCEMENTS                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023118**  6.5       CODE CLEAN-UP AND STANDARDIZATION                **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      *---------------------
       ENVIRONMENT DIVISION.
      *---------------------

      *--------------
       DATA DIVISION.
      *--------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM1170'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME                 PIC X(04) VALUE 'UCON'.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-VALID                    VALUE '1170'
                                                             '1172'.
               88  WS-BUS-FCN-RETRIEVE                 VALUE '1170'.
               88  WS-BUS-FCN-UPDATE                   VALUE '1172'.
025970*    05  WS-TWRK-KEY                   PIC X(04) VALUE '1170'.

           05  WS-SUBSCRIPTS.
016537*        10  WS-SCRN                   PIC S9(4) COMP.
016537         10  WS-SCRN                   PIC S9(4) BINARY.
016537*        10  WS-FILE                   PIC S9(4) COMP.
016537         10  WS-FILE                   PIC S9(4) BINARY.
016537*        10  WS-OLD-POS                PIC S9(4) COMP.
016537         10  WS-OLD-POS                PIC S9(4) BINARY.
016537*        10  WS-NEW-POS                PIC S9(4) COMP.
016537         10  WS-NEW-POS                PIC S9(4) BINARY.
016537*        10  WS-SUB                    PIC S9(4) COMP.
016537         10  WS-SUB                    PIC S9(4) BINARY.

           05  WS-SWITCHES.
               10  WS-MIB-UPDATE-SW          PIC X.
                   88  WS-MIB-UPDATE              VALUE 'Y'.
               10  WS-MIB-VALID-SW           PIC X    OCCURS 60 TIMES.
                   88  WS-MIB-VALID               VALUE ' '.
                   88  WS-MIB-INVALID             VALUE 'C' 'T' 'B'.
                   88  WS-MIB-CODE-TYPE-INVALID   VALUE 'T'.
                   88  WS-MIB-CODE-INVALID        VALUE 'C'.
                   88  WS-MIB-BOTH-INVALID        VALUE 'B'.
               10  WS-KEY-FIELDS-OK-SW       PIC X(01).
                   88  KEYS-FIELDS-OK             VALUE 'Y'.
               10  WS-EDITS-OK-SW            PIC X(01).
                   88  WS-EDITS-OK                VALUE 'Y'.
               10  WS-MIB-SECURITY-SW        PIC X.
                   88  WS-MIB-SECURITY-OK         VALUE 'Y'.
               10  WS-MIB-AT-LEAST-1-UPDATED-SW PIC X.
                   88  WS-MIB-AT-LEAST-1-UPDATED  VALUE 'Y'.
               10  WS-INSUR-TYPE               PIC X(01).
                   88  WS-LIFE                 VALUE 'L'.
                   88  WS-HEALTH               VALUE 'H'.
                   88  WS-NOT-TYPE-SPECIFIC    VALUE ' '.
       01  WS-MISC.
016537*    05  WS-MAX-MIB-CODES-SCREEN       PIC S9(4) COMP  VALUE +60.
025970*    05  WS-MAX-MIB-CODES-SCREEN       PIC S9(4)
025970*                                      BINARY  VALUE +60.
016537*    05  WS-MAX-WORKSHEET              PIC S9(4) COMP  VALUE +99.
025970*    05  WS-MAX-WORKSHEET              PIC S9(4)
025970*                                      BINARY  VALUE +99.
008455*    05  WS-WRK-8-0                    PIC 9(8).
008455*    05  WS-EDIT-8-0                   PIC ZZZZZZZ9.
008455*    05  WS-EDIT-9-0                   PIC ZZZZZZZZ9.
008455*    05  WS-EDIT-9-2                   PIC ZZZZZZZZ9.99.
           05  WS-EDIT-MIB-CODE-TYPE         PIC X.
               88  WS-VALID-MIB-CODE-TYPE         VALUE ' ' 'N' 'S'.
016537*    05  WS-LAST-MIB-CODE              PIC S9(4) COMP.
016537     05  WS-LAST-MIB-CODE              PIC S9(4) BINARY.
           05  WS-SAVE-RUCON-DATA-REC        PIC X(1600).
      *
      *  ONE FIELD REQUIRED BY CCPSPGA IS HARDCODED SO THAT
      *  THE POLICY TABLE DOES NOT NEED TO BE INCLUDED
      *
           05  RPOL-POL-ID                  PIC X(10) VALUE SPACES.
010311*    05  RPOL-POL-BASE-CVG-NUM        PIC 9(02) VALUE ZERO.
010311*    05  HOLD-RUN-ID                  PIC X(01) VALUE '0'.
      /
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME                 PIC X(04).
025970         88  WS-DEFAULT-TRANS-NAME               VALUE 'UCON'.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                 VALUE '1170'.
025970     05  WS-MAX-MIB-CODES-SCREEN       PIC S9(4) BINARY.
025970         88  WS-DEFAULT-MAX-MIB-CODES            VALUE +60.
025970     05  WS-MAX-WORKSHEET              PIC S9(4) BINARY.
025970         88  WS-DEFAULT-MAX-WORKSHEET            VALUE +99.
      /
      ****************************************************************
      *  COMMON COPYBOOKS
      ****************************************************************
       COPY XCWWWKDT.
014221 COPY CCWWLOCK.
028298 COPY CCWL2626.
       COPY XCWL0280.
014221 COPY XCWL8090.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION
      ****************************************************************
557667 COPY CCWL2432.
      /
018732 COPY CCWL2435.
      /
008455 COPY XCWL0290.
008455/
       COPY NCWL0303.
      /
010418 COPY CCWL3320.
      /
       COPY CCWL5600.
      /
       COPY NCWL5850.
      /
      /
       COPY XCWEBLCH.
      /
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
       COPY CCWLPGA.
      /
       COPY CCWL0063.
       COPY CCWL0620.
       COPY NCWL1180.
       COPY XCWL1640.
       COPY XCWLDTLK.
      /
       COPY NCFWAPPF.
       COPY NCFRAPPF.
      /
023447*COPY NCFWDOCM.
023447*COPY NCFRDOCM.
023447 COPY XCFWDOCM.
023447 COPY XCFRDOCM.
      /
       COPY CCFWCLI.
       COPY CCFRCLI.
      /
021930*COPY CCFWCLNM.
021930*COPY CCFRCLNM.
021930*
021930*COPY CCFWCLNC.
021930*COPY CCFRCLNC.
021930*
016537*COPY CCFRCLIA.
016537*COPY CCFWCLIA.
      /
010418 COPY CCFRSCOM.
010418 COPY CCFWSCOM.
      /
       COPY NCFWUCON.
       COPY NCFRUCON.
      /
      *----------------
       LINKAGE SECTION.

CVMQ71 COPY XCWWDFH.
      *----------------

      /
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM1170.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023118
023118     PERFORM  9990-INIT-WORKING-STORAGE
023118         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------

025970     PERFORM  0290-1000-BUILD-PARM-INFO
025970         THRU 0290-1000-BUILD-PARM-INFO-X.
025970
025970     PERFORM  9300-SETUP-MSIN-REFERENCE
025970         THRU 9300-SETUP-MSIN-REFERENCE-X.
025970
025970     PERFORM  PGA-1000-BUILD-PARMS
025970         THRU PGA-1000-BUILD-PARMS-X.
025970*
023118*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
023118*    SET MIR-RETRN-OK           TO TRUE.
023118*    SET WS-EDITS-OK            TO TRUE.
023118*
018732     MOVE MIR-CLI-ID            TO L2435-CLI-ID.

018732     PERFORM  2435-1000-OBTAIN-CLI-INFO
018732         THRU 2435-1000-OBTAIN-CLI-INFO-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-PROCESS-UPDATE
                        THRU 5000-PROCESS-UPDATE-X

               WHEN OTHER
                    SET MIR-RETRN-INVALD-RQST
                                      TO TRUE
                    GO TO 2000-PROCESS-REQUEST-X

           END-EVALUATE.

           IF  (MIR-DOC-ID NOT = SPACES)
           AND (WGLOB-MSG-ERROR-SW = ZERO)
               PERFORM  7000-PRINT-DOCUMENT
                   THRU 7000-PRINT-DOCUMENT-X
           END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *-----------------------
       3000-PROCESS-RETRIEVE.
      *-----------------------

           PERFORM  3100-VALIDATE-CONTROL-FIELDS
               THRU 3100-VALIDATE-CONTROL-FIELDS-X
           IF NOT WS-EDITS-OK
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  3200-GET-WORKSHEET
               THRU 3200-GET-WORKSHEET-X.

           IF NOT WS-EDITS-OK
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

      *MSG MAINTAIN DETAILS
           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *-----------------------------
       3100-VALIDATE-CONTROL-FIELDS.
      *-----------------------------

      *****************************************************************
      *   VALIDATE CONTROL FIELDS:
      *   CHECK VALIDITY OF ALL KEY AND CONTROL FIELDS.
      *   NUMERIC FIELDS ARE RIGHT JUSTIFIED, ZERO FILLED AND CHECKED
      *   FOR VALIDITY.
      *****************************************************************

      *  EDIT CLIENT NUMBER
      *
           MOVE MIR-CLI-ID            TO WCLI-CLI-ID.
014221*    PERFORM  CLI-1000-READ
014221*        THRU CLI-1000-READ-X.

014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

           IF NOT WCLI-IO-OK
               MOVE MIR-CLI-ID        TO WGLOB-MSG-PARM (1)
      *MSG CLIENT (@1) DOES NOT EXIST
               MOVE 'XS00000076'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 3100-VALIDATE-CONTROL-FIELDS-X
           END-IF.

018732*    INITIALIZE RCLNC-REC-INFO.
018732*    INITIALIZE RCLNM-REC-INFO.
015508
018732*    IF  RCLI-CLI-SEX-COMPANY
018732*        MOVE LOW-VALUES        TO WCLNC-KEY
018732*        MOVE RCLI-CLI-ID       TO WCLNC-CLI-ID
018732*        SET WCLNC-CLI-CO-GR-ALPHA
018732*                               TO TRUE
018732*        SET WCLNC-CLI-CO-NM-TYP-CLI
018732*                               TO TRUE
015508
018732*        PERFORM  CLNC-1000-READ
018732*            THRU CLNC-1000-READ-X
018732*    ELSE
018732*        MOVE LOW-VALUES        TO WCLNM-KEY
018732*        MOVE RCLI-CLI-ID       TO WCLNM-CLI-ID
018732*        SET WCLNM-CLI-INDV-GR-ALPHA
018732*                               TO TRUE
018732*        SET WCLNM-CLI-INDV-NM-TYP-CRNT
018732*                               TO TRUE
018732*        MOVE +1                TO WCLNM-CLI-INDV-SEQ-NUM
015508
018732*        PERFORM  CLNM-1000-READ
018732*            THRU CLNM-1000-READ-X
018732*    END-IF.
015508
           PERFORM 5600-0000-INIT-PARM-INFO
              THRU 5600-0000-INIT-PARM-INFO-X.
           PERFORM 5600-1000-BUILD-PARM-INFO
              THRU 5600-1000-BUILD-PARM-INFO-X.
           MOVE MIR-CLI-ID            TO L5600-CLI-ID.
           PERFORM 5600-1000-CLI-CHK
              THRU 5600-1000-CLI-CHK-X.
      *
      *  EDIT CLIENT NUMBER
      *
           IF  NOT L5600-RETRN-OK
           OR  L5600-CNFD-ACCS-RESTRICTED
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 3100-VALIDATE-CONTROL-FIELDS-X
           END-IF.

           IF  NOT L5600-RETRN-OK
           OR  L5600-CCAS-ACCS-RESTRICTED
      *MSG CLIENT LOCK ON CLEAR CASE
               MOVE 'NS11700022'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 3100-VALIDATE-CONTROL-FIELDS-X
           END-IF.

           IF  MIR-UWG-WRKSHT-NUM = ZERO
               MOVE SPACE             TO MIR-UWG-WRKSHT-NUM
           END-IF.

           IF  MIR-UWG-WRKSHT-NUM = SPACES
               GO TO 3100-VALIDATE-CONTROL-FIELDS-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-LENGTH.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE +2                    TO L0280-INPUT-SIZE.
           MOVE MIR-UWG-WRKSHT-NUM    TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF NOT L0280-OK
      *MSG WORKSHEET MUST BE NUMERIC
               MOVE 'NS11700001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 3100-VALIDATE-CONTROL-FIELDS-X
           END-IF.

           IF L0280-OUTPUT NOT > ZERO
      *MSG WORKSHEET NUMBER MUST BE GREATER THAN ZERO
               MOVE 'NS11700002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 3100-VALIDATE-CONTROL-FIELDS-X
           END-IF.

       3100-VALIDATE-CONTROL-FIELDS-X.
           EXIT.
      /
      *-------------------
       3200-GET-WORKSHEET.
      *-------------------

      *****************************************************************
      *   GET THE WORKSHEET REQUESTED FOR THIS CLIENT
      *****************************************************************

      *
      *  CLIENT HAS NO WORKSHEETS YET
      *
           IF RCLI-UWG-WRKSHT-NUM = ZEROS
               PERFORM  3210-CREATE-WORKSHEET
                   THRU 3210-CREATE-WORKSHEET-X
               GO TO 3200-GET-WORKSHEET-X
           END-IF.
      *
      *  GET A SPECIFIED WORKSHEET
      *
           IF  (MIR-UWG-WRKSHT-NUM NOT = SPACES)
           AND (MIR-UWG-WRKSHT-NUM < RCLI-UWG-WRKSHT-NUM)
               PERFORM  8000-BUILD-UCON-KEY
                   THRU 8000-BUILD-UCON-KEY-X
               PERFORM  UCON-1000-READ
                   THRU UCON-1000-READ-X
               IF NOT WUCON-IO-OK
                   MOVE WUCON-KEY     TO WGLOB-MSG-PARM (1)
      *MSG WORKSHEET LOST - KEY: @1 - CONTACT SYSTEMS
                   MOVE 'NS11700003'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-EDITS-OK-SW
                   GO TO 3200-GET-WORKSHEET-X
               ELSE
      *MSG WORKSHEET IS NOT CURRENT
                   MOVE 'NS11700004'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 3200-GET-WORKSHEET-X
               END-IF
           END-IF.
      *
      *  GET LAST WORKSHEET
      *
           MOVE MIR-CLI-ID            TO WUCON-CLI-ID.
           MOVE RCLI-UWG-WRKSHT-NUM-N TO WUCON-UWG-WRKSHT-NUM-N.

           PERFORM  UCON-1000-READ-FOR-UPDATE
               THRU UCON-1000-READ-FOR-UPDATE-X.

           IF NOT WUCON-IO-OK
               MOVE WUCON-KEY         TO WGLOB-MSG-PARM (1)
      *MSG WORKSHEET LOST - KEY: @1 - CONTACT SYSTEMS
               MOVE 'NS11700003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 3200-GET-WORKSHEET-X
           END-IF.
      *
      *  DETERMINE IF LAST WORKSHEET IS CURRENT
      *
           MOVE RUCON-REC-INFO        TO WS-SAVE-RUCON-DATA-REC.

           MOVE RUCON-CLI-ID          TO L1180-CLI-ID.
           PERFORM 1180-1000-BUILD-PARM-INFO
              THRU 1180-1000-BUILD-PARM-INFO-X.
           PERFORM  1180-2000-GET-WORKSHEET
               THRU 1180-2000-GET-WORKSHEET-X.
           PERFORM 1180-2000-RETRN-PARM-INFO
              THRU 1180-2000-RETRN-PARM-INFO-X.
      *
      *  IF UCON RECORD MAY HAVE CHANGED DUE TO DYNAMIC ALLOCATION
      *
           IF RUCON-REC-INFO NOT = WS-SAVE-RUCON-DATA-REC
               PERFORM UCON-2000-REWRITE
                   THRU UCON-2000-REWRITE-X
           ELSE
               PERFORM UCON-3000-UNLOCK
                   THRU UCON-3000-UNLOCK-X
           END-IF.

           IF L1180-WORKSHEET-CURRENT
               IF  (MIR-UWG-WRKSHT-NUM NOT = SPACES)
               AND (MIR-UWG-WRKSHT-NUM > RCLI-UWG-WRKSHT-NUM)
                   MOVE WUCON-UWG-WRKSHT-NUM
                                      TO WGLOB-MSG-PARM (1)
      *MSG WORKSHEET @1 IS STILL CURRENT
                   MOVE 'NS11700005'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-EDITS-OK-SW
                   GO TO 3200-GET-WORKSHEET-X
               END-IF
           END-IF.

           IF NOT L1180-WORKSHEET-CURRENT
               IF  (MIR-UWG-WRKSHT-NUM NOT = SPACES)
               AND (MIR-UWG-WRKSHT-NUM = RCLI-UWG-WRKSHT-NUM)
      *MSG WORKSHEET IS NOT CURRENT
                   MOVE 'NS11700004'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
                   PERFORM  3210-CREATE-WORKSHEET
                       THRU 3210-CREATE-WORKSHEET-X
               END-IF
           END-IF.

           MOVE RUCON-UWG-WRKSHT-NUM  TO MIR-UWG-WRKSHT-NUM.

       3200-GET-WORKSHEET-X.
           EXIT.
      /
      *----------------------
       3210-CREATE-WORKSHEET.
      *----------------------

      *****************************************************************
      *   CREATE THE NEXT WORKSHEET FOR THIS CLIENT
      *****************************************************************

      *
      *   BUILD NAL READ KEY.
      *

           MOVE MIR-CLI-ID            TO WCLI-CLI-ID.
      *
      *  GET NEXT WORKSHEET NUMBER
      *
           PERFORM  CLI-1000-READ-FOR-UPDATE
               THRU CLI-1000-READ-FOR-UPDATE-X.

           IF NOT WCLI-IO-OK
      *MSG CLIENT RECORD LOST - CONTACT SYSTEMS
               MOVE 'NS11700006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 3210-CREATE-WORKSHEET-X
           END-IF.

           IF RCLI-UWG-WRKSHT-NUM-N = WS-MAX-WORKSHEET
      *MSG CLIENT HAS MAXIMUM NUMBER OF WORKSHEETS
               MOVE 'NS11700007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-EDITS-OK-SW
               GO TO 3210-CREATE-WORKSHEET-X
           END-IF.

           ADD +1                     TO RCLI-UWG-WRKSHT-NUM-N.

           PERFORM  CLI-2000-REWRITE
               THRU CLI-2000-REWRITE-X.

014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

      *
      *  SETUP NEXT WORKSHEET
      *
           MOVE RCLI-UWG-WRKSHT-NUM   TO MIR-UWG-WRKSHT-NUM.

           PERFORM  8000-BUILD-UCON-KEY
               THRU 8000-BUILD-UCON-KEY-X.

           PERFORM  UCON-1000-CREATE
               THRU UCON-1000-CREATE-X.

           MOVE RUCON-CLI-ID          TO L1180-CLI-ID.
           PERFORM  1180-1000-BUILD-PARM-INFO
               THRU 1180-1000-BUILD-PARM-INFO-X.
           PERFORM  1180-1000-CREATE-WORKSHEET
               THRU 1180-1000-CREATE-WORKSHEET-X.
           PERFORM  1180-2000-RETRN-PARM-INFO
               THRU 1180-2000-RETRN-PARM-INFO-X.
      *
      *  SET CREATION DATE
      *
           MOVE WGLOB-SYSTEM-DATE-INT TO RUCON-UWG-WRKSHT-DT.
           MOVE WGLOB-SYSTEM-DATE-INT TO L1640-INTERNAL-DATE.

020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE   TO MIR-UWG-WRKSHT-DT.

           PERFORM  UCON-1000-WRITE
               THRU UCON-1000-WRITE-X.

       3210-CREATE-WORKSHEET-X.
           EXIT.

      *--------------------
       5000-PROCESS-UPDATE.
      *--------------------

           PERFORM  8000-BUILD-UCON-KEY
               THRU 8000-BUILD-UCON-KEY-X.

           PERFORM  UCON-1000-READ-FOR-UPDATE
               THRU UCON-1000-READ-FOR-UPDATE-X.

           IF NOT WUCON-IO-OK
               MOVE WUCON-KEY         TO WGLOB-MSG-PARM (1)
      *MSG LOST WORKSHEET (@1) IN MAINTAIN - CONTACT SYSTEMS
               MOVE 'NS11700008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.
      *
      *   BUILD NAL READ KEY.
      *
           MOVE MIR-CLI-ID            TO WCLI-CLI-ID.
      *
      *  LOCK NAL RECORD
      *
014221*    PERFORM  CLI-1000-READ-FOR-UPDATE
014221*        THRU CLI-1000-READ-FOR-UPDATE-X.

014221     PERFORM  CLI-2000-UPDATE-TWRK-TS
014221         THRU CLI-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'CLI'                 TO WGLOB-MSG-PARM (01)
014221        MOVE WCLI-KEY              TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  UCON-3000-UNLOCK
014221             THRU UCON-3000-UNLOCK-X
014221         PERFORM  9100-BLANK-DATA-FIELDS
014221             THRU 9100-BLANK-DATA-FIELDS-X
014221        GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF NOT WCLI-IO-OK
               PERFORM  UCON-3000-UNLOCK
                   THRU UCON-3000-UNLOCK-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           END-IF.

           IF NOT WCLI-IO-OK
               MOVE WCLI-KEY          TO WGLOB-MSG-PARM (1)
      *MSG LOST CLIENT (@1) IN MAINTAIN - CONTACT SYSTEMS
               MOVE 'NS11700009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  5300-EDIT-DATA-FIELDS
               THRU 5300-EDIT-DATA-FIELDS-X.

           PERFORM  5400-SCROLL-MIB-CODES
               THRU 5400-SCROLL-MIB-CODES-X.

      *MSG WORKSHEET UPDATED
           MOVE 'NS11700010'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  UCON-2000-REWRITE
               THRU UCON-2000-REWRITE-X.

      *MSG CLIENT UPDATED
           MOVE 'NS11700011'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  CLI-2000-REWRITE
               THRU CLI-2000-REWRITE-X.

014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

       5000-PROCESS-UPDATE-X.
           EXIT.

      *----------------------
       5300-EDIT-DATA-FIELDS.
      *----------------------

      *****************************************************************
      *   FIELD EDITS: CHECK VALIDITY OF ALL DATA FIELDS.
      *****************************************************************

           IF MIR-CLI-MIB-IND-CD = SPACES
               MOVE RCLI-CLI-MIB-IND-CD
                                      TO MIR-CLI-MIB-IND-CD
           ELSE
      *
      *      EDIT INPUT
      *
               PERFORM  5310-MOVE-MIR-TO-EDIT
                   THRU 5310-MOVE-MIR-TO-EDIT-X

015508*        MOVE RCLI-REC-INFO     TO L0063-HOLD-CLI
015508*        MOVE MIR-CLI-ID        TO WCLIA-CLI-ID
015508*        MOVE 'PR'              TO WCLIA-CLI-ADDR-TYP-CD
015508*        MOVE '001'             TO WCLIA-CLI-ADDR-SEQ-NUM
015508*        PERFORM  CLIA-1000-READ
015508*           THRU  CLIA-1000-READ-X
015508*        MOVE RCLIA-REC-INFO    TO L0063-HOLD-CLIA (1)
               PERFORM  0063-1000-PROCESS-EDITS
                   THRU 0063-1000-PROCESS-EDITS-X
015508*        MOVE  L0063-HOLD-CLI   TO  RCLI-REC-INFO

               PERFORM  5320-MOVE-EDIT-TO-MIR
                   THRU 5320-MOVE-EDIT-TO-MIR-X
           END-IF.
      *
      *  EDIT UCON INPUT
      *    WS-SCRN IS THE INDEX OF THE MIB CODE ON THE SCREEN
      *    WS-FILE IS THE INDEX OF THE CORRESPONDING MIB CODE
      *    ON THE FILE.
      *    SECURITY FOR UPDATING THE MIB CODES WILL BE DETERMINED
      *    FROM THE MESSAGE.  IF SECURITY IS OK MIB CODES WILL BE
      *    UPDATED.  IF SECURITY IS FAILED AND MIB DATA HAS BEEN
      *    UPDATED THE VALUES WILL BE RESTORED
      *
      *MSG 1- SECURITY CLASS DOES NOT ALLOW ACESS TO MIB CODES
      *MSG A- WARNING - SECURITY CLASS ALLOWED UPDATE TO MIB CODES
           MOVE 'NS11700021'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-2000-GET-MESSAGE
               THRU 0260-2000-GET-MESSAGE-X.

           MOVE 'N'                   TO  WS-MIB-SECURITY-SW.

           IF WGLOB-MSG-SEVRTY-WARNING
               MOVE 'Y'               TO  WS-MIB-SECURITY-SW
           END-IF.

           MOVE 'N'                   TO
                WS-MIB-AT-LEAST-1-UPDATED-SW.
           MOVE +1                    TO WS-FILE.

           PERFORM  5330-EDIT-MIB
               THRU 5330-EDIT-MIB-X
               VARYING WS-SCRN FROM 1 BY 1
               UNTIL WS-SCRN > WS-MAX-MIB-CODES-SCREEN.

           IF WS-MIB-AT-LEAST-1-UPDATED
      *MSG 1- SECURITY CLASS DOES NOT ALLOW ACESS TO MIB CODES
      *MSG A- WARNING - SECURITY CLASS ALLOWED UPDATE TO MIB CODES
               MOVE 'NS11700021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   PERFORM  9120-BLANK-MIB-CODE
                       THRU 9120-BLANK-MIB-CODE-X
                       VARYING WS-SUB FROM 1 BY 1
                       UNTIL WS-SUB > WS-MAX-MIB-CODES-SCREEN
                   COMPUTE WS-FILE = +1
                   MOVE 1             TO WS-SCRN
                   PERFORM  9220-LOAD-MIB-CODE
                       THRU 9220-LOAD-MIB-CODE-X
                       VARYING WS-SCRN FROM 1 BY 1
                       UNTIL (WS-SCRN > WS-MAX-MIB-CODES-SCREEN) OR
                         (RUCON-CLI-MIB-DTL-TYP-CD (WS-FILE) = SPACES)
               END-IF
           END-IF.

      *
      *  COMPRESS MIB CODES ON THE SCREEN AND HIGHLIGHT ERRORS
      *    WS-OLD-POS IS THE OLD POSITION OF MIB CODE ON THE SCREEN
      *    WS-NEW-POS WILL BE THE NEW POSITION OF MIB CODE ON THE
      *    SCREEN.
      *
           MOVE ZERO                  TO WS-NEW-POS.
           PERFORM  5340-COMPRESS-SCREEN-CODE
               THRU 5340-COMPRESS-SCREEN-CODE-X
               VARYING WS-OLD-POS FROM 1 BY 1
               UNTIL WS-OLD-POS > WS-MAX-MIB-CODES-SCREEN.

      *
      *  WS-NEW-POS SHOULD BE LAST NON-BLANK/NON-ERROR MIB CODE ON
      *  THE NEW SCREEN
      *

           MOVE WS-NEW-POS            TO WS-LAST-MIB-CODE.
      *
      *  COMPRESS MIB CODES ON THE FILE
      *    WS-OLD-POS IS THE OLD POSITION OF MIB CODE ON THE FILE
      *    WS-NEW-POS IS THE NEW POSITION OF MIB CODE ON THE FILE
      *
           IF WS-NEW-POS < WS-MAX-MIB-CODES-SCREEN
               MOVE +1                TO WS-NEW-POS
               PERFORM  5350-COMPRESS-FILE-CODE
                   THRU 5350-COMPRESS-FILE-CODE-X
                   VARYING WS-OLD-POS FROM +1 BY 1
                   UNTIL WS-OLD-POS > WUCON-MAX-MIB-CODES
               PERFORM  5355-BLANK-FILE-CODE
                   THRU 5355-BLANK-FILE-CODE-X
                   VARYING WS-NEW-POS FROM WS-NEW-POS BY 1
                   UNTIL WS-NEW-POS > WUCON-MAX-MIB-CODES
           END-IF.
      *
      *  EDIT COMMENTS
      *
           PERFORM  5360-EDIT-COMMENT
               THRU 5360-EDIT-COMMENT-X.

           MOVE RUCON-CNFD-COMNT-TXT  TO MIR-CNFD-COMNT-TXT.

       5300-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      *****************************************************************
      *   MOVE MIR FIELDS TO THE EDIT WORK AREA FIELDS
      *****************************************************************
      *----------------------
       5310-MOVE-MIR-TO-EDIT.
      *----------------------


           INITIALIZE L0063-PARM-INFO.
015508*    MOVE MIR-CLI-MIB-IND-CD    TO L0063-MIB5.
015508     MOVE MIR-CLI-MIB-IND-CD    TO L0063-CLI-MIB-IND-CD.

       5310-MOVE-MIR-TO-EDIT-X.
           EXIT.
      /
      *****************************************************************
      *   MOVE EDIT WORK AREA FIELDS TO MIR FIELDS
      *****************************************************************
      *----------------------
       5320-MOVE-EDIT-TO-MIR.
      *----------------------

015508*    IF L0063-MIB5 = HIGH-VALUES
015508     IF L0063-CLI-MIB-IND-CD = HIGH-VALUES
               CONTINUE
           ELSE
015508         MOVE L0063-CLI-MIB-IND-CD
015508                                TO MIR-CLI-MIB-IND-CD
015508*        MOVE L0063-MIB5        TO MIR-CLI-MIB-IND-CD
      *
      *  FATAL CROSS EDITS SHOULD NOT AFFECT UCON PROCESSING
      *
               MOVE ZERO              TO WGLOB-MSG-ERROR-SW
           END-IF.

       5320-MOVE-EDIT-TO-MIR-X.
           EXIT.
      /
      *--------------
       5330-EDIT-MIB.
      *--------------

      *****************************************************************
      *   EDIT MIB CODE AND TYPE
      *****************************************************************

           MOVE SPACES                TO WS-MIB-VALID-SW (WS-SCRN).
           MOVE SPACES                TO WS-MIB-UPDATE-SW.

           PERFORM  5331-EDIT-MIB-CODE-TYPE
               THRU 5331-EDIT-MIB-CODE-TYPE-X.

           PERFORM  5332-EDIT-MIB-CODE
               THRU 5332-EDIT-MIB-CODE-X.

           PERFORM  5333-MIB-CROSS-EDITS
               THRU 5333-MIB-CROSS-EDITS-X.

           IF WS-MIB-UPDATE
               MOVE 'Y'               TO  WS-MIB-AT-LEAST-1-UPDATED-SW
           END-IF.

           IF  WS-MIB-VALID (WS-SCRN)
           AND WS-MIB-UPDATE
           AND WS-MIB-SECURITY-OK
               MOVE MIR-DV-MIB-DTL-TYP-CD-T (WS-SCRN)
                                   TO RUCON-CLI-MIB-DTL-TYP-CD (WS-FILE)
               MOVE MIR-DV-CLI-MIB-DTL-CD-T (WS-SCRN)
                                   TO RUCON-CLI-MIB-DTL-CD (WS-FILE)
           END-IF.

           ADD +1                     TO WS-FILE.

       5330-EDIT-MIB-X.
           EXIT.
      /
      *------------------------
       5331-EDIT-MIB-CODE-TYPE.
      *------------------------

      *****************************************************************
      *   EDIT MIB CODE TYPE - NO FILE UPDATE YET
      *****************************************************************

           IF MIR-DV-MIB-DTL-TYP-CD-T (WS-SCRN) = SPACES
               MOVE RUCON-CLI-MIB-DTL-TYP-CD (WS-FILE)
                                    TO MIR-DV-MIB-DTL-TYP-CD-T (WS-SCRN)
               GO TO 5331-EDIT-MIB-CODE-TYPE-X
           END-IF.

           MOVE 'Y'                   TO WS-MIB-UPDATE-SW.

           IF MIR-DV-MIB-DTL-TYP-CD-T (WS-SCRN) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES          TO MIR-DV-MIB-DTL-TYP-CD-T (WS-SCRN)
           END-IF.

           MOVE MIR-DV-MIB-DTL-TYP-CD-T (WS-SCRN)
                                      TO WS-EDIT-MIB-CODE-TYPE.

           IF WS-VALID-MIB-CODE-TYPE
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE MIR-DV-CLI-MIB-DTL-CD-T (WS-SCRN)
                                      TO WGLOB-MSG-PARM (1)
      *MSG MIB CODE TYPE FOR MIB CODE (@1) IS INVALID
               MOVE 'NS11700012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'T'               TO WS-MIB-VALID-SW (WS-SCRN)
           END-IF.

       5331-EDIT-MIB-CODE-TYPE-X.
           EXIT.
      /
      *-------------------
       5332-EDIT-MIB-CODE.
      *-------------------

      *****************************************************************
      *   EDIT MIB CODE - NO FILE UPDATE YET
      *****************************************************************

           IF MIR-DV-CLI-MIB-DTL-CD-T (WS-SCRN) = SPACES
               MOVE RUCON-CLI-MIB-DTL-CD (WS-FILE)
                                    TO MIR-DV-CLI-MIB-DTL-CD-T (WS-SCRN)
               GO TO 5332-EDIT-MIB-CODE-X
           END-IF.

           MOVE 'Y'                   TO WS-MIB-UPDATE-SW.

           IF MIR-DV-CLI-MIB-DTL-CD-T (WS-SCRN) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES          TO MIR-DV-CLI-MIB-DTL-CD-T (WS-SCRN)
           END-IF.

       5332-EDIT-MIB-CODE-X.
           EXIT.
      /
      *---------------------
       5333-MIB-CROSS-EDITS.
      *---------------------

      *****************************************************************
      *   PERFORM CROSS EDITS BETWEEN MIB CODE AND MIB CODE TYPE
      *****************************************************************

      *
      *  NOTE:  THESE ARE SOMEWHAT IRREGULAR CROSS EDITS IN THAT
      *        THEY WILL PREVENT FILE UPDATE IF THEY FAIL
      *
           IF (MIR-DV-CLI-MIB-DTL-CD-T (WS-SCRN) = SPACES) AND
              (MIR-DV-MIB-DTL-TYP-CD-T (WS-SCRN) NOT = SPACES)
      *MSG MIB CODE TYPE MUST HAVE AN MIB CODE
               MOVE 'NS11700013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'B'               TO WS-MIB-VALID-SW (WS-SCRN)
           ELSE
               IF (MIR-DV-CLI-MIB-DTL-CD-T (WS-SCRN) NOT = SPACES) AND
                  (MIR-DV-MIB-DTL-TYP-CD-T (WS-SCRN) = SPACES)
                   MOVE MIR-DV-CLI-MIB-DTL-CD-T (WS-SCRN)
                                      TO WGLOB-MSG-PARM (1)
      *MSG MIB CODE @1 MUST HAVE A TYPE
                   MOVE 'NS11700014'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'B'           TO WS-MIB-VALID-SW (WS-SCRN)
               END-IF
           END-IF.

       5333-MIB-CROSS-EDITS-X.
           EXIT.
      /
      *--------------------------
       5340-COMPRESS-SCREEN-CODE.
      *--------------------------

      *****************************************************************
      *   COMPRESS THE SCREEN MIB CODES, REMOVING DELETED CODES, AND
      *   HIGHLIGHT ANY TYPES AND CODES THAT ARE IN ERROR
      *****************************************************************

           IF  (WS-MIB-VALID (WS-OLD-POS))
           AND (MIR-DV-MIB-DTL-TYP-CD-T (WS-OLD-POS) = SPACES)
           AND (MIR-DV-CLI-MIB-DTL-CD-T (WS-OLD-POS) = SPACES)
               GO TO 5340-COMPRESS-SCREEN-CODE-X
           END-IF.

           ADD +1                     TO WS-NEW-POS.
           MOVE MIR-DV-MIB-DTL-TYP-CD-T (WS-OLD-POS)
                                TO MIR-DV-MIB-DTL-TYP-CD-T (WS-NEW-POS).
           MOVE MIR-DV-CLI-MIB-DTL-CD-T (WS-OLD-POS)
                                TO MIR-DV-CLI-MIB-DTL-CD-T (WS-NEW-POS).

           IF WS-MIB-CODE-INVALID (WS-OLD-POS)
               GO TO 5340-COMPRESS-SCREEN-CODE-X
           END-IF.

           IF WS-MIB-CODE-TYPE-INVALID (WS-OLD-POS)
               GO TO 5340-COMPRESS-SCREEN-CODE-X
           END-IF.

           IF WS-MIB-BOTH-INVALID (WS-OLD-POS)
               GO TO 5340-COMPRESS-SCREEN-CODE-X
           END-IF.

       5340-COMPRESS-SCREEN-CODE-X.
           EXIT.
      /
      *------------------------
       5350-COMPRESS-FILE-CODE.
      *------------------------

      *****************************************************************
      *   COMPRESS THE FILE MIB CODES, REMOVING DELETED CODES
      *****************************************************************

           IF (RUCON-CLI-MIB-DTL-TYP-CD (WS-OLD-POS) = SPACES) AND
              (RUCON-CLI-MIB-DTL-CD  (WS-OLD-POS) = SPACES)
               GO TO 5350-COMPRESS-FILE-CODE-X
           END-IF.

           MOVE RUCON-CLI-MIB-DTL-TYP-CD (WS-OLD-POS)
                               TO RUCON-CLI-MIB-DTL-TYP-CD (WS-NEW-POS).
           MOVE RUCON-CLI-MIB-DTL-CD  (WS-OLD-POS)
                                  TO RUCON-CLI-MIB-DTL-CD  (WS-NEW-POS).

           ADD +1                     TO WS-NEW-POS.

       5350-COMPRESS-FILE-CODE-X.
           EXIT.
      /
      *---------------------
       5355-BLANK-FILE-CODE.
      *---------------------

      *****************************************************************
      *   BLANK OUT MIB CODE ON THE FILE
      *****************************************************************

           MOVE SPACES         TO RUCON-CLI-MIB-DTL-TYP-CD (WS-NEW-POS).
           MOVE SPACES            TO RUCON-CLI-MIB-DTL-CD  (WS-NEW-POS).

       5355-BLANK-FILE-CODE-X.
           EXIT.
      /
      *------------------
       5360-EDIT-COMMENT.
      *------------------

      *****************************************************************
      *   PROCESS COMMENT INPUT
      *****************************************************************

           IF MIR-CNFD-COMNT-TXT  = SPACES
               GO TO 5360-EDIT-COMMENT-X
           END-IF.

           IF  MIR-CNFD-COMNT-TXT = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CNFD-COMNT-TXT
           END-IF.

           MOVE MIR-CNFD-COMNT-TXT    TO RUCON-CNFD-COMNT-TXT.

       5360-EDIT-COMMENT-X.
           EXIT.
      /
      *----------------------
       5400-SCROLL-MIB-CODES.
      *----------------------

      *****************************************************************
      *   LOAD MIB CODES INTO MIR RECORD
      *****************************************************************
      *  WS-SCRN IS SCREEN POSITION OF MIB CODE
      *  WS-FILE IS FILE POSITION OF CORRESPONDING MIB CODE

           MOVE +1                    TO WS-FILE.
           MOVE +1                    TO WS-LAST-MIB-CODE.

           PERFORM  9220-LOAD-MIB-CODE
               THRU 9220-LOAD-MIB-CODE-X
               VARYING WS-SCRN FROM WS-LAST-MIB-CODE BY 1
               UNTIL WS-SCRN > WS-MAX-MIB-CODES-SCREEN OR
                     WS-FILE > WUCON-MAX-MIB-CODES.

           IF WS-FILE > WUCON-MAX-MIB-CODES
           OR (RUCON-CLI-MIB-DTL-TYP-CD (WS-FILE) = SPACES AND
               RUCON-CLI-MIB-DTL-CD (WS-FILE)   = SPACES)
      *MSG *** END OF MIB CODE LIST ***
               MOVE 'NS11700023'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5400-SCROLL-MIB-CODES-X.
           EXIT.

      *--------------------
       7000-PRINT-DOCUMENT.
      *--------------------

      *****************************************************************
      *   CREATE A PRINT TRANSACTION FOR DOCUMENT
      *****************************************************************

      *
      *  EDIT DOCUMENT NAME
      *
           MOVE MIR-DOC-ID            TO WDOCM-DOC-ID.
023447*    MOVE WGLOB-USER-LANG       TO WDOCM-DOC-LANG-CD.
           PERFORM  DOCM-1000-READ
               THRU DOCM-1000-READ-X.

           IF NOT WDOCM-IO-OK
               MOVE WDOCM-KEY         TO WGLOB-MSG-PARM (1)
      *MSG DOCUMENT MUST EXIST ON DOCM - @1
               MOVE 'NS11700018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-PRINT-DOCUMENT-X
           END-IF.

           PERFORM  0303-1000-BUILD-PARM-INFO
               THRU 0303-1000-BUILD-PARM-INFO-X.

010418     PERFORM  7100-GET-DFLT-SUB-CO
010418         THRU 7100-GET-DFLT-SUB-CO-X.

           SET L0303-TRNXT-TYP-CNFD-WRKSHT
                                      TO TRUE.

           MOVE MIR-DOC-ID            TO L0303-DOC-ID.
           MOVE MIR-UWG-WRKSHT-NUM    TO L0303-POL-ID.
           MOVE MIR-CLI-ID            TO L0303-CLI-ID.
012624*    MOVE 'NB'                  TO L0303-APPL-ID.
           MOVE SPACES                TO L0303-PRTR-ID.
023447*    MOVE ZERO                  TO L0303-TRNXT-DOC-CPY-QTY.
023447*    MOVE WGLOB-USER-LANG       TO L0303-TRNXT-LANG-CD.

           PERFORM  0303-1000-WRITE-PRTX-TRAN
               THRU 0303-1000-WRITE-PRTX-TRAN-X.

           MOVE MIR-DOC-ID            TO WGLOB-MSG-PARM (1).
      *MSG DOCUMENT @1 PRINT REQUEST SUBMITTED
           MOVE 'NS11700019'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           MOVE SPACES                TO MIR-DOC-ID.

       7000-PRINT-DOCUMENT-X.
           EXIT.
      /
      *--------------------------
010418 7100-GET-DFLT-SUB-CO.
      *--------------------------
010418
010418     PERFORM  3320-1000-BUILD-PARM-INFO
010418         THRU 3320-1000-BUILD-PARM-INFO-X.

010418     PERFORM  3320-1000-DEFAULT-SUB-CO
010418         THRU 3320-1000-DEFAULT-SUB-CO-X.

010418     IF  L3320-RETRN-OK
010418     AND L3320-RETRN-SBSDRY-CO-ID NOT = SPACES
010418         MOVE L3320-RETRN-SBSDRY-CO-ID
010418                                TO L0303-SBSDRY-CO-ID
010418         GO TO 7100-GET-DFLT-SUB-CO-X
010418     END-IF.

010418     MOVE LOW-VALUES            TO WSCOM-KEY.
010418     MOVE HIGH-VALUES           TO WSCOM-ENDBR-KEY.
010418
010418     PERFORM  SCOM-1000-BROWSE
010418         THRU SCOM-1000-BROWSE-X.
010418
010418     IF  NOT WSCOM-IO-OK
010418         GO TO 7100-GET-DFLT-SUB-CO-X
010418     END-IF.
010418
010418     PERFORM  SCOM-2000-READ-NEXT
010418         THRU SCOM-2000-READ-NEXT-X.
010418
010418     IF  WSCOM-IO-OK
010418         MOVE RSCOM-SBSDRY-CO-ID
010418                                TO  L0303-SBSDRY-CO-ID
010418     END-IF.
010418
010418     PERFORM  SCOM-3000-END-BROWSE
010418         THRU SCOM-3000-END-BROWSE-X.
010418
010418 7100-GET-DFLT-SUB-CO-X.
010418     EXIT.
      /

      *--------------------
       8000-BUILD-UCON-KEY.
      *--------------------

      *****************************************************************
      *   BUILD UCON READ KEY.
      *****************************************************************

           MOVE MIR-CLI-ID            TO WUCON-CLI-ID.
           MOVE MIR-UWG-WRKSHT-NUM    TO WUCON-UWG-WRKSHT-NUM.

       8000-BUILD-UCON-KEY-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

      *****************************************************************
      *  BLANK DATA FIELDS:  SET EACH DATA (NON-KEY AND NON-CONTROL) *
      *  FIELD ON THE SCREEN TO SPACES.                              *
      *****************************************************************

           MOVE SPACES                TO MIR-DV-OWN-CLI-NM.
           MOVE SPACES                TO MIR-UWG-WRKSHT-DT.
           MOVE SPACES                TO MIR-CNFD-COMNT-TXT.

           PERFORM  9110-BLANK-POLICY
               THRU 9110-BLANK-POLICY-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WUCON-MAX-POLICIES.

           PERFORM  9120-BLANK-MIB-CODE
               THRU 9120-BLANK-MIB-CODE-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > WS-MAX-MIB-CODES-SCREEN.

           PERFORM  9240-BLANK-CURRENT-DETAILS
               THRU 9240-BLANK-CURRENT-DETAILS-X.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *------------------
       9110-BLANK-POLICY.
      *------------------

           MOVE SPACES                TO MIR-POL-ID-BASE-T (WS-SUB).
           MOVE SPACES                TO MIR-POL-ID-SFX-T (WS-SUB).
           MOVE SPACES                TO MIR-POL-CSTAT-CD-T (WS-SUB).

       9110-BLANK-POLICY-X.
           EXIT.
      /
      *--------------------
       9120-BLANK-MIB-CODE.
      *--------------------

           MOVE SPACES              TO MIR-DV-CLI-MIB-DTL-CD-T (WS-SUB).
           MOVE SPACES              TO MIR-DV-MIB-DTL-TYP-CD-T (WS-SUB).

       9120-BLANK-MIB-CODE-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

      *****************************************************************
      *   RECORD TO SCREEN: SHIFT DATA FROM RECORD BUFFER TO SCREEN
      *   INTERFACE RECORD IN PREPARATION FOR DISPLAYING NEW DATA.
      *****************************************************************

557698*    MOVE RCLI-CLI-GIV-NM    TO L0620-CLI-GIV-NM.
557698*    MOVE RCLI-CLI-SUR-NM    TO L0620-CLI-SUR-NM.
           MOVE RCLI-CLI-SEX-CD       TO L0620-CLI-SEX-CD.
557698*    MOVE RCLI-CLI-CO-NM     TO L0620-CLI-CO-NM.
015508*    MOVE RCLI-CLI-ENTR-GIV-NM  TO L0620-CLI-GIV-NM.
015508*    MOVE RCLI-CLI-ENTR-SUR-NM  TO L0620-CLI-SUR-NM.
015508*    MOVE RCLI-CLI-ENTR-CO-NM   TO L0620-CLI-CO-NM.
018732*    MOVE RCLNM-ENTR-GIV-NM     TO L0620-CLI-GIV-NM.
018732*    MOVE RCLNM-ENTR-SUR-NM     TO L0620-CLI-SUR-NM.
018732*    MOVE RCLNM-CLI-INDV-MID-NM TO L0620-CLI-MID-INIT-NM.
018732*    MOVE RCLNM-CLI-INDV-SFX-NM TO L0620-CLI-SFX-NM.
018732*    MOVE RCLNC-CLI-CO-ENTR-NM  TO L0620-CLI-CO-NM.

018732     MOVE L2435-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM.
018732     MOVE L2435-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM.
018732     MOVE L2435-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM.
018732     MOVE L2435-CLI-SFX-NM      TO L0620-CLI-SFX-NM.
018732     MOVE L2435-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM.

           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.

           MOVE L0620-SCREEN-NAME     TO MIR-DV-OWN-CLI-NM.
           MOVE RUCON-UWG-WRKSHT-DT   TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE   TO MIR-UWG-WRKSHT-DT.
           PERFORM  9210-LOAD-POLICY
               THRU 9210-LOAD-POLICY-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL (WS-SUB > WUCON-MAX-POLICIES) OR
                     (RUCON-POL-ID (WS-SUB) = SPACES).

           MOVE RUCON-CNFD-COMNT-TXT  TO MIR-CNFD-COMNT-TXT.

           MOVE +1                    TO WS-FILE.
           PERFORM  9220-LOAD-MIB-CODE
               THRU 9220-LOAD-MIB-CODE-X
               VARYING WS-SCRN FROM 1 BY 1
               UNTIL (WS-SCRN > WS-MAX-MIB-CODES-SCREEN) OR
                     (RUCON-CLI-MIB-DTL-TYP-CD (WS-FILE) = SPACE AND
                      RUCON-CLI-MIB-DTL-CD (WS-FILE)   = SPACE).

017418     IF  WS-FILE > WUCON-MAX-MIB-CODES
017418*MSG *** END OF MIB CODE LIST ***
017418         MOVE 'NS11700023'      TO WGLOB-MSG-REF-INFO
017418         PERFORM  0260-1000-GENERATE-MESSAGE
017418             THRU 0260-1000-GENERATE-MESSAGE-X
017418     ELSE
              IF RUCON-CLI-MIB-DTL-TYP-CD (WS-FILE) = SPACE
              AND RUCON-CLI-MIB-DTL-CD (WS-FILE)   = SPACE
      *MSG *** END OF MIB CODE LIST ***
                  MOVE 'NS11700023'      TO WGLOB-MSG-REF-INFO
                  PERFORM  0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
017418        END-IF
           END-IF.

           IF L1180-WORKSHEET-CURRENT
               PERFORM  9230-LOAD-CURRENT-DETAILS
                   THRU 9230-LOAD-CURRENT-DETAILS-X
           ELSE
               PERFORM  9240-BLANK-CURRENT-DETAILS
                   THRU 9240-BLANK-CURRENT-DETAILS-X
           END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *-----------------
       9210-LOAD-POLICY.
      *-----------------

      *****************************************************************
      *   MOVE POLICY INFORMATION FOR WORKSHEET TO SCREEN
      *****************************************************************

           MOVE RUCON-POL-ID-BASE (WS-SUB)
                                      TO MIR-POL-ID-BASE-T (WS-SUB).
           MOVE RUCON-POL-ID-SFX (WS-SUB)
                                      TO MIR-POL-ID-SFX-T (WS-SUB).
           MOVE RUCON-POL-CSTAT-CD (WS-SUB)
                                      TO MIR-POL-CSTAT-CD-T (WS-SUB).

       9210-LOAD-POLICY-X.
           EXIT.
      /
      *-------------------
       9220-LOAD-MIB-CODE.
      *-------------------

      *****************************************************************
      *   MOVE MIB CODE INFORMATION FROM WORKSHEET TO SCREEN
      *****************************************************************

           MOVE RUCON-CLI-MIB-DTL-TYP-CD (WS-FILE)
                                   TO MIR-DV-MIB-DTL-TYP-CD-T (WS-SCRN).
           MOVE RUCON-CLI-MIB-DTL-CD (WS-FILE)
                                   TO MIR-DV-CLI-MIB-DTL-CD-T (WS-SCRN).

           COMPUTE WS-FILE = WS-FILE + 1.

       9220-LOAD-MIB-CODE-X.
           EXIT.
      /
      *--------------------------
       9230-LOAD-CURRENT-DETAILS.
      *--------------------------

      *****************************************************************
      *   LOAD DETAILS FOR CURRENT WORKSHEET
      *****************************************************************

           MOVE RCLI-CLI-UWGDECN-CD   TO MIR-CLI-UWGDECN-CD.
           MOVE RCLI-CLI-UWGDECN-TYP-CD
                                      TO MIR-CLI-UWGDECN-TYP-CD.
           MOVE RCLI-CLI-UWGDECN-DT   TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE   TO MIR-CLI-UWGDECN-DT.
           MOVE RCLI-UW-USER-ID (1)   TO MIR-UW-USER-1-ID.
           MOVE RCLI-UW-USER-ID (2)   TO MIR-UW-USER-2-ID.
           MOVE RCLI-CLI-CNFD-IND     TO MIR-CLI-CNFD-IND.

           MOVE L1180-CONF-POL-IND    TO MIR-POL-CNFD-IND.
           MOVE L1180-WP-INDICATOR    TO MIR-DV-UWG-WP-IND.
008455*    MOVE L1180-TOTAL-AMT-UW        TO WS-EDIT-9-2.
008455*    MOVE WS-EDIT-9-2               TO MIR-DV-CLI-TOT-UWG-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = L1180-TOTAL-AMT-UW * 100.
020874     MOVE L1180-TOTAL-AMT-UW    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CLI-TOT-UWG-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-CLI-TOT-UWG-AMT.
008455*    MOVE L1180-TOTAL-ALL-ADB       TO WS-EDIT-9-2.
008455*    MOVE WS-EDIT-9-2               TO MIR-DV-CLI-TOT-ADB-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = L1180-TOTAL-ALL-ADB * 100.
020874     MOVE L1180-TOTAL-ALL-ADB   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CLI-TOT-ADB-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-CLI-TOT-ADB-AMT.

           MOVE MIR-CLI-ID            TO WAPPF-CLI-ID.
           PERFORM  APPF-1000-READ
               THRU APPF-1000-READ-X.

           IF WAPPF-IO-OK
               MOVE MIR-CLI-ID        TO L5850-CLI-ID
               MOVE 'L'               TO L5850-CLI-OINS-TYP-CD
               PERFORM  5850-1000-LOAD-CLIO-ARRAY
                   THRU 5850-1000-LOAD-CLIO-ARRAY-X

008455*        COMPUTE WS-EDIT-9-0 = L5850-CLI-OINS-TOT-AMT (1) +
020874*        COMPUTE L0290-INPUT-NUMBER =
020874         COMPUTE L0290-INPUT-V00 =
008455                               L5850-CLI-OINS-TOT-AMT (1) +
                                     L5850-CLI-OINS-TOT-AMT (2) +
                                     L5850-CLI-OINS-TOT-AMT (3) +
                                     L5850-CLI-OINS-TOT-AMT (4) +
                                     L5850-CLI-OINS-TOT-AMT (5) +
                                     L5850-CLI-OINS-TOT-AMT (6)
               MOVE RAPPF-CLI-INS-REFUS-IND
                                      TO MIR-CLI-PREV-DCLN-IND
           ELSE
008455*        MOVE ZERO                  TO WS-EDIT-9-0
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE 0                 TO L0290-INPUT-V00
               MOVE SPACES            TO MIR-CLI-PREV-DCLN-IND
      *MSG NO TOTI INFORMATION FOR THIS CLIENT
               MOVE 'NS11700020'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

008455*    MOVE WS-EDIT-9-0               TO MIR-DV-CLI-TOT-INS-AMT.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CLI-TOT-INS-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-CLI-TOT-INS-AMT.
           MOVE RCLI-CLI-MIB-IND-CD   TO MIR-CLI-MIB-IND-CD.
           MOVE L1180-REINSURANCE-IND TO MIR-POL-REINS-CD.
           MOVE L1180-TIA-INDICATOR   TO MIR-POL-TIA-IND.

557667*    IF (RCLI-CLI-INCM-EARN-AMT > ZERO) OR
557667*       (RCLI-CLI-OTHR-INCM-AMT > ZERO)
557667*        ADD RCLI-CLI-INCM-EARN-AMT
557667*            RCLI-CLI-OTHR-INCM-AMT GIVING WS-EDIT-8-0
557667*        MOVE WS-EDIT-8-0           TO MIR-CLI-EARN-INCM-AMT
557667*    ELSE
557667*        MOVE RCLI-CLI-INCM-EARN-CD TO MIR-CLI-EARN-INCM-AMT
557667*    END-IF.
557667
557667     PERFORM 2432-1000-BUILD-PARM-INFO
557667        THRU 2432-1000-BUILD-PARM-INFO-X.
557667     MOVE RCLI-CLI-ID           TO L2432-CLI-ID.
557667     MOVE WGLOB-SYSTEM-DATE-INT TO L2432-EFF-DT.
557667     PERFORM 2432-1000-GET-INCOME
557667        THRU 2432-1000-GET-INCOME-X.
557667     IF L2432-RETRN-OK
557667         IF L2432-CLI-EARN-INCM-AMT > ZERO
557667         OR L2432-CLI-OTHR-INCM-AMT > ZERO
557667             IF L2432-EARN-INCM-MODE-CD = 'M'
008455*                COMPUTE WS-WRK-8-0 =
020874*                COMPUTE L0290-INPUT-NUMBER =
020874                 COMPUTE L0290-INPUT-V00 =
557667                      L2432-CLI-EARN-INCM-AMT * 12
557667             ELSE
008455*                MOVE L2432-CLI-EARN-INCM-AMT TO WS-WRK-8-0
008455                 MOVE L2432-CLI-EARN-INCM-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
557667             END-IF
557667             IF L2432-OTHR-INCM-MODE-CD = 'M'
008455*                COMPUTE WS-WRK-8-0 =
008455*                    WS-WRK-8-0 + L2432-CLI-OTHR-INCM-AMT * 12
020874*                COMPUTE L0290-INPUT-NUMBER =
020874*                    L0290-INPUT-NUMBER +
020874                 COMPUTE L0290-INPUT-V00 =
020874                     L0290-INPUT-V00    +
008455                     L2432-CLI-OTHR-INCM-AMT * 12
557667             ELSE
008455*                ADD L2432-CLI-OTHR-INCM-AMT TO WS-WRK-8-0
008455                 ADD L2432-CLI-OTHR-INCM-AMT
020874*                               TO L0290-INPUT-NUMBER
020874                                TO L0290-INPUT-V00
557667             END-IF
008455*            MOVE WS-WRK-8-0              TO WS-EDIT-8-0
008455*            MOVE WS-EDIT-8-0             TO MIR-CLI-EARN-INCM-AMT
008455             MOVE 0             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CLI-EARN-INCM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM  0290-1000-NUMERIC-FORMAT
020874*                THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-CLI-EARN-INCM-AMT
557667         ELSE
557667             MOVE L2432-EARN-INCM-MODE-CD
                                      TO MIR-CLI-EARN-INCM-AMT
557667         END-IF
557667     ELSE
557667         INITIALIZE MIR-CLI-EARN-INCM-AMT
557667     END-IF.

       9230-LOAD-CURRENT-DETAILS-X.
           EXIT.
      /
      *---------------------------
       9240-BLANK-CURRENT-DETAILS.
      *---------------------------

      *****************************************************************
      *   BLANK CURRENT DETAILS FOR A NON CURRENT WORKSHEET
      *****************************************************************

           MOVE SPACES                TO MIR-CLI-UWGDECN-CD.
           MOVE SPACES                TO MIR-CLI-UWGDECN-TYP-CD.
           MOVE SPACES                TO MIR-CLI-UWGDECN-DT.
           MOVE SPACES                TO MIR-UW-USER-1-ID.
           MOVE SPACES                TO MIR-UW-USER-2-ID.
           MOVE SPACES                TO MIR-CLI-CNFD-IND.
           MOVE SPACES                TO MIR-POL-CNFD-IND.
           MOVE SPACES                TO MIR-DV-UWG-WP-IND.
           MOVE SPACES                TO MIR-DV-CLI-TOT-UWG-AMT.
           MOVE SPACES                TO MIR-DV-CLI-TOT-ADB-AMT.
           MOVE SPACES                TO MIR-DV-CLI-TOT-INS-AMT.
           MOVE SPACES                TO MIR-CLI-MIB-IND-CD.
           MOVE SPACES                TO MIR-POL-REINS-CD.
           MOVE SPACES                TO MIR-CLI-PREV-DCLN-IND.
           MOVE SPACES                TO MIR-POL-TIA-IND.
           MOVE SPACES                TO MIR-CLI-PREV-DCLN-IND.
           MOVE SPACES                TO MIR-CLI-EARN-INCM-AMT.

       9240-BLANK-CURRENT-DETAILS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

      *****************************************************************
      *   SET REFERENCE: MOVE DATA WHICH IDENTIFIES THE OBJECT THAT
      *   IS BEING WORKED ON TO THE GLOBAL AREA FOR MSIN AND MSAU
      *   PROCESSING.
      *****************************************************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'C'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-CLI-ID            TO WGLOB-REF-CLIENT-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023118/
023118*--------------------------
023118 9990-INIT-WORKING-STORAGE.
023118*--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023118
025970*    PERFORM  0290-1000-BUILD-PARM-INFO
025970*        THRU 0290-1000-BUILD-PARM-INFO-X.
025970*
025970*    PERFORM  9300-SETUP-MSIN-REFERENCE
025970*        THRU 9300-SETUP-MSIN-REFERENCE-X.
025970*
025970*    PERFORM  PGA-1000-BUILD-PARMS
025970*        THRU PGA-1000-BUILD-PARMS-X.
023118
025970     PERFORM  0063-0000-INIT-PARM-INFO
025970         THRU 0063-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0303-0000-INIT-PARM-INFO
025970         THRU 0303-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1180-0000-INIT-PARM-INFO
025970         THRU 1180-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2432-0000-INIT-PARM-INFO
025970         THRU 2432-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  3320-0000-INIT-PARM-INFO
025970         THRU 3320-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5600-0000-INIT-PARM-INFO
025970         THRU 5600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5850-0000-INIT-PARM-INFO
025970         THRU 5850-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WS-MISC.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-TRANS-NAME          TO TRUE.
025970     SET WS-DEFAULT-MAX-MIB-CODES       TO TRUE.
025970     SET WS-DEFAULT-MAX-WORKSHEET       TO TRUE.
023118     SET WS-EDITS-OK                    TO TRUE.
025970
023118     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970     MOVE SPACES                        TO WWKDT-WORK-FIELDS.
025970*    SET MIR-RETRN-OK           TO TRUE.
023118
023118 9990-INIT-WORKING-STORAGE-X.
023118     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
      /
025970 COPY CCPS2435.
025970 COPY XCPS8090.
       COPY CCPSPGA.
      /
       COPY XCPPEXIT.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CLI
014221                         '$VAR2' BY 'CLI'.
      /
      ****************************************************************
      * LINKAGE  COPYBOOKS                                           *
      ****************************************************************
025970 COPY XCPS0280.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY XCPL0280.

008455 COPY XCPL0290.
008455 COPY XCPS0290.
008455/
021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
025970 COPY CCPS0620.
       COPY CCPL0620.
      /
018764*COPY CCCL2432.
018764 COPY CCPL2432.
557667 COPY CCPS2432.
      /
018764*COPY CCCL2435.
018764 COPY CCPL2435.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
018764*COPY CCCL3320.
018764 COPY CCPL3320.
010418 COPY CCPS3320.
      /
018764*COPY CCCL5600.
018764 COPY CCPL5600.
       COPY CCPS5600.
      /
018764*COPY NCCL5850.
025970 COPY NCPS5850.
018764 COPY NCPL5850.
      /
018764*COPY NCCL0303.
018764 COPY NCPL0303.
       COPY NCPS0303.
      /
018764*COPY CCCL0063.
025970 COPY CCPS0063.
018764 COPY CCPL0063.
      /
018764*COPY NCCL1180.
018764 COPY NCPL1180.
       COPY NCPS1180.
      /
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS                                 *
      ****************************************************************
012624*COPY XCPPMEXT.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY NCPCUCON.
      /
       COPY NCPAUCON.
      /
       COPY NCPNUCON.
      /
       COPY NCPUUCON.
      /
       COPY NCPNAPPF.
      /
023447*COPY NCPNDOCM.
023447 COPY XCPNDOCM.
      /
      *****************************************************************
      *  ADMIN COPYBOOKS
      *****************************************************************
010418 COPY CCPBSCOM.
       COPY CCPNCLI.
       COPY CCPUCLI.
016537*COPY CCPNCLIA.
      /
021930*COPY CCPNCLNC.
021930*COPY CCPNCLNM.
021930*
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM1170                     **
      *****************************************************************

