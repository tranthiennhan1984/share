      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM7733.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM7733                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE RECORD DELETE FUNCTION  **
      **            FOR THE UTRA TABLE                               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
021239**  6.4       FUND UNIT VALUE                                  **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM7733'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************

      /
      ****************************************************************
      *  WORKING AREA                                                *
      ****************************************************************

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-DELETE         VALUE '7733'.
           05  WS-ASIGN-EFF-DT               PIC X(10).
           05  WS-DEFN-RULE-ID               PIC 9(04).

       01  WS-CONSTANT-AREA.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970*                                      VALUE '7730'.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '7730'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY SCFWUTRA.
       COPY SCFRUTRA.
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.

       COPY XCWL0280.

       COPY XCWL1640.

       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM7733.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  2000-DELETE
                        THRU 2000-DELETE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE WPGWS-CRNT-PGM-ID
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-----------
       2000-DELETE.
      *-----------

           PERFORM  2100-VALIDATE-DATA
               THRU 2100-VALIDATE-DATA-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-DELETE-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  UTRA-2000-UPDATE-TWRK-TS
               THRU UTRA-2000-UPDATE-TWRK-TS-X.

           IF  WUTRA-IO-NOT-FOUND
      *MSG: 'LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS'
               MOVE WUTRA-KEY
                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-DELETE-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG: 'PROCESS FAILED - RE-ENTER DATA AS ANOTHER PROCESS HAS
      *      DELETED - TABLE (@1), KEY @2'
               MOVE 'XS00000303'
                 TO WGLOB-MSG-REF-INFO
               MOVE 'UTRA'
                 TO WGLOB-MSG-PARM (1)
               MOVE WUTRA-KEY
                 TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-DELETE-X
           END-IF.

           PERFORM  UTRA-1000-DELETE
               THRU UTRA-1000-DELETE-X.

           PERFORM  9350-SETUP-AUDIT-INFO
               THRU 9350-SETUP-AUDIT-INFO-X.

       2000-DELETE-X.
           EXIT.
      /
      *----------------------------
       2100-VALIDATE-DATA.
      *----------------------------

           PERFORM  2110-EDIT-UTR-DEFN-RULE-ID
               THRU 2110-EDIT-UTR-DEFN-RULE-ID-X.

           PERFORM  2120-EDIT-UTR-ASIGN-EFF-DT
               THRU 2120-EDIT-UTR-ASIGN-EFF-DT-X.

       2100-VALIDATE-DATA-X.
           EXIT.

      *----------------------------
       2110-EDIT-UTR-DEFN-RULE-ID.
      *----------------------------

           SET L0280-SIGN-NOT-PERMITTED  TO TRUE.
           MOVE ZERO                   TO L0280-PRECISION.
           MOVE LENGTH OF MIR-UTR-DEFN-RULE-ID
             TO L0280-LENGTH.
           MOVE LENGTH OF MIR-UTR-DEFN-RULE-ID
             TO L0280-INPUT-SIZE.
           MOVE MIR-UTR-DEFN-RULE-ID   TO L0280-INPUT-DATA.

           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00   TO WS-DEFN-RULE-ID
           ELSE
      *MSG: INVALID DEFINITION RULE ID
               MOVE 'SS77330001'       TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2110-EDIT-UTR-DEFN-RULE-ID-X.
           EXIT.

      *----------------------------
       2120-EDIT-UTR-ASIGN-EFF-DT.
      *----------------------------

           MOVE MIR-UTR-ASIGN-EFF-DT   TO L1640-EXTERNAL-DATE

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      *MSG: INVALID ASSIGNMENT EFFECTIVE DATE
               MOVE 'SS77330002'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L1640-INTERNAL-DATE
                                       TO WS-ASIGN-EFF-DT
           END-IF.

       2120-EDIT-UTR-ASIGN-EFF-DT-X.
           EXIT.

      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE WS-DEFN-RULE-ID         TO WUTRA-UTR-DEFN-RULE-ID.
           MOVE WS-ASIGN-EFF-DT         TO WUTRA-UTR-ASIGN-EFF-DT.

       7000-BUILD-KEYS-X.
           EXIT.


      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      /
      *----------------------
       9350-SETUP-AUDIT-INFO.
      *----------------------

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM  UTRA-1000-CALL-AUDIT
                   THRU UTRA-1000-CALL-AUDIT-X
           END-IF.

       9350-SETUP-AUDIT-INFO-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

025970     SET WS-TWRK-KEY-DEFAULT     TO TRUE.
025970
       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  UTRA
                                '$VAR2'   BY 'UTRA'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.

025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.

025970 COPY XCPS1640.
       COPY XCPL1640.

       COPY XCPL8090.
      /
       COPY SCPLUTRA.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY SCPNUTRA.
       COPY SCPUUTRA.
       COPY SCPXUTRA.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                      END OF PROGRAM SSOM7733                **
      *****************************************************************
