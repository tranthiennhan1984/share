      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM5042.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM5042                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE RECORD UPDATE FUNCTION  **
      **            FOR THE CRTX TABLE                               **
      **                                                             **
      **  DOMAIN :  BC                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014221**  6.2       LOGICAL LOCKING                                  **
016395**  6.2       CREDIT CARD BILLING HISTORY UPDATE               **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018770**  6.3       PCR - ALLOWABLE VALUE EDIT                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM5042'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT                 VALUE '5040'.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-UPDATE         VALUE '5042'.
025970*    05  WS-TWRK-KEY                   PIC X(04) VALUE '5040'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
       COPY XCWEBLCH.
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWCRTX.
       COPY CCFRCRTX.
      /
014221 COPY CCFWCRCD.
       COPY CCFRCRCD.
      /
018770*COPY XCFWDMAD.
018770*COPY XCFRDMAD.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
021930*COPY CCWL0620.
       COPY XCWLDTLK.
       COPY XCWL0290.
       COPY XCWL1640.
014221 COPY XCWL8090.
018770 COPY XCWL8960.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM5042.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM5042'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-UPDATE.
      *------------
      *
      *  THE RECORD MUST EXIST ON A MAINTAIN
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

014221     PERFORM  CRCD-2000-UPDATE-TWRK-TS
014221         THRU CRCD-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221        MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
014221        MOVE 'CRCD'                TO WGLOB-MSG-PARM (01)
014221        MOVE WCRCD-KEY             TO WGLOB-MSG-PARM (02)
014221        PERFORM  0260-1000-GENERATE-MESSAGE
014221            THRU 0260-1000-GENERATE-MESSAGE-X
014221        GO TO 2000-UPDATE-X
014221     END-IF.

014221     IF  WCRCD-IO-NOT-FOUND
014221*MSG: RECORD @1 NOT FOUND
014221         MOVE WCRCD-KEY
014221           TO WGLOB-MSG-PARM (1)
014221         MOVE 'XS00000001'
014221           TO WGLOB-MSG-REF-INFO
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         SET MIR-RETRN-RQST-FAILED
014221           TO TRUE
014221         GO TO 2000-UPDATE-X
014221     END-IF.

           PERFORM  CRTX-1000-READ-FOR-UPDATE
               THRU CRTX-1000-READ-FOR-UPDATE-X.

           IF  WCRTX-IO-NOT-FOUND
      *MSG: 'LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS'
               MOVE WCRTX-KEY
                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

           IF  NOT RCRTX-CRC-TRXN-STAT-REVRS
      * MSG: CRTX STATUS CODE MUST BE REVERSED IN ORDER TO UPDATE
               MOVE 'CS50420001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 1             TO WGLOB-RETURN-CODE
                   PERFORM  9200-MOVE-RECORD-TO-MIR
                       THRU 9200-MOVE-RECORD-TO-MIR-X
014221             PERFORM  CRCD-3000-UNLOCK
014221                 THRU CRCD-3000-UNLOCK-X
                   GO TO 2000-UPDATE-X
               END-IF
           END-IF.

           PERFORM  8000-EDITS
               THRU 8000-EDITS-X.

           IF  WGLOB-MSG-ERROR-SW = ZERO
               PERFORM  9200-MOVE-RECORD-TO-MIR
                   THRU 9200-MOVE-RECORD-TO-MIR-X
           ELSE
               SET MIR-RETRN-EDIT-ERROR
                 TO TRUE
           END-IF.

           PERFORM  CRTX-2000-REWRITE
               THRU CRTX-2000-REWRITE-X.

014221     PERFORM  CRCD-2000-REWRITE
014221         THRU CRCD-2000-REWRITE-X.
014221     PERFORM  CRCD-1000-READ-TWRK-TS
014221         THRU CRCD-1000-READ-TWRK-TS-X.

       2000-UPDATE-X.
           EXIT.

      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WCRTX-KEY.
           MOVE MIR-CRC-TYP-CD         TO WCRTX-CRC-TYP-CD.
           MOVE MIR-CRC-ID             TO WCRTX-CRC-ID.

           MOVE MIR-CRC-TRXN-DT        TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               MOVE WWKDT-ZERO-DT      TO WCRTX-CRC-TRXN-DT
           ELSE
               MOVE L1640-INTERNAL-DATE
                                       TO WCRTX-CRC-TRXN-DT
           END-IF.

           MOVE MIR-CRC-TRXN-SEQ-NUM   TO WCRTX-CRC-TRXN-SEQ-NUM.

014221     MOVE MIR-CRC-TYP-CD         TO WCRCD-CRC-TYP-CD.
014221     MOVE MIR-CRC-ID             TO WCRCD-CRC-ID.

       7000-BUILD-KEYS-X.
           EXIT.

      /
      *-----------
       8000-EDITS.
      *-----------

           PERFORM  8020-EDIT-CRC-TRXN-REVRS-CD
               THRU 8020-EDIT-CRC-TRXN-REVRS-CD-X.

       8000-EDITS-X.
           EXIT.

      /
      *----------------------------
       8020-EDIT-CRC-TRXN-REVRS-CD.
      *----------------------------

           IF  MIR-CRC-TRXN-REVRS-CD = SPACES
               MOVE RCRTX-CRC-TRXN-REVRS-CD
                                      TO MIR-CRC-TRXN-REVRS-CD
               GO TO 8020-EDIT-CRC-TRXN-REVRS-CD-X
           END-IF.

           IF MIR-CRC-TRXN-REVRS-CD = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CRC-TRXN-REVRS-CD
           END-IF.

018770*    MOVE 'CRC-TRXN-REVRS-CD'   TO WDMAD-DM-AV-TBL-CD.
018770*    MOVE MIR-CRC-TRXN-REVRS-CD
018770*                               TO WDMAD-DM-AV-CD.
018770*    MOVE WGLOB-USER-LANG       TO WDMAD-DM-AV-DESC-LANG-CD.
018770*
018770*    PERFORM  DMAD-1000-READ
018770*        THRU DMAD-1000-READ-X.
018770*
018770*    IF  WDMAD-IO-OK
018770     PERFORM  8960-1000-BUILD-PARM-INFO
018770         THRU 8960-1000-BUILD-PARM-INFO-X.
018770     MOVE 'CRC-TRXN-REVRS-CD'   TO L8960-AV-TBL-CD.
018770     MOVE MIR-CRC-TRXN-REVRS-CD TO L8960-AV-CD.
018770
018770     PERFORM  8960-1000-VALIDATE-CODE
018770         THRU 8960-1000-VALIDATE-CODE-X.
018770
018770     IF  L8960-RETRN-OK
               MOVE MIR-CRC-TRXN-REVRS-CD
                                      TO RCRTX-CRC-TRXN-REVRS-CD
           ELSE
      * MSG:   INVALID REVERSE REASON CODE - REENTER
               MOVE 'CS50420002'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-SEVRTY-FATAL
                   MOVE 1             TO WGLOB-RETURN-CODE
               END-IF
           END-IF.

       8020-EDIT-CRC-TRXN-REVRS-CD-X.
           EXIT.

      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES
             TO MIR-CRC-TRXN-STAT-CD.
           MOVE SPACES
             TO MIR-CRC-TRXN-REVRS-CD.
           MOVE SPACES
             TO MIR-SBSDRY-CO-ID.
           MOVE SPACES
             TO MIR-CRC-TRXN-AMT.
           MOVE SPACES
             TO MIR-CRC-TRXN-CRCY-CD.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *------------------------
       9200-MOVE-RECORD-TO-MIR.
      *------------------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           MOVE RCRTX-CRC-TRXN-STAT-CD
             TO MIR-CRC-TRXN-STAT-CD.

           MOVE RCRTX-CRC-TRXN-REVRS-CD
             TO MIR-CRC-TRXN-REVRS-CD.

           MOVE RCRTX-SBSDRY-CO-ID
             TO MIR-SBSDRY-CO-ID.

020874*    COMPUTE L0290-INPUT-NUMBER = RCRTX-CRC-TRXN-AMT * 100.
020874     MOVE RCRTX-CRC-TRXN-AMT    TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CRC-TRXN-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM  0290-2000-FORMAT-FOR-MIR
020874         THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CRC-TRXN-AMT.
           MOVE RCRTX-CRC-TRXN-CRCY-CD
             TO MIR-CRC-TRXN-CRCY-CD.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     MOVE SPACES                     TO WWKDT-WORK-FIELDS.
025970     SET WS-TWRK-KEY-DEFAULT         TO TRUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CRCD
014221                         '$VAR2' BY 'CRCD'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
021930*COPY CCPL0620.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
025970 COPY XCPS8090.
       COPY XCPS0290.
       COPY XCPL0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
018770 COPY XCPS8960.
018770 COPY XCPL8960.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPUCRTX.
018770*COPY XCPNDMAD.
      /
014221 COPY CCPNCRCD.
014221 COPY CCPUCRCD.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM5042                     **
      *****************************************************************
