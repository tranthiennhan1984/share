      *-----------------------
       IDENTIFICATION DIVISION.
      *-----------------------

       PROGRAM-ID. SSOM1730.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM1730                                         **
      **  REMARKS:  FINQ - SEG FUND SYSTEM - FUND INQUIRY SCREEN.    **
      **                                                             **
      **  DOMAIN :  CV                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016679**  6.2       DESCRIPTION                                      **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020469**  6.4       MULTI-CURRENCY FUND PROCESSING                   **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023257**  6.4       WORKING STORAGE INITIALIZATION                   **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      *--------------------
       ENVIRONMENT DIVISION.
      *--------------------

      *-------------
       DATA DIVISION.
      *-------------

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM1730'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                        PIC X(04).
               88  WS-BUS-FCN-CONTR                  VALUE '1730'.
           05  WS-SUB                               PIC S9(04) BINARY.
025970*    05  WS-MAX-LIST-LINES                    PIC S9(04) BINARY
025970*                                             VALUE 20.
       01  GENERAL-WORK-AREA.
           03  WS-ACB-TOT                        PIC S9(15)V99  COMP-3.
           03  WS-SIGN6-G.
               05  WS-SIGN6-T                    OCCURS  139
                                                 PIC X(01).
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
021930*COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY SCFWFC.
       COPY SCFRFC.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
      /
       COPY SCFWFS.
       COPY SCFRFS.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************

028298 COPY CCWL2626.
       COPY XCWLDTLK.
021930*COPY XCWL0280.
023257 COPY XCWL0280.
       COPY XCWL1640.
018764*COPY XCWLPTR.
      /
       COPY XCWL0290.
      /
       COPY CCWL5400.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM1730.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.
      *
      *  VALIDATE / CHECK POLICY ACCESS
      *
           PERFORM  2100-VALIDATE-POLICY
               THRU 2100-VALIDATE-POLICY-X.

           IF  WGLOB-RETURN-ERROR
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 1000-PROCESS-REQUEST-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 1000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2500-NOW-GET-FUND
               THRU 2500-NOW-GET-FUND-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
               GO TO 1000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

020469     MOVE RPOL-POL-CRCY-CD          TO MIR-CIA-CRCY-CD.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CONTR
                    PERFORM  4000-PROCESS-LIST
                        THRU 4000-PROCESS-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'SSOM1730'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      *---------------------
       2100-VALIDATE-POLICY.
      *---------------------

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
      *MSG: POLICY NOT IN FILE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 2100-VALIDATE-POLICY-X
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
           SET  L5400-STAT-MSG-NOT-REQD TO TRUE.
           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-CNFD-ACCS-RESTRICTED
           OR  NOT L5400-RETRN-OK
               SET WGLOB-RETURN-ERROR   TO TRUE
           END-IF.

       2100-VALIDATE-POLICY-X.
           EXIT.
      /
      *------------------
       2500-NOW-GET-FUND.
      *------------------

           MOVE WPOL-POL-ID           TO WFC-POL-ID.
023257*    MOVE MIR-CVG-NUM           TO WFC-CVG-NUM-N.
023257*
023257     SET L0280-SIGN-NOT-PERMITTED   TO TRUE.
023257     SET L0280-SPACES-PERMITTED     TO TRUE.
023257     MOVE ZERO                      TO L0280-PRECISION.
023257     MOVE LENGTH OF MIR-CVG-NUM     TO L0280-LENGTH.
023257     MOVE LENGTH OF MIR-CVG-NUM     TO L0280-INPUT-SIZE.
023257     MOVE MIR-CVG-NUM               TO L0280-INPUT-DATA.
023257
023257     PERFORM  0280-1000-NUMERIC-EDIT
023257         THRU 0280-1000-NUMERIC-EDIT-X.
023257
023257     IF  L0280-OK
023257         MOVE L0280-OUTPUT-V00      TO WFC-CVG-NUM-N
023257     ELSE
023257         MOVE ZERO                  TO WFC-CVG-NUM-N
023257     END-IF.
023257
           PERFORM  FC-1000-READ
               THRU FC-1000-READ-X.

           IF NOT WFC-IO-OK
               MOVE 'SS17300001'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2500-NOW-GET-FUND-X.
           EXIT.
      *--------------------
       4000-PROCESS-LIST .
      *--------------------

      ***** FUND CONTRACT *****

           MOVE SPACES                TO WFS-KEY.
           MOVE RFC-KEY               TO WFS-KEY.
           MOVE 0                     TO WS-ACB-TOT.
           MOVE WFS-KEY               TO WFS-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WFS-ENDBR-FND-ID.
           PERFORM  FS-1000-BROWSE
               THRU FS-1000-BROWSE-X.
           IF NOT WFS-IO-EOF
               PERFORM  FS-2000-READ-NEXT
                   THRU FS-2000-READ-NEXT-X
               PERFORM  4100-READ-NEXT-FS
                   THRU 4100-READ-NEXT-FS-X
                   UNTIL NOT WFS-IO-OK
               PERFORM  FS-3000-END-BROWSE
                   THRU FS-3000-END-BROWSE-X
           ELSE
               PERFORM  FS-3000-END-BROWSE
                   THRU FS-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 4000-PROCESS-LIST-X
           END-IF.

           MOVE RFC-INV-CVG-STAT-CD   TO MIR-CFN-STAT-CD.
           MOVE RFC-LATST-CIA-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-LATST-CIA-DT.
           MOVE RFC-FRST-PRCES-CIA-DT TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-FRST-PRCES-CIA-DT.
           MOVE RFC-EARLST-CIA-DT     TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-EARLST-CIA-DT.
           MOVE RFC-LATST-DPOS-CIA-DT TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-LATST-DPOS-CIA-DT.
           MOVE RFC-LATST-PSUR-CIA-DT TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-LATST-PSUR-CIA-DT.

           MOVE RFC-PREV-T3-PRCES-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
020462     MOVE L1640-EXTERNAL-DATE   TO MIR-PREV-T3-PRCES-DT.

           MOVE RFC-RPT-PEND-CIA-DT   TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-RPT-PEND-CIA-DT.
           MOVE RFC-VALU-PEND-CIA-DT  TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-VALU-PEND-CIA-DT.

020874*    COMPUTE L0290-INPUT-NUMBER = RFC-CVG-T5-INT-AMT * 100.
020874     MOVE RFC-CVG-T5-INT-AMT    TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-T5-INT-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CVG-T5-INT-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = WS-ACB-TOT * 100.
020874     MOVE WS-ACB-TOT            TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-CDN-TAX-ACB-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-DV-CDN-TAX-ACB-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RFC-CVG-ELIG-INT-AMT * 100.
020874     MOVE RFC-CVG-ELIG-INT-AMT  TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-ELIG-INT-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CVG-ELIG-INT-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RFC-CVG-INELG-INT-AMT * 100.
020874     MOVE RFC-CVG-INELG-INT-AMT TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-INELG-INT-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CVG-INELG-INT-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RFC-CVG-ELIG-DIV-AMT * 100.
020874     MOVE RFC-CVG-ELIG-DIV-AMT  TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-ELIG-DIV-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CVG-ELIG-DIV-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RFC-CVG-INELG-DIV-AMT * 100.
020874     MOVE RFC-CVG-INELG-DIV-AMT TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-INELG-DIV-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CVG-INELG-DIV-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RFC-CVG-OTHR-INCM-AMT * 100.
020874     MOVE RFC-CVG-OTHR-INCM-AMT TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-OTHR-INCM-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CVG-OTHR-INCM-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RFC-CVG-CDN-GAIN-AMT * 100.
020874     MOVE RFC-CVG-CDN-GAIN-AMT  TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-CDN-GAIN-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CVG-CDN-GAIN-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = RFC-CVG-FRGN-GAIN-AMT * 100.
020874     MOVE RFC-CVG-FRGN-GAIN-AMT TO L0290-INPUT-V02.
           MOVE 2                     TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CVG-FRGN-GAIN-AMT
                                      TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CVG-FRGN-GAIN-AMT.

       4000-PROCESS-LIST-X.
           EXIT.
      /
      *------------------
       4100-READ-NEXT-FS.
      *------------------

           COMPUTE WS-ACB-TOT ROUNDED = WS-ACB-TOT + RFS-CFN-ACB-AMT.

           PERFORM  FS-2000-READ-NEXT
               THRU FS-2000-READ-NEXT-X.

       4100-READ-NEXT-FS-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES            TO WFC-KEY.
           MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.

       7000-BUILD-KEYS-X.
           EXIT.

      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

            MOVE SPACES          TO  WS-SIGN6-G.
            MOVE SPACES          TO  MIR-LATST-CIA-DT.
            MOVE SPACES          TO  MIR-FRST-PRCES-CIA-DT.
            MOVE SPACES          TO  MIR-EARLST-CIA-DT.
            MOVE SPACES          TO  MIR-LATST-DPOS-CIA-DT.
            MOVE SPACES          TO  MIR-LATST-PSUR-CIA-DT.
            MOVE SPACES          TO  MIR-PREV-T3-PRCES-DT.
            MOVE SPACES          TO  MIR-RPT-PEND-CIA-DT.
            MOVE SPACES          TO  MIR-VALU-PEND-CIA-DT.
            MOVE SPACES          TO  MIR-CVG-T5-INT-AMT.
            MOVE SPACES          TO  MIR-DV-CDN-TAX-ACB-AMT.
            MOVE SPACES          TO  MIR-CVG-OTHR-INCM-AMT.
            MOVE SPACES          TO  MIR-CVG-CDN-GAIN-AMT.
            MOVE SPACES          TO  MIR-CVG-FRGN-GAIN-AMT.
            MOVE SPACES          TO  MIR-CVG-ELIG-INT-AMT.
            MOVE SPACES          TO  MIR-CVG-INELG-INT-AMT.
            MOVE SPACES          TO  MIR-CVG-ELIG-DIV-AMT.
            MOVE SPACES          TO  MIR-CVG-INELG-DIV-AMT.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                 TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE GENERAL-WORK-AREA.
025970
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************

028298 COPY CCPS2626.
028298 COPY CCPL2626.
      * COPY CCPL0620.
      * COPY CCCL2440.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
021930*COPY XCPL0280.
025970 COPY XCPS0280.
023257 COPY XCPL0280.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
       COPY XCPL0290.
       COPY XCPS0290.
      /
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************

      *COPY CCPNEDIT.
      *COPY XCPNCRCY.
      *COPY XCPNXTAB.
      /
       COPY CCPNPOL.
      /
       COPY SCPNFC.
      /
       COPY SCPBFS.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM SSOM1730
      *****************************************************************
