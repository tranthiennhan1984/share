      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM0160.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM0160                                         **
      **  REMARKS:  DOCM - MAINTAIN POLICY DOCUMENT PRINTING PARMS.  **
      **            THIS MODULE IS CALLED TO MAINTAIN DEFAULT        **
      **            PRINTING PARAMETERS FOR POLICY DOCUMENTS. EACH   **
      **            DOCUMENT TO BE PRINTED MUST BE ASSIGNED PRINTING **
      **            PARAMETERS.  YOU CAN OVERRIDE SELECTED PARAMETERS**
      **            WHEN YOU MANUALLY ISSUE A REQUEST TO A DOCUMENT  **
      **            FROM THE PRINT REQUEST (PRRQ) SCREEN.            **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
554712**  5.5       DESCRIPTION BEING REMOVED FROM DOCM.  THIS       **
554712**            FIELD IS NOW DISPLAY ONLY AND THE                **
554712**            DESCRIPTION WILL COME FROM EDIT/DCOM USING       **
554712**            THE DOCUMENT ID AND DOCUMENT LANGAUGE            **
557659**  5.5       DATA ARCHITECTURE MODIFICATIONS                  **
557708**  5.5       HANDLING OF CICS ABENDS                          **
007685**  5.6       NAIC MODULATION REGULATIONS                      **
007685**            NEW NAME AND VALUES FOR PRINT SWITCH             **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010311**  5.6       CORRECTED ATTRIBUTE SETTING ON KEY ERRORS        **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       MESSAGE SUPPORT - REMOVAL OF XCPPMEXT            **
015543**  6.0       CODE CLEANUP                                     **
014221**  6.2       LOGICAL LOCKING                                  **
016440**  6.2       NB/AD CONSOLIDATIONS                             **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
023118**  6.5       CODE CLEAN-UP AND STANDARDIZATION                **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025244**  6.6       ADD INFORMATIONAL MESSAGE                        **
026766**  6.6       PERFORMANCE MONITORING                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0160'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
025970*    05  WS-TRANS-NAME               PIC X(04)  VALUE 'DOCM'.
           05  WS-BUS-FCN-ID               PIC X(04).
               88  WS-BUS-FCN-VALID        VALUE '1240' '1241'
                                                 '1242' '1243'
                                                 '1244'.
               88  WS-BUS-FCN-RETRIEVE     VALUE '1240'.
               88  WS-BUS-FCN-CREATE       VALUE '1241'.
               88  WS-BUS-FCN-UPDATE       VALUE '1242'.
               88  WS-BUS-FCN-DELETE       VALUE '1243'.
               88  WS-BUS-FCN-LIST         VALUE '1244'.
025970*    05  WS-TWRK-KEY                 PIC X(04)  VALUE '1240'.
023447*    05  WS-DATA-EDITS               PIC X(01).
023447     05  WS-DATA-EDITS-OK-IND        PIC X(01).
023447         88  WS-DATA-EDITS-OK-NO                VALUE 'N'.
               88  WS-DATA-EDITS-OK                   VALUE 'Y'.
           05  WS-VALIDATE-CONTROL         PIC X(01).
               88  WS-INVALID-CONTROL                 VALUE '1'.
           05  WS-COPIES                   PIC 99.
               88  WS-COPIES-VALID                    VALUE 1 THRU 99.
           05  WS-VALID-SW                 PIC X(01).
007685         88  WS-NPRSW-VALID                     VALUE 'I' 'E'.
007685         88  WS-NPRSW-EX-VALID                  VALUE 'E'.
007685*        88  WS-NPRSW-VALID                     VALUE 'N' 'Y'.
007685         88  WS-ONBSW-VALID                     VALUE 'B'.

      *   CURRENTLY, THE ONLY VALID VALUE FOR ONBSW IS "B".  IN THE
      *   FUTURE AN ONLINE FACILITY WILL BE ADDED AND "O" WILL BE VALID

           05  WS-ROUTES-VALID-SW          PIC X(01).
               88  WS-ROUTES-VALID                    VALUE 'Y'.
               88  WS-ROUTES-INVALID                  VALUE 'N'.
           05  WS-DOC-ARRAY.
               10  WS-DOC-NAME             PIC X(01)  OCCURS 5 TIMES.
           05  WS-ROUTE-HOLD               PIC X(08)  OCCURS 4 TIMES.
016548*    05  WS-SUB                      PIC S9(04) COMP.
016548     05  WS-SUB                      PIC S9(04) BINARY.
016548*    05  WS-SUB2                     PIC S9(04) COMP.
016548     05  WS-SUB2                     PIC S9(04) BINARY.
016548*    05  WS-MAX-LIST-LINES           PIC S9(04) COMP VALUE +100.
025970*    05  WS-MAX-LIST-LINES           PIC S9(04) BINARY VALUE +100.
016548*    05  WS-INDX1                    PIC S9(4) COMP.
016548     05  WS-INDX1                    PIC S9(4) BINARY.
016548*    05  WS-INDX2                    PIC S9(4) COMP.
016548     05  WS-INDX2                    PIC S9(4) BINARY.
025970/
025970 01  WS-CONSTANTS.
025970     05  WS-TRANS-NAME               PIC X(04).
025970         88  WS-DEFAULT-TRANS-NAME              VALUE 'DOCM'.
025970     05  WS-TWRK-KEY                 PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                VALUE '1240'.
025970     05  WS-MAX-LIST-LINES           PIC S9(04) BINARY.
025970         88  WS-DEFAULT-MAX-LIST-LINES          VALUE +100.
      /
016537*COPY XCWWWKDT.
      /
014221 COPY CCWWLOCK.
      /
023447*COPY NCFWDOCM.
023447*COPY NCFRDOCM.
      /
       COPY XCWEBLCH.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
023447/
023447 COPY XCFWDTOK.
023447 COPY XCFRDTOK.
023447/
023447 COPY XCFWDOCS.
023447 COPY XCFRDOCS.
      /
023447 COPY XCFWDOCM.
023447 COPY XCFRDOCM.
023447
013578 COPY XCFWXTAB.
013578 COPY XCFRXTAB.
      /
       COPY XCWL0280.
      /
014221 COPY XCWL8090.
      /
013578*COPY NCWL7100.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0160.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
557708
023118     PERFORM  9990-INIT-WORKING-STORAGE
023118         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

023118*    SET MIR-RETRN-OK              TO  TRUE.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *--------------------
       2000-PROCESS-REQUEST.
      *---------------------

023118*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           IF  WGLOB-MSG-ERROR-SW       NOT = ZERO
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           EVALUATE TRUE

               WHEN  WS-BUS-FCN-RETRIEVE
                   PERFORM  3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN  WS-BUS-FCN-CREATE
                   PERFORM  4000-PROCESS-CREATE
                       THRU 4000-PROCESS-CREATE-X

               WHEN  WS-BUS-FCN-UPDATE
                   PERFORM  5000-PROCESS-UPDATE
                       THRU 5000-PROCESS-UPDATE-X

               WHEN  WS-BUS-FCN-DELETE
                   PERFORM  6000-PROCESS-DELETE
                       THRU 6000-PROCESS-DELETE-X

               WHEN  WS-BUS-FCN-LIST
                   PERFORM  7000-PROCESS-LIST
                       THRU 7000-PROCESS-LIST-X

           WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                   MOVE 'XS00000237'         TO  WGLOB-MSG-REF-INFO
                   MOVE MIR-BUS-FCN-ID       TO  WGLOB-MSG-PARM (1)
                   MOVE 'NSOM0160'           TO  WGLOB-MSG-PARM (2)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-INVALD-RQST     TO  TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *---------------------
       3000-PROCESS-RETRIEVE.
      *--------------------

           PERFORM  8100-BUILD-DOCM-KEY
               THRU 8100-BUILD-DOCM-KEY-X.

014221*    PERFORM  DOCM-1000-READ
014221*        THRU DOCM-1000-READ-X.
014221
014221     PERFORM  DOCM-1000-READ-TWRK-TS
014221         THRU DOCM-1000-READ-TWRK-TS-X.

           IF  WDOCM-IO-NOT-FOUND
      *MSG: 'DOCUMENT MASTER RECORD (@1) NOT FOUND'
               MOVE 'NS01600001'      TO WGLOB-MSG-REF-INFO
               MOVE WDOCM-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           ELSE
      *MSG: 'INQUIRE COMPLETED - CONTINUE'
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *-------------------
       4000-PROCESS-CREATE.
      *-------------------
      *****************************************************************
      *   CHECK THAT RECORD DOES NOT EXIST, INITIATE
      *   NEW RECORD AND ALLOW USER TO MODIFY
      *****************************************************************

           PERFORM  8100-BUILD-DOCM-KEY
               THRU 8100-BUILD-DOCM-KEY-X.

           PERFORM  8000-EDIT-CONROL-FIELDS
               THRU 8000-EDIT-CONROL-FIELDS-X.

           IF  WS-INVALID-CONTROL
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  DOCM-1000-READ
               THRU DOCM-1000-READ-X.

           IF  WDOCM-IO-NOT-FOUND
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *MSG: 'DOCUMENT MASTER RECORD @1 ALREADY EXISTS'
               MOVE 'NS01600002'      TO WGLOB-MSG-REF-INFO
               MOVE WDOCM-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  DOCM-1000-CREATE
               THRU DOCM-1000-CREATE-X.

           PERFORM  DOCM-1000-WRITE
               THRU DOCM-1000-WRITE-X.

014221     PERFORM  DOCM-1000-READ-TWRK-TS
014221         THRU DOCM-1000-READ-TWRK-TS-X.

      *MSG: 'RECORD CREATED - CONTINUE'
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *-------------------
       5000-PROCESS-UPDATE.
      *-------------------

           PERFORM  8100-BUILD-DOCM-KEY
               THRU 8100-BUILD-DOCM-KEY-X.

014221*    PERFORM  DOCM-1000-READ-FOR-UPDATE
014221*        THRU DOCM-1000-READ-FOR-UPDATE-X.
014221
014221     PERFORM  DOCM-2000-UPDATE-TWRK-TS
014221         THRU DOCM-2000-UPDATE-TWRK-TS-X.
014221
014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221         MOVE 'DOCM'            TO WGLOB-MSG-PARM (01)
014221         MOVE WDOCM-KEY         TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF  WDOCM-IO-NOT-FOUND
      *MSG: 'LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS'
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WDOCM-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

023447*    MOVE 'Y'                   TO WS-DATA-EDITS.
023447     SET WS-DATA-EDITS-OK TO TRUE.

           PERFORM  8500-EDIT-DATA-FIELDS
               THRU 8500-EDIT-DATA-FIELDS-X.

023447     IF WS-DATA-EDITS-OK-NO
023447         PERFORM  DOCM-3000-UNLOCK
023447             THRU DOCM-3000-UNLOCK-X
023447
023447         GO TO 5000-PROCESS-UPDATE-X
023447     END-IF.

023447* IF DOCSTC-ID HAS BEEN CHANGED, THEN WE NEED TO REFLECT THIS
023447* IN EVERY DTOK LINKED TO THIS DOCM BEFORE WE UPDATE DOCM.
023447* N.B. IT DOESN'T MATTER WHETHER WE DO THIS BEFORE OR AFTER WE
023447* UPDATE DOCM, AS ALTHOUGH DOCSTC-ID RESIDES ON BOTH TABLES IT
023447* HASN'T BEEN INCLUDED IN ANY FOREIGN KEY BETWEEN THE TWO TABLES.
023447
023447     IF MIR-DOCSTC-ID = RDOCM-DOCSTC-ID
023447         CONTINUE
023447     ELSE
023447         PERFORM  5100-UPDATE-DTOKS
023447             THRU 5100-UPDATE-DTOKS-X
023447
023447         MOVE MIR-DOCSTC-ID          TO RDOCM-DOCSTC-ID
023447     END-IF.

           PERFORM  DOCM-2000-REWRITE
               THRU DOCM-2000-REWRITE-X.

014221     PERFORM  DOCM-1000-READ-TWRK-TS
014221         THRU DOCM-1000-READ-TWRK-TS-X.

023447*    IF  WS-DATA-EDITS-OK
023447*MSG: 'MAINTENANCE COMPLETED - CONTINUE'
023447*        MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
023447*        PERFORM  0260-1000-GENERATE-MESSAGE
023447*            THRU 0260-1000-GENERATE-MESSAGE-X
023447*    ELSE
023447*MSG: 'RECORD UPDATED'
023447*        MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
023447*        PERFORM  0260-1000-GENERATE-MESSAGE
023447*            THRU 0260-1000-GENERATE-MESSAGE-X
023447     MOVE 'XS00000008'          TO WGLOB-MSG-REF-INFO.
023447     PERFORM  0260-1000-GENERATE-MESSAGE
023447         THRU 0260-1000-GENERATE-MESSAGE-X.
023447*    END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.

023447*------------------
023447 5100-UPDATE-DTOKS.
023447*------------------
023447
023447     MOVE MIR-DOC-ID                 TO WDTOK-DOC-ID.
023447     MOVE SPACES                     TO WDTOK-DBSRL-ID.
023447     MOVE SPACES                     TO WDTOK-TOKEN-ID.
023447
023447     MOVE WDTOK-KEY                  TO WDTOK-ENDBR-KEY.
023447
023447     MOVE HIGH-VALUES                TO WDTOK-ENDBR-DBSRL-ID.
023447     MOVE HIGH-VALUES                TO WDTOK-ENDBR-TOKEN-ID.
023447
023447     PERFORM  DTOK-1000-BROWSE-UCUR
023447         THRU DTOK-1000-BROWSE-UCUR-X.
023447
023447     IF WDTOK-IO-OK
023447         CONTINUE
023447     ELSE
023447         GO TO 5100-UPDATE-DTOKS-X
023447     END-IF.
023447
023447     PERFORM  5200-UPDATE-DTOK
023447         THRU 5200-UPDATE-DTOK-X
023447         UNTIL NOT WDTOK-IO-OK.
023447
023447     PERFORM  DTOK-5000-END-BROWSE-UCUR
023447         THRU DTOK-5000-END-BROWSE-UCUR-X.
023447
023447 5100-UPDATE-DTOKS-X.
023447     EXIT.
023447
023447*-----------------
023447 5200-UPDATE-DTOK.
023447*-----------------
023447
023447     PERFORM  DTOK-2000-READ-NEXT-UCUR
023447         THRU DTOK-2000-READ-NEXT-UCUR-X.
023447
023447     IF WDTOK-IO-OK
023447         CONTINUE
023447     ELSE
023447         GO TO 5200-UPDATE-DTOK-X
023447     END-IF.
023447
023447     MOVE MIR-DOCSTC-ID              TO RDTOK-DOCSTC-ID.
023447
023447     PERFORM  DTOK-3000-REWRITE-UCUR
023447         THRU DTOK-3000-REWRITE-UCUR-X.
023447
023447 5200-UPDATE-DTOK-X.
023447     EXIT.
      /
      *-------------------
       6000-PROCESS-DELETE.
      *-------------------
      *

           PERFORM  8100-BUILD-DOCM-KEY
               THRU 8100-BUILD-DOCM-KEY-X.

014221*    PERFORM  DOCM-1000-READ-FOR-UPDATE
014221*        THRU DOCM-1000-READ-FOR-UPDATE-X.
014221
014221     PERFORM  DOCM-2000-UPDATE-TWRK-TS
014221         THRU DOCM-2000-UPDATE-TWRK-TS-X.
014221
014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221         MOVE 'DOCM'            TO WGLOB-MSG-PARM (01)
014221         MOVE WDOCM-KEY         TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF  WDOCM-IO-NOT-FOUND
      *MSG: 'RECORD (@1) LOST IN DELETE - CONTACT SYSTEMS'
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WDOCM-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  DOCM-1000-DELETE
                   THRU DOCM-1000-DELETE-X
      *MSG: 'DELETE COMPLETED - CONTINUE'
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *------------------
       7000-PROCESS-LIST.
      *------------------

           PERFORM  8200-BUILD-DOCM-BROWSE-KEY
               THRU 8200-BUILD-DOCM-BROWSE-KEY-X.

           PERFORM  DOCM-1000-BROWSE
               THRU DOCM-1000-BROWSE-X.

           PERFORM  DOCM-2000-READ-NEXT
               THRU DOCM-2000-READ-NEXT-X.

           IF  WDOCM-IO-EOF
               PERFORM  DOCM-3000-END-BROWSE
                   THRU DOCM-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-PROCESS-LIST-X
           END-IF.

           PERFORM  7100-BROWSE-DOCM
               THRU 7100-BROWSE-DOCM-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WDOCM-IO-EOF.
           

           IF  WDOCM-IO-EOF
025244         MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
025244         PERFORM  0260-1000-GENERATE-MESSAGE
025244             THRU 0260-1000-GENERATE-MESSAGE-X
025244*        CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS    TO  TRUE
025244         MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
025244* TO VIEW MORE DATA - SELECT MORE
025244         PERFORM  0260-1000-GENERATE-MESSAGE
025244             THRU 0260-1000-GENERATE-MESSAGE-X

               MOVE RDOCM-DOC-ID             TO  MIR-DOC-ID
023447*        MOVE RDOCM-DOC-LANG-CD        TO  MIR-DOC-LANG-CD
           END-IF.

           PERFORM  DOCM-3000-END-BROWSE
               THRU DOCM-3000-END-BROWSE-X.

       7000-PROCESS-LIST-X.
           EXIT.
      /
      *----------------
       7100-BROWSE-DOCM.
      *----------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  DOCM-2000-READ-NEXT
               THRU DOCM-2000-READ-NEXT-X.

       7100-BROWSE-DOCM-X.
           EXIT.
      /
      *-------------------------
       8000-EDIT-CONROL-FIELDS.
      *-------------------------
      *****************************************************************
      *   CHECK VALIDITY OF ALL CONTROL FIELD EXCEPT ENTER
      *****************************************************************

           MOVE '0'                   TO WS-VALIDATE-CONTROL.

           MOVE MIR-DOC-ID            TO WS-DOC-ARRAY.

           PERFORM
               VARYING WS-INDX1 FROM 1 BY 1
                 UNTIL WS-INDX1 > 5
                    OR WS-DOC-NAME (WS-INDX1) NOT = SPACE
015543         CONTINUE
           END-PERFORM.

           PERFORM
               VARYING WS-INDX2 FROM 1 BY 1
                 UNTIL WS-INDX2 > 5
                    OR WS-DOC-NAME (WS-INDX2) = SPACE
015543         CONTINUE
           END-PERFORM.

           IF  WS-INDX2 < WS-INDX1
           OR  MIR-DOC-ID = SPACES
      *MSG: 'INVALID DOCUMENT NAME'
               MOVE 'NS01600009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'               TO WS-VALIDATE-CONTROL
           END-IF.

023447*    MOVE MIR-DOC-LANG-CD       TO WEDIT-ETBL-VALU-ID.

023447*    PERFORM  LANG-1000-EDIT
023447*        THRU LANG-1000-EDIT-X.

023447*    IF  WEDIT-IO-OK
023447*        NEXT SENTENCE
023447*    ELSE
      *MSG: 'LANGUAGE CODE MUST BE IN EDIT TYPE 'LANG''
023447*        MOVE 'XS00000115'      TO WGLOB-MSG-REF-INFO
023447*        MOVE MIR-DOC-LANG-CD   TO WGLOB-MSG-PARM (1)
023447*        PERFORM  0260-1000-GENERATE-MESSAGE
023447*            THRU 0260-1000-GENERATE-MESSAGE-X
023447*        IF  WGLOB-MSG-SEVRTY-WARNING
023447*            NEXT SENTENCE
023447*        ELSE
023447*            MOVE '1'           TO WS-VALIDATE-CONTROL
023447*        END-IF
023447*    END-IF.

       8000-EDIT-CONROL-FIELDS-X.
           EXIT.
      /
      *--------------------
       8100-BUILD-DOCM-KEY.
      *--------------------
      *****************************************************************
      *   SET UP THE KEY TO BE USED IN I/O ROUTINES.
      *****************************************************************

023447*    MOVE MIR-DOC-LANG-CD       TO WDOCM-DOC-LANG-CD.
           MOVE MIR-DOC-ID            TO WDOCM-DOC-ID.

       8100-BUILD-DOCM-KEY-X.
           EXIT.
      /
      *--------------------------
       8200-BUILD-DOCM-BROWSE-KEY.
      *--------------------------
      *****************************************************************
      *   SET UP THE KEY TO BE USED IN I/O ROUTINES.
      *****************************************************************

           MOVE LOW-VALUES            TO WDOCM-KEY.
           MOVE MIR-DOC-ID            TO WDOCM-DOC-ID.
023447*    MOVE MIR-DOC-LANG-CD       TO WDOCM-DOC-LANG-CD.

           MOVE HIGH-VALUES           TO WDOCM-ENDBR-KEY.

       8200-BUILD-DOCM-BROWSE-KEY-X.
           EXIT.
      /
      *----------------------
       8500-EDIT-DATA-FIELDS.
      *----------------------
      *****************************************************************
      *   CHECK VALIDITY OF ALL DATA FIELDS
      *****************************************************************

           PERFORM  8510-EDIT-ROUTES
               THRU 8510-EDIT-ROUTES-X.

554712*    PERFORM  8610-EDIT-DODES
554712*        THRU 8610-EDIT-DODES-X.

           PERFORM  8620-EDIT-COPYS
               THRU 8620-EDIT-COPYS-X.

           PERFORM  8630-EDIT-NPRSW
               THRU 8630-EDIT-NPRSW-X.

           PERFORM  8640-EDIT-ONBSW
               THRU 8640-EDIT-ONBSW-X.

023447     PERFORM  8660-EDIT-STRUCT-ID
023447         THRU 8660-EDIT-STRUCT-ID-X.

       8500-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      *-----------------
       8510-EDIT-ROUTES.
      *-----------------
      *****************************************************************
      *    ENSURE THAT THE ROUTE FIELDS ARE VALID
      *    DO NOT CHANGE ANY OF THE ROUTE FIELDS IF
      *    ANY ONE IS INCORRECT
      *****************************************************************

           SET  WS-ROUTES-VALID            TO TRUE.

           PERFORM  8520-EDIT-ROUTE
               THRU 8520-EDIT-ROUTE-X
                  VARYING WS-SUB FROM 1 BY 1
                  UNTIL WS-SUB > 4.

           IF  WS-ROUTES-VALID
               MOVE SPACES            TO MIR-RTE-4-PRTR-ID-T (1)
               MOVE SPACES            TO MIR-RTE-4-PRTR-ID-T (2)
               MOVE SPACES            TO MIR-RTE-4-PRTR-ID-T (3)
               MOVE SPACES            TO MIR-RTE-4-PRTR-ID-T (4)
               MOVE SPACES            TO RDOCM-RTE-PRTR-ID-INFO
               MOVE 1                 TO WS-SUB2
               PERFORM  8530-MOVE-ROUTES
                   THRU 8530-MOVE-ROUTES-X
                   VARYING WS-SUB FROM 1 BY 1
                   UNTIL WS-SUB > 4
           ELSE
      *MSG: 'ROUTING IS NOT VALID'
               MOVE 'NS01600004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
                   MOVE SPACES        TO MIR-RTE-4-PRTR-ID-T (1)
                   MOVE SPACES        TO MIR-RTE-4-PRTR-ID-T (2)
                   MOVE SPACES        TO MIR-RTE-4-PRTR-ID-T (3)
                   MOVE SPACES        TO MIR-RTE-4-PRTR-ID-T (4)
                   MOVE SPACES        TO RDOCM-RTE-PRTR-ID-INFO
                   MOVE 1             TO WS-SUB2
                   PERFORM  8530-MOVE-ROUTES
                       THRU 8530-MOVE-ROUTES-X
                       VARYING WS-SUB FROM 1 BY 1
                       UNTIL WS-SUB > 4
               ELSE
023447*            MOVE 'N'           TO WS-DATA-EDITS
023447             SET WS-DATA-EDITS-OK-NO TO TRUE
               END-IF
           END-IF.

       8510-EDIT-ROUTES-X.
           EXIT.
      /
      *----------------
       8520-EDIT-ROUTE.
      *----------------
      *****************************************************************
      *   THE ROUTING FIELD IS EDITED IN NSLC7100
      *   (NOT ALL FOUR ROUTINGS NEED BE SPECIFIED)
      *****************************************************************

           IF  MIR-RTE-4-PRTR-ID-T (WS-SUB)         = SPACES
               MOVE RDOCM-RTE-PRTR-ID (WS-SUB)
                                      TO MIR-RTE-4-PRTR-ID-T (WS-SUB)
               MOVE RDOCM-RTE-PRTR-ID (WS-SUB)
                                      TO WS-ROUTE-HOLD (WS-SUB)
               GO TO 8520-EDIT-ROUTE-X
           END-IF.

           IF  MIR-RTE-4-PRTR-ID-T (WS-SUB) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO WS-ROUTE-HOLD (WS-SUB)
               GO TO 8520-EDIT-ROUTE-X
           END-IF.

013578*    MOVE MIR-RTE-4-PRTR-ID-T (WS-SUB)
013578*                               TO L7100-ROUTE.

013578*    PERFORM  7100-1000-VALIDATE-ROUTE
013578*        THRU 7100-1000-VALIDATE-ROUTE-X.

013578*    IF  L7100-RETRN-ROUTE-INVALID
013578*        SET  WS-ROUTES-INVALID      TO TRUE
013578*        MOVE L7100-ROUTE       TO WS-ROUTE-HOLD (WS-SUB)
013578*        GO TO 8520-EDIT-ROUTE-X
013578*    END-IF.

013578*    MOVE L7100-ROUTE           TO WS-ROUTE-HOLD (WS-SUB).

013578**   VERIFY PRINTER ID EXISTS ON XTAB
013578     MOVE MIR-RTE-4-PRTR-ID-T (WS-SUB) TO WXTAB-ETBL-VALU-ID.
013578     PERFORM PRTI-1000-EDIT-PRINTER-ID
013578        THRU PRTI-1000-EDIT-PRINTER-ID-X.
013578     IF NOT WXTAB-IO-OK
013578         SET WS-ROUTES-INVALID         TO TRUE
           END-IF.

013578     MOVE MIR-RTE-4-PRTR-ID-T (WS-SUB) TO WS-ROUTE-HOLD (WS-SUB).

       8520-EDIT-ROUTE-X.
           EXIT.
      /
      *-----------------
       8530-MOVE-ROUTES.
      *-----------------
      *****************************************************************
      *   MOVE ROUTING FIELDS TO THE DOCUMENT RECORD SUCH
      *   THAT THEY ARE "LEFT-JUSTIFIED"
      *****************************************************************

           IF  WS-ROUTE-HOLD (WS-SUB)      = SPACES
               GO TO 8530-MOVE-ROUTES-X
           ELSE
               MOVE WS-ROUTE-HOLD (WS-SUB)
                                      TO MIR-RTE-4-PRTR-ID-T (WS-SUB2)
               MOVE MIR-RTE-4-PRTR-ID-T (WS-SUB2)
                                      TO RDOCM-RTE-PRTR-ID (WS-SUB2)
               ADD 1                       TO WS-SUB2
           END-IF.

       8530-MOVE-ROUTES-X.
           EXIT.
      /
      *----------------
554712*8610-EDIT-DODES.
554712*----------------
554712*****************************************************************
554712*   DOCUMENT DESCRIPTION IS FREE FORMAT, SO NO EDITS
554712*   ARE NECESSARY BEYOND CHECKING WHETHER VALUE WAS
554712*   BLANKED OUT.
554712*****************************************************************
554712*
554712*    IF  MIR-ETBL-DESC-TXT                    = SPACES
554712*        MOVE RDOCM-DOC-DESC-TXT     TO MIR-ETBL-DESC-TXT
554712*    ELSE
554712*        IF  MIR-ETBL-DESC-TXT   = EBLCH-BLANK-FIELD-CHAR
554712*            MOVE SPACES             TO MIR-ETBL-DESC-TXT
554712*        END-IF
554712*    END-IF.
554712*
554712*    IF  MIR-ETBL-DESC-TXT                NOT = SPACES
554712*        MOVE MIR-ETBL-DESC-TXT        TO RDOCM-DOC-DESC-TXT
554712*    ELSE
554712*MSG: 'PLEASE ENTER DESCRIPTION'
554712*        MOVE 'NS01600008'           TO WGLOB-MSG-REF-INFO
554712*        PERFORM  0260-1000-GENERATE-MESSAGE
554712*            THRU 0260-1000-GENERATE-MESSAGE-X
554712*        MOVE TATRB-DATA-ERROR       TO MIR-ETBL-DESC-TXT-A
554712*        MOVE -1                     TO MIR-ETBL-DESC-TXT-L
554712*        MOVE 'P'                    TO LTPI-CURSOR-POS-IND
554712*        MOVE 'N'                    TO WS-DATA-EDITS
554712*    END-IF.
554712*
554712*8610-EDIT-DODES-X.
554712*    EXIT.
      /
      *----------------
       8620-EDIT-COPYS.
      *----------------
      *****************************************************************
      *   COPIES MUST BE NUMERIC 1 THROUGH 99
      *****************************************************************

           IF  MIR-DOC-CPY-QTY                    = SPACES
               MOVE RDOCM-DOC-CPY-QTY-N
                                      TO MIR-DOC-CPY-QTY
               GO TO 8620-EDIT-COPYS-X
           ELSE
               IF  MIR-DOC-CPY-QTY   = EBLCH-BLANK-FIELD-CHAR
                   MOVE ZEROS         TO MIR-DOC-CPY-QTY
               END-IF
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-LENGTH.
           MOVE 0                     TO L0280-PRECISION.
           MOVE MIR-DOC-CPY-QTY       TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-ARGS-INVALID
      *MSG: 'NUMERIC CHECK ARGUMENTS INVALID'
               MOVE 'XS00000020'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8620-EDIT-COPYS-X
           END-IF.

           IF  L0280-OK
               MOVE L0280-OUTPUT      TO WS-COPIES
               MOVE WS-COPIES         TO MIR-DOC-CPY-QTY
           ELSE
      *MSG: 'COPIES MUST BE NUMERIC 1-99'
               MOVE 'NS01600005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
023447*        MOVE 'N'               TO WS-DATA-EDITS
023447         SET WS-DATA-EDITS-OK-NO TO TRUE
               GO TO  8620-EDIT-COPYS-X
           END-IF.

           IF  WS-COPIES-VALID
               MOVE WS-COPIES         TO RDOCM-DOC-CPY-QTY-N
           ELSE
      *MSG: 'COPIES MUST BE NUMERIC 1-99'
               MOVE 'NS01600005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
                   MOVE L0280-OUTPUT  TO RDOCM-DOC-CPY-QTY-N
               ELSE
023447*            MOVE 'N'           TO WS-DATA-EDITS
023447             SET WS-DATA-EDITS-OK-NO TO TRUE
               END-IF
           END-IF.

       8620-EDIT-COPYS-X.
           EXIT.
      /
      *----------------
       8630-EDIT-NPRSW.
      *----------------
      *****************************************************************
007685*   PRINT-SW MUST BE EITHER 'I' OR 'E'
      *****************************************************************

016440*    IF  MIR-DOC-NB-DOC-CD                    = SPACES
016440     IF  MIR-DOC-PRT-CREAT-CD                 = SPACES
016440*        MOVE RDOCM-DOC-NB-DOC-CD
016440*                               TO MIR-DOC-NB-DOC-CD
016440         MOVE RDOCM-DOC-PRT-CREAT-CD
016440                                TO MIR-DOC-PRT-CREAT-CD
               GO TO 8630-EDIT-NPRSW-X
           ELSE
016440*        IF  MIR-DOC-NB-DOC-CD  = EBLCH-BLANK-FIELD-CHAR
016440*            MOVE SPACES        TO MIR-DOC-NB-DOC-CD
016440         IF  MIR-DOC-PRT-CREAT-CD  = EBLCH-BLANK-FIELD-CHAR
016440             MOVE SPACES        TO MIR-DOC-PRT-CREAT-CD
               END-IF
           END-IF.

016440*    MOVE MIR-DOC-NB-DOC-CD     TO WS-VALID-SW.
016440     MOVE MIR-DOC-PRT-CREAT-CD  TO WS-VALID-SW.
007685     IF  WS-NPRSW-VALID
016440*        MOVE MIR-DOC-NB-DOC-CD TO RDOCM-DOC-NB-DOC-CD
016440         MOVE MIR-DOC-PRT-CREAT-CD TO RDOCM-DOC-PRT-CREAT-CD
007685         IF  WS-NPRSW-EX-VALID
007685*MSG: (I) 'EXTERNAL DOCUMENT WILL NOT PRINT IN INGENIUM'
007685             MOVE 'NS01600003'  TO WGLOB-MSG-REF-INFO
007685             PERFORM  0260-1000-GENERATE-MESSAGE
007685                 THRU 0260-1000-GENERATE-MESSAGE-X
007685         END-IF
007685     END-IF.
007685*    ELSE

007685     IF NOT WS-NPRSW-VALID
007685*MSG: 'PRINT OPTION MUST BE I OR E'
               MOVE 'NS01600006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
016440*            MOVE MIR-DOC-NB-DOC-CD
016440*                               TO RDOCM-DOC-NB-DOC-CD
016440             MOVE MIR-DOC-PRT-CREAT-CD
016440                                TO RDOCM-DOC-PRT-CREAT-CD
               ELSE
023447*            MOVE 'N'           TO WS-DATA-EDITS
023447             SET WS-DATA-EDITS-OK-NO TO TRUE
               END-IF
           END-IF.

       8630-EDIT-NPRSW-X.
           EXIT.
      /
      *----------------
       8640-EDIT-ONBSW.
      *----------------
      *****************************************************************
      *   ONLINE-BATCH-SW MUST BE EITHER 'O' OR 'B'
      *****************************************************************

           IF  MIR-DOC-ENVRMNT-PRT-CD                    = SPACES
557659*        MOVE RDOCM-ONLN-OR-BTCH-IND TO MIR-DOC-ENVRMNT-PRT-CD
557659         MOVE RDOCM-DOC-ENVRMNT-PRT-CD
                                      TO MIR-DOC-ENVRMNT-PRT-CD
               GO TO 8640-EDIT-ONBSW-X
           ELSE
               IF  MIR-DOC-ENVRMNT-PRT-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-DOC-ENVRMNT-PRT-CD
               END-IF
           END-IF.

           MOVE MIR-DOC-ENVRMNT-PRT-CD                   TO WS-VALID-SW.
           IF  WS-ONBSW-VALID
557659*        MOVE MIR-DOC-ENVRMNT-PRT-CD TO RDOCM-ONLN-OR-BTCH-IND
557659         MOVE MIR-DOC-ENVRMNT-PRT-CD
                                      TO RDOCM-DOC-ENVRMNT-PRT-CD
           ELSE
      *MSG: 'ONLINE/BATCH MUST BE B'
               MOVE 'NS01600007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-WARNING
557659*            MOVE MIR-DOC-ENVRMNT-PRT-CD TO RDOCM-ONLN-OR-BTCH-IND
557659             MOVE MIR-DOC-ENVRMNT-PRT-CD
                                      TO RDOCM-DOC-ENVRMNT-PRT-CD
               ELSE
023447*            MOVE 'N'           TO WS-DATA-EDITS
023447             SET WS-DATA-EDITS-OK-NO TO TRUE
               END-IF
           END-IF.

       8640-EDIT-ONBSW-X.
           EXIT.
      /
023447*--------------------
023447 8660-EDIT-STRUCT-ID.
023447*--------------------
023447
023447* DOCSTC-ID MUST EXIST IN XTAB
023447
023447     MOVE MIR-DOCSTC-ID              TO WXTAB-ETBL-VALU-ID.
023447
023447     PERFORM  DSID-1000-EDIT-DOCS-ST-ID
023447         THRU DSID-1000-EDIT-DOCS-ST-ID-X.
023447
023447     IF WXTAB-IO-OK
023447         CONTINUE
023447     ELSE
023447*MSG: 'INVALID STRUCTURE ID (@1).  CHECK SECURITY EDIT TYPE
023447*     'DSID'.'
023447         MOVE 'NS01600012'           TO WGLOB-MSG-REF-INFO
023447         PERFORM  0260-1000-GENERATE-MESSAGE
023447             THRU 0260-1000-GENERATE-MESSAGE-X
023447         IF  WGLOB-MSG-SEVRTY-WARNING
023447             CONTINUE
023447         ELSE
023447             SET WS-DATA-EDITS-OK-NO TO TRUE
023447         END-IF
023447         GO TO 8660-EDIT-STRUCT-ID-X
023447     END-IF.
023447
023447* DOCSTC-ID MUST BE PRESENT IN DOCS TABLE
023447
023447     MOVE MIR-DOCSTC-ID              TO WDOCS-DOCSTC-ID.
023447     MOVE LOW-VALUES                 TO WDOCS-DBSRL-ID.
023447
023447     MOVE WDOCS-KEY                  TO WDOCS-ENDBR-KEY.
023447     MOVE HIGH-VALUES                TO WDOCS-ENDBR-DBSRL-ID.
023447
023447     PERFORM  DOCS-4000-BROWSE-INDEX
023447         THRU DOCS-4000-BROWSE-INDEX-X.
023447
023447     PERFORM  DOCS-5000-READ-NEXT-INDEX
023447         THRU DOCS-5000-READ-NEXT-INDEX-X.
023447
023447     IF WDOCS-IO-EOF
023447*MSG: 'STRUCTURE ID NOT FOUND IN DOCUMENT STRUCTURE TABLE'
023447         MOVE 'NS01600011'           TO WGLOB-MSG-REF-INFO
023447         PERFORM  0260-1000-GENERATE-MESSAGE
023447             THRU 0260-1000-GENERATE-MESSAGE-X
023447         SET WS-DATA-EDITS-OK-NO TO TRUE
023447         GO TO 8660-EDIT-STRUCT-ID-X
023447     END-IF.
023447
023447     PERFORM  DOCS-6000-END-BROWSE-INDEX
023447         THRU DOCS-6000-END-BROWSE-INDEX-X.
023447
023447* NOW WE NEED TO CHECK EVERY DTOK LINKED TO THIS DOCM AGAINST
023447* DOCS, TO ENSURE THAT THE NEW DOCSTC-ID SUPPORTS EACH DBRL
023447* IDENTIFIED IN DTOK
023447
023447     IF MIR-DOCSTC-ID = RDOCM-DOCSTC-ID
023447         GO TO 8660-EDIT-STRUCT-ID-X
023447     END-IF.
023447
023447     MOVE MIR-DOC-ID                 TO WDTOK-DOC-ID.
023447     MOVE SPACES                     TO WDTOK-DBSRL-ID.
023447     MOVE SPACES                     TO WDTOK-TOKEN-ID.
023447
023447     MOVE WDTOK-KEY                  TO WDTOK-ENDBR-KEY.
023447
023447     MOVE HIGH-VALUES                TO WDTOK-ENDBR-DBSRL-ID.
023447     MOVE HIGH-VALUES                TO WDTOK-ENDBR-TOKEN-ID.
023447
023447     PERFORM  DTOK-4000-BROWSE-INDEX
023447         THRU DTOK-4000-BROWSE-INDEX-X.
023447
023447     IF WDTOK-IO-OK
023447         CONTINUE
023447     ELSE
023447         GO TO 8660-EDIT-STRUCT-ID-X
023447     END-IF.
023447
023447     PERFORM  8670-DTOK-XREF-DOCS
023447         THRU 8670-DTOK-XREF-DOCS-X
023447         UNTIL NOT WDTOK-IO-OK
023447            OR WS-DATA-EDITS-OK-NO.
023447
023447     PERFORM  DTOK-6000-END-BROWSE-INDEX
023447         THRU DTOK-6000-END-BROWSE-INDEX-X.
023447
023447 8660-EDIT-STRUCT-ID-X.
023447     EXIT.
023447
023447*--------------------
023447 8670-DTOK-XREF-DOCS.
023447*--------------------
023447
023447     PERFORM  DTOK-5000-READ-NEXT-INDEX
023447         THRU DTOK-5000-READ-NEXT-INDEX-X.
023447
023447     IF WDTOK-IO-OK
023447         CONTINUE
023447     ELSE
023447         GO TO 8670-DTOK-XREF-DOCS-X
023447     END-IF.
023447
023447     MOVE MIR-DOCSTC-ID              TO WDOCS-DOCSTC-ID.
023447     MOVE RDTOK-DBSRL-ID             TO WDOCS-DBSRL-ID.
023447
023447     PERFORM  DOCS-2000-READ-INDEX
023447         THRU DOCS-2000-READ-INDEX-X.
023447
023447     IF WDOCS-IO-OK
023447         CONTINUE
023447     ELSE
023447*MSG: 'TOKEN (@1) CANNOT BE MOVED AS RELATIONSHIP (@3) DOES '
023447*     'NOT EXIST IN THE NEW STRUCTURE (@2).'
023447         MOVE 'NS01600013'           TO WGLOB-MSG-REF-INFO
023447         MOVE RDTOK-TOKEN-ID         TO WGLOB-MSG-PARM (1)
023447         MOVE MIR-DOCSTC-ID          TO WGLOB-MSG-PARM (2)
023447         MOVE RDTOK-DBSRL-ID         TO WGLOB-MSG-PARM (3)
023447         PERFORM  0260-1000-GENERATE-MESSAGE
023447             THRU 0260-1000-GENERATE-MESSAGE-X
023447         SET WS-DATA-EDITS-OK-NO TO TRUE
023447         GO TO 8670-DTOK-XREF-DOCS-X
023447     END-IF.
023447
023447 8670-DTOK-XREF-DOCS-X.
023447     EXIT.
023447/
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------
      *****************************************************************
      *   SET ALL (NON-KEY, NON-CONTROL) DATA FIELDS ON THE
      *   SCREEN TO SPACES.
      *****************************************************************

           MOVE SPACES                TO MIR-DOC-ID-G.
023447*    MOVE SPACES                TO MIR-DOC-LANG-CD-G.

           MOVE SPACES                TO MIR-RTE-4-PRTR-ID-T (1).
           MOVE SPACES                TO MIR-RTE-4-PRTR-ID-T (2).
           MOVE SPACES                TO MIR-RTE-4-PRTR-ID-T (3).
           MOVE SPACES                TO MIR-RTE-4-PRTR-ID-T (4).
           MOVE SPACES                TO MIR-DOC-CPY-QTY.
016440*    MOVE SPACES                TO MIR-DOC-NB-DOC-CD.
016440     MOVE SPACES                TO MIR-DOC-PRT-CREAT-CD.
           MOVE SPACES                TO MIR-DOC-ENVRMNT-PRT-CD.
023447     MOVE SPACES                TO MIR-DOCSTC-ID.
023447     MOVE SPACES                TO MIR-DOCSTC-ID-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------
      *****************************************************************
      *   MOVE DATA FROM RECORD BUFFER TO SCREEN INTERFACE RECORD
      *   IN PREPARATION FOR DISPLAY OF NEW DATA
      *****************************************************************


           IF WS-BUS-FCN-LIST
              MOVE RDOCM-DOC-ID          TO  MIR-DOC-ID-T (WS-SUB)
023447*       MOVE RDOCM-DOC-LANG-CD     TO  MIR-DOC-LANG-CD-T (WS-SUB)
023447        MOVE RDOCM-DOCSTC-ID       TO MIR-DOCSTC-ID-T(WS-SUB)
              GO TO 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

554712*
554712*    GET THE DESCRIPTION FROM EDIT/DCOM USING
554712*    THE DOCUMENT ID AND DOCUMENT LANGAUGE
554712*
554712*    MOVE RDOCM-DOC-DESC-TXT         TO MIR-ETBL-DESC-TXT.
           MOVE RDOCM-RTE-PRTR-ID (1) TO MIR-RTE-4-PRTR-ID-T (1).
           MOVE RDOCM-RTE-PRTR-ID (2) TO MIR-RTE-4-PRTR-ID-T (2).
           MOVE RDOCM-RTE-PRTR-ID (3) TO MIR-RTE-4-PRTR-ID-T (3).
           MOVE RDOCM-RTE-PRTR-ID (4) TO MIR-RTE-4-PRTR-ID-T (4).
           MOVE RDOCM-DOC-CPY-QTY-N   TO MIR-DOC-CPY-QTY.
016440*    MOVE RDOCM-DOC-NB-DOC-CD   TO MIR-DOC-NB-DOC-CD.
016440     MOVE RDOCM-DOC-PRT-CREAT-CD  TO MIR-DOC-PRT-CREAT-CD.
557659*    MOVE RDOCM-ONLN-OR-BTCH-IND     TO MIR-DOC-ENVRMNT-PRT-CD.
557659     MOVE RDOCM-DOC-ENVRMNT-PRT-CD
                                      TO MIR-DOC-ENVRMNT-PRT-CD.
023447     MOVE RDOCM-DOCSTC-ID       TO MIR-DOCSTC-ID.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
554712
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------
      *****************************************************************
      *   SET UP THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023118/
023118*--------------------------
023118 9990-INIT-WORKING-STORAGE.
023118*--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023118
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                        WS-PGM-WORK-AREA.
025970     INITIALIZE                        WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                        WLOCK-TWRK-OTHER-INFO.
025970*    SET MIR-RETRN-OK              TO  TRUE.
025970
025970     SET WS-DEFAULT-TRANS-NAME         TO  TRUE.
025970     SET WS-DEFAULT-TWRK-KEY           TO  TRUE.
025970     SET WS-DEFAULT-MAX-LIST-LINES     TO  TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.
023118
023118 9990-INIT-WORKING-STORAGE-X.
023118     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS
      ****************************************************************

026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY DOCM
014221                         '$VAR2' BY 'DOCM'.
      /
       COPY CCPELANG.
      /
016537*COPY NCPEDOCM.
023447 COPY XCPEDSID.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      ****************************************************************
      * LINKAGE COPYBOOKS
      ****************************************************************
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS
      ****************************************************************
014660*COPY XCPPMEXT.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      ****************************************************************
      *  FILE I/O PROCESS MODULES
      ****************************************************************
023447*COPY NCPADOCM.
023447*COPY NCPBDOCM.
023447*COPY NCPNDOCM.
023447*COPY NCPUDOCM.
023447*COPY NCPXDOCM.
023447*
023447*COPY NCPCDOCM.
      /
013578 COPY XCPNXTAB.
      /
       COPY CCPNEDIT.
023447/
023447 COPY XCPBDTOK.
023447 COPY XCPDDTOK.
023447 COPY XCPUDTOK.
023447/
023447 COPY XCPBDOCS.
023447 COPY XCPNDOCS.
023447/
023447 COPY XCPADOCM.
023447 COPY XCPBDOCM.
023447 COPY XCPCDOCM.
023447 COPY XCPNDOCM.
023447 COPY XCPUDOCM.
023447 COPY XCPXDOCM.
023447/
013578 COPY XCPEPRTI.
      /
013578*COPY NCCL7100.
      /
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM0160                     **
      *****************************************************************
