      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4902.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4902                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION FOR     **
      **            THE PACK TABLE. FOR A GIVEN BASE COVERAGE PLAN   **
      **            IT WILL RETURN CORRESPONDING OPTIONAL RISK PLANS **
      **            AND THEIR DESCRIPTIONS.                          **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014653**  6.0       NEW FOR RELEASE 6.0                              **
016051**  6.1       CHANGES FOR APP ENTRY FLOW                       **
014591**  6.2       COMBINE PLAN-ID & RS                             **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4902'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
014590*COPY XCWL0030.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                           PIC X(04).
               88  WS-BUS-FCN-LIST                     VALUE '4902'.
      * NUMBER OF ENTRIES USED IN MIR OUTPUT TABLE.
016548*    05  WS-SUB1                                 PIC S9(04) COMP.
016548     05  WS-SUB1                                 PIC S9(04)
016548                                                 BINARY.
      * NUMBER OF COVERAGES BEING PROCESSED.
016548*    05  WS-SUB2                                 PIC S9(04) COMP.
016548     05  WS-SUB2                                 PIC S9(04)
016548                                                 BINARY.
016548*    05  WS-MAX-LIST-LINES                       PIC S9(04) COMP
025970*    05  WS-MAX-LIST-LINES                       PIC S9(04) BINARY
025970*                                                VALUE 50.

025970 01  WS-CONSTANT-AREA.
025970     05  WS-MAX-LIST-LINES                       PIC S9(04) BINARY
025970                                                 VALUE 50.
025970         88  WS-MAX-LIST-LINES-DEFAULT           VALUE 50.
025970
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWCVGS.
      /
       COPY CCWWINDX.
      /
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY CCFWPACK.
       COPY CCFRPACK.
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
       COPY CCFWPD.
       COPY CCFRPD.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
       COPY CCWL3330.
      /
018764*COPY XCWLPTR.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM4902.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

025970*    SET MIR-RETRN-OK           TO TRUE.
025970*    MOVE ZERO                  TO WS-SUB1.
025970*    MOVE ZERO                  TO WS-SUB2.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID
025970*      TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM4902'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEY-POL
               THRU 7000-BUILD-KEY-POL-X.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WPOL-KEY
                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           PERFORM  7010-BUILD-KEY-PH
               THRU 7010-BUILD-KEY-PH-X.

           PERFORM  PH-1000-READ
               THRU PH-1000-READ-X.

           IF  WPH-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WPH-KEY
                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-LIST-X
           END-IF.

           PERFORM 8000-GET-LOCATION-GROUP
              THRU 8000-GET-LOCATION-GROUP-X.

           IF  L3330-RETRN-OK
               CONTINUE
           ELSE
      *MSG: PACKAGING LOCATION GROUP NOT FOUND FOR GROUP (@1)
               MOVE 'CS49020001'          TO WGLOB-MSG-REF-INFO
               MOVE RPH-LOC-GR-COLCT-ID   TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET MIR-RETRN-EDIT-ERROR TO TRUE
                   GO TO 2000-LIST-X
               END-IF
           END-IF.

           PERFORM  7020-BUILD-KEY-PACK-READ
               THRU 7020-BUILD-KEY-PACK-READ-X.

           PERFORM  PACK-1000-READ
               THRU PACK-1000-READ-X.

      *
      * PLAN MUST HAVE A BASIC PLAN PACKAGING MATRIX
      *
           IF  WPACK-IO-NOT-FOUND
      *MSG: NO PACK ENTRY FOR BASIC PLAN - @1 SUB-CO @2
               MOVE 'CS49020002'          TO WGLOB-MSG-REF-INFO
               MOVE WPACK-BASIC-PLAN-ID   TO WGLOB-MSG-PARM (1)
               MOVE WPACK-SBSDRY-CO-ID    TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   SET MIR-RETRN-EDIT-ERROR TO TRUE
                   GO TO 2000-LIST-X
               END-IF
           END-IF.

016051* WE ARE ONLY DEALING THE PLAN THAT IS ALLOW FOR ADDITIONAL
016051* PLAN AND PKG-TYP-CD 'O' IS CONSIDERED

           IF  RPACK-PLAN-PKG-TYP-CD NOT = 'O'
      *MSG: NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

           PERFORM  7030-BUILD-KEY-PACK-BROWSE
               THRU 7030-BUILD-KEY-PACK-BROWSE-X.

           PERFORM  PACK-1000-BROWSE
               THRU PACK-1000-BROWSE-X.

           PERFORM  PACK-2000-READ-NEXT
               THRU PACK-2000-READ-NEXT-X.

           IF  WPACK-IO-EOF
               PERFORM  PACK-3000-END-BROWSE
                   THRU PACK-3000-END-BROWSE-X
      *MSG: NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

           MOVE 1                TO  WS-SUB1.
           PERFORM  2010-BROWSE-TABLE-PACK
               THRU 2010-BROWSE-TABLE-PACK-X
              UNTIL WS-SUB1 > WS-MAX-LIST-LINES
                 OR WPACK-IO-EOF.

           IF  WPACK-IO-EOF
               CONTINUE
           ELSE
      *        SET WGLOB-MORE-DATA-EXISTS TO TRUE
      *MSG: MORE DATA EXISTS
               MOVE 'XS00000014'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF WS-SUB1 = 1
      *MSG: NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  PACK-3000-END-BROWSE
               THRU PACK-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.
      /
      *-----------------------
       2010-BROWSE-TABLE-PACK.
      *-----------------------

           PERFORM  7040-BUILD-KEY-PD
               THRU 7040-BUILD-KEY-PD-X.

016051     IF WPD-PLAN-ID = SPACES
016051        PERFORM  PACK-2000-READ-NEXT
016051            THRU PACK-2000-READ-NEXT-X
016051        GO TO 2010-BROWSE-TABLE-PACK-X
016051     END-IF.

           PERFORM  PD-1000-READ
               THRU PD-1000-READ-X.
           IF WPD-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WPD-KEY
                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  WPD-IO-OK
           AND (    RPD-PLAN-INS-TYP-INCM-REPL
                OR  RPD-PLAN-INS-TYP-PURE-ENDOW
                OR  RPD-PLAN-INS-TYP-PU-ENDOW
                OR  RPD-PLAN-INS-TYP-PAID-UP-LIFE
                OR  RPD-PLAN-INS-TYP-PAID-UP-TERM
                OR  RPD-PLAN-INS-TYP-WHOLE-LIFE
                OR  RPD-PLAN-INS-TYP-LEVEL-TERM
                OR  RPD-PLAN-INS-TYP-DECR-TERM
                OR  RPD-PLAN-INS-TYP-OOE
                OR  RPD-PLAN-INS-TYP-UL-INS-ONLY
016051          OR  RPD-PLAN-INS-TYP-UL-ANTY-INS
                OR  RPD-PLAN-INS-TYP-IMMED-ANTY
                OR  RPD-PLAN-INS-TYP-RRIF
                OR  RPD-PLAN-INS-TYP-TRADL-ANTY
                OR  RPD-PLAN-INS-TYP-ISWL )

               PERFORM  8100-GET-PLAN-NAME
                   THRU 8100-GET-PLAN-NAME-X
               PERFORM  9200-MOVE-RECORD-TO-MIR
                   THRU 9200-MOVE-RECORD-TO-MIR-X
           END-IF.

           PERFORM  PACK-2000-READ-NEXT
               THRU PACK-2000-READ-NEXT-X.

       2010-BROWSE-TABLE-PACK-X.
           EXIT.
      /
      *-------------------
       7000-BUILD-KEY-POL.
      *-------------------

           MOVE LOW-VALUES            TO WPOL-KEY.

           MOVE MIR-POL-ID            TO WPOL-POL-ID.

       7000-BUILD-KEY-POL-X.
           EXIT.
      /
      *------------------
       7010-BUILD-KEY-PH.
      *------------------

           MOVE LOW-VALUES            TO WPH-KEY.

           MOVE RPOL-PLAN-ID          TO WPH-PLAN-ID.

       7010-BUILD-KEY-PH-X.
           EXIT.
      /
      *-------------------------
       7020-BUILD-KEY-PACK-READ.
      *-------------------------

           MOVE SPACES                TO WPACK-KEY.
           MOVE HIGH-VALUES           TO WPACK-ENDBR-KEY.

           MOVE RPOL-PLAN-ID          TO WPACK-BASIC-PLAN-ID.
           MOVE RPOL-SBSDRY-CO-ID     TO WPACK-SBSDRY-CO-ID.
           MOVE L3330-LOC-GR-ID       TO WPACK-LOC-GR-ID.

       7020-BUILD-KEY-PACK-READ-X.
           EXIT.
      /
      *---------------------------
       7030-BUILD-KEY-PACK-BROWSE.
      *---------------------------

           MOVE LOW-VALUES            TO WPACK-KEY.
           MOVE HIGH-VALUES           TO WPACK-ENDBR-KEY.

           MOVE RPOL-PLAN-ID          TO WPACK-BASIC-PLAN-ID.
           MOVE RPOL-SBSDRY-CO-ID     TO WPACK-SBSDRY-CO-ID.
           MOVE L3330-LOC-GR-ID       TO WPACK-LOC-GR-ID.
           MOVE WPACK-KEY             TO WPACK-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WPACK-ENDBR-ADDL-PLAN-MAND-IND.
014591*    MOVE HIGH-VALUES           TO WPACK-ENDBR-ADDL-PLAN-ID-BASE.
014591*    MOVE HIGH-VALUES           TO WPACK-ENDBR-ADDL-PLAN-ID-RS.
014591     MOVE HIGH-VALUES           TO WPACK-ENDBR-ADDL-PLAN-ID.

       7030-BUILD-KEY-PACK-BROWSE-X.
           EXIT.
      /
      *------------------
       7040-BUILD-KEY-PD.
      *------------------

           MOVE LOW-VALUES              TO WPD-KEY.

016051*    IF  RPACK-ADDL-PLAN-ID = SPACES
016051*        MOVE RPACK-BASIC-PLAN-ID TO WPD-PLAN-ID
016051*    ELSE
016051*        MOVE RPACK-ADDL-PLAN-ID  TO WPD-PLAN-ID
016051*    END-IF.

016051     MOVE RPACK-ADDL-PLAN-ID      TO WPD-PLAN-ID.

       7040-BUILD-KEY-PD-X.
           EXIT.
      /
      *------------------------
       8000-GET-LOCATION-GROUP.
      *------------------------

           PERFORM  3330-1000-BUILD-PARM-INFO
               THRU 3330-1000-BUILD-PARM-INFO-X.

           SET L3330-LOC-GR-TYP-PAKIT      TO TRUE.

           PERFORM  3330-1000-GET-LOC-GROUP
               THRU 3330-1000-GET-LOC-GROUP-X.

       8000-GET-LOCATION-GROUP-X.
            EXIT.
      /
      *-------------------
       8100-GET-PLAN-NAME.
      *-------------------

      * READ EDIT TABLE "PLAN" RECORD TYPE FOR THE GIVEN PLAN
      * CODE/RATE SCALE AND GET FULL PLAN NAME.

           MOVE RPD-PLAN-ID           TO WEDIT-ETBL-VALU-ID.
           PERFORM PLAN-2000-DESC
              THRU PLAN-2000-DESC-X.
           IF  NOT WEDIT-IO-OK
      *MSG: PLAN NAME MUST BE ON EDIT TYPE PLAN
      *        MOVE 'CS49020003'      TO WGLOB-MSG-REF-INFO
      *        PERFORM 0260-1000-GENERATE-MESSAGE
      *           THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE SPACES            TO REDIT-ETBL-DESC-TXT
           END-IF.

       8100-GET-PLAN-NAME-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-DV-SBOX-CD-G.
           MOVE SPACES                TO MIR-DV-SBOX-DESC-TXT-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *------------------------
       9200-MOVE-RECORD-TO-MIR.
      *------------------------

           MOVE RPD-PLAN-ID           TO MIR-DV-SBOX-CD-T (WS-SUB1).
           MOVE REDIT-ETBL-DESC-TXT   TO MIR-DV-SBOX-DESC-TXT-T
                                         (WS-SUB1).
           ADD  1                     TO WS-SUB1.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY      TO TRUE.
           MOVE MIR-POL-ID            TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  3330-0000-INIT-PARM-INFO
025970         THRU 3330-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970
025970     SET  WS-MAX-LIST-LINES-DEFAULT   TO TRUE.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970
025970     MOVE SPACES                      TO WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY CCPEPLAN.
      /
       COPY CCPPMIDT.
      /
       COPY NCPPCVGS.
      /
034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY CCCL3330.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPL3330.
       COPY CCPS3330.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCVG.
      /
       COPY CCPNEDIT.
      /
       COPY CCPBPACK.
       COPY CCPNPACK.
      /
       COPY CCPNPH.
       COPY CCPNPD.
      /
       COPY CCPNPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM CSOM4902                     **
      *****************************************************************
