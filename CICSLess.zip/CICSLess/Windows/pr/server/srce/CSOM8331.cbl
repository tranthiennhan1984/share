      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM8331.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM8331                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE CREATE FUNCTION   **
      **            FOR THE POLX TABLE                               **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
031036**  7.0       EXEMPT STATUS MANAGEMENT                         **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM8331'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                          PIC X(04).
               88  WS-BUS-FCN-CREATE                  VALUE '8331'.
           05  WS-POL-XEMP-EFF-DT                     PIC X(10).

       01  WS-CONSTANT-AREA.
           05  WS-TWRK-KEY                            PIC X(04).
               88 WS-TWRK-KEY-DEFAULT                 VALUE '8330'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRPOL.
       COPY CCFWPOL.

       COPY CCFWPOLX.
       COPY CCFRPOLX.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
       COPY CCWLPGA.

       COPY XCWL1640.
       COPY XCWL1670.
       COPY XCWL1680.
       COPY XCWLDTLK.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM8331.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-CREATE
                        THRU 2000-CREATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM8331'           TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-CREATE.
      *------------

      * VALIDATE KEY, CHECK WHETHER POLICY EXEMPT RECORD EXISTS

           PERFORM  8000-EDIT-KEY-INFO
               THRU 8000-EDIT-KEY-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  7000-BUILD-KEY
               THRU 7000-BUILD-KEY-X.

           PERFORM  POLX-2000-READ-INDEX
               THRU POLX-2000-READ-INDEX-X.

           IF  WPOLX-IO-OK
      *MSG: 'RECORD @1 ALREADY EXISTS'
               MOVE 'XS00000003'  TO WGLOB-MSG-REF-INFO
               MOVE WPOLX-KEY     TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1             TO WGLOB-MSG-ERROR-SW
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  POLX-1000-CREATE
               THRU POLX-1000-CREATE-X.

           PERFORM  POLX-1000-WRITE
               THRU POLX-1000-WRITE-X.

       2000-CREATE-X.
           EXIT.
      /

      *---------------
       7000-BUILD-KEY.
      *---------------

           MOVE LOW-VALUES              TO WPOLX-KEY.
           MOVE WGLOB-COMPANY-CODE      TO WPOLX-CO-ID.
           MOVE RPOL-POL-ID             TO WPOLX-POL-ID.
           MOVE WS-POL-XEMP-EFF-DT      TO WPOLX-POL-XEMP-EFF-DT.

       7000-BUILD-KEY-X.
           EXIT.

      *-------------------
       8000-EDIT-KEY-INFO.
      *-------------------
      *
      * VALIDATE POL NUMBER
      *
           MOVE MIR-POL-ID-BASE            TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX             TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'XS00000001'           TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID            TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8000-EDIT-KEY-INFO-X
           END-IF.
      *
      * VALIDATE EFFECTIVE DATE
      *
           MOVE MIR-POL-XEMP-EFF-DT        TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
               MOVE 'XS00000036'           TO WGLOB-MSG-REF-INFO
               MOVE MIR-POL-XEMP-EFF-DT    TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8000-EDIT-KEY-INFO-X
           ELSE
               MOVE L1640-INTERNAL-DATE    TO WS-POL-XEMP-EFF-DT
           END-IF.

      *
      * VALIDATE THE EFFECTIVE CANNOT BE IN THE FUTURE
      *
           IF  WS-POL-XEMP-EFF-DT > WGLOB-PROCESS-DATE
      *MSG: CANNOT CREATE A RECORD THAT IS IN THE FUTURE
               MOVE 'CS83310001'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8000-EDIT-KEY-INFO-X
           END-IF.

      *
      * VALIDATE WHETHER THE EFFECTIVE DATE IS A POLICY ANNIVERSARY DATE
      *
           MOVE RPOL-POL-ISS-EFF-DT     TO L1680-INTERNAL-1.
           MOVE WS-POL-XEMP-EFF-DT      TO L1680-INTERNAL-2.

           PERFORM  1680-2000-COMP-DAYS-BETWEEN
               THRU 1680-2000-COMP-DAYS-BETWEEN-X.

           IF  L1680-NUMBER-OF-YEARS >= ZERO
           AND L1680-NUMBER-OF-MONTHS = ZERO
           AND L1680-NUMBER-OF-DAYS = ZERO
               CONTINUE
           ELSE
      *MSG: EFFECTIVE DATE MUST BE A POLICY ANNIVERSARY DATE
               MOVE 'CS83310002'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8000-EDIT-KEY-INFO-X
           END-IF.

       8000-EDIT-KEY-INFO-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.
           MOVE MIR-POL-ID-BASE          TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX           TO WGLOB-REF-POLICY-SUFFIX.
           SET WGLOB-REF-POLICY          TO TRUE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  1640-0000-INIT-PARM-INFO
               THRU 1640-0000-INIT-PARM-INFO-X.

           PERFORM  1670-0000-INIT-PARM-INFO
               THRU 1670-0000-INIT-PARM-INFO-X.

           PERFORM  1680-0000-INIT-PARM-INFO
               THRU 1680-0000-INIT-PARM-INFO-X.

           PERFORM  8090-0000-INIT-PARM-INFO
               THRU 8090-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
           INITIALIZE WLOCK-TWRK-OTHER-INFO.

           SET WS-TWRK-KEY-DEFAULT   TO TRUE.
           SET MIR-RETRN-OK          TO TRUE.

           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPS8090.

       COPY XCPL0260.

       COPY XCPS1640.
       COPY XCPL1640.

       COPY XCPS1670.

       COPY XCPS1680.
       COPY XCPL1680.

       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.

       COPY CCPNPOLX.
       COPY CCPAPOLX.
       COPY CCPCPOLX.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM8331                     **
      *****************************************************************
