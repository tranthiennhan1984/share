      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSOM2372.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  XSOM2372                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE RECORD UPDATE FUNCTION  **
      **            FOR THE CRAS TABLE                               **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
018770**  6.3       PCR - ALLOWABLE VALUE EDIT                       **
018841**  6.3       REGIONAL EXITS                                   **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSOM2372'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-UPDATE         VALUE '2372'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWLOCK.
       COPY XCWEBLCH.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY XCFWCRAS.
       COPY XCFRCRAS.
      /
018770*COPY XCFWDMAD.
018770*COPY XCFRDMAD.
018770*
       COPY XCFWXTAB.
       COPY XCFRXTAB.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
018764*COPY XCWLPTR.
       COPY XCWL8090.
018770 COPY XCWL8960.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY XCWM2372.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

025970*           PERFORM  9300-SETUP-MSIN-REFERENCE
025970*               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*           MOVE MIR-BUS-FCN-ID
025970*             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'XSOM2372'
                      TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-----------
       2000-UPDATE.
      *-----------
      *
      *  THE RECORD MUST EXIST ON A MAINTAIN
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  CRAS-2000-UPDATE-TWRK-TS
               THRU CRAS-2000-UPDATE-TWRK-TS-X.

           IF  WCRAS-IO-NOT-FOUND
      *MSG: 'LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS'
               MOVE WCRAS-KEY               TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG:   TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
      *       NOT COMPLETE
               MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
               MOVE 'CRAS'                TO WGLOB-MSG-PARM (01)
               MOVE WCRAS-KEY             TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.
      *
      *  EDIT THE DATA ENTERED FOR THE RECORD AND AUDIT CHANGES
      *
           PERFORM  8000-EDITS
               THRU 8000-EDITS-X.

           IF  WGLOB-MSG-ERROR-SW = ZERO
               PERFORM  9200-MOVE-RECORD-TO-MIR
                   THRU 9200-MOVE-RECORD-TO-MIR-X
           ELSE
               SET MIR-RETRN-EDIT-ERROR
                 TO TRUE
           END-IF.

           PERFORM  CRAS-2000-REWRITE
               THRU CRAS-2000-REWRITE-X.

           PERFORM  CRAS-1000-READ-TWRK-TS
               THRU CRAS-1000-READ-TWRK-TS-X.

       2000-UPDATE-X.
           EXIT.
      /
      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------

           PERFORM  4110-EDIT-RGN-EXIT-ID
               THRU 4110-EDIT-RGN-EXIT-ID-X.

           PERFORM  4120-EDIT-CTRY-CD
               THRU 4120-EDIT-CTRY-CD-X.

       2100-VALIDATE-KEYS-X.
           EXIT.
      /

      *----------------------
       4110-EDIT-RGN-EXIT-ID.
      *----------------------

018770*    MOVE MIR-RGN-EXIT-ID         TO WDMAD-DM-AV-CD.
018770*    MOVE 'RGN-EXIT-ID'           TO WDMAD-DM-AV-TBL-CD.
018770*    MOVE WGLOB-USER-LANG         TO WDMAD-DM-AV-DESC-LANG-CD.
018770*
018770*    PERFORM  DMAD-1000-READ
018770*        THRU DMAD-1000-READ-X.
018770*
018770*    IF  NOT WDMAD-IO-OK
018770     PERFORM  8960-1000-BUILD-PARM-INFO
018770         THRU 8960-1000-BUILD-PARM-INFO-X.
018770     MOVE 'RGN-EXIT-ID'           TO L8960-AV-TBL-CD.
018770     MOVE MIR-RGN-EXIT-ID         TO L8960-AV-CD.
018770
018770     PERFORM  8960-1000-VALIDATE-CODE
018770         THRU 8960-1000-VALIDATE-CODE-X.
018770
018770     IF  NOT L8960-RETRN-OK
      *MSG: INVALID REGION EXIT ID (@1) ENTERED
               MOVE MIR-RGN-EXIT-ID     TO WGLOB-MSG-PARM (1)
               MOVE 'XS23720001'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4110-EDIT-RGN-EXIT-ID-X
           END-IF.

       4110-EDIT-RGN-EXIT-ID-X.
           EXIT.
      /

      *------------------
       4120-EDIT-CTRY-CD.
      *------------------

           MOVE MIR-CTRY-CD             TO WXTAB-ETBL-VALU-ID.
           MOVE 'CNTRY'                 TO WXTAB-ETBL-TYP-ID.
           MOVE WGLOB-EDIT-LANG         TO WXTAB-ETBL-LANG-CD.

           PERFORM  XTAB-1000-READ
               THRU XTAB-1000-READ-X.

           IF NOT WXTAB-IO-OK
      *MSG: INVALID COUNTRY CODE (@1) ENTERED
               MOVE MIR-CTRY-CD         TO WGLOB-MSG-PARM (1)
               MOVE 'XS23720002'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4120-EDIT-CTRY-CD-X
           END-IF.

       4120-EDIT-CTRY-CD-X.
           EXIT.
      /

      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WCRAS-KEY.

           MOVE MIR-RGN-EXIT-ID        TO WCRAS-RGN-EXIT-ID.
           MOVE MIR-CTRY-CD            TO WCRAS-CTRY-CD.

       7000-BUILD-KEYS-X.
           EXIT.
      /

      *-----------
       8000-EDITS.
      *-----------

           IF  MIR-CTRY-RGN-CD = SPACES
               MOVE RCRAS-CTRY-RGN-CD  TO MIR-CTRY-RGN-CD
           ELSE
               IF  MIR-CTRY-RGN-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES         TO MIR-CTRY-RGN-CD
               END-IF
           END-IF.

      *  VALIDATE REGION CDOD AGAINST EDIT TABLE.

           MOVE 'RGNCD'                TO WEDIT-ETBL-TYP-ID.
           MOVE MIR-CTRY-RGN-CD        TO WEDIT-ETBL-VALU-ID.
           MOVE WGLOB-EDIT-LANG        TO WEDIT-ETBL-LANG-CD.

           PERFORM  EDIT-1000-READ
               THRU EDIT-1000-READ-X.

           IF  WEDIT-IO-OK
               MOVE MIR-CTRY-RGN-CD    TO RCRAS-CTRY-RGN-CD
           ELSE
      *MSG: INVALID REGION CODE (@1) ENTERED'
               MOVE 'XS23720003'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-CTRY-RGN-CD    TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       8000-EDITS-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                 TO MIR-CTRY-RGN-CD.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9200-MOVE-RECORD-TO-MIR.
      *--------------------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           MOVE RCRAS-CTRY-RGN-CD      TO MIR-CTRY-RGN-CD.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.

025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  9300-SETUP-MSIN-REFERENCE
025970         THRU 9300-SETUP-MSIN-REFERENCE-X.

025970     INITIALIZE WS-WORKING-STORAGE.
025970     MOVE MIR-BUS-FCN-ID
025970       TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY CRAS
                               '$VAR2' BY 'CRAS'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
025970 COPY XCPS8090.
018770 COPY XCPS8960.
018770 COPY XCPL8960.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNEDIT.
018770*COPY XCPNDMAD.
       COPY XCPNXTAB.
      /
       COPY XCPNCRAS.
       COPY XCPUCRAS.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM XSOM2372                     **
      *****************************************************************

