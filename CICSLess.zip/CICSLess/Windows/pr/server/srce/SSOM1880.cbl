      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM1880.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM1880                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE RETRIEVE FUNCTION     **
      **            FOR THE FV TABLE                                 **
      **                                                             **
      **            THE RETRIEVE WILL RETRIEVE ALL UNIT TYPES        **
      **            FOR THE FUND                                     **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
021239**  6.4       FUND UNIT VALUE                                  **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM1880'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-RETRIEVE       VALUE '1880'.
           05  WS-FNDVL-EFF-DT               PIC X(10).
           05  WS-LIST-SIZE                  PIC 9(03).
           05  WS-LIST-IDX                   PIC S9(04) BINARY.

       01  WS-CONSTANT-AREA.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970*                                      VALUE '1880'.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '1880'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY SCFWFH.
       COPY SCFRFH.

       COPY SCFWFVAA.
       COPY SCFRFV.

       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM1880.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE WPGWS-CRNT-PGM-ID
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      *-------------
       2000-RETRIEVE.
      *-------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  FVAA-1000-BROWSE
               THRU FVAA-1000-BROWSE-X.

           PERFORM  FVAA-2000-READ-NEXT
               THRU FVAA-2000-READ-NEXT-X.

           PERFORM
               UNTIL NOT WFVAA-IO-OK

               PERFORM  9200-MOVE-RECORD-TO-MIR
                   THRU 9200-MOVE-RECORD-TO-MIR-X

               PERFORM  FVAA-2000-READ-NEXT
                   THRU FVAA-2000-READ-NEXT-X

           END-PERFORM.

           PERFORM  FVAA-3000-END-BROWSE
               THRU FVAA-3000-END-BROWSE-X.

           IF  WS-LIST-IDX = ZERO
      *MSG: NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2000-RETRIEVE-X.
           EXIT.

      *----------------------------
       2100-VALIDATE-KEYS.
      *----------------------------

           PERFORM  2110-EDIT-FND-ID
               THRU 2110-EDIT-FND-ID-X.

           PERFORM  2120-EDIT-FNDVL-EFF-DT
               THRU 2120-EDIT-FNDVL-EFF-DT-X.

       2100-VALIDATE-KEYS-X.
           EXIT.

      *----------------------------
       2110-EDIT-FND-ID.
      *----------------------------

           MOVE MIR-FND-ID                  TO WFH-FND-ID.

           PERFORM  FH-1000-READ-TWRK-TS
               THRU FH-1000-READ-TWRK-TS-X.

           IF  WFH-IO-NOT-FOUND
      *MSG: @2 RECORD (@1) NOT FOUND
               MOVE WFH-KEY                 TO WGLOB-MSG-PARM (1)
               MOVE 'FH'                    TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000001'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2110-EDIT-FND-ID-X
           END-IF.

           MOVE RFH-FND-PRIC-STRUCT-CD      TO MIR-FND-PRIC-STRUCT-CD.
           MOVE RFH-FND-TYP-CD              TO MIR-FND-TYP-CD.

           MOVE RFH-FND-NXT-VALN-DT         TO L1640-EXTERNAL-DATE.
           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE         TO MIR-FND-NXT-VALN-DT.


       2110-EDIT-FND-ID-X.
           EXIT.

      *----------------------------
       2120-EDIT-FNDVL-EFF-DT.
      *----------------------------

           MOVE MIR-FNDVL-EFF-DT       TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      *MSG: INVALID FUND VALUATION DATE
               MOVE 'SS18800001'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2120-EDIT-FNDVL-EFF-DT-X
           END-IF.

           MOVE L1640-INTERNAL-DATE    TO WS-FNDVL-EFF-DT.

       2120-EDIT-FNDVL-EFF-DT-X.
           EXIT.

      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES             TO WFVAA-KEY.

           MOVE MIR-FND-ID             TO WFVAA-FND-ID.

           MOVE WS-FNDVL-EFF-DT        TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE    TO WFVAA-FNDVL-IDT-NUM.

           MOVE WFVAA-KEY              TO WFVAA-ENDBR-KEY.
           MOVE HIGH-VALUE             TO WFVAA-ENDBR-FNDVL-UNIT-TYP-CD.

       7000-BUILD-KEYS-X.
           EXIT.

      *-----------------
       9000-BLANK-DATA-FIELDS.
      *-----------------

           MOVE SPACE                       TO MIR-FND-ID-G.
           MOVE SPACE                       TO MIR-FNDVL-UNIT-TYP-CD-G.
           MOVE SPACE                       TO MIR-SELL-PRIC-AMT-G.
           MOVE SPACE                       TO MIR-PURCH-PRIC-AMT-G.
           MOVE SPACE                       TO MIR-FNDVL-CHNG-IND-G.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9200-MOVE-RECORD-TO-MIR.
      *--------------------------

           ADD +1                           TO WS-LIST-IDX.

           IF  WS-LIST-IDX > WS-LIST-SIZE
      *MSG: THIS FUND HAS EXCEEDED THE MAX. # OF UNIT TYPE OF @1
               MOVE WS-LIST-SIZE            TO WGLOB-MSG-PARM (1)
               MOVE 'SS18800002'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE
               GO TO 9200-MOVE-RECORD-TO-MIR-X
           END-IF.

           MOVE RFV-FND-ID
             TO MIR-FND-ID-T (WS-LIST-IDX).

           MOVE RFV-FNDVL-UNIT-TYP-CD
             TO MIR-FNDVL-UNIT-TYP-CD-T (WS-LIST-IDX).

           MOVE RFV-SELL-PRIC-AMT     TO L0290-INPUT-V09.
           MOVE +9                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-SELL-PRIC-AMT-T (WS-LIST-IDX)
                                      TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-SELL-PRIC-AMT-T (WS-LIST-IDX).

           MOVE RFV-PURCH-PRIC-AMT    TO L0290-INPUT-V09.
           MOVE +9                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PURCH-PRIC-AMT-T (WS-LIST-IDX)
                                      TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-PURCH-PRIC-AMT-T (WS-LIST-IDX).

           MOVE RFV-FNDVL-CHNG-IND
             TO MIR-FNDVL-CHNG-IND-T (WS-LIST-IDX).

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                     TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE         TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE MIR-OUTPUT-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           COMPUTE WS-LIST-SIZE = LENGTH OF MIR-FND-ID-G
                                / LENGTH OF MIR-FND-ID-T (1).

025970     SET WS-TWRK-KEY-DEFAULT      TO TRUE.
025970
       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  FH
                                '$VAR2'   BY 'FH'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL8090.

       COPY XCPL0260.


025970 COPY XCPS8090.
025970 COPY XCPS1640.
       COPY XCPL1640.

025970 COPY XCPS1660.
       COPY XCPL1660.

       COPY XCPL0290.
       COPY XCPS0290.

      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY SCPNFH.
       COPY SCPUFH.

       COPY SCPBFVAA.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM SSOM1880                        **
      *****************************************************************
