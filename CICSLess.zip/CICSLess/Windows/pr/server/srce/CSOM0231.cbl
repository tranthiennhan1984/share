      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM0231.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0231                                         **
      **  REMARKS:  THIS MODULE PERFORMS CREATE FUNCTION             **
      **            FOR THE CHTX TABLE                               **
      **                                                             **
      **  DOMAIN :  AC                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
016457**  6.2       NEW                                              **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0231'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                           PIC X(04).
               88  WS-BUS-FCN-CREATE                   VALUE '0231'.
           05  WS-CHQ-DT                               PIC X(10).

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFRCHTX.
021930*COPY CCFWCHTX.
       COPY CCFWCHTD.
      /
       COPY CCFWSCOM.
       COPY CCFRSCOM.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
018764*COPY XCWLPTR.
       COPY XCWL1640.
       COPY XCWLDTLK.
      /
       COPY CCWLPGA.
       COPY CCWL5271.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM0231.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-CREATE
                        THRU 2000-CREATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0231'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *---------------
       2000-CREATE.
      *---------------

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > 0
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               PERFORM  9000-BLANK-DATA-FIELDS
                   THRU 9000-BLANK-DATA-FIELDS-X
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  CHTD-1000-READ
               THRU CHTD-1000-READ-X.

           IF  WCHTD-IO-OK
      *MSG: 'RECORD @1 ALREADY EXISTS'
               MOVE WCHTD-KEY
                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-CREATE-X
           END-IF.

           PERFORM  5271-1000-BUILD-PARM-INFO
               THRU 5271-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CHQ-ID                  TO L5271-CHQ-ID.
           MOVE MIR-SBSDRY-CO-ID            TO L5271-ACCT-SBSDRY-CO-ID.
           MOVE WS-CHQ-DT                   TO L5271-CHQ-DT.
           SET L5271-CHQ-STAT-NO-DATA       TO TRUE.
           SET L5271-CHQ-TYP-MANL           TO TRUE.

           PERFORM  5271-1000-WRITE-CHQ
               THRU 5271-1000-WRITE-CHQ-X.

       2000-CREATE-X.
           EXIT.

      *---------------------------
       2100-VALIDATE-KEYS.
      *---------------------------

           PERFORM  2110-EDIT-CHQ-DT
               THRU 2110-EDIT-CHQ-DT-X.

           PERFORM  2120-EDIT-SBSDRY-CO-ID
               THRU 2120-EDIT-SBSDRY-CO-ID-X.


       2100-VALIDATE-KEYS-X.
           EXIT.

      *-------------------
       2110-EDIT-CHQ-DT.
      *-------------------

           MOVE MIR-CHQ-DT                TO L1640-EXTERNAL-DATE.
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
               MOVE WWKDT-LOW-DT          TO WS-CHQ-DT
      *MSG: INVALID DATE
               MOVE 'CS02310103'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2110-EDIT-CHQ-DT-X
           ELSE
               MOVE L1640-INTERNAL-DATE   TO WS-CHQ-DT
           END-IF.

           IF  WS-CHQ-DT > WGLOB-PROCESS-DATE
      *MSG: CHEQUE ISSUE DATE CANNOT BE IN THE FUTURE
               MOVE 'CS02310104'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.


       2110-EDIT-CHQ-DT-X.
           EXIT.


      *-----------------------
       2120-EDIT-SBSDRY-CO-ID.
      *-----------------------

           MOVE MIR-SBSDRY-CO-ID            TO WSCOM-SBSDRY-CO-ID.
           PERFORM  SCOM-1000-READ
               THRU SCOM-1000-READ-X.
           IF  NOT WSCOM-IO-OK
      *MSG: SUB CO DOES NOT EXIST
               MOVE 'CS02310102'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2120-EDIT-SBSDRY-CO-ID-X.
           EXIT.

      *---------------------------
       7000-BUILD-KEYS.
      *---------------------------

           MOVE MIR-CHQ-ID                  TO WCHTD-CHQ-ID.
           MOVE MIR-SBSDRY-CO-ID            TO WCHTD-SBSDRY-CO-ID.
           MOVE WS-CHQ-DT                   TO WCHTD-CHQ-DT.

       7000-BUILD-KEYS-X.
           EXIT.

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5271-0000-INIT-PARM-INFO
025970         THRU 5271-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  WS-WORKING-STORAGE.
025970
025970     MOVE SPACES TO  WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
       COPY CCPS5271.
018764*COPY CCCL5271.
018764 COPY CCPL5271.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
021930*COPY CCPCCHTX.
021930*COPY CCPACHTX.
       COPY CCPNCHTD.
      /
       COPY CCPNSCOM.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0231
      *****************************************************************
