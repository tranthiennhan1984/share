      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7355.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7355                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE PRIMARY INSURED         **
      **            RETRIEVAL FUNCTION                               **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
026055**  6.6       INTEREST ON DELAYED DEATH CLAIMS                 **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7355'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                          PIC X(04).
               88  WS-BUS-FCN-RETRIEVE                VALUE '7355'.
           05  WS-CVG-NUM                             PIC S9(02) BINARY.
           05  WS-CVGC-CTR                            PIC S9(04) BINARY.
           05  WS-CLI-ID                              PIC X(10).
           05  WS-MULT-INSURED-SW                     PIC X(01).
               88  WS-MULT-INSURED-YES                VALUE 'Y'.
               88  WS-MULT-INSURED-NO                 VALUE 'N'.

      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWLOCK.
       COPY CCWWINDX.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRCVG.
       COPY CCFWCVG.

       COPY CCFRPOL.
       COPY CCFWPOL.

       COPY CCFRCVGC.
       COPY CCFWCVGC.

       COPY CCWWCVGS.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
       COPY CCWL2430.
028298 COPY CCWL2626.

       COPY XCWL0280.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7355.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  TIMR-6000-MAIN-ENTRY-TIME
               THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

           PERFORM  TIMR-7000-MAIN-EXIT-TIME
               THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7355'           TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *--------------
       2000-RETRIEVE.
      *--------------

      * VALIDATE KEY INFO

           PERFORM  8000-EDIT-INFO
               THRU 8000-EDIT-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED    TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

      * INITIALIZE OUTPUT FIELDS

           PERFORM  8100-BLANK-DATA-FIELDS
               THRU 8100-BLANK-DATA-FIELDS-X.

      * CALL CSDU2430 TO RETRIEVE PRIMARY CLIENT ID

           MOVE WS-CVG-NUM                  TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-3100-GET-PRIM-INSRD
               THRU 2430-3100-GET-PRIM-INSRD-X.

           IF  NOT L2430-RETRN-OK
           OR  L2430-RELATIONSHIP-FOUND-NO
      *MSG: NO CLIENT RECORD FOUND
               MOVE 'CS73550001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-RETRIEVE-X
           END-IF.

           MOVE L2430-CLI-ID          TO MIR-CLI-ID.

      * CHECK WHETHER MULTIPLE INSUREDS EXIST

           PERFORM  2100-CHECK-MULT-INSURED
               THRU 2100-CHECK-MULT-INSURED-X.

       2000-RETRIEVE-X.
           EXIT.

      *------------------------
       2100-CHECK-MULT-INSURED.
      *------------------------

           IF  WS-CVG-NUM = ZERO
               PERFORM  7000-BUILD-POL-BROWSE-KEY
                   THRU 7000-BUILD-POL-BROWSE-KEY-X
           ELSE
               PERFORM  7010-BUILD-CVG-BROWSE-KEY
                   THRU 7010-BUILD-CVG-BROWSE-KEY-X
           END-IF.

           PERFORM  CVGC-1000-BROWSE
               THRU CVGC-1000-BROWSE-X.

           PERFORM  CVGC-2000-READ-NEXT
               THRU CVGC-2000-READ-NEXT-X.

           IF  WCVGC-IO-EOF
               PERFORM  CVGC-3000-END-BROWSE
                   THRU CVGC-3000-END-BROWSE-X
               GO TO 2100-CHECK-MULT-INSURED-X
           END-IF.

      * CHECK WHETHER MORE THAN ONE INSURED

           MOVE ZERO                   TO WS-CVGC-CTR.
           SET WS-MULT-INSURED-NO      TO TRUE.

           PERFORM  2110-MULT-INSURED-LOOP
               THRU 2110-MULT-INSURED-LOOP-X
               UNTIL WCVGC-IO-EOF
                  OR WS-MULT-INSURED-YES.

           PERFORM  CVGC-3000-END-BROWSE
               THRU CVGC-3000-END-BROWSE-X.

           IF  WS-MULT-INSURED-YES
      *MSG: 'POLICY/COVERAGE HAS MULTIPLE INSUREDS.  FUTHER REVIEW OF
      *      OTHER INSUREDS MAY BE REQUIRED.
               MOVE 'CS73550003'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2100-CHECK-MULT-INSURED-X.
           EXIT.

      *-----------------------
       2110-MULT-INSURED-LOOP.
      *-----------------------

           ADD +1                      TO WS-CVGC-CTR.

           IF  WS-CVGC-CTR > 1
           AND RCVGC-INSRD-CLI-ID NOT = WS-CLI-ID
               SET WS-MULT-INSURED-YES TO TRUE
               GO TO 2110-MULT-INSURED-LOOP-X
           END-IF.

           MOVE RCVGC-INSRD-CLI-ID     TO WS-CLI-ID.

           PERFORM  CVGC-2000-READ-NEXT
               THRU CVGC-2000-READ-NEXT-X.

       2110-MULT-INSURED-LOOP-X.
           EXIT.

      *--------------------------
       7000-BUILD-POL-BROWSE-KEY.
      *--------------------------

           MOVE LOW-VALUES       TO WCVGC-KEY.
           MOVE RPOL-POL-ID      TO WCVGC-POL-ID.

           MOVE WCVGC-KEY        TO WCVGC-ENDBR-KEY.
           MOVE HIGH-VALUES      TO WCVGC-ENDBR-CVG-NUM.
           MOVE HIGH-VALUES      TO WCVGC-ENDBR-CVG-CLI-REL-TYP-CD.
           MOVE HIGH-VALUES      TO WCVGC-ENDBR-INSRD-CLI-ID.

       7000-BUILD-POL-BROWSE-KEY-X.
           EXIT.

      *--------------------------
       7010-BUILD-CVG-BROWSE-KEY.
      *--------------------------

           MOVE LOW-VALUES       TO WCVGC-KEY.
           MOVE RPOL-POL-ID      TO WCVGC-POL-ID.
           MOVE WS-CVG-NUM       TO WCVGC-CVG-NUM-N.

           MOVE WCVGC-KEY        TO WCVGC-ENDBR-KEY.
           MOVE HIGH-VALUES      TO WCVGC-ENDBR-CVG-CLI-REL-TYP-CD.
           MOVE HIGH-VALUES      TO WCVGC-ENDBR-INSRD-CLI-ID.

       7010-BUILD-CVG-BROWSE-KEY-X.
           EXIT.

      *---------------
       8000-EDIT-INFO.
      *---------------

      * VALIDATE KEY INFOMATION

           PERFORM  8010-EDIT-KEY-INFO
               THRU 8010-EDIT-KEY-INFO-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8000-EDIT-INFO-X
           END-IF.

       8000-EDIT-INFO-X.
           EXIT.

      *-------------------
       8010-EDIT-KEY-INFO.
      *-------------------
      *
      * VALIDATE POL NUMBER
      *
           MOVE MIR-POL-ID-BASE            TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX             TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD (@1) NOT FOUND
               MOVE 'XS00000001'           TO WGLOB-MSG-REF-INFO
               MOVE WPOL-POL-ID            TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8010-EDIT-KEY-INFO-X
           END-IF.
      *
      *  VALIDATE COVERAGE NUMBER
      *
           IF  MIR-CVG-NUM = SPACES
               MOVE ZERO                   TO WS-CVG-NUM
               GO TO 8010-EDIT-KEY-INFO-X
           END-IF.

           SET L0280-SIGN-NOT-PERMITTED    TO TRUE.
           MOVE ZERO                       TO L0280-PRECISION.
           MOVE 2                          TO L0280-LENGTH.
           MOVE 2                          TO L0280-INPUT-SIZE.
           MOVE MIR-CVG-NUM                TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  NOT L0280-OK
      *MSG:     'COVERAGE NUMBER MUST BE VALID NUMERIC OR SPACES'
               MOVE 'CS73550002'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8010-EDIT-KEY-INFO-X
           ELSE
               MOVE L0280-OUTPUT           TO WS-CVG-NUM
           END-IF.
      *
      * LOAD WCVGS ARRAY
      *
           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 8010-EDIT-KEY-INFO-X
           END-IF.

       8010-EDIT-KEY-INFO-X.
           EXIT.

      *-----------------------
       8100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       8100-BLANK-DATA-FIELDS-X.
           EXIT.
      /

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.
           MOVE MIR-POL-ID-BASE          TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX           TO WGLOB-REF-POLICY-SUFFIX.
           SET WGLOB-REF-POLICY          TO TRUE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           PERFORM  0280-0000-INIT-PARM-INFO
               THRU 0280-0000-INIT-PARM-INFO-X.

           PERFORM  2430-0000-INIT-PARM-INFO
               THRU 2430-0000-INIT-PARM-INFO-X.

028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
           INITIALIZE WS-WORKING-STORAGE.
           INITIALIZE FREQUENTLY-USED-INDICES.

           SET MIR-RETRN-OK          TO TRUE.

           MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
       COPY XCPSTIMR.
       COPY XCCPTIMR.

       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY NCPPCVGS.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY CCPS2430.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL2430.

       COPY XCPL0260.
       COPY XCPS0280.
       COPY XCPL0280.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.

       COPY CCPNCVG.

       COPY CCPBCVGC.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
       COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM7355                     **
      *****************************************************************
