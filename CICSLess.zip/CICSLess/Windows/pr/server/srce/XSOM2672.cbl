      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSOM2672.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  XSOM2672                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE RECORD UPDATE FUNCTION  **
      **            FOR THE TOKN TABLE                               **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
025244**  6.6       ADDED STANDARD MESSAGE                           **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSOM2672'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                         PIC X(04).
               88  WS-BUS-FCN-UPDATE                 VALUE '2672'.
025970*    05  WS-TWRK-KEY                           PIC X(04)
025970*                                              VALUE '2672'.
           05  WS-TOKEN-PGM-ID                       PIC X(08).
           05  WS-TOKEN-PGM-ID-R                     REDEFINES
               WS-TOKEN-PGM-ID.
               10  WS-TOKEN-PGM-NAME.
                   15  WS-TOKEN-PGM-SUB-SYS          PIC X(01).
                   15  WS-TOKEN-PGM-NAME-CHK         PIC X(03).
                       88  WS-TOKEN-PGM-NAME-VALID   VALUE 'SDP'.
               10  WS-TOKEN-PGM-NUMBER               PIC X(04).

025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                           PIC X(04).  
025970         88  WS-TWRK-KEY-DEFAULT               VALUE '2672'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWEBLCH.
       COPY XCWL8090.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY XCFWTOKN.
       COPY XCFRTOKN.
       COPY CCWWLOCK.
      /
       COPY XCFRXTAB.
       COPY XCFWXTAB.
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL0280.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY XCWM2672.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*           MOVE MIR-BUS-FCN-ID
025970*             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'XSOM2672'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *------------
       2000-UPDATE.
      *------------
      *
      *  THE RECORD MUST EXIST, AND HAVE A CURRENT TIMESTAMP
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.
    
           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               PERFORM  9000-BLANK-DATA-FIELDS
                   THRU 9000-BLANK-DATA-FIELDS-X
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  TOKN-2000-UPDATE-TWRK-TS
               THRU TOKN-2000-UPDATE-TWRK-TS-X.

           IF  WTOKN-IO-NOT-FOUND
      *MSG: 'LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS'
               MOVE WTOKN-KEY
                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000006'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

           IF MIR-RETRN-TS-MISMATCH
      *MSG: 'PROCESS FAILED - RE-ENTER DATA AS ANOTHER PROCESS HAS
      *      UPDATED - TABLE (@1), KEY @2' 
              MOVE 'XS00000303'  
                TO WGLOB-MSG-REF-INFO
              MOVE 'TOKN' 
                TO WGLOB-MSG-PARM (1) 
              MOVE WTOKN-KEY
                TO WGLOB-MSG-PARM (2)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 2000-UPDATE-X
           END-IF.

      *
      *
      *  EDIT THE DATA ENTERED FOR THE RECORD CHANGES
      *

           PERFORM  8000-EDITS
               THRU 8000-EDITS-X.

           IF  WGLOB-MSG-ERROR-SW = ZERO
               PERFORM  9200-MOVE-RECORD-TO-MIR
                   THRU 9200-MOVE-RECORD-TO-MIR-X
           ELSE
               SET MIR-RETRN-EDIT-ERROR
                 TO TRUE
           END-IF.

           PERFORM  TOKN-2000-REWRITE
               THRU TOKN-2000-REWRITE-X.

      *  UPDATE TIMESTAMP FOR LOGICAL LOCKING

           PERFORM  TOKN-1000-READ-TWRK-TS
               THRU TOKN-1000-READ-TWRK-TS-X.

025244*MSG: 'MAINTENANCE COMPLETED - CONTINUE'
025244     MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO.
025244     PERFORM  0260-1000-GENERATE-MESSAGE
025244         THRU 0260-1000-GENERATE-MESSAGE-X.
025244
       2000-UPDATE-X.
           EXIT.
      /
      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------
       
           PERFORM  4110-EDIT-TOKN-ID
               THRU 4110-EDIT-TOKN-ID-X.

       2100-VALIDATE-KEYS-X.
           EXIT.
      /
      *------------------
       4110-EDIT-TOKN-ID.
      *------------------

      *
      *
      * TOKEN ID IS VALIDATED AGAINST THE XTAB TABLE
      *
           
           MOVE MIR-TOKEN-ID          TO WXTAB-ETBL-VALU-ID.
           
           PERFORM  TOKN-1000-EDIT-TOKEN-ID
               THRU TOKN-1000-EDIT-TOKEN-ID-X.
           
           IF WXTAB-IO-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
      *        MSG: INVALID TOKENN ID - CHECK XTAB TYPE 'TOKEN'
               MOVE 'XS26720001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4110-EDIT-TOKN-ID-X
           END-IF.

       4110-EDIT-TOKN-ID-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------
           
           MOVE LOW-VALUES             TO WTOKN-KEY.
           MOVE MIR-TOKEN-ID           TO WTOKN-TOKEN-ID.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------
       8000-EDITS.
      *-----------
      
           PERFORM  8100-EDIT-PROGRAM-ID
               THRU 8100-EDIT-PROGRAM-ID-X.

       8000-EDITS-X.
           EXIT.
      /
      *---------------------
       8100-EDIT-PROGRAM-ID.
      *---------------------

           IF  MIR-TOKEN-PGM-ID = SPACES
           OR  MIR-TOKEN-PGM-ID = EBLCH-BLANK-FIELD-CHAR
      *MSG:   'TOKEN REPLACEMENT PROGRAM NAME MUST BE ENTERED'
               MOVE 'XS26720002'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8100-EDIT-PROGRAM-ID-X
           END-IF.
      
           MOVE MIR-TOKEN-PGM-ID         TO WS-TOKEN-PGM-ID.
      
           IF  NOT WS-TOKEN-PGM-NAME-VALID
      *MSG:   'INVALID TOKEN REPLACEMENT PROGRAM NAME (@1) ENTERED'
               MOVE MIR-TOKEN-PGM-ID     TO WGLOB-MSG-PARM (1)
               MOVE 'XS26720003'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8100-EDIT-PROGRAM-ID-X
           END-IF.
      
           SET L0280-SIGN-NOT-PERMITTED  TO TRUE.
           MOVE ZERO                     TO L0280-PRECISION.
           MOVE LENGTH OF WS-TOKEN-PGM-NUMBER
                                         TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE         TO L0280-LENGTH.
           MOVE WS-TOKEN-PGM-NUMBER      TO L0280-INPUT-DATA.
      
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
      
           IF  NOT L0280-OK
      *MSG:   'INVALID TOKEN REPLACEMENT PROGRAM NAME (@1) ENTERED'
               MOVE MIR-TOKEN-PGM-ID     TO WGLOB-MSG-PARM (1)
               MOVE 'XS26720003'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8100-EDIT-PROGRAM-ID-X
           ELSE
               MOVE MIR-TOKEN-PGM-ID     TO RTOKN-TOKEN-PGM-ID
           END-IF.

       8100-EDIT-PROGRAM-ID-X.
           EXIT.
      /
      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES         TO MIR-TOKEN-ID.
           MOVE SPACES         TO MIR-TOKEN-PGM-ID.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *------------------------
       9200-MOVE-RECORD-TO-MIR.
      *------------------------

           MOVE RTOKN-TOKEN-ID         TO MIR-TOKEN-ID.
           MOVE RTOKN-TOKEN-PGM-ID     TO MIR-TOKEN-PGM-ID.
       
       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE          WS-WORKING-STORAGE.
           
025970     MOVE MIR-BUS-FCN-ID
025970       TO WS-BUS-FCN-ID.
025970     SET  WS-TWRK-KEY-DEFAULT       TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  TOKN
                                '$VAR2'   BY 'TOKN'.
       COPY XCPL8090.
       COPY XCPEDBRI.
       COPY XCPETOKN.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY XCPNTOKN.
       COPY XCPUTOKN.
      /
       COPY XCPNXTAB. 
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM 'XSOM2672'                   **
      *****************************************************************
