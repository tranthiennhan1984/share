      *------------------------
       IDENTIFICATION DIVISION.
      *------------------------
      *
       COPY XCWWCRHT.
      *
       PROGRAM-ID. SSOM0070.
      *
      *****************************************************************
      **  MEMBER :  SSOM0070                                         **
      **  REMARKS:  FTRS - PROCESS SEGREGATED FUND TRANSFERS         **
      **                                                             **
      **            THIS MODULE IS USED TO PROCESS SEGREGATED        **
      **            FUND TRANSFERS. THERE ARE THREE METHODS          **
      **            OF ALLOCATING THE TRANSFER FROM ONE FUND         **
      **            TO THE OTHER: AMOUNT TO AMOUNT; AMOUNT           **
      **            TO PERCENTAGE ALLOCATIONS; AND FUND              **
      **            PERCENTAGES TO PERCENTAGE ALLOCATIONS.           **
      **            LOADS CAN EITHER BE FORCED BY THE USER           **
      **            OR CALCULATED BY THE MODULE.                     **
      **                                                             **
      **  DOMAIN :  CV                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP                                     **
557701**  5.5       UNDO/REDO FOR SEGFUNDS                           **
557708**  5.5       CICS ABEND PROCESSING                            **
557756**  5.5       ENHANCED MULTIPLE LANGUAGE SUPPORT               **
557973**  5.5       AMOUNT FIELD SIZE CHANGES FOR INTERNATIONAL      **
008453**  5.5.2     MULTIPLE EXTERNAL DATE FORMATS                   **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
005198**  5.6V      FIXED CHG FUNCTIONALITY OF VERIFY STEP(PCR)      **
012134**  5.6V      TAXATION OF VARIABLE UL AND VAR ANNUITIES        **
012137**  5.6V      SEC CONFIRMATION STATEMENTS                      **
012141**  5.6V      PORTFOLIO EXPANSION                              **
012146**  5.6V      MORTALITY & EXPENSE CHARGES                      **
012696**  5.6V      DEFER TRANSFER IF UNIT PRICES NOT AVAILABLE      **
014035**  5.6V      CODE CLEANUP & STANDARDIZATION                   **
012624**  6.0       GLOBAL SECURITY CHANGES                          **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
016194**  6.1       NEGATIVE PERCENT FOR TRANSFER OUT FUNDS          **
014221**  6.2       LOGICAL LOCKING                                  **
016392**  6.2       FIX DEFERRED TRANSFER AMOUNT TO AMOUNT           **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016503**  6.2       SCHEDULING ENHANCEMENTS                          **
016537**  6.2       CODE CLEAN UP                                    **
016605**  6.2       CLEAR TWRK BEFORE CREATING A NEW ONE             **
017427**  6.2       HANDLE INVALID POLICIES                          **
016108**  6.3       CLIENT DEATH NOTIFICATION (6.1.2J)               **
016109**  6.3       FREE FUND TRANSFERS (6.1.2J)                     **
016326**  6.3       FIX ABENDS ON POLICY ERRORS                      **
016652**  6.3       FIX ALLOCATE WITH CHARGE PROBLEM AFTER UNDO      **
018763**  6.3       CODE CLEAN-UP AND STANDARDIZATION                **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019549**  6.4       CHANGE EDIT FOR TRANSFER FROM AMOUNT             **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020906**  6.4       REMOVAL OF UNUSED FIELDS FROM GLOBAL AREA        **
021311**  6.4       MULTI-PLATFORM SUPPORT                           **
020464**  6.4       FUND MGMT PROCESSING FOR PENDING & DEFER ACTIVITY**
020463**  6.4       INVESTOR PROFILES                                **
020467**  6.4       TWO STAGE AUTOPAY PROCESSING                     **
020469**  6.4       MULTI-CURRENCY FUND PROCESSING                   **
019573**  6.4       WRITE CDSA RECORDS FOR ALL TYPES OF ACTIVITY     **
021239**  6.4       FUND UNIT VALUE                                  **
023112**  6.5       CASH FLOW DESTINATION INSTRUCTIONS               **
025388**  6.6       DATABASE CLEANUP                                 **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
023629**  6.7       TRANSFER OUT PERCENTAGE TRUNCATED                **
032329**  7.0       99 COVERAGES AND 98 FUNDS HANDLING               **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
*****************************************************************

       ENVIRONMENT DIVISION.
      *---------------------
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM0070'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      *

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
013578 COPY XCWL8090.

007766 COPY XCWWCVGM.
012141 COPY XCWWFNDM.
014221 COPY CCWWLOCK.

       01  WS-PGM-WORK-AREA.
025970*    05  REQUEST-NAME      PIC X(14)  VALUE 'FUND TRANSFERS'.
      *
013578     05  WS-BUS-FCN-ID                    PIC X(04).
013578         88  WS-BUS-FCN-VALID             VALUE '1770'
013578                                                '1771'
013578                                                '1772'.
013578         88  WS-BUS-FCN-AMTAMT            VALUE '1770'.
013578         88  WS-BUS-FCN-AMTPCT            VALUE '1771'.
013578         88  WS-BUS-FCN-PCTPCT            VALUE '1772'.
025970*    05  WS-TWRK-KEY                      PIC X(04)
025970*                                         VALUE '1770'.
020469     05  WS-POL-CRCY-CD                   PIC X(02)
020469                                          VALUE SPACES.
020469     05  WS-REQIR-CNVR-AMT                PIC S9(13)V9(02)
020469                                          COMP-3.
025970 01  WS-CONSTANTS.
025970     05  REQUEST-NAME                 PIC X(14).
025970         88  REQUEST-NAME-DEFAULT     VALUE 'FUND TRANSFERS'.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '1770'.

       01  WS-TWRK-FIELDS.
013578     05  WS-TWRK-WORK-AREA.
013578         COPY SCWWPDTQ.
032329*        10  WS-TWRK-TAMT                 OCCURS 25
032329         10  WS-TWRK-TAMT                 OCCURS 98
018763                                          PIC S9(15)V99.


       01  HEADER-MISC-WORK-AREAS.
008453     05  EDATE-HOLD                       PIC X(10).
           05  KEY-HOLD.
               10  HOLD-POL-ID-BASE             PIC X(9).
               10  HOLD-POL-ID-SFX              PIC X.
               10  COV-HOLD                     PIC 99.
               10  COV-HOLD-R REDEFINES COV-HOLD.
                   15  COV-HOLD-EDIT-1          PIC X.
                   15  COV-HOLD-EDIT-2          PIC X.
           05  CLEAR-SW                         PIC 99.
               88  CLEAR-SW-ON                      VALUE 1.
           05 FTRS-CALL-SW                      PIC 9.
               88  FTRS-NO-CALL                     VALUE 0.
               88  FTRS-DO-CALL                     VALUE 1.
           05 AMOUNT-EDIT-FROM-SW               PIC 9.
               88  NO-AMOUNT-FROM-ERROR             VALUE 0.
               88  AMOUNT-FROM-ERROR                VALUE 1.
           05 AMOUNT-EDIT-TO-SW                 PIC 9.
               88  NO-AMOUNT-TO-ERROR               VALUE 0.
               88  AMOUNT-TO-ERROR                  VALUE 1.
           05 PERCNT-EDIT-FROM-SW               PIC 9.
               88  NO-PERCNT-FROM-ERROR             VALUE 0.
               88  PERCNT-FROM-ERROR                VALUE 1.
           05 PERCNT-EDIT-TO-SW                 PIC 9.
               88  NO-PERCNT-TO-ERROR               VALUE 0.
               88  PERCNT-TO-ERROR                  VALUE 1.
019549*    05 AMOUNT-COMPARE-SW                 PIC 9.
019549*        88  NO-AMOUNT-COMPARE-ERROR          VALUE 0.
019549*        88  AMOUNT-COMPARE-ERROR             VALUE 1.
           05 TO-FROM-ERROR-SW                  PIC 9.
               88  NO-TO-FROM-ERROR                 VALUE 0.
               88  TO-FROM-ERROR                    VALUE 1.
           05 FROM-AMOUNT-ERROR-SW              PIC 9.
               88  NO-FROM-AMOUNT-ERROR             VALUE 0.
               88  FROM-AMOUNT-ERROR                VALUE 1.
           05 TO-AMOUNT-ERROR-SW                PIC 9.
               88  NO-TO-AMOUNT-ERROR               VALUE 0.
               88  TO-AMOUNT-ERROR                  VALUE 1.
           05 FROM-PERCNT-ERROR-SW              PIC 9.
               88  NO-FROM-PERCNT-ERROR             VALUE 0.
               88  FROM-PERCNT-ERROR                VALUE 1.
           05 TO-PERCNT-ERROR-SW                PIC 9.
               88  NO-TO-PERCNT-ERROR               VALUE 0.
               88  TO-PERCNT-ERROR                  VALUE 1.
           05 TRANSFER-TYPE-SW                  PIC 9.
               88  AMOUNT-TO-AMOUNT                 VALUE 0.
               88  AMOUNT-TO-PERCNT                 VALUE 1.
               88  PERCNT-TO-PERCNT                 VALUE 2.
557701     05  WS-REBUILD-AFTER-UNDO-SW         PIC X(01).
557701         88  WS-REBUILD-AFTER-UNDO-NO         VALUE 'N'.
557701         88  WS-REBUILD-AFTER-UNDO-YES        VALUE 'Y'.
016503     05  WS-REBUILD-AFTER-REDO-SW         PIC X(01).
016503         88  WS-REBUILD-AFTER-REDO-NO     VALUE 'N'.
016503         88  WS-REBUILD-AFTER-REDO-YES    VALUE 'Y'.
016503     05  WS-REDO-SWITCH          PIC X(01).
016503         88  WS-REDO-OK          VALUE 'Y'.
016503         88  WS-REDO-NOT-OK      VALUE 'N'.

557660 01  WS-INPUT-AREA.
557973     05  WS-ALLOC-NUM                     PIC S9(13)V9(4) COMP-3.
557973     05  WS-INPUT-AMOUNT                  PIC S9(15)V99 COMP-3.
023629*    05  WS-INPUT-PCNT                    PIC S9(03)V9(04) COMP-3.
023629     05  WS-INPUT-PCNT                    PIC S9(05)V9(04) COMP-3.
557660     05  WS-DV-FND-CTR-HOLD.
557660         10  WS-DV-FND-CTR-HOLD-N               PIC 9(03).
           05  WS-PCNT-HOLD.
               10  WS-PCNT-HOLD-N   PIC 999.9999.
557701*
557701 COPY CCFHPOL.
      *
       COPY CCWWINDX.
       COPY XCWLDTLK.
       COPY XCWL1640.
      *
020478 COPY CCWL2626.
013578 COPY CCWL0620.
      *
016108 COPY CCWL0985.
016108*
       COPY CCWL2430.
      *
019573 COPY CCWL2600.
      *
557701*
557701 COPY CCWL4750.
012696*
012696 COPY FCWL8170.
012696 COPY FCWLFUND.
      *
020463 COPY CCWL2735.
020463/
       COPY CCWL5400.
      *
016503 COPY CCWL0201.
016503*
016503 COPY CCWL0289.
016503*
016503 COPY CCWL4780.
016503*
       COPY SCWLSEGF.
      *
       COPY SCWL0410.
      *
       COPY SCWL0500.
      *
012137 COPY SCWL6330.
012137*
       COPY SCWL6350.
      *
       COPY XCWL0280.
      *
008455 COPY XCWL0290.
008455*
013578*COPY XCWL2510.
013578*
020469 COPY XCWL8640.
      *
020469 COPY XCWL8695.
      *
012696 COPY XCWWWKDT.
      *
      *****************************************************************
      * I/O COPYBOOKS
      *****************************************************************

       COPY CCFWCVG.
       COPY CCFRCVG.
      *
       COPY CCFWPOL.
      *
       COPY SCFRFA.
      *
       COPY SCFRFD.
      *
       COPY SCFRFC.
      *
       COPY SCFRFS.
      *
      ******************************************************************
      ** INPUT PARAMETER
      ******************************************************************
      *
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      *
      ******************
       LINKAGE SECTION.
      ******************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY SCWM0070.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

021311     PERFORM  9990-INIT-WORKING-STORAGE
021311         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.
008455
008455     PERFORM  0290-1000-BUILD-PARM-INFO
008455         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  0500-PROCESS-REQUEST
               THRU 0500-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.


026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      *--------------------------
       0500-PROCESS-REQUEST.
      *--------------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           PERFORM  0510-INIT-REQUESTS
               THRU 0510-INIT-REQUESTS-X.

021311*    SET FTRS-NO-CALL TO TRUE.
021311*    SET WS-REBUILD-AFTER-UNDO-NO  TO TRUE.

025970*    MOVE MIR-BUS-FCN-ID           TO WS-BUS-FCN-ID.
013578     IF  NOT WS-BUS-FCN-VALID
013578         SET MIR-RETRN-INVALD-RQST TO TRUE
013578         GO TO 0500-PROCESS-REQUEST-X
013578     END-IF.
013578
           PERFORM  1000-SET-UP-INPUT
               THRU 1000-SET-UP-INPUT-X.

016503     SET WS-REDO-OK                TO TRUE.
013578     PERFORM  1100-PROCESS-REQUESTS-PHASE
013578         THRU 1100-PROCESS-REQUESTS-PHASE-X.

016503     IF  WS-REDO-NOT-OK
017427     OR  WGLOB-RETURN-ERROR
016503         GO TO 0500-PROCESS-REQUEST-X
016503     END-IF.

           IF  FTRS-DO-CALL
               PERFORM  1200-CALL-FTRS
                   THRU 1200-CALL-FTRS-X
           END-IF.

016326     IF  WGLOB-MSG-ERROR-SW NOT > ZERO
               PERFORM  1300-FORMAT-OUTPUT-SCREEN
                   THRU 1300-FORMAT-OUTPUT-SCREEN-X
016326     END-IF.

       0500-PROCESS-REQUEST-X.
           EXIT.
      *
      *----------------
       0510-INIT-REQUESTS.
      *----------------

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM 6350-1000-BUILD-PARM-INFO
              THRU 6350-1000-BUILD-PARM-INFO-X.

       0510-INIT-REQUESTS-X.
           EXIT.
      *
      *------------------
       1000-SET-UP-INPUT.
      *------------------

           MOVE ZERO                  TO WGLOB-MSG-ERROR-SW.
           MOVE ZERO                  TO CLEAR-SW.

           PERFORM  1050-MOVE-SCREEN-TO-WS
               THRU 1050-MOVE-SCREEN-TO-WS-X.

       1000-SET-UP-INPUT-X.
           EXIT.
      *
      *------------------------
       1050-MOVE-SCREEN-TO-WS.
      *------------------------

           PERFORM  1051-MOVE-TOP-TO-WS
               THRU 1051-MOVE-TOP-TO-WS-X.

557660     IF  MIR-DV-PRCES-STATE-CD = '1'
               GO TO 1050-MOVE-SCREEN-TO-WS-X
           ELSE
               INITIALIZE WS-INPUT-AREA
               PERFORM  1052-MOVE-SCREEN-TO-WS
                   THRU 1052-MOVE-SCREEN-TO-WS-X
                   VARYING I FROM 1 BY 1
012141             UNTIL I > WFNDM-MAX-WFUND-NUM
           END-IF.

       1050-MOVE-SCREEN-TO-WS-X.
           EXIT.
      *
      *--------------------
       1051-MOVE-TOP-TO-WS.
      *--------------------

013578     EVALUATE TRUE
013578
013578         WHEN WS-BUS-FCN-AMTAMT
013578             MOVE 'A'           TO L6350-ALLOC-CD
013578
013578         WHEN WS-BUS-FCN-AMTPCT
013578             MOVE 'B'           TO L6350-ALLOC-CD
013578
013578         WHEN WS-BUS-FCN-PCTPCT
013578             MOVE 'C'           TO L6350-ALLOC-CD
013578
013578     END-EVALUATE.

           MOVE MIR-POL-ID-BASE       TO HOLD-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO HOLD-POL-ID-SFX.
           MOVE MIR-CVG-NUM           TO COV-HOLD-R.
           MOVE KEY-HOLD              TO LSEGF-INV-CVG-REST-KEY-INFO.
012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L6330-SUPPRESS-CONFIRM
012137                                TO TRUE
012137     END-IF.
           MOVE MIR-CIA-EFF-DT        TO EDATE-HOLD.

       1051-MOVE-TOP-TO-WS-X.
           EXIT.
      *
      *----------------------
       1052-MOVE-SCREEN-TO-WS.
      *----------------------
      *
      *  MIR FIELDS ARE NOW A TABLE AND THIS PARAGRAPH IS PERFORMED
      *  IN A LOOP
      *
557660     IF MIR-DV-FND-CTR-T (I) > SPACES
557660         MOVE MIR-DV-FND-CTR-T (I)    TO WS-DV-FND-CTR-HOLD
557660         MOVE WS-DV-FND-CTR-HOLD-N    TO L6350-FUND-NUM (I)
557660     END-IF.

           MOVE MIR-FND-ID-T (I)      TO L6350-FUND-CD (I).

557660     IF MIR-DV-CFN-APROX-AMT-T (I) > SPACES
008455         SET L0280-SIGN-NOT-PERMITTED    TO TRUE
008455         MOVE '2'               TO L0280-PRECISION
008455         MOVE MIR-DV-CFN-APROX-AMT-T (I)
                                      TO L0280-INPUT-DATA
008455         MOVE LENGTH OF MIR-DV-CFN-APROX-AMT-T (I)
                                      TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                                L0280-PRECISION - 1
008455         PERFORM  0280-1000-NUMERIC-EDIT
008455             THRU 0280-1000-NUMERIC-EDIT-X
008455         MOVE L0280-OUTPUT-DOLLAR
020469*                               TO L6350-FUND-VALUE (I)
020469                                TO L6350-POL-CRCY-FND-VAL (I)
557660     END-IF.

020469     IF MIR-DV-FIA-POL-CRCY-AMT-T (I) > SPACES
020469         SET L0280-SIGN-NOT-PERMITTED    TO TRUE
020469         MOVE '2'               TO L0280-PRECISION
020469         MOVE MIR-DV-FIA-POL-CRCY-AMT-T (I)
020469                                TO L0280-INPUT-DATA
020469         MOVE LENGTH OF MIR-DV-FIA-POL-CRCY-AMT-T (I)
020469                                TO L0280-INPUT-SIZE
020469         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
020469                                L0280-PRECISION - 1
020469         PERFORM  0280-1000-NUMERIC-EDIT
020469             THRU 0280-1000-NUMERIC-EDIT-X
020469         MOVE L0280-OUTPUT-DOLLAR
020469                                TO L6350-POL-CRCY-FND-VAL (I)
020469     END-IF.

557660     IF MIR-DV-FROM-FND-AMT-T (I) > SPACES
008455         SET L0280-SIGN-NOT-PERMITTED  TO TRUE
008455         MOVE '2'               TO L0280-PRECISION
008455         MOVE MIR-DV-FROM-FND-AMT-T (I)
                                      TO L0280-INPUT-DATA
008455         MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (I)
                                      TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                                L0280-PRECISION - 1
008455         PERFORM  0280-1000-NUMERIC-EDIT
008455             THRU 0280-1000-NUMERIC-EDIT-X
008455         MOVE L0280-OUTPUT-DOLLAR
                                      TO L6350-AMT-FROM-FND (I)
557660     END-IF.

557660     IF MIR-DV-TO-FND-AMT-T (I) > SPACES
008455         SET L0280-SIGN-NOT-PERMITTED  TO TRUE
008455         MOVE '2'               TO L0280-PRECISION
008455         MOVE MIR-DV-TO-FND-AMT-T (I)
                                      TO L0280-INPUT-DATA
008455         MOVE LENGTH OF MIR-DV-TO-FND-AMT-T (I)
                                      TO L0280-INPUT-SIZE
008455         COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
008455                                L0280-PRECISION - 1
008455         PERFORM  0280-1000-NUMERIC-EDIT
008455             THRU 0280-1000-NUMERIC-EDIT-X
008455         MOVE L0280-OUTPUT-DOLLAR
                                      TO L6350-AMT-TO-FND (I)
557660     END-IF.

557660     IF MIR-FIA-OUT-ALLOC-PCT-T (I) > SPACES
020469*        MOVE MIR-FIA-OUT-ALLOC-PCT-T (I)
020469*                               TO WS-PCNT-HOLD
020469*        MOVE WS-PCNT-HOLD-N    TO L6350-PCT-FROM-FND (I)
020469         SET L0280-SIGN-NOT-PERMITTED    TO TRUE
020469         MOVE '3'               TO L0280-LENGTH
020469         MOVE '4'               TO L0280-PRECISION
020469         MOVE MIR-FIA-OUT-ALLOC-PCT-T (I)
020469                                TO L0280-INPUT-DATA
020469         PERFORM  0280-1000-NUMERIC-EDIT
020469             THRU 0280-1000-NUMERIC-EDIT-X
020469         IF  L0280-OK
020469             MOVE L0280-OUTPUT-V04
020469                                TO L6350-PCT-FROM-FND (I)
020469         ELSE
020469             MOVE ZEROS         TO L6350-PCT-FROM-FND (I)
020469         END-IF
557660     END-IF.

557660     IF MIR-FIA-IN-ALLOC-PCT-T (I) > SPACES
020469*         MOVE MIR-FIA-IN-ALLOC-PCT-T (I)
020469*                               TO WS-PCNT-HOLD
020469*        MOVE WS-PCNT-HOLD-N    TO L6350-FND-PCT-ALLOC (I)
020469         SET L0280-SIGN-NOT-PERMITTED    TO TRUE
020469         MOVE '3'               TO L0280-LENGTH
020469         MOVE '4'               TO L0280-PRECISION
020469         MOVE MIR-FIA-IN-ALLOC-PCT-T (I)
020469                                TO L0280-INPUT-DATA
020469         PERFORM  0280-1000-NUMERIC-EDIT
020469             THRU 0280-1000-NUMERIC-EDIT-X
020469         IF  L0280-OK
020469             MOVE L0280-OUTPUT-V04
020469                                TO L6350-FND-PCT-ALLOC (I)
020469         ELSE
020469             MOVE ZEROS         TO L6350-FND-PCT-ALLOC (I)
020469         END-IF
557660     END-IF.

018763     IF  MIR-DV-PRCES-STATE-CD = '2'
018763         MOVE L6350-AMT-TO-FND (I)
018763                                TO WS-TWRK-TAMT (I)
018763     END-IF.


       1052-MOVE-SCREEN-TO-WS-X.
           EXIT.
      *
      *-------------------------
       1100-PROCESS-REQUESTS-PHASE.
      *-------------------------

           EVALUATE MIR-DV-PRCES-STATE-CD

               WHEN '1'
                   PERFORM  1400-REQUEST-PHASE-0
                       THRU 1400-REQUEST-PHASE-0-X

               WHEN '2'
                   PERFORM  1500-REQUEST-PHASE-1
                       THRU 1500-REQUEST-PHASE-1-X

               WHEN '3'
                   PERFORM  1600-REQUEST-PHASE-2
                       THRU 1600-REQUEST-PHASE-2-X

013578         WHEN OTHER
013578              SET MIR-RETRN-INVALD-RQST
013578                                   TO TRUE
013578              GO TO 1100-PROCESS-REQUESTS-PHASE-X
013578
           END-EVALUATE.

       1100-PROCESS-REQUESTS-PHASE-X.
           EXIT.
      *
      *---------------
       1200-CALL-FTRS.
      *---------------
      *
      * SETUP PARMS AND CALL FUNCTION DRIVER TO PROCESS THE TRANSFER
      *
           MOVE LSEGF-INV-CVG-REC-INFO TO RFC-REC-INFO.
           MOVE 'TRS'                 TO LSEGF-INPUT-TYP-CD.
           MOVE HOLD-POL-ID-BASE      TO LSEGF-INPUT-POL-ID-BASE.
           MOVE HOLD-POL-ID-SFX       TO LSEGF-INPUT-POL-ID-SFX.
           MOVE COV-HOLD              TO LSEGF-INPUT-CVG-NUM.
           MOVE LSEGF-INV-CVG-CFN-EFF-DT
                                      TO LSEGF-INPUT-EFF-DT.
           MOVE +0                    TO LSEGF-INPUT-SEQ-NUM.
           MOVE +0                    TO LSEGF-INPUT-SURR-PCT.
           MOVE SPACES                TO LSEGF-INPUT-REASN-CD.
           MOVE SPACES                TO LSEGF-INPUT-SURR-REASN-CD.
012134     MOVE ZEROS                 TO LSEGF-INPUT-TAX-YR.
021239     MOVE WCVGS-CVG-UNIT-TYP-CD (COV-HOLD)
021239                                TO LSEGF-CVG-UNIT-TYP-CD.

           IF  L6350-ALLOC-CD = 'A'
           OR  L6350-ALLOC-CD = 'B'
               MOVE WS-INPUT-AMOUNT   TO LSEGF-INPUT-AMT
           ELSE
               MOVE +0                TO LSEGF-INPUT-AMT
           END-IF.

           IF  LSEGF-INPUT-LOAD-FORCE-IND = 'N'
               MOVE +0                TO LSEGF-INPUT-LOAD-AMT
           ELSE
               MOVE L6350-XFER-CHRG   TO LSEGF-INPUT-LOAD-AMT
           END-IF.

           MOVE L6350-SOURCE-CD       TO LSEGF-INPUT-SRC-CD.
           MOVE SPACES                TO LSEGF-INPUT-COMM-PRCES-IND.
025388*    MOVE SPACES                TO LSEGF-INPUT-REG-FND-SRC-CD.
025388     SET  LSEGF-INPUT-FND-REG-CONTRB   TO TRUE.

           MOVE 0                     TO J.
           PERFORM  1250-FORMAT-FD-FTRS
               THRU 1250-FORMAT-FD-FTRS-X
            VARYING I FROM 1 BY 1
              UNTIL I > LSEGF-FND-CTR.

           MOVE L6350-ALLOC-CD        TO LSEGF-INPUT-ALLOC-IND.

           MOVE 'TRS'                 TO LSEGF-CIA-FIA-OPT-CD.

           MOVE J                     TO LSEGF-FIA-REC-CTR.

           IF  L6350-ALLOC-CD = 'C'
               PERFORM  2500-GET-CASH-VALUES
                   THRU 2500-GET-CASH-VALUES-X
           END-IF.

           IF WGLOB-GOOD-RETURN
               SET L6350-PRCES-TYP-ALL TO TRUE
016109         SET L6350-XFER-OVRID-NO TO TRUE
016503         SET L6350-REDO-WARNING  TO TRUE
               PERFORM 6350-1000-PROCESS-XFER
                  THRU 6350-1000-PROCESS-XFER-X
               IF  L6350-RETRN-ERROR
                   SET WGLOB-RETURN-ERROR TO TRUE
                   PERFORM 2200-SET-ERROR-ATTRIB
                      THRU 2200-SET-ERROR-ATTRIB-X
               END-IF
           END-IF.

      *
      * EXIT IF ERROR. IF TRANSFER OK, REQUEST USER TO VERIFY TRANSFER
      * AND SAVE INFO ON TSQ.
      *
           IF  NOT L6350-RETRN-OK
               GO TO 1200-CALL-FTRS-X
           END-IF.

           IF  NOT WS-REBUILD-AFTER-UNDO-YES
               PERFORM 8600-CHECK-REQUESTS-DEFER
                  THRU 8600-CHECK-REQUESTS-DEFER-X
               IF  L8170-RETRN-OK
               AND L8170-DEFR-REQUIRED
      *MSG: THIS TRANSFER WILL BE DEFERRED
                   MOVE 'SS00700027'  TO WGLOB-MSG-REF-INFO
                   PERFORM 0260-1000-GENERATE-MESSAGE
                      THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF  NOT WS-REBUILD-AFTER-UNDO-YES

016605         PERFORM  8090-1000-BUILD-PARM-INFO
016605             THRU 8090-1000-BUILD-PARM-INFO-X
016605
016605         SET L8090-TEMP-WRK-TYP-SEG-ACTV  TO TRUE
016605         MOVE LENGTH OF WS-TWRK-WORK-AREA TO L8090-AREA-LEN
016605         MOVE +1                  TO L8090-TEMP-WRK-SEQ-NUM
016605
016605        PERFORM  8090-3000-DELETE-TWRK
016605            THRU 8090-3000-DELETE-TWRK-X

               MOVE LSEGF-FC-FS-INFO  TO WPDTQ-CMFC-AREA
               MOVE LSEGF-FA-FD-INFO  TO WPDTQ-CMFA-AREA
013578
013578         PERFORM  8090-1000-BUILD-PARM-INFO
013578             THRU 8090-1000-BUILD-PARM-INFO-X
013578
013578         SET L8090-TEMP-WRK-TYP-SEG-ACTV
013578                                TO TRUE
013578         MOVE WS-TWRK-WORK-AREA TO L8090-AREA-INFO-TEXT
013578         MOVE LENGTH OF WS-TWRK-WORK-AREA
013578                                TO L8090-AREA-LEN
013578
013578         PERFORM  8090-1000-WRITE-TWRK
013578             THRU 8090-1000-WRITE-TWRK-X
013578
013578         IF  NOT L8090-RETRN-OK
013578             MOVE 'XS00000092'  TO WGLOB-MSG-REF-INFO
013578                PERFORM  0260-1000-GENERATE-MESSAGE
013578                    THRU 0260-1000-GENERATE-MESSAGE-X
013578             GO TO 1200-CALL-FTRS-X
013578         END-IF
013578     END-IF.
013578
           IF (LSEGF-INPUT-ALLOC-IND = 'A' OR
               LSEGF-INPUT-ALLOC-IND = 'B')
025388*    AND LSEGF-INPUT-REG-FND-SRC-CD = ' '
025388     AND LSEGF-INPUT-FND-REG-CONTRB
               MOVE 1                 TO I
               PERFORM  1275-REFORMAT-SCREEN
                   THRU 1275-REFORMAT-SCREEN-X
              VARYING J FROM 1 BY 1
                UNTIL J > LSEGF-FND-CTR
            END-IF.

013578     IF  MIR-CIA-LOAD-FORCE-IND = 'N'
               MOVE LSEGF-CIA-REC-INFO   TO RFA-REC-INFO
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CIA-LOAD-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        COMPUTE L0290-INPUT-NUMBER = RFA-CIA-LOAD-AMT * 100
020874         MOVE RFA-CIA-LOAD-AMT  TO L0290-INPUT-V02
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
013578         MOVE L0290-OUTPUT-DATA TO MIR-CIA-LOAD-AMT
           END-IF.

       1200-CALL-FTRS-X.
           EXIT.
      *
      *--------------------
       1250-FORMAT-FD-FTRS.
      *--------------------

           IF  L6350-ALLOC-CD = 'A'
           OR  L6350-ALLOC-CD = 'B'
               MOVE L6350-AMT-FROM-FND (I)
                                      TO WS-ALLOC-NUM
           ELSE
               MOVE L6350-PCT-FROM-FND (I)
                                      TO WS-ALLOC-NUM
           END-IF.

           IF  WS-ALLOC-NUM NOT = 0.0
               COMPUTE WS-ALLOC-NUM = WS-ALLOC-NUM * -1.0
           ELSE
               IF  L6350-ALLOC-CD = 'A'
                   MOVE L6350-AMT-TO-FND (I)
                                      TO WS-ALLOC-NUM
               ELSE
                   MOVE L6350-FND-PCT-ALLOC (I)
                                      TO WS-ALLOC-NUM
               END-IF
           END-IF.

           IF  WS-ALLOC-NUM NOT = +0.0000
           AND WS-ALLOC-NUM NOT = -0.0000
               COMPUTE J = J + 1
               MOVE WS-ALLOC-NUM      TO LSEGF-INPUT-ALLOC-AMT (J)
               MOVE L6350-FUND-CD (I) TO LSEGF-INPUT-FND-ID (J)
           END-IF.

       1250-FORMAT-FD-FTRS-X.
           EXIT.
      *
      *---------------------
       1275-REFORMAT-SCREEN.
      *---------------------

           MOVE ZERO                  TO L6350-AMT-TO-FND (J).
           IF  I NOT > LSEGF-FIA-REC-CTR
           AND L6350-FUND-CD (J) = LSEGF-INPUT-FND-ID (I)
               MOVE LSEGF-FIA-REC-INFO (I)
                                      TO RFD-REC-INFO
               ADD 1              TO I
               IF RFD-FIA-FND-TRXN-AMT > 0
                   MOVE RFD-FIA-FND-TRXN-AMT
                                      TO L6350-AMT-TO-FND (J)
               END-IF
           END-IF.

       1275-REFORMAT-SCREEN-X.
           EXIT.
      *
      *--------------------------
       1300-FORMAT-OUTPUT-SCREEN.
      *--------------------------

013578*    IF CLEAR-SW-ON
013578*    OR MIR-DV-PRCES-STATE-CD = '1'
013578*        PERFORM  3000-FORMAT-TOP-LINE
013578*            THRU 3000-FORMAT-TOP-LINE-X
013578*    ELSE
013578*        PERFORM  6050-FORMAT-FUND-NO
013578*            THRU 6050-FORMAT-FUND-NO-X
013578*         VARYING I FROM 1 BY 1
013578*           UNTIL I > LSEGF-FND-CTR
013578*        PERFORM  3000-FORMAT-TOP-LINE
013578*            THRU 3000-FORMAT-TOP-LINE-X
013578*        PERFORM  3100-MOVE-WS-TO-SCREEN
013578*            THRU 3100-MOVE-WS-TO-SCREEN-X
013578*         VARYING I FROM 1 BY 1
013578*            UNTIL I > 15
013578*             UNTIL I > WFNDM-MAX-WFUND-NUM
013578*       END-IF.
013578*
013578     PERFORM  6050-FORMAT-FUND-NO
013578         THRU 6050-FORMAT-FUND-NO-X
013578      VARYING I FROM 1 BY 1
013578        UNTIL I > LSEGF-FND-CTR.
013578
013578     PERFORM  3000-FORMAT-TOP-LINE
013578         THRU 3000-FORMAT-TOP-LINE-X.
013578
013578     PERFORM  3100-MOVE-WS-TO-SCREEN
013578         THRU 3100-MOVE-WS-TO-SCREEN-X
013578      VARYING I FROM 1 BY 1
013578          UNTIL I > WFNDM-MAX-WFUND-NUM.

       1300-FORMAT-OUTPUT-SCREEN-X.
           EXIT.
      *
      *------------------
       1400-REQUEST-PHASE-0.
      *------------------
      *
      * FIRST PHASE WILL EDIT THE KEY INPUT FIELDS AND CALL FUNCTION
      * DRIVER TO PERFORM TRANSFER EDITS
      *
013578     PERFORM  8090-1000-BUILD-PARM-INFO
013578         THRU 8090-1000-BUILD-PARM-INFO-X.
013578
013578     SET L8090-TEMP-WRK-TYP-SEG-ACTV  TO TRUE.
013578     MOVE LENGTH OF WS-TWRK-WORK-AREA TO L8090-AREA-LEN.
013578     MOVE +1                          TO L8090-TEMP-WRK-SEQ-NUM.
013578
013578     PERFORM  8090-3000-DELETE-TWRK
013578         THRU 8090-3000-DELETE-TWRK-X.

           PERFORM  2100-EDIT-INPUT
               THRU 2100-EDIT-INPUT-X.

           IF WGLOB-GOOD-RETURN
               PERFORM  2300-GET-POLICY
                   THRU 2300-GET-POLICY-X
           END-IF.

014221     IF MIR-RETRN-TS-MISMATCH
014221        GO TO 1400-REQUEST-PHASE-0-X
014221     END-IF.

           IF WGLOB-GOOD-RETURN
               PERFORM  2350-EDATE-EDITS
                   THRU 2350-EDATE-EDITS-X
           END-IF.

016652     IF WGLOB-GOOD-RETURN
016652         PERFORM  2370-INPUT-LOAD-EDITS
016652             THRU 2370-INPUT-LOAD-EDITS-X
016652     END-IF.
016652
016652     IF WGLOB-GOOD-RETURN
016652         PERFORM  2371-LOAD-EDITS
016652             THRU 2371-LOAD-EDITS-X
016652     END-IF.

016108     IF WGLOB-GOOD-RETURN
016108         PERFORM  2360-VAL-DATE-OF-DTH
016108             THRU 2360-VAL-DATE-OF-DTH-X
016108     END-IF.

           IF WGLOB-GOOD-RETURN
               PERFORM  2400-GET-FC
                   THRU 2400-GET-FC-X
           END-IF.

           IF WGLOB-GOOD-RETURN
               PERFORM  2500-GET-CASH-VALUES
                   THRU 2500-GET-CASH-VALUES-X
           END-IF.

           IF  WGLOB-GOOD-RETURN
               SET L6350-PRCES-TYP-EDIT-ONLY TO TRUE
016109         SET L6350-XFER-OVRID-NO       TO TRUE
016503         SET L6350-REDO-WARNING  TO TRUE
               PERFORM 6350-1000-PROCESS-XFER
                  THRU 6350-1000-PROCESS-XFER-X
               IF  L6350-RETRN-ERROR
                   SET WGLOB-RETURN-ERROR TO TRUE
                   PERFORM 2200-SET-ERROR-ATTRIB
                      THRU 2200-SET-ERROR-ATTRIB-X
               END-IF
           END-IF.

           PERFORM  1420-FORMAT-ATTR-PHASE-0
               THRU 1420-FORMAT-ATTR-PHASE-0-X.

       1400-REQUEST-PHASE-0-X.
           EXIT.
      *
      *-------------------------
       1420-FORMAT-ATTR-PHASE-0.
      *-------------------------

           IF WGLOB-RETURN-ERROR
               SET FTRS-NO-CALL TO TRUE
               GO TO 1420-FORMAT-ATTR-PHASE-0-X
           END-IF.

           EVALUATE  L6350-ALLOC-CD

               WHEN 'A'
               WHEN 'B'
               WHEN 'C'
                   SET  FTRS-NO-CALL  TO TRUE

               WHEN OTHER
                   CONTINUE

           END-EVALUATE.

       1420-FORMAT-ATTR-PHASE-0-X.
           EXIT.
      *
      *------------------
       1500-REQUEST-PHASE-1.
      *------------------
      *
      * SECOND PHASE REDOES INITIAL EDITS, EDITS THE TRANSFER DETAILS
      * INPUT AND CALLS THE FUNCTION DRIVER TO PERFORM TRANSFER EDITS
      * BASED ON THE INPUT
      *
           PERFORM  2100-EDIT-INPUT
               THRU 2100-EDIT-INPUT-X.

           IF WGLOB-GOOD-RETURN
               PERFORM  2300-GET-POLICY
                   THRU 2300-GET-POLICY-X
           END-IF.

014221     IF MIR-RETRN-TS-MISMATCH
014221        GO TO 1500-REQUEST-PHASE-1-X
014221     END-IF.

           IF WGLOB-GOOD-RETURN
               PERFORM  2350-EDATE-EDITS
                   THRU 2350-EDATE-EDITS-X
           END-IF.

016652     IF WGLOB-GOOD-RETURN
016652         PERFORM  2371-LOAD-EDITS
016652             THRU 2371-LOAD-EDITS-X
016652     END-IF.

016108     IF WGLOB-GOOD-RETURN
016108         PERFORM  2360-VAL-DATE-OF-DTH
016108             THRU 2360-VAL-DATE-OF-DTH-X
016108     END-IF.

           IF WGLOB-GOOD-RETURN
               PERFORM  2400-GET-FC
                   THRU 2400-GET-FC-X
           END-IF.

           IF NOT WGLOB-GOOD-RETURN
               GO TO 1500-REQUEST-PHASE-1-X
           END-IF.

           MOVE 0                     TO AMOUNT-EDIT-FROM-SW.
           MOVE 0                     TO AMOUNT-EDIT-TO-SW.
           MOVE 0                     TO PERCNT-EDIT-FROM-SW.
           MOVE 0                     TO PERCNT-EDIT-TO-SW.
019549*    MOVE 0                     TO AMOUNT-COMPARE-SW.
           MOVE 0                     TO TO-FROM-ERROR-SW.
           MOVE 0                     TO FROM-AMOUNT-ERROR-SW.
           MOVE 0                     TO TO-AMOUNT-ERROR-SW.
           MOVE 0                     TO FROM-PERCNT-ERROR-SW.
           MOVE 0                     TO TO-PERCNT-ERROR-SW.

           MOVE ZERO                  TO WS-INPUT-AMOUNT.
           MOVE ZERO                  TO WS-INPUT-PCNT.

019549     PERFORM  2500-GET-CASH-VALUES
019549         THRU 2500-GET-CASH-VALUES-X.
019549
           PERFORM  2800-EDIT-BOTTOM-DATA
               THRU 2800-EDIT-BOTTOM-DATA-X
            VARYING I FROM 1 BY 1
              UNTIL I > LSEGF-FND-CTR.

           IF ((L6350-ALLOC-CD = 'A'
           OR   L6350-ALLOC-CD = 'B')
           AND  WS-INPUT-AMOUNT = ZERO)
           OR (L6350-ALLOC-CD = 'C'
           AND WS-INPUT-PCNT = ZERO)
      * MSG: 'TRANSFER FROM' AMOUNT/PERCENTAGE NOT SPECIFIED - REENTER
               MOVE 'SS00700002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF WGLOB-MSG-ERROR-SW > ZERO
                   SET WGLOB-RETURN-ERROR TO TRUE
               END-IF
           END-IF.

           PERFORM  1510-REPORT-ERRORS
               THRU 1510-REPORT-ERRORS-X.

           IF  WGLOB-GOOD-RETURN
               SET L6350-PRCES-TYP-EDIT-ONLY TO TRUE
016109         SET L6350-XFER-OVRID-NO       TO TRUE
016503         SET L6350-REDO-WARNING  TO TRUE
               PERFORM 6350-1000-PROCESS-XFER
                  THRU 6350-1000-PROCESS-XFER-X
               IF  L6350-RETRN-ERROR
                   SET WGLOB-RETURN-ERROR TO TRUE
                   PERFORM 2200-SET-ERROR-ATTRIB
                      THRU 2200-SET-ERROR-ATTRIB-X
               END-IF
           END-IF.

           PERFORM  1520-FORMAT-ATTR-PHASE-1
               THRU 1520-FORMAT-ATTR-PHASE-1-X.


       1500-REQUEST-PHASE-1-X.
           EXIT.
      *
      *-------------------
       1510-REPORT-ERRORS.
      *-------------------

           IF AMOUNT-FROM-ERROR
      *MSG:    'TRANSFER FROM' AMOUNT NOT NUMERIC
               MOVE 'SS00700008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
019549*    IF AMOUNT-COMPARE-ERROR
019549*MSG:    'TRANSFER FROM' AMOUNT EXCEEDS APPROXIMATE FUND VALUE
019549*        MOVE 'SS00700009'      TO WGLOB-MSG-REF-INFO
019549*        PERFORM  0260-1000-GENERATE-MESSAGE
019549*            THRU 0260-1000-GENERATE-MESSAGE-X
019549*    END-IF.
           IF PERCNT-FROM-ERROR
      *MSG:    'TRANSFER FROM' PERCENTAGE INVALID
               MOVE 'SS00700010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
           IF AMOUNT-TO-ERROR
      *MSG:    'TRANSFER TO AMOUNT NOT NUMERIC
               MOVE 'SS00700011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
           IF PERCNT-TO-ERROR
      *MSG: 'TRANSFER TO' PERCENTAGE INVALID
               MOVE 'SS00700012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.
           IF TO-FROM-ERROR
      *MSG:    CANNOT TRANSFER FROM AND TO THE SAME FUND
               MOVE 'SS00700013'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

       1510-REPORT-ERRORS-X.
           EXIT.
      *
      *------------------------
       1520-FORMAT-ATTR-PHASE-1.
      *------------------------

           IF WGLOB-RETURN-ERROR
               SET  FTRS-NO-CALL  TO TRUE
           ELSE
               SET FTRS-DO-CALL   TO TRUE
           END-IF.

       1520-FORMAT-ATTR-PHASE-1-X.
           EXIT.
      *
      *------------------
       1600-REQUEST-PHASE-2.
      *------------------
      *
      * THIRD PHASE READS TSQ
      *
           SET FTRS-NO-CALL           TO TRUE.
013578
013578     PERFORM  8090-1000-BUILD-PARM-INFO
013578         THRU 8090-1000-BUILD-PARM-INFO-X.
013578
013578     SET L8090-TEMP-WRK-TYP-SEG-ACTV  TO TRUE.
013578     MOVE LENGTH OF WS-TWRK-WORK-AREA TO L8090-AREA-LEN.
013578     MOVE +1                          TO L8090-TEMP-WRK-SEQ-NUM.
013578
013578     PERFORM  8090-2000-RETRIEVE-TWRK
013578         THRU 8090-2000-RETRIEVE-TWRK-X.
013578
013578     IF  L8090-RETRN-OK
013578         MOVE L8090-AREA-INFO-TEXT TO WS-TWRK-WORK-AREA
013578         MOVE WPDTQ-CMFC-AREA      TO LSEGF-FC-FS-INFO
013578         MOVE WPDTQ-CMFA-AREA      TO LSEGF-FA-FD-INFO
013578         PERFORM  8090-3000-DELETE-TWRK
013578             THRU 8090-3000-DELETE-TWRK-X
           ELSE
               MOVE 'XS00000092'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 1600-REQUEST-PHASE-2-X
           END-IF.

           PERFORM  1650-VERIFY-TRANSFER
               THRU 1650-VERIFY-TRANSFER-X.

       1600-REQUEST-PHASE-2-X.
           EXIT.

      *---------------------
       1650-VERIFY-TRANSFER.
      *---------------------

           MOVE 'VER'                 TO LSEGF-CIA-FIA-OPT-CD.

557701*** NEED TO SETUP ALL L6350 INPUT FIELDS
557701     PERFORM 2100-EDIT-INPUT
557701        THRU 2100-EDIT-INPUT-X.
557701     PERFORM 2350-EDATE-EDITS
557701        THRU 2350-EDATE-EDITS-X.
016652     PERFORM 2371-LOAD-EDITS
016652        THRU 2371-LOAD-EDITS-X.
           PERFORM 2300-GET-POLICY
              THRU 2300-GET-POLICY-X.

014221     IF MIR-RETRN-TS-MISMATCH
014221        GO TO 1650-VERIFY-TRANSFER-X
014221     END-IF.

020463     IF  NOT WGLOB-GOOD-RETURN
020463         GO TO 1650-VERIFY-TRANSFER-X
020463     END-IF.

016108     PERFORM  2360-VAL-DATE-OF-DTH
016108         THRU 2360-VAL-DATE-OF-DTH-X.

           PERFORM 2400-GET-FC
              THRU 2400-GET-FC-X.

016503* INVOKE REDO PROCESSING IF REQUIRED.
016503

016503     SET WS-REDO-OK                  TO TRUE.
016503     PERFORM  1651-INVOKE-REDO
016503         THRU 1651-INVOKE-REDO-X.

016503     IF  WS-REDO-NOT-OK
016503         GO TO 1650-VERIFY-TRANSFER-X
016503     END-IF.

557701     PERFORM  1652-INVOKE-UNDO
557701         THRU 1652-INVOKE-UNDO-X.
557701
557701     IF  NOT WGLOB-GOOD-RETURN
557701         GO TO 1650-VERIFY-TRANSFER-X
557701     END-IF.
557701
           SET L6350-PRCES-TYP-ALL TO TRUE.
012137     IF  MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L6350-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.
012696*
012696     PERFORM 8600-CHECK-REQUESTS-DEFER
012696        THRU 8600-CHECK-REQUESTS-DEFER-X.
012696*
012696     IF  L8170-RETRN-OK
012696     AND L8170-DEFR-REQUIRED
012696         PERFORM 8700-DEFER-REQUEST
012696            THRU 8700-DEFER-REQUEST-X
012696         SET LSEGF-INV-CVG-CFN-OPT-UPD-FILE TO TRUE
012696         PERFORM  0500-1000-PROCESS-FC-FS
012696             THRU 0500-1000-PROCESS-FC-FS-X
012696         MOVE RPOL-REC-INFO     TO HPOL-REC-INFO
012696         MOVE RPOL-KEY          TO WPOL-KEY
012696         PERFORM  POL-1000-READ-FOR-UPDATE
012696             THRU POL-1000-READ-FOR-UPDATE-X
012696         MOVE HPOL-REC-INFO     TO RPOL-REC-INFO

016503         PERFORM  1700-SET-POL-NXT-ACTV
016503            THRU  1700-SET-POL-NXT-ACTV-X

012696         PERFORM  POL-2000-REWRITE
012696             THRU POL-2000-REWRITE-X
012696         MOVE RPOL-POL-ID       TO WCVG-POL-ID
012696         MOVE COV-HOLD          TO I
012696         PERFORM CVGR-2000-REWRITE-COVERAGE
012696            THRU CVGR-2000-REWRITE-COVERAGE-X
014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X
012696         GO TO 1650-VERIFY-TRANSFER-X
012696     END-IF.
012696*

019573*    CALL CSLU2600 TO WRITE CDSA & CDSD RECORDS FOR THE TRANSFER

019573     PERFORM  2600-1000-BUILD-PARM-INFO
019573         THRU 2600-1000-BUILD-PARM-INFO-X.

019573     MOVE RPOL-POL-ID           TO L2600-POL-ID.
019573     SET L2600-CDA-TYP-XFER        TO TRUE.
019573     SET L2600-CDA-STAT-ACTIVE     TO TRUE.
023112*    SET L2600-CDA-CREAT-BY-SYSTEM TO TRUE.

019573     MOVE L6350-EFF-DT          TO L2600-CDA-EFF-DT.
019573     MOVE ZERO                  TO L2600-CDA-TOT-TRXN-AMT.

019573     PERFORM  2600-1000-WRITE-CDSA
019573         THRU 2600-1000-WRITE-CDSA-X.

019573     MOVE L2600-POL-PAYO-NUM    TO L6350-POL-PAYO-NUM.
019573     MOVE L2600-CDA-SEQ-NUM     TO L6350-CDA-SEQ-NUM.

016503     SET L6350-REDO-WARNING  TO TRUE.
           PERFORM 6350-2000-VERIFY-XFER
              THRU 6350-2000-VERIFY-XFER-X.

           IF  L6350-RETRN-OK
019573         MOVE LSEGF-CIA-REC-INFO TO RFA-REC-INFO
019573         MOVE RFA-CIA-SEQ-NUM    TO L2600-CDAD-CF-FA-SEQ-NUM
019573         MOVE COV-HOLD           TO L2600-CVG-NUM
019573         MOVE ZERO               TO L2600-CDAD-TRXN-AMT

019573         PERFORM  2600-2000-WRITE-CDSD
019573             THRU 2600-2000-WRITE-CDSD-X

      *MSG: TRANSFER ACCEPTED
               MOVE 'SS00700015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET LSEGF-INV-CVG-CFN-OPT-UPD-FILE TO TRUE

               PERFORM  0500-1000-PROCESS-FC-FS
                   THRU 0500-1000-PROCESS-FC-FS-X

               IF  L0500-RETRN-OK
557701             MOVE RPOL-REC-INFO TO HPOL-REC-INFO
557701             MOVE RPOL-KEY      TO WPOL-KEY
557701             PERFORM  POL-1000-READ-FOR-UPDATE
557701                 THRU POL-1000-READ-FOR-UPDATE-X
557701             MOVE HPOL-REC-INFO TO RPOL-REC-INFO

016503             PERFORM  1700-SET-POL-NXT-ACTV
016503                THRU  1700-SET-POL-NXT-ACTV-X

557701             PERFORM  POL-2000-REWRITE
557701                 THRU POL-2000-REWRITE-X
                   MOVE RPOL-POL-ID   TO WCVG-POL-ID
                   MOVE COV-HOLD      TO I
                   PERFORM CVGR-2000-REWRITE-COVERAGE
                      THRU CVGR-2000-REWRITE-COVERAGE-X
014221             PERFORM  POL-1000-READ-TWRK-TS
014221                 THRU POL-1000-READ-TWRK-TS-X
               END-IF
           END-IF.

       1650-VERIFY-TRANSFER-X.
           EXIT.
016503*-----------------
016503 1651-INVOKE-REDO.
016503*-----------------
016503
016503     IF  (RPOL-POL-NXT-ACTV-DT NOT = WWKDT-ZERO-DT
016503     AND RPOL-POL-NXT-ACTV-DT > WGLOB-PROCESS-DATE)
016503         GO TO 1651-INVOKE-REDO-X
016503     END-IF.
016503
016503     IF  NOT RPOL-POL-STAT-IN-FORCE
016503         GO TO 1651-INVOKE-REDO-X
016503     END-IF.

016503     PERFORM  4780-1000-BUILD-PARM-INFO
016503         THRU 4780-1000-BUILD-PARM-INFO-X.
016503     SET L4780-REDO-WARNING             TO TRUE.
016503     SET L4780-MSG-SUPPRESS             TO TRUE.
016503     MOVE L6350-EFF-DT                  TO L4780-EFF-DT.
016503     MOVE RPOL-PREV-BTCH-PRCES-DT TO L4780-LAST-PROCESS-DATE.
016503     SET L4780-PRCES-INCLUSIVE          TO TRUE.
016503
016503     PERFORM  4780-1000-GET-NEXT-ACT-DT
016503         THRU 4780-1000-GET-NEXT-ACT-DT-X.
016503
016503     EVALUATE  TRUE
016503         WHEN L4780-RETRN-ERROR
016503         WHEN L4780-RETRN-INVALID-REQUEST
016503              SET WS-REDO-NOT-OK           TO TRUE
016503         WHEN  (L4780-RETRN-OK
016503         AND L4780-ACTIVITY-DUE
016503         AND L4780-REDO-ALLOW)
016503             MOVE L6350-EFF-DT        TO L0201-EFF-DT
016503             SET L0201-AUTO-REDO      TO TRUE
016503             PERFORM  0201-1000-AUTO-PROCESSING
016503                 THRU 0201-1000-AUTO-PROCESSING-X

016503             PERFORM  1700-SET-POL-NXT-ACTV
016503                THRU  1700-SET-POL-NXT-ACTV-X

016503             MOVE RPOL-REC-INFO            TO HPOL-REC-INFO
016503             PERFORM  POL-1000-READ-FOR-UPDATE
016503                 THRU POL-1000-READ-FOR-UPDATE-X
016503             MOVE HPOL-REC-INFO            TO RPOL-REC-INFO
016503             PERFORM  POL-2000-REWRITE
016503                 THRU POL-2000-REWRITE-X
016503             PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
016503                 THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
014221             PERFORM  POL-1000-READ-TWRK-TS
014221                 THRU POL-1000-READ-TWRK-TS-X
016503             IF  L0201-RETRN-OK
016503                 MOVE 'XS00000307'     TO  WGLOB-MSG-REF-INFO
016503*MSG: 'AUTO REDO PROCESSING COMPLETED
016503                 PERFORM  0260-1000-GENERATE-MESSAGE
016503                     THRU 0260-1000-GENERATE-MESSAGE-X
016503             ELSE
016503                 SET WS-REDO-NOT-OK           TO TRUE
016503                 IF  NOT L0201-INCOMPLETE-DUE-ACTV
016503                     MOVE 'XS00000308' TO WGLOB-MSG-REF-INFO
016503*MSG: PROBLEM IN AUTO REDO PROCESSING
016503                     PERFORM  0260-1000-GENERATE-MESSAGE
016503                         THRU 0260-1000-GENERATE-MESSAGE-X
016503                 END-IF
016503                 GO TO 1651-INVOKE-REDO-X
016503             END-IF
016503*
016503*  REBUILD SEGFUND TSQ'S, ETC.
016503*
016503             SET WS-REBUILD-AFTER-REDO-YES TO TRUE
016503             MOVE 0                     TO FTRS-CALL-SW
016503
016503             PERFORM  1500-REQUEST-PHASE-1
016503                 THRU 1500-REQUEST-PHASE-1-X
016503
016503             IF  FTRS-CALL-SW = 1
016503                 PERFORM  1200-CALL-FTRS
016503                     THRU 1200-CALL-FTRS-X
016503                 MOVE 0                 TO FTRS-CALL-SW
016503             END-IF
016503     END-EVALUATE.
016503
016503 1651-INVOKE-REDO-X.
016503     EXIT.

557701*
557701******************
557701 1652-INVOKE-UNDO.
557701******************
557701
557701     PERFORM  4750-1000-BUILD-PARM-INFO
557701         THRU 4750-1000-BUILD-PARM-INFO-X.
557701
012137     IF MIR-SUPRES-CNFRM-IND = 'Y'
012137         SET L4750-SUPPRESS-CONFIRM TO TRUE
012137     END-IF.
012137
557701     SET L4750-FCN-DRVR-SECONDARY TO TRUE.
557701     MOVE L6350-EFF-DT          TO L4750-EFF-DT.
557701     SET  L4750-PRCES-EXCLUSIVE   TO TRUE
557701
557701     PERFORM  4750-1000-UNDO-PROCESSING
557701         THRU 4750-1000-UNDO-PROCESSING-X.
557701
557701     IF  NOT L4750-RETRN-OK
557701         SET WGLOB-RETURN-ERROR      TO TRUE
557701     END-IF.
557701
557701     IF  L4750-POL-UPDATE-NOT-REQD
557701         GO TO 1652-INVOKE-UNDO-X
557701     END-IF.
557701
557701*  SAVE POLICY CHANGES DONE BY UNDO PROCESS
557701     MOVE RPOL-REC-INFO         TO HPOL-REC-INFO.
557701
557701     MOVE RPOL-KEY              TO WPOL-KEY.
557701     PERFORM  POL-1000-READ-FOR-UPDATE
557701         THRU POL-1000-READ-FOR-UPDATE-X.
557701     MOVE HPOL-REC-INFO         TO RPOL-REC-INFO.
557701
016503     PERFORM  1700-SET-POL-NXT-ACTV
016503        THRU  1700-SET-POL-NXT-ACTV-X.

557701     PERFORM  POL-2000-REWRITE
557701         THRU POL-2000-REWRITE-X.
557701     PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
557701         THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.
014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X
557701
557701*  REBUILD SEGFUND TSQ'S, ETC. AS UNDO WILL HAVE CHANGED
557701*  REQUESTS DATED AFTER THIS ONE
557701*
557701     SET WS-REBUILD-AFTER-UNDO-YES TO TRUE.
557701     SET L6350-ADD-CHARGE-YES      TO TRUE.
557701     SET FTRS-NO-CALL              TO TRUE.
557701
557701     PERFORM  1500-REQUEST-PHASE-1
557701         THRU 1500-REQUEST-PHASE-1-X.
557701
557701     IF  FTRS-DO-CALL
557701         PERFORM  1200-CALL-FTRS
557701             THRU 1200-CALL-FTRS-X
557701         SET FTRS-NO-CALL    TO TRUE
557701     END-IF.
557701
557701     SET L6350-ADD-CHARGE-NO       TO TRUE.
557701
557701 1652-INVOKE-UNDO-X.
557701     EXIT.

016503*----------------------
016503 1700-SET-POL-NXT-ACTV.
016503*----------------------

016503     PERFORM  0289-1000-INIT-PARM-INFO
016503         THRU 0289-1000-INIT-PARM-INFO-X.
016503
016503     MOVE L6350-EFF-DT    TO L0289-LO-PAC-DT.
016503     MOVE L6350-EFF-DT    TO L0289-LO-CRC-DT.
020467     MOVE L6350-EFF-DT    TO L0289-LO-DD2-DT.
016503     MOVE L6350-EFF-DT    TO L0289-PROC-EFF-DT.
016503
016503     PERFORM  0289-1000-OBTAIN-NXT-ACTV
016503         THRU 0289-1000-OBTAIN-NXT-ACTV-X.
016503
016503     IF  L0289-RETRN-OK
016503         MOVE L0289-NXT-ACTV-TYP-CD
016503           TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE L0289-NXT-ACTV-DT
016503           TO RPOL-POL-NXT-ACTV-DT
016503     ELSE
016503         MOVE 'RSH'  TO RPOL-NXT-ACTV-TYP-CD
016503         MOVE WGLOB-PROCESS-DATE
016503                     TO RPOL-POL-NXT-ACTV-DT
016503     END-IF.

016503 1700-SET-POL-NXT-ACTV-X.
016503     EXIT.
      *
       2100-EDIT-INPUT.
      *===============

           IF HOLD-POL-ID-BASE = SPACES
           OR HOLD-POL-ID-BASE = LOW-VALUES
      *MSG:    POLICY MUST BE ENTERED
               MOVE 'SS00700018'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           SET  L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE '2'                   TO L0280-LENGTH.
           MOVE '0'                   TO L0280-PRECISION.
           MOVE MIR-CVG-NUM           TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF  L0280-OK
               MOVE L0280-OUTPUT      TO COV-HOLD
020874*        MOVE COV-HOLD-R        TO MIR-CVG-NUM
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CVG-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-CVG-NUM
               MOVE L0280-OUTPUT      TO L6350-CVG-NUM
           END-IF.
           IF MIR-CVG-NUM NOT NUMERIC
           OR MIR-CVG-NUM < '01'
007766     OR MIR-CVG-NUM > WCVGM-MAX-WCVGS-NUM
007766*MSG:    COVERAGE NUMBER MUST BE BETWEEN 01 AND @1
               MOVE 'SS00700019'      TO WGLOB-MSG-REF-INFO
007766         MOVE WCVGM-MAX-WCVGS-NUM
                                      TO  WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
012146     ELSE
012146         MOVE COV-HOLD          TO I
021239*        MOVE WCVGS-CVG-UNIT-TYP-CD (I)
021239*                               TO LSEGF-CVG-UNIT-TYP-CD
           END-IF.

016652*    MOVE MIR-CIA-LOAD-FORCE-IND
016652*                               TO LSEGF-INPUT-LOAD-FORCE-IND.
016652*
016652*    IF  MIR-CIA-LOAD-FORCE-IND = 'N'
016652*        MOVE ZEROS             TO L6350-XFER-CHRG
016652*    ELSE
016652*        SET  L0280-SIGN-NOT-PERMITTED
016652*                               TO TRUE
016652*        MOVE '2'               TO L0280-PRECISION
016652*        MOVE MIR-CIA-LOAD-AMT  TO L0280-INPUT-DATA
016652*        MOVE LENGTH OF MIR-CIA-LOAD-AMT
016652*                               TO L0280-INPUT-SIZE
016652*        COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
016652*                               L0280-PRECISION - 1
016652*        PERFORM 0280-1000-NUMERIC-EDIT
016652*           THRU 0280-1000-NUMERIC-EDIT-X
016652*        IF  L0280-OK
016652*            MOVE 2             TO L0290-PRECISION
016652*            MOVE LENGTH OF MIR-CIA-LOAD-AMT
016652*                               TO L0290-MAX-OUT-LEN
016652*            MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
016652*            PERFORM  0290-1000-NUMERIC-FORMAT
016652*                THRU 0290-1000-NUMERIC-FORMAT-X
016652*            MOVE L0290-OUTPUT-DATA
016652*                               TO MIR-CIA-LOAD-AMT
016652*            MOVE L0280-OUTPUT-DOLLAR
016652*                               TO L6350-XFER-CHRG
016652*        ELSE
016652*MSG:        INVALID CHANGE - REENTER
016652*            MOVE 'SS00700003'  TO WGLOB-MSG-REF-INFO
016652*            PERFORM  0260-1000-GENERATE-MESSAGE
016652*                THRU 0260-1000-GENERATE-MESSAGE-X
016652*            MOVE 'N'           TO MIR-CIA-LOAD-FORCE-IND
016652*            MOVE ZEROS         TO L6350-XFER-CHRG
016652*        END-IF
016652*    END-IF.


012137*    VALIDATE VALUE FOR SUPPRESS CONFIRMATION FIELD
012137     IF  MIR-SUPRES-CNFRM-IND NOT = SPACES
012137         IF    MIR-SUPRES-CNFRM-IND NOT = 'Y'
012137         AND   MIR-SUPRES-CNFRM-IND NOT = 'N'
012137*MSG: SUPPRESS CONFIRMATION STATEMENT INVALID. ENTER  'Y' OR 'N'
012137               MOVE 'SS00700026' TO WGLOB-MSG-REF-INFO
012137               PERFORM  0260-1000-GENERATE-MESSAGE
012137                   THRU 0260-1000-GENERATE-MESSAGE-X
012137         END-IF
012137     ELSE
012137         MOVE 'N'               TO MIR-SUPRES-CNFRM-IND
012137     END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

       2100-EDIT-INPUT-X.
           EXIT.
      *
      *----------------------
       2200-SET-ERROR-ATTRIB.
      *----------------------

           IF  L6350-XFER-CHRG-ERR
013578         MOVE 'N'               TO MIR-CIA-LOAD-FORCE-IND
           END-IF.

       2200-SET-ERROR-ATTRIB-X.
           EXIT.

      *----------------
       2300-GET-POLICY.
      *----------------

           MOVE HOLD-POL-ID-BASE      TO WPOL-POL-ID-BASE.
           MOVE HOLD-POL-ID-SFX       TO WPOL-POL-ID-SFX.

014221     EVALUATE MIR-DV-PRCES-STATE-CD
014221         WHEN '1'
014221         WHEN '2'
014221             PERFORM  POL-1000-READ-TWRK-TS
014221                 THRU POL-1000-READ-TWRK-TS-X
014221         WHEN '3'
014221             PERFORM  POL-2000-UPDATE-TWRK-TS
014221                 THRU POL-2000-UPDATE-TWRK-TS-X
014221             IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221                 MOVE 'XS00000303'    TO WGLOB-MSG-REF-INFO
014221                 MOVE 'POL'           TO WGLOB-MSG-PARM (01)
014221                 MOVE WPOL-KEY        TO WGLOB-MSG-PARM (02)
014221                 PERFORM  0260-1000-GENERATE-MESSAGE
014221                     THRU 0260-1000-GENERATE-MESSAGE-X
014221                 SET WGLOB-RETURN-ERROR    TO  TRUE
014221                 GO TO 2300-GET-POLICY-X
014221             ELSE
014221                 IF  WPOL-IO-OK
014221                     PERFORM  POL-3000-UNLOCK
014221                         THRU POL-3000-UNLOCK-X
014221                 END-IF
014221             END-IF
014221     END-EVALUATE.

014221*    PERFORM  POL-1000-READ
014221*        THRU POL-1000-READ-X.
           IF  NOT WPOL-IO-OK
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
007766         MOVE WCVGM-MAX-WCVGS-NUM
                                      TO  WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 2300-GET-POLICY-X
           END-IF.

      *
      *  DO POLICY ACCESS CHECKS
      *
           PERFORM 5400-1000-BUILD-PARM-INFO
              THRU 5400-1000-BUILD-PARM-INFO-X.

016440     SET L5400-POL-XFER-UPDATE  TO TRUE.

           PERFORM 5400-1000-POL-CHK
              THRU 5400-1000-POL-CHK-X.
           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
016440     OR  L5400-XFER-ACCS-RESTRICTED
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 2300-GET-POLICY-X
           END-IF.

012624     IF  RPOL-POL-SUSPENDED
012624*MSG:POLICY CURRENTLY SUSPENDED - CANNOT MAINTAIN OR PROCESS
012624         MOVE 'XS00000240'         TO WGLOB-MSG-REF-INFO
012624         PERFORM  0260-1000-GENERATE-MESSAGE
012624             THRU 0260-1000-GENERATE-MESSAGE-X
012624         GO TO 2300-GET-POLICY-X
012624     END-IF.
012624
016440*    IF  RPOL-POL-APPL-CTL-NBS
016440*MSG:NEWBUS POLICY - CANNOT MAINTAIN OR PROCESS
016440*        MOVE 'XS00000238'        TO WGLOB-MSG-REF-INFO
016440*        PERFORM  0260-1000-GENERATE-MESSAGE
016440*            THRU 0260-1000-GENERATE-MESSAGE-X
016440*        GO TO 2300-GET-POLICY-X
016440*    END-IF.
012624
012624     IF  L5400-STAT-ACCS-RESTRICTED
012624         GO TO 2300-GET-POLICY-X
012624     END-IF.


020463* CHECK FOR INVESTOR PROFILE ON POLICY AND, IF NECESSARY, DISPLAY
020463* WARNING MESSAGE.

020463     PERFORM  2320-CHECK-FOR-INV-PRFL
020463         THRU 2320-CHECK-FOR-INV-PRFL-X.

           MOVE RPOL-POL-ID           TO LPGA-POLICY-NUMBER.

           IF  COV-HOLD                =  ZEROES
           OR  COV-HOLD                >  RPOL-POL-CVG-REC-CTR-N
               MOVE 'CS00000021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 2300-GET-POLICY-X
           END-IF.

           PERFORM CVGS-1000-LOAD-CVGS-ARRAY
              THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

016440     IF  WCVGS-CVG-STAT-BEFORE-SETL (COV-HOLD)
016440* MSG: COVERAGE NOT IN FORCE - CANNOT MAINTAIN OR PROCESS
016440         MOVE 'XS00000244'       TO WGLOB-MSG-REF-INFO
016440         PERFORM  0260-1000-GENERATE-MESSAGE
016440             THRU 0260-1000-GENERATE-MESSAGE-X
016440         GO TO 2300-GET-POLICY-X
016440     END-IF.

           IF  WGLOB-MSG-ERROR-SW = ZERO
               IF  NOT RPOL-POL-STAT-IN-FORCE
                   MOVE 'SS00000002'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

       2300-GET-POLICY-X.
           EXIT.

      *------------------------
020463 2320-CHECK-FOR-INV-PRFL.
      *------------------------

020463     PERFORM  2735-1000-BUILD-PARM-INFO
020463         THRU 2735-1000-BUILD-PARM-INFO-X.
020463     MOVE  RPOL-POL-ID   TO L2735-POL-ID.
020463     PERFORM  2735-1000-GET-PRFL
020463         THRU 2735-1000-GET-PRFL-X.
020463
020463     IF L2735-RETRN-PRFL-FND
020463* MSG: THIS POLICY CONTAINS INVESTOR PROFILE (@1). ALLOCATIONS
020463*      ENTERED MAY NOT MATCH THOSE DEFINED FOR THE PROFILE.
020463         MOVE L2735-PRFL-ID  TO WGLOB-MSG-PARM (1)
020463         MOVE 'SS00700030'   TO WGLOB-MSG-REF-INFO
020463         PERFORM  0260-1000-GENERATE-MESSAGE
020463             THRU 0260-1000-GENERATE-MESSAGE-X

020463         IF  WGLOB-MSG-SEVRTY-FATAL
020463             SET WGLOB-RETURN-ERROR  TO TRUE
020463         END-IF

020463     END-IF.

020463 2320-CHECK-FOR-INV-PRFL-X.
020463     EXIT.


      *
      *-----------------
       2350-EDATE-EDITS.
      *-----------------

           MOVE COV-HOLD              TO J.
           MOVE EDATE-HOLD            TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           IF  L1640-NOT-VALID
      *MSG:    INVALID DATE - REENTER
               MOVE 'SS00700022'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO L6350-EFF-DT
               MOVE L1640-INTERNAL-DATE
                                      TO LSEGF-INV-CVG-CFN-EFF-DT
               MOVE L1640-INTERNAL-DATE
                                      TO LSEGF-CIA-FIA-EFF-DT
           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

       2350-EDATE-EDITS-X.
           EXIT.
      *
016108*---------------------
016108 2360-VAL-DATE-OF-DTH.
016108*---------------------
016108*
016108* VALIDATE CLIENTS DATE OF DEATH FIELDS
016108*
016108     PERFORM  0985-1000-BUILD-PARM-INFO
016108         THRU 0985-1000-BUILD-PARM-INFO-X.
016108
016108     MOVE L6350-EFF-DT          TO L0985-EFF-DT.
016108
016108     PERFORM  0985-1000-VAL-POL-DT-OF-DTH
016108         THRU 0985-1000-VAL-POL-DT-OF-DTH-X.
016108
016108     IF  NOT L0985-RETRN-OK
016108         SET WGLOB-RETURN-ERROR TO TRUE
016108     END-IF.
016108
016108 2360-VAL-DATE-OF-DTH-X.
016108     EXIT.

016652*----------------------
016652 2370-INPUT-LOAD-EDITS.
016652*----------------------
016652
016109*    IF MIR-CIA-LOAD-FORCE-NO
016109     IF NOT RPOL-POL-FREE-XFER-NONE
016109     OR MIR-CIA-LOAD-FORCE-NO
016652         SET MIR-CIA-LOAD-FORCE-NO     TO TRUE
016652         MOVE 2                 TO L0290-PRECISION
016652         MOVE LENGTH OF MIR-CIA-LOAD-AMT
016652                                TO L0290-MAX-OUT-LEN
020874*        MOVE ZERO              TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
016652         MOVE L0290-OUTPUT-DATA
016652                                TO MIR-CIA-LOAD-AMT
016652     END-IF.
016652
016652 2370-INPUT-LOAD-EDITS-X.
016652     EXIT.
016652
016652*----------------
016652 2371-LOAD-EDITS.
016652*----------------
016652
016652     MOVE MIR-CIA-LOAD-FORCE-IND
016652                                TO LSEGF-INPUT-LOAD-FORCE-IND.
016652
016652     SET  L0280-SIGN-NOT-PERMITTED  TO TRUE.
016652     MOVE '2'               TO L0280-PRECISION.
016652     MOVE MIR-CIA-LOAD-AMT  TO L0280-INPUT-DATA.
016652     MOVE LENGTH OF MIR-CIA-LOAD-AMT
016652                            TO L0280-INPUT-SIZE.
016652     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE -
016652                            L0280-PRECISION - 1.
016652     PERFORM 0280-1000-NUMERIC-EDIT
016652        THRU 0280-1000-NUMERIC-EDIT-X.
016652     IF  L0280-OK
016652         MOVE 2             TO L0290-PRECISION
016652         MOVE LENGTH OF MIR-CIA-LOAD-AMT
016652                            TO L0290-MAX-OUT-LEN
016652         MOVE L0280-OUTPUT  TO L0290-INPUT-NUMBER
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
016652         MOVE L0290-OUTPUT-DATA
016652                            TO MIR-CIA-LOAD-AMT
016652         MOVE L0280-OUTPUT-DOLLAR
016652                            TO L6350-XFER-CHRG
016652     ELSE
016652*MSG:    INVALID CHARGE - REENTER
016652         MOVE 'SS00700003'  TO WGLOB-MSG-REF-INFO
016652         PERFORM  0260-1000-GENERATE-MESSAGE
016652             THRU 0260-1000-GENERATE-MESSAGE-X
016652         MOVE 'N'           TO MIR-CIA-LOAD-FORCE-IND
016652         MOVE ZEROS         TO L6350-XFER-CHRG
016652     END-IF.
016652
016652 2371-LOAD-EDITS-X.
016652     EXIT.

      *------------
       2400-GET-FC.
      *------------

           MOVE COV-HOLD              TO I.
           MOVE WCVGS-PLAN-ID (I)     TO LSEGF-PLAN-ID.
           MOVE SPACES                TO LSEGF-ALLOC-INFO.

           SET  LSEGF-INV-CVG-CFN-OPT-READ-INQ TO TRUE.
           PERFORM 0500-1000-PROCESS-FC-FS
              THRU 0500-1000-PROCESS-FC-FS-X.
      *
           IF  L0500-RETRN-ERROR
               MOVE 1                 TO WGLOB-MSG-ERROR-SW
           ELSE
               IF MIR-DV-PRCES-STATE-CD = '1'
                   PERFORM  2401-LOAD-FS-IN-WS
                       THRU 2401-LOAD-FS-IN-WS-X
               END-IF
           END-IF.

           IF WGLOB-MSG-ERROR-SW > ZERO
               SET WGLOB-RETURN-ERROR TO TRUE
           END-IF.

       2400-GET-FC-X.
           EXIT.
      *
      *-------------------
       2401-LOAD-FS-IN-WS.
      *-------------------

           MOVE 1                     TO J.
           PERFORM  8000-MOVE-FS-TO-WS
               THRU 8000-MOVE-FS-TO-WS-X
            VARYING I FROM 1 BY 1
              UNTIL I > LSEGF-FND-CTR.

           IF J = 1
      *MSG:   NO FUNDS ARE ACTIVE FOR THIS POLICY
               MOVE 'SS00700024'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2401-LOAD-FS-IN-WS-X.
           EXIT.
      *
      *---------------------
       2500-GET-CASH-VALUES.
      *---------------------

           MOVE ZERO                  TO LSEGF-INV-CVG-CFN-SEQ-NUM.
016537*    PERFORM  0410-1000-SEG-FND-CV
016537*        THRU 0410-1000-SEG-FND-CV-X.
016537     PERFORM  0410-0100-SEG-FND-CV
016537         THRU 0410-0100-SEG-FND-CV-X.

           IF  L0410-RETRN-ERROR
               SET WGLOB-RETURN-ERROR TO TRUE
           ELSE
               PERFORM  2520-MOVE-CASH-VALUES
                   THRU 2520-MOVE-CASH-VALUES-X
                VARYING I FROM 1 BY 1
                  UNTIL I > LSEGF-FND-CTR
           END-IF.

       2500-GET-CASH-VALUES-X.
           EXIT.

      *---------------------
       2520-MOVE-CASH-VALUES.
      *---------------------

020464*    MOVE LSEGF-CFN-CV-AMT (I) TO L6350-FUND-VALUE (I).

020469*    COMPUTE L6350-FUND-VALUE (I)
020469     COMPUTE L6350-POL-CRCY-FND-VAL (I)
020469*          = LSEGF-CFN-CV-AMT (I)
020469           = LSEGF-CFN-POL-CRCY-CV-AMT  (I)
020464           + LSEGF-CFN-POL-DEFR-IN-AMT  (I)
020464           + LSEGF-CFN-POL-DEFR-OUT-AMT (I).

020469     MOVE L6350-POL-CRCY-FND-VAL (I) TO WS-REQIR-CNVR-AMT.

020469     PERFORM  9100-POL-TO-FND-CRCY
020469         THRU 9100-POL-TO-FND-CRCY-X.

020469     IF  WGLOB-RETURN-ERROR
020469         GO TO 2520-MOVE-CASH-VALUES-X
020469     END-IF.

020469     MOVE L8695-CNVR-AMT     TO L6350-FND-CRCY-FND-VAL (I).

      *
       2520-MOVE-CASH-VALUES-X.
           EXIT.
      *
      *---------------------
       2800-EDIT-BOTTOM-DATA.
      *---------------------

           PERFORM  2810-EDIT-LINE-AMOUNTS
               THRU 2810-EDIT-LINE-AMOUNTS-X.
           PERFORM  2820-CHECK-LINE-TO-FROM
               THRU 2820-CHECK-LINE-TO-FROM-X.

       2800-EDIT-BOTTOM-DATA-X.
           EXIT.

      *----------------------
       2810-EDIT-LINE-AMOUNTS.
      *----------------------

           IF  L6350-ALLOC-CD = 'A'
           OR L6350-ALLOC-CD = 'B'
               PERFORM  2811-EDIT-FAMT
                   THRU 2811-EDIT-FAMT-X
           END-IF.

           IF  L6350-ALLOC-CD = 'A'
               PERFORM  2812-EDIT-TAMT
                   THRU 2812-EDIT-TAMT-X
           END-IF.

           IF  L6350-ALLOC-CD = 'C'
               PERFORM  2813-EDIT-FPCT
                   THRU 2813-EDIT-FPCT-X
           END-IF.

           IF  L6350-ALLOC-CD = 'B'
           OR L6350-ALLOC-CD = 'C'
               PERFORM  2814-EDIT-TPCT
                   THRU 2814-EDIT-TPCT-X
           END-IF.

019549     IF  L6350-AMT-FROM-FND (I) > ZERO
019549     OR  L6350-PCT-FROM-FND (I) > ZERO
020469*        IF  L6350-FUND-VALUE (I) = ZERO
020469         IF  L6350-POL-CRCY-FND-VAL (I) = ZERO
019549*MSG: FUND (@1) HAS NO VALUE
019549             MOVE 'SS00700029'      TO WGLOB-MSG-REF-INFO
019549             MOVE MIR-FND-ID-T (I)  TO WGLOB-MSG-PARM (1)
019549             PERFORM  0260-1000-GENERATE-MESSAGE
019549                 THRU 0260-1000-GENERATE-MESSAGE-X
019549         END-IF
019549     END-IF.
019549
020469*    IF  L6350-AMT-FROM-FND (I) > L6350-FUND-VALUE (I)
020469     IF  L6350-AMT-FROM-FND (I) > L6350-POL-CRCY-FND-VAL (I)
019549*MSG:    'TRANSFER FROM' AMOUNT EXCEEDS APPROXIMATE FUND VALUE
019549         MOVE 'SS00700009'      TO WGLOB-MSG-REF-INFO
019549         PERFORM  0260-1000-GENERATE-MESSAGE
019549             THRU 0260-1000-GENERATE-MESSAGE-X
019549     END-IF.
019549
       2810-EDIT-LINE-AMOUNTS-X.
           EXIT.

      *---------------
       2811-EDIT-FAMT.
      *---------------

012141     IF  MIR-DV-FROM-FND-AMT-T (I) = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = L6350-AMT-FROM-FND (I)
020874*                                     * 100
020874         MOVE L6350-AMT-FROM-FND (I) TO L0290-INPUT-V02
               PERFORM  9000-FORMAT-FAMT-T
012141             THRU 9000-FORMAT-FAMT-T-X
012141     END-IF.
           SET  L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE '2'                   TO L0280-PRECISION.
           MOVE MIR-DV-FROM-FND-AMT-T (I)
                                      TO L0280-INPUT-DATA.
020906*    IF  WGLOB-ENVRMNT-GUI
020906     IF  WGLOB-ENVRMNT-ONLINE
008455         MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (I)
008455                                TO L0280-INPUT-SIZE
008455     ELSE
008455         MOVE 10                TO L0280-INPUT-SIZE
008455     END-IF
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
008455                            - 1.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF  L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO L6350-AMT-FROM-FND (I)
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         PERFORM  9000-FORMAT-FAMT-T
008455             THRU 9000-FORMAT-FAMT-T-X
008455         ADD L6350-AMT-FROM-FND (I) TO WS-INPUT-AMOUNT
           ELSE
               MOVE 1                 TO AMOUNT-EDIT-FROM-SW
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
008455         PERFORM  9000-FORMAT-FAMT-T
008455             THRU 9000-FORMAT-FAMT-T-X
               MOVE ZEROS             TO L6350-AMT-FROM-FND (I)
           END-IF.

       2811-EDIT-FAMT-X.
           EXIT.

      *---------------
       2812-EDIT-TAMT.
      *---------------

012141     IF  MIR-DV-TO-FND-AMT-T (I) = SPACES
020874*        COMPUTE L0290-INPUT-NUMBER = L6350-AMT-TO-FND (I) * 100
020874         MOVE L6350-AMT-TO-FND (I)  TO L0290-INPUT-V02
               PERFORM  9002-FORMAT-TAMT-T
012141             THRU 9002-FORMAT-TAMT-T-X
012141     END-IF.
           SET  L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE '2'                   TO L0280-PRECISION.
           MOVE MIR-DV-TO-FND-AMT-T (I)
                                      TO L0280-INPUT-DATA.
020906*    IF  WGLOB-ENVRMNT-GUI
020906     IF  WGLOB-ENVRMNT-ONLINE
008455         MOVE LENGTH OF MIR-DV-TO-FND-AMT-T (I)
008455                                TO L0280-INPUT-SIZE
008455     ELSE
008455         MOVE 10                TO L0280-INPUT-SIZE
008455     END-IF
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - L0280-PRECISION
008455                            - 1.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF  L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO L6350-AMT-TO-FND (I)
008455         MOVE L0280-OUTPUT      TO L0290-INPUT-NUMBER
008455         PERFORM  9002-FORMAT-TAMT-T
008455             THRU 9002-FORMAT-TAMT-T-X
           ELSE
               MOVE 1                 TO AMOUNT-EDIT-TO-SW
020874*        MOVE 0                 TO L0290-INPUT-NUMBER
020874         MOVE ZERO              TO L0290-INPUT-V02
008455         PERFORM  9002-FORMAT-TAMT-T
008455             THRU 9002-FORMAT-TAMT-T-X
               MOVE ZEROS             TO L6350-AMT-TO-FND (I)
           END-IF.

018763     IF  MIR-DV-PRCES-STATE-CD = '3'
018763         MOVE WS-TWRK-TAMT (I)
018763                                TO L6350-AMT-TO-FND (I)
018763     END-IF.

       2812-EDIT-TAMT-X.
           EXIT.

      *---------------
       2813-EDIT-FPCT.
      *---------------

012141     IF  MIR-FIA-OUT-ALLOC-PCT-T (I) = SPACES
012141         MOVE L6350-PCT-FROM-FND (I)
                                      TO WS-PCNT-HOLD-N
020874*        MOVE WS-PCNT-HOLD      TO MIR-FIA-OUT-ALLOC-PCT-T (I)
020874         MOVE L6350-PCT-FROM-FND (I) TO L0290-INPUT-V04
020874         MOVE 4                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (I)
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-FIA-OUT-ALLOC-PCT-T (I)
012141     END-IF.
           SET  L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE '3'                   TO L0280-LENGTH.
           MOVE '4'                   TO L0280-PRECISION.
           MOVE MIR-FIA-OUT-ALLOC-PCT-T (I)
                                      TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF  L0280-OK
               MOVE L0280-OUTPUT-V04  TO L6350-PCT-FROM-FND (I)
020469*        MOVE L0280-OUTPUT-V04  TO WS-PCNT-HOLD-N
020874*        MOVE WS-PCNT-HOLD      TO MIR-FIA-OUT-ALLOC-PCT-T (I)
020469*        MOVE L0280-OUTPUT-V04      TO L0290-INPUT-V04
020469*        MOVE 4                     TO L0290-PRECISION
020469*        MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (I)
020469*                                   TO L0290-MAX-OUT-LEN
020469*        PERFORM 0290-2000-FORMAT-FOR-MIR
020469*           THRU 0290-2000-FORMAT-FOR-MIR-X
020469*        MOVE L0290-OUTPUT-DATA     TO MIR-FIA-OUT-ALLOC-PCT-T (I)
               ADD L6350-PCT-FROM-FND (I) TO WS-INPUT-PCNT
               IF  L6350-PCT-FROM-FND (I) > 100.0000
                  MOVE 1              TO PERCNT-EDIT-FROM-SW
               END-IF
           ELSE
               MOVE 1                 TO PERCNT-EDIT-FROM-SW
020469*        MOVE '000.0000'        TO MIR-FIA-OUT-ALLOC-PCT-T (I)
               MOVE ZEROS             TO L6350-PCT-FROM-FND (I)
           END-IF.

       2813-EDIT-FPCT-X.
           EXIT.

      *---------------
       2814-EDIT-TPCT.
      *---------------

012141     IF  MIR-FIA-IN-ALLOC-PCT-T (I) = SPACES
012141         MOVE L6350-FND-PCT-ALLOC (I)
                                      TO WS-PCNT-HOLD-N
020874*        MOVE WS-PCNT-HOLD-N    TO MIR-FIA-IN-ALLOC-PCT-T (I)
020874         MOVE L6350-FND-PCT-ALLOC (I) TO L0290-INPUT-V04
020874         MOVE 4                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FIA-IN-ALLOC-PCT-T (I)
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-FIA-IN-ALLOC-PCT-T (I)
012141     END-IF.
           SET  L0280-SIGN-NOT-PERMITTED TO TRUE.
           MOVE '3'                   TO L0280-LENGTH.
           MOVE '4'                   TO L0280-PRECISION.
           MOVE MIR-FIA-IN-ALLOC-PCT-T (I)
                                      TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF  L0280-OK
               MOVE L0280-OUTPUT-V04  TO L6350-FND-PCT-ALLOC (I)
020469*        MOVE L0280-OUTPUT-V04  TO WS-PCNT-HOLD-N
020874*        MOVE WS-PCNT-HOLD      TO MIR-FIA-IN-ALLOC-PCT-T (I)
020469*        MOVE L0280-OUTPUT-V04      TO L0290-INPUT-V04
020469*        MOVE 4                     TO L0290-PRECISION
020469*        MOVE LENGTH OF MIR-FIA-IN-ALLOC-PCT-T (I)
020469*                                   TO L0290-MAX-OUT-LEN
020469*        PERFORM 0290-2000-FORMAT-FOR-MIR
020469*           THRU 0290-2000-FORMAT-FOR-MIR-X
020469*        MOVE L0290-OUTPUT-DATA     TO MIR-FIA-IN-ALLOC-PCT-T (I)
               IF  L6350-FND-PCT-ALLOC (I) > 100.0000
                  MOVE 1              TO PERCNT-EDIT-TO-SW
               END-IF
           ELSE
               MOVE 1                 TO PERCNT-EDIT-TO-SW
020469*        MOVE '000.0000'        TO MIR-FIA-IN-ALLOC-PCT-T (I)
               MOVE ZEROS             TO L6350-FND-PCT-ALLOC (I)
           END-IF.

       2814-EDIT-TPCT-X.
           EXIT.
      *
      *-----------------------
       2820-CHECK-LINE-TO-FROM.
      *-----------------------


           EVALUATE  L6350-ALLOC-CD

               WHEN 'A'
                   PERFORM  2821-CHECK-TO-FROM-A
                       THRU 2821-CHECK-TO-FROM-A-X

               WHEN 'B'
                   PERFORM  2822-CHECK-TO-FROM-B
                       THRU 2822-CHECK-TO-FROM-B-X

               WHEN 'C'
                   PERFORM  2823-CHECK-TO-FROM-C
                       THRU 2823-CHECK-TO-FROM-C-X

           END-EVALUATE.

       2820-CHECK-LINE-TO-FROM-X.
           EXIT.
      *
      *---------------------
       2821-CHECK-TO-FROM-A.
      *---------------------

           IF NO-AMOUNT-FROM-ERROR
           AND NO-AMOUNT-TO-ERROR
               IF  L6350-AMT-FROM-FND (I) NOT = ZERO
               AND L6350-AMT-TO-FND (I) NOT = ZERO
                   MOVE 1             TO TO-FROM-ERROR-SW
               END-IF
           END-IF.

       2821-CHECK-TO-FROM-A-X.
           EXIT.

      *---------------------
       2822-CHECK-TO-FROM-B.
      *---------------------

           IF NO-AMOUNT-FROM-ERROR
           AND NO-PERCNT-TO-ERROR
               IF  L6350-AMT-FROM-FND (I) NOT = ZERO
               AND L6350-FND-PCT-ALLOC (I) NOT = ZERO
                   MOVE 1             TO TO-FROM-ERROR-SW
               END-IF
           END-IF.

       2822-CHECK-TO-FROM-B-X.
           EXIT.

      *---------------------
       2823-CHECK-TO-FROM-C.
      *---------------------

           IF  NO-PERCNT-FROM-ERROR
           AND NO-PERCNT-TO-ERROR
               IF  L6350-PCT-FROM-FND (I) NOT = ZERO
               AND L6350-FND-PCT-ALLOC (I) NOT = ZERO
                   MOVE 1             TO TO-FROM-ERROR-SW
               END-IF
           END-IF.

       2823-CHECK-TO-FROM-C-X.
           EXIT.
      *
      *--------------------
       3000-FORMAT-TOP-LINE.
      *--------------------

           MOVE HOLD-POL-ID-BASE      TO MIR-POL-ID-BASE.
           MOVE HOLD-POL-ID-SFX       TO MIR-POL-ID-SFX.
           MOVE COV-HOLD-R            TO MIR-CVG-NUM.
           MOVE EDATE-HOLD            TO MIR-CIA-EFF-DT.
013578* GET OWNER'S NAME
013578
013578     PERFORM  2430-1000-BUILD-PARM-INFO
013578         THRU 2430-1000-BUILD-PARM-INFO-X.
013578
013578     MOVE MIR-POL-ID                    TO L2430-POL-ID.
013578     MOVE ZERO                          TO I.
013578
013578     PERFORM  2430-2100-GET-OWNER
013578         THRU 2430-2100-GET-OWNER-X.
013578
013578     IF  L2430-RETRN-OK
013578         INITIALIZE                        L0620-INPUT-PARM-INFO
013578         IF  L2430-CLI-SEX-COMPANY
013578             MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
013578         ELSE
013578             MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
013578             MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
013578             MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
013578             MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
013578         END-IF
013578         MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD
013578         PERFORM  0620-1000-FORMAT-SCREEN-NAME
013578             THRU 0620-1000-FORMAT-SCREEN-NAME-X
013578         MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM
013578     ELSE
013578         MOVE SPACES                    TO MIR-DV-OWN-CLI-NM
013578     END-IF.

013578     EVALUATE L6350-ALLOC-CD
013578
013578         WHEN 'A'
013578             SET WS-BUS-FCN-AMTAMT TO TRUE
013578
013578         WHEN 'B'
013578             SET WS-BUS-FCN-AMTPCT TO TRUE
013578
013578         WHEN 'C'
013578             SET WS-BUS-FCN-PCTPCT TO TRUE
013578
013578         WHEN OTHER
013578             SET WS-BUS-FCN-AMTAMT TO TRUE
013578
013578     END-EVALUATE.

020469     MOVE RPOL-POL-CRCY-CD         TO WS-POL-CRCY-CD.

       3000-FORMAT-TOP-LINE-X.
           EXIT.
      *
      *----------------------
       3100-MOVE-WS-TO-SCREEN.
      *----------------------
      *
           IF  L6350-FUND-CD (I) = SPACE
               MOVE ZEROES            TO WS-DV-FND-CTR-HOLD-N
013578         MOVE WS-DV-FND-CTR-HOLD TO MIR-DV-FND-CTR-T (I)
               MOVE SPACES            TO MIR-FND-ID-T (I)
               MOVE SPACES            TO MIR-DV-CFN-APROX-AMT-T (I)
               MOVE SPACES TO MIR-DV-FROM-FND-AMT-T (I)
               MOVE SPACES TO MIR-DV-TO-FND-AMT-T (I)
               MOVE SPACES            TO MIR-FIA-OUT-ALLOC-PCT-T (I)
               MOVE SPACES            TO MIR-FIA-IN-ALLOC-PCT-T (I)
020469         MOVE SPACES            TO MIR-FIA-CRCY-CD-T      (I)
020469         MOVE SPACES            TO MIR-CIA-CRCY-CD-T      (I)
020469         MOVE SPACES            TO MIR-DV-FIA-POL-CRCY-AMT-T  (I)
               GO TO 3100-MOVE-WS-TO-SCREEN-X
           END-IF.

           MOVE L6350-FUND-NUM (I)    TO WS-DV-FND-CTR-HOLD-N.
           MOVE WS-DV-FND-CTR-HOLD    TO MIR-DV-FND-CTR-T (I).
           MOVE L6350-FUND-CD (I)     TO MIR-FND-ID-T (I).
020874*    COMPUTE L0290-INPUT-NUMBER = L6350-FUND-VALUE (I)
020874*                                 * 100
020469*    MOVE L6350-FUND-VALUE (I)  TO L0290-INPUT-V02

020469     MOVE L6350-FND-CRCY-FND-VAL (I)
020469                                TO L0290-INPUT-V02.

008455     PERFORM  9004-FORMAT-FVAL-T
008455         THRU 9004-FORMAT-FVAL-T-X

020469     MOVE L6350-POL-CRCY-FND-VAL (I)
020469                                TO L0290-INPUT-V02.

020469     PERFORM  9005-FORMAT-POL-CRCY-FVAL-T
020469         THRU 9005-FORMAT-POL-CRCY-FVAL-T-X

           IF  (L6350-ALLOC-CD = 'A' OR
                L6350-ALLOC-CD = 'B')
020874*        COMPUTE L0290-INPUT-NUMBER = L6350-AMT-FROM-FND (I)
020874*                                     * 100
020874         MOVE L6350-AMT-FROM-FND (I) TO L0290-INPUT-V02
               PERFORM  9000-FORMAT-FAMT-T
008455             THRU 9000-FORMAT-FAMT-T-X
           END-IF.

           IF  L6350-ALLOC-CD = 'A'
           OR  L6350-ALLOC-CD = 'B'
020874*        COMPUTE L0290-INPUT-NUMBER = L6350-AMT-TO-FND (I) * 100
020874         MOVE L6350-AMT-TO-FND (I)  TO L0290-INPUT-V02
               PERFORM  9002-FORMAT-TAMT-T
008455             THRU 9002-FORMAT-TAMT-T-X
           END-IF.

           IF  L6350-ALLOC-CD = 'C'
020469*        MOVE L6350-PCT-FROM-FND (I)
020469*                               TO WS-PCNT-HOLD-N
020874*        MOVE WS-PCNT-HOLD      TO MIR-FIA-OUT-ALLOC-PCT-T (I)
020874         MOVE L6350-PCT-FROM-FND (I) TO L0290-INPUT-V04
020874         MOVE 4                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FIA-OUT-ALLOC-PCT-T (I)
020874                                    TO L0290-MAX-OUT-LEN
020469         MOVE WGLOB-DCML-SYMBL      TO L0290-DCML-SYMBL
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-FIA-OUT-ALLOC-PCT-T (I)
           END-IF.

           IF  (L6350-ALLOC-CD = 'C' OR
                L6350-ALLOC-CD = 'B')
020469*        MOVE L6350-FND-PCT-ALLOC (I)
020469*                               TO WS-PCNT-HOLD-N
020874*        MOVE WS-PCNT-HOLD-N    TO MIR-FIA-IN-ALLOC-PCT-T (I)
020874         MOVE L6350-FND-PCT-ALLOC (I) TO L0290-INPUT-V04
020874         MOVE 4                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-FIA-IN-ALLOC-PCT-T (I)
020874                                    TO L0290-MAX-OUT-LEN
020469         MOVE WGLOB-DCML-SYMBL      TO L0290-DCML-SYMBL
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-FIA-IN-ALLOC-PCT-T (I)
           END-IF.

020469*    RETRIEVE THE FUNDS CURRENCY CODE WHICH IS STORED BY
020469*    COUNTRY CODE ON THE CRCY TABLE

020469     PERFORM  8640-1000-BUILD-PARM-INFO
020469         THRU 8640-1000-BUILD-PARM-INFO-X.

020469     MOVE L6350-FUND-CD (I) TO L8640-FND-ID.

020469     PERFORM  8640-1000-GET-FND-CRCY-CD
020469         THRU 8640-1000-GET-FND-CRCY-CD-X.

020469     IF L8640-RETRN-OK
020469         MOVE L8640-FND-CRCY-CD TO MIR-FIA-CRCY-CD-T (I)
020469     ELSE
020469         MOVE SPACES            TO MIR-FIA-CRCY-CD-T (I)
020469     END-IF.

020469*    FOR EACH FUND, MOVE THE POLICY CURRENCY TO THE MIR

020469     MOVE WS-POL-CRCY-CD        TO MIR-CIA-CRCY-CD-T (I).

       3100-MOVE-WS-TO-SCREEN-X.
           EXIT.
      *
      *-------------------
       6050-FORMAT-FUND-NO.
      *-------------------

           MOVE I                     TO L6350-FUND-NUM (I).

       6050-FORMAT-FUND-NO-X.
           EXIT.
      *
      *------------------
       8000-MOVE-FS-TO-WS.
      *------------------

           MOVE LSEGF-CFN-REC-INFO (I) TO RFS-REC-INFO.

           MOVE RFS-FND-ID            TO L6350-FUND-CD (I).

           IF  L6350-ALLOC-CD = 'A'
           OR L6350-ALLOC-CD = 'B'
               MOVE ZEROS             TO L6350-AMT-FROM-FND (I)
           END-IF.

           IF  L6350-ALLOC-CD = 'A'
           OR L6350-ALLOC-CD = 'B'
               MOVE ZEROS             TO L6350-AMT-TO-FND (I)
           END-IF.

           IF  L6350-ALLOC-CD = 'B'
           OR L6350-ALLOC-CD = 'C'
               MOVE ZEROS             TO L6350-FND-PCT-ALLOC (I)
           END-IF.

           IF  L6350-ALLOC-CD = 'C'
               MOVE ZEROS             TO L6350-PCT-FROM-FND (I)
           END-IF.

           IF RFS-CFN-STAT-CD = 'A'
               ADD 1                 TO J
           END-IF.

       8000-MOVE-FS-TO-WS-X.
           EXIT.
012696*
012696*-----------------------
012696 8600-CHECK-REQUESTS-DEFER.
012696*-----------------------
012696*
012696     PERFORM 8170-1000-BUILD-PARM-INFO
012696        THRU 8170-1000-BUILD-PARM-INFO-X.
012696     MOVE LSEGF-INPUT-EFF-DT    TO L8170-EFF-DT.
012696     MOVE LSEGF-INPUT-CVG-NUM   TO L8170-CVG-NUM-N.
012696     MOVE LSEGF-INPUT-LOAD-AMT  TO L8170-TRAN-FEE-AMT.
012696     SET L8170-DEFR-ALLOWED           TO TRUE.
016109     SET L8170-XFER-OVRID-NO          TO TRUE.
012696*
012696     IF  LSEGF-INPUT-LOAD-FORCE-IND = 'Y'
012696         MOVE LSEGF-INPUT-LOAD-FORCE-IND
                                      TO L8170-TRXN-FEE-OVRID-IND
012696     ELSE
012696         MOVE 'N'               TO L8170-TRXN-FEE-OVRID-IND
012696     END-IF.
012696*
012696     IF  L6350-SUPPRESS-CONFIRM
012696         MOVE 'Y'               TO L8170-SUPR-CONF-IND
012696     ELSE
012696         MOVE 'N'               TO L8170-SUPR-CONF-IND
012696     END-IF.
012696*
012696     EVALUATE TRUE
012696         WHEN L6350-ALLOC-CD = 'A'
012696             MOVE 'H'           TO L8170-TRAN-AMT-ALLOC-CD
012696         WHEN L6350-ALLOC-CD = 'B'
012696             MOVE 'I'           TO L8170-TRAN-AMT-ALLOC-CD
012696         WHEN L6350-ALLOC-CD = 'C'
012696             MOVE 'J'           TO L8170-TRAN-AMT-ALLOC-CD
012696     END-EVALUATE.
012696*
012696     SET LFUND-ACTV-TRANSFER          TO TRUE.
012696     MOVE ZERO                  TO LFUND-FND-CTR.
012696     PERFORM

               VARYING J FROM 1 BY 1
012696           UNTIL J > LSEGF-FIA-REC-CTR

012696             ADD +1                       TO LFUND-FND-CTR
012696             INITIALIZE LFUND-FND-INFO (LFUND-FND-CTR)
012696             MOVE LSEGF-INPUT-CVG-NUM
                                      TO LFUND-CVG-NUM-N (LFUND-FND-CTR)
012696             MOVE LSEGF-INPUT-FND-ID (J)
                                      TO LFUND-FND-ID (LFUND-FND-CTR)
012696             MOVE LSEGF-FIA-REC-INFO (J)
                                      TO RFD-REC-INFO
012696             EVALUATE TRUE

012696                 WHEN RFD-FIA-IN-ALLOC-PCT NOT = ZERO
012696                     SET LFUND-ALLOC-PERCENT (LFUND-FND-CTR)
                                                                 TO TRUE
012696                     MOVE RFD-FIA-IN-ALLOC-PCT
                                      TO LFUND-ALLOC-PCT (LFUND-FND-CTR)
012696                     MOVE RFD-FIA-FND-TRXN-AMT
                                      TO LFUND-ALLOC-AMT (LFUND-FND-CTR)
012696
012696                 WHEN RFD-FIA-VALU-SURR-PCT NOT = ZERO
012696                     SET LFUND-ALLOC-PERCENT (LFUND-FND-CTR)
                                                                 TO TRUE
012696                     MOVE RFD-FIA-VALU-SURR-PCT
                                      TO LFUND-ALLOC-PCT (LFUND-FND-CTR)
016194                     COMPUTE LFUND-ALLOC-PCT (LFUND-FND-CTR) =
016194                             LFUND-ALLOC-PCT (LFUND-FND-CTR) * -1
012696                    MOVE RFD-FIA-FND-TRXN-AMT
                                      TO LFUND-ALLOC-AMT (LFUND-FND-CTR)
012696
012696                 WHEN RFD-FIA-FND-TRXN-AMT NOT = ZERO
012696                     SET LFUND-ALLOC-AMOUNT (LFUND-FND-CTR)
                                                                 TO TRUE
016392                     IF LSEGF-INPUT-LOAD-FORCE-IND = 'Y'
012696                        MOVE RFD-FIA-FND-TRXN-AMT
                                      TO LFUND-ALLOC-AMT (LFUND-FND-CTR)
016392                     ELSE
016392                        MOVE LSEGF-INPUT-ALLOC-AMT(J)
016392                                TO LFUND-ALLOC-AMT (LFUND-FND-CTR)
016392                     END-IF
012696
012696             END-EVALUATE

012696             IF  LFUND-ALLOC-AMT (LFUND-FND-CTR) = ZERO
012696             AND LFUND-ALLOC-PCT (LFUND-FND-CTR) = ZERO
012696                 SUBTRACT 1               FROM LFUND-FND-CTR
012696             END-IF

012696     END-PERFORM.
012696*
012696     PERFORM 8170-1000-CHECK-TRANS-DEFER
012696        THRU 8170-1000-CHECK-TRANS-DEFER-X.
012696*
012696 8600-CHECK-REQUESTS-DEFER-X.
012696     EXIT.
      *
012696*-----------------------
012696 8700-DEFER-REQUEST.
012696*-----------------------
012696*
012696     PERFORM 8170-2000-DEFER-TRANSACTION
012696        THRU 8170-2000-DEFER-TRANSACTION-X.
012696*
012696     IF  L8170-RETRN-OK
012696*MSG: THIS SURRENDER HAS BEEN DEFERRED
012696         MOVE 'SS00700028'      TO WGLOB-MSG-REF-INFO
012696         PERFORM 0260-1000-GENERATE-MESSAGE
012696            THRU 0260-1000-GENERATE-MESSAGE-X
012696     END-IF.
012696*
012696 8700-DEFER-REQUEST-X.
012696     EXIT.
      *
008455*-------------------
008455 9000-FORMAT-FAMT-T.
008455*-------------------
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-FROM-FND-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-FROM-FND-AMT-T (I).
008455 9000-FORMAT-FAMT-T-X.
008455     EXIT.
008455*
008455*-------------------
008455 9002-FORMAT-TAMT-T.
008455*-------------------
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-TO-FND-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-TO-FND-AMT-T (I).
008455 9002-FORMAT-TAMT-T-X.
008455     EXIT.
008455*
008455*-------------------
008455 9004-FORMAT-FVAL-T.
008455*-------------------
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-CFN-APROX-AMT-T (I)
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-CFN-APROX-AMT-T (I).
008455 9004-FORMAT-FVAL-T-X.
008455     EXIT.
      *
      *----------------------------
020469 9005-FORMAT-POL-CRCY-FVAL-T.
      *----------------------------
020469     MOVE 2                     TO L0290-PRECISION.
020469     MOVE LENGTH OF MIR-DV-FIA-POL-CRCY-AMT-T (I)
020469                                TO L0290-MAX-OUT-LEN.
020469     PERFORM 0290-2000-FORMAT-FOR-MIR
020469        THRU 0290-2000-FORMAT-FOR-MIR-X.
020469     MOVE L0290-OUTPUT-DATA     TO MIR-DV-FIA-POL-CRCY-AMT-T (I).
020469 9005-FORMAT-POL-CRCY-FVAL-T-X.
020469     EXIT.
012696*
      *---------------------
020469 9100-POL-TO-FND-CRCY.
      *---------------------

020469     PERFORM  8640-1000-BUILD-PARM-INFO
020469         THRU 8640-1000-BUILD-PARM-INFO-X.

020469     MOVE L6350-FUND-CD (I)   TO L8640-FND-ID.

020469     PERFORM  8640-1000-GET-FND-CRCY-CD
020469         THRU 8640-1000-GET-FND-CRCY-CD-X.

020469     IF NOT L8640-RETRN-OK
020469*MSG: ERROR READING THE FH TABLE FOR FUND @1
020469         MOVE 'SS00700031'       TO WGLOB-MSG-REF-INFO
020469         MOVE L8640-FND-ID       TO WGLOB-MSG-PARM (1)
020469         PERFORM  0260-1000-GENERATE-MESSAGE
020469             THRU 0260-1000-GENERATE-MESSAGE-X
020469         GO TO 9100-POL-TO-FND-CRCY-X
020469     END-IF.

020469     PERFORM  8695-1000-BUILD-PARM-INFO
020469         THRU 8695-1000-BUILD-PARM-INFO-X.

020469     MOVE WS-REQIR-CNVR-AMT          TO L8695-REQIR-CNVR-AMT.
020469     MOVE RPOL-POL-CRCY-CD           TO L8695-XCHNG-FROM-CRCY-CD.
020469     MOVE L8640-FND-CRCY-CD          TO L8695-XCHNG-TO-CRCY-CD.
020469     MOVE LSEGF-INV-CVG-CFN-EFF-DT   TO L8695-XCHNG-EFF-DT.
020469     SET  L8695-XCHNG-RT-TYP-REAL    TO TRUE.

020469     PERFORM  8695-1000-CRCY-CNVR
020469         THRU 8695-1000-CRCY-CNVR-X.

020469     IF NOT L8695-RETRN-OK
020469         SET WGLOB-RETURN-ERROR  TO TRUE
020469         GO TO 9100-POL-TO-FND-CRCY-X
020469     END-IF.

020469 9100-POL-TO-FND-CRCY-X.
020469     EXIT.
      *
      *-------------------------
       9300-SETUP-MSIN-REFERENCE.
      *-------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                   TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      *
021311*--------------------------
021311 9990-INIT-WORKING-STORAGE.
021311*--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
021311
025970     PERFORM  0201-0000-INIT-PARM-INFO
025970         THRU 0201-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0410-0000-INIT-PARM-INFO
025970         THRU 0410-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0500-0000-INIT-PARM-INFO
025970         THRU 0500-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2600-0000-INIT-PARM-INFO
025970         THRU 2600-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2735-0000-INIT-PARM-INFO
025970         THRU 2735-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4750-0000-INIT-PARM-INFO
025970         THRU 4750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4780-0000-INIT-PARM-INFO
025970         THRU 4780-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6330-0000-INIT-PARM-INFO
025970         THRU 6330-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6350-0000-INIT-PARM-INFO
025970         THRU 6350-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8170-0000-INIT-PARM-INFO
025970         THRU 8170-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8640-0000-INIT-PARM-INFO
025970         THRU 8640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8695-0000-INIT-PARM-INFO
025970         THRU 8695-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WS-TWRK-FIELDS.
025970     INITIALIZE HEADER-MISC-WORK-AREAS.
025970     INITIALIZE WS-INPUT-AREA.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
021311     INITIALIZE LSEGF-PARM-INFO.

025970     SET REQUEST-NAME-DEFAULT      TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT       TO TRUE.
021311     SET FTRS-NO-CALL              TO TRUE.
021311     SET WS-REBUILD-AFTER-UNDO-NO  TO TRUE.
025970     MOVE SPACES                   TO WWKDT-WORK-FIELDS.

025970     MOVE MIR-BUS-FCN-ID           TO WS-BUS-FCN-ID.
021311
021311 9990-INIT-WORKING-STORAGE-X.
021311     EXIT.
021311*
      *****************************************************************
      * PROCESSING COPYBOOKS
      *****************************************************************

026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
025970 COPY SCPS0410.
025970 COPY SCPS6330.
       COPY CCPSPGA.
      *
       COPY NCPPCVGR.
       COPY NCPPCVGS.
      *
       COPY XCPPINIT.
       COPY XCPPEXIT.
      *
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      *
      *********** LINKAGE SECTIONS ********

020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY CCPS0620.
013578 COPY CCPL0620.
      *
016108 COPY CCPS0985.
018764*COPY CCCL0985.
018764 COPY CCPL0985.
016108*
       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      *
019573 COPY CCPS2600.
019573 COPY CCPL2600.
557701*
557701 COPY CCPS4750.
018764*COPY CCCL4750.
018764 COPY CCPL4750.
      *
018764*COPY CCCL0201.
025970 COPY CCPS0201.
018764 COPY CCPL0201.
      *
020463 COPY CCPS2735.
020463 COPY CCPL2735.
020463/
016503 COPY CCPS4780.
018764*COPY CCCL4780.
018764 COPY CCPL4780.
      *
016503 COPY CCPS0289.
018764*COPY CCCL0289.
018764 COPY CCPL0289.
      *
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
012696*
012696 COPY FCPS8170.
018764*COPY FCCL8170.
018764 COPY FCPL8170.
      *
018764*COPY SCCL0410.
018764 COPY SCPL0410.
      *
018764*COPY SCCL0500.
025970 COPY SCPS0500.
018764 COPY SCPL0500.
      *
       COPY SCPS6350.
018764*COPY SCCL6350.
018764 COPY SCPL6350.
      *
013578*COPY XCPS2510.
013578*COPY XCCL2510.
013578*
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
025970 COPY XCPS0280.
       COPY XCPL0280.
008455 COPY XCPL0290.
008455 COPY XCPS0290.
013578 COPY XCPS8090.
008455*
020469 COPY XCPS8640.
020469 COPY XCPL8640.
      *
020469 COPY XCPS8695.
020469 COPY XCPL8695.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
      ************* IO/CR SECTIONS *********
       COPY CCPNCVG.
       COPY CCPUCVG.
      *
       COPY CCPNPOL.
557701 COPY CCPUPOL.
      *
      *****************************************************************
      * ERROR HANDLING ROUTINES
      *****************************************************************

026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM SSOM0070                     **
      *****************************************************************
