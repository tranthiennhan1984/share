      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM2573.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM2573                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE DELETE RECORD FUNCTION  **
      **            FOR THE PLIP TABLE                               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
020463**  6.4       INVESTOR PROFILES                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2573'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-DELETE            VALUE '2573'.
           05  WS-TRMN-POL-SW                   PIC X(01).
               88  WS-TRMN-POL-EXIST            VALUE 'Y'.
               88  WS-TRMN-POL-NOT-EXIST        VALUE 'N'.

       01  WS-CONSTANT-AREA.
           05  WS-TWRK-KEY                      PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT          VALUE '2573'.
025970*                                         VALUE '2573'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWL8090.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY CCFWPH.
       COPY CCFRPH.
      /
       COPY CCFWPLIP.
       COPY CCFRPLIP.
      /
       COPY CCFWPOIR.
       COPY CCFRPOIP.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
      *****************************************************************
      *  INPUT PARAMETER INFORMATION                                  *
      *****************************************************************
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2573.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.
           SET WS-TRMN-POL-NOT-EXIST      TO TRUE.
      *
      *   CHECK ENTER CODE FOR FUNCTION REQUESTED
      *
           EVALUATE TRUE

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  2000-DELETE
                        THRU 2000-DELETE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM2573'           TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'         TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-DELETE.
      *------------

           PERFORM  2100-EDIT-KEY-FIELDS
               THRU 2100-EDIT-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-DELETE-X
           END-IF.

      *
      *  THE RECORD MUST EXIST, AND HAVE A CURRENT TIMESTAMP
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  PLIP-2000-UPDATE-TWRK-TS
               THRU PLIP-2000-UPDATE-TWRK-TS-X.

           IF  WPLIP-IO-NOT-FOUND
      *MSG: 'RECORD (@1) ON TABLE (@2) NOT FOUND. DELETE FAILED'
               MOVE WPLIP-KEY             TO WGLOB-MSG-PARM (1)
               MOVE 'TPLIP'               TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000010'          TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-DELETE-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG: 'PROCESS FAILED - RE-ENTER DATA AS ANOTHER PROCESS HAS
      *      UPDATED - TABLE (@1), KEY @2'
               MOVE 'XS00000303'          TO WGLOB-MSG-REF-INFO
               MOVE 'PLIP'                TO WGLOB-MSG-PARM (1)
               MOVE WPLIP-KEY             TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-DELETE-X
           END-IF.

           PERFORM  2200-XEDIT-DATA-FIELDS
               THRU 2200-XEDIT-DATA-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-DELETE-X
           END-IF.

      *
      *  DELETE THE RECORD AND AUDIT THE CHANGE
      *
           PERFORM  PLIP-1000-DELETE
               THRU PLIP-1000-DELETE-X.

      *MSG: RECORD DELETED SUCCESSFULLY - CONTINUE

           MOVE 'XS00000011'           TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
               
           PERFORM 9000-BLANK-DATA-FIELDS
              THRU 9000-BLANK-DATA-FIELDS-X.

       2000-DELETE-X.
           EXIT.

      *-----------------------
       2100-EDIT-KEY-FIELDS.
      *-----------------------

           MOVE MIR-PLAN-ID              TO  WPH-PLAN-ID.

           PERFORM  PH-1000-READ
               THRU PH-1000-READ-X.

           IF  WPH-IO-NOT-FOUND
      *MSG: RECORD @1 NOT FOUND
               MOVE WPH-KEY              TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 2100-EDIT-KEY-FIELDS-X
           END-IF.

       2100-EDIT-KEY-FIELDS-X.
           EXIT.

      *-----------------------
       2200-XEDIT-DATA-FIELDS.
      *-----------------------

      *  CHECK NO POLICY IS USING THE PLAN INVESTOR PROFILE

           MOVE LOW-VALUES               TO WPOIR-KEY.
           MOVE HIGH-VALUES              TO WPOIR-ENDBR-KEY

           MOVE RPLIP-PRFL-ID            TO WPOIR-PRFL-ID.
           MOVE RPLIP-PRFL-ID            TO WPOIR-ENDBR-PRFL-ID.

           PERFORM  POIR-4000-BROWSE-INDEX
               THRU POIR-4000-BROWSE-INDEX-X.

           PERFORM  POIR-5000-READ-NEXT-INDEX
               THRU POIR-5000-READ-NEXT-INDEX-X.
               
           PERFORM  2300-XEDIT-POL
               THRU 2300-XEDIT-POL-X
               UNTIL NOT WPOIR-IO-OK
                  OR RPOL-POL-STAT-PENDING
                  OR RPOL-POL-STAT-IN-FORCE
               
           PERFORM  POIR-6000-END-BROWSE-INDEX
               THRU POIR-6000-END-BROWSE-INDEX-X.

       2200-XEDIT-DATA-FIELDS-X.
           EXIT.
      /
      *---------------
       2300-XEDIT-POL.
      *---------------
      
           MOVE RPOIP-POL-ID             TO WPOL-POL-ID
               
           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.
                   
           IF WPOL-IO-OK
               
               IF RPOL-POL-STAT-PENDING
               OR RPOL-POL-STAT-IN-FORCE
      *MSG: PLAN/PROFILE (@1) ATTACHED TO A NON-TERMINATED
      *     POLICY..CANNOT DELETE.
                   MOVE WPLIP-KEY    TO WGLOB-MSG-PARM (1)
                   MOVE 'CS25730001' TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 1            TO WGLOB-MSG-ERROR-SW
                   GO TO 2300-XEDIT-POL-X
               END-IF
                   
           END-IF.
               
           PERFORM  POIR-5000-READ-NEXT-INDEX
               THRU POIR-5000-READ-NEXT-INDEX-X.

       2300-XEDIT-POL-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE MIR-PLAN-ID              TO WPLIP-PLAN-ID.
           MOVE MIR-PRFL-ID              TO WPLIP-PRFL-ID.
           MOVE MIR-SBSDRY-CO-ID         TO WPLIP-SBSDRY-CO-ID.
           MOVE MIR-LOC-GR-ID            TO WPLIP-LOC-GR-ID.

       7000-BUILD-KEYS-X.
           EXIT.

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-INPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                    TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE        TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      /
      *---------------------------
       9990-INIT-WORKING-STORAGE.
      *---------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     SET WS-TWRK-KEY-DEFAULT   TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
025970     SET  MIR-RETRN-OK                TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.


      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  PLIP
                                '$VAR2'   BY 'PLIP'.
       COPY XCPL8090.
025970 COPY XCPS8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPBPOIR.
      /
       COPY CCPNPH.
      /
       COPY CCPNPLIP.
       COPY CCPUPLIP.
       COPY CCPXPLIP.
      /
       COPY CCPNPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2573                     **
      *****************************************************************
