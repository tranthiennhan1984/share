      *************************
       IDENTIFICATION DIVISION.
      *************************


       PROGRAM-ID.    CSOM0381.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM0381                                         **
      **  REMARKS:  RECD/REDI-MAINTAINS REINSURANCE COVERAGE DETAILS.**
      **            RECD (REINSURANCE COVERAGE DETAILS-LIFE) SCREEN  **
      **            IS USED TO UPDATE THE RI (REINSURANCE CESSION)   **
      **            FILE. REINSURANCE DETAILS FOR DISABILITY INCOME  **
      **            COVERAGES AND BENEFITS SHOULD BE MAINTAINED      **
      **            USING THE REDI TRANSACTION WHICH EXECUTES THIS   **
      **            PROGRAM AS WELL.                                 **
      **            IN ORDER TO WORK WITH REINSURANCE CESSIONS, AN   **
      **            INQUIRE, CREATE, MAINTAIN AND A DELETE FUNCTIONS **
      **            ARE AVAILABLE ON THIS SCREENS.                   **
      **            OTHER SUB-FUNCTIONS ARE:                         **
      **            -AUTOMATIC ASSIGNMENT OF REINSURANCE NUMBER      **
      **             UPON CREATION                                   **
      **            -VARIOUS REINSURANCE CALCULATIONS ENGAGE UPON    **
      **             MODIFICATION OF A CESSION                       **
      **                                                             **
      **  DOMAIN :  RI                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
550417**  5.5       REMOVE MESSAGE CS03810001 FOR CREATE.            **
556984**  5.5       MOVE ZEROES TO FIELD IF NO VALUE ENTERED         **
557659**  5.5       DATA ARCHITECTURE MODIFICATIONS                  **
557668**  5.5       SELECTION LIST (CLIENT SCRATCHPAD)               **
557708**  5.5       HANDLING OF CICS ABEND                           **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010418**  5.6       ADD SUB-CO TO THE TT-TABLE KEY.                  **
012624**  6.0       POLICY ACCESS VERIFICATION                       **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014221**  6.2       LOGICAL RECORD LOCKING                           **
014591**  6.2       COMBINE PLAN ID AND RATE SCALE                   **
016440**  6.2       COMBINE NB AND ADMIN - ONLINE REQUIREMENTS       **
016537**  6.2       CODE CLEAN UP                                    **
017190**  6.2       SET CORRECT INSURED NAME ON CESSION SCREENS      **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
019507**  6.4       ADD NEW FIELDS TO REINSURANCE DISPLAY            **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
024767**  6.7       REINSURANCE CESSION RECORD NO DFLT OF ALLOW ID   **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
029672**  7.1       PROBLEMS WITH SESSION CREATE AND UPDATE          **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM0381'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
007766 COPY XCWWCVGM.
025970
025970 01  WS-CONSTANTS.
025970     03  WS-TRANS-NAME               PIC X(04).
025970         88  WS-TRANS-NAME-DEFAULT   VALUE 'RECD'.
025970     03  NUM-ERR-LN                  PIC 99.
025970         88 NUM-ERR-LN-DEFAULT       VALUE 03.
025970     03  WS-TWRK-KEY                 PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT     VALUE  '1330'.
025970     03  MAX-REINSURED               PIC 99.
025970         88 MAX-REINSURED-DEFAULT    VALUE 9.
       01  WS-PGM-WORK-AREA.
025970*    03  TRANSACTION-NAME   PIC X(04)  VALUE 'RECD'.
025970*    03  NUM-ERR-LN         PIC 99     VALUE 03.
           03  NUMERIC-ATTR-BYTE  PIC X.
           03  ALPHA-ATTR-BYTE    PIC X.
           03  WS-BUS-FCN-ID      PIC X(4).
               88  WS-BUS-FCN-RETRIVE        VALUE  '1330'.
               88  WS-BUS-FCN-UPDATE         VALUE  '1332'.
               88  WS-BUS-FCN-CREATE         VALUE  '1331'.
               88  WS-BUS-FCN-DELETE         VALUE  '1333'.
025970*    03  WS-TWRK-KEY        PIC X(04)  VALUE  '1330'.

      /
      *****************************************************************
      * COMMON COPYBOOKS
      *****************************************************************

       COPY XCWEBLCH.
016537*COPY XCWWWKDT.
       COPY CCWWRIDF.
      /
       01  MC-MISC-WORK-AREAS.
           03  HOLD-FORCE               PIC X.

       01  LITTLE-WORK-AREAS.
           03  HOLD-RIDER-NO            PIC 99.
           03  R-HOLD-RIDER-NO REDEFINES HOLD-RIDER-NO
                                        PIC XX.
           03  TOTAL-REIN               PIC 99.
025970*    03  MAX-REINSURED            PIC 99  VALUE 9.
           03  HOLD-REIN-NO             PIC 99.
           03  HOLD-REIN-NO-X REDEFINES HOLD-REIN-NO
                                        PIC XX.
           03  PREV-PAID-TO-DATE        PIC X(10).
007766*    03  I                        PIC 99.
007766     03  I                        PIC 9(4).
           03  HOLD-I2                  PIC 99.
           03  J                        PIC 99.
           03  K                        PIC 99.
           03  ERROR-NUM                PIC 99.
           03  ERR-BIT                  PIC X.
           03  POLICY-HOLD.
               05  POLICY-FIRST         PIC X.
               05  POLICY-MID           PIC X(8).
               05  POLICY-LAST          PIC X.
           03  WORK-AMOUNT              PIC S9(9)V99 COMP-3.
025970*    03  HOLD-RUN-ID              PIC X   VALUE '0'.
025970     03  HOLD-RUN-ID              PIC X.
025970         88  HOLD-RUN-ID-DEFAULT  VALUE '0'.
       01  WS-PROGRAM-CONTROL-SWITCHES.
           05  WS-ERROR-SWITCH              PIC X(01).
               88  WS-EDIT-ERROR            VALUE 'Y'.
               88  WS-NO-EDIT-ERROR         VALUE 'N'.
           05  WS-RESTRICT-ERRORS-SW        PIC X(01).
               88  WS-RESTRICT-ERRORS       VALUE 'Y'.

       01  WS-NUMBER-EDITING.
           05  WS-DISP-S1V2.
               10  WS-HOLD-S1V2             PIC +9.99.
           05  WS-DISP-3V0.
               10  WS-HOLD-3V0              PIC 9(03).
008455*    05  WS-DISP-S3V2.
008455*        10  WS-HOLD-S3V2             PIC +9(03).99.
           05  WS-DISP-3V2.
               10  WS-HOLD-3V2              PIC 9(03).99.
008455*    05  WS-DISP-5V2.
008455*        10  WS-HOLD-5V2              PIC 9(05).99.
008455*    05  WS-DISP-7V0.
008455*        10  WS-HOLD-7V0              PIC 9(07).
008455*    05  WS-DISP-S7V2.
008455*        10  WS-HOLD-S7V2             PIC +9(07).99.
008455*    05  WS-DISP-7V2.
008455*        10  WS-HOLD-7V2              PIC 9(07).99.
008455*    05  WS-DISP-9V2.
008455*        10  WS-HOLD-9V2              PIC 9(09).99.

       01  WS-STATUS-CODE                   PIC X.
           88  VALID-STATUS-CODE               VALUES '1' '2' '3' '4'
                                                      'A' 'B' 'D' 'E'
                                                      'F' 'H' 'I' 'P'
                                                      'R' 'T' 'W' 'X'.
      ****************************************************************
      * I/O COPYBOOKS
      ****************************************************************

       COPY CCFWPOL.
      /
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFWRI.
       COPY CCFRRI.
      /
       COPY CCFWTT.
       COPY CCFRTT.
      /
      *****************************************************************
      * CALLED MODULE INFORMATION
      *****************************************************************

028298 COPY CCWL2626.
008455 COPY XCWL0290.
008455/
       COPY CCWL2430.
       COPY CCWL2435.
      /
       COPY CCWL0384.
       COPY CCWL0389.
      /
       COPY CCWL5400.
      /
557668 COPY CCWL0620.
557668/
       COPY XCWLDTLK.
       COPY XCWL1640.
014221 COPY XCWL8090.
014221 COPY CCWWLOCK.
      /
      ******************************************************************
      * INPUT PARAMETER INFORMATION
      ******************************************************************
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
       COPY CCWLPGA.
      /
       COPY CCFRPOL.
      /
       COPY CCWWCVGS.
      /
      ******************
       LINKAGE SECTION.
      ******************

CVMQ71 COPY XCWWDFHQ.

007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM0381.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

008455     PERFORM 0290-1000-BUILD-PARM-INFO
008455        THRU 0290-1000-BUILD-PARM-INFO-X.
008455

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.


      *
      *  VERIFY USER ACCESS TO RECD (REDI)
      *

           MOVE MIR-POL-ID-BASE       TO POLICY-HOLD.
           MOVE MIR-POL-ID-SFX        TO POLICY-LAST.
           MOVE POLICY-HOLD           TO WPOL-POL-ID.
           MOVE MIR-CVG-NUM           TO R-HOLD-RIDER-NO.
           MOVE MIR-CSN-REC-NUM       TO HOLD-REIN-NO-X.


      *  BUILD GENERAL PARM AREA AND VALIDATE RECD (REDI) KEY FORMAT

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  2200-VALID-KEY-FORMAT
               THRU 2200-VALID-KEY-FORMAT-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

      *  READ POLICY
           PERFORM  2300-READ-AND-CHECK
               THRU 2300-READ-AND-CHECK-X.

           IF  WGLOB-RETURN-ERROR
014221         IF  ((WS-BUS-FCN-UPDATE
014221          OR   WS-BUS-FCN-DELETE)
014221          AND NOT MIR-RETRN-TS-MISMATCH)
014221                  PERFORM  POL-3000-UNLOCK
014221                      THRU POL-3000-UNLOCK-X
014221         END-IF
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

      *  READ COVERAGE
           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.
           MOVE WCVGS-CVG-CSN-REC-CTR-N (HOLD-RIDER-NO)
                                      TO TOTAL-REIN.

      *  READ REINSURANCE FILE
           IF  NOT WS-BUS-FCN-CREATE
               PERFORM  8000-READ-REINSURANCE-IN
                   THRU 8000-READ-REINSURANCE-IN-X
               IF  NOT WRI-IO-OK
      *MSG: REINSURANCE RECORD NOT FOUND
                   MOVE 'CS03810003'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 2000-PROCESS-REQUEST-X
               END-IF
           END-IF.
      *
      * PROCESS APPROPRIATE FUNCTION
      *
           EVALUATE TRUE
               WHEN WS-BUS-FCN-RETRIVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X
               WHEN WS-BUS-FCN-CREATE
                    PERFORM  4000-PROCESS-CREATE
                        THRU 4000-PROCESS-CREATE-X
               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5000-MAINTAIN
                        THRU 5000-MAINTAIN-X
               WHEN WS-BUS-FCN-DELETE
                    PERFORM  6000-DELETE
                        THRU 6000-DELETE-X
               WHEN OTHER
      *MSG: INVALID FUNCTION ID - PROCESSING STOPPED
                    MOVE MIR-BUS-FCN-ID           TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM0381'               TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.


       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------
       2200-VALID-KEY-FORMAT.
      *----------------------

      *  VALID COVERAGE NUMBER AND RESINSURANCE NUMBER
           IF R-HOLD-RIDER-NO NOT NUMERIC
           OR HOLD-RIDER-NO < 1
007766*    OR HOLD-RIDER-NO > 20
007766     OR HOLD-RIDER-NO > WCVGM-MAX-WCVGS-NUM
007766*MSG: COVERAGE NUMBER MUST BE 01 TO 20
007766*MSG: COVERAGE NUMBER MUST BE 01 TO @1
               MOVE 'CS03810006'      TO WGLOB-MSG-REF-INFO
007766         MOVE WCVGM-MAX-WCVGS-NUM
                                      TO  WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR   TO TRUE
               GO TO 2200-VALID-KEY-FORMAT-X
           END-IF.

           IF HOLD-REIN-NO-X NOT NUMERIC
           OR HOLD-REIN-NO < 1
           OR HOLD-REIN-NO > MAX-REINSURED
      *MSG: REINSURANCE NUM MUST BE A VALID NUMERIC IN THE RANGE 01-09
               MOVE 'CS03810005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR   TO TRUE
           END-IF.

       2200-VALID-KEY-FORMAT-X.
           EXIT.

      *--------------------
       2300-READ-AND-CHECK.
      *--------------------

014221*    PERFORM  POL-1000-READ
014221*        THRU POL-1000-READ-X.

014221     EVALUATE TRUE
014221        WHEN WS-BUS-FCN-UPDATE
014221        WHEN WS-BUS-FCN-DELETE
014221             PERFORM  POL-2000-UPDATE-TWRK-TS
014221                 THRU POL-2000-UPDATE-TWRK-TS-X
014221             IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221                 MOVE 'XS00000303'   TO WGLOB-MSG-REF-INFO
014221                 MOVE 'POL'          TO WGLOB-MSG-PARM (01)
014221                 MOVE WPOL-KEY       TO WGLOB-MSG-PARM (02)
014221                 PERFORM  0260-1000-GENERATE-MESSAGE
014221                     THRU 0260-1000-GENERATE-MESSAGE-X
014221                 SET WGLOB-RETURN-ERROR     TO TRUE
014221                 GO TO 2300-READ-AND-CHECK-X
014221             END-IF
014221        WHEN OTHER
014221             PERFORM  POL-1000-READ-TWRK-TS
014221                 THRU POL-1000-READ-TWRK-TS-X
014221     END-EVALUATE.

           IF  NOT WPOL-IO-OK
      *MSG: POLICY NOT ON FILE
               MOVE 'CS00000019'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  WGLOB-RETURN-ERROR TO TRUE
               GO TO 2300-READ-AND-CHECK-X
           END-IF.

           IF  HOLD-RIDER-NO > RPOL-POL-CVG-REC-CTR-N
      *MSG: COVERAGE RECORD MUST EXIST. RE-ENTER
               MOVE 'CS00000021'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET  WGLOB-RETURN-ERROR TO TRUE
               GO TO 2300-READ-AND-CHECK-X
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

012624*    SET L5400-SYS-APPL-CTL-ADMIN TO TRUE.

016440     IF  WS-BUS-FCN-CREATE
016440     OR  WS-BUS-FCN-UPDATE
016440     OR  WS-BUS-FCN-DELETE
016440         SET L5400-POL-XFER-UPDATE TO TRUE
016440     ELSE
016440         SET L5400-POL-XFER-INQ    TO TRUE
016440     END-IF.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-RETRN-OK
           AND (L5400-CNFD-ACCS-RESTRICTED
012624*    OR  L5400-CTL-ACCS-RESTRICTED
016440     OR  L5400-XFER-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED)
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

       2300-READ-AND-CHECK-X.
           EXIT.
      /
      *---------------------
       3000-PROCESS-RETRIEVE.
      *---------------------

           PERFORM 7000-MOVE-RECORD-TO-SCREEN
              THRU 7000-MOVE-RECORD-TO-SCREEN-X.


       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *-------------------
       4000-PROCESS-CREATE.
      *-------------------

           ADD 1                       TO TOTAL-REIN.

           IF  TOTAL-REIN GREATER THAN MAX-REINSURED
      *MSG: REINSURANCE RECORD LIMIT IS REACHED
               MOVE 'CS03810011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           MOVE  TOTAL-REIN           TO MIR-CSN-REC-NUM.
           MOVE  TOTAL-REIN           TO MIR-CVG-CSN-REC-CTR.
           MOVE  TOTAL-REIN           TO HOLD-REIN-NO.
           MOVE  TOTAL-REIN  TO WCVGS-CVG-CSN-REC-CTR-N (HOLD-RIDER-NO).
024767*  BUILD KEY OF NEW REINSURANCE RECORD
024767*    MOVE 'C'                   TO WRI-CSN-REC-TYP-CD.
024767*    MOVE RPOL-POL-ID           TO WRI-POL-ID.
024767*    MOVE HOLD-RIDER-NO         TO WRI-CVG-NUM-N.
024767*    MOVE HOLD-REIN-NO          TO WRI-CSN-REC-NUM-N.

024767*    PERFORM  RI-1000-CREATE
024767*        THRU RI-1000-CREATE-X.

      *  SET DEFAULT VALUES ON RECORD
024767*    MOVE MIR-ASSUM-CO-ID       TO RRI-ASSUM-CO-ID.
024767*    MOVE WCVGS-PLAN-ID (WRI-CVG-NUM-N)
024767     MOVE WCVGS-PLAN-ID (HOLD-RIDER-NO)           
                                      TO WTT-PLAN-ID.
024767*    MOVE WCVGS-CVG-SMKR-CD (WRI-CVG-NUM-N)
024767     MOVE WCVGS-CVG-SMKR-CD (HOLD-RIDER-NO)
                                      TO WTT-TRTY-SMKR-CD.
           MOVE MIR-ASSUM-CO-ID       TO WTT-TRTY-ASSUM-CO-ID.

010418     MOVE RPOL-SBSDRY-CO-ID     TO WTT-SBSDRY-CO-ID.
010418
           PERFORM  TT-1000-READ
               THRU TT-1000-READ-X.

           IF  NOT WTT-IO-OK
024767*        PERFORM  TT-1000-CREATE
024767*            THRU TT-1000-CREATE-X
024767*MSG: WARNING .... REIN TREATY NOT FOUND: @1
024767*MSG: REINSURANCE TREATY NOT FOUND: @1
024767         MOVE 'CS03810001'      TO WGLOB-MSG-REF-INFO
024767         MOVE WTT-KEY-INFO      TO WGLOB-MSG-PARM (1)
024767         PERFORM  0260-1000-GENERATE-MESSAGE
024767             THRU 0260-1000-GENERATE-MESSAGE-X
024767         GO TO 4000-PROCESS-CREATE-X
550417*        MOVE 'CS03810001'       TO WGLOB-MSG-REF-INFO
550417*        MOVE WTT-KEY-INFO       TO WGLOB-MSG-PARM (1)
550417*        PERFORM  0260-1000-GENERATE-MESSAGE
550417*           THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

024767*  BUILD KEY OF NEW REINSURANCE RECORD
024767     MOVE 'C'                   TO WRI-CSN-REC-TYP-CD.
024767     MOVE RPOL-POL-ID           TO WRI-POL-ID.
024767     MOVE HOLD-RIDER-NO         TO WRI-CVG-NUM-N.
024767     MOVE HOLD-REIN-NO          TO WRI-CSN-REC-NUM-N.

024767     PERFORM  RI-1000-CREATE
024767         THRU RI-1000-CREATE-X.

           MOVE WRI-CVG-NUM-N         TO WRIDF-CVG-NUM.
024767     MOVE MIR-ASSUM-CO-ID       TO RRI-ASSUM-CO-ID.

           PERFORM  RIDF-1000-SET-RI-DEFAULTS
               THRU RIDF-1000-SET-RI-DEFAULTS-X.

      *MSG: REINSURANCE RECORD CREATED ... CONTINUE
           MOVE 'CS03810004'          TO WGLOB-MSG-REF-INFO.
           MOVE '1332'                   TO MIR-BUS-FCN-ID.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

024767*
024767*  THE CO-ID HAS TO BE RESET BACK TO THE ORIGINAL SPACES THAT
024767*  IT WAS AFTER THE CREATE BECAUSE THE MIR FIELD HAS NOT BEEN
024767*  EDITED OR MOVED TO THE TABLE FIELD. THE COMPANY FIELD WAS
024767*  NEEDED TO GET THE TT TABLE INITIAL DEFAULTS.
024767*
024767*    MOVE SPACES                TO RRI-ASSUM-CO-ID.
      
      *  MOVE FIELDS TO SCREEN AND SET ATTRIBUTES
      *
           PERFORM  7000-MOVE-RECORD-TO-SCREEN
               THRU 7000-MOVE-RECORD-TO-SCREEN-X.

      *
      *  WRITE RI RECORD
      *
           PERFORM  RI-1000-WRITE
               THRU RI-1000-WRITE-X.

014221     MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID-BASE.
014221     MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.

014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.
      *
      *  UPDATE COVERAGE
      *
           MOVE HOLD-RIDER-NO         TO I.

           PERFORM  CVGR-2000-REWRITE-COVERAGE
               THRU CVGR-2000-REWRITE-COVERAGE-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *--------------
       5000-MAINTAIN.
      *--------------

      *  TEST THAT POLICY REINSURANCE INDICATOR IS ON

557659*    IF  RPOL-POL-REINS-IND = ' '
557659*    OR  RPOL-POL-REINS-IND = 'N'
029672*    IF  NOT RPOL-POL-REINS
029672     IF  RPOL-POL-REINS
029672     OR  RPOL-POL-REINS-AD-ONLY
029672         CONTINUE
029672     ELSE
      *MSG: REINSURANCE INDICATOR IS NOT 'Y' ON POLICY
               MOVE 'CS03810012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

               PERFORM  5200-PROCESS-UPDATE
                   THRU 5200-PROCESS-UPDATE-X.

       5000-MAINTAIN-X.
           EXIT.
      /
      *------------------------
       5200-PROCESS-UPDATE.
      *------------------------

           PERFORM  0389-1000-BUILD-PARM-INFO
               THRU 0389-1000-BUILD-PARM-INFO-X.

           MOVE HOLD-RIDER-NO         TO L0389-CVG-NUM.

           PERFORM  5300-SET-EDIT-AREA
               THRU 5300-SET-EDIT-AREA-X.

           PERFORM  0389-1000-EDIT-CALC-MAINTAIN
               THRU 0389-1000-EDIT-CALC-MAINTAIN-X.

           IF  L0389-ERRORS-FOUND
               PERFORM  5400-CHECK-EDIT-AREA
                   THRU 5400-CHECK-EDIT-AREA-X
           END-IF.

           IF  WS-RESTRICT-ERRORS
      *MSG: CANNOT ENTER PREMIUMS UNLESS RI PREM IS RESTRICTED
               MOVE 'CS03810063'      TO WGLOB-MSG-REF-INFO
               SET WS-EDIT-ERROR       TO TRUE
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  WS-EDIT-ERROR
               CONTINUE
           ELSE
               PERFORM  7000-MOVE-RECORD-TO-SCREEN
                   THRU 7000-MOVE-RECORD-TO-SCREEN-X
           END-IF.
      *
      *  UPDATE RECORDS
      *
           MOVE HOLD-RIDER-NO         TO I.

           PERFORM  CVGR-2000-REWRITE-COVERAGE
               THRU CVGR-2000-REWRITE-COVERAGE-X.

           PERFORM  RI-2000-REWRITE
               THRU RI-2000-REWRITE-X.
014221     PERFORM  POL-2000-REWRITE
014221         THRU POL-2000-REWRITE-X.
014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

       5200-PROCESS-UPDATE-X.
           EXIT.
      /
      *-------------------
       5300-SET-EDIT-AREA.
      *-------------------

      *  MOVE MIR FIELDS TO CORRESPONDING L0389 FIELDS

           MOVE MIR-DV-PREM-PD-YR-QTY TO L0389-TDUR.
           MOVE MIR-POL-ID-BASE            TO L0389-POLNO.
           MOVE MIR-POL-ID-SFX            TO L0389-SUFF.
           MOVE MIR-CVG-NUM           TO L0389-COVNO.
           MOVE MIR-CSN-REC-NUM       TO L0389-REINNUM.
           MOVE MIR-CVG-CSN-REC-CTR   TO L0389-TOTREIN.
013578*    MOVE MIR-BUS-FCN-ID             TO L0389-ENTER.
           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIVE
                    MOVE 'I'     TO L0389-ENTER
               WHEN WS-BUS-FCN-CREATE
                    MOVE 'C'     TO L0389-ENTER
               WHEN WS-BUS-FCN-UPDATE
                    MOVE 'M'     TO L0389-ENTER
               WHEN WS-BUS-FCN-DELETE
                    MOVE 'D'     TO L0389-ENTER

           END-EVALUATE.

017190*    MOVE MIR-DV-OWN-CLI-NM        TO L0389-TNAME.
017190     MOVE MIR-DV-INSRD-CLI-NM      TO L0389-TNAME.
014591*    MOVE MIR-PLAN-ID             TO L0389-TRPLAN.
014591     MOVE MIR-PLAN-ID             TO L0389-TR-PLAN-ID.
           MOVE MIR-CVG-CSTAT-CD             TO L0389-TRSTAT.
013578*    MOVE MIR-TRRTSC            TO L0389-TRRTSC.
           MOVE MIR-CVG-SMKR-CD       TO L0389-TSMOKE.
           MOVE MIR-CVG-PAR-CD        TO L0389-TPAR.
           MOVE MIR-CVG-SEX-CD        TO L0389-TSEX.
           MOVE MIR-CVG-STBL-1-CD     TO L0389-TQUAL.
           MOVE MIR-CVG-STBL-2-CD     TO L0389-TELIM.
           MOVE MIR-CVG-STBL-3-CD     TO L0389-TBENF.
           MOVE MIR-CVG-STBL-4-CD     TO L0389-TOCC.
           MOVE MIR-CVG-RT-AGE        TO L0389-TAGE.
           MOVE MIR-DV-PREM-PD-YR-QTY TO L0389-TDUR.
           MOVE MIR-CVG-FACE-AMT      TO L0389-FACE.
           MOVE MIR-CVG-BASIC-PREM-AMT                  TO L0389-ANNPRM.
           MOVE MIR-CVG-FE-PREM-AMT   TO L0389-FEPRM.
           MOVE MIR-CVG-FE-DUR        TO L0389-FEDUR.
           MOVE MIR-CVG-FE-REASN-CD   TO L0389-FERSN.
           MOVE MIR-CVG-ME-FCT        TO L0389-MULT.
           MOVE MIR-CVG-ME-DUR        TO L0389-MDUR.
           MOVE MIR-CVG-ME-REASN-CD   TO L0389-MRSN.
           MOVE MIR-INSRD-CLI-ID      TO L0389-CLIENT.
013578*    MOVE MIR-DIRET             TO L0389-DIRET.
014591*    MOVE MIR-CSN-PLAN-ID       TO L0389-PLANCD.
014591     MOVE MIR-CSN-PLAN-ID       TO L0389-PLAN-ID.
           MOVE MIR-CSN-SMKR-CD       TO L0389-SMOKE.
           MOVE MIR-CSN-PAR-CD        TO L0389-PAR.
           MOVE MIR-CSN-SEX-CD        TO L0389-SEX.
           MOVE MIR-CSN-RT-AGE        TO L0389-AGE.
           MOVE MIR-CSN-REINS-TYP-CD  TO L0389-TYPE.
           MOVE MIR-CSN-TRTY-TYP-CD   TO L0389-RTT.
           MOVE MIR-ASSUM-CO-ID       TO L0389-COMPANY.
           MOVE MIR-CSN-PREM-OFFST-DUR                  TO L0389-DUROFF.
           MOVE MIR-ASSUM-CO-REF-ID   TO L0389-CESSION.
           MOVE MIR-CSN-EFF-DT        TO L0389-EDATE.
           MOVE MIR-CSN-PD-TO-DT      TO L0389-PTDTE.
           MOVE MIR-CSN-MAT-XPRY-DT   TO L0389-MEDATE.
           MOVE MIR-REDC-EP-PREM-AMT  TO L0389-EPHPREM.
           MOVE MIR-REDC-EP-ALLOW-ID  TO L0389-EPHTRTY.
           MOVE MIR-DV-REDC-EP-ALLOW-AMT  TO L0389-EPHALL.
           MOVE MIR-OWN-OCCP-PREM-AMT TO L0389-OCCPREM.
           MOVE MIR-OWN-OCCP-ALLOW-ID TO L0389-OCCTRTY.
           MOVE MIR-DV-OWN-OCCP-ALLOW-AMT  TO L0389-OCCALL.
           MOVE MIR-CSN-LTA-PREM-AMT  TO L0389-LTAPREM.
           MOVE MIR-CSN-LTA-ALLOW-ID  TO L0389-LTATRTY.
           MOVE MIR-DV-LTA-ALLOW-AMT  TO L0389-LTAALL.
           MOVE MIR-CSN-LTB-PREM-AMT  TO L0389-LTBPREM.
           MOVE MIR-CSN-LTB-ALLOW-ID  TO L0389-LTBTRTY.
           MOVE MIR-DV-LTB-ALLOW-AMT  TO L0389-LTBALL.
           MOVE MIR-PDISAB-PREM-AMT   TO L0389-PDIPREM.
           MOVE MIR-PDISAB-ALLOW-ID   TO L0389-PDITRTY.
           MOVE MIR-DV-PDISAB-ALLOW-AMT  TO L0389-PDIALL.
           MOVE MIR-CSN-COLA-PREM-AMT TO L0389-COLPREM.
           MOVE MIR-CSN-COLA-ALLOW-ID TO L0389-COLTRTY.
           MOVE MIR-DV-COLA-ALLOW-AMT  TO L0389-COLALL.
           MOVE MIR-CSN-RSK-CALC-CD   TO L0389-RISKIND.
           MOVE MIR-CSN-ORIG-RSK-AMT  TO L0389-RISKAMT.
           MOVE MIR-CSN-LIFE-ALLOW-ID TO L0389-RITRTY.
           MOVE MIR-CSN-WP-FACE-AMT   TO L0389-WPFAMT.
           MOVE MIR-CSN-WP-ALLOW-ID   TO L0389-WPTRTY.
           MOVE MIR-CSN-AD-FACE-AMT   TO L0389-ADFAMT.
           MOVE MIR-CSN-AD-ALLOW-ID   TO L0389-ADTRTY.
           MOVE MIR-CSN-FE-FCT        TO L0389-FLATEX.
           MOVE MIR-CSN-FE-ALLOW-ID   TO L0389-EXTRTY.
           MOVE MIR-CSN-ME-FCT        TO L0389-MULTEX.
           MOVE MIR-CSN-ME-ALLOW-ID   TO L0389-MRTRTY.
           MOVE MIR-CSN-RETEN-AMT     TO L0389-RETAMT.
           MOVE MIR-BCK-BILL-REASN-CD TO L0389-BILLIND.
           MOVE MIR-BCK-BILL-PREM-AMT TO L0389-BBAMT.
           MOVE MIR-BCK-BILL-ALLOW-AMT                 TO L0389-BBALLOW.
           MOVE MIR-CSN-RESTR-PREM-IND                 TO L0389-RESTIND.
           MOVE MIR-CSN-TOT-NPREM-AMT TO L0389-TOTPREM.
           MOVE MIR-DV-TOT-VAR-PREM-AMT TO L0389-STPREM.
           MOVE MIR-CSN-CRNT-RSK-AMT  TO L0389-CRISK.
           MOVE MIR-CSN-RSK-DECR-AMT  TO L0389-DECRMNT.
           MOVE MIR-CSN-NPREM-YTD-AMT TO L0389-NETPREM.
           MOVE MIR-DV-LIFE-ALLOW-AMT  TO L0389-LIFALL.
           MOVE MIR-CSN-BASIC-PREM-AMT                 TO L0389-LIFPREM.
           MOVE MIR-CSN-PFEE-AMT      TO L0389-POLFEE.
           MOVE MIR-CSN-AD-PREM-AMT   TO L0389-ADBPREM.
           MOVE MIR-CSN-WP-PREM-AMT   TO L0389-WPPREM.
           MOVE MIR-DV-ME-ALLOW-AMT  TO L0389-MXALL.
           MOVE MIR-CSN-ME-PREM-AMT   TO L0389-MXPREM.
013578*    MOVE MIR-EXALL             TO L0389-EXALL.
           MOVE MIR-CSN-FE-PREM-AMT   TO L0389-EXPREM.
           MOVE MIR-CSN-TOT-ALLOW-AMT TO L0389-ALPREM.
           MOVE MIR-CSN-NOTI-DT       TO L0389-NOTDATE.
           MOVE MIR-CSN-NOTI-CD       TO L0389-NOTRSN.
           MOVE MIR-CSN-STAT-CD       TO L0389-CSTAT.
           MOVE MIR-CSN-PREV-STAT-CD  TO L0389-PSTAT.
013578*    MOVE MIR-GROSS             TO L0389-GROSS.
           MOVE MIR-CSN-CHNG-EFF-DT   TO L0389-CHGDATE.

       5300-SET-EDIT-AREA-X.
           EXIT.
      /
      *---------------------
       5400-CHECK-EDIT-AREA.
      *---------------------

           IF  L0389-TDUR = HIGH-VALUES
               SET WS-EDIT-ERROR       TO TRUE
               IF  MIR-DV-PREM-PD-YR-QTY = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-DV-PREM-PD-YR-QTY
               END-IF
           ELSE
               MOVE L0389-TDUR        TO MIR-DV-PREM-PD-YR-QTY
           END-IF.

           IF  L0389-POLNO = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-POL-ID-BASE = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-POL-ID-BASE
               END-IF
           ELSE
               MOVE L0389-POLNO       TO MIR-POL-ID-BASE
           END-IF.

           IF  L0389-SUFF = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-POL-ID-SFX = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-POL-ID-SFX
               END-IF
           ELSE
               MOVE L0389-SUFF        TO MIR-POL-ID-SFX
           END-IF.

           IF  L0389-COVNO = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CVG-NUM = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-NUM
               END-IF
           ELSE
               MOVE L0389-COVNO       TO MIR-CVG-NUM
           END-IF.

           IF  L0389-REINNUM = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-REC-NUM = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-REC-NUM
               END-IF
           ELSE
               MOVE L0389-REINNUM     TO MIR-CSN-REC-NUM
           END-IF.

           IF  L0389-TOTREIN = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CVG-CSN-REC-CTR = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-CSN-REC-CTR
               END-IF
           ELSE
               MOVE L0389-TOTREIN     TO MIR-CVG-CSN-REC-CTR
           END-IF.

           IF  L0389-TNAME = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
017190*        IF  MIR-DV-OWN-CLI-NM = EBLCH-BLANK-FIELD-CHAR
017190*            MOVE SPACES        TO MIR-DV-OWN-CLI-NM
017190         IF  MIR-DV-INSRD-CLI-NM = EBLCH-BLANK-FIELD-CHAR
017190             MOVE SPACES        TO MIR-DV-INSRD-CLI-NM
               END-IF
           ELSE
017190*        MOVE L0389-TNAME       TO MIR-DV-OWN-CLI-NM
               MOVE L0389-TNAME       TO MIR-DV-INSRD-CLI-NM
           END-IF.

           IF  L0389-ENTER = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
           END-IF.

014591*    IF  L0389-TRPLAN = HIGH-VALUES
014591     IF  L0389-TR-PLAN-ID = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-PLAN-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES          TO MIR-PLAN-ID
               END-IF
           ELSE
014591*        MOVE L0389-TRPLAN       TO MIR-PLAN-ID
014591         MOVE L0389-TR-PLAN-ID   TO MIR-PLAN-ID
           END-IF.

013578*    IF  L0389-TRRTSC = HIGH-VALUES
013578*        SET  WS-EDIT-ERROR       TO TRUE
013578*        IF  MIR-TRRTSC = EBLCH-BLANK-FIELD-CHAR
013578*            MOVE SPACES        TO MIR-TRRTSC
013578*        END-IF
013578*    ELSE
013578*        MOVE L0389-TRRTSC        TO MIR-TRRTSC
013578*    END-IF.

           IF  L0389-TRSTAT = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CVG-CSTAT-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES          TO MIR-CVG-CSTAT-CD
               END-IF
           ELSE
               MOVE L0389-TRSTAT      TO MIR-CVG-CSTAT-CD
           END-IF.

           IF  L0389-TSMOKE = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CVG-SMKR-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-SMKR-CD
               END-IF
           ELSE
               MOVE L0389-TSMOKE      TO MIR-CVG-SMKR-CD
           END-IF.

           IF  L0389-TPAR = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CVG-PAR-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-PAR-CD
               END-IF
           ELSE
               MOVE L0389-TPAR        TO MIR-CVG-PAR-CD
           END-IF.

           IF  L0389-TSEX = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CVG-SEX-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-SEX-CD
               END-IF
           ELSE
               MOVE L0389-TSEX        TO MIR-CVG-SEX-CD
           END-IF.

           IF  L0389-TQUAL = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CVG-STBL-1-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-STBL-1-CD
               END-IF
           ELSE
               MOVE L0389-TQUAL       TO MIR-CVG-STBL-1-CD
           END-IF.

           IF  L0389-TELIM = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CVG-STBL-2-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-STBL-2-CD
               END-IF
           ELSE
               MOVE L0389-TELIM       TO MIR-CVG-STBL-2-CD
           END-IF.

           IF  L0389-TBENF = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CVG-STBL-3-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-STBL-3-CD
               END-IF
           ELSE
               MOVE L0389-TBENF       TO MIR-CVG-STBL-3-CD
           END-IF.

           IF  L0389-TOCC = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CVG-STBL-4-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-STBL-4-CD
               END-IF
           ELSE
               MOVE L0389-TOCC        TO MIR-CVG-STBL-4-CD
           END-IF.

           IF  L0389-TAGE = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CVG-RT-AGE = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-RT-AGE
               END-IF
           ELSE
               MOVE L0389-TAGE        TO MIR-CVG-RT-AGE
           END-IF.

           IF  L0389-TDUR = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-DV-PREM-PD-YR-QTY = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-DV-PREM-PD-YR-QTY
               END-IF
           ELSE
               MOVE L0389-TDUR        TO MIR-DV-PREM-PD-YR-QTY
           END-IF.

           IF  L0389-FACE = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CVG-FACE-AMT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-FACE-AMT
               END-IF
           ELSE
               MOVE L0389-FACE        TO MIR-CVG-FACE-AMT
           END-IF.

           IF  L0389-ANNPRM = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CVG-BASIC-PREM-AMT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-BASIC-PREM-AMT
               END-IF
           ELSE
               MOVE L0389-ANNPRM      TO MIR-CVG-BASIC-PREM-AMT
           END-IF.

           IF  L0389-FEPRM = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CVG-FE-PREM-AMT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-FE-PREM-AMT
               END-IF
           ELSE
               MOVE L0389-FEPRM       TO MIR-CVG-FE-PREM-AMT
           END-IF.

           IF  L0389-FEDUR = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CVG-FE-DUR = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-FE-DUR
               END-IF
           ELSE
               MOVE L0389-FEDUR       TO MIR-CVG-FE-DUR
           END-IF.

           IF  L0389-FERSN = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CVG-FE-REASN-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-FE-REASN-CD
               END-IF
           ELSE
               MOVE L0389-FERSN       TO MIR-CVG-FE-REASN-CD
           END-IF.

           IF  L0389-MULT = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CVG-ME-FCT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-ME-FCT
               END-IF
           ELSE
               MOVE L0389-MULT        TO MIR-CVG-ME-FCT
           END-IF.

           IF  L0389-MDUR = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CVG-ME-DUR = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-ME-DUR
               END-IF
           ELSE
               MOVE L0389-MDUR        TO MIR-CVG-ME-DUR
           END-IF.

           IF  L0389-MRSN = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CVG-ME-REASN-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CVG-ME-REASN-CD
               END-IF
           ELSE
               MOVE L0389-MRSN        TO MIR-CVG-ME-REASN-CD
           END-IF.

           IF  L0389-CLIENT = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-INSRD-CLI-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-INSRD-CLI-ID
               END-IF
           ELSE
               MOVE L0389-CLIENT      TO MIR-INSRD-CLI-ID
           END-IF.

013578*    IF  L0389-DIRET = HIGH-VALUES
013578*        SET  WS-EDIT-ERROR       TO TRUE
013578*        IF  MIR-DIRET = EBLCH-BLANK-FIELD-CHAR
013578*            MOVE SPACES        TO MIR-DIRET
013578*        END-IF
013578*    ELSE
013578*        MOVE L0389-DIRET       TO MIR-DIRET
013578*    END-IF.

014591*    IF  L0389-PLANCD = HIGH-VALUES
014591     IF  L0389-PLAN-ID = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-PLAN-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-PLAN-ID
               END-IF
           ELSE
014591*        MOVE L0389-PLANCD      TO MIR-CSN-PLAN-ID
014591         MOVE L0389-PLAN-ID     TO MIR-CSN-PLAN-ID
           END-IF.

           IF  L0389-SMOKE = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-SMKR-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-SMKR-CD
               END-IF
           ELSE
               MOVE L0389-SMOKE       TO MIR-CSN-SMKR-CD
           END-IF.

           IF  L0389-PAR = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CSN-PAR-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-PAR-CD
               END-IF
           ELSE
               MOVE L0389-PAR         TO MIR-CSN-PAR-CD
           END-IF.

           IF  L0389-SEX = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-SEX-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-SEX-CD
               END-IF
           ELSE
               MOVE L0389-SEX         TO MIR-CSN-SEX-CD
           END-IF.

           IF  L0389-AGE = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-RT-AGE = EBLCH-BLANK-FIELD-CHAR
                   MOVE '000'         TO MIR-CSN-RT-AGE
               END-IF
           ELSE
               MOVE L0389-AGE         TO MIR-CSN-RT-AGE
           END-IF.

           IF  L0389-TYPE = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CSN-REINS-TYP-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-REINS-TYP-CD
               END-IF
           ELSE
               MOVE L0389-TYPE        TO MIR-CSN-REINS-TYP-CD
           END-IF.

           IF  L0389-RTT = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CSN-TRTY-TYP-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-TRTY-TYP-CD
               END-IF
           ELSE
               MOVE L0389-RTT         TO MIR-CSN-TRTY-TYP-CD
           END-IF.

           IF  L0389-COMPANY = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-ASSUM-CO-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-ASSUM-CO-ID
               END-IF
           ELSE
               MOVE L0389-COMPANY     TO MIR-ASSUM-CO-ID
           END-IF.

           IF  L0389-DUROFF = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-PREM-OFFST-DUR = EBLCH-BLANK-FIELD-CHAR
                   MOVE '000'         TO MIR-CSN-PREM-OFFST-DUR
               END-IF
           ELSE
               MOVE L0389-DUROFF      TO MIR-CSN-PREM-OFFST-DUR
           END-IF.

           IF  L0389-CESSION = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-ASSUM-CO-REF-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-ASSUM-CO-REF-ID
               END-IF
           ELSE
               MOVE L0389-CESSION     TO MIR-ASSUM-CO-REF-ID
           END-IF.

           IF  L0389-EDATE = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CSN-EFF-DT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-EFF-DT
               END-IF
           ELSE
               MOVE L0389-EDATE       TO MIR-CSN-EFF-DT
           END-IF.

           IF  L0389-PTDTE = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CSN-PD-TO-DT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-PD-TO-DT
               END-IF
           ELSE
               MOVE L0389-PTDTE       TO MIR-CSN-PD-TO-DT
           END-IF.

           IF  L0389-MEDATE = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CSN-MAT-XPRY-DT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-MAT-XPRY-DT
               END-IF
           ELSE
               MOVE L0389-MEDATE      TO MIR-CSN-MAT-XPRY-DT
           END-IF.

           IF  L0389-EPHPREM = HIGH-VALUES
               SET  WS-RESTRICT-ERRORS  TO TRUE
               IF  MIR-REDC-EP-PREM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '00000.00'      TO MIR-REDC-EP-PREM-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-REDC-EP-PREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-REDC-EP-PREM-AMT
               END-IF
           ELSE
               MOVE L0389-EPHPREM     TO MIR-REDC-EP-PREM-AMT
           END-IF.

           IF  L0389-EPHTRTY = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-REDC-EP-ALLOW-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-REDC-EP-ALLOW-ID
               END-IF
           ELSE
               MOVE L0389-EPHTRTY     TO MIR-REDC-EP-ALLOW-ID
           END-IF.

           IF  L0389-EPHALL = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-DV-REDC-EP-ALLOW-AMT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-DV-REDC-EP-ALLOW-AMT
               END-IF
           ELSE
               MOVE L0389-EPHALL      TO MIR-DV-REDC-EP-ALLOW-AMT
           END-IF.

           IF  L0389-OCCPREM = HIGH-VALUES
               SET  WS-RESTRICT-ERRORS  TO TRUE
               IF  MIR-OWN-OCCP-PREM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '00000.00'      TO MIR-OWN-OCCP-PREM-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-OWN-OCCP-PREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-OWN-OCCP-PREM-AMT
               END-IF
           ELSE
               MOVE L0389-OCCPREM     TO MIR-OWN-OCCP-PREM-AMT
           END-IF.

           IF  L0389-OCCTRTY = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-OWN-OCCP-ALLOW-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-OWN-OCCP-ALLOW-ID
               END-IF
           ELSE
               MOVE L0389-OCCTRTY     TO MIR-OWN-OCCP-ALLOW-ID
           END-IF.

           IF  L0389-OCCALL = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-DV-OWN-OCCP-ALLOW-AMT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-DV-OWN-OCCP-ALLOW-AMT
               END-IF
           ELSE
               MOVE L0389-OCCALL      TO MIR-DV-OWN-OCCP-ALLOW-AMT
           END-IF.

           IF  L0389-LTAPREM = HIGH-VALUES
               SET  WS-RESTRICT-ERRORS  TO TRUE
               IF  MIR-CSN-LTA-PREM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '00000.00'      TO MIR-CSN-LTA-PREM-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CSN-LTA-PREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-CSN-LTA-PREM-AMT
               END-IF
           ELSE
               MOVE L0389-LTAPREM     TO MIR-CSN-LTA-PREM-AMT
           END-IF.

           IF  L0389-LTATRTY = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-LTA-ALLOW-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-LTA-ALLOW-ID
               END-IF
           ELSE
               MOVE L0389-LTATRTY     TO MIR-CSN-LTA-ALLOW-ID
           END-IF.

           IF  L0389-LTAALL = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-DV-LTA-ALLOW-AMT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-DV-LTA-ALLOW-AMT
               END-IF
           ELSE
               MOVE L0389-LTAALL      TO MIR-DV-LTA-ALLOW-AMT
           END-IF.

           IF  L0389-LTBPREM = HIGH-VALUES
               SET  WS-RESTRICT-ERRORS  TO TRUE
               IF  MIR-CSN-LTB-PREM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '00000.00'      TO MIR-CSN-LTB-PREM-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CSN-LTB-PREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-CSN-LTB-PREM-AMT
               END-IF
           ELSE
               MOVE L0389-LTBPREM     TO MIR-CSN-LTB-PREM-AMT
           END-IF.

           IF  L0389-LTBTRTY = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-LTB-ALLOW-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-LTB-ALLOW-ID
               END-IF
           ELSE
               MOVE L0389-LTBTRTY     TO MIR-CSN-LTB-ALLOW-ID
           END-IF.

           IF  L0389-LTBALL = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-DV-LTB-ALLOW-AMT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-DV-LTB-ALLOW-AMT
               END-IF
           ELSE
               MOVE L0389-LTBALL      TO MIR-DV-LTB-ALLOW-AMT
           END-IF.

           IF  L0389-PDIPREM = HIGH-VALUES
               SET  WS-RESTRICT-ERRORS  TO TRUE
               IF  MIR-PDISAB-PREM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '00000.00'      TO MIR-PDISAB-PREM-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-PDISAB-PREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-PDISAB-PREM-AMT
               END-IF
           ELSE
               MOVE L0389-PDIPREM     TO MIR-PDISAB-PREM-AMT
           END-IF.

           IF  L0389-PDITRTY = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-PDISAB-ALLOW-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-PDISAB-ALLOW-ID
               END-IF
           ELSE
               MOVE L0389-PDITRTY     TO MIR-PDISAB-ALLOW-ID
           END-IF.

           IF  L0389-PDIALL = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-DV-PDISAB-ALLOW-AMT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-DV-PDISAB-ALLOW-AMT
               END-IF
           ELSE
               MOVE L0389-PDIALL      TO MIR-DV-PDISAB-ALLOW-AMT
           END-IF.

           IF  L0389-COLPREM = HIGH-VALUES
               SET  WS-RESTRICT-ERRORS  TO TRUE
               IF  MIR-CSN-COLA-PREM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '00000.00'      TO MIR-CSN-COLA-PREM-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CSN-COLA-PREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-CSN-COLA-PREM-AMT
               END-IF
           ELSE
               MOVE L0389-COLPREM     TO MIR-CSN-COLA-PREM-AMT
           END-IF.

           IF  L0389-COLTRTY = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-COLA-ALLOW-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-COLA-ALLOW-ID
               END-IF
           ELSE
               MOVE L0389-COLTRTY     TO MIR-CSN-COLA-ALLOW-ID
           END-IF.

           IF  L0389-COLALL = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-DV-COLA-ALLOW-AMT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-DV-COLA-ALLOW-AMT
               END-IF
           ELSE
               MOVE L0389-COLALL      TO MIR-DV-COLA-ALLOW-AMT
           END-IF.

           IF  L0389-RISKIND = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-RSK-CALC-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-RSK-CALC-CD
               END-IF
           ELSE
               MOVE L0389-RISKIND     TO MIR-CSN-RSK-CALC-CD
           END-IF.

           IF  L0389-RISKAMT = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-ORIG-RSK-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '000000000.00'  TO MIR-CSN-ORIG-RSK-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CSN-ORIG-RSK-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-CSN-ORIG-RSK-AMT
               END-IF
           ELSE
               MOVE L0389-RISKAMT     TO MIR-CSN-ORIG-RSK-AMT
           END-IF.

           IF  L0389-RITRTY = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CSN-LIFE-ALLOW-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-LIFE-ALLOW-ID
               END-IF
           ELSE
               MOVE L0389-RITRTY      TO MIR-CSN-LIFE-ALLOW-ID
           END-IF.

           IF  L0389-WPFAMT = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-WP-FACE-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '000000000.00'  TO MIR-CSN-WP-FACE-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CSN-WP-FACE-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-CSN-WP-FACE-AMT
               END-IF
           ELSE
               MOVE L0389-WPFAMT      TO MIR-CSN-WP-FACE-AMT
           END-IF.

           IF  L0389-WPTRTY = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CSN-WP-ALLOW-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-WP-ALLOW-ID
               END-IF
           ELSE
               MOVE L0389-WPTRTY      TO MIR-CSN-WP-ALLOW-ID
           END-IF.

           IF  L0389-ADFAMT = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-AD-FACE-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '000000000.00'  TO MIR-CSN-AD-FACE-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CSN-AD-FACE-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-CSN-AD-FACE-AMT
               END-IF
           ELSE
               MOVE L0389-ADFAMT      TO MIR-CSN-AD-FACE-AMT
           END-IF.

           IF  L0389-ADTRTY = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CSN-AD-ALLOW-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-AD-ALLOW-ID
               END-IF
           ELSE
               MOVE L0389-ADTRTY      TO MIR-CSN-AD-ALLOW-ID
           END-IF.

           IF  L0389-FLATEX = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-FE-FCT = EBLCH-BLANK-FIELD-CHAR
                   MOVE '000.00'      TO MIR-CSN-FE-FCT
               END-IF
           ELSE
               MOVE L0389-FLATEX      TO MIR-CSN-FE-FCT
           END-IF.

           IF  L0389-EXTRTY = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-FE-ALLOW-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-FE-ALLOW-ID
               END-IF
           ELSE
               MOVE L0389-EXTRTY      TO MIR-CSN-FE-ALLOW-ID
           END-IF.

           IF  L0389-MULTEX = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-ME-FCT = EBLCH-BLANK-FIELD-CHAR
                   MOVE '000.00'      TO MIR-CSN-ME-FCT
               END-IF
           ELSE
               MOVE L0389-MULTEX      TO MIR-CSN-ME-FCT
           END-IF.

           IF  L0389-MRTRTY = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-ME-ALLOW-ID = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-ME-ALLOW-ID
               END-IF
           ELSE
               MOVE L0389-MRTRTY      TO MIR-CSN-ME-ALLOW-ID
           END-IF.

           IF  L0389-RETAMT = HIGH-VALUES
008455*        MOVE '000000000.00'      TO MIR-CSN-RETEN-AMT
020874*        MOVE ZEROS             TO L0290-INPUT-NUMBER
020874         MOVE ZEROS             TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-CSN-RETEN-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-CSN-RETEN-AMT
               SET  WS-EDIT-ERROR       TO TRUE
           ELSE
               MOVE L0389-RETAMT      TO MIR-CSN-RETEN-AMT
           END-IF.

           IF  L0389-BILLIND = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-BCK-BILL-REASN-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-BCK-BILL-REASN-CD
               END-IF
           ELSE
               MOVE L0389-BILLIND     TO MIR-BCK-BILL-REASN-CD
           END-IF.

           IF  L0389-BBAMT = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-BCK-BILL-PREM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '+0000000.00'   TO MIR-BCK-BILL-PREM-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-BCK-BILL-PREM-AMT
                                      TO L0290-MAX-OUT-LEN
008455             SET L0290-SIGN-DISPLAY     TO TRUE
008455             SET L0290-SIGN-POS-DISPLAY TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-BCK-BILL-PREM-AMT
               END-IF
           ELSE
               MOVE L0389-BBAMT       TO MIR-BCK-BILL-PREM-AMT
           END-IF.

           IF  L0389-BBALLOW = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-BCK-BILL-ALLOW-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '+0000000.00'   TO MIR-BCK-BILL-ALLOW-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-BCK-BILL-ALLOW-AMT
                                      TO L0290-MAX-OUT-LEN
008455             SET L0290-SIGN-DISPLAY     TO TRUE
008455             SET L0290-SIGN-POS-DISPLAY TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-BCK-BILL-ALLOW-AMT
               END-IF
           ELSE
               MOVE L0389-BBALLOW     TO MIR-BCK-BILL-ALLOW-AMT
           END-IF.

           IF  L0389-RESTIND = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-RESTR-PREM-IND = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-RESTR-PREM-IND
               END-IF
           ELSE
               MOVE L0389-RESTIND     TO MIR-CSN-RESTR-PREM-IND
           END-IF.

           IF  L0389-TOTPREM = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CSN-TOT-NPREM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '+0000000.00'   TO MIR-CSN-TOT-NPREM-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CSN-TOT-NPREM-AMT
                                      TO L0290-MAX-OUT-LEN
008455             SET L0290-SIGN-DISPLAY     TO TRUE
008455             SET L0290-SIGN-POS-DISPLAY TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-CSN-TOT-NPREM-AMT
               END-IF
           ELSE
               MOVE L0389-TOTPREM     TO MIR-CSN-TOT-NPREM-AMT
           END-IF.

           IF  L0389-STPREM = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-DV-TOT-VAR-PREM-AMT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-DV-TOT-VAR-PREM-AMT
               END-IF
           ELSE
               MOVE L0389-STPREM      TO MIR-DV-TOT-VAR-PREM-AMT
           END-IF.

           IF  L0389-CRISK = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-CRNT-RSK-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '000000000.00'  TO MIR-CSN-CRNT-RSK-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CSN-CRNT-RSK-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-CSN-CRNT-RSK-AMT
               END-IF
           ELSE
               MOVE L0389-CRISK       TO MIR-CSN-CRNT-RSK-AMT
           END-IF.

           IF  L0389-DECRMNT = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-RSK-DECR-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '0000000'       TO MIR-CSN-RSK-DECR-AMT
008455             MOVE  ZEROS        TO MIR-CSN-RSK-DECR-AMT
               END-IF
           ELSE
               MOVE L0389-DECRMNT     TO MIR-CSN-RSK-DECR-AMT
           END-IF.

           IF  L0389-NETPREM = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-NPREM-YTD-AMT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-NPREM-YTD-AMT
               END-IF
           ELSE
               MOVE L0389-NETPREM     TO MIR-CSN-NPREM-YTD-AMT
           END-IF.

           IF  L0389-LIFALL = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-DV-LIFE-ALLOW-AMT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-DV-LIFE-ALLOW-AMT
               END-IF
           ELSE
               MOVE L0389-LIFALL      TO MIR-DV-LIFE-ALLOW-AMT
           END-IF.

           IF  L0389-LIFPREM = HIGH-VALUES
               SET  WS-RESTRICT-ERRORS  TO TRUE
               IF  MIR-CSN-BASIC-PREM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '0000000.00'    TO MIR-CSN-BASIC-PREM-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CSN-BASIC-PREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-CSN-BASIC-PREM-AMT
               END-IF
           ELSE
               MOVE L0389-LIFPREM     TO MIR-CSN-BASIC-PREM-AMT
           END-IF.

           IF  L0389-POLFEE = HIGH-VALUES
               SET  WS-RESTRICT-ERRORS  TO TRUE
               IF  MIR-CSN-PFEE-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '+000.00'       TO MIR-CSN-PFEE-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CSN-PFEE-AMT
                                      TO L0290-MAX-OUT-LEN
008455             SET L0290-SIGN-DISPLAY     TO TRUE
008455             SET L0290-SIGN-POS-DISPLAY TO TRUE
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-CSN-PFEE-AMT
               END-IF
           ELSE
               MOVE L0389-POLFEE      TO MIR-CSN-PFEE-AMT
           END-IF.

           IF  L0389-ADBPREM = HIGH-VALUES
               SET  WS-RESTRICT-ERRORS  TO TRUE
               IF  MIR-CSN-AD-PREM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '0000000.00'    TO MIR-CSN-AD-PREM-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CSN-AD-PREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-CSN-AD-PREM-AMT
               END-IF
           ELSE
               MOVE L0389-ADBPREM     TO MIR-CSN-AD-PREM-AMT
           END-IF.

           IF  L0389-WPPREM = HIGH-VALUES
               SET  WS-RESTRICT-ERRORS  TO TRUE
               IF  MIR-CSN-WP-PREM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '0000000.00'    TO MIR-CSN-WP-PREM-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CSN-WP-PREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-CSN-WP-PREM-AMT
               END-IF
           ELSE
               MOVE L0389-WPPREM      TO MIR-CSN-WP-PREM-AMT
           END-IF.

           IF  L0389-MXALL = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-DV-ME-ALLOW-AMT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-DV-ME-ALLOW-AMT
               END-IF
           ELSE
               MOVE L0389-MXALL       TO MIR-DV-ME-ALLOW-AMT
           END-IF.

           IF  L0389-MXPREM = HIGH-VALUES
               SET  WS-RESTRICT-ERRORS  TO TRUE
               IF  MIR-CSN-ME-PREM-AMT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-ME-PREM-AMT
               END-IF
           ELSE
               MOVE L0389-MXPREM      TO MIR-CSN-ME-PREM-AMT
           END-IF.

013578*    IF  L0389-EXALL = HIGH-VALUES
013578*        SET  WS-EDIT-ERROR       TO TRUE
013578*        IF  MIR-EXALL = EBLCH-BLANK-FIELD-CHAR
013578*            MOVE SPACES        TO MIR-EXALL
013578*        END-IF
013578*    ELSE
013578*        MOVE L0389-EXALL       TO MIR-EXALL
013578*    END-IF.

           IF  L0389-EXPREM = HIGH-VALUES
               SET  WS-RESTRICT-ERRORS  TO TRUE
               IF  MIR-CSN-FE-PREM-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '0000000.00'    TO MIR-CSN-FE-PREM-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CSN-FE-PREM-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-CSN-FE-PREM-AMT
               END-IF
           ELSE
               MOVE L0389-EXPREM      TO MIR-CSN-FE-PREM-AMT
           END-IF.

           IF  L0389-ALPREM = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-TOT-ALLOW-AMT = EBLCH-BLANK-FIELD-CHAR
008455*            MOVE '0000000.00'    TO MIR-CSN-TOT-ALLOW-AMT
020874*            MOVE ZEROS         TO L0290-INPUT-NUMBER
020874             MOVE ZEROS         TO L0290-INPUT-V02
008455             MOVE 2             TO L0290-PRECISION
008455             MOVE LENGTH OF MIR-CSN-TOT-ALLOW-AMT
                                      TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
008455             MOVE L0290-OUTPUT-DATA
                                      TO MIR-CSN-TOT-ALLOW-AMT
               END-IF
           ELSE
               MOVE L0389-ALPREM      TO MIR-CSN-TOT-ALLOW-AMT
           END-IF.

           IF  L0389-NOTDATE = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-NOTI-DT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-NOTI-DT
               END-IF
           ELSE
               MOVE L0389-NOTDATE     TO MIR-CSN-NOTI-DT
           END-IF.

           IF  L0389-NOTRSN = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-NOTI-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-NOTI-CD
               END-IF
           ELSE
               MOVE L0389-NOTRSN      TO MIR-CSN-NOTI-CD
           END-IF.

           IF  L0389-CSTAT = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CSN-STAT-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-STAT-CD
               END-IF
           ELSE
               MOVE L0389-CSTAT       TO MIR-CSN-STAT-CD
           END-IF.

           IF  L0389-PSTAT = HIGH-VALUES
               SET WS-EDIT-ERROR        TO TRUE
               IF  MIR-CSN-PREV-STAT-CD = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-PREV-STAT-CD
               END-IF
           ELSE
               MOVE L0389-PSTAT       TO MIR-CSN-PREV-STAT-CD
           END-IF.

013578*    IF  L0389-GROSS = HIGH-VALUES
013578*        SET  WS-EDIT-ERROR       TO TRUE
013578*        IF  MIR-GROSS = EBLCH-BLANK-FIELD-CHAR
013578*            MOVE SPACES        TO MIR-GROSS
013578*        END-IF
013578*    ELSE
013578*        MOVE L0389-GROSS       TO MIR-GROSS
013578*    END-IF.

           IF  L0389-CHGDATE = HIGH-VALUES
               SET  WS-EDIT-ERROR       TO TRUE
               IF  MIR-CSN-CHNG-EFF-DT = EBLCH-BLANK-FIELD-CHAR
                   MOVE SPACES        TO MIR-CSN-CHNG-EFF-DT
               END-IF
           ELSE
               MOVE L0389-CHGDATE     TO MIR-CSN-CHNG-EFF-DT
           END-IF.

       5400-CHECK-EDIT-AREA-X.
           EXIT.
      /
      *------------
       6000-DELETE.
      *------------

      *
      *  REINSURANCE NUMBER AND STATUS VALIDATION
      *
           IF  HOLD-REIN-NO < WCVGS-CVG-CSN-REC-CTR-N (HOLD-RIDER-NO)
      *MSG: CAN ONLY DELETE LAST REINSURANCE RECORD
               MOVE 'CS03810008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  POL-3000-UNLOCK
014221             THRU POL-3000-UNLOCK-X
               GO TO 6000-DELETE-X
           END-IF.

           IF  NOT RRI-CSN-STAT-PENDING
      *MSG: REINSURANCE RECORD MUST BE PENDING TO BE DELETED
               MOVE 'CS03810064'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
014221         PERFORM  POL-3000-UNLOCK
014221             THRU POL-3000-UNLOCK-X
               GO TO 6000-DELETE-X
           END-IF.

           PERFORM  RI-1000-DELETE
               THRU RI-1000-DELETE-X
014221     PERFORM  POL-2000-REWRITE
014221         THRU POL-2000-REWRITE-X.
014221     PERFORM  POL-1000-READ-TWRK-TS
014221         THRU POL-1000-READ-TWRK-TS-X.

           SUBTRACT 1 FROM TOTAL-REIN.
           MOVE     TOTAL-REIN        TO WCVGS-CVG-CSN-REC-CTR-N
                                          (HOLD-RIDER-NO).
           IF  TOTAL-REIN > ZERO
               MOVE TOTAL-REIN        TO MIR-CSN-REC-NUM
           ELSE
               MOVE '01'              TO MIR-CSN-REC-NUM
           END-IF.

      *MSG: REINSURANCE RECORD DELETED
           MOVE 'CS03810002'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
      *
      *  UPDATE COVERAGE
      *
           MOVE HOLD-RIDER-NO         TO I.

           PERFORM  CVGR-2000-REWRITE-COVERAGE
               THRU CVGR-2000-REWRITE-COVERAGE-X.

       6000-DELETE-X.
           EXIT.
      /
      *---------------------------
       7000-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           MOVE HOLD-RIDER-NO         TO I.
           MOVE WCVGS-CVG-CSN-REC-CTR-N (I)
                                      TO MIR-CVG-CSN-REC-CTR.

           PERFORM 2430-1000-BUILD-PARM-INFO
              THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM 2430-4100-PRIM-INSRD-KEY
              THRU 2430-4100-PRIM-INSRD-KEY-X.

           PERFORM 2435-1000-BUILD-PARM-INFO
              THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE L2430-CLI-ID          TO L2435-CLI-ID.

           PERFORM 2435-1000-OBTAIN-CLI-INFO
              THRU 2435-1000-OBTAIN-CLI-INFO-X.

557668*    MOVE L2435-CLI-NM-COMPRESSED TO MIR-DV-OWN-CLI-NM.
557668     INITIALIZE L0620-INPUT-PARM-INFO
557668     IF   L2435-CLI-SEX-CD = 'C'
557668          MOVE L2435-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
557668     ELSE
557668          MOVE L2435-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
557668          MOVE L2435-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
                MOVE L2435-CLI-MID-INIT-NM
                                      TO L0620-CLI-MID-INIT-NM
                MOVE L2435-CLI-SFX-NM TO L0620-CLI-SFX-NM
557668     END-IF
557668     MOVE L2435-CLI-SEX-CD      TO L0620-CLI-SEX-CD
557668
557668     PERFORM  0620-1000-FORMAT-SCREEN-NAME
557668         THRU 0620-1000-FORMAT-SCREEN-NAME-X
557668
017190*    MOVE L0620-SCREEN-NAME     TO MIR-DV-OWN-CLI-NM
017190     MOVE L0620-SCREEN-NAME     TO MIR-DV-INSRD-CLI-NM


           MOVE WCVGS-PLAN-ID (I)     TO MIR-PLAN-ID.
           MOVE WCVGS-CVG-CSTAT-CD (I) TO MIR-CVG-CSTAT-CD.

           MOVE WCVGS-CVG-SMKR-CD (I) TO MIR-CVG-SMKR-CD.
           MOVE WCVGS-CVG-PAR-CD (I)  TO MIR-CVG-PAR-CD.
           MOVE WCVGS-CVG-SEX-CD (I)  TO MIR-CVG-SEX-CD.
           MOVE WCVGS-CVG-STBL-1-CD (I)
                                      TO MIR-CVG-STBL-1-CD.
           MOVE WCVGS-CVG-STBL-2-CD (I)
                                      TO MIR-CVG-STBL-2-CD.
           MOVE WCVGS-CVG-STBL-3-CD (I)
                                      TO MIR-CVG-STBL-3-CD.
           MOVE WCVGS-CVG-STBL-4-CD (I)
                                      TO MIR-CVG-STBL-4-CD.
           MOVE WCVGS-CVG-RT-AGE   (I)                TO MIR-CVG-RT-AGE.

           PERFORM  0384-1000-BUILD-PARM-INFO
               THRU 0384-1000-BUILD-PARM-INFO-X.

           MOVE HOLD-RIDER-NO         TO L0384-CVG-NUM.
           SET L0384-DISPLAY-MESSAGES        TO TRUE.

           PERFORM 0384-3000-CALC-DUR
              THRU 0384-3000-CALC-DUR-X.

           MOVE L0384-DUR             TO MIR-DV-PREM-PD-YR-QTY.

008455*    MOVE WCVGS-CVG-FACE-AMT (I)       TO WS-HOLD-9V2.
008455*    MOVE WS-DISP-9V2                  TO MIR-CVG-FACE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WCVGS-CVG-FACE-AMT (I) * 100.
020874     MOVE WCVGS-CVG-FACE-AMT (I) TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-FACE-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-FACE-AMT.
008455
008455*    MOVE WCVGS-CVG-BASIC-PREM-AMT (I) TO WS-HOLD-7V2.
008455*    MOVE WS-DISP-7V2                  TO MIR-CVG-BASIC-PREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WCVGS-CVG-BASIC-PREM-AMT (I)
020874*                                 * 100.
020874     MOVE WCVGS-CVG-BASIC-PREM-AMT (I) TO L0290-INPUT-V02.
008455     MOVE 2                            TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-BASIC-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-BASIC-PREM-AMT.
008455
008455*    MOVE WCVGS-CVG-FE-PREM-AMT (I)    TO WS-HOLD-S7V2.
008455*    MOVE WS-DISP-S7V2                 TO MIR-CVG-FE-PREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = WCVGS-CVG-FE-PREM-AMT (I)
020874*                                  * 100.
020874     MOVE WCVGS-CVG-FE-PREM-AMT (I) TO L0290-INPUT-V02.
008455     MOVE 2                         TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CVG-FE-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY           TO TRUE.
008455     SET  L0290-SIGN-POS-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-FE-PREM-AMT.
008455
           MOVE WCVGS-CVG-FE-DUR (I)  TO WS-HOLD-3V0
           MOVE WS-DISP-3V0           TO MIR-CVG-FE-DUR.
           MOVE WCVGS-CVG-FE-REASN-CD (I)
                                      TO MIR-CVG-FE-REASN-CD.
020874*    MOVE WCVGS-CVG-ME-FCT (I)  TO WS-HOLD-S1V2.
020874*    MOVE WS-DISP-S1V2          TO MIR-CVG-ME-FCT.
020874     MOVE WCVGS-CVG-ME-FCT (I)  TO L0290-INPUT-V02.
020874     MOVE 2                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CVG-ME-FCT
020874                                TO L0290-MAX-OUT-LEN.
020874     SET L0290-SIGN-DISPLAY     TO TRUE.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CVG-ME-FCT.
           MOVE WCVGS-CVG-ME-DUR (I)  TO WS-HOLD-3V0.
           MOVE WS-DISP-3V0           TO MIR-CVG-ME-DUR.
           MOVE WCVGS-CVG-ME-REASN-CD  (I)
                                      TO MIR-CVG-ME-REASN-CD.

           PERFORM  2430-3100-GET-PRIM-INSRD
               THRU 2430-3100-GET-PRIM-INSRD-X.

           MOVE L2430-CLI-ID          TO MIR-INSRD-CLI-ID.

           MOVE RRI-CSN-PLAN-ID       TO MIR-CSN-PLAN-ID.
           MOVE RRI-CSN-SMKR-CD       TO MIR-CSN-SMKR-CD.
           MOVE RRI-CSN-PAR-CD        TO MIR-CSN-PAR-CD.
           MOVE RRI-CSN-SEX-CD        TO MIR-CSN-SEX-CD.
           MOVE RRI-CSN-RT-AGE        TO WS-HOLD-3V0.
           MOVE WS-DISP-3V0           TO MIR-CSN-RT-AGE.
           MOVE RRI-CSN-REINS-TYP-CD  TO MIR-CSN-REINS-TYP-CD.
           MOVE RRI-CSN-TRTY-TYP-CD   TO MIR-CSN-TRTY-TYP-CD.
           MOVE RRI-ASSUM-CO-ID       TO MIR-ASSUM-CO-ID.
           MOVE RRI-CSN-PREM-OFFST-DUR-N
                                      TO MIR-CSN-PREM-OFFST-DUR.
           MOVE RRI-ASSUM-CO-REF-ID   TO MIR-ASSUM-CO-REF-ID.

           MOVE RRI-CSN-EFF-DT        TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CSN-EFF-DT.

           MOVE RRI-CSN-PD-TO-DT      TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CSN-PD-TO-DT.

           MOVE RRI-CSN-MAT-XPRY-DT   TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CSN-MAT-XPRY-DT.

           MOVE RRI-CSN-RSK-CALC-CD   TO MIR-CSN-RSK-CALC-CD.
           MOVE RRI-CSN-LIFE-ALLOW-ID TO MIR-CSN-LIFE-ALLOW-ID.
           MOVE RRI-CSN-WP-ALLOW-ID   TO MIR-CSN-WP-ALLOW-ID.
           MOVE RRI-CSN-AD-ALLOW-ID   TO MIR-CSN-AD-ALLOW-ID.
           MOVE RRI-CSN-FE-ALLOW-ID   TO MIR-CSN-FE-ALLOW-ID.
           MOVE RRI-CSN-ME-ALLOW-ID   TO MIR-CSN-ME-ALLOW-ID.

008455*    MOVE RRI-CSN-WP-FACE-AMT          TO WS-HOLD-9V2.
008455*    MOVE WS-DISP-9V2                  TO MIR-CSN-WP-FACE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-CSN-WP-FACE-AMT * 100.
020874     MOVE RRI-CSN-WP-FACE-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-WP-FACE-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-WP-FACE-AMT.
008455
008455*    MOVE RRI-CSN-AD-FACE-AMT          TO WS-HOLD-9V2.
008455*    MOVE WS-DISP-9V2                  TO MIR-CSN-AD-FACE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-CSN-AD-FACE-AMT * 100.
020874     MOVE RRI-CSN-AD-FACE-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-AD-FACE-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-AD-FACE-AMT.
008455
020874*    MOVE RRI-CSN-FE-FCT        TO WS-HOLD-3V2.
020874*    MOVE WS-DISP-3V2           TO MIR-CSN-FE-FCT.
020874     MOVE RRI-CSN-FE-FCT        TO L0290-INPUT-V02.
020874     MOVE 2                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CSN-FE-FCT
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-FE-FCT.
020874*    MOVE RRI-CSN-ME-FCT        TO WS-HOLD-3V2.
020874*    MOVE WS-DISP-3V2           TO MIR-CSN-ME-FCT.
020874     MOVE RRI-CSN-ME-FCT        TO L0290-INPUT-V02.
020874     MOVE 2                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-CSN-ME-FCT
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-ME-FCT.
008455*    MOVE RRI-CSN-ORIG-RSK-AMT         TO WS-HOLD-9V2.
008455*    MOVE WS-HOLD-9V2                  TO MIR-CSN-ORIG-RSK-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-CSN-ORIG-RSK-AMT * 100.
020874     MOVE RRI-CSN-ORIG-RSK-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-ORIG-RSK-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-ORIG-RSK-AMT.
008455
008455*    COMPUTE WS-HOLD-9V2 = WCVGS-CVG-FACE-AMT (I)
008455*                        - RRI-CSN-ORIG-RSK-AMT.
008455*    MOVE WS-DISP-9V2                  TO MIR-DIRET.
013578*    COMPUTE L0290-INPUT-NUMBER
013578*         = (WCVGS-CVG-FACE-AMT (I) - RRI-CSN-ORIG-RSK-AMT) * 100.
013578*    MOVE 2                     TO L0290-PRECISION.
013578*    MOVE LENGTH OF MIR-DIRET   TO L0290-MAX-OUT-LEN.
013578*    PERFORM 0290-1000-NUMERIC-FORMAT
013578*       THRU 0290-1000-NUMERIC-FORMAT-X.
013578*    MOVE L0290-OUTPUT-DATA     TO MIR-DIRET.

008455*    MOVE RRI-CSN-RETEN-AMT            TO WS-HOLD-9V2.
008455*    MOVE WS-DISP-9V2                  TO MIR-CSN-RETEN-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-CSN-RETEN-AMT * 100.
020874     MOVE RRI-CSN-RETEN-AMT     TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-RETEN-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-RETEN-AMT.
008455
           MOVE RRI-BCK-BILL-REASN-CD TO MIR-BCK-BILL-REASN-CD.
008455*    MOVE RRI-BCK-BILL-PREM-AMT        TO WS-HOLD-S7V2.
008455*    MOVE WS-DISP-S7V2                 TO MIR-BCK-BILL-PREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-BCK-BILL-PREM-AMT * 100.
020874     MOVE RRI-BCK-BILL-PREM-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-BCK-BILL-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY           TO TRUE.
008455     SET  L0290-SIGN-POS-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-BCK-BILL-PREM-AMT.
008455
008455*    MOVE RRI-BCK-BILL-ALLOW-AMT       TO WS-HOLD-S7V2.
008455*    MOVE WS-DISP-S7V2                 TO MIR-BCK-BILL-ALLOW-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-BCK-BILL-ALLOW-AMT * 100.
020874     MOVE RRI-BCK-BILL-ALLOW-AMT TO L0290-INPUT-V02.
008455     MOVE 2                      TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-BCK-BILL-ALLOW-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY           TO TRUE.
008455     SET  L0290-SIGN-POS-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-BCK-BILL-ALLOW-AMT.
008455
557659*    MOVE RRI-CSN-RESTR-PREM-CD        TO MIR-CSN-RESTR-PREM-IND.
557659     MOVE RRI-CSN-RESTR-PREM-IND        TO MIR-CSN-RESTR-PREM-IND.
008455*    MOVE RRI-CSN-TOT-NPREM-AMT        TO WS-HOLD-S7V2.
008455*    MOVE WS-DISP-S7V2                 TO MIR-CSN-TOT-NPREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-CSN-TOT-NPREM-AMT * 100.
020874     MOVE RRI-CSN-TOT-NPREM-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-TOT-NPREM-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY           TO TRUE.
008455     SET  L0290-SIGN-POS-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-TOT-NPREM-AMT.
008455
008455*    MOVE RRI-CSN-CRNT-RSK-AMT         TO WS-HOLD-9V2.
008455*    MOVE WS-DISP-9V2                  TO MIR-CSN-CRNT-RSK-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-CSN-CRNT-RSK-AMT * 100.
020874     MOVE RRI-CSN-CRNT-RSK-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-CRNT-RSK-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-CRNT-RSK-AMT.
008455
008455*    MOVE RRI-CSN-RSK-DECR-AMT         TO WS-HOLD-7V0.
008455*    MOVE WS-HOLD-7V0                  TO MIR-CSN-RSK-DECR-AMT.
020874*    MOVE RRI-CSN-RSK-DECR-AMT  TO L0290-INPUT-NUMBER.
020874     MOVE RRI-CSN-RSK-DECR-AMT  TO L0290-INPUT-V00.
008455     MOVE 0                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-RSK-DECR-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-RSK-DECR-AMT.

008455*    MOVE RRI-CSN-BASIC-PREM-AMT       TO WS-HOLD-7V2.
008455*    MOVE WS-DISP-7V2                  TO MIR-CSN-BASIC-PREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-CSN-BASIC-PREM-AMT * 100.
020874     MOVE RRI-CSN-BASIC-PREM-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                       TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-BASIC-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-BASIC-PREM-AMT.
008455
008455*    MOVE RRI-CSN-PFEE-AMT             TO WS-HOLD-S3V2.
008455*    MOVE WS-DISP-S3V2                 TO MIR-CSN-PFEE-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-CSN-PFEE-AMT * 100.
020874     MOVE RRI-CSN-PFEE-AMT      TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-PFEE-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY           TO TRUE.
008455     SET  L0290-SIGN-POS-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-PFEE-AMT.
008455
008455*    MOVE RRI-CSN-AD-PREM-AMT          TO WS-HOLD-7V2.
008455*    MOVE WS-DISP-7V2                  TO MIR-CSN-AD-PREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-CSN-AD-PREM-AMT * 100.
020874     MOVE RRI-CSN-AD-PREM-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-AD-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-AD-PREM-AMT.
008455
008455*    MOVE RRI-CSN-WP-PREM-AMT          TO WS-HOLD-7V2.
008455*    MOVE WS-DISP-7V2                  TO MIR-CSN-WP-PREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-CSN-WP-PREM-AMT * 100.
020874     MOVE RRI-CSN-WP-PREM-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-WP-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-WP-PREM-AMT.
008455
008455*    MOVE RRI-CSN-FE-PREM-AMT          TO WS-HOLD-7V2.
008455*    MOVE WS-DISP-7V2                  TO MIR-CSN-FE-PREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-CSN-FE-PREM-AMT * 100.
020874     MOVE RRI-CSN-FE-PREM-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-FE-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-FE-PREM-AMT.
008455
008455*    MOVE RRI-CSN-ME-PREM-AMT          TO WS-HOLD-7V2.
008455*    MOVE WS-DISP-7V2                  TO MIR-CSN-ME-PREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-CSN-ME-PREM-AMT * 100.
020874     MOVE RRI-CSN-ME-PREM-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-ME-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-ME-PREM-AMT.
008455
008455*    MOVE RRI-CSN-TOT-ALLOW-AMT        TO WS-HOLD-S7V2.
008455*    MOVE WS-DISP-S7V2                 TO MIR-CSN-TOT-ALLOW-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-CSN-TOT-ALLOW-AMT * 100.
020874     MOVE RRI-CSN-TOT-ALLOW-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-TOT-ALLOW-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY           TO TRUE.
008455     SET  L0290-SIGN-POS-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-TOT-ALLOW-AMT.

           MOVE RRI-CSN-NOTI-DT       TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CSN-NOTI-DT.

           MOVE RRI-CSN-NOTI-CD       TO MIR-CSN-NOTI-CD.
           MOVE RRI-CSN-STAT-CD       TO MIR-CSN-STAT-CD.
           MOVE RRI-CSN-PREV-STAT-CD  TO MIR-CSN-PREV-STAT-CD.
008455*    MOVE RRI-CSN-NPREM-YTD-AMT        TO WS-HOLD-7V2.
008455*    MOVE WS-DISP-7V2                  TO MIR-GROSS.
013578*    COMPUTE L0290-INPUT-NUMBER = RRI-CSN-NPREM-YTD-AMT * 100.
013578*    MOVE 2                     TO L0290-PRECISION.
013578*    MOVE LENGTH OF MIR-GROSS   TO L0290-MAX-OUT-LEN.
013578*    PERFORM 0290-1000-NUMERIC-FORMAT
013578*       THRU 0290-1000-NUMERIC-FORMAT-X.
013578*    MOVE L0290-OUTPUT-DATA     TO MIR-GROSS.

           MOVE RRI-CSN-CHNG-EFF-DT   TO L1640-INTERNAL-DATE.
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-CSN-CHNG-EFF-DT.

           MOVE RRI-REDC-EP-ALLOW-ID  TO MIR-REDC-EP-ALLOW-ID.
           MOVE RRI-OWN-OCCP-ALLOW-ID TO MIR-OWN-OCCP-ALLOW-ID.
           MOVE RRI-CSN-LTA-ALLOW-ID  TO MIR-CSN-LTA-ALLOW-ID.
           MOVE RRI-CSN-LTB-ALLOW-ID  TO MIR-CSN-LTB-ALLOW-ID.
           MOVE RRI-PDISAB-ALLOW-ID   TO MIR-PDISAB-ALLOW-ID.
           MOVE RRI-CSN-COLA-ALLOW-ID TO MIR-CSN-COLA-ALLOW-ID.

008455*    MOVE RRI-REDC-EP-PREM-AMT         TO WS-HOLD-5V2.
008455*    MOVE WS-DISP-5V2                  TO MIR-REDC-EP-PREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-REDC-EP-PREM-AMT * 100.
020874     MOVE RRI-REDC-EP-PREM-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-REDC-EP-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-REDC-EP-PREM-AMT.
008455
008455*    MOVE RRI-OWN-OCCP-PREM-AMT        TO WS-HOLD-5V2.
008455*    MOVE WS-DISP-5V2                  TO MIR-OWN-OCCP-PREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-OWN-OCCP-PREM-AMT * 100.
020874     MOVE RRI-OWN-OCCP-PREM-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-OWN-OCCP-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-OWN-OCCP-PREM-AMT.
008455
008455*    MOVE RRI-CSN-LTA-PREM-AMT         TO WS-HOLD-5V2.
008455*    MOVE WS-DISP-5V2                  TO MIR-CSN-LTA-PREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-CSN-LTA-PREM-AMT * 100.
020874     MOVE RRI-CSN-LTA-PREM-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-LTA-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-LTA-PREM-AMT.
008455
008455*    MOVE RRI-CSN-LTB-PREM-AMT         TO WS-HOLD-5V2.
008455*    MOVE WS-DISP-5V2                  TO MIR-CSN-LTB-PREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-CSN-LTB-PREM-AMT * 100.
020874     MOVE RRI-CSN-LTB-PREM-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-LTB-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-LTB-PREM-AMT.
008455
008455*    MOVE RRI-PDISAB-PREM-AMT          TO WS-HOLD-5V2.
008455*    MOVE WS-DISP-5V2                  TO MIR-PDISAB-PREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-PDISAB-PREM-AMT * 100.
020874     MOVE RRI-PDISAB-PREM-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-PDISAB-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-PDISAB-PREM-AMT.
008455
008455*    MOVE RRI-CSN-COLA-PREM-AMT        TO WS-HOLD-5V2.
008455*    MOVE WS-DISP-5V2                  TO MIR-CSN-COLA-PREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = RRI-CSN-COLA-PREM-AMT * 100.
020874     MOVE RRI-CSN-COLA-PREM-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-COLA-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-COLA-PREM-AMT.

           SET  L0384-DO-NOT-DISP-MSG        TO TRUE.
008455*    MOVE L0384-LTA-ALLOW-AMT          TO WS-HOLD-5V2.

           IF  RRI-CSN-RSK-CALC-CD NOT = '6'
               PERFORM  0384-1000-BUILD-PARM-INFO
                   THRU 0384-1000-BUILD-PARM-INFO-X
               SET L0384-DISPLAY-MESSAGES    TO TRUE
               MOVE HOLD-RIDER-NO     TO L0384-CVG-NUM

               EVALUATE TRUE

                   WHEN WS-BUS-FCN-RETRIVE
                        MOVE 'I'     TO L0384-ENTER-CODE
                   WHEN WS-BUS-FCN-CREATE
                        MOVE 'C'     TO L0384-ENTER-CODE
                   WHEN WS-BUS-FCN-UPDATE
                        MOVE 'M'     TO L0384-ENTER-CODE
                   WHEN WS-BUS-FCN-DELETE
                        MOVE 'D'     TO L0384-ENTER-CODE

               END-EVALUATE

               PERFORM  0384-1000-CALC-RI-AMTS
                   THRU 0384-1000-CALC-RI-AMTS-X
           END-IF.

008455*    MOVE L0384-TOT-VAR-PREM-AMT       TO WS-HOLD-S7V2.
008455*    MOVE WS-DISP-S7V2                 TO MIR-BCK-BILL-PREM-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = L0384-TOT-VAR-PREM-AMT * 100.
020874     MOVE L0384-TOT-VAR-PREM-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                       TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-TOT-VAR-PREM-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY           TO TRUE.
008455     SET  L0290-SIGN-POS-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-TOT-VAR-PREM-AMT.
008455
008455*    MOVE L0384-LIFE-ALLOW-AMT         TO WS-HOLD-7V2.
008455*    MOVE WS-DISP-7V2                  TO MIR-DV-CSN-ALLOW-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = L0384-LIFE-ALLOW-AMT * 100.
020874     MOVE L0384-LIFE-ALLOW-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-LIFE-ALLOW-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-LIFE-ALLOW-AMT.
008455
008455*    MOVE L0384-REDC-EP-ALLOW-AMT      TO WS-HOLD-5V2.
008455*    MOVE WS-DISP-5V2                  TO MIR-DV-CSN-ALLOW-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = L0384-REDC-EP-ALLOW-AMT * 100.
020874     MOVE L0384-REDC-EP-ALLOW-AMT TO L0290-INPUT-V02.
008455     MOVE 2                       TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-REDC-EP-ALLOW-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-REDC-EP-ALLOW-AMT.
008455
008455*    MOVE L0384-OWN-OCCP-ALLOW-AMT     TO WS-HOLD-5V2.
008455*    MOVE WS-DISP-5V2                  TO MIR-DV-CSN-ALLOW-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = L0384-OWN-OCCP-ALLOW-AMT * 100.
020874     MOVE L0384-OWN-OCCP-ALLOW-AMT TO L0290-INPUT-V02.
008455     MOVE 2                        TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-OWN-OCCP-ALLOW-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-OWN-OCCP-ALLOW-AMT.
008455
008455*    MOVE L0384-LTA-ALLOW-AMT          TO WS-HOLD-5V2.
008455*    MOVE WS-DISP-5V2                  TO MIR-DV-CSN-ALLOW-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = L0384-LTA-ALLOW-AMT * 100.
020874     MOVE L0384-LTA-ALLOW-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-LTA-ALLOW-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-LTA-ALLOW-AMT.
008455
008455*    MOVE L0384-LTB-ALLOW-AMT          TO WS-HOLD-5V2.
008455*    MOVE WS-DISP-5V2                  TO MIR-DV-CSN-ALLOW-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = L0384-LTB-ALLOW-AMT * 100.
020874     MOVE L0384-LTB-ALLOW-AMT   TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-LTB-ALLOW-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-LTB-ALLOW-AMT.

008455*    MOVE L0384-PDISAB-ALLOW-AMT       TO WS-HOLD-5V2.
008455*    MOVE WS-DISP-5V2                  TO MIR-DV-CSN-ALLOW-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = L0384-PDISAB-ALLOW-AMT * 100.
020874     MOVE L0384-PDISAB-ALLOW-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                       TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-PDISAB-ALLOW-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-PDISAB-ALLOW-AMT.
008455
008455*    MOVE L0384-COLA-ALLOW-AMT         TO WS-HOLD-5V2.
008455*    MOVE WS-DISP-5V2                  TO MIR-DV-CSN-ALLOW-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = L0384-COLA-ALLOW-AMT * 100.
020874     MOVE L0384-COLA-ALLOW-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-COLA-ALLOW-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-COLA-ALLOW-AMT.
008455
008455*    MOVE L0384-ME-ALLOW-AMT           TO WS-HOLD-7V2.
008455*    MOVE WS-DISP-7V2                  TO MIR-DV-CSN-ALLOW-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = L0384-ME-ALLOW-AMT * 100.
020874     MOVE L0384-ME-ALLOW-AMT    TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-DV-ME-ALLOW-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-DV-ME-ALLOW-AMT.

008455*    COMPUTE WS-HOLD-S7V2 = RRI-CSN-TOT-NPREM-AMT
008455*                         - RRI-CSN-TOT-ALLOW-AMT
008455*                         + RRI-CSN-PFEE-AMT.
008455*    MOVE WS-DISP-S7V2                 TO MIR-CSN-NPREM-YTD-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER = (RRI-CSN-TOT-NPREM-AMT
020874*                               -  RRI-CSN-TOT-ALLOW-AMT
020874*                               +  RRI-CSN-PFEE-AMT) * 100.
019507     MOVE RRI-CSN-NPREM-YTD-AMT TO L0290-INPUT-V02
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-CSN-NPREM-YTD-AMT
                                      TO L0290-MAX-OUT-LEN.
008455     SET  L0290-SIGN-DISPLAY           TO TRUE.
008455     SET  L0290-SIGN-POS-DISPLAY       TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-CSN-NPREM-YTD-AMT.

013578*010418     MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.

019507     MOVE L0384-FE-ALLOW-AMT    TO L0290-INPUT-V02.
019507     MOVE 2                     TO L0290-PRECISION.
019507     MOVE LENGTH OF MIR-DV-CSN-FE-ALLOW-AMT
019507                                TO L0290-MAX-OUT-LEN.
019507     PERFORM 0290-2000-FORMAT-FOR-MIR
019507        THRU 0290-2000-FORMAT-FOR-MIR-X.
019507     MOVE L0290-OUTPUT-DATA     TO MIR-DV-CSN-FE-ALLOW-AMT.

019507     MOVE L0384-WP-ALLOW-AMT    TO L0290-INPUT-V02.
019507     MOVE 2                     TO L0290-PRECISION.
019507     MOVE LENGTH OF MIR-DV-CSN-WP-ALLOW-AMT
019507                                TO L0290-MAX-OUT-LEN.
019507     PERFORM 0290-2000-FORMAT-FOR-MIR
019507        THRU 0290-2000-FORMAT-FOR-MIR-X.
019507     MOVE L0290-OUTPUT-DATA     TO MIR-DV-CSN-WP-ALLOW-AMT.

019507     MOVE L0384-AD-ALLOW-AMT    TO L0290-INPUT-V02.
019507     MOVE 2                     TO L0290-PRECISION.
019507     MOVE LENGTH OF MIR-DV-CSN-AD-ALLOW-AMT
019507                                TO L0290-MAX-OUT-LEN.
019507     PERFORM 0290-2000-FORMAT-FOR-MIR
019507        THRU 0290-2000-FORMAT-FOR-MIR-X.
019507     MOVE L0290-OUTPUT-DATA     TO MIR-DV-CSN-AD-ALLOW-AMT.


       7000-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      *-------------------------
       8000-READ-REINSURANCE-IN.
      *-------------------------

           MOVE 'C'                   TO WRI-CSN-REC-TYP-CD.
           MOVE RPOL-POL-ID           TO WRI-POL-ID.
           MOVE HOLD-RIDER-NO         TO WRI-CVG-NUM-N.
           MOVE HOLD-REIN-NO          TO WRI-CSN-REC-NUM-N.

           PERFORM  RI-1000-READ-FOR-UPDATE
               THRU RI-1000-READ-FOR-UPDATE-X.

       8000-READ-REINSURANCE-IN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

            MOVE SPACES               TO WGLOB-MSIN-REFERENCE.
            MOVE WGLOB-COMPANY-CODE   TO WGLOB-REF-COMPANY-CODE.
            MOVE 'P'                  TO WGLOB-REF-POLICY-OR-CLIENT.
            MOVE MIR-POL-ID-BASE      TO WGLOB-REF-POLICY-NUMBER.
            MOVE MIR-POL-ID-SFX       TO WGLOB-REF-POLICY-SUFFIX.
            MOVE MIR-CVG-NUM          TO WGLOB-REF-COVERAGE-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0384-0000-INIT-PARM-INFO
025970         THRU 0384-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0389-0000-INIT-PARM-INFO
025970         THRU 0389-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE       WS-PGM-WORK-AREA.
025970     INITIALIZE       MC-MISC-WORK-AREAS.
025970     INITIALIZE       LITTLE-WORK-AREAS.
025970     INITIALIZE       WS-PROGRAM-CONTROL-SWITCHES
025970     INITIALIZE       WS-NUMBER-EDITING.
025970     INITIALIZE       WS-STATUS-CODE.
025970     INITIALIZE       WRIDF-WORK-AREA.
025970
025970     SET WS-TRANS-NAME-DEFAULT TO TRUE.
025970     SET NUM-ERR-LN-DEFAULT    TO TRUE.   
025970     SET MAX-REINSURED-DEFAULT TO TRUE.
025970     SET WS-TWRK-KEY-DEFAULT   TO TRUE.
025970     SET HOLD-RUN-ID-DEFAULT   TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ******************************************************************
      * PROCESSING COPYBOOKS
      ******************************************************************

028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY NCPPCVGS.
       COPY NCPPCVGR.
      /
       COPY CCPPRIDF.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
025970 COPY XCPS8090.
       COPY CCPSPGA.
      /
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      /
      ******************************************************************
      * LINKAGE PROCESSING COPYBOOKS
      ******************************************************************

028298 COPY CCPS2626.
028298 COPY CCPL2626.
008455 COPY XCPL0290.
008455 COPY XCPS0290.
008455/
018764*COPY CCCL0384.
018764 COPY CCPL0384.
       COPY CCPS0384.
      /
018764*COPY CCCL2430.
018764 COPY CCPL2430.
       COPY CCPS2430.
      /
       COPY CCPS2435.
018764*COPY CCCL2435.
018764 COPY CCPL2435.
      /
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      /
       COPY CCPS0389.
018764*COPY CCCL0389.
018764 COPY CCPL0389.
      /
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
025970 COPY CCPS0620.
557668 COPY CCPL0620.
557668/
      *****************************************************************
      * FILE I/O PROCESS MODULES
      *****************************************************************

       COPY CCPNPOL.
014221 COPY CCPUPOL.
      /
       COPY CCPCTT.
       COPY CCPNTT.
016537*COPY CCPATT.
      /
       COPY CCPNCVG.
       COPY CCPUCVG.
      /
       COPY CCPCRI.
       COPY CCPURI.
       COPY CCPARI.
       COPY CCPXRI.
      /
      *****************************************************************
      * ERROR HANDLING ROUTINES
      *****************************************************************

557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM0381                     **
      *****************************************************************
