      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4480.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4480                                         **
      **  REMARKS:  PGAL - POLICY GAIN ALLOCATION RETRIEVE           **
      **            THIS MODULE RETRIEVES RECORED FROM PGAL TABLE    **
      **                                                             **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
015290**  6.3       PRE & POST TEFRA PROCESSING ENHANCEMENTS         **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4480'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

025970 01  WS-CONSTANT-AREA.
025970     05  WS-TWRK-KEY                  PIC X(04)
025970                                      VALUE '4480'.
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '4480'.
025970     05  WS-MAX-ALLOC-TYP             PIC S9(04) BINARY
025970                                      VALUE +9.
025970         88  WS-MAX-ALLOC-TYP-DEFAULT VALUE +9.
025970
       01  WS-PGM-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-RETRIEVE      VALUE '4480'.
025970*    05  WS-TWRK-KEY                  PIC X(04)
025970*                                     VALUE '4480'.
           05  WS-SUB                       PIC S9(04) BINARY.
           05  WS-SUB2                      PIC S9(04) BINARY.
           05  WS-START-ROW                 PIC S9(04) BINARY.
025970*    05  WS-MAX-ALLOC-TYP             PIC S9(04) BINARY
025970*                                     VALUE +9.
           05  WS-POL-ID.
               10  WS-POL-ID-BASE           PIC X(09).
               10  WS-POL-ID-SFX            PIC X(01).
           05  WS-ALLOC-TYP-MATCH-IND       PIC X(01).
               88  WS-ALLOC-TYP-MATCH-NO    VALUE 'N'.
               88  WS-ALLOC-TYP-MATCH-YES   VALUE 'Y'.
           05  WS-SORT-DONE-IND             PIC X(01).
               88  WS-SORT-DONE-NO          VALUE 'N'.
               88  WS-SORT-DONE-YES         VALUE 'Y'.
           05  WS-SORT-MATCH-IND            PIC X(01).
               88  WS-SORT-MATCH-NO         VALUE 'N'.
               88  WS-SORT-MATCH-YES        VALUE 'Y'.
           05  WS-MIR-AREA.
               10 WS-MIR-POL-ID               PIC X(010).
               10 WS-MIR-PGAL-TRXN-TYP-CD     PIC X(001).
               10 WS-MIR-PGAL-EFF-DT          PIC X(010).
               10 WS-MIR-PGAL-SEQ-NUM         PIC X(003).
               10 WS-MIR-PGAL-ALLOC-TYP-CD    PIC X(001).
               10 WS-MIR-PGAL-TRXN-STAT-CD    PIC X(001).
               10 WS-MIR-PGAL-OPN-PRIN-AMT    PIC X(017).
               10 WS-MIR-PGAL-OPN-GAIN-AMT    PIC X(017).
               10 WS-MIR-PGAL-TRXN-PRIN-AMT   PIC X(017).
               10 WS-MIR-PGAL-TRXN-GAIN-AMT   PIC X(017).
               10 WS-MIR-PGAL-SURR-CHRG-AMT   PIC X(017).
               10 WS-MIR-PGAL-APROX-CV-IND    PIC X(001).

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY CCWWLOCK.
       COPY CCWWINDX.
026057 COPY CCWWIHSD.
026057 COPY XCWWWKDT.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
021930*COPY CCFWPGAL.
       COPY CCFRPGAL.
       COPY CCFWPGAS.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
       COPY CCFRCVG.
       COPY CCFWCVG.
       COPY CCWWCVGS.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
028298 COPY CCWL2626.
       COPY CCWL3088.
       COPY XCWLDTLK.
021930*COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
021930*COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
       COPY XCWL8090.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM4480.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

025970*    SET  MIR-RETRN-OK          TO TRUE.
025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
025970*    MOVE MIR-POL-ID-BASE       TO WS-POL-ID-BASE.
025970*    MOVE MIR-POL-ID-SFX        TO WS-POL-ID-SFX.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 3000-PROCESS-RETRIEVE
                       THRU 3000-PROCESS-RETRIEVE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM4480'   TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237' TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------
       3000-PROCESS-RETRIEVE.
      *----------------------

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           IF  WS-POL-ID = SPACES
      *MSG: POLICY ID MUST BE FILLED
              MOVE 'CS44800001'       TO WGLOB-MSG-REF-INFO
              MOVE WPOL-KEY           TO WGLOB-MSG-PARM (1)
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
              SET WGLOB-RETURN-ERROR  TO TRUE
              GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM 6000-BUILD-KEY
              THRU 6000-BUILD-KEY-X.

           IF WGLOB-RETURN-ERROR
              GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.


           IF WPOL-IO-NOT-FOUND
      *MSG: POLICY RECORD NOT FOUND
              MOVE 'CS44800002'       TO WGLOB-MSG-REF-INFO
              MOVE WPOL-KEY           TO WGLOB-MSG-PARM (1)
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
              SET WGLOB-RETURN-ERROR  TO TRUE
              GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WPGAS-PGAL-EFF-DT        TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057        SET WGLOB-RETURN-ERROR     TO TRUE
026057        GO TO 3000-PROCESS-RETRIEVE-X
026057     END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           PERFORM  3088-0000-INIT-PARM-INFO
               THRU 3088-0000-INIT-PARM-INFO-X.

           MOVE RPOL-POL-ID           TO L3088-POL-ID.

           PERFORM  3088-3000-OBTAIN-PLAR
               THRU 3088-3000-OBTAIN-PLAR-X.

           IF  NOT L3088-RETRN-OK
           OR  L3088-PLAR-REC-NOT-FOUND
      *MSG: PLAN ALLOCATION RECORD NOT FOUND
              MOVE 'CS44800003'       TO WGLOB-MSG-REF-INFO
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
              SET WGLOB-RETURN-ERROR  TO TRUE
              GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  3100-SETUP-MIR-ALLOC-TYP-CD
               THRU 3100-SETUP-MIR-ALLOC-TYP-CD-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-ALLOC-TYP.


           PERFORM  PGAS-1000-BROWSE
               THRU PGAS-1000-BROWSE-X.

           PERFORM  PGAS-2000-READ-NEXT
               THRU PGAS-2000-READ-NEXT-X.

           IF  NOT WPGAS-IO-OK
      *MSG:  RECORD NOT FOUND
               MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
021930*        MOVE WPGAL-KEY          TO WGLOB-MSG-PARM (1)
021930         MOVE WPGAS-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM 0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  3400-RETRIEVE-ALLOC-REC
                   THRU 3400-RETRIEVE-ALLOC-REC-X
                   UNTIL NOT WPGAS-IO-OK
           END-IF.

           PERFORM  PGAS-3000-END-BROWSE
               THRU PGAS-3000-END-BROWSE-X.

           SET WS-SORT-DONE-NO         TO TRUE.
           PERFORM  3500-SORT-MIR-TABLE
               THRU 3500-SORT-MIR-TABLE-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > WS-MAX-ALLOC-TYP
               OR      WS-SORT-DONE-YES.

       3000-PROCESS-RETRIEVE-X.
           EXIT.


      *---------------------------
       3100-SETUP-MIR-ALLOC-TYP-CD.
      *---------------------------

           IF  L3088-PLAR-ALLOC-TYP-CD (WS-SUB) NOT = SPACE
               MOVE L3088-PLAR-ALLOC-TYP-CD (WS-SUB)
               TO   MIR-PGAL-ALLOC-TYP-CD-T (WS-SUB)
           END-IF.

       3100-SETUP-MIR-ALLOC-TYP-CD-X.
           EXIT.


      *---------------------
       3200-MATCH-ALLOC-TYP.
      *---------------------

           IF  MIR-PGAL-ALLOC-TYP-CD-T (WS-SUB2) =
               RPGAL-PGAL-ALLOC-TYP-CD
               MOVE WS-SUB2                 TO  WS-SUB
               SET  WS-ALLOC-TYP-MATCH-YES  TO TRUE
           END-IF.

       3200-MATCH-ALLOC-TYP-X.
           EXIT.

      /
      *---------------------------
       3400-RETRIEVE-ALLOC-REC.
      *---------------------------

           SET  WS-ALLOC-TYP-MATCH-NO    TO TRUE.

           PERFORM  3200-MATCH-ALLOC-TYP
               THRU 3200-MATCH-ALLOC-TYP-X
               VARYING WS-SUB2 FROM 1 BY 1
               UNTIL   WS-SUB2 > WS-MAX-ALLOC-TYP
               OR      WS-ALLOC-TYP-MATCH-YES.

           IF WS-ALLOC-TYP-MATCH-NO
      *MSG: PGAL ALLOCATION RECORD NOT MATCHING PLAR
              MOVE 'CS44800004'       TO WGLOB-MSG-REF-INFO
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
              SET WGLOB-RETURN-ERROR  TO TRUE
              GO TO 3400-RETRIEVE-ALLOC-REC-X
           END-IF.

           PERFORM  9200-MOVE-RECORD-TO-MIR
               THRU 9200-MOVE-RECORD-TO-MIR-X.

           PERFORM  PGAS-2000-READ-NEXT
               THRU PGAS-2000-READ-NEXT-X.


       3400-RETRIEVE-ALLOC-REC-X.
           EXIT.


      *--------------------
       3500-SORT-MIR-TABLE.
      *--------------------

           IF  MIR-PGAL-TRXN-STAT-CD-T (WS-SUB) NOT = SPACE
               GO TO 3500-SORT-MIR-TABLE-X
           END-IF.

           IF WS-SUB = WS-MAX-ALLOC-TYP
              GO TO 3500-SORT-MIR-TABLE-X
           END-IF.

           MOVE WS-SUB            TO WS-START-ROW.
           ADD  1                 TO WS-START-ROW.
           SET WS-SORT-MATCH-NO    TO TRUE.
           PERFORM  3510-SORT-MIR-TABLE-LOOP
               THRU 3510-SORT-MIR-TABLE-LOOP-X
               VARYING WS-SUB2 FROM WS-START-ROW BY 1
               UNTIL   WS-SUB2 > WS-MAX-ALLOC-TYP
               OR      WS-SORT-MATCH-YES.

           IF WS-SORT-MATCH-NO
              SET WS-SORT-DONE-YES   TO TRUE
           END-IF.

       3500-SORT-MIR-TABLE-X.
           EXIT.

      *------------------------
       3510-SORT-MIR-TABLE-LOOP.
      *------------------------

           IF  MIR-PGAL-TRXN-STAT-CD-T (WS-SUB2) = SPACE
               GO TO 3510-SORT-MIR-TABLE-LOOP-X
           END-IF.

           MOVE MIR-POL-ID-T             (WS-SUB)
             TO WS-MIR-POL-ID.

           MOVE MIR-PGAL-TRXN-TYP-CD-T   (WS-SUB)
             TO WS-MIR-PGAL-TRXN-TYP-CD.

           MOVE MIR-PGAL-EFF-DT-T        (WS-SUB)
             TO WS-MIR-PGAL-EFF-DT.

           MOVE MIR-PGAL-SEQ-NUM-T       (WS-SUB)
             TO WS-MIR-PGAL-SEQ-NUM.

           MOVE MIR-PGAL-ALLOC-TYP-CD-T  (WS-SUB)
             TO WS-MIR-PGAL-ALLOC-TYP-CD.

           MOVE MIR-PGAL-TRXN-STAT-CD-T  (WS-SUB)
             TO WS-MIR-PGAL-TRXN-STAT-CD.

           MOVE MIR-PGAL-OPN-PRIN-AMT-T  (WS-SUB)
             TO WS-MIR-PGAL-OPN-PRIN-AMT.

           MOVE MIR-PGAL-OPN-GAIN-AMT-T  (WS-SUB)
             TO WS-MIR-PGAL-OPN-GAIN-AMT.

           MOVE MIR-PGAL-TRXN-PRIN-AMT-T (WS-SUB)
             TO WS-MIR-PGAL-TRXN-PRIN-AMT.

           MOVE MIR-PGAL-TRXN-GAIN-AMT-T (WS-SUB)
             TO WS-MIR-PGAL-TRXN-GAIN-AMT.

           MOVE MIR-PGAL-SURR-CHRG-AMT-T (WS-SUB)
             TO WS-MIR-PGAL-SURR-CHRG-AMT.

           MOVE MIR-PGAL-APROX-CV-IND-T  (WS-SUB)
             TO WS-MIR-PGAL-APROX-CV-IND.


           MOVE MIR-POL-ID-T             (WS-SUB2)
             TO MIR-POL-ID-T             (WS-SUB ).

           MOVE MIR-PGAL-TRXN-TYP-CD-T   (WS-SUB2)
             TO MIR-PGAL-TRXN-TYP-CD-T   (WS-SUB ).

           MOVE MIR-PGAL-EFF-DT-T        (WS-SUB2)
             TO MIR-PGAL-EFF-DT-T        (WS-SUB ).

           MOVE MIR-PGAL-SEQ-NUM-T       (WS-SUB2)
             TO MIR-PGAL-SEQ-NUM-T       (WS-SUB ).

           MOVE MIR-PGAL-ALLOC-TYP-CD-T  (WS-SUB2)
             TO MIR-PGAL-ALLOC-TYP-CD-T  (WS-SUB ).

           MOVE MIR-PGAL-TRXN-STAT-CD-T  (WS-SUB2)
             TO MIR-PGAL-TRXN-STAT-CD-T  (WS-SUB ).

           MOVE MIR-PGAL-OPN-PRIN-AMT-T  (WS-SUB2)
             TO MIR-PGAL-OPN-PRIN-AMT-T  (WS-SUB ).

           MOVE MIR-PGAL-OPN-GAIN-AMT-T  (WS-SUB2)
             TO MIR-PGAL-OPN-GAIN-AMT-T  (WS-SUB ).

           MOVE MIR-PGAL-TRXN-PRIN-AMT-T (WS-SUB2)
             TO MIR-PGAL-TRXN-PRIN-AMT-T (WS-SUB ).

           MOVE MIR-PGAL-TRXN-GAIN-AMT-T (WS-SUB2)
             TO MIR-PGAL-TRXN-GAIN-AMT-T (WS-SUB ).

           MOVE MIR-PGAL-SURR-CHRG-AMT-T (WS-SUB2)
             TO MIR-PGAL-SURR-CHRG-AMT-T (WS-SUB ).

           MOVE MIR-PGAL-APROX-CV-IND-T  (WS-SUB2)
             TO MIR-PGAL-APROX-CV-IND-T  (WS-SUB ).


           MOVE WS-MIR-POL-ID
             TO MIR-POL-ID-T             (WS-SUB2).

           MOVE WS-MIR-PGAL-TRXN-TYP-CD
             TO MIR-PGAL-TRXN-TYP-CD-T   (WS-SUB2).

           MOVE WS-MIR-PGAL-EFF-DT
             TO MIR-PGAL-EFF-DT-T        (WS-SUB2).

           MOVE WS-MIR-PGAL-SEQ-NUM
             TO MIR-PGAL-SEQ-NUM-T       (WS-SUB2).

           MOVE WS-MIR-PGAL-ALLOC-TYP-CD
             TO MIR-PGAL-ALLOC-TYP-CD-T  (WS-SUB2).

           MOVE WS-MIR-PGAL-TRXN-STAT-CD
             TO MIR-PGAL-TRXN-STAT-CD-T  (WS-SUB2).

           MOVE WS-MIR-PGAL-OPN-PRIN-AMT
             TO MIR-PGAL-OPN-PRIN-AMT-T  (WS-SUB2).

           MOVE WS-MIR-PGAL-OPN-GAIN-AMT
             TO MIR-PGAL-OPN-GAIN-AMT-T  (WS-SUB2).

           MOVE WS-MIR-PGAL-TRXN-PRIN-AMT
             TO MIR-PGAL-TRXN-PRIN-AMT-T (WS-SUB2).

           MOVE WS-MIR-PGAL-TRXN-GAIN-AMT
             TO MIR-PGAL-TRXN-GAIN-AMT-T (WS-SUB2).

           MOVE WS-MIR-PGAL-SURR-CHRG-AMT
             TO MIR-PGAL-SURR-CHRG-AMT-T (WS-SUB2).

           MOVE WS-MIR-PGAL-APROX-CV-IND
             TO MIR-PGAL-APROX-CV-IND-T  (WS-SUB2).

           SET WS-SORT-MATCH-YES      TO TRUE.

       3510-SORT-MIR-TABLE-LOOP-X.
           EXIT.
      /
      *---------------
       6000-BUILD-KEY.
      *---------------

           MOVE WS-POL-ID             TO WPOL-POL-ID.

           MOVE WS-POL-ID             TO WPGAS-POL-ID.
           MOVE MIR-PGAL-TRXN-TYP-CD  TO WPGAS-PGAL-TRXN-TYP-CD.

           MOVE MIR-PGAL-EFF-DT       TO L1640-EXTERNAL-DATE
020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
      * MSG: INVALID DATE
               MOVE 'XS00000036'      TO WGLOB-MSG-REF-INFO
               MOVE MIR-PGAL-EFF-DT   TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR     TO TRUE
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO WPGAS-PGAL-EFF-DT
           END-IF.

           MOVE MIR-PGAL-SEQ-NUM      TO WPGAS-PGAL-SEQ-NUM.
           MOVE LOW-VALUES            TO WPGAS-PGAL-ALLOC-TYP-CD.
           MOVE WPGAS-KEY             TO WPGAS-ENDBR-KEY.
           MOVE HIGH-VALUES           TO WPGAS-ENDBR-PGAL-ALLOC-TYP-CD.

       6000-BUILD-KEY-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-POL-ID-G.
           MOVE SPACES                TO MIR-PGAL-TRXN-TYP-CD-G.
           MOVE SPACES                TO MIR-PGAL-EFF-DT-G.
           MOVE SPACES                TO MIR-PGAL-SEQ-NUM-G.
           MOVE SPACES                TO MIR-PGAL-ALLOC-TYP-CD-G.
           MOVE SPACES                TO MIR-PGAL-TRXN-STAT-CD-G.
           MOVE SPACES                TO MIR-PGAL-OPN-PRIN-AMT-G.
           MOVE SPACES                TO MIR-PGAL-OPN-GAIN-AMT-G.
           MOVE SPACES                TO MIR-PGAL-TRXN-PRIN-AMT-G.
           MOVE SPACES                TO MIR-PGAL-TRXN-GAIN-AMT-G.
           MOVE SPACES                TO MIR-PGAL-SURR-CHRG-AMT-G.
           MOVE SPACES                TO MIR-PGAL-APROX-CV-IND-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *------------------------
       9200-MOVE-RECORD-TO-MIR.
      *------------------------

           MOVE RPGAL-POL-ID          TO MIR-POL-ID-T (WS-SUB).
           MOVE RPGAL-PGAL-TRXN-TYP-CD
                                      TO MIR-PGAL-TRXN-TYP-CD-T
                                         (WS-SUB).

           MOVE RPGAL-PGAL-EFF-DT     TO L1640-INTERNAL-DATE
020462*    PERFORM 1640-2000-INTERNAL-TO-EXT
020462*       THRU 1640-2000-INTERNAL-TO-EXT-X
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE   TO MIR-PGAL-EFF-DT-T  (WS-SUB).

           MOVE RPGAL-PGAL-SEQ-NUM    TO MIR-PGAL-SEQ-NUM-T (WS-SUB).
           MOVE RPGAL-PGAL-TRXN-STAT-CD
                                      TO MIR-PGAL-TRXN-STAT-CD-T
                                         (WS-SUB).
           MOVE RPGAL-PGAL-APROX-CV-IND
                                      TO MIR-PGAL-APROX-CV-IND-T
                                         (WS-SUB).

           MOVE RPGAL-PGAL-ALLOC-TYP-CD
                                      TO MIR-PGAL-ALLOC-TYP-CD-T
                                         (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RPGAL-PGAL-OPN-PRIN-AMT * 100.
020874     MOVE RPGAL-PGAL-OPN-PRIN-AMT TO L0290-INPUT-V02.
           SET  L0290-SIGN-DISPLAY      TO TRUE.
           SET  L0290-SIGN-POS-DISPLAY  TO TRUE.
           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PGAL-OPN-PRIN-AMT-T (WS-SUB)
                                        TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO MIR-PGAL-OPN-PRIN-AMT-T
                                         (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RPGAL-PGAL-OPN-GAIN-AMT * 100.
020874     MOVE RPGAL-PGAL-OPN-GAIN-AMT TO L0290-INPUT-V02.
           SET L0290-SIGN-DISPLAY       TO TRUE.
           SET L0290-SIGN-POS-DISPLAY   TO TRUE.
           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PGAL-OPN-GAIN-AMT-T (WS-SUB)
                                        TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO MIR-PGAL-OPN-GAIN-AMT-T
                                           (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RPGAL-PGAL-TRXN-PRIN-AMT * 100.
020874     MOVE RPGAL-PGAL-TRXN-PRIN-AMT TO L0290-INPUT-V02.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-POS-DISPLAY    TO TRUE.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PGAL-TRXN-PRIN-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-PGAL-TRXN-PRIN-AMT-T
                                         (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RPGAL-PGAL-TRXN-GAIN-AMT * 100.
020874     MOVE RPGAL-PGAL-TRXN-GAIN-AMT TO L0290-INPUT-V02.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-POS-DISPLAY    TO TRUE.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PGAL-TRXN-GAIN-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-PGAL-TRXN-GAIN-AMT-T
                                         (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = RPGAL-PGAL-SURR-CHRG-AMT * 100.
020874     MOVE RPGAL-PGAL-SURR-CHRG-AMT TO L0290-INPUT-V02.
           SET L0290-SIGN-DISPLAY        TO TRUE.
           SET L0290-SIGN-POS-DISPLAY    TO TRUE.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-PGAL-SURR-CHRG-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-PGAL-SURR-CHRG-AMT-T
                                         (WS-SUB).

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  3088-0000-INIT-PARM-INFO
025970         THRU 3088-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     SET  WS-TWRK-KEY-DEFAULT         TO TRUE.
025970     SET  WS-MAX-ALLOC-TYP-DEFAULT    TO TRUE.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
025970     MOVE MIR-POL-ID-BASE             TO WS-POL-ID-BASE.
025970     MOVE MIR-POL-ID-SFX              TO WS-POL-ID-SFX.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
026057 COPY CCPPIHSD.
       COPY XCPPINIT.
      /
       COPY XCPPEXIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
       COPY NCPPCVGS.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
025970 COPY XCPS1670.
025970 COPY XCPS8090.
       COPY CCPS3088.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL3088.
      /
       COPY XCPL0260.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
021930*COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
021930*COPY XCPS8090.
       COPY XCPL8090.
      /
      ****************************************************************
      *  FILE I/O PROCESS MODULES                                    *
      ****************************************************************
021930*COPY CCPNPGAL.
       COPY CCPBPGAS.
      /
       COPY CCPNPOL.
       COPY CCPUPOL.
       COPY CCPNCVG.
      /
      ****************************************************************
      *  ERROR HANDLING ROUTINES                                     *
      ****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM4480                     *
      ****************************************************************
