       IDENTIFICATION DIVISION.

       COPY XCWWCRHT.

       PROGRAM-ID. CSOM2822.

      *****************************************************************
      **  MEMBER : CSOM2822                                          **
      **  REMARKS: POLICY DIVIDEND OPTION UPDATE                     **
      **           THIS ROUTINE CONTROLS CHANGES TO DIVIDEND OPTION  **
      **           CODE AND EXCESS DIVIDEND OPTION CODE FOR POLICY   **
      **           WITH STATUS 'PREMIUM PAYING', 'PREMIUM WAIVER'    **
      **           OR 'PAID-UP'. UPDATES ARE PERFORMED THROUGH THE   **
      **           POLICY MAINTENANCE FUNCTION DRIVER.               **
      **                                                             **
      **  DOMAIN : PO                                                **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023436**  6.5       UNDO/REDO OF ANNIVERSARY PROCESSING              **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
031037**  7.0       TAMRA OFF ANNIVERSARY PROCESSING                 **
030054**  7.0       PHST SEQUENCE NUMBER EXPANSION                   **
035251**  7.1       MOVE MXDX TO RH AND RT                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      /
       ENVIRONMENT DIVISION.
       DATA DIVISION.
       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM2822'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

028298 COPY CCWL2626.
       COPY XCWL8090.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                     PIC X(04).
               88  WS-BUS-FCN-UPDATE                 VALUE '2822'.

           05  WS-REDO-SWITCH                    PIC X(01).
               88  WS-REDO-OK                        VALUE 'Y'.
               88  WS-REDO-NOT-OK                    VALUE 'N'.

           05  WS-DIV-OPT-MATCHED-SW             PIC X(01).
               88  WS-DIV-OPT-MATCHED                VALUE 'Y'.
               88  WS-DIV-OPT-NOT-MATCHED            VALUE 'N'.

           05  WS-ISS-EFF-DT                     PIC X(10).
           05  WS-OLD-DIV-OPT-CD                 PIC X(01).
           05  WS-OLD-DIV-XCES-CD                PIC X(01).

           05  WS-DO-EDO-CD.
               10  WS-DIV-OPT-CD                 PIC X(01).
                   88 WS-POL-DIV-OPT-NON-PAR           VALUE '0'.
                   88 WS-POL-DIV-OPT-CASH              VALUE '1'.
                   88 WS-POL-DIV-OPT-REDC-PREM         VALUE '2'.
                   88 WS-POL-DIV-OPT-PUA               VALUE '3'.
                   88 WS-POL-DIV-OPT-DOD               VALUE '4'.
                   88 WS-POL-DIV-OPT-OYT               VALUE '5'.
                   88 WS-POL-DIV-OPT-REDC-LOAN         VALUE '6'.
                   88 WS-POL-DIV-OPT-XFER-EQTY         VALUE '9'.
                   88 WS-POL-DIV-OPT-OYT-REMN-1        VALUE 'A'.
                   88 WS-POL-DIV-OPT-OYT-REMN-2        VALUE 'B'.
                   88 WS-POL-DIV-OPT-OYT-REMN-3        VALUE 'C'.
                   88 WS-POL-DIV-OPT-OYT-REMN-4        VALUE 'D'.
               10  WS-DIV-XCES-CD                PIC X(01).
                   88 WS-POL-DIV-XCES-NONE             VALUE '0'.
                   88 WS-POL-DIV-XCES-CSH              VALUE '1'.
                   88 WS-POL-DIV-XCES-PREM-PMT         VALUE '2'.
                   88 WS-POL-DIV-XCES-PUA              VALUE '3'.
                   88 WS-POL-DIV-XCES-ON-DPOS          VALUE '4'.

       01  WS-CONSTANT-AREA.
025970     05  WS-PHST-ACTV-TYP-1073             PIC 9(4).
025970         88  WS-PHST-ACTV-TYP-1073-DEFAULT VALUE 1073.
025970     05  WS-PHST-ACTV-TYP-1074             PIC 9(4).
025970         88  WS-PHST-ACTV-TYP-1074-DEFAULT VALUE 1074.
025970*    05  WS-PHST-ACTV-TYP-1073             PIC 9(4) VALUE 1073.
025970*    05  WS-PHST-ACTV-TYP-1074             PIC 9(4) VALUE 1074.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY CCWWINDX.
030054 COPY XCWWCNST.
      /
       COPY XCWWWKDT.
      /
       COPY CCWWLOCK.
026057 COPY CCWWIHSD.
      /
       COPY XCWEBLCH.
      /
      *****************************************************************
      * I/O    COPYBOOKS
      *****************************************************************

       COPY CCFRBNDV.
       COPY CCFWBNDV.
      /
       COPY CCFRCVG.
       COPY CCFWCVG.
      /
       COPY CCFHPOL.
       COPY CCFWPOL.
      /
       COPY CCFRPH.
       COPY CCFWPH.
      /
       COPY CCFRPDIV.
       COPY CCFWPDIV.
      /
       COPY CCFRPHST.
       COPY CCFWPHST.

      *****************************************************************
      * LINKAGE PROCESSING COPYBOOKS
      *****************************************************************
       COPY CCWL0201.
       COPY CCWL0289.
       COPY CCWL0620.
       COPY CCWL0985.
031037 COPY CCWL2408.
       COPY CCWL2420.
       COPY CCWL2430.
020478 COPY CCWL2625.
       COPY CCWL3330.
       COPY CCWL4750.
       COPY CCWL4780.
       COPY CCWL5400.
       COPY XCWL1640.
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
       COPY XCWL8960.
       COPY XCWLDTLK.
      /
      *****************************************************************
      *  INPUT PARAMETER
      *****************************************************************
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM2822.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  9400-SETUP-MSIN-REFERENCE
               THRU 9400-SETUP-MSIN-REFERENCE-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG: INVALID FUNCTION ID - PROCESSING STOPPED
                    MOVE 'XS00000237'      TO  WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *------------
       2000-UPDATE.
      *------------
      *
      * EDIT THE ENTERED DATA FOR VALIDITY
      *
           PERFORM  2050-INPUT-EDIT
               THRU 2050-INPUT-EDIT-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  7100-BUILD-KEYS
               THRU 7100-BUILD-KEYS-X.
      *
      * GET POLICY INFO FROM TWRK
      *
           IF  MIR-DV-PRCES-STATE-CD = '3'
               PERFORM  POL-2000-UPDATE-TWRK-TS
                   THRU POL-2000-UPDATE-TWRK-TS-X
           ELSE
               PERFORM  POL-1000-READ-TWRK-TS
                   THRU POL-1000-READ-TWRK-TS-X
           END-IF.

           IF MIR-RETRN-TS-MISMATCH
      *MSG: 'TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2,
      *      PROCESS NOT COMPLETE'
               MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
               MOVE 'POL'             TO WGLOB-MSG-PARM (01)
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-UPDATE-X
           END-IF.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD (@1) NOT FOUND
               MOVE WPOL-KEY           TO WGLOB-MSG-PARM (1)
               MOVE 'POL'              TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-UPDATE-X
           END-IF.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-ISS-EFF-DT            TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-2000-CHK-IHSD-PROCESS
026057         THRU IHSD-2000-CHK-IHSD-PROCESS-X.
026057     IF WIHSD-CHK-EFF-DT-NOT-OK
026057         SET WGLOB-RETURN-ERROR TO TRUE
026057         GO TO 2000-UPDATE-X
026057     END-IF.

      *
      * VERIFY THAT POLICY ACCESS IS ALLOWED
      *
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-CRCY-MSG-REQD      TO TRUE.
           SET L5400-POL-XFER-UPDATE    TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-XFER-ACCS-RESTRICTED
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.
      *
      * VALIDATE CLIENTS DATE OF DEATH FIELDS
      *
           PERFORM  0985-1000-BUILD-PARM-INFO
               THRU 0985-1000-BUILD-PARM-INFO-X.

           MOVE WS-ISS-EFF-DT         TO L0985-EFF-DT.

           PERFORM  0985-1000-VAL-POL-DT-OF-DTH
               THRU 0985-1000-VAL-POL-DT-OF-DTH-X.

           IF  NOT L0985-RETRN-OK
               SET WGLOB-RETURN-ERROR TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

      * READ IN THE COVERAGES

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

      * CHECK FOR VERIFY STEP

           PERFORM  2500-CHECK-PREV-CHNG
               THRU 2500-CHECK-PREV-CHNG-X.
           IF  WGLOB-RETURN-ERROR
               GO TO 2000-UPDATE-X
           END-IF.

           IF  MIR-DV-PRCES-STATE-CD = '3'
               PERFORM  2300-VERIFY-PASS
                   THRU 2300-VERIFY-PASS-X
               IF  WS-REDO-NOT-OK
               OR  MIR-RETRN-TS-MISMATCH
                   GO TO 2000-UPDATE-X
               END-IF
           ELSE
               PERFORM  5100-CHECK-OS-ACTV
                   THRU 5100-CHECK-OS-ACTV-X
               PERFORM  2100-EDIT-INPUT
                   THRU 2100-EDIT-INPUT-X
               IF  WGLOB-RETURN-ERROR
                   GO TO 2000-UPDATE-X
               END-IF
           END-IF.
      *
      * REDISPLAY CLIENT NAME
      *
           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           MOVE RPOL-POL-ID                   TO L2430-POL-ID.
           MOVE ZERO                          TO I.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF L2430-RETRN-OK
               INITIALIZE                        L0620-INPUT-PARM-INFO
               IF L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES                    TO MIR-DV-OWN-CLI-NM
           END-IF.

       2000-UPDATE-X.
           EXIT.
      /
      *----------------
       2050-INPUT-EDIT.
      *----------------
      *
      * EDIT THE ENTERED DATA FOR VALIDITY
      *
           IF  MIR-POL-ID-BASE = SPACES
           AND MIR-POL-ID-SFX  = SPACES
      *MSG:    POLICY ID MUST BE ENTERED
               MOVE 'CS28220009'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR       TO TRUE
               GO TO 2050-INPUT-EDIT-X
           END-IF.

      * VALIDATE EFFECTIVE DATE

           IF  MIR-PCHST-EFF-IDT-NUM = WWKDT-ZERO-DT
           OR  MIR-PCHST-EFF-IDT-NUM = SPACES
      *MSG:    EFFECTIVE DATE MUST BE ENTERED
               MOVE 'CS28220010'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR       TO TRUE
               GO TO 2050-INPUT-EDIT-X
           END-IF.

           MOVE MIR-PCHST-EFF-IDT-NUM       TO L1640-EXTERNAL-DATE.
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-RETRN-OK
               MOVE L1640-INTERNAL-DATE     TO WS-ISS-EFF-DT
           ELSE
      *MSG:    INVALID EFFECTIVE DATE
               MOVE 'CS28220011'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR       TO TRUE
               GO TO 2050-INPUT-EDIT-X
           END-IF.

       2050-INPUT-EDIT-X.
           EXIT.
      /
      *----------------
       2100-EDIT-INPUT.
      *----------------

      *
      * EDIT THE POLICY STATUS FOR DIVIDEND MAINTAIN PROCESS
      *
035251*    IF  RPOL-POL-STAT-PREM-PAYING
035251*    OR  RPOL-POL-STAT-PAID-UP-LIFE
035251*        CONTINUE
035251*    ELSE
035251*MSGS: INVALID POLICY STATUS FOR DIVIDEND MAINTAIN PROCESS
035251*        MOVE 'CS28220001'            TO WGLOB-MSG-REF-INFO
035251*        PERFORM  0260-1000-GENERATE-MESSAGE
035251*            THRU 0260-1000-GENERATE-MESSAGE-X
035251*        MOVE '1'                     TO WGLOB-RETURN-CODE
035251*        GO TO 2100-EDIT-INPUT-X
035251*    END-IF.
035251
035251     IF  RPOL-POL-STAT-PREM-PAYING
035251         CONTINUE
035251     ELSE
035251         PERFORM  2105-CHECK-PAID-UP-STAT
035251             THRU 2105-CHECK-PAID-UP-STAT-X 
035251     END-IF.
035251
035251     IF  WGLOB-RETURN-ERROR
035251         GO TO 2100-EDIT-INPUT-X
035251     END-IF.
      *
      * EDIT DIVIDEND OPTION CODE AGAINST DMAV TABLE
      *
           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.
           MOVE 'PLAN-DIV-OPT-CD'           TO L8960-AV-TBL-CD.
           MOVE MIR-POL-DIV-OPT-CD          TO L8960-AV-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.

           IF  NOT L8960-RETRN-OK
      *MSG:    'INVALID DIVIDEND OPTION'
               MOVE 'CS28220002'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'                     TO WGLOB-RETURN-CODE
           END-IF.
      *
      * EDIT DIVIDEND EXCESS CODE AGAINST DMAV TABLE
      *
           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.
           MOVE 'PLAN-DIV-XCES-CD'          TO L8960-AV-TBL-CD.
           MOVE MIR-POL-DIV-XCES-CD         TO L8960-AV-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.

           IF  NOT L8960-RETRN-OK
      *MSG:    'INVALID EXCESS DIVIDEND OPTION'
               MOVE 'CS28220003'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'                     TO WGLOB-RETURN-CODE
           END-IF.

           MOVE MIR-POL-DIV-OPT-CD          TO WS-DIV-OPT-CD.
           MOVE MIR-POL-DIV-XCES-CD         TO WS-DIV-XCES-CD.
      *
      *  OBTAIN PLAN HEADER FOR PAYMENT PROCESSING INFORMATION
      *
           MOVE ZERO                        TO I.

           PERFORM  PLIN-1000-PLAN-HEADER-IN
               THRU PLIN-1000-PLAN-HEADER-IN-X.

           IF  NOT WPH-IO-OK
               PERFORM  PH-1000-CREATE
                   THRU PH-1000-CREATE-X
           END-IF.

           PERFORM  3330-1000-BUILD-PARM-INFO
               THRU 3330-1000-BUILD-PARM-INFO-X.

           SET L3330-LOC-GR-TYP-DIVOP       TO TRUE.

           PERFORM  3330-1000-GET-LOC-GROUP
               THRU 3330-1000-GET-LOC-GROUP-X.

           IF  L3330-RETRN-OK
               CONTINUE
           ELSE
      *MSG:    'ERROR READING LOCATION GROUP'
               MOVE 'CS28220004'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE '1'                     TO WGLOB-RETURN-CODE
               GO TO 2100-EDIT-INPUT-X
           END-IF.

           MOVE RPOL-PLAN-ID                TO WPDIV-PLAN-ID.
           MOVE L3330-LOC-GR-ID             TO WPDIV-LOC-GR-ID.
           MOVE WS-DIV-OPT-CD               TO WPDIV-PLAN-DIV-OPT-CD.
           MOVE WS-DIV-XCES-CD              TO WPDIV-PLAN-DIV-XCES-CD.

           PERFORM PDIV-1000-READ
              THRU PDIV-1000-READ-X.

           IF NOT WPDIV-IO-OK
      *MSG:  DIV-OPTION DIC-XCES-OPTION COMBINATION NOT ON PDIV
               MOVE 'CS28220005'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE HIGH-VALUES             TO MIR-POL-DIV-OPT-CD
               MOVE HIGH-VALUES             TO MIR-POL-DIV-XCES-CD
               GO TO 2100-EDIT-INPUT-X
           END-IF.

           IF  RPOL-POL-DIV-OPT-REDC-PREM
               PERFORM  2110-SET-BNDV-KEY
                   THRU 2110-SET-BNDV-KEY-X

               PERFORM  BNDV-1000-BROWSE
                   THRU BNDV-1000-BROWSE-X

               PERFORM  BNDV-2000-READ-NEXT
                   THRU BNDV-2000-READ-NEXT-X
                   UNTIL NOT WBNDV-IO-OK
                   OR   RBNDV-BON-DIV-STAT-PEND

               IF  WBNDV-IO-OK
               AND RBNDV-BON-DIV-STAT-PEND
      *MSG:  A REDUCED POLICY BILLING WAS PREVIOSLY GENERATED USING
      *MSG   "REDUCED PREMIUM" DIVIDEND OPTION
                   MOVE 'CS28220006'        TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF

               PERFORM  BNDV-3000-END-BROWSE
                   THRU BNDV-3000-END-BROWSE-X
           END-IF.

020478*    IF  RPOL-POL-OFFANNV-PD-DT NOT = SPACES
020478*    AND RPOL-POL-OFFANNV-PD-DT NOT = WWKDT-ZERO-DT
020478*    AND ( WS-POL-DIV-OPT-REDC-PREM
020478*       OR WS-POL-DIV-XCES-PREM-PMT)
020478*MSG: POLICY IS OFF ANNIVERSARY, CANNOT HAVE REDUCE PREMIUM IN
020478*     DIVIDEND OPTION OR EXCESS OPTION
020478*        MOVE 'CS28220013'        TO WGLOB-MSG-REF-INFO
020478*        PERFORM  0260-1000-GENERATE-MESSAGE
020478*            THRU 0260-1000-GENERATE-MESSAGE-X
020478*        SET WGLOB-RETURN-ERROR      TO TRUE
020478*    END-IF.
020478     PERFORM  2625-0000-INIT-PARM-INFO
020478         THRU 2625-0000-INIT-PARM-INFO-X.
020478     PERFORM  2625-1000-BILL-CHNG-RETRIEVE
020478         THRU 2625-1000-BILL-CHNG-RETRIEVE-X.
020478
020478     IF  L2625-OFFANNV-PD-DT NOT = WWKDT-ZERO-DT
020478         IF  ( WS-POL-DIV-OPT-REDC-PREM
020478         OR    WS-POL-DIV-XCES-PREM-PMT)
020478*MSG: POLICY IS OFF ANNIVERSARY, CANNOT HAVE REDUCE PREMIUM IN
020478*     DIVIDEND OPTION OR EXCESS OPTION
020478             MOVE 'CS28220013'        TO WGLOB-MSG-REF-INFO
020478             PERFORM  0260-1000-GENERATE-MESSAGE
020478                 THRU 0260-1000-GENERATE-MESSAGE-X
020478             SET WGLOB-RETURN-ERROR   TO TRUE
020478         END-IF
020478     ELSE
020478         IF  RPOL-POL-OFFANNV-PD-DT NOT = SPACES
020478         AND RPOL-POL-OFFANNV-PD-DT NOT = WWKDT-ZERO-DT
020478         AND ( WS-POL-DIV-OPT-REDC-PREM
020478         OR    WS-POL-DIV-XCES-PREM-PMT)
020478*MSG: POLICY IS OFF ANNIVERSARY, CANNOT HAVE REDUCE PREMIUM IN
020478*     DIVIDEND OPTION OR EXCESS OPTION
020478             MOVE 'CS28220013'        TO WGLOB-MSG-REF-INFO
020478             PERFORM  0260-1000-GENERATE-MESSAGE
020478                 THRU 0260-1000-GENERATE-MESSAGE-X
020478             SET WGLOB-RETURN-ERROR   TO TRUE
020478         END-IF
020478     END-IF.

       2100-EDIT-INPUT-X.
           EXIT.
      /
035251*------------------------
035251 2105-CHECK-PAID-UP-STAT.
035251*------------------------
035251
035251*  CHECK NEW POLICY STATUS CODE FOR PAID UP LIFE
035251
035251     IF  RPOL-POL-STAT-PAID-UP
035251     OR  RPOL-POL-STAT-RPU
035251         IF  RPOL-POL-INS-TYP-PAID-UP-LIFE
035251         OR  RPOL-POL-INS-TYP-WHOLE-LIFE
035251             CONTINUE
035251         ELSE
035251*MSGS: INVALID POLICY STATUS FOR DIVIDEND MAINTAIN PROCESS
035251             MOVE 'CS28220001'        TO WGLOB-MSG-REF-INFO
035251             PERFORM  0260-1000-GENERATE-MESSAGE
035251                 THRU 0260-1000-GENERATE-MESSAGE-X
035251             MOVE '1'                 TO WGLOB-RETURN-CODE
035251             SET WGLOB-RETURN-ERROR   TO TRUE
035251         END-IF
035251     ELSE
035251*MSGS: INVALID POLICY STATUS FOR DIVIDEND MAINTAIN PROCESS
035251         MOVE 'CS28220001'            TO WGLOB-MSG-REF-INFO
035251         PERFORM  0260-1000-GENERATE-MESSAGE
035251             THRU 0260-1000-GENERATE-MESSAGE-X
035251         MOVE '1'                     TO WGLOB-RETURN-CODE
035251         SET WGLOB-RETURN-ERROR       TO TRUE
035251     END-IF.
035251
035251 2105-CHECK-PAID-UP-STAT-X.
035251     EXIT.
035251/
      *------------------
       2110-SET-BNDV-KEY.
      *------------------
      *
      * SETUP THE BNDV TABLE KEY, TO SEARCH FOR PENDING BNDV RECORD
      *
           MOVE LOW-VALUES             TO WBNDV-KEY.
           MOVE RPOL-POL-ID            TO WBNDV-POL-ID.
           MOVE RPOL-POL-PAR-CVG-NUM   TO WBNDV-CVG-NUM-N.
           MOVE 'D'                    TO WBNDV-BON-DIV-TYP-CD.
           MOVE 000                    TO WBNDV-BON-DIV-SEQ-NUM.

           MOVE WBNDV-KEY              TO WBNDV-ENDBR-KEY.
           MOVE HIGH-VALUES            TO WBNDV-ENDBR-BON-DIV-IDT-NUM.
           MOVE 999                    TO WBNDV-ENDBR-BON-DIV-SEQ-NUM.

       2110-SET-BNDV-KEY-X.
           EXIT.
      /
      *-----------------
       2300-VERIFY-PASS.
      *-----------------

           PERFORM  POL-3000-UNLOCK
               THRU POL-3000-UNLOCK-X.

           MOVE MIR-PCHST-EFF-IDT-NUM       TO L1640-EXTERNAL-DATE.
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE         TO WS-ISS-EFF-DT.

      *  INVOKE REDO PROCESSING

           SET WS-REDO-OK                   TO  TRUE.
           IF (RPOL-POL-NXT-ACTV-DT > WWKDT-ZERO-DT
           AND RPOL-POL-NXT-ACTV-DT > WGLOB-PROCESS-DATE)
              CONTINUE
           ELSE
              PERFORM  5000-INVOKE-REDO
                  THRU 5000-INVOKE-REDO-X
           END-IF.

           IF  WS-REDO-NOT-OK
               GO TO 2300-VERIFY-PASS-X
           END-IF.

      * SET UP AND CALL THE UNDO FUNCTION DRIVER TO REVERSE
      * TRANSACTIONS DATED LATER THEN THE EFFECTIVE DATE

           PERFORM  4750-1000-BUILD-PARM-INFO
               THRU 4750-1000-BUILD-PARM-INFO-X.
           MOVE WS-ISS-EFF-DT               TO L4750-EFF-DT.
           SET L4750-FCN-DRVR-SECONDARY     TO TRUE.
           SET L4750-PRCES-EXCLUSIVE        TO TRUE.
           PERFORM  4750-1000-UNDO-PROCESSING
               THRU 4750-1000-UNDO-PROCESSING-X.

      * IF UNDO WAS UNABLE TO COMPLETE SUCESSFULLY, REWRITE THE
      * RECORD LAYOUTS TO THE DATABASE TO REFLECT THE TRANSACTIONS
      * WHICH MAY HAVE BEEN REVERSED.

           IF  NOT L4750-RETRN-OK
               SET WGLOB-RETURN-ERROR       TO TRUE
           END-IF.

      * SET UP AND CALL THE FUNCTION DRIVER TO MODIFY THE POLICY DATA

           IF  WGLOB-GOOD-RETURN
               PERFORM  2320-VERIFY-MODB-CHANGES
                   THRU 2320-VERIFY-MODB-CHANGES-X
           END-IF.

      *
      * IF THE DATA HAS NOT BEEN CHANGED, BYPASS REMAINING UPDATES.
      *
           IF  L2420-POLICY-CHG-DATA = SPACES
           AND L4750-POL-UPDATE-NOT-REQD
               PERFORM  4000-MOVE-DATA-TO-MIR
                   THRU 4000-MOVE-DATA-TO-MIR-X
               GO TO 2300-VERIFY-PASS-X
           END-IF.

      * SUCESSFUL MODIFICATION - REWRITE POLICY AND COVERAGES

           PERFORM  2340-UPDATE-POL-AND-CVGS
               THRU 2340-UPDATE-POL-AND-CVGS-X.

           IF  WGLOB-RETURN-ERROR
               MOVE 'XS00000032'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *
      * DISPLAY UPDATED FIELDS ON THE SCREEN.
      *
               PERFORM  4000-MOVE-DATA-TO-MIR
                   THRU 4000-MOVE-DATA-TO-MIR-X
           END-IF.

       2300-VERIFY-PASS-X.
           EXIT.


      *-------------------------
       2320-VERIFY-MODB-CHANGES.
      *-------------------------
      *
      * SAVE POLICY DIVIDEND OPTION AND POL EXCESS DIVIDEND OPTION CODE
      *
           MOVE RPOL-POL-DIV-OPT-CD         TO WS-OLD-DIV-OPT-CD.
           MOVE RPOL-POL-DIV-XCES-CD        TO WS-OLD-DIV-XCES-CD.


           PERFORM  2420-1000-BUILD-PARM-INFO
               THRU 2420-1000-BUILD-PARM-INFO-X.
      *
      * MOVE THE INPUT TO THE L2420 WORK AREA, SETTING FSET ON FOR
      * EACH FIELD THAT WAS ENTERED.
      *
           MOVE SPACES                      TO L2420-POLICY-CHG-DATA.

           MOVE MIR-PCHST-EFF-IDT-NUM       TO L1640-EXTERNAL-DATE.
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE         TO WS-ISS-EFF-DT.
           MOVE WS-ISS-EFF-DT               TO L2420-EFF-DT.

           SET L2420-REDO-WARNING           TO TRUE.

           SET  L2420-PRCES-NON-BILLING     TO TRUE.
           IF  MIR-POL-DIV-OPT-CD NOT = SPACES
               MOVE MIR-POL-DIV-OPT-CD      TO L2420-POL-DIV-OPT-CD
           END-IF.

           IF  MIR-POL-DIV-XCES-CD  NOT = SPACES
               MOVE MIR-POL-DIV-XCES-CD
                                            TO L2420-POL-DIV-XCES-CD
           END-IF.
031037
031037     PERFORM  2408-0000-INIT-PARM-INFO
031037         THRU 2408-0000-INIT-PARM-INFO-X.
031037     MOVE RPOL-POL-ID                 TO L2408-POL-ID.
031037     MOVE L2420-EFF-DT                TO L2408-EFF-DT.
031037     PERFORM  2408-2000-NXT-PHST-SEQ
031037         THRU 2408-2000-NXT-PHST-SEQ-X.
031037     MOVE L2408-NXT-PCHST-SEQ-NUM     TO WGLOB-PCHST-REL-SEQ-NUM.
031037     MOVE L2408-NXT-PCHST-SEQ-NUM     TO L2420-PCHST-SEQ-NUM.
031037
           PERFORM  2420-1000-MODIFY-POLICY
               THRU 2420-1000-MODIFY-POLICY-X.
031037     MOVE ZERO                        TO WGLOB-PCHST-REL-SEQ-NUM.

           IF  L2420-RETRN-ERROR
               SET WGLOB-RETURN-ERROR       TO TRUE
           END-IF.

       2320-VERIFY-MODB-CHANGES-X.
           EXIT.


      *-------------------------
       2340-UPDATE-POL-AND-CVGS.
      *-------------------------

           MOVE RPOL-REC-INFO               TO HPOL-REC-INFO.
           MOVE MIR-POL-ID-BASE             TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX              TO WPOL-POL-ID-SFX.
           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.

           MOVE HPOL-REC-INFO               TO RPOL-REC-INFO.

           PERFORM  0289-1000-INIT-PARM-INFO
               THRU 0289-1000-INIT-PARM-INFO-X.
           IF  WS-ISS-EFF-DT < RPOL-POL-ISS-EFF-DT
               MOVE RPOL-POL-ISS-EFF-DT     TO  L0289-LO-PAC-DT
               MOVE RPOL-POL-ISS-EFF-DT     TO  L0289-LO-CRC-DT
               MOVE RPOL-POL-ISS-EFF-DT     TO  L0289-LO-DD2-DT
               MOVE RPOL-POL-ISS-EFF-DT     TO  L0289-PROC-EFF-DT
           ELSE
               MOVE WS-ISS-EFF-DT           TO L0289-LO-PAC-DT
               MOVE WS-ISS-EFF-DT           TO L0289-LO-CRC-DT
               MOVE WS-ISS-EFF-DT           TO L0289-LO-DD2-DT
               MOVE WS-ISS-EFF-DT           TO L0289-PROC-EFF-DT
           END-IF.
           PERFORM  0289-1000-OBTAIN-NXT-ACTV
               THRU 0289-1000-OBTAIN-NXT-ACTV-X.
           IF  L0289-RETRN-OK
               MOVE L0289-NXT-ACTV-TYP-CD   TO RPOL-NXT-ACTV-TYP-CD
               MOVE L0289-NXT-ACTV-DT       TO RPOL-POL-NXT-ACTV-DT
           ELSE
               MOVE 'RSH'                   TO RPOL-NXT-ACTV-TYP-CD
               MOVE WGLOB-PROCESS-DATE      TO RPOL-POL-NXT-ACTV-DT
           END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.
           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.
           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.

           IF  RPOL-POL-DIV-OPT-CD NOT = WS-OLD-DIV-OPT-CD
      *MSG:  POLICY DIVIDEND OPTION FOR @1 UPDATED SUCCESFULLY
               MOVE 'CS28220007'            TO WGLOB-MSG-REF-INFO
               MOVE RPOL-POL-ID             TO WGLOB-MSG-PARM (01)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  RPOL-POL-DIV-XCES-CD NOT = WS-OLD-DIV-XCES-CD
      *MSG:  POLICY EXCESS DIVIDEND OPTION FOR @1 UPDATED SUCCESFULLY
               MOVE 'CS28220008'            TO WGLOB-MSG-REF-INFO
               MOVE RPOL-POL-ID             TO WGLOB-MSG-PARM (01)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2340-UPDATE-POL-AND-CVGS-X.
           EXIT.


      *--------------------
       2500-CHECK-PREV-CHNG.
      *--------------------

           INITIALIZE                 RPHST-REC-INFO.
           MOVE RPOL-POL-ID           TO WPHST-POL-ID.
           MOVE WS-ISS-EFF-DT         TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE   TO WPHST-PCHST-EFF-IDT-NUM.
           MOVE ZEROS                 TO WPHST-PCHST-SEQ-NUM.

           MOVE WPHST-KEY             TO WPHST-ENDBR-KEY.
030054*    MOVE 999                   TO WPHST-ENDBR-PCHST-SEQ-NUM.
030054     MOVE WCNST-MAX-PCHST-SEQ-NUM-N
030054                                TO WPHST-ENDBR-PCHST-SEQ-NUM.

           PERFORM  PHST-1000-BROWSE
               THRU PHST-1000-BROWSE-X.

           PERFORM  PHST-2000-READ-NEXT
               THRU PHST-2000-READ-NEXT-X.

           IF  NOT WPHST-IO-OK
               PERFORM  PHST-3000-END-BROWSE
                   THRU PHST-3000-END-BROWSE-X
               GO  TO 2500-CHECK-PREV-CHNG-X
           END-IF.
      *
      *  FIND ANY ACTIVE/REVERSE PHST RECORD ON 1073/1074
      *
           PERFORM  PHST-2000-READ-NEXT
               THRU PHST-2000-READ-NEXT-X
               UNTIL WPHST-IO-EOF
               OR ((RPHST-POL-ACTV-TYP-ID = WS-PHST-ACTV-TYP-1073 OR
                    RPHST-POL-ACTV-TYP-ID = WS-PHST-ACTV-TYP-1074)
               AND (RPHST-PCHST-STAT-ACTIVE  OR
                    RPHST-PCHST-STAT-REVERSED))

           IF  WPHST-IO-OK
               MOVE WS-ISS-EFF-DT          TO L1640-INTERNAL-DATE
               PERFORM  1640-2000-INTERNAL-TO-EXT
                   THRU 1640-2000-INTERNAL-TO-EXT-X
               MOVE L1640-EXTERNAL-DATE    TO WGLOB-MSG-PARM (1)
      * MSG: EXISTING DIVIDEDN CHANGE ON SAME DAY, REVERSE AND ERROR OUT
      *       THE PREVIOUS CHANGE BEFORE MAKING THIS CHANGE
               MOVE 'CS28220012'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR      TO TRUE
           END-IF.

           PERFORM  PHST-3000-END-BROWSE
               THRU PHST-3000-END-BROWSE-X.

       2500-CHECK-PREV-CHNG-X.
           EXIT.

      /
      *----------------------
       4000-MOVE-DATA-TO-MIR.
      *----------------------

           IF  MIR-POL-DIV-OPT-CD = SPACES
               MOVE RPOL-POL-DIV-OPT-CD     TO MIR-POL-DIV-OPT-CD
           END-IF.

           IF  MIR-POL-DIV-XCES-CD = SPACES
               MOVE RPOL-POL-DIV-XCES-CD
                                            TO MIR-POL-DIV-XCES-CD
           END-IF.

      * DISPLAY CLIENT NAME

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           MOVE RPOL-POL-ID                 TO L2430-POL-ID.
           MOVE ZERO                        TO I.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF L2430-RETRN-OK
              INITIALIZE                       L0620-INPUT-PARM-INFO
              IF L2430-CLI-SEX-COMPANY
                 MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
              ELSE
                 MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
                 MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
                 MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
                 MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
              END-IF
              MOVE L2430-CLI-SEX-CD         TO L0620-CLI-SEX-CD
              PERFORM  0620-1000-FORMAT-SCREEN-NAME
                  THRU 0620-1000-FORMAT-SCREEN-NAME-X
              MOVE L0620-SCREEN-NAME        TO MIR-DV-OWN-CLI-NM
           ELSE
              MOVE SPACES                   TO MIR-DV-OWN-CLI-NM
           END-IF.

       4000-MOVE-DATA-TO-MIR-X.
           EXIT.
      /
      *-----------------
       5000-INVOKE-REDO.
      *-----------------

           IF  NOT RPOL-POL-STAT-IN-FORCE
               GO TO 5000-INVOKE-REDO-X
           END-IF.

           PERFORM  4780-1000-BUILD-PARM-INFO
               THRU 4780-1000-BUILD-PARM-INFO-X.
           SET L4780-REDO-WARNING           TO TRUE.
           SET L4780-MSG-SUPPRESS           TO TRUE.
           MOVE WS-ISS-EFF-DT               TO L4780-EFF-DT.
           MOVE RPOL-PREV-BTCH-PRCES-DT     TO L4780-LAST-PROCESS-DATE.
           SET L4780-PRCES-INCLUSIVE        TO TRUE.

           PERFORM  4780-1000-GET-NEXT-ACT-DT
               THRU 4780-1000-GET-NEXT-ACT-DT-X.

           EVALUATE  TRUE
               WHEN L4780-RETRN-ERROR
               WHEN L4780-RETRN-INVALID-REQUEST
                    SET WS-REDO-NOT-OK      TO TRUE
               WHEN  (L4780-RETRN-OK
               AND L4780-ACTIVITY-DUE
               AND L4780-REDO-ALLOW)
                   MOVE WS-ISS-EFF-DT       TO L0201-EFF-DT
                   SET L0201-AUTO-REDO      TO TRUE
                   PERFORM  0201-1000-AUTO-PROCESSING
                       THRU 0201-1000-AUTO-PROCESSING-X
                   PERFORM  0289-1000-INIT-PARM-INFO
                       THRU 0289-1000-INIT-PARM-INFO-X
                   MOVE WS-ISS-EFF-DT       TO L0289-LO-PAC-DT
                   MOVE WS-ISS-EFF-DT       TO L0289-LO-CRC-DT
                   MOVE WS-ISS-EFF-DT       TO L0289-LO-DD2-DT
                   MOVE WS-ISS-EFF-DT       TO L0289-PROC-EFF-DT
                   PERFORM  0289-1000-OBTAIN-NXT-ACTV
                       THRU 0289-1000-OBTAIN-NXT-ACTV-X
                   IF  L0289-RETRN-OK
                       MOVE L0289-NXT-ACTV-TYP-CD
                                            TO RPOL-NXT-ACTV-TYP-CD
                       MOVE L0289-NXT-ACTV-DT
                                            TO RPOL-POL-NXT-ACTV-DT
                   ELSE
                       MOVE 'RSH'           TO RPOL-NXT-ACTV-TYP-CD
                       MOVE WGLOB-PROCESS-DATE
                                            TO RPOL-POL-NXT-ACTV-DT
                   END-IF

                   MOVE RPOL-REC-INFO       TO HPOL-REC-INFO
                   PERFORM  POL-1000-READ-FOR-UPDATE
                       THRU POL-1000-READ-FOR-UPDATE-X
                   MOVE HPOL-REC-INFO       TO RPOL-REC-INFO
                   PERFORM  POL-2000-REWRITE
                       THRU POL-2000-REWRITE-X
                   PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
                       THRU CVGR-1000-REWRITE-CVGS-ARRAY-X
                   PERFORM  POL-1000-READ-TWRK-TS
                       THRU POL-1000-READ-TWRK-TS-X
                   IF  L0201-RETRN-OK
                       MOVE 'XS00000307'    TO  WGLOB-MSG-REF-INFO
      *MSG: 'AUTO REDO PROCESSING COMPLETED
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                   ELSE
                       SET WS-REDO-NOT-OK   TO TRUE
                       IF NOT L0201-INCOMPLETE-DUE-ACTV
                          MOVE 'XS00000308' TO WGLOB-MSG-REF-INFO
      *MSG: PROBLEM IN AUTO REDO PROCESSING
                          PERFORM  0260-1000-GENERATE-MESSAGE
                              THRU 0260-1000-GENERATE-MESSAGE-X
                       END-IF
                   END-IF
           END-EVALUATE.

       5000-INVOKE-REDO-X.
           EXIT.
      *-------------------
       5100-CHECK-OS-ACTV.
      *-------------------

           IF  NOT RPOL-POL-STAT-IN-FORCE
               GO TO 5100-CHECK-OS-ACTV-X
           END-IF.

           PERFORM  4780-1000-BUILD-PARM-INFO
               THRU 4780-1000-BUILD-PARM-INFO-X.
           MOVE WS-ISS-EFF-DT               TO L4780-EFF-DT.
           SET L4780-REDO-WARNING           TO TRUE.
           MOVE RPOL-PREV-BTCH-PRCES-DT     TO L4780-LAST-PROCESS-DATE.
           SET L4780-PRCES-INCLUSIVE        TO TRUE.

           PERFORM  4780-1000-GET-NEXT-ACT-DT
               THRU 4780-1000-GET-NEXT-ACT-DT-X.

       5100-CHECK-OS-ACTV-X.
           EXIT.
      /
      *----------------
       7100-BUILD-KEYS.
      *----------------
      *
      *  BUILD THE RECORD KEY FROM THE MIR FIELDS
      *
           MOVE MIR-POL-ID-BASE             TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX              TO WPOL-POL-ID-SFX.

       7100-BUILD-KEYS-X.
           EXIT.
      /
      *--------------------------
       9400-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                      TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE          TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                         TO
                                            WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE             TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX              TO WGLOB-REF-POLICY-SUFFIX.

       9400-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0201-0000-INIT-PARM-INFO
025970         THRU 0201-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0985-0000-INIT-PARM-INFO
025970         THRU 0985-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
031037
031037     PERFORM  2408-0000-INIT-PARM-INFO
031037         THRU 2408-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2420-0000-INIT-PARM-INFO
025970         THRU 2420-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
020478     PERFORM  2625-0000-INIT-PARM-INFO
020478         THRU 2625-0000-INIT-PARM-INFO-X.
020478
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  3330-0000-INIT-PARM-INFO
025970         THRU 3330-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4750-0000-INIT-PARM-INFO
025970         THRU 4750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4780-0000-INIT-PARM-INFO
025970         THRU 4780-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE                       WS-WORK-AREA.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.
025970     SET WS-PHST-ACTV-TYP-1073-DEFAULT TO TRUE.
025970     SET WS-PHST-ACTV-TYP-1074-DEFAULT TO TRUE.
           MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.
           SET  MIR-RETRN-OK                 TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *****************************************************************
      * PROCESSING COPYBOOKS
      *****************************************************************

028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

026057 COPY CCPPIHSD.

025970 COPY XCPS1670.
       COPY CCPSPGA.

       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
       COPY NCPPCVGR.
       COPY NCPPCVGS.

       COPY XCPPINIT.
       COPY XCPPEXIT.
       COPY CCPPMIDT.
      /
      *****************************************************************
      * LINKAGE PROCESSING COPYBOOKS
      *****************************************************************
025970 COPY CCPS0620.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL0620.

       COPY CCPS0985.
       COPY CCPL0985.

025970 COPY CCPS0201.
       COPY CCPL0201.

       COPY CCPS0289.
       COPY CCPL0289.

031037 COPY CCPS2408.
031037 COPY CCPL2408.
031037
       COPY CCPS2420.
       COPY CCPL2420.

       COPY CCPS2430.
       COPY CCPL2430.
020478
020478 COPY CCPS2625.
020478 COPY CCPL2625.

       COPY CCPS3330.
       COPY CCPL3330.

       COPY CCPS4750.
       COPY CCPL4750.

       COPY CCPS4780.
       COPY CCPL4780.

       COPY CCPS5400.
       COPY CCPL5400.

       COPY XCPL0260.

025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      /
       COPY XCPS8960.
       COPY XCPL8960.
      /
       COPY XCPS8090.
       COPY XCPL8090.
      /
      *****************************************************************
      * FILE I/O PROCESSING MODULES
      *****************************************************************

       COPY CCPBBNDV.

       COPY CCPPPLIN.
       COPY CCPCPH.
       COPY CCPNPH.

       COPY CCPNCVG.
       COPY CCPUCVG.

       COPY CCPNPOL.
       COPY CCPUPOL.

       COPY CCPNPDIV.
       COPY CCPBPHST.
      /
      *****************************************************************
      * ERROR HANDLING ROUTINES
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM2822                     **
      *****************************************************************

