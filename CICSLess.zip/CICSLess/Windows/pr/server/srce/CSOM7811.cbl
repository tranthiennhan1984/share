      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID.  CSOM7811.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7811                                         **
      **  REMARKS:  FINANCIAL ACTIVITY BUSINESS FUNCTION             **
      **            THIS MODULE PERFORMS THE POLICY INQUIRY FOR THE  **
      **            POLICY VALUES                                    **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
018839**  6.3       FINANCIAL BALANCES FLOW                          **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020464**  6.4       FUND MGMT PROCESSING FOR PENDING & DEFER ACTIVITY**
020469**  6.4       MULTI-CURRENCY FUND PROCESSING                   **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023437**  6.5       WITHHOLDING AS PERCENTAGE OR FLAT AMOUNT         **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
030054**  7.0       PHST SEQUENCE NUMBER EXPANSION                   **
031036**  7.0       EXEMPT STATUS MANAGEMENT                         **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************

      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7811'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                     PIC X(04).
               88  WS-BUS-FCN-RETRIEVE           VALUE '7811'.
           05  WS-TRXN-GRS-AMT                   PIC 9(13)V99 COMP-3.
           05  WS-CLI-TRXN-AMT                   PIC S9(13)V99 COMP-3.
           05  WS-POL-TOTAL-DPOS-AMT             PIC S9(13)V99 COMP-3.
           05  WS-POL-TOTAL-WTHDR-AMT            PIC S9(13)V99 COMP-3.
           05  WS-POL-PERI-DED-AMT               PIC S9(13)V99 COMP-3.
           05  WS-POL-LOAN-AMT                   PIC S9(13)V99 COMP-3.
           05  WS-WEALTH-ACCUM-IND               PIC X(01) VALUE 'N'.
               88  WS-WEALTH-ACCUM-YES           VALUE 'Y'.
               88  WS-WEALTH-ACCUM-NO            VALUE 'N'.
           05  WS-COLLATERAL-FUND-IND            PIC X(01) VALUE 'N'.
               88  WS-COLLATERAL-FUND-YES        VALUE 'Y'.
               88  WS-COLLATERAL-FUND-NO         VALUE 'N'.
           05  WS-CDSA-REC-IND                   PIC X(01).
               88  WS-CDSA-REC-FOUND             VALUE 'Y'.
               88  WS-CDSA-REC-NOT-FOUND         VALUE 'N'.
           05  WS-SUB                            PIC S9(04) BINARY.
           05  WS-CVG                            PIC 99.
           05  WS-EFF-DT                         PIC X(10).
           05  WS-EFF-IDT-NUM                    PIC X(07).
           05  WS-SEQ                            PIC X(20).
           05  FILLER                REDEFINES   WS-SEQ.
               10  WS-SEQ-NUM                    PIC 999.
               10  FILLER                        PIC X(17).
           05  FILLER                REDEFINES   WS-SEQ.
               10  WS-CDSA-NUM                   PIC 99999.
               10  FILLER                        PIC X(15).
           05  WS-FA-SEQ-NUM                     PIC 999.
           05  WS-CDA-NUM                        PIC 99999.
           05  WS-SAVE-CDSA-KEY.
               10  WS-CDSA-CO-ID                 PIC X(02).
               10  WS-CDSA-POL-ID                PIC X(10).
023437*        10  WS-CDSA-TYP-CD               PIC X(01).
023437         10  WS-CDSA-TYP-CD               PIC X(02).
               10  WS-CDSA-POL-PAYO-NUM          PIC S9(05)  COMP-3.
               10  WS-CDSA-CDA-EFF-IDT-NUM       PIC X(07).
               10  WS-CDSA-CDA-EFF-IDT-NUM-N     REDEFINES
                   WS-CDSA-CDA-EFF-IDT-NUM       PIC 9(07).
               10  WS-CDSA-CDA-SEQ-NUM           PIC S9(03)  COMP-3.
           05  WS-ACTIVITY-TYPE-ID               PIC X(04).
               88  WS-ACTIVITY-TYPE-DEP   VALUE '4009' '4012' '4013'
031036*                                         '5000'.
031036                                          '5000' '7061' '7062'.
               88  WS-ACTIVITY-TYPE-WTH   VALUE '4001' '4003' '4005'
                                                '4022' '5005' '5006'
031036*                                         '5022'.
031036                                          '5022' '7063' '7064'.

      ************************************************************
      * COMMON WORKING STORAGE COPYBOOKS                         *
      ************************************************************
026057 COPY CCWWIHSD.
       COPY XCWWWKDT.
       COPY CCWWINDX.
030054 COPY XCWWCNST.
       COPY CCWWLOCK.
      *
      ************************************************************
      * FILE I/O WORKING STORAGE COPYBOOKS                       *
      ************************************************************
       COPY CCFWCLI.
       COPY CCFRCLI.
      *
       COPY CCFWPOL.
       COPY CCFRPOL.
      *
       COPY CCFWCVG.
       COPY CCFRCVG.
      *
021930*COPY CCFWPOLT.
021930*COPY CCFRPOLT.
      *
       COPY CCFWPHST.
       COPY CCFRPHST.
      *
       COPY CCFWCFLY.
       COPY CCFRCFLW.
      *
       COPY CCFWLHST.
       COPY CCFRLHST.
      *
       COPY SCFWFATP.
       COPY SCFRFA.
      *
       COPY SCFWFA.
      *
       COPY CCFWCFLW.
      *
       COPY SCFWFD.
       COPY SCFRFD.
      *
       COPY CCFWCDSA.
       COPY CCFRCDSA.
      *
       COPY CCWWCVGS.
      *
      ************************************************************
      * LINKAGE WORKING STORAGE COPYBOOKS                        *
      ************************************************************
       COPY CCWL2430.
028298 COPY CCWL2626.

020464 COPY CCWL2630.

020464 COPY CCWLPGA.

       COPY XCWLDTLK.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
       COPY XCWL8090.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7811.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

025970*    INITIALIZE WS-WORKING-STORAGE.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9000-SETUP-MSIN-REFERENCE
               THRU 9000-SETUP-MSIN-REFERENCE-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET  WGLOB-RETURN-ERROR TO TRUE
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

025970*    MOVE MIR-BUS-FCN-ID                    TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-RETRIEVE
                        THRU 3000-RETRIEVE-X

               WHEN OTHER
      *MSG: INVALID FUNCTION ID - PROCESSING STOPPED
                    MOVE MIR-BUS-FCN-ID           TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7811'               TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'             TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *--------------
       3000-RETRIEVE.
      *--------------

           PERFORM  8100-BLANK-DATA-FIELDS
               THRU 8100-BLANK-DATA-FIELDS-X.

           MOVE MIR-POL-ID           TO WPOL-POL-ID.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: (@2) RECORD (@1) NOT FOUND
               MOVE WPOL-POL-ID      TO WGLOB-MSG-PARM (1)
               MOVE 'POL'            TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000344'     TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 3000-RETRIEVE-X
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           MOVE MIR-DV-EFF-DT          TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
026057     IF  L1640-NOT-VALID
026057*MSG:    'DATE @1 INVALID'
026057         MOVE 'CS78110002'      TO WGLOB-MSG-REF-INFO
026057         MOVE MIR-DV-EFF-DT     TO WGLOB-MSG-PARM (1)
026057         PERFORM  0260-1000-GENERATE-MESSAGE
026057             THRU 0260-1000-GENERATE-MESSAGE-X
026057         SET MIR-RETRN-RQST-FAILED  TO TRUE
026057         GO TO 3000-RETRIEVE-X
026057     END-IF.

           MOVE L1640-INTERNAL-DATE    TO WS-EFF-DT.

026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-EFF-DT              TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF  WIHSD-CHK-EFF-DT-NOT-OK
026057         SET MIR-RETRN-RQST-FAILED  TO TRUE
026057         GO TO 3000-RETRIEVE-X
026057     END-IF.

           MOVE L1640-INTERNAL-DATE    TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE    TO WS-EFF-IDT-NUM.

           PERFORM  4000-GET-DEP-WTH-TOTALS
               THRU 4000-GET-DEP-WTH-TOTALS-X.

           PERFORM  5000-GET-PERI-DED-AMT
               THRU 5000-GET-PERI-DED-AMT-X.

           PERFORM  6000-GET-LOAN-AMT
               THRU 6000-GET-LOAN-AMT-X.

           PERFORM  7000-GET-CLI-INFO
               THRU 7000-GET-CLI-INFO-X.

020464     PERFORM  7500-GET-DEFR-ACT-AMT
020464         THRU 7500-GET-DEFR-ACT-AMT-X.

       3000-RETRIEVE-X.
           EXIT.

      *------------------------
       4000-GET-DEP-WTH-TOTALS.
      *------------------------

           SET WS-WEALTH-ACCUM-NO    TO TRUE.

           PERFORM  4010-INS-TYPE-CHECK
               THRU 4010-INS-TYPE-CHECK-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > RPOL-POL-CVG-REC-CTR-N
                  OR WS-WEALTH-ACCUM-YES.

           IF  WS-WEALTH-ACCUM-NO
               GO TO 4000-GET-DEP-WTH-TOTALS-X
           END-IF.

           MOVE RPOL-POL-ID          TO WPHST-POL-ID.
           MOVE WS-EFF-IDT-NUM       TO WPHST-PCHST-EFF-IDT-NUM.
           MOVE ZERO                 TO WPHST-PCHST-SEQ-NUM.
           MOVE WPHST-KEY            TO WPHST-ENDBR-KEY.
           MOVE HIGH-VALUES          TO WPHST-ENDBR-PCHST-EFF-IDT-NUM.
030054*    MOVE +999                 TO WPHST-ENDBR-PCHST-SEQ-NUM.
030054     MOVE WCNST-MAX-PCHST-SEQ-NUM-N
030054                               TO WPHST-ENDBR-PCHST-SEQ-NUM.

           PERFORM  PHST-1000-BROWSE
               THRU PHST-1000-BROWSE-X.

           PERFORM  PHST-2000-READ-NEXT
               THRU PHST-2000-READ-NEXT-X.

           IF  WPHST-IO-EOF
               PERFORM  PHST-3000-END-BROWSE
                   THRU PHST-3000-END-BROWSE-X
               GO TO 4000-GET-DEP-WTH-TOTALS-X
           END-IF.

           PERFORM  4100-PHST-LOOP
               THRU 4100-PHST-LOOP-X
               UNTIL WPHST-IO-EOF.

           PERFORM  PHST-3000-END-BROWSE
               THRU PHST-3000-END-BROWSE-X.

020874*    COMPUTE L0290-INPUT-NUMBER = WS-POL-TOTAL-DPOS-AMT * 100.
020874     MOVE WS-POL-TOTAL-DPOS-AMT    TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-POL-DPOS-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-DPOS-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = WS-POL-TOTAL-WTHDR-AMT * 100.
020874     MOVE WS-POL-TOTAL-WTHDR-AMT   TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-POL-WTHDR-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-WTHDR-AMT.

       4000-GET-DEP-WTH-TOTALS-X.
           EXIT.

      *--------------------
       4010-INS-TYPE-CHECK.
      *--------------------

           IF  WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-SUB)
           OR  WCVGS-CVG-INS-TYP-SEG-FUND    (WS-SUB)
           OR  WCVGS-CVG-INS-TYP-FPA         (WS-SUB)
               SET WS-WEALTH-ACCUM-YES    TO TRUE
           END-IF.

       4010-INS-TYPE-CHECK-X.
           EXIT.

      *---------------
       4100-PHST-LOOP.
      *---------------

           IF  RPHST-PCHST-STAT-ACTIVE
               CONTINUE
           ELSE
               PERFORM  PHST-2000-READ-NEXT
                   THRU PHST-2000-READ-NEXT-X
               GO TO 4100-PHST-LOOP-X
           END-IF.

           MOVE RPHST-POL-ACTV-TYP-ID     TO WS-ACTIVITY-TYPE-ID.

           EVALUATE TRUE

               WHEN WS-ACTIVITY-TYPE-DEP
               WHEN WS-ACTIVITY-TYPE-WTH
                    PERFORM  4200-PROCESS-DEP-WTH
                        THRU 4200-PROCESS-DEP-WTH-X

           END-EVALUATE.

           PERFORM  PHST-2000-READ-NEXT
               THRU PHST-2000-READ-NEXT-X.

       4100-PHST-LOOP-X.
           EXIT.

      *---------------------
       4200-PROCESS-DEP-WTH.
      *---------------------

           MOVE RPHST-CVG-NUM                TO WS-CVG.
           SET WS-CDSA-REC-NOT-FOUND         TO TRUE.

           EVALUATE TRUE

               WHEN WCVGS-CVG-INS-TYP-SEG-FUND (WS-CVG)
                    PERFORM  4220-DEP-WTH-FA
                        THRU 4220-DEP-WTH-FA-X

               WHEN WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-CVG)
               WHEN WCVGS-CVG-INS-TYP-FPA         (WS-CVG)
                    PERFORM  4250-DEP-WTH-CFLW
                        THRU 4250-DEP-WTH-CFLW-X

           END-EVALUATE.

           IF  WS-CDSA-REC-NOT-FOUND
               GO TO 4200-PROCESS-DEP-WTH-X
           END-IF.

           IF  RCDSA-KEY NOT = WS-SAVE-CDSA-KEY
               MOVE RCDSA-CDA-TOT-TRXN-AMT   TO WS-TRXN-GRS-AMT
               PERFORM  4290-DEP-WTH-TOTALS
                   THRU 4290-DEP-WTH-TOTALS-X
               MOVE RCDSA-KEY                TO WS-SAVE-CDSA-KEY
           END-IF.

       4200-PROCESS-DEP-WTH-X.
           EXIT.

      *----------------
       4220-DEP-WTH-FA.
      *----------------

           MOVE RPHST-POL-ID             TO WFA-POL-ID.
           MOVE RPHST-CVG-NUM            TO WFA-CVG-NUM.
           MOVE RPHST-PCHST-EFF-IDT-NUM  TO WFA-CIA-IDT-NUM.
           MOVE RPHST-PCHST-NEW-VALU-TXT TO WS-SEQ.
           COMPUTE WS-FA-SEQ-NUM = 1000 - WS-SEQ-NUM.

           MOVE WS-FA-SEQ-NUM            TO WFA-CIA-SEQ-NUM.

           PERFORM  FA-1000-READ
               THRU FA-1000-READ-X.

           IF  NOT WFA-IO-OK
               GO TO 4220-DEP-WTH-FA-X
           END-IF.

           MOVE RPHST-POL-ID            TO WCDSA-POL-ID.

           EVALUATE TRUE

               WHEN WS-ACTIVITY-TYPE-DEP
                    IF  WCVGS-PLAN-FND-TYP-SIDE (WS-CVG)
                        SET WCDSA-CDA-TYP-SIDFND TO TRUE
                    ELSE
                        SET WCDSA-CDA-TYP-DPOS   TO TRUE
                    END-IF

               WHEN WS-ACTIVITY-TYPE-WTH
                    SET  WCDSA-CDA-TYP-WTHDR     TO TRUE

           END-EVALUATE.

           MOVE RFA-POL-PAYO-NUM        TO WCDSA-POL-PAYO-NUM.
           MOVE RPHST-PCHST-EFF-IDT-NUM TO WCDSA-CDA-EFF-IDT-NUM.
           MOVE RFA-CDA-SEQ-NUM         TO WCDSA-CDA-SEQ-NUM.

           IF  WCDSA-KEY = WS-SAVE-CDSA-KEY
               SET WS-CDSA-REC-FOUND    TO TRUE
               GO TO 4220-DEP-WTH-FA-X
           END-IF.

           PERFORM  CDSA-1000-READ
               THRU CDSA-1000-READ-X.

           IF  NOT WCDSA-IO-OK
               PERFORM  4225-FA-TOTALS
                   THRU 4225-FA-TOTALS-X
               GO TO 4220-DEP-WTH-FA-X
           END-IF.

           SET WS-CDSA-REC-FOUND        TO TRUE.

       4220-DEP-WTH-FA-X.
           EXIT.

      *---------------
       4225-FA-TOTALS.
      *---------------

           MOVE RFA-POL-ID             TO WFD-POL-ID.
           MOVE RFA-CVG-NUM            TO WFD-CVG-NUM.
           MOVE RFA-FRST-FIA-FND-ID    TO WFD-FND-ID.
           MOVE RFA-CIA-IDT-NUM        TO WFD-FIA-IDT-NUM.
           MOVE RFA-CIA-SEQ-NUM        TO WFD-FIA-SEQ-NUM.

           MOVE ZERO                   TO WS-CLI-TRXN-AMT.

           PERFORM  4226-READ-FD
               THRU 4226-READ-FD-X
               UNTIL WFD-FND-ID = SPACE.

           MOVE WS-CLI-TRXN-AMT        TO WS-TRXN-GRS-AMT.

           PERFORM  4290-DEP-WTH-TOTALS
               THRU 4290-DEP-WTH-TOTALS-X.

       4225-FA-TOTALS-X.
           EXIT.

      *-------------
       4226-READ-FD.
      *-------------

           PERFORM  FD-1000-READ
               THRU FD-1000-READ-X.

           IF  NOT WFD-IO-OK
               MOVE SPACES             TO WFD-FND-ID
               GO TO 4226-READ-FD-X
           END-IF.

           EVALUATE TRUE

               WHEN WS-ACTIVITY-TYPE-DEP
                    COMPUTE WS-CLI-TRXN-AMT = WS-CLI-TRXN-AMT
020469*                                     + RFD-FIA-FND-TRXN-AMT
020469*                                     + RFD-FIA-LOAD-AMT
020469                                      + RFD-FIA-ORIG-TRXN-AMT
020469                                      + RFD-FIA-ORIG-LOAD-AMT

               WHEN WS-ACTIVITY-TYPE-WTH
                    COMPUTE WS-CLI-TRXN-AMT = WS-CLI-TRXN-AMT
020469*                                     + RFD-FIA-FND-TRXN-AMT
020469                                      + RFD-FIA-ORIG-TRXN-AMT

           END-EVALUATE.

           MOVE RFD-NXT-FIA-FND-ID     TO WFD-FND-ID.

       4226-READ-FD-X.
           EXIT.
      *
      *------------------
       4250-DEP-WTH-CFLW.
      *------------------

           MOVE RPHST-POL-ID                 TO WCFLW-POL-ID.
           MOVE RPHST-CVG-NUM                TO WCFLW-CVG-NUM.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG) TO WCFLW-CF-TYP-CD.
           MOVE RPHST-PCHST-EFF-DT           TO WCFLW-CF-EFF-DT.
           MOVE RPHST-PCHST-NEW-VALU-TXT     TO WS-SEQ.
           MOVE WS-SEQ-NUM                   TO WCFLW-CF-SEQ-NUM-N.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

           IF  NOT WCFLW-IO-OK
               GO TO 4250-DEP-WTH-CFLW-X
           END-IF.

           MOVE RPHST-POL-ID                 TO WCDSA-POL-ID.

           EVALUATE TRUE

               WHEN WS-ACTIVITY-TYPE-DEP
                    IF  WCVGS-PLAN-FND-TYP-SIDE (WS-CVG)
                        SET WCDSA-CDA-TYP-SIDFND TO TRUE
                    ELSE
                        SET WCDSA-CDA-TYP-DPOS   TO TRUE
                    END-IF
                    MOVE RCFLW-SRC-CDA-SEQ-NUM   TO WCDSA-CDA-SEQ-NUM
                    MOVE RCFLW-SRC-POL-PAYO-NUM  TO WCDSA-POL-PAYO-NUM

               WHEN WS-ACTIVITY-TYPE-WTH
                    SET  WCDSA-CDA-TYP-WTHDR     TO TRUE
                    MOVE RCFLW-DEST-CDA-SEQ-NUM  TO WCDSA-CDA-SEQ-NUM
                    MOVE RCFLW-DEST-POL-PAYO-NUM TO WCDSA-POL-PAYO-NUM

           END-EVALUATE.

           MOVE RPHST-PCHST-EFF-IDT-NUM      TO WCDSA-CDA-EFF-IDT-NUM.

           IF  WCDSA-KEY = WS-SAVE-CDSA-KEY
               SET WS-CDSA-REC-FOUND             TO TRUE
               GO TO 4250-DEP-WTH-CFLW-X
           END-IF.

           PERFORM  CDSA-1000-READ
               THRU CDSA-1000-READ-X.

           IF  NOT WCDSA-IO-OK
               PERFORM  4255-CFLW-TOTALS
                   THRU 4255-CFLW-TOTALS-X
               GO TO 4250-DEP-WTH-CFLW-X
           END-IF.

           SET WS-CDSA-REC-FOUND                 TO TRUE.

       4250-DEP-WTH-CFLW-X.
           EXIT.

      *-----------------
       4255-CFLW-TOTALS.
      *-----------------

           EVALUATE TRUE

               WHEN WS-ACTIVITY-TYPE-DEP
                    MOVE RCFLW-CF-CLI-TRXN-AMT   TO WS-TRXN-GRS-AMT

               WHEN WS-ACTIVITY-TYPE-WTH
                    MOVE RCFLW-CF-CLI-TRXN-AMT   TO WS-TRXN-GRS-AMT

           END-EVALUATE.

           PERFORM  4290-DEP-WTH-TOTALS
               THRU 4290-DEP-WTH-TOTALS-X.

       4255-CFLW-TOTALS-X.
           EXIT.

      *--------------------
       4290-DEP-WTH-TOTALS.
      *--------------------

           EVALUATE TRUE

               WHEN WS-ACTIVITY-TYPE-DEP
                    COMPUTE WS-POL-TOTAL-DPOS-AMT
                          = WS-POL-TOTAL-DPOS-AMT + WS-TRXN-GRS-AMT

               WHEN WS-ACTIVITY-TYPE-WTH
                    COMPUTE WS-POL-TOTAL-WTHDR-AMT
                          = WS-POL-TOTAL-WTHDR-AMT + WS-TRXN-GRS-AMT

           END-EVALUATE.

       4290-DEP-WTH-TOTALS-X.
           EXIT.

      *----------------------
       5000-GET-PERI-DED-AMT.
      *----------------------

           PERFORM  5100-GET-FA-PERI-DED-AMT
               THRU 5100-GET-FA-PERI-DED-AMT-X.

           PERFORM  5200-GET-CFLW-PERI-DED-AMT
               THRU 5200-GET-CFLW-PERI-DED-AMT-X.

020874*    COMPUTE L0290-INPUT-NUMBER = WS-POL-PERI-DED-AMT * 100.
020874     MOVE WS-POL-PERI-DED-AMT      TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-POL-PERI-DED-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-PERI-DED-AMT.

       5000-GET-PERI-DED-AMT-X.
           EXIT.

      *-------------------------
       5100-GET-FA-PERI-DED-AMT.
      *-------------------------

           MOVE LOW-VALUES             TO WFATP-KEY.
           MOVE RPOL-POL-ID            TO WFATP-POL-ID.
           MOVE 'ADM'                  TO WFATP-CIA-TYP-CD.
           MOVE WS-EFF-IDT-NUM         TO WFATP-CIA-IDT-NUM.

           MOVE WFATP-KEY              TO WFATP-ENDBR-KEY.
           MOVE HIGH-VALUES            TO WFATP-ENDBR-CIA-IDT-NUM.
           MOVE 9999                   TO WFATP-ENDBR-CIA-SEQ-NUM.
           MOVE HIGH-VALUES            TO WFATP-ENDBR-CVG-NUM.

           PERFORM  FATP-1000-BROWSE
               THRU FATP-1000-BROWSE-X.

           PERFORM  FATP-2000-READ-NEXT
               THRU FATP-2000-READ-NEXT-X.

           IF  NOT WFATP-IO-OK
               PERFORM  FATP-3000-END-BROWSE
                   THRU FATP-3000-END-BROWSE-X
               GO TO 5100-GET-FA-PERI-DED-AMT-X
           END-IF.

           PERFORM  5110-FA-LOOP
               THRU 5110-FA-LOOP-X
               UNTIL NOT WFATP-IO-OK.

           PERFORM  FATP-3000-END-BROWSE
               THRU FATP-3000-END-BROWSE-X.

       5100-GET-FA-PERI-DED-AMT-X.
           EXIT.

      *-------------
       5110-FA-LOOP.
      *-------------

           IF  RFA-CIA-REVRS-PRCES-DT = WWKDT-ZERO-DT
               COMPUTE WS-POL-PERI-DED-AMT = WS-POL-PERI-DED-AMT
                                           + RFA-CIA-CLI-TRXN-AMT
           END-IF.

           PERFORM  FATP-2000-READ-NEXT
               THRU FATP-2000-READ-NEXT-X.

       5110-FA-LOOP-X.
           EXIT.

      *---------------------------
       5200-GET-CFLW-PERI-DED-AMT.
      *---------------------------

           MOVE LOW-VALUES             TO WCFLY-KEY.
           MOVE RPOL-POL-ID            TO WCFLY-POL-ID.
           MOVE 'ADM'                  TO WCFLY-CF-TRXN-CD.
           MOVE WWKDT-LOW-DT           TO WCFLY-CF-EFF-DT.
           MOVE ZERO                   TO WCFLY-CF-SEQ-NUM-N.
           MOVE ZERO                   TO WCFLY-CVG-NUM-N.

           MOVE WCFLY-KEY              TO WCFLY-ENDBR-KEY.
           MOVE WS-EFF-DT              TO WCFLY-ENDBR-CF-EFF-DT.
           MOVE HIGH-VALUES            TO WCFLY-ENDBR-CF-SEQ-NUM.
           MOVE HIGH-VALUES            TO WCFLY-ENDBR-CVG-NUM.

           PERFORM  CFLY-1000-BROWSE
               THRU CFLY-1000-BROWSE-X.

           PERFORM  CFLY-2000-READ-NEXT
               THRU CFLY-2000-READ-NEXT-X.

           IF  NOT WCFLY-IO-OK
               PERFORM  CFLY-3000-END-BROWSE
                   THRU CFLY-3000-END-BROWSE-X
               GO TO 5200-GET-CFLW-PERI-DED-AMT-X
           END-IF.

           PERFORM  5210-CFLW-LOOP
               THRU 5210-CFLW-LOOP-X
               UNTIL NOT WCFLY-IO-OK.

           PERFORM  CFLY-3000-END-BROWSE
               THRU CFLY-3000-END-BROWSE-X.

       5200-GET-CFLW-PERI-DED-AMT-X.
           EXIT.

      *---------------
       5210-CFLW-LOOP.
      *---------------

           COMPUTE WS-POL-PERI-DED-AMT = WS-POL-PERI-DED-AMT
                                       + RCFLW-CF-CLI-TRXN-AMT.

           PERFORM  CFLY-2000-READ-NEXT
               THRU CFLY-2000-READ-NEXT-X.

       5210-CFLW-LOOP-X.
           EXIT.

      *------------------
       6000-GET-LOAN-AMT.
      *------------------

           SET WS-COLLATERAL-FUND-NO   TO TRUE.

           PERFORM  6100-COLFND-CHECK
               THRU 6100-COLFND-CHECK-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > RPOL-POL-CVG-REC-CTR-N
               OR      WS-COLLATERAL-FUND-YES.

           IF  WS-COLLATERAL-FUND-NO
               GO TO 6000-GET-LOAN-AMT-X
           END-IF.


           MOVE LOW-VALUES             TO WLHST-KEY.
           MOVE RPOL-POL-ID            TO WLHST-POL-ID.
           MOVE 'C'                    TO WLHST-POL-LOAN-ID.
           MOVE WWKDT-LOW-DT           TO WLHST-POL-LOAN-EFF-DT.
           MOVE ZERO                   TO WLHST-POL-LOAN-SEQ-NUM.

           MOVE WLHST-KEY              TO WLHST-ENDBR-KEY.
           MOVE WS-EFF-DT              TO WLHST-ENDBR-POL-LOAN-EFF-DT.
           MOVE 999                    TO WLHST-ENDBR-POL-LOAN-SEQ-NUM.

           PERFORM  LHST-1000-BROWSE
               THRU LHST-1000-BROWSE-X.

           PERFORM  LHST-2000-READ-NEXT
               THRU LHST-2000-READ-NEXT-X.

           IF  NOT WLHST-IO-OK
               PERFORM  LHST-3000-END-BROWSE
                   THRU LHST-3000-END-BROWSE-X
               GO TO 6000-GET-LOAN-AMT-X
           END-IF.

           PERFORM  6200-LHST-LOOP
               THRU 6200-LHST-LOOP-X
               UNTIL NOT WLHST-IO-OK.

           PERFORM  LHST-3000-END-BROWSE
               THRU LHST-3000-END-BROWSE-X.

020874*    COMPUTE L0290-INPUT-NUMBER = WS-POL-LOAN-AMT * 100.
020874     MOVE WS-POL-LOAN-AMT          TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-POL-LOAN-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-DV-POL-LOAN-AMT.

       6000-GET-LOAN-AMT-X.
           EXIT.

      *------------------
       6100-COLFND-CHECK.
      *------------------

           IF  WCVGS-CVG-COLFND (WS-SUB)
               SET WS-COLLATERAL-FUND-YES TO TRUE
           END-IF.

       6100-COLFND-CHECK-X.
           EXIT.

      *---------------
       6200-LHST-LOOP.
      *---------------

           IF  NOT RLHST-POL-LOAN-STAT-HISTORY
               PERFORM  LHST-2000-READ-NEXT
                   THRU LHST-2000-READ-NEXT-X
               GO TO 6200-LHST-LOOP-X
           END-IF.

           EVALUATE TRUE

               WHEN RLHST-POL-LOAN-TRXN-LOAN
                    COMPUTE WS-POL-LOAN-AMT = WS-POL-LOAN-AMT
                                            + RLHST-POL-LOAN-TRXN-AMT

               WHEN RLHST-POL-LOAN-TRXN-REPAY-CSH
               WHEN RLHST-POL-LOAN-TRXN-REPAY-TRMN
               WHEN RLHST-POL-LOAN-TRXN-CNTRCT
                    COMPUTE WS-POL-LOAN-AMT = WS-POL-LOAN-AMT
                                            - RLHST-POL-LOAN-TRXN-AMT

           END-EVALUATE.

           PERFORM  LHST-2000-READ-NEXT
               THRU LHST-2000-READ-NEXT-X.

       6200-LHST-LOOP-X.
           EXIT.

      *------------------
       7000-GET-CLI-INFO.
      *------------------

           MOVE ZERO                  TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF  NOT L2430-RETRN-OK
      *MSG: 'CLIENT RECORD NOT FOUND'
               MOVE 'CS78110001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-GET-CLI-INFO-X
           END-IF.

           MOVE L2430-CLI-ID          TO WCLI-CLI-ID.

           PERFORM  CLI-1000-READ
               THRU CLI-1000-READ-X.

           IF  WCLI-IO-NOT-FOUND
      *MSG: 'CLIENT RECORD NOT FOUND'
               MOVE 'CS78110001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-GET-CLI-INFO-X
           END-IF.

           MOVE RCLI-CLI-ID           TO MIR-CLI-ID.

020874*    COMPUTE L0290-INPUT-NUMBER = RCLI-CLI-SUSP-AMT * 100.
020874     MOVE RCLI-CLI-SUSP-AMT        TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CLI-SUSP-AMT
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA        TO MIR-CLI-SUSP-AMT.

       7000-GET-CLI-INFO-X.
           EXIT.


020464*-----------------------
020464 7500-GET-DEFR-ACT-AMT.
020464*-----------------------
020464*
020464* GET DEFERRED ACTIVITY VALUE FOR THE POLICY
020464*
020464     PERFORM  2630-0000-INIT-PARM-INFO
020464         THRU 2630-0000-INIT-PARM-INFO-X.
020464
020464     MOVE RPOL-POL-ID             TO L2630-POL-ID.
020464     MOVE MIR-DV-EFF-DT           TO L2630-EFF-DT.
020464
020464     PERFORM  2630-1000-POL-DEFR-VALU
020464         THRU 2630-1000-POL-DEFR-VALU-X.
020464
020464     IF NOT L2630-RETRN-OK
020464        GO TO 7500-GET-DEFR-ACT-AMT-X
020464     END-IF.
020464
020464     COMPUTE L0290-INPUT-V02
020464           = L2630-DEFR-IN-AMT
020464           + L2630-DEFR-OUT-AMT
020464
020464     MOVE 2                       TO L0290-PRECISION.
020464     MOVE LENGTH OF MIR-DV-POL-DEFR-ACTV-AMT
020464                                  TO L0290-MAX-OUT-LEN.
020464
020464     PERFORM 0290-2000-FORMAT-FOR-MIR
020464        THRU 0290-2000-FORMAT-FOR-MIR-X.
020464
020464     MOVE L0290-OUTPUT-DATA       TO MIR-DV-POL-DEFR-ACTV-AMT.
020464
020464 7500-GET-DEFR-ACT-AMT-X.
020464     EXIT.

      *-----------------------
       8100-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-OUTPUT-AREA.

       8100-BLANK-DATA-FIELDS-X.
           EXIT.

      *--------------------------
       9000-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY      TO TRUE.
           MOVE MIR-POL-ID-BASE       TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX        TO WGLOB-REF-POLICY-SUFFIX.

       9000-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  2630-0000-INIT-PARM-INFO
025970         THRU 2630-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-WEALTH-ACCUM-NO     TO TRUE.
025970     SET WS-COLLATERAL-FUND-NO  TO TRUE.
025970
025970     MOVE SPACES                TO WWKDT-WORK-FIELDS.
025970
025970     MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *****************************************************************
      *  PROCESSING COPYBOOKS
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

026057 COPY CCPPIHSD.
       COPY XCPPINIT.
       COPY XCPPEXIT.
      *
       COPY NCPPCVGS.
      *
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      *
      *****************************************************************
      *  LINKAGE COPYBOOKS
      *****************************************************************
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL2430.
025970 COPY XCPS1670.
025970 COPY XCPS8090.
       COPY CCPS2430.

020464 COPY CCPL2630.
020464 COPY CCPS2630.

       COPY XCPS0290.
       COPY XCPL0290.
      *
       COPY XCPL0260.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
      *
       COPY XCPL8090.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNCLI.

       COPY CCPNPOL.
       COPY CCPUPOL.

       COPY CCPNCVG.

021930*COPY CCPNPOLT.

       COPY CCPBCFLY.

       COPY CCPBLHST.

       COPY SCPBFATP.

       COPY CCPBPHST.

       COPY CCPNCFLW.

       COPY SCPNFA.
       COPY SCPNFD.

       COPY CCPNCDSA.

      *****************************************************************
      *  ERROR PROCESSING COPYPBOOKS
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *
      *****************************************************************
      **                 END OF PROGRAM CSOM7811                     **
      *****************************************************************
