      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7900.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7900                                         **
      **  REMARKS:  RETRIEVE PROCESS DRIVER FOR THE OFF ANNIVERSARY  **
      **            POLICY UPDATE FOR THE NEXT BILLING INFORMATION   **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
023435**  6.5       OFF ANNIVERSARY PREMIUM                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      *
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7900'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-RETRIEVE      VALUE '7900'.


      *COPY XCWLCOMM REPLACING '$VAR1' BY '7900'.

      ****************************************************************
      *  COMMON COPYBOOKS                                            *
      ****************************************************************
       COPY CCWWCVGS.
      /
       COPY CCWWINDX.
      /
       COPY CCWWLOCK.
      /
       COPY XCWWWKDT.
      /
      ****************************************************************
      *  I/O COPYBOOKS                                               *
      ****************************************************************
       COPY CCFRCVG.
       COPY CCFWCVG.
      /
       COPY CCFRPOL.
       COPY CCFWPOL.
      /
      ****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      ****************************************************************
020478 COPY CCWL2626.
       COPY CCWLPGA.
      /
       COPY CCWL5400.
      /
       COPY CCWL2430.
      /
020478 COPY CCWL2625.
       COPY CCWL0620.
      /
       COPY XCWLDTLK.
      /
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL8090.
      /
      ****************************************************************
      *  INPUT PARAMETER INFORMATION                                 *
      ****************************************************************

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7900.

CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.
      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

025970*    MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM 2000-PROCESS-RETRIEVE
                       THRU 2000-PROCESS-RETRIEVE-X

               WHEN OTHER
      *MSG:    INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7900'     TO WGLOB-MSG-PARM (2)
                    MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------
       2000-PROCESS-RETRIEVE.
      *----------------------

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-PROCESS-RETRIEVE-X
           END-IF.

           IF  RPOL-POL-SUSPENDED
      *MSGS: POLICY CURRENTLY SUSPENDED - CANNOT MAINTAIN OR PROCESS
               MOVE 'XS00000240'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   MOVE '1'               TO WGLOB-RETURN-CODE
                   GO TO 2000-PROCESS-RETRIEVE-X
               END-IF
           END-IF.

           IF  RPOL-POL-STAT-BEFORE-SETL
      *MSGS: PENDING POLICY - CANNOT MAINTAIN OR PROCESS
               MOVE 'XS00000238'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   MOVE '1'               TO WGLOB-RETURN-CODE
                   GO TO 2000-PROCESS-RETRIEVE-X
               END-IF
           END-IF.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-CRCY-MSG-REQD          TO TRUE.
           SET L5400-STAT-MSG-NOT-REQD      TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
           OR  L5400-XFER-ACCS-RESTRICTED
               MOVE '1'               TO WGLOB-RETURN-CODE
               GO TO 2000-PROCESS-RETRIEVE-X
           END-IF.

           IF  WGLOB-GOOD-RETURN
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X

               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X

           END-IF.

      *MSG:'INQUIRE COMPLETED - CONTINUE'
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       2000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------

           MOVE MIR-POL-ID-BASE        TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX         TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: POLICY @1 DOES NOT EXIST
               MOVE 'XS00000070'       TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY           TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
               GO TO 2100-VALIDATE-KEYS-X
           END-IF.

020478     PERFORM  2625-0000-INIT-PARM-INFO
020478         THRU 2625-0000-INIT-PARM-INFO-X.
020478     PERFORM  2625-1000-BILL-CHNG-RETRIEVE
020478         THRU 2625-1000-BILL-CHNG-RETRIEVE-X.

       2100-VALIDATE-KEYS-X.
           EXIT.
      /

      *----------------
       7000-BUILD-KEYS.
      *----------------

           IF  MIR-POL-ID = SPACE
      *MSG: THE POLICY ID MUST BE ENTERED
               MOVE 'CS79000001'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR  TO TRUE
           END-IF.

       7000-BUILD-KEYS-X.
           EXIT.

      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

020478*    MOVE SPACE                  TO MIR-POL-BILL-CHNG-DT.
020478     MOVE SPACE                  TO MIR-PBRQST-EFF-DT.
           MOVE SPACE                  TO MIR-POL-OFFANNV-PD-DT.
           MOVE SPACE                  TO MIR-DV-OWN-CLI-NM.

           MOVE ZERO                   TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-MPREM-AMT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-MPREM-AMT.

           MOVE ZERO                   TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-POL-NXT-SNDRY-AMT
020478     MOVE LENGTH OF MIR-PBRQST-SNDRY-AMT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-SNDRY-AMT.
020478*    MOVE L0290-OUTPUT-DATA      TO MIR-POL-NXT-SNDRY-AMT.
020478     MOVE L0290-OUTPUT-DATA      TO MIR-PBRQST-SNDRY-AMT.

           MOVE ZERO                   TO L0290-INPUT-V07.
           MOVE 7                      TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-POL-NXT-MODE-FCT
020478     MOVE LENGTH OF MIR-PBRQST-MODE-FCT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-CRNT-MODE-FCT.
020478*    MOVE L0290-OUTPUT-DATA      TO MIR-POL-NXT-MODE-FCT.
020478     MOVE L0290-OUTPUT-DATA      TO MIR-PBRQST-MODE-FCT.

           MOVE ZERO                   TO L0290-INPUT-V07.
           MOVE 7                      TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-POL-NXT-PFEE-FCT
020478     MOVE LENGTH OF MIR-PBRQST-PFEE-FCT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-PFEE-FCT.
020478*    MOVE L0290-OUTPUT-DATA      TO MIR-POL-NXT-PFEE-FCT.
020478     MOVE L0290-OUTPUT-DATA      TO MIR-PBRQST-PFEE-FCT.

020478*    MOVE SPACE                  TO MIR-POL-NXT-BILL-CD.
020478     MOVE SPACE                  TO MIR-PBRQST-BILL-TYP-CD.
           MOVE SPACE                  TO MIR-POL-BILL-MODE-CD.
           MOVE SPACE                  TO MIR-POL-BILL-MODE-CD.
020478*    MOVE SPACE                  TO MIR-POL-NXT-MODE-CD.
020478     MOVE SPACE                  TO MIR-BILL-MODE-CD.
           MOVE SPACE                  TO MIR-MODE-FCT-RESTR-IND.
020478*    MOVE SPACE                  TO MIR-NXT-FCT-RESTR-IND.
020478     MOVE SPACE                  TO MIR-DV-MODE-FCT-RESTR-IND.
           MOVE SPACE                  TO MIR-POL-PFEE-RESTR-IND.
020478*    MOVE SPACE                  TO MIR-NXT-PFEE-RESTR-IND.
020478     MOVE SPACE                  TO MIR-PFEE-RESTR-IND.
           MOVE SPACE                  TO MIR-POL-SNDRY-REASN-CD.
020478*    MOVE SPACE                  TO MIR-NXT-SNDRY-REASN-CD.
020478     MOVE SPACE                  TO MIR-SNDRY-REASN-CD.

           MOVE ZERO                    TO L0290-INPUT-V00.
           MOVE ZERO                    TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-POL-NXT-PMT-DRW-DY
020478     MOVE LENGTH OF MIR-PBRQST-PMT-DRW-DY
                                        TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO MIR-POL-PMT-DRW-DY.
020478*    MOVE L0290-OUTPUT-DATA       TO MIR-POL-NXT-PMT-DRW-DY.
020478     MOVE L0290-OUTPUT-DATA       TO MIR-PBRQST-PMT-DRW-DY.


       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *----------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *----------------------------


      * GET OWNER'S NAME

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           MOVE MIR-POL-ID                    TO L2430-POL-ID.
           MOVE ZERO                          TO I.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF L2430-RETRN-OK
               INITIALIZE                        L0620-INPUT-PARM-INFO
               IF L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD          TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME         TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES                    TO MIR-DV-OWN-CLI-NM
           END-IF.

           MOVE RPOL-POL-ID-BASE       TO MIR-POL-ID-BASE.
           MOVE RPOL-POL-ID-SFX        TO MIR-POL-ID-SFX.

           MOVE RPOL-POL-MPREM-AMT     TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-MPREM-AMT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-MPREM-AMT.

020478*    MOVE RPOL-POL-BILL-CHNG-DT    TO L1640-INTERNAL-DATE.
020478     MOVE L2625-PBRQST-EFF-DT     TO L1640-INTERNAL-DATE.
           PERFORM 1640-8000-INTERNAL-TO-MIR
              THRU 1640-8000-INTERNAL-TO-MIR-X.
020478*    MOVE L1640-EXTERNAL-DATE     TO MIR-POL-BILL-CHNG-DT.
020478     MOVE L1640-EXTERNAL-DATE     TO MIR-PBRQST-EFF-DT.

020478*    MOVE RPOL-POL-OFFANNV-PD-DT  TO L1640-INTERNAL-DATE.
020478     IF  L2625-PBRQST-EFF-DT = WWKDT-ZERO-DT
020478         MOVE RPOL-POL-OFFANNV-PD-DT TO L1640-INTERNAL-DATE
020478     ELSE
020478         MOVE L2625-OFFANNV-PD-DT TO L1640-INTERNAL-DATE
020478     END-IF.
           PERFORM 1640-8000-INTERNAL-TO-MIR
              THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE     TO MIR-POL-OFFANNV-PD-DT.

           MOVE RPOL-POL-BILL-TYP-CD    TO MIR-POL-BILL-TYP-CD.
020478*    MOVE RPOL-POL-NXT-BILL-CD    TO MIR-POL-NXT-BILL-CD.
020478     MOVE L2625-PBRQST-BILL-TYP-CD
020478                                  TO MIR-PBRQST-BILL-TYP-CD.
           MOVE RPOL-POL-BILL-MODE-CD   TO MIR-POL-BILL-MODE-CD.
020478*    MOVE RPOL-POL-NXT-MODE-CD    TO MIR-POL-NXT-MODE-CD.
020478     MOVE L2625-BILL-MODE-CD      TO MIR-BILL-MODE-CD.
           MOVE RPOL-MODE-FCT-RESTR-IND TO MIR-MODE-FCT-RESTR-IND.
020478*    MOVE RPOL-NXT-FCT-RESTR-IND  TO MIR-NXT-FCT-RESTR-IND.
020478     MOVE L2625-MODE-FCT-RESTR-IND
020478                                  TO MIR-DV-MODE-FCT-RESTR-IND.
           MOVE RPOL-POL-PFEE-RESTR-IND TO MIR-POL-PFEE-RESTR-IND.
020478*    MOVE RPOL-NXT-PFEE-RESTR-IND TO MIR-NXT-PFEE-RESTR-IND.
020478     MOVE L2625-PFEE-RESTR-IND    TO MIR-PFEE-RESTR-IND.
           MOVE RPOL-POL-SNDRY-REASN-CD TO MIR-POL-SNDRY-REASN-CD.
020478*    MOVE RPOL-NXT-SNDRY-REASN-CD TO MIR-NXT-SNDRY-REASN-CD.
020478     MOVE L2625-SNDRY-REASN-CD    TO MIR-SNDRY-REASN-CD.

020478*    IF   RPOL-POL-NXT-PMT-DRW-DY = ZERO
020478     IF   L2625-PBRQST-PMT-DRW-DY = ZERO
020478*         MOVE SPACES             TO MIR-POL-NXT-PMT-DRW-DY
020478          MOVE SPACES             TO MIR-PBRQST-PMT-DRW-DY
           ELSE
020478*        MOVE RPOL-POL-NXT-PMT-DRW-DY TO L0290-INPUT-V00
020478         MOVE L2625-PBRQST-PMT-DRW-DY TO L0290-INPUT-V00
               MOVE ZERO                TO L0290-PRECISION
020478*        MOVE LENGTH OF MIR-POL-NXT-PMT-DRW-DY
020478         MOVE LENGTH OF MIR-PBRQST-PMT-DRW-DY
                                        TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
020478*        MOVE L0290-OUTPUT-DATA   TO MIR-POL-NXT-PMT-DRW-DY
020478         MOVE L0290-OUTPUT-DATA   TO MIR-PBRQST-PMT-DRW-DY
           END-IF.

           MOVE RPOL-POL-PMT-DRW-DY     TO L0290-INPUT-V00.
           MOVE ZERO                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-PMT-DRW-DY
                                        TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO MIR-POL-PMT-DRW-DY.

           MOVE RPOL-POL-SNDRY-AMT     TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-SNDRY-AMT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-SNDRY-AMT.

020478*    IF  RPOL-POL-NXT-SNDRY-AMT = ZERO
020478     IF  L2625-PBRQST-SNDRY-AMT = ZERO
020478*        MOVE SPACES             TO MIR-POL-NXT-SNDRY-AMT
020478         MOVE SPACES             TO MIR-PBRQST-SNDRY-AMT
           ELSE
020478*        MOVE RPOL-POL-NXT-SNDRY-AMT TO L0290-INPUT-V02
020478         MOVE L2625-PBRQST-SNDRY-AMT TO L0290-INPUT-V02
               MOVE 2                  TO L0290-PRECISION
020478*        MOVE LENGTH OF MIR-POL-NXT-SNDRY-AMT
020478         MOVE LENGTH OF MIR-PBRQST-SNDRY-AMT
                                       TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                  THRU 0290-2000-FORMAT-FOR-MIR-X
020478*        MOVE L0290-OUTPUT-DATA  TO MIR-POL-NXT-SNDRY-AMT
020478         MOVE L0290-OUTPUT-DATA  TO MIR-PBRQST-SNDRY-AMT
           END-IF.

           MOVE RPOL-POL-CRNT-MODE-FCT TO L0290-INPUT-V07.
           MOVE 7                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-CRNT-MODE-FCT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-CRNT-MODE-FCT.

020478*    IF  RPOL-POL-NXT-MODE-FCT = ZERO
020478     IF  L2625-PBRQST-MODE-FCT = ZERO
020478*        MOVE SPACES             TO MIR-POL-NXT-MODE-FCT
020478         MOVE SPACES             TO MIR-PBRQST-MODE-FCT
           ELSE
020478*        MOVE RPOL-POL-NXT-MODE-FCT  TO L0290-INPUT-V07
020478         MOVE L2625-PBRQST-MODE-FCT  TO L0290-INPUT-V07
               MOVE 7                  TO L0290-PRECISION
020478*        MOVE LENGTH OF MIR-POL-NXT-MODE-FCT
020478         MOVE LENGTH OF MIR-PBRQST-MODE-FCT
                                       TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
020478*        MOVE L0290-OUTPUT-DATA  TO MIR-POL-NXT-MODE-FCT
020478         MOVE L0290-OUTPUT-DATA  TO MIR-PBRQST-MODE-FCT
           END-IF.

           MOVE RPOL-POL-PFEE-FCT      TO L0290-INPUT-V07.
           MOVE 7                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-PFEE-FCT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-PFEE-FCT.

020478*    IF  RPOL-POL-NXT-PFEE-FCT  = ZERO
020478     IF  L2625-PBRQST-PFEE-FCT   = ZERO
020478*        MOVE SPACES             TO MIR-POL-NXT-PFEE-FCT
020478         MOVE SPACES             TO MIR-PBRQST-PFEE-FCT
           ELSE
020478*    MOVE RPOL-POL-NXT-PFEE-FCT  TO L0290-INPUT-V07
020478     MOVE L2625-PBRQST-PFEE-FCT  TO L0290-INPUT-V07
           MOVE 7                      TO L0290-PRECISION
020478*    MOVE LENGTH OF MIR-POL-NXT-PFEE-FCT
020478     MOVE LENGTH OF MIR-PBRQST-PFEE-FCT
                                       TO L0290-MAX-OUT-LEN
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X
020478*    MOVE L0290-OUTPUT-DATA      TO MIR-POL-NXT-PFEE-FCT
020478     MOVE L0290-OUTPUT-DATA      TO MIR-PBRQST-PFEE-FCT
           END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                  TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2625-0000-INIT-PARM-INFO
025970         THRU 2625-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORK-AREA.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     MOVE SPACES TO WWKDT-WORK-FIELDS.
025970
025970     MOVE MIR-BUS-FCN-ID          TO WS-BUS-FCN-ID.
025970
       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      ****************************************************************
      *  PROCESSING COPYBOOKS                                        *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
       COPY NCPPCVGS.
      /
      *COPY XCPPCOMM.
      /
       COPY XCPPEXIT.
      /
       COPY XCPPINIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      ****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                *
      ****************************************************************
       COPY CCPSPGA.
      /
       COPY CCPS5400.
020478 COPY CCPS2626.
020478 COPY CCPL2626.
       COPY CCPL5400.
      /
       COPY CCPS2430.
       COPY CCPL2430.
      /
020478 COPY CCPS2625.
020478 COPY CCPL2625.
020478/
025970 COPY CCPS0620.
       COPY CCPL0620.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
       COPY XCPL8090.
       COPY XCPS8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNCVG.
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      ****************************************************************
      *                  END OF PROGRAM CSOM7900                     *
      ****************************************************************
