      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM3300.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM3300                                         **
      **  REMARKS:  RCCL TABLE MAINTENANCE SCREEN.                   **
      **            THIS PROGRAM ALLOWS THE USER TO BROWSE, MODIFY,  **
      **            ADD, AND DELETE COCL TABLE RECORDS.              **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
010418**  5.6       ORIGINAL                                         **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       MESSAGE SUPPORT - REMOVAL OF XCPPMEXT            **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM3300'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      /

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
025970*    05  TRANSACTION-NAME            PIC X(04)  VALUE 'COCL'.
           05  WS-VALIDATE-KEY             PIC X.
               88  WS-INVALID-KEY          VALUE '1'.
           05  WS-BUS-FCN-ID               PIC X(04).
               88  WS-BUS-FCN-VALID        VALUE  '1660' '1661'
                                                  '1662' '1663'
                                                  '1664'.
               88  WS-BUS-FCN-RETRIEVE     VALUE  '1660'.
               88  WS-BUS-FCN-CREATE       VALUE  '1661'.
               88  WS-BUS-FCN-UPDATE       VALUE  '1662'.
               88  WS-BUS-FCN-DELETE       VALUE  '1663'.
               88  WS-BUS-FCN-LIST         VALUE  '1664'.
025970*    05  WS-TWRK-KEY                 PIC X(04)  VALUE '1660'.
025970*    05  WS-NO-DISPLAY-LINES         PIC S9(3) COMP-3
025970*                                     VALUE +11.
           05  WS-LINES                    PIC S9(3) COMP-3.
025970*    05  WS-MAX-LINES                PIC S9(3) COMP-3 VALUE 11.

025970*    05  WS-EDIT-ERROR-SW            PIC X VALUE 'N'.
025970     05  WS-EDIT-ERROR-SW            PIC X.
025970         88  WS-DEFAULT-EDIT-ERROR-SW      VALUE 'N'.
               88  WS-EDIT-ERRORS                VALUE 'Y'.
               88  WS-NO-EDIT-ERRORS             VALUE 'N'.
      /
025970 01  WS-CONSTANTS.
025970     05  TRANSACTION-NAME            PIC X(04).
025970         88  WS-DEFAULT-TRANSACTION-NAME        VALUE 'COCL'.
025970     05  WS-TWRK-KEY                 PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                VALUE '1660'.
025970     05  WS-NO-DISPLAY-LINES         PIC S9(3) COMP-3.
025970         88  WS-DEFAULT-NO-DISPLAY-LINES        VALUE +11.
025970     05  WS-MAX-LINES                PIC S9(3) COMP-3.
025970         88  WS-DEFAULT-MAX-LINES               VALUE +11.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
016537*COPY XCWEBLCH.
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWEDIT.
       COPY CCFREDIT.
      /
       COPY CCFWCOCL.
       COPY CCFRCOCL.
      /
021930*COPY CCFWCLI.
021930*COPY CCFRCLI.
021930*
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
021930*COPY XCWLDTLK.
021930*
016537*COPY XCWW0260.
      /
016537*COPY XCWL1640.
      /
013578*COPY XCWL5490.
      /
028298 COPY CCWL2626.
014221 COPY XCWL8090.
      /
       COPY CCWL2435.
      /
016537*COPY CCWL5600.
      /
      *****************************************************************
      *  INPUT PARAMETER INFORMATION                                  *
      *****************************************************************
      /
      /
       LINKAGE SECTION.

CVMQ71 COPY XCWWDFH.
      *
       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY NCWM3300.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

025970*    SET MIR-RETRN-OK              TO  TRUE.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.


           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      /
      *-------------------
       2000-PROCESS-REQUEST.
      *-------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.



           EVALUATE TRUE
           WHEN WS-BUS-FCN-RETRIEVE
               PERFORM  3000-PROCESS-RETRIEVE
                   THRU 3000-PROCESS-RETRIEVE-X
           WHEN WS-BUS-FCN-LIST
               PERFORM  3500-PROCESS-LIST
                   THRU 3500-PROCESS-LIST-X
           WHEN WS-BUS-FCN-CREATE
               PERFORM  4000-PROCESS-CREATE
                   THRU 4000-PROCESS-CREATE-X
           WHEN WS-BUS-FCN-UPDATE
               PERFORM  5000-PROCESS-UPDATE
                   THRU 5000-PROCESS-UPDATE-X
           WHEN WS-BUS-FCN-DELETE
               PERFORM  6000-PROCESS-DELETE
                   THRU 6000-PROCESS-DELETE-X
           WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                   MOVE 'XS00000237'         TO  WGLOB-MSG-REF-INFO
                   MOVE MIR-BUS-FCN-ID       TO  WGLOB-MSG-PARM (1)
                   MOVE 'NSOM3300'           TO  WGLOB-MSG-PARM (2)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   SET MIR-RETRN-INVALD-RQST     TO  TRUE
           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *---------------------
       3000-PROCESS-RETRIEVE.
      *--------------------

           PERFORM  8000-BUILD-COCL-KEY
               THRU 8000-BUILD-COCL-KEY-X.

014221*    PERFORM  COCL-1000-READ
014221*        THRU COCL-1000-READ-X.

014221     PERFORM  COCL-1000-READ-TWRK-TS
014221         THRU COCL-1000-READ-TWRK-TS-X.

           IF NOT WCOCL-IO-OK
               MOVE 'NS33000001'      TO WGLOB-MSG-REF-INFO
               MOVE WCOCL-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           ELSE
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.


       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *------------
       3500-PROCESS-LIST.
      *------------


           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.


           MOVE LOW-VALUES            TO WCOCL-KEY.
           MOVE HIGH-VALUES           TO WCOCL-ENDBR-KEY.

           IF MIR-CO-CLI-LANG-CD > SPACES
               MOVE MIR-CO-CLI-LANG-CD           TO WCOCL-CO-CLI-LANG-CD
           END-IF.

           PERFORM  COCL-1000-BROWSE
               THRU COCL-1000-BROWSE-X.

           IF WCOCL-IO-OK
               PERFORM  COCL-2000-READ-NEXT
                   THRU COCL-2000-READ-NEXT-X
           ELSE
      * MSG:   RECORD (@1) NOT FOUND
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               MOVE WCOCL-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 3500-PROCESS-LIST-X
           END-IF.

           IF WCOCL-IO-OK
               MOVE 1                 TO WS-LINES
               PERFORM  3550-DISPLAY-RECORD
                   THRU 3550-DISPLAY-RECORD-X
                   UNTIL (WS-LINES > WS-NO-DISPLAY-LINES)
                   OR    (WCOCL-IO-EOF)

               IF NOT WCOCL-IO-EOF
                   MOVE RCOCL-CO-CLI-LANG-CD
                                      TO MIR-CO-CLI-LANG-CD
               END-IF
           END-IF.


           IF WCOCL-IO-EOF
      *MSG:    'END OF FILE REACHED'
               MOVE 'XS00000025'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               SET WGLOB-MORE-DATA-EXISTS TO TRUE
      * MSG:   TO VIEW MORE DATA PRESS ENTER
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  COCL-3000-END-BROWSE
               THRU COCL-3000-END-BROWSE-X.

           IF MIR-CO-CLI-LANG-CD > SPACES
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               MOVE MIR-CO-CLI-LANG-CD-T (1)
                                      TO MIR-CO-CLI-LANG-CD
           END-IF.


       3500-PROCESS-LIST-X.
           EXIT.
      /
      /
      /
      *--------------------
       3550-DISPLAY-RECORD.
      *--------------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.
           ADD +1 TO WS-LINES.
           PERFORM  COCL-2000-READ-NEXT
               THRU COCL-2000-READ-NEXT-X.

       3550-DISPLAY-RECORD-X.
           EXIT.
      /
      *------------
       4000-PROCESS-CREATE.
      *------------

010418     PERFORM  9100-BLANK-DATA-FIELDS
010418         THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  4100-EDIT-KEY
               THRU 4100-EDIT-KEY-X.

           IF WS-INVALID-KEY
               SET MIR-RETRN-RQST-FAILED     TO  TRUE
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  8000-BUILD-COCL-KEY
               THRU 8000-BUILD-COCL-KEY-X.

           PERFORM  COCL-1000-READ
               THRU COCL-1000-READ-X.

           IF WCOCL-IO-OK
      * MSG:   (COCL) RECORD ALREADY EXISTS
               MOVE 'XS00000003'      TO WGLOB-MSG-REF-INFO
               MOVE WCOCL-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  COCL-1000-CREATE
               THRU COCL-1000-CREATE-X.

           PERFORM  COCL-1000-WRITE
               THRU COCL-1000-WRITE-X.

014221     PERFORM  COCL-1000-READ-TWRK-TS
014221         THRU COCL-1000-READ-TWRK-TS-X.

           MOVE +1                    TO WS-LINES.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.



      *MSG: (COCL) RECORD CREATED - CONTINUE
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

      *MSG: (COCL) MAINTAIN DETAILS
           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *--------------
       4100-EDIT-KEY.
      *--------------

           MOVE MIR-CO-CLI-LANG-CD    TO WEDIT-ETBL-VALU-ID.
           MOVE MIR-CO-CLI-LANG-CD    TO WGLOB-EDIT-LANG.
           PERFORM  LANG-2000-EDIT
               THRU LANG-2000-EDIT-X.

           IF WEDIT-IO-OK
               CONTINUE
           ELSE
               MOVE '1'               TO WS-VALIDATE-KEY
               MOVE 'XS00000115'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       4100-EDIT-KEY-X.
           EXIT.
      /
      *--------------
       5000-PROCESS-UPDATE.
      *--------------
      /
           PERFORM  8000-BUILD-COCL-KEY
               THRU 8000-BUILD-COCL-KEY-X.

014221*    PERFORM  COCL-1000-READ-FOR-UPDATE
014221*        THRU COCL-1000-READ-FOR-UPDATE-X.

014221     PERFORM  COCL-2000-UPDATE-TWRK-TS
014221         THRU COCL-2000-UPDATE-TWRK-TS-X.


014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'COCL'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WCOCL-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF NOT WCOCL-IO-OK
      * MSG:   LOST RECORD IN MAINTAIN - CONTACT SYSTEMS
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               MOVE WCOCL-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  5210-EDIT-DATA-FIELDS
               THRU 5210-EDIT-DATA-FIELDS-X

           IF WS-EDIT-ERRORS
014221*        CONTINUE
014221         PERFORM  COCL-3000-UNLOCK
014221             THRU COCL-3000-UNLOCK-X
           ELSE
               MOVE MIR-CLI-ID        TO RCOCL-CLI-ID
               PERFORM  COCL-2000-REWRITE
                   THRU COCL-2000-REWRITE-X
014221         PERFORM  COCL-1000-READ-TWRK-TS
014221             THRU COCL-1000-READ-TWRK-TS-X
           END-IF.

           IF WS-NO-EDIT-ERRORS
      *MSG:    MAINTENANCE COMPLETED - CONTINUE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE 'XS00000032'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *----------------------
       5210-EDIT-DATA-FIELDS.
      *----------------------

           MOVE 'N'                   TO WS-EDIT-ERROR-SW.

           IF MIR-CLI-ID = SPACES
               MOVE RCOCL-CLI-ID      TO MIR-CLI-ID
           END-IF.

            PERFORM  2435-1000-BUILD-PARM-INFO
                THRU 2435-1000-BUILD-PARM-INFO-X.
            MOVE MIR-CLI-ID           TO L2435-CLI-ID.
            PERFORM  2435-1000-OBTAIN-CLI-INFO
                THRU 2435-1000-OBTAIN-CLI-INFO-X.

            IF NOT L2435-RETRN-OK
               MOVE 'NS33000002'      TO WGLOB-MSG-REF-INFO
      * MSG:   INVALID CLIENT-ID
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'Y'               TO WS-EDIT-ERROR-SW
            END-IF.

       5210-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      *-------------------
       6000-PROCESS-DELETE.
      *-------------------

           PERFORM  8000-BUILD-COCL-KEY
               THRU 8000-BUILD-COCL-KEY-X.

014221*    PERFORM  COCL-1000-READ-FOR-UPDATE
014221*        THRU COCL-1000-READ-FOR-UPDATE-X.

014221     PERFORM  COCL-2000-UPDATE-TWRK-TS
014221         THRU COCL-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'COCL'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WCOCL-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF NOT WCOCL-IO-OK
      * MSG:   LOST RECORD (COCL) IN DELETE - CONTACT SYSTEMS
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               MOVE WCOCL-KEY         TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  COCL-1000-DELETE
                   THRU COCL-1000-DELETE-X
      * MSG:   DELETE COMPLETED CONTINUE
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      /
      *--------------------
       8000-BUILD-COCL-KEY.
      *--------------------
           MOVE MIR-CO-ID             TO WCOCL-CO-ID.
           MOVE MIR-CO-CLI-LANG-CD    TO WCOCL-CO-CLI-LANG-CD.

       8000-BUILD-COCL-KEY-X.
           EXIT.
      /
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

           IF WS-BUS-FCN-LIST
               MOVE SPACES            TO MIR-CLI-ID-G
               MOVE SPACES            TO MIR-CO-CLI-LANG-CD-G
           ELSE
               MOVE SPACES            TO MIR-CLI-ID
           END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           IF WS-BUS-FCN-LIST
               MOVE RCOCL-CO-CLI-LANG-CD
                                      TO MIR-CO-CLI-LANG-CD-T (WS-LINES)
               MOVE RCOCL-CLI-ID      TO MIR-CLI-ID-T (WS-LINES)
           ELSE
               MOVE RCOCL-CLI-ID      TO MIR-CLI-ID
           END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
023514     INITIALIZE                         WS-PGM-WORK-AREA.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TRANSACTION-NAME    TO TRUE.
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-NO-DISPLAY-LINES    TO TRUE.
025970     SET WS-DEFAULT-MAX-LINES           TO TRUE.
025970     SET WS-DEFAULT-EDIT-ERROR-SW       TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
025970
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
016537*COPY CCPERELA.
016537*COPY CCPESYST.
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY COCL
014221                         '$VAR2' BY 'COCL'.
      /
       COPY XCPPINIT.
       COPY XCPPEXIT.
014660*COPY XCPPMEXT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY XCPL0260.
      /
018764*COPY XCCL8090.
018764 COPY XCPL8090.
016537*COPY XCPL1640.
      /
      /
018764*COPY CCCL2435.
018764 COPY CCPL2435.
025970 COPY XCPS8090.
       COPY CCPS2435.
      /
016537*COPY CCCL5600.
016537*COPY CCPS5600.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNEDIT.
      /
       COPY CCPACOCL.
       COPY CCPBCOCL.
       COPY CCPCCOCL.
       COPY CCPNCOCL.
       COPY CCPUCOCL.
       COPY CCPXCOCL.
      /
       COPY CCPELANG.
016537*COPY CCPNCLI.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM NSOM3300                     **
      *****************************************************************
