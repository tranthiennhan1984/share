      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM4150.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM4150                                         **
      **  REMARKS:  USTM - MAINTAINS THE U.S. MISCELLANEOUS TAX      **
      **                   REPORTING RECORDS.                        **
      **                                                             **
      **            THE USTM TRANSACTION IS USED TO MAINTAIN         **
      **            MISCELLANEOUS TAX REPORTING INFORMATION FOR      **
      **            NON-EMPLOYEE US AGENTS BEING PAID IN U.S.        **
      **            CURRENCY.                                        **
      **                                                             **
      **  DOMAIN :  TX                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP                                     **
557696**  5.5       INITIAL REVISION                                 **
557698**  5.5       MIXED CASE SUPPORT                               **
557699**  5.5       ADD LOGIC FOR ACCESSING ADUIT MODULES            **
008453**  5.5.2     MULTIPLE EXTERNAL DATE FORMATS                   **
008455**  5.5.2     EXTENSIVE NUMERIC FORMATTING                     **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010418**  5.6       MULTI-COMPANY SUPPORT                            **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVE XCCPMEXT                                  **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
028789**  6.7       EXTERNAL AGENCY INTEGRATION - REAL TIME INFO.    **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************
      *
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM4150'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

      *
025970 01  WS-CONSTANT-AREA.
025970     05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +10
025970                                      BINARY.
025970         88  WS-MAX-BROWSE-LINES-DEFAULT         VALUE +10.
025970     05  WS-TWRK-KEY                  PIC X(04)  VALUE '0910'.
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '0910'.
025970
       01  WS-WORKING-STORAGE.
016548*    05  WS-SUB                       PIC S9(4)  VALUE ZERO COMP.
016548     05  WS-SUB                       PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  I                            PIC S9(4)  VALUE ZERO COMP.
016548     05  I                            PIC S9(4)  VALUE ZERO
016548                                      BINARY.
016548*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +10  COMP.
025970*    05  WS-MAX-BROWSE-LINES          PIC S9(4)  VALUE +10
025970*                                     BINARY.
           05  WS-BUS-FCN-ID                PIC X(04)  VALUE SPACES.
               88  WS-BUS-FCN-ID-VALID                 VALUES ARE
                   '0910', '0911', '0912', '0914'.
               88  WS-BUS-FCN-RETRIEVE                 VALUE '0910'.
               88  WS-BUS-FCN-CREATE                   VALUE '0911'.
               88  WS-BUS-FCN-UPDATE                   VALUE '0912'.
               88  WS-BUS-FCN-LIST                     VALUE '0914'.
025970*    05  WS-TWRK-KEY                  PIC X(04)  VALUE '0910'.
           05  WS-STATUS-CODE               PIC X(01)  VALUE SPACES.
               88  WS-STATUS-ERROR                     VALUE 'E'.
           05  WS-EVENT-CODE                PIC X(03)  VALUE SPACES.
               88  WS-EVENT-CODE-VALID                 VALUES ARE
                   'COM', 'RNT', 'EXP', 'RWD'.
           05  WS-NUMERIC-ERROR-SW          PIC X(01)  VALUE SPACES.
               88  WS-NUMERIC-ERROR                    VALUE 'Y'.
008455*    05  DISPLAY-NUMBER-Z-9-2         PIC Z(8)9.99.
008455*    05  DISPLAY-NUMBER-9-2           PIC 9(9).99.
           05  DISPLAY-NUMBER-3             PIC 999.
           05  WS-PIC-999                   PIC 999.
008453     05  WS-YEAR                      PIC 9(4).
008453     05  WS-DEFAULT-YEAR              PIC X(4).
008453*    05  WS-DATE.
008453*        10  WS-DAY                   PIC X(2).
008453*        10  WS-MONTH                 PIC X(3).
008453*        10  WS-YEAR                  PIC 9(4).
008453*    05  WS-DATE2.
008453*        10  WS-DAY2                  PIC X(2).
008453*        10  WS-MONTH2                PIC X(3).
008453*        10  WS-YEAR2                 PIC 9(4).
008453*    05  WS-DEFAULT-DATE.
008453*        10  FILLER                   PIC X(2)   VALUE '01'.
008453*        10  WS-DEFAULT-MONTH         PIC X(3).
008453*        10  WS-DEFAULT-YEAR          PIC X(4).
      *
      *
       COPY CCWL0083.
028298 COPY CCWL2626.
      *
       COPY CCWL2435.
      *
       COPY CCWL0620.
      *
014221 COPY CCWWLOCK.
      *
016537*COPY XCWEBLCH.
      *
       COPY XCWL0280.
      *
008455 COPY XCWL0290.
      *
       COPY XCWL1640.
      *
014221 COPY XCWL8090.
      *
       COPY XCWLDTLK.
      *
       COPY XCWWWKDT.
      *
       COPY CCFWUSTM.
      *
       COPY CCFRUSTM.
      *
010418 COPY CCFWSCOM.
      *
010418 COPY CCFRSCOM.
      *
016537*COPY CCFHCLI.
      *
016537*COPY CCFRCLIA.
      *
016537*COPY CCFWEDIT.
      *
016537*COPY CCFREDIT.
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      *
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY CCWM4150.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM ABND-1000-HANDLE-ABEND
026070*       THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM INIT-1000-INITIALIZE
              THRU INIT-1000-INITIALIZE-X.

           PERFORM 2000-PROCESS-REQUEST
              THRU 2000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM EXIT-1000-FINALIZE
              THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      ***************************
       2000-PROCESS-REQUEST.
      ***************************

008455     PERFORM 0290-1000-BUILD-PARM-INFO
008455        THRU 0290-1000-BUILD-PARM-INFO-X.
025970*    MOVE MIR-BUS-FCN-ID         TO WS-BUS-FCN-ID.
      *
      *    READ AGENT INFORMATION
      *
           PERFORM  7000-READ-AGENT-INFO
               THRU 7000-READ-AGENT-INFO-X.
           IF WGLOB-MSG-ERROR-SW > ZERO
              GO TO 2000-PROCESS-REQUEST-X
           END-IF.
      *
      *    CHECK FOR VALID DATE OR INSERT SYSTEM DATE
      *
           IF  MIR-USTM-EFF-DT = SPACES
               MOVE WGLOB-PROCESS-DATE            TO L1640-INTERNAL-DATE
               MOVE 01                TO L1640-MM-1
               MOVE 01                TO L1640-DD-1
020462*        PERFORM  1640-2000-INTERNAL-TO-EXT
020462*            THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM  1640-8000-INTERNAL-TO-MIR
020462             THRU 1640-8000-INTERNAL-TO-MIR-X                   
008453*        MOVE L1640-YYYY-2          TO WS-DEFAULT-YEAR
020874*        MOVE L1640-YYYY-1          TO WS-DEFAULT-YEAR
008453*        MOVE L1640-MMM-2           TO WS-DEFAULT-MONTH
020874*        MOVE WS-DEFAULT-YEAR       TO MIR-USTM-EFF-YR
008453*        MOVE WS-DEFAULT-DATE       TO MIR-USTM-EFF-DT
020874         MOVE L1640-YYYY-1          TO L0290-INPUT-V00
020874         MOVE 0                     TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-USTM-EFF-YR
020874                                TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-USTM-EFF-YR
008453         MOVE L1640-EXTERNAL-DATE
                                      TO MIR-USTM-EFF-DT
           ELSE
               MOVE MIR-USTM-EFF-DT   TO L1640-EXTERNAL-DATE
020462*        PERFORM  1640-3000-EXTERNAL-TO-INT
020462*            THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM  1640-7000-MIR-TO-INT
020462             THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-NOT-VALID
      *MSG: DATE (@1) INVALID
                   MOVE 'CS41500001'  TO WGLOB-MSG-REF-INFO
                   MOVE MIR-USTM-EFF-DT
                                      TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 2000-PROCESS-REQUEST-X
               ELSE
008453*            MOVE L1640-YYYY-2     TO WS-DEFAULT-YEAR
020874*            MOVE L1640-YYYY-1  TO WS-DEFAULT-YEAR
020874*            MOVE WS-DEFAULT-YEAR
020874*                               TO MIR-USTM-EFF-YR
020874             MOVE L1640-YYYY-1          TO L0290-INPUT-V00
020874             MOVE 0                     TO L0290-PRECISION
020874             MOVE LENGTH OF MIR-USTM-EFF-YR
020874                                TO L0290-MAX-OUT-LEN
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
020874             MOVE L0290-OUTPUT-DATA     TO MIR-USTM-EFF-YR
               END-IF
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 0                     TO L0280-PRECISION.
           MOVE 3                     TO L0280-LENGTH.
           MOVE 3                     TO L0280-INPUT-SIZE.

           IF  NOT WS-BUS-FCN-CREATE
           AND MIR-USTM-SEQ-NUM NOT = SPACES
               MOVE MIR-USTM-SEQ-NUM  TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF L0280-OK
020874*            MOVE L0280-OUTPUT  TO DISPLAY-NUMBER-3
020874*            MOVE DISPLAY-NUMBER-3
020874*                               TO MIR-USTM-SEQ-NUM
020874             MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874             MOVE 0                     TO L0290-PRECISION
020874             MOVE LENGTH OF MIR-USTM-SEQ-NUM
020874                                        TO L0290-MAX-OUT-LEN
020874             PERFORM 0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
020874             MOVE L0290-OUTPUT-DATA     TO MIR-USTM-SEQ-NUM
               ELSE
      *MSG - SEQUENCE NUMBER MUST BE NUMERIC
                   MOVE 'CS41500002'  TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO 2000-PROCESS-REQUEST-X
               END-IF
           END-IF.

           IF  NOT WS-BUS-FCN-CREATE
           AND MIR-USTM-SEQ-NUM = SPACES
               MOVE '001'             TO MIR-USTM-SEQ-NUM
           END-IF.

      *
      *    PROCESS SCREEN FUNCTIONS
      *
           EVALUATE TRUE
           WHEN  WS-BUS-FCN-RETRIEVE

              PERFORM 3000-PROCESS-RETRIEVE
                 THRU 3000-PROCESS-RETRIEVE-X

           WHEN  WS-BUS-FCN-CREATE

              PERFORM 4000-PROCESS-CREATE
                 THRU 4000-PROCESS-CREATE-X

           WHEN  WS-BUS-FCN-UPDATE

              PERFORM 5000-PROCESS-UPDATE
                 THRU 5000-PROCESS-UPDATE-X

           WHEN  WS-BUS-FCN-LIST

              PERFORM 6000-PROCESS-LIST
                 THRU 6000-PROCESS-LIST-X
           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      **********************
       3000-PROCESS-RETRIEVE.
      **********************

           MOVE MIR-USTM-EFF-YR       TO WS-YEAR.
           MOVE WS-YEAR               TO WUSTM-USTM-EFF-YR.

           MOVE MIR-AGT-ID            TO WUSTM-AGT-ID.
           MOVE MIR-USTM-SEQ-NUM      TO WUSTM-USTM-SEQ-NUM.

           MOVE MIR-USTM-EFF-DT       TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
           MOVE L1640-INTERNAL-DATE   TO WUSTM-USTM-EFF-DT.
           MOVE MIR-USTM-SEQ-NUM      TO WUSTM-USTM-SEQ-NUM.
014221*    PERFORM  USTM-1000-READ
014221*        THRU USTM-1000-READ-X.
014221
014221     PERFORM  USTM-1000-READ-TWRK-TS
014221         THRU USTM-1000-READ-TWRK-TS-X.

           IF WUSTM-IO-OK
               PERFORM  9200-MOVE-RECORD-TO-SCREEN
                   THRU 9200-MOVE-RECORD-TO-SCREEN-X
      * MSG: INQUIRE COMPLETED - CONTINUE.
               MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
      * MSG: RECORD NOT FOUND. CHECK KEY AND RE-ENTER.
               MOVE 'CS00000026'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      *
      *********************
       4000-PROCESS-CREATE.
      *********************

           MOVE MIR-USTM-EFF-DT       TO L1640-EXTERNAL-DATE.

020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           MOVE L1640-INTERNAL-DATE   TO WUSTM-USTM-EFF-DT.
      *
      * TRANSACTION EFFECTIVE DATE MUST NOT BE > THAN PROCESSING DATE
      *
           IF WUSTM-USTM-EFF-DT > WGLOB-PROCESS-DATE
               MOVE MIR-USTM-EFF-DT   TO WGLOB-MSG-PARM (1)
               MOVE WGLOB-PROCESS-DATE            TO L1640-INTERNAL-DATE
               PERFORM  1640-2000-INTERNAL-TO-EXT
                   THRU 1640-2000-INTERNAL-TO-EXT-X
               MOVE L1640-EXTERNAL-DATE
                                      TO WGLOB-MSG-PARM (2)
      * MSG - EFF-DATE (@1) MUST BE AFTER PROCESSING DATE (@2)
               MOVE 'CS41500003'      TO WGLOB-MSG-REF-INFO

               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X

557660*        PERFORM 9100-BLANK-DATA-FIELDS
557660*           THRU 9100-BLANK-DATA-FIELDS-X
557660*
557660*
557660*        GO TO 4000-PROCESS-CREATE-X
           END-IF.
      *
      * IF PROCESSING YEAR > EFFECTIVE YEAR, DISPLAY WARNING MESSAGE
      *
008453*    MOVE  MIR-USTM-EFF-YR                TO WS-YEAR2
008453*    IF WGLOB-PROCESS-DATE-YR > WS-YEAR2
008453     MOVE  MIR-USTM-EFF-YR      TO WS-YEAR
008453     IF WGLOB-PROCESS-DATE-YR > WS-YEAR
      * MSG - YOU ARE ALTERING TAX INFORMATION FROM A PREVIOUSLY
      *       REPORTED TAX YEAR
               MOVE 'CS41500004'      TO WGLOB-MSG-REF-INFO

               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X

557660*        IF WGLOB-MSG-SEVRTY-FATAL
557660*           PERFORM 9100-BLANK-DATA-FIELDS
557660*              THRU 9100-BLANK-DATA-FIELDS-X
557660*           GO TO 4000-PROCESS-CREATE-X
557660*        END-IF
557660*
           END-IF.
557660
557660     PERFORM 8000-GET-CLIENT-INFO
557660        THRU 8000-GET-CLIENT-INFO-X.
557660
557660     IF WGLOB-MSG-ERROR-SW > ZERO
557660        PERFORM 9100-BLANK-DATA-FIELDS
557660           THRU 9100-BLANK-DATA-FIELDS-X
557660
557660        GO TO 4000-PROCESS-CREATE-X
557660     END-IF.

008453     MOVE MIR-USTM-EFF-DT       TO L1640-EXTERNAL-DATE.

020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

008453     MOVE L1640-YYYY-1          TO WS-YEAR.

           MOVE LOW-VALUES            TO WUSTM-KEY.
008453*    MOVE MIR-USTM-EFF-DT                TO WS-DATE.
           MOVE WS-YEAR               TO WUSTM-USTM-EFF-YR.
           MOVE MIR-AGT-ID            TO WUSTM-AGT-ID.
           MOVE L1640-INTERNAL-DATE   TO WUSTM-USTM-EFF-DT.
           MOVE ZEROES                TO WUSTM-USTM-SEQ-NUM.

           MOVE HIGH-VALUES           TO WUSTM-ENDBR-KEY.
           MOVE WS-YEAR               TO WUSTM-ENDBR-USTM-EFF-YR.
           MOVE MIR-AGT-ID            TO WUSTM-ENDBR-AGT-ID.
           MOVE L1640-INTERNAL-DATE   TO WUSTM-ENDBR-USTM-EFF-DT.
           MOVE '999'                 TO WUSTM-ENDBR-USTM-SEQ-NUM.

           PERFORM  USTM-1000-BROWSE
               THRU USTM-1000-BROWSE-X.

           IF WUSTM-IO-OK
               PERFORM  USTM-2000-READ-NEXT
                   THRU USTM-2000-READ-NEXT-X
               IF WUSTM-IO-OK
                   MOVE RUSTM-USTM-SEQ-NUM
                                      TO WS-PIC-999

                   PERFORM  4150-SEQ-NUM-FIND
                       THRU 4150-SEQ-NUM-FIND-X
                       UNTIL NOT WUSTM-IO-OK
                   ADD 1                 TO WS-PIC-999

                   PERFORM  USTM-3000-END-BROWSE
                       THRU USTM-3000-END-BROWSE-X
               ELSE
                   MOVE WUSTM-ENDBR-KEY
                                      TO WUSTM-KEY
                   MOVE 1             TO WS-PIC-999

                   PERFORM  USTM-3000-END-BROWSE
                       THRU USTM-3000-END-BROWSE-X
               END-IF
           ELSE
               MOVE 1                 TO WS-PIC-999
           END-IF.

           MOVE WS-PIC-999            TO WUSTM-USTM-SEQ-NUM.
           MOVE WS-PIC-999            TO MIR-USTM-SEQ-NUM.

           PERFORM  USTM-1000-CREATE
               THRU USTM-1000-CREATE-X.

           MOVE 'M'                   TO RUSTM-USTM-STAT-CD.

           PERFORM  USTM-1000-WRITE
               THRU USTM-1000-WRITE-X.

557699     IF WGLOB-AUDIT-REQUESTED
557699        PERFORM USTM-1000-CALL-AUDIT
557699           THRU USTM-1000-CALL-AUDIT-X
557699     END-IF.

014221     PERFORM  USTM-1000-READ-TWRK-TS
014221         THRU USTM-1000-READ-TWRK-TS-X.

           PERFORM 9200-MOVE-RECORD-TO-SCREEN
              THRU 9200-MOVE-RECORD-TO-SCREEN-X.

      * MSG : RECORD CREATED - CONTINUE.
           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       4000-PROCESS-CREATE-X.
           EXIT.
      *
      *******************
       4150-SEQ-NUM-FIND.
      *******************

           PERFORM  USTM-2000-READ-NEXT
               THRU USTM-2000-READ-NEXT-X.

           IF WUSTM-IO-OK
               ADD 1                     TO WS-PIC-999
           END-IF.

       4150-SEQ-NUM-FIND-X.
           EXIT.

      ***********************
       5000-PROCESS-UPDATE.
      ***********************

008453     MOVE MIR-USTM-EFF-DT       TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

008453     MOVE L1640-YYYY-1          TO WS-YEAR.

           MOVE WS-YEAR               TO WUSTM-USTM-EFF-YR.
           MOVE MIR-AGT-ID            TO WUSTM-AGT-ID.
           MOVE L1640-INTERNAL-DATE   TO WUSTM-USTM-EFF-DT.
           MOVE MIR-USTM-SEQ-NUM      TO WUSTM-USTM-SEQ-NUM.

014221*    PERFORM USTM-1000-READ-FOR-UPDATE
014221*       THRU USTM-1000-READ-FOR-UPDATE-X.
014221
014221     PERFORM  USTM-2000-UPDATE-TWRK-TS
014221         THRU USTM-2000-UPDATE-TWRK-TS-X.
014221
014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
014221         MOVE 'USTM'            TO WGLOB-MSG-PARM (01)
014221         MOVE WUSTM-KEY         TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           IF WUSTM-IO-NOT-FOUND

              PERFORM 9100-BLANK-DATA-FIELDS
                 THRU 9100-BLANK-DATA-FIELDS-X

              MOVE WUSTM-KEY          TO WGLOB-MSG-PARM (1)
              GO TO 5000-PROCESS-UPDATE-X
           ELSE
557699        IF WGLOB-AUDIT-REQUESTED
557699           PERFORM USTM-1000-CALL-AUDIT
557699              THRU USTM-1000-CALL-AUDIT-X
557699        END-IF
           END-IF.

           IF WGLOB-PROCESS-DATE-YR > RUSTM-USTM-EFF-YR
      * MSG - YOU ARE ALTERING TAX INFORMATION FROM A PREVIOUSLY
      *       REPORTED TAX YEAR
               MOVE 'CS41500004'      TO WGLOB-MSG-REF-INFO

               PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU  0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  5300-EDIT-DATA-FIELDS
               THRU 5300-EDIT-DATA-FIELDS-X.

           PERFORM  8000-GET-CLIENT-INFO
               THRU 8000-GET-CLIENT-INFO-X.

           PERFORM  USTM-2000-REWRITE
               THRU USTM-2000-REWRITE-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
           OR  NOT WGLOB-GOOD-RETURN
      * MSG : RECORD UPDATED
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
557699         IF WGLOB-AUDIT-REQUESTED
557699            PERFORM USTM-1000-CALL-AUDIT
557699               THRU USTM-1000-CALL-AUDIT-X
557699         END-IF
      * MSG : MAINTENANCE COMPLETED - CONTINUE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X

           END-IF.

014221     PERFORM  USTM-1000-READ-TWRK-TS
014221         THRU USTM-1000-READ-TWRK-TS-X.

       5000-PROCESS-UPDATE-X.
           EXIT.
      *
      ***********************
       5300-EDIT-DATA-FIELDS.
      ***********************

010418     PERFORM  5305-EDIT-SUBCO
010418        THRU  5305-EDIT-SUBCO-X.

           PERFORM  5310-EDIT-STATUS-CD
              THRU  5310-EDIT-STATUS-CD-X.

           PERFORM  5320-EDIT-EVENT-CD
              THRU  5320-EDIT-EVENT-CD-X.

           PERFORM  5330-EDIT-NON-EMPLE-AMT
              THRU  5330-EDIT-NON-EMPLE-AMT-X.

           PERFORM  5340-EDIT-FED-TAX-WITHHELD
              THRU  5340-EDIT-FED-TAX-WITHHELD-X.

           IF WS-NUMERIC-ERROR
      * MSG - FIELD (S) MUST BE VALID NUMERIC
               MOVE 'CS41500012'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5300-EDIT-DATA-FIELDS-X.
           EXIT.
      *
010418****************
010418 5305-EDIT-SUBCO.
010418****************

010418     IF MIR-SBSDRY-CO-ID = SPACES
010418        MOVE RUSTM-SBSDRY-CO-ID TO MIR-SBSDRY-CO-ID
010418     END-IF.
010418     MOVE MIR-SBSDRY-CO-ID      TO WSCOM-SBSDRY-CO-ID.
010418     PERFORM SCOM-1000-READ
010418        THRU SCOM-1000-READ-X.
010418     IF WSCOM-IO-OK
010418         MOVE MIR-SBSDRY-CO-ID  TO RUSTM-SBSDRY-CO-ID
010418     ELSE
010418        MOVE MIR-SBSDRY-CO-ID   TO WGLOB-MSG-PARM (1)
010418*MSG: SUB-COMPANY MUST BE EXIST ON SUB-COMPANY PROFILE
010418        MOVE 'CS41500008'       TO WGLOB-MSG-REF-INFO
010418        PERFORM 0260-1000-GENERATE-MESSAGE
010418           THRU 0260-1000-GENERATE-MESSAGE-X
010418     END-IF.

010418 5305-EDIT-SUBCO-X.
010418     EXIT.
      *
      *********************
       5310-EDIT-STATUS-CD.
      *********************

           IF MIR-USTM-STAT-CD = SPACES
               MOVE RUSTM-USTM-STAT-CD               TO MIR-USTM-STAT-CD
               GO TO 5310-EDIT-STATUS-CD-X
           END-IF.

           IF MIR-USTM-STAT-CD = 'E'
013578     OR MIR-USTM-STAT-CD = RUSTM-USTM-STAT-CD
               MOVE MIR-USTM-STAT-CD  TO RUSTM-USTM-STAT-CD
           ELSE
      * MSG - MANUALLY ENTERED STATUS CODE MUST BE 'E'
               MOVE 'CS41500005'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5310-EDIT-STATUS-CD-X.
           EXIT.
      *
      ********************
       5320-EDIT-EVENT-CD.
      ********************

           IF MIR-USTM-TAXBL-EVNT-CD = SPACES
               MOVE RUSTM-USTM-TAXBL-EVNT-CD
                                      TO MIR-USTM-TAXBL-EVNT-CD
               MOVE RUSTM-USTM-TAXBL-EVNT-CD
                                      TO WS-EVENT-CODE
               GO TO 5320-EDIT-EVENT-CD-X
           END-IF.

           MOVE MIR-USTM-TAXBL-EVNT-CD                 TO WS-EVENT-CODE.

           IF WS-EVENT-CODE-VALID
               MOVE MIR-USTM-TAXBL-EVNT-CD
                                      TO RUSTM-USTM-TAXBL-EVNT-CD
           ELSE
               MOVE MIR-USTM-TAXBL-EVNT-CD
                                      TO WGLOB-MSG-PARM (1)
      * MSG - EVENT CODE (@1) INVALID
               MOVE 'CS41500006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5320-EDIT-EVENT-CD-X.
           EXIT.
      *
      **************************
       5330-EDIT-NON-EMPLE-AMT.
      **************************
      *************************************************************
      * VALIDATE THE NON EMPLOYEE AMOUNT
      *************************************************************

           IF MIR-USTM-TAXBL-AMT = SPACES
008455*        MOVE RUSTM-USTM-TAXBL-AMT TO DISPLAY-NUMBER-Z-9-2
008455*        MOVE DISPLAY-NUMBER-Z-9-2 TO MIR-USTM-TAXBL-AMT
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             RUSTM-USTM-TAXBL-AMT *  100
020874         MOVE RUSTM-USTM-TAXBL-AMT TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-USTM-TAXBL-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-USTM-TAXBL-AMT
               GO TO 5330-EDIT-NON-EMPLE-AMT-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 13                       TO L0280-LENGTH.
008455*    MOVE 16                       TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-USTM-TAXBL-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.

           MOVE MIR-USTM-TAXBL-AMT    TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RUSTM-USTM-TAXBL-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR  TO DISPLAY-NUMBER-Z-9-2
008455*        MOVE DISPLAY-NUMBER-Z-9-2 TO MIR-USTM-TAXBL-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = L0280-OUTPUT-DOLLAR  * 100
020874         MOVE L0280-OUTPUT-DOLLAR  TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-USTM-TAXBL-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-USTM-TAXBL-AMT
           ELSE
               MOVE 'Y'               TO WS-NUMERIC-ERROR-SW
           END-IF.

       5330-EDIT-NON-EMPLE-AMT-X.
           EXIT.
      *
      ****************************
       5340-EDIT-FED-TAX-WITHHELD.
      ****************************
      *************************************************************
      * VALIDATE THE FEDERAL TAX WITHHELD AMOUNT
      *************************************************************

           IF MIR-USTM-FED-TAXWH-AMT = SPACES
008455*        MOVE RUSTM-USTM-FED-TAXWH-AMT TO DISPLAY-NUMBER-Z-9-2
008455*        MOVE DISPLAY-NUMBER-Z-9-2    TO MIR-USTM-FED-TAXWH-AMT
020874*        COMPUTE L0290-INPUT-NUMBER =
020874*             RUSTM-USTM-FED-TAXWH-AMT *  100
020874         MOVE RUSTM-USTM-FED-TAXWH-AMT TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-USTM-FED-TAXWH-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-USTM-FED-TAXWH-AMT
               GO TO 5340-EDIT-FED-TAX-WITHHELD-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-PRECISION.
008455*    MOVE 11                        TO L0280-LENGTH.
008455*    MOVE 14                        TO L0280-INPUT-SIZE.
008455     MOVE LENGTH OF MIR-USTM-FED-TAXWH-AMT
                                      TO L0280-INPUT-SIZE.
008455     COMPUTE L0280-LENGTH = L0280-INPUT-SIZE - 3.

           MOVE MIR-USTM-FED-TAXWH-AMT              TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT-DOLLAR
                                      TO RUSTM-USTM-FED-TAXWH-AMT
008455*        MOVE L0280-OUTPUT-DOLLAR   TO DISPLAY-NUMBER-Z-9-2
008455*        MOVE DISPLAY-NUMBER-Z-9-2 TO MIR-USTM-FED-TAXWH-AMT
020874*        COMPUTE L0290-INPUT-NUMBER = L0280-OUTPUT-DOLLAR * 100
020874         MOVE L0280-OUTPUT-DOLLAR  TO L0290-INPUT-V02
008455         MOVE 2                 TO L0290-PRECISION
008455         MOVE LENGTH OF MIR-USTM-FED-TAXWH-AMT
                                      TO L0290-MAX-OUT-LEN
020874*        SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE
020874*        PERFORM  0290-1000-NUMERIC-FORMAT
020874*            THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
008455         MOVE L0290-OUTPUT-DATA TO MIR-USTM-FED-TAXWH-AMT
           ELSE
               MOVE 'Y'               TO WS-NUMERIC-ERROR-SW
           END-IF.

       5340-EDIT-FED-TAX-WITHHELD-X.
           EXIT.
      *
      *********************
       6000-PROCESS-LIST.
      *********************

           MOVE SPACES                TO MIR-USTM-EFF-DT-G.
           MOVE SPACES                TO MIR-USTM-SEQ-NUM-G.
           MOVE SPACES                TO MIR-SBSDRY-CO-ID-G,
           MOVE SPACES                TO MIR-USTM-TAXBL-EVNT-CD-G.
           MOVE SPACES                TO MIR-USTM-STAT-CD-G.
           MOVE SPACES                TO MIR-USTM-TAXBL-AMT-G.
           MOVE SPACES                TO MIR-USTM-FED-TAXWH-AMT-G.

           IF MIR-AGT-ID = SPACES
      * MSG - AGENT NUMBER REQUIRED FOR BROWSE
              MOVE 'CS41500007'       TO WGLOB-MSG-REF-INFO
              PERFORM 0260-1000-GENERATE-MESSAGE
                 THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 6000-PROCESS-LIST-X
           END-IF.

           MOVE LOW-VALUES            TO WUSTM-KEY.

008453*    MOVE MIR-USTM-EFF-DT                TO WS-DATE.

008453     MOVE MIR-USTM-EFF-DT       TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.
008453     MOVE L1640-YYYY-1          TO WS-YEAR.

           MOVE WS-YEAR               TO WUSTM-USTM-EFF-YR.
           MOVE MIR-AGT-ID            TO WUSTM-AGT-ID.
008453*    MOVE MIR-USTM-EFF-DT                TO L1640-EXTERNAL-DATE.
008453*    PERFORM  1640-3000-EXTERNAL-TO-INT
008453*        THRU 1640-3000-EXTERNAL-TO-INT-X.
           MOVE L1640-INTERNAL-DATE   TO WUSTM-USTM-EFF-DT.
           MOVE MIR-USTM-SEQ-NUM      TO WUSTM-USTM-SEQ-NUM.

           MOVE HIGH-VALUES           TO WUSTM-ENDBR-KEY.
           MOVE WS-YEAR               TO WUSTM-ENDBR-USTM-EFF-YR.
           MOVE MIR-AGT-ID            TO WUSTM-ENDBR-AGT-ID.
           MOVE WWKDT-HIGH-DT         TO WUSTM-ENDBR-USTM-EFF-DT.
           MOVE '999'                 TO WUSTM-ENDBR-USTM-SEQ-NUM.

           PERFORM USTM-1000-BROWSE
              THRU USTM-1000-BROWSE-X.

           IF WUSTM-IO-EOF
      * MSG: NO RECORDS FOUND TO DISPLAY
              MOVE 'XS00000034'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 6000-PROCESS-LIST-X
           ELSE
              PERFORM  USTM-2000-READ-NEXT
                  THRU USTM-2000-READ-NEXT-X
              IF WUSTM-IO-EOF
                 PERFORM  USTM-3000-END-BROWSE
                     THRU USTM-3000-END-BROWSE-X
      * MSG : NO RECORD FOUND TO DISPLAY
                 MOVE 'XS00000034'    TO WGLOB-MSG-REF-INFO
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
                 GO TO 6000-PROCESS-LIST-X
              END-IF
           END-IF.

           PERFORM  8000-GET-CLIENT-INFO
               THRU 8000-GET-CLIENT-INFO-X.

           PERFORM  6100-PROCESS-LIST-READ
               THRU 6100-PROCESS-LIST-READ-X
                    VARYING WS-SUB FROM +1 BY +1
                      UNTIL WS-SUB > WS-MAX-BROWSE-LINES
                         OR WUSTM-IO-EOF.

           IF WUSTM-IO-EOF
      * MSG : END OF FILE REACHED
              MOVE 'XS00000025'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      * MSG : TO VIEW MORE DATA, PRESS ENTER
              MOVE 'XS00000014'       TO WGLOB-MSG-REF-INFO
              SET WGLOB-MORE-DATA-EXISTS TO TRUE
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  USTM-3000-END-BROWSE
               THRU USTM-3000-END-BROWSE-X.

       6000-PROCESS-LIST-X.
           EXIT.
      *
      **************************
       6100-PROCESS-LIST-READ.
      **************************

           MOVE RUSTM-USTM-EFF-DT     TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE   TO MIR-USTM-EFF-DT-T   (WS-SUB).
           MOVE RUSTM-USTM-SEQ-NUM    TO WS-PIC-999.
           MOVE WS-PIC-999            TO MIR-USTM-SEQ-NUM-T  (WS-SUB).
010418     MOVE RUSTM-SBSDRY-CO-ID  TO MIR-SBSDRY-CO-ID-T      (WS-SUB).
           MOVE RUSTM-USTM-TAXBL-EVNT-CD
                                 TO MIR-USTM-TAXBL-EVNT-CD-T   (WS-SUB).
           MOVE RUSTM-USTM-STAT-CD    TO MIR-USTM-STAT-CD-T    (WS-SUB).
008455*    MOVE RUSTM-USTM-TAXBL-AMT     TO DISPLAY-NUMBER-Z-9-2.
008455*    MOVE DISPLAY-NUMBER-Z-9-2   TO MIR-USTM-TAXBL-AMT-T (WS-SUB).
020874*    COMPUTE L0290-INPUT-NUMBER =  RUSTM-USTM-TAXBL-AMT * 100.
020874     MOVE RUSTM-USTM-TAXBL-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-USTM-TAXBL-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA    TO MIR-USTM-TAXBL-AMT-T   (WS-SUB).

008455*    MOVE RUSTM-USTM-FED-TAXWH-AMT TO DISPLAY-NUMBER-Z-9-2.
008455*  MOVE DISPLAY-NUMBER-Z-9-2 TO MIR-USTM-FED-TAXWH-AMT-T (WS-SUB).
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         RUSTM-USTM-FED-TAXWH-AMT *  100.
020874     MOVE RUSTM-USTM-FED-TAXWH-AMT TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-USTM-FED-TAXWH-AMT-T (WS-SUB)
008455                                TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA
                                 TO MIR-USTM-FED-TAXWH-AMT-T   (WS-SUB).


           PERFORM USTM-2000-READ-NEXT
              THRU USTM-2000-READ-NEXT-X.

           IF WS-SUB = WS-MAX-BROWSE-LINES
              AND NOT WUSTM-IO-EOF
               MOVE MIR-USTM-EFF-DT-T (WS-SUB)
                                      TO MIR-USTM-EFF-DT
               MOVE MIR-USTM-SEQ-NUM-T   (WS-SUB)
                                      TO MIR-USTM-SEQ-NUM
           END-IF.

       6100-PROCESS-LIST-READ-X.
           EXIT.
      *
      ***********************
       7000-READ-AGENT-INFO.
      ***********************

           PERFORM  0083-0000-INIT-PARM-INFO
               THRU 0083-0000-INIT-PARM-INFO-X.

028789*    MOVE MIR-AGT-ID            TO  L0083-AGENT-ID.
028789     MOVE MIR-AGT-ID            TO L0083-AGT-ID (1).

           PERFORM 0083-1000-RETRIEVE-AGT-INFO
              THRU 0083-1000-RETRIEVE-AGT-INFO-X.

           IF NOT L0083-RETRN-OK
028789     OR  L0083-AGT-NOTFND (1)
028789*        MOVE L0083-AGENT-ID    TO WGLOB-MSG-PARM (1)
028789         MOVE L0083-AGT-ID (1)  TO WGLOB-MSG-PARM (1)
      * MSG : RECORD (@1) NOT FOUND
               MOVE 'XS00000001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7000-READ-AGENT-INFO-X
           END-IF.

       7000-READ-AGENT-INFO-X.
           EXIT.
      *
      **********************
       8000-GET-CLIENT-INFO.
      **********************

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X

028789*    MOVE L0083-AGT-CLI-ID      TO L2435-CLI-ID.
028789     MOVE L0083-AGT-CLI-ID (1)  TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X.

           IF  L2435-RETRN-OK
               IF L2435-CLI-SEX-CD = 'C'
557698*           MOVE L2435-CLI-FULL-NAME   TO L0620-CLI-CO-NM
557698            MOVE L2435-CLI-ENTR-CO-NM
                                      TO L0620-CLI-CO-NM
               ELSE
557698*           MOVE L2435-CLI-GIV-NM      TO L0620-CLI-GIV-NM
557698*           MOVE L2435-CLI-SUR-NM      TO L0620-CLI-SUR-NM
557698            MOVE L2435-CLI-ENTR-GIV-NM
                                      TO L0620-CLI-GIV-NM
557698            MOVE L2435-CLI-ENTR-SUR-NM
                                      TO L0620-CLI-SUR-NM
                  MOVE L2435-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
                  MOVE L2435-CLI-SFX-NM TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2435-CLI-SEX-CD  TO L0620-CLI-SEX-CD

               PERFORM 0620-1000-FORMAT-SCREEN-NAME
                  THRU 0620-1000-FORMAT-SCREEN-NAME-X

               MOVE L0620-SCREEN-NAME TO MIR-DV-OWN-CLI-NM
               MOVE L2435-CLI-TAX-ID  TO MIR-CLI-TAX-ID
               MOVE L2435-CLI-ID      TO MIR-CLI-ID
               IF   L2435-CLI-TAX-ID  =  SPACES
               OR   L2435-CLI-TAX-ID  =  ZERO
      *MSG:    'AGENT'S TAX ID/SOCIAL SECURITY NUMBER IS MISSING'
                   MOVE 'CS41500009'  TO  WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           ELSE
               MOVE SPACES            TO MIR-DV-OWN-CLI-NM
               MOVE SPACES            TO MIR-CLI-TAX-ID
           END-IF.


       8000-GET-CLIENT-INFO-X.
           EXIT.
      *
      ************************
       9100-BLANK-DATA-FIELDS.
      ************************

010418     MOVE SPACES                TO MIR-SBSDRY-CO-ID.
           MOVE SPACES                TO MIR-USTM-STAT-CD.
           MOVE SPACES                TO MIR-USTM-TAXBL-EVNT-CD.
           MOVE SPACES                TO MIR-USTM-TAXBL-AMT.
           MOVE SPACES                TO MIR-USTM-FED-TAXWH-AMT.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      ****************************
       9200-MOVE-RECORD-TO-SCREEN.
      ****************************

010418     MOVE RUSTM-SBSDRY-CO-ID    TO MIR-SBSDRY-CO-ID.
           MOVE RUSTM-USTM-STAT-CD    TO MIR-USTM-STAT-CD.
           MOVE RUSTM-USTM-TAXBL-EVNT-CD
                                      TO MIR-USTM-TAXBL-EVNT-CD.

008455*    MOVE RUSTM-USTM-TAXBL-AMT     TO DISPLAY-NUMBER-Z-9-2.
008455*    MOVE DISPLAY-NUMBER-Z-9-2     TO MIR-USTM-TAXBL-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER =  RUSTM-USTM-TAXBL-AMT * 100.
020874     MOVE RUSTM-USTM-TAXBL-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-USTM-TAXBL-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-USTM-TAXBL-AMT.

008455*    MOVE RUSTM-USTM-FED-TAXWH-AMT TO DISPLAY-NUMBER-Z-9-2.
008455*    MOVE DISPLAY-NUMBER-Z-9-2     TO MIR-USTM-FED-TAXWH-AMT.
020874*    COMPUTE L0290-INPUT-NUMBER =
020874*         RUSTM-USTM-FED-TAXWH-AMT *  100.
020874     MOVE RUSTM-USTM-FED-TAXWH-AMT  TO L0290-INPUT-V02.
008455     MOVE 2                     TO L0290-PRECISION.
008455     MOVE LENGTH OF MIR-USTM-FED-TAXWH-AMT
                                      TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
008455     MOVE L0290-OUTPUT-DATA     TO MIR-USTM-FED-TAXWH-AMT.

           PERFORM  8000-GET-CLIENT-INFO
               THRU 8000-GET-CLIENT-INFO-X.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0083-0000-INIT-PARM-INFO
025970         THRU 0083-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WWKDT-WORK-FIELDS.
025970     SET  WS-TWRK-KEY-DEFAULT         TO TRUE.
025970     SET  WS-MAX-BROWSE-LINES-DEFAULT TO TRUE.
025970     SET  MIR-RETRN-OK                TO TRUE.
025970     MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      *****************************************************************
      *  PROCESSING COPYBOOK AREAS.
      *****************************************************************
      *
      *****************************************************************
      * LINK COPYBOOK FOR AUDIT MODULE CSLUUSTM                     ***
      *****************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY USTM
014221                         '$VAR2' BY 'USTM'.
      *
018764*COPY CCCLUSTM.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
018764 COPY CCPLUSTM.
      *
018764*COPY CCCL0083.
018764 COPY CCPL0083.
025970 COPY XCPS8090.
       COPY CCPS0083.
      *
018764*COPY CCCL2435.
018764 COPY CCPL2435.
       COPY CCPS2435.
      *
025970 COPY CCPS0620.
       COPY CCPL0620.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
025970 COPY XCPS0280.
       COPY XCPL0280.
      *
008455 COPY XCPL0290.
008455 COPY XCPS0290.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
      *
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
014660*COPY XCPPMEXT.
      *
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPCUSTM.
      *
       COPY CCPAUSTM.
      *
       COPY CCPBUSTM.
      *
       COPY CCPNUSTM.
      *
       COPY CCPUUSTM.
      *
010418 COPY CCPNSCOM.
      *
016537*COPY CCPNEDIT.
      *
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      *
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM4150                     **
      *****************************************************************
