      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7705.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7705                                         **
      **  REMARKS:  THIS MODULE PERFORMS CNTX RECORD SPLIT           **
      **                                                             **
      **  DOMAIN :  TX                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
013697**  6.3       ROTH IRA / EDUCATIONAL IRA                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
022455**  6.4       CORRECT POLICY ACTIVITY DATE                     **
023271**  6.5       REMOVAL OF CSINPGAO AND CSINPGAR                 **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7705'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                       PIC X(04).
               88  WS-BUS-FCN-PRCES                VALUE '7705'.
           05  WS-MIR-FIELDS.
               10  WS-MIR-CNTRXN-SEQ-NUM           PIC 9(01).
               10  WS-MIR-CNTRXN-AMT               PIC S9(13)V9(02)
                                                   COMP-3.
               10  WS-MIR-CNTRXN-TAX-YR            PIC 9(04).
               10  WS-MIR-REMN-CNTRXN-AMT          PIC S9(13)V9(02)
                                                   COMP-3.
           05  WS-TAX-YR-DIFF                      PIC S9(04).
           05  WS-NEXT-CNTRXN-SEQ-NUM              PIC 9(01).
           05  WS-NEW-ALLOC-TYP-CD                 PIC X(01).
           05  WS-OLD-ALLOC-TYP-CD                 PIC X(01).
           05  WS-EFF-DT                           PIC X(10).
           05  WS-PGAL-SEQ-NUM                     PIC S9(03) COMP-3.
           05  WS-PGAL-UPDATE-IND                  PIC X.
               88  WS-PGAL-UPDATE-YES              VALUE 'Y'.
               88  WS-PGAL-UPDATE-NO               VALUE 'N'.
           05  WS-PGAL-REC-FOUND-IND               PIC 9.
               88  WS-PGAL-REC-FOUND-NONE          VALUE 0.
               88  WS-PGAL-REC-FOUND-ONE           VALUE 1.
               88  WS-PGAL-REC-FOUND-TWO           VALUE 2.
           05  WS-SAVE-PGAL-EFF-DT                 PIC X(10).
           05  WS-SAVE-PGAL-SEQ-NUM                PIC S9(03) COMP-3.
           05  WS-DPOS-DFLT-SW                     PIC X(01).
               88  WS-DPOS-DFLT-FOUND              VALUE 'Y'.
               88  WS-DPOS-DFLT-NOT-FOUND          VALUE 'N'.

      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
028298 COPY CCWL2626.
       COPY XCWLDTLK.
       COPY XCWWWKDT.
       COPY CCWLPGA.
       COPY CCWWLOCK.
       COPY CCWWCVGS.
       COPY CCWWINDX.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWPOL.
       COPY CCFRPOL.
      /
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCFWCNTX.
       COPY CCFHCNTX.
       COPY CCFRCNTX.
      /
       COPY CCFWPGAO.
       COPY CCFWPGAM.
       COPY CCFRPGAL.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY CCWL2435.
       COPY CCWL7280.
       COPY CCWL7800.
       COPY CCWLPGAL.
021930*COPY XCWL1640.
       COPY XCWL1646.
       COPY XCWL1660.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL8090.
       COPY XCWL8960.

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7705.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    INITIALIZE WS-WORKING-STORAGE.

025970*    MOVE MIR-BUS-FCN-ID              TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-PRCES
                    PERFORM  3000-PROCESS-REQUEST
                        THRU 3000-PROCESS-REQUEST-X

               WHEN OTHER
      *MSG: INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
025999*             MOVE 'XS00000000'         TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'         TO WGLOB-MSG-REF-INFO
                    MOVE MIR-BUS-FCN-ID       TO WGLOB-MSG-PARM (1)
                    MOVE WPGWS-CRNT-PGM-ID    TO WGLOB-MSG-PARM (2)
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *----------------------------
       3000-PROCESS-REQUEST.
      *----------------------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  7300-EDIT-INPUT
               THRU 7300-EDIT-INPUT-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-EDIT-ERROR     TO TRUE
               GO TO 3000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  3100-CALC-REMN-CNTRXN-AMT
               THRU 3100-CALC-REMN-CNTRXN-AMT-X.

           PERFORM  3200-NEXT-CNTRXN-SEQ-NUM
               THRU 3200-NEXT-CNTRXN-SEQ-NUM-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3000-PROCESS-REQUEST-X
           END-IF.

022455     MOVE WS-EFF-DT               TO MIR-DV-EFF-DT.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           PERFORM  3300-GET-NEW-GAIN-ALLOC
               THRU 3300-GET-NEW-GAIN-ALLOC-X.

           PERFORM  3350-GET-ORIG-GAIN-ALLOC
               THRU 3350-GET-ORIG-GAIN-ALLOC-X.

           PERFORM  3360-PGAL-ROLL-FRWD-EDIT
               THRU 3360-PGAL-ROLL-FRWD-EDIT-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
           OR  MIR-DV-PRCES-STATE-CD NOT = '3'
               GO TO 3000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  3370-UPDATE-ORIGINAL-CNTX
               THRU 3370-UPDATE-ORIGINAL-CNTX-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 3000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  3380-CREATE-NEW-CNTX
               THRU 3380-CREATE-NEW-CNTX-X.

           PERFORM  3390-PGAL-ROLL-FRWD-UPDT
               THRU 3390-PGAL-ROLL-FRWD-UPDT-X.

       3000-PROCESS-REQUEST-X.
           EXIT.
      /
      *----------------------------
       3100-CALC-REMN-CNTRXN-AMT.
      *----------------------------

           COMPUTE WS-MIR-REMN-CNTRXN-AMT = HCNTX-CNTRXN-AMT
                                          - WS-MIR-CNTRXN-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = WS-MIR-REMN-CNTRXN-AMT
020874*                               * 100.
020874     MOVE WS-MIR-REMN-CNTRXN-AMT      TO L0290-INPUT-V02.
           MOVE +2                          TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-CNTRXN-REMN-AMT
             TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY           TO TRUE.
020874*    SET L0290-LEAD-ZEROS-DISPLAY     TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA           TO MIR-DV-CNTRXN-REMN-AMT.

       3100-CALC-REMN-CNTRXN-AMT-X.
           EXIT.

      *----------------------------
       3200-NEXT-CNTRXN-SEQ-NUM.
      *----------------------------

           MOVE LOW-VALUES               TO WCNTX-KEY.
           MOVE RPOL-POL-ID              TO WCNTX-POL-ID.
           MOVE MIR-CNTRXN-TS            TO WCNTX-CNTRXN-TS.
           MOVE ZERO                     TO WCNTX-CNTRXN-SEQ-NUM.

           MOVE WCNTX-KEY                TO WCNTX-ENDBR-KEY.
           MOVE +9                       TO WCNTX-ENDBR-CNTRXN-SEQ-NUM.

           PERFORM  CNTX-2000-READ-MAX
               THRU CNTX-2000-READ-MAX-X.

           IF  NOT WCNTX-IO-OK
               MOVE +1                   TO WS-NEXT-CNTRXN-SEQ-NUM
               GO TO 3200-NEXT-CNTRXN-SEQ-NUM-X
           END-IF.

           IF  WCNTX-MAX-CNTRXN-SEQ-NUM = +9
      *MSG: NO CNTX SEQUENCE NUMBER AVAILABLE
               MOVE 'CS77050001'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 3200-NEXT-CNTRXN-SEQ-NUM-X
           END-IF.

           COMPUTE WS-NEXT-CNTRXN-SEQ-NUM = WCNTX-MAX-CNTRXN-SEQ-NUM
                                          + 1.

       3200-NEXT-CNTRXN-SEQ-NUM-X.
           EXIT.

      *----------------------------
       3300-GET-NEW-GAIN-ALLOC.
      *----------------------------

           PERFORM  7280-1000-BUILD-PARM-INFO
               THRU 7280-1000-BUILD-PARM-INFO-X.

           MOVE RPOL-POL-ID                 TO L7800-POL-ID.
           IF  HCNTX-CDA-TYP-CD = SPACE
               MOVE RPOL-POL-MISC-SUSP-DT   TO L7800-EFF-DT
           ELSE
               MOVE WS-EFF-DT               TO L7800-EFF-DT
           END-IF.

           MOVE MIR-CNTRXN-TYP-CD           TO L7800-CNTRXN-TYP-CD.
           MOVE WS-MIR-CNTRXN-TAX-YR        TO L7800-TAX-YR.
           SET L7800-TRXN-DPOS              TO TRUE.
           SET L7800-PRCES-NORMAL           TO TRUE.
           SET L7800-GET-PLAR-REQ           TO TRUE.

           PERFORM  7800-1000-GET-PLAR-INFO
               THRU 7800-1000-GET-PLAR-INFO-X.

           IF  NOT L7800-RETRN-OK
      *MSG: 7800 CALL FAILED
               MOVE 'CS77050002'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 3300-GET-NEW-GAIN-ALLOC-X
           END-IF.

           PERFORM
               VARYING LPGAL-SUB FROM 1 BY 1
               UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
               OR WS-NEW-ALLOC-TYP-CD NOT = SPACE

               IF  L7800-PGAL-DPOS-DFLT (LPGAL-SUB)
                   MOVE L7800-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
                     TO WS-NEW-ALLOC-TYP-CD
               END-IF

           END-PERFORM.

           IF  WS-NEW-ALLOC-TYP-CD = SPACE
      *MSG: NEW ALLOCATION NOT FOUND
               MOVE 'CS77050003'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
           END-IF.

       3300-GET-NEW-GAIN-ALLOC-X.
           EXIT.

      *----------------------------
       3350-GET-ORIG-GAIN-ALLOC.
      *----------------------------

           SET WS-PGAL-UPDATE-YES      TO TRUE.
           SET WS-DPOS-DFLT-NOT-FOUND  TO TRUE.

           PERFORM  7800-0000-INIT-PARM-INFO
               THRU 7800-0000-INIT-PARM-INFO-X.

           MOVE RPOL-POL-ID                 TO L7800-POL-ID.

           IF  HCNTX-CDA-TYP-CD = SPACE
               MOVE RPOL-POL-MISC-SUSP-DT   TO L7800-EFF-DT
           ELSE
               MOVE HCNTX-CDA-EFF-IDT-NUM   TO L1660-INVERTED-DATE
               PERFORM  1660-3000-CONVERT-INV-TO-INT
                   THRU 1660-3000-CONVERT-INV-TO-INT-X
               MOVE L1660-INTERNAL-DATE     TO L7800-EFF-DT
           END-IF

           MOVE HCNTX-CNTRXN-TYP-CD         TO L7800-CNTRXN-TYP-CD.
           MOVE HCNTX-CNTRXN-TAX-YR         TO L7800-TAX-YR.
           SET L7800-TRXN-DPOS              TO TRUE.
           SET L7800-GET-PLAR-REQ           TO TRUE.
           SET L7800-PRCES-NORMAL           TO TRUE.
           SET L7800-PGAL-ALLOC-REQ         TO TRUE.

           PERFORM  7800-1000-GET-PLAR-INFO
               THRU 7800-1000-GET-PLAR-INFO-X.

           IF  NOT L7800-RETRN-OK
      *MSG: 7800 CALL FAILED
               MOVE 'CS77050002'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 3350-GET-ORIG-GAIN-ALLOC-X
           END-IF.

           PERFORM

               VARYING LPGAL-SUB FROM 1 BY 1
               UNTIL LPGAL-SUB > LPGAL-MAX-ALLOC-TYP
               OR WS-OLD-ALLOC-TYP-CD NOT = SPACE

               IF  L7800-PGAL-DPOS-DFLT (LPGAL-SUB)
                   MOVE L7800-PGAL-ALLOC-TYP-CD (LPGAL-SUB)
                     TO WS-OLD-ALLOC-TYP-CD
                     SET WS-DPOS-DFLT-FOUND TO TRUE
               END-IF

           END-PERFORM.


           IF  HCNTX-CDA-TYP-CD = SPACE
               PERFORM  3400-GET-PENDING-PGAL
                   THRU 3400-GET-PENDING-PGAL-X
               GO TO 3350-GET-ORIG-GAIN-ALLOC-X
           ELSE
               IF  WS-OLD-ALLOC-TYP-CD NOT = SPACES
                   MOVE LOW-VALUES           TO WPGAO-KEY
                   MOVE HCNTX-POL-ID         TO WPGAO-POL-ID
                   MOVE HCNTX-CDA-TYP-CD     TO WPGAO-CDA-TYP-CD
                   MOVE HCNTX-POL-PAYO-NUM   TO WPGAO-POL-PAYO-NUM
                   MOVE HCNTX-CDA-EFF-IDT-NUM  TO WPGAO-CDA-EFF-IDT-NUM
                   MOVE HCNTX-CDA-SEQ-NUM    TO WPGAO-CDA-SEQ-NUM
                   MOVE WS-OLD-ALLOC-TYP-CD  TO WPGAO-PGAL-ALLOC-TYP-CD

023271             MOVE WPGAO-KEY            TO WPGAO-ENDBR-KEY
023271*            PERFORM  PGAO-1000-READ
023271*                THRU PGAO-1000-READ-X

023271             PERFORM  PGAO-1000-BROWSE
023271                 THRU PGAO-1000-BROWSE-X
023271
023271             PERFORM  PGAO-2000-READ-NEXT
023271                 THRU PGAO-2000-READ-NEXT-X
023271
                   IF  WPGAO-IO-OK
                       MOVE RPGAL-PGAL-SEQ-NUM TO WS-PGAL-SEQ-NUM
023271             END-IF
023271
023271             PERFORM  PGAO-3000-END-BROWSE
023271                 THRU PGAO-3000-END-BROWSE-X
023271
023271*            ELSE
023271             IF  NOT WPGAO-IO-OK
      *MSG: ORIGINAL ALLOCATION NOT FOUND
                       MOVE 'CS77050004'     TO WGLOB-MSG-REF-INFO
                       PERFORM  0260-1000-GENERATE-MESSAGE
                           THRU 0260-1000-GENERATE-MESSAGE-X
                       MOVE 1                TO WGLOB-MSG-ERROR-SW
                   END-IF
               ELSE
      *MSG: ORIGINAL ALLOCATION NOT FOUND
                   MOVE 'CS77050004'         TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 1                    TO WGLOB-MSG-ERROR-SW
                   GO TO 3350-GET-ORIG-GAIN-ALLOC-X
               END-IF
           END-IF.

       3350-GET-ORIG-GAIN-ALLOC-X.
           EXIT.

      *----------------------------
       3360-PGAL-ROLL-FRWD-EDIT.
      *----------------------------

           IF  WS-OLD-ALLOC-TYP-CD = WS-NEW-ALLOC-TYP-CD
           OR  WS-PGAL-UPDATE-NO
               GO TO 3360-PGAL-ROLL-FRWD-EDIT-X
           END-IF.

           PERFORM  7280-1000-BUILD-PARM-INFO
               THRU 7280-1000-BUILD-PARM-INFO-X.

           SET L7280-PRCES-TYP-EDIT-ONLY    TO TRUE.

           PERFORM  3361-PGAL-ROLL-FRWD
               THRU 3361-PGAL-ROLL-FRWD-X.

       3360-PGAL-ROLL-FRWD-EDIT-X.
           EXIT.

      *----------------------------
       3361-PGAL-ROLL-FRWD.
      *----------------------------

           SET L7280-FCN-DRVR-PRIMARY       TO TRUE.
           MOVE WS-EFF-DT                   TO L7280-EFF-DT.
           MOVE WS-OLD-ALLOC-TYP-CD         TO L7280-FROM-ALLOC-TYP-CD.
           MOVE WS-NEW-ALLOC-TYP-CD         TO L7280-TO-ALLOC-TYP-CD.
           MOVE WS-PGAL-SEQ-NUM             TO L7280-PGAL-SEQ-NUM.
           MOVE WS-MIR-CNTRXN-AMT           TO L7280-REALLOC-PRIN-AMT.
           MOVE HCNTX-CDA-TYP-CD            TO L7280-CDA-TYP-CD.
           MOVE HCNTX-POL-PAYO-NUM          TO L7280-POL-PAYO-NUM.
           MOVE HCNTX-CDA-EFF-IDT-NUM       TO L7280-CDA-EFF-IDT-NUM.
           MOVE HCNTX-CDA-SEQ-NUM           TO L7280-CDA-SEQ-NUM.

           PERFORM  7280-2000-PROCESS-REQST
               THRU 7280-2000-PROCESS-REQST-X.

           IF  NOT L7280-RETRN-OK
      *MSG: 7280 CALL FAILED
               MOVE 'CS77050005'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
           END-IF.

       3361-PGAL-ROLL-FRWD-X.
           EXIT.

      *----------------------------
       3370-UPDATE-ORIGINAL-CNTX.
      *----------------------------

           MOVE MIR-POL-ID               TO WPOL-POL-ID.

           PERFORM  POL-2000-UPDATE-TWRK-TS
               THRU POL-2000-UPDATE-TWRK-TS-X.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG: PROCESS FAILED - RE-ENTER DATA AS ANOTHER PROCESS HAS
      *      UPDATED - TABLE (@1), KEY @2
               MOVE 'XS00000303'            TO WGLOB-MSG-REF-INFO
               MOVE 'POL'                   TO WGLOB-MSG-PARM (1)
               MOVE WPOL-KEY                TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 3370-UPDATE-ORIGINAL-CNTX-X
           END-IF.

           IF  NOT WPOL-IO-OK
      *MSG: RECORD NOT FOUND
               MOVE 'XS00000001'            TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY                TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 3370-UPDATE-ORIGINAL-CNTX-X
           END-IF.

           MOVE HCNTX-POL-ID                TO WCNTX-POL-ID.
           MOVE HCNTX-CNTRXN-TS             TO WCNTX-CNTRXN-TS.
           MOVE HCNTX-CNTRXN-SEQ-NUM        TO WCNTX-CNTRXN-SEQ-NUM.

           PERFORM  CNTX-1000-READ-FOR-UPDATE
               THRU CNTX-1000-READ-FOR-UPDATE-X.

           IF  NOT WCNTX-IO-OK
      *MSG: CNTX (@1) NOT FOUND
               MOVE 'CS77050007'            TO WGLOB-MSG-REF-INFO
               MOVE WCNTX-KEY               TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 3370-UPDATE-ORIGINAL-CNTX-X
           END-IF.

           MOVE WS-MIR-REMN-CNTRXN-AMT   TO RCNTX-CNTRXN-AMT.
           MOVE MIR-CNTRXN-COMNT-TXT     TO RCNTX-CNTRXN-COMNT-TXT-TXT.
           MOVE LENGTH OF RCNTX-CNTRXN-COMNT-TXT-TXT
             TO I.

           PERFORM
               VARYING I
               FROM LENGTH OF RCNTX-CNTRXN-COMNT-TXT-TXT BY -1
               UNTIL RCNTX-CNTRXN-COMNT-TXT-TXT (I:1) NOT = SPACE
               OR I = 1

               CONTINUE

           END-PERFORM.

           MOVE I                        TO RCNTX-CNTRXN-COMNT-TXT-LEN.

           PERFORM  CNTX-2000-REWRITE
               THRU CNTX-2000-REWRITE-X.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

       3370-UPDATE-ORIGINAL-CNTX-X.
           EXIT.

      *----------------------------
       3380-CREATE-NEW-CNTX.
      *----------------------------

           MOVE HCNTX-REC-INFO           TO RCNTX-REC-INFO.
           MOVE RCNTX-KEY                TO WCNTX-KEY.

           MOVE WS-NEXT-CNTRXN-SEQ-NUM   TO WCNTX-CNTRXN-SEQ-NUM.

           MOVE MIR-CNTRXN-TYP-CD        TO RCNTX-CNTRXN-TYP-CD.
           MOVE WS-MIR-CNTRXN-TAX-YR     TO RCNTX-CNTRXN-TAX-YR.
           MOVE WS-MIR-CNTRXN-AMT        TO RCNTX-CNTRXN-AMT.
           MOVE MIR-CLI-ID               TO RCNTX-CLI-ID.
           MOVE MIR-CNTRXN-COMNT-TXT     TO RCNTX-CNTRXN-COMNT-TXT-TXT.

           MOVE LENGTH OF RCNTX-CNTRXN-COMNT-TXT-TXT
             TO I.

           PERFORM
               VARYING I
               FROM LENGTH OF RCNTX-CNTRXN-COMNT-TXT-TXT BY -1
               UNTIL RCNTX-CNTRXN-COMNT-TXT-TXT (I:1) NOT = SPACE
               OR I = 1

               CONTINUE

           END-PERFORM.

           MOVE I                        TO RCNTX-CNTRXN-COMNT-TXT-LEN.

           PERFORM  CNTX-1000-WRITE
               THRU CNTX-1000-WRITE-X.

       3380-CREATE-NEW-CNTX-X.
           EXIT.

      *----------------------------
       3390-PGAL-ROLL-FRWD-UPDT.
      *----------------------------

           IF  WS-OLD-ALLOC-TYP-CD = WS-NEW-ALLOC-TYP-CD
           OR  WS-PGAL-UPDATE-NO
               GO TO 3390-PGAL-ROLL-FRWD-UPDT-X
           END-IF.

           PERFORM  7280-1000-BUILD-PARM-INFO
               THRU 7280-1000-BUILD-PARM-INFO-X.

           SET L7280-PRCES-TYP-ALL          TO TRUE.

           PERFORM  3361-PGAL-ROLL-FRWD
               THRU 3361-PGAL-ROLL-FRWD-X.

       3390-PGAL-ROLL-FRWD-UPDT-X.
           EXIT.


      *----------------------
       3400-GET-PENDING-PGAL.
      *----------------------

           SET  WS-PGAL-REC-FOUND-NONE   TO TRUE.
           MOVE SPACE              TO WS-SAVE-PGAL-EFF-DT.
           MOVE ZERO               TO WS-SAVE-PGAL-SEQ-NUM.

           MOVE RPOL-POL-ID        TO WPGAM-POL-ID.
           MOVE WWKDT-LOW-DT       TO WPGAM-PGAL-EFF-DT.
           MOVE ZERO               TO WPGAM-PGAL-SEQ-NUM.
           MOVE LOW-VALUE          TO WPGAM-PGAL-ALLOC-TYP-CD.
           MOVE WPGAM-KEY          TO WPGAM-ENDBR-KEY.
           MOVE WWKDT-HIGH-DT      TO WPGAM-ENDBR-PGAL-EFF-DT.
           MOVE 999                TO WPGAM-ENDBR-PGAL-SEQ-NUM.
           MOVE HIGH-VALUE         TO WPGAM-ENDBR-PGAL-ALLOC-TYP-CD.

           PERFORM  PGAM-1000-BROWSE
               THRU PGAM-1000-BROWSE-X.

           PERFORM  PGAM-2000-READ-NEXT
               THRU PGAM-2000-READ-NEXT-X.

           IF  WPGAM-IO-EOF
               PERFORM  PGAM-3000-END-BROWSE
                   THRU PGAM-3000-END-BROWSE-X
               PERFORM  3420-GEN-MANUAL-MSG
                   THRU 3420-GEN-MANUAL-MSG-X
               GO TO 3400-GET-PENDING-PGAL-X
           END-IF.

           MOVE RPGAL-PGAL-EFF-DT  TO WS-SAVE-PGAL-EFF-DT.
           MOVE RPGAL-PGAL-SEQ-NUM TO WS-SAVE-PGAL-SEQ-NUM.

           IF  WS-DPOS-DFLT-NOT-FOUND
              MOVE RPGAL-PGAL-ALLOC-TYP-CD TO WS-OLD-ALLOC-TYP-CD
           END-IF.

           SET  WS-PGAL-REC-FOUND-ONE   TO TRUE.

           PERFORM  3410-READ-NEXT-PGAL
               THRU 3410-READ-NEXT-PGAL-X
               UNTIL WPGAM-IO-EOF
               OR    WS-PGAL-REC-FOUND-TWO.

           PERFORM  PGAM-3000-END-BROWSE
               THRU PGAM-3000-END-BROWSE-X.

           IF WS-PGAL-REC-FOUND-TWO
               PERFORM  3420-GEN-MANUAL-MSG
                   THRU 3420-GEN-MANUAL-MSG-X
               GO TO 3400-GET-PENDING-PGAL-X
           END-IF.

           IF  WS-OLD-ALLOC-TYP-CD = SPACE
      *MSG: ORIGINAL ALLOCATION NOT FOUND
               MOVE 'CS77050004'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
           END-IF.

           MOVE WS-SAVE-PGAL-EFF-DT         TO WS-EFF-DT.
           MOVE WS-SAVE-PGAL-SEQ-NUM        TO WS-PGAL-SEQ-NUM.

       3400-GET-PENDING-PGAL-X.
           EXIT.

      *-------------------
       3410-READ-NEXT-PGAL.
      *-------------------

           IF RPGAL-PGAL-EFF-DT   NOT = WS-SAVE-PGAL-EFF-DT
           OR RPGAL-PGAL-SEQ-NUM  NOT = WS-SAVE-PGAL-SEQ-NUM
              SET WS-PGAL-REC-FOUND-TWO     TO TRUE
              GO TO 3410-READ-NEXT-PGAL-X
           END-IF.

           IF  RPGAL-PGAL-ALLOC-TYP-CD = WS-OLD-ALLOC-TYP-CD
               MOVE RPGAL-PGAL-EFF-DT       TO WS-SAVE-PGAL-EFF-DT
               MOVE RPGAL-PGAL-SEQ-NUM      TO WS-SAVE-PGAL-SEQ-NUM
           END-IF.

           IF  WS-DPOS-DFLT-NOT-FOUND
           AND WS-OLD-ALLOC-TYP-CD NOT = WS-NEW-ALLOC-TYP-CD
               MOVE RPGAL-PGAL-ALLOC-TYP-CD TO WS-OLD-ALLOC-TYP-CD
           END-IF.

           PERFORM  PGAM-2000-READ-NEXT
               THRU PGAM-2000-READ-NEXT-X.

       3410-READ-NEXT-PGAL-X.
           EXIT.


      *--------------------
       3420-GEN-MANUAL-MSG.
      *--------------------

           SET WS-PGAL-UPDATE-NO   TO TRUE
           MOVE SPACE              TO WS-OLD-ALLOC-TYP-CD
      *MSG: MANUAL UPDATE ON PGAL AND POLT INFORMATION MAY BE REQUIRED,
      *     ALLOCATION TYPES ARE (@1) AND (@2)
           MOVE 'CS77050020'            TO WGLOB-MSG-REF-INFO
           MOVE WS-OLD-ALLOC-TYP-CD     TO WGLOB-MSG-PARM (1)
           MOVE WS-NEW-ALLOC-TYP-CD     TO WGLOB-MSG-PARM (2)
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.


       3420-GEN-MANUAL-MSG-X.
           EXIT.


      *----------------
       7300-EDIT-INPUT.
      *----------------

           PERFORM  7310-EDIT-POL-ID
               THRU 7310-EDIT-POL-ID-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 7300-EDIT-INPUT-X
           END-IF.

           PERFORM  7320-EDIT-CNTX-RECORD
               THRU 7320-EDIT-CNTX-RECORD-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 7300-EDIT-INPUT-X
           END-IF.

           PERFORM  7330-EDIT-CLI-ID
               THRU 7330-EDIT-CLI-ID-X.

           PERFORM  7340-EDIT-CNTRXN-STAT-CD
               THRU 7340-EDIT-CNTRXN-STAT-CD-X.

           PERFORM  7350-EDIT-CNTRXN-RPT-CD
               THRU 7350-EDIT-CNTRXN-RPT-CD-X.

           PERFORM  7360-EDIT-CNTRXN-AMT
               THRU 7360-EDIT-CNTRXN-AMT-X.

           PERFORM  7370-EDIT-CNTRXN-TYP-CD
               THRU 7370-EDIT-CNTRXN-TYP-CD-X.

           PERFORM  7380-EDIT-CNTRXN-TAX-YR
               THRU 7380-EDIT-CNTRXN-TAX-YR-X.

           PERFORM  7390-EDIT-CNTRXN-COMNT-TXT
               THRU 7390-EDIT-CNTRXN-COMNT-TXT-X.

       7300-EDIT-INPUT-X.
           EXIT.

      *----------------------------
       7310-EDIT-POL-ID.
      *----------------------------

           MOVE MIR-POL-ID                  TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  NOT WPOL-IO-OK
      *MSG: RECORD NOT FOUND
               MOVE 'CS77050006'            TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY                TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 7310-EDIT-POL-ID-X
           END-IF.

       7310-EDIT-POL-ID-X.
           EXIT.

      *----------------------------
       7320-EDIT-CNTX-RECORD.
      *----------------------------

           PERFORM  7321-EDIT-CNTRXN-TS
               THRU 7321-EDIT-CNTRXN-TS-X.

           PERFORM  7322-EDIT-CNTRXN-SEQ-NUM
               THRU 7322-EDIT-CNTRXN-SEQ-NUM-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               GO TO 7320-EDIT-CNTX-RECORD-X
           END-IF.

           MOVE RPOL-POL-ID                 TO WCNTX-POL-ID.
           MOVE MIR-CNTRXN-TS               TO WCNTX-CNTRXN-TS.
           MOVE WS-MIR-CNTRXN-SEQ-NUM       TO WCNTX-CNTRXN-SEQ-NUM.

           PERFORM  CNTX-1000-READ
               THRU CNTX-1000-READ-X

           IF  NOT WCNTX-IO-OK
      *MSG: CNTX (@1) NOT FOUND
               MOVE 'CS77050007'            TO WGLOB-MSG-REF-INFO
               MOVE WCNTX-KEY               TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 7320-EDIT-CNTX-RECORD-X
           END-IF.

           MOVE RCNTX-CDA-EFF-IDT-NUM       TO L1660-INVERTED-DATE.
           PERFORM  1660-3000-CONVERT-INV-TO-INT
               THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE         TO WS-EFF-DT.

           MOVE RCNTX-REC-INFO              TO HCNTX-REC-INFO.

       7320-EDIT-CNTX-RECORD-X.
           EXIT.

      *----------------------------
       7321-EDIT-CNTRXN-TS.
      *----------------------------

           PERFORM  1646-1000-BUILD-PARM-INFO
               THRU 1646-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CNTRXN-TS               TO L1646-TIMESTAMP.

           PERFORM  1646-1000-EDIT-TIMESTAMP
               THRU 1646-1000-EDIT-TIMESTAMP-X.

           IF  NOT L1646-EDIT-OK
      *MSG: INVALID TIMESTAMP
               MOVE 'CS77050008'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
           END-IF.

       7321-EDIT-CNTRXN-TS-X.
           EXIT.

      *----------------------------
       7322-EDIT-CNTRXN-SEQ-NUM.
      *----------------------------

           MOVE MIR-CNTRXN-SEQ-NUM           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-CNTRXN-SEQ-NUM TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE             TO L0280-LENGTH.
           MOVE ZERO                         TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED      TO TRUE.
           SET L0280-SPACES-PERMITTED        TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00         TO WS-MIR-CNTRXN-SEQ-NUM
           ELSE
      *MSG: INVALID SEQUENCE NUMBER
               MOVE 'CS77050009'             TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                        TO WGLOB-MSG-ERROR-SW
               MOVE ZERO                     TO WS-MIR-CNTRXN-SEQ-NUM
           END-IF.

       7322-EDIT-CNTRXN-SEQ-NUM-X.
           EXIT.

      *----------------------------
       7330-EDIT-CLI-ID.
      *----------------------------

           PERFORM  2435-1000-BUILD-PARM-INFO
               THRU 2435-1000-BUILD-PARM-INFO-X.

           MOVE MIR-CLI-ID                  TO L2435-CLI-ID.

           PERFORM  2435-1000-OBTAIN-CLI-INFO
               THRU 2435-1000-OBTAIN-CLI-INFO-X

           IF  NOT L2435-RETRN-OK
      *MSG: CLIENT (@1) NOT FOUND
               MOVE 'CS77050010'            TO WGLOB-MSG-REF-INFO
               MOVE MIR-CLI-ID              TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7330-EDIT-CLI-ID-X.
           EXIT.

      *----------------------------
       7340-EDIT-CNTRXN-STAT-CD.
      *----------------------------

           IF  HCNTX-CNTRXN-STAT-ERROR
      *MSG: RECORD STATUS IS 'ERROR'
               MOVE 'CS77050011'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7340-EDIT-CNTRXN-STAT-CD-X.
           EXIT.

      *----------------------------
       7350-EDIT-CNTRXN-RPT-CD.
      *----------------------------

           IF  HCNTX-CNTRXN-RPT-ACTV-RPT
           OR  HCNTX-CNTRXN-RPT-RPT-LATE
      *MSG: REPORTING STATUS IS 'REPORTED'
               MOVE 'CS77050012'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7350-EDIT-CNTRXN-RPT-CD-X.
           EXIT.

      *----------------------------
       7360-EDIT-CNTRXN-AMT.
      *----------------------------

           MOVE MIR-CNTRXN-AMT              TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-CNTRXN-AMT    TO L0280-INPUT-SIZE.
           COMPUTE L0280-LENGTH = L0280-INPUT-SIZE
                                - 4.
           MOVE +2                          TO L0280-PRECISION.
           SET L0280-SIGN-PERMITTED         TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V02        TO WS-MIR-CNTRXN-AMT
           ELSE
      *MSG: INVALID CONTRIBUTION AMOUNT
               MOVE 'CS77050013'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 7360-EDIT-CNTRXN-AMT-X
           END-IF.

           IF  WS-MIR-CNTRXN-AMT > HCNTX-CNTRXN-AMT
      *MSG: NEW CONTRIBUTION AMOUNT > ORIGINAL AMOUNT
               MOVE 'CS77050014'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7360-EDIT-CNTRXN-AMT-X.
           EXIT.

      *----------------------------
       7370-EDIT-CNTRXN-TYP-CD.
      *----------------------------

           PERFORM  8960-1000-BUILD-PARM-INFO
               THRU 8960-1000-BUILD-PARM-INFO-X.

           MOVE 'CNTRXN-TYP-CD'              TO L8960-AV-TBL-CD.
           MOVE MIR-CNTRXN-TYP-CD            TO L8960-AV-CD.

           PERFORM  8960-1000-VALIDATE-CODE
               THRU 8960-1000-VALIDATE-CODE-X.

           IF  NOT L8960-RETRN-OK
      *MSG: INVALID CONTRIBUTION TYPE CODE
               MOVE 'CS77050015'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7370-EDIT-CNTRXN-TYP-CD-X.
           EXIT.

      *----------------------------
       7380-EDIT-CNTRXN-TAX-YR.
      *----------------------------

           MOVE MIR-CNTRXN-TAX-YR           TO L0280-INPUT-DATA.
           MOVE LENGTH OF MIR-CNTRXN-TAX-YR TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE            TO L0280-LENGTH.
           MOVE ZERO                        TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED     TO TRUE.
           SET L0280-SPACES-PERMITTED       TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00        TO WS-MIR-CNTRXN-TAX-YR
           ELSE
      *MSG: INVALID TAX YEAR
               MOVE 'CS77050016'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                       TO WGLOB-MSG-ERROR-SW
               GO TO 7380-EDIT-CNTRXN-TAX-YR-X
           END-IF.


           COMPUTE WS-TAX-YR-DIFF = WS-MIR-CNTRXN-TAX-YR
                                  - HCNTX-CNTRXN-TAX-YR.


           IF  WS-TAX-YR-DIFF > 1
           OR  WS-TAX-YR-DIFF < -1
      *MSG: TAX YEAR DIFFERS MORE THAN 1 YEAR
               MOVE 'CS77050017'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7380-EDIT-CNTRXN-TAX-YR-X
           END-IF.

           IF  WS-TAX-YR-DIFF = 1
           AND WS-MIR-CNTRXN-TAX-YR > WGLOB-PROCESS-DATE-YR
      *MSG: NEW TAX YEAR IS LATER THAN CURRENT PROCESS YEAR
               MOVE 'CS77050018'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 7380-EDIT-CNTRXN-TAX-YR-X
           END-IF.

       7380-EDIT-CNTRXN-TAX-YR-X.
           EXIT.


      *----------------------------
       7390-EDIT-CNTRXN-COMNT-TXT.
      *----------------------------

           IF  MIR-CNTRXN-COMNT-TXT = SPACE
      *MSG: AUDIT HISTORY USER COMMENT IS EMPTY
               MOVE 'CS77050019'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7390-EDIT-CNTRXN-COMNT-TXT-X.
           EXIT.

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                   TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1646-0000-INIT-PARM-INFO
025970         THRU 1646-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2435-0000-INIT-PARM-INFO
025970         THRU 2435-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  7280-0000-INIT-PARM-INFO
025970         THRU 7280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  7800-0000-INIT-PARM-INFO
025970         THRU 7800-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     MOVE SPACES         TO WWKDT-WORK-FIELDS.
025970
025970     MOVE MIR-BUS-FCN-ID TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY NCPPCVGS.
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  POL
                                '$VAR2'   BY 'POL'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
025970 COPY XCPS8090.
       COPY CCPS2435.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
       COPY CCPL2435.
      /
       COPY CCPS7800.
       COPY CCPL7800.
      /
       COPY CCPS7280.
       COPY CCPL7280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
       COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
021930*COPY XCPL1640.
021930*
       COPY XCPS1646.
       COPY XCPL1646.
      /
025970 COPY XCPS1660.
       COPY XCPL1660.
      /
021930*COPY XCPS8090.
       COPY XCPL8090.

       COPY XCPS8960.
       COPY XCPL8960.

      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.

       COPY CCPNCVG.

       COPY CCPFCNTX.
       COPY CCPNCNTX.
       COPY CCPUCNTX.
       COPY CCPACNTX.
      /
023271 COPY CCPBPGAO.
023271*COPY CCPNPGAO.
       COPY CCPBPGAM.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM CSOM7705
      *****************************************************************
