      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7816.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7816                                         **
      **  REMARKS:  THIS MODULE PERFORMS                             **
      **            FUND BALANCE DETAILS - ACTIVITY LIST             **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
018839**  6.3       FINANCIAL BALANCES FLOW                          **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021239**  6.4       FUND UNIT VALUE                                  **
020463**  6.4       INVESTOR PROFILES                                **
023112**  6.5       CASH FLOW DESTINATION INSTRUCTIONS               **
023478**  6.5       TXN REASON CODE FOR FUSION REGEN                 **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
021657**  6.6       CORRECT FIELD NAMES IN MIR COPYBOOKS             **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
025999**  6.6       MESSAGE CORRECTION                               **
026057**  6.6       INVESTMENT HISTORY START DATE                    **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
026206**  6.7       FINANCIAL BALANCE ENQUIRY ON ASSEST REBALANCE    **
027315**  6.7       TRANSFER DOESNOT SHOW UP ON POLICY ACTIVITY LIST **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
030054**  7.0       PHST SEQUENCE NUMBER EXPANSION                   **
031036**  7.0       EXEMPT STATUS MANAGEMENT                         **
033899**  7.0       M&E TRANSFER MISSING FROM POLICY ACTIVITY LIST   **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7816'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-MAX-LINE                      PIC 999 VALUE 50.

       01  WS-WORK-AREA.
           05  WS-BUS-FCN-ID                    PIC X(04).
               88  WS-BUS-FCN-RETRIEVE          VALUE '7816'.
           05  WS-CVG                           PIC 99.
           05  WS-SEQ                           PIC X(20).
           05  FILLER                REDEFINES  WS-SEQ.
               10  WS-SEQ-NUM                   PIC 999.
               10  FILLER                       PIC X(17).
           05  FILLER                           REDEFINES WS-SEQ.
               10  WS-CDSA-NUM                  PIC 99999.
               10  FILLER                       PIC X(15).
           05  WS-FA-SEQ-NUM                    PIC 999.
           05  WS-CDA-NUM                       PIC 99999.
           05  WS-SUB                           PIC 999.
           05  WS-WEALTH-ACCUM-IND              PIC X.
               88  WS-WEALTH-ACCUM-YES          VALUE 'Y'.
               88  WS-WEALTH-ACCUM-NO           VALUE 'N'.
           05  WS-COLLATERAL-FUND-IND           PIC X.
               88  WS-COLLATERAL-FUND-YES       VALUE 'Y'.
               88  WS-COLLATERAL-FUND-NO        VALUE 'N'.
           05  WS-CVG-TYP-CD                    PIC X.
               88  WS-CVG-TYP-SEG-FUND          VALUE 'F'.
               88  WS-CVG-TYP-CASH-FLOW         VALUE 'C'.
           05  WS-SAVE-POL-ID                   PIC X(010).
           05  WS-SAVE-CVG                      PIC 9(002).
           05  WS-SAVE-FND-ID                   PIC X(005).
           05  WS-SAVE-DEST-SEQ                 PIC 9(003).
           05  WS-SAVE-EFF-IDT-NUM              PIC X(007).
           05  WS-SAVE-EFF-DT                   PIC X(010).
030054*    05  WS-SAVE-SEQ-NUM                  PIC 9(003).
030054     05  WS-SAVE-SEQ-NUM                  PIC 9(005).
030054*    05  WS-SAVE-PHST-DATA.
030054*        10  WS-SAVE-PCHST-SEQ-NUM        PIC 9(003).
030054*        10  WS-SAVE-POL-ACTV-TYP-ID      PIC X(004).
030054*        10  WS-SAVE-PCHST-EFF-DT         PIC X(010).
           05  WS-SAVE-UH-EFF-DT                PIC X(010).
           05  WS-SAVE-UH-EFF-DT-R REDEFINES WS-SAVE-UH-EFF-DT.
               10  WS-SAVE-UH-EFF-DT-YR         PIC 9(004).
               10  FILLER                       PIC X(001).
               10  WS-SAVE-UH-EFF-DT-MT         PIC 9(002).
               10  FILLER                       PIC X(001).
               10  WS-SAVE-UH-EFF-DT-DY         PIC 9(002).

           05  WS-OUTPUT-DATA.
               10  WS-TRXN-EFF-DT               PIC X(010).
               10  WS-TRXN-TYP-CD               PIC X(003).
                   88  WS-TRXN-TYP-SDP          VALUE 'SDP'.
                   88  WS-TRXN-TYP-DEP          VALUE 'DEP'.
                   88  WS-TRXN-TYP-IPD          VALUE 'IPD'.
                   88  WS-TRXN-TYP-IPT          VALUE 'IPT'.
                   88  WS-TRXN-TYP-SUR          VALUE 'SUR'.
                   88  WS-TRXN-TYP-PSR          VALUE 'PSR'.
                   88  WS-TRXN-TYP-AFR          VALUE 'AFR'.
                   88  WS-TRXN-TYP-ADM          VALUE 'ADM'.
                   88  WS-TRXN-TYP-CDM          VALUE 'CDM'.
                   88  WS-TRXN-TYP-AMF          VALUE 'AMF'.
                   88  WS-TRXN-TYP-AFO          VALUE 'AFO'.
                   88  WS-TRXN-TYP-TAF          VALUE 'TAF'.
                   88  WS-TRXN-TYP-MTH          VALUE 'MTH'.
                   88  WS-TRXN-TYP-LON          VALUE 'LON'.
                   88  WS-TRXN-TYP-RLN          VALUE 'RLN'.
                   88  WS-TRXN-TYP-CSW          VALUE 'CSW'.
                   88  WS-TRXN-TYP-FLT          VALUE 'FLT'.
                   88  WS-TRXN-TYP-INT          VALUE 'INT'.
                   88  WS-TRXN-TYP-TRF          VALUE 'TRF'.
                   88  WS-TRXN-TYP-SWP          VALUE 'SWP'.
                   88  WS-TRXN-TYP-ASR          VALUE 'ASR'.
                   88  WS-TRXN-TYP-DCA          VALUE 'DCA'.
                   88  WS-TRXN-TYP-MEX          VALUE 'MEX'.
                   88  WS-TRXN-TYP-PUP          VALUE 'PUP'.
023112             88  WS-TRXN-TYP-ROL          VALUE 'ROL'.
               10  WS-TRXN-STAT-CD              PIC X(001).
                   88  WS-TRXN-STAT-ACTIVE      VALUE 'A'.
               10  WS-TRXN-GRS-AMT              PIC S9(13)V99.
               10  WS-TRXN-NET-AMT              PIC S9(13)V99.
               10  WS-TRXN-CHRG-AMT             PIC S9(13)V99.
               10  WS-TRXN-INT-PCT              PIC S9(3)V9(4).
021239*        10  WS-TRXN-UNIT-QTY             PIC S9(8)V9(9).
021239         10  WS-TRXN-UNIT-QTY             PIC S9(12)V9(06).
               10  WS-TRXN-UNIT-PRC-AMT         PIC S9(8)V9(9).

           05  WS-UH-OUTPUT-DATA.
               10  WS-UH-TRXN-EFF-DT            PIC X(010).
               10  WS-UH-TRXN-TYP-CD            PIC X(003).
               10  WS-UH-TRXN-STAT-CD           PIC X(001).
               10  WS-UH-TRXN-GRS-AMT           PIC S9(13)V99.
               10  WS-UH-TRXN-NET-AMT           PIC S9(13)V99.
               10  WS-UH-TRXN-CHRG-AMT          PIC S9(13)V99.
               10  WS-UH-TRXN-INT-PCT           PIC S9(3)V9(4).
021239*        10  WS-UH-TRXN-UNIT-QTY          PIC S9(8)V9(9).
021239         10  WS-UH-TRXN-UNIT-QTY          PIC S9(12)V9(06).
               10  WS-UH-TRXN-UNIT-PRC-AMT      PIC S9(8)V9(9).

           05  WS-PHST-OUTPUT-DATA.
               10  WS-PHST-TRXN-EFF-DT          PIC X(010).
               10  WS-PHST-TRXN-TYP-CD          PIC X(003).
               10  WS-PHST-TRXN-STAT-CD         PIC X(001).
               10  WS-PHST-TRXN-GRS-AMT         PIC S9(13)V99.
               10  WS-PHST-TRXN-NET-AMT         PIC S9(13)V99.
               10  WS-PHST-TRXN-CHRG-AMT        PIC S9(13)V99.
               10  WS-PHST-TRXN-INT-PCT         PIC S9(3)V9(4).
021239*        10  WS-PHST-TRXN-UNIT-QTY        PIC S9(8)V9(9).
021239         10  WS-PHST-TRXN-UNIT-QTY        PIC S9(12)V9(06).
               10  WS-PHST-TRXN-UNIT-PRC-AMT    PIC S9(8)V9(9).

021239*    05  WS-INIT-WORK                     PIC S9(8)V9(9).
021239*    05  WS-ACUM-WORK                     PIC S9(8)V9(9).
           05  WS-TOTAL-DR                      PIC S9(13)V99.
           05  WS-TOTAL-CR                      PIC S9(13)V99.
           05  WS-CLI-TRXN-AMT                  PIC S9(13)V9(02).
           05  WS-FND-TRXN-AMT                  PIC S9(13)V9(02).
           05  WS-CHRG-AMT                      PIC S9(13)V9(02).
           05  WS-ACT-PHST-REC-IND              PIC X(001).
               88  WS-ACT-PHST-FOUND-NO         VALUE 'N'.
               88  WS-ACT-PHST-FOUND-YES        VALUE 'Y'.
           05  WS-ADM-REC-FOUND-IND             PIC X(001).
               88  WS-ADM-REC-FOUND-NO          VALUE 'N'.
               88  WS-ADM-REC-FOUND-YES         VALUE 'Y'.
           05  WS-UH-REC-IND                    PIC X(001).
               88  WS-UH-REC-FOUND-NO           VALUE 'N'.
               88  WS-UH-REC-FOUND-YES          VALUE 'Y'.
               88  WS-UH-REC-NO-MORE            VALUE 'E'.
           05  WS-CDSD-FOUND-IND                PIC X(001).
               88  WS-CDSD-FOUND-NO             VALUE 'N'.
               88  WS-CDSD-FOUND-YES            VALUE 'Y'.
           05  WS-PROCESS-END-IND               PIC X(001).
               88  WS-PROCESS-END-NO            VALUE 'N'.
               88  WS-PROCESS-END-YES           VALUE 'Y'.
           05  WS-ACTV-SOURCE-CD                PIC X(001).
               88  WS-ACTV-SOURCE-UH            VALUE 'U'.
               88  WS-ACTV-SOURCE-PHST          VALUE 'P'.

           05  WS-ACTIVITY-TYPE-ID              PIC X(4).
               88  WS-ACTIVITY-TYPE-VALID VALUE '4009' '4012' '4013'
                                                '5000' '5022'
                                                '4001' '4003'
                                                '4005' '5005' '5006'
                                                '4007' '4008' '4014'
                                                '5002' '5003' '5004'
                                                '4019' '5019' '5021'
                                                '4006' '4011' '4017'
                                                '4021' '5001' '5007'
020463*                                         '5009' '4018' '5009'.
033899*                                         '7029' '5008' '5010'
033899                                          '7029' '5008' '5011'
027315                                          '5100' '4022'
031036*                                         '7030' '4018'.
031036                                          '7030' '4018' '7061'
031036                                          '7062' '7063' '7064'.
               88  WS-ACTIVITY-TYPE-DEP   VALUE '4009' '4012' '4013'
031036*                                         '5000'.
031036                                          '5000' '7061' '7062'.
               88  WS-ACTIVITY-TYPE-WTH   VALUE '4001' '4003' '4005'
                                                '4022' '5005' '5006'
031036*                                         '5022'.
031036                                          '5022' '7063' '7064'.
               88  WS-ACTIVITY-TYPE-ADMIN VALUE '4007' '4008' '4014'
                                                '5002' '5003' '5004'
                                                '5100'.
               88  WS-ACTIVITY-TYPE-LOANS VALUE '4019' '5019'.
               88  WS-ACTIVITY-TYPE-TRXNS VALUE '4006' '4011' '4017'
                                                '4021' '5001' '5007'
033899*                                         '5010' '5021'.
033899                                          '5011' '5021'.
027315         88  WS-ACTIVITY-TYPE-INTR  VALUE '7029'.
020463*        88  WS-ACTIVITY-TYPE-AR    VALUE '5009'.
020463         88  WS-ACTIVITY-TYPE-AR    VALUE '7030'.
               88  WS-ACTIVITY-TYPE-DCA   VALUE '4018' '5008'.
               88  WS-ACTIVITY-TYPE-REVRS VALUE '4001' '4002' '4003'
                                                '4006' '4007' '4008'
                                                '4011' '4012' '4013'
                                                '4014' '4015' '4017'
                                                '4018' '5002' '5003'
                                                '5004' '5005' '5006'
033899*                                         '5007' '5010' '5100'
033899                                          '5007' '5011' '5100'
031036*                                         '5022'.
031036                                          '5022' '7061' '7062'
031036                                          '7063' '7064'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
026057 COPY CCWWIHSD.
       COPY XCWWWKDT.
       COPY CCWWINDX.
       COPY CCWWLOCK.
030054 COPY XCWWCNST.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
       COPY CCWWCVGS.
       COPY CCFWPOL.
       COPY CCFRPOL.
       COPY SCFWFA.
       COPY SCFRFA.
       COPY SCFWFD.
       COPY SCFRFD.
021239 COPY SCFRFDUT.
       COPY SCFWFS.
       COPY SCFRFS.
       COPY CCFWCFLW.
       COPY CCFRCFLW.
       COPY CCFWCDSA.
       COPY CCFRCDSA.
       COPY CCFWCDSD.
       COPY CCFRCDSD.
       COPY CCFWPHST.
       COPY CCFRPHST.
030054 COPY CCFHPHST.
       COPY CCFWLHST.
       COPY CCFRLHST.
       COPY CCFWUH.
       COPY CCFRUH.
       COPY CCFWUHCO.
       COPY CCFRUHCO.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
028298 COPY CCWL2626.
021239 COPY SCWL7791.
       COPY XCWLDTLK.
       COPY XCWL0280.
       COPY XCWL0290.
       COPY XCWL1640.
       COPY XCWL1660.
026057 COPY XCWL1670.
026057 COPY XCWL1680.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM7816.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FPCK-1000-CHECK-POLICY
028298         THRU FPCK-1000-CHECK-POLICY-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    INITIALIZE                   WS-WORK-AREA.
025970*    MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.
025970*    SET  MIR-RETRN-OK         TO TRUE.
025970*    MOVE SPACES               TO MIR-OUTPUT-AREA.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  2000-RETRIEVE
                        THRU 2000-RETRIEVE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7816'     TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'   TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'   TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *--------------
       2000-RETRIEVE.
      *--------------

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF MIR-RETRN-RQST-FAILED
              GO TO 2000-RETRIEVE-X
           END-IF.


           IF  NOT WS-CVG-TYP-SEG-FUND
           AND NOT WS-CVG-TYP-CASH-FLOW
      *MSG: COVERAGE IS NOT A FUND COVERAGE
               MOVE 'CS78160002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.


           IF  WS-CVG-TYP-SEG-FUND
           AND MIR-FND-ID = SPACE
      *MSG: MISSING FUND ID FOR SEG FUND COVERAGE
               MOVE 'CS78160003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2000-RETRIEVE-X
           END-IF.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           SET WS-WEALTH-ACCUM-NO       TO TRUE.
           SET WS-COLLATERAL-FUND-NO    TO TRUE.

           PERFORM  2010-INS-TYPE-CHECK
               THRU 2010-INS-TYPE-CHECK-X
               VARYING WS-SUB FROM 1 BY 1
               UNTIL WS-SUB > RPOL-POL-CVG-REC-CTR-N.

           IF WS-WEALTH-ACCUM-NO
      * MSG: FINANCIAL ACTIVITY IS NOT AVAILABLE FOR THIS TYPE OF POLICY
               MOVE 'CS78160004'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-RETRIEVE-X
           END-IF.

           MOVE  WS-SAVE-EFF-DT           TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE       TO WS-SAVE-EFF-IDT-NUM.

           PERFORM  3000-POL-ACTIVITY-LIST
               THRU 3000-POL-ACTIVITY-LIST-X.

       2000-RETRIEVE-X.
           EXIT.


      *--------------------
       2010-INS-TYPE-CHECK.
      *--------------------

           IF WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-SUB)
           OR WCVGS-CVG-INS-TYP-SEG-FUND    (WS-SUB)
           OR WCVGS-CVG-INS-TYP-FPA         (WS-SUB)
               SET WS-WEALTH-ACCUM-YES TO TRUE
           END-IF.

           IF WCVGS-CVG-COLFND (WS-SUB)
              SET WS-COLLATERAL-FUND-YES      TO TRUE
           END-IF.

       2010-INS-TYPE-CHECK-X.
           EXIT.

      *-------------------
       2100-VALIDATE-KEYS.
      *-------------------

           PERFORM  2110-EDIT-POL-ID
               THRU 2110-EDIT-POL-ID-X.

           PERFORM  2120-EDIT-CVG-NUM
               THRU 2120-EDIT-CVG-NUM-X.

           PERFORM  2130-EDIT-FND-ID
               THRU 2130-EDIT-FND-ID-X.

           PERFORM  2140-EDIT-START-DT
               THRU 2140-EDIT-START-DT-X.

           PERFORM  2150-EDIT-START-SEQ-NUM
               THRU 2150-EDIT-START-SEQ-NUM-X.

026057     IF  MIR-RETRN-RQST-FAILED
026057         GO TO 2100-VALIDATE-KEYS-X
026057     END-IF.
026057
026057* EDIT THE EFFECTIVE DATE AGAINST INVESTMENT HISTORY START DATE
026057
026057     MOVE WS-SAVE-EFF-DT     TO WIHSD-EFF-DT.
026057     PERFORM  IHSD-1000-CHK-IHSD-INQUIRY
026057         THRU IHSD-1000-CHK-IHSD-INQUIRY-X.
026057     IF  WIHSD-CHK-EFF-DT-NOT-OK
026057         SET MIR-RETRN-RQST-FAILED  TO TRUE
026057     END-IF.

       2100-VALIDATE-KEYS-X.
           EXIT.


      *-----------------
       2110-EDIT-POL-ID.
      *-----------------

           MOVE MIR-POL-ID          TO WPOL-POL-ID.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: (@2) RECORD (@1) NOT FOUND
               MOVE WPOL-KEY   TO WGLOB-MSG-PARM (1)
               MOVE 'POL'      TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000344'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
           ELSE
               MOVE MIR-POL-ID       TO WS-SAVE-POL-ID
           END-IF.

       2110-EDIT-POL-ID-X.
           EXIT.


      *-----------------
       2120-EDIT-CVG-NUM.
      *-----------------

           MOVE MIR-POL-ID          TO WCVG-POL-ID.
           MOVE MIR-CVG-NUM         TO WCVG-CVG-NUM.

           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X.

           IF  WCVG-IO-NOT-FOUND
      *MSG: (@2) RECORD (@1) NOT FOUND
               MOVE WCVG-KEY     TO WGLOB-MSG-PARM (1)
               MOVE 'CVG'        TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000344'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2120-EDIT-CVG-NUM-X
           ELSE
               MOVE MIR-CVG-NUM       TO WS-SAVE-CVG
           END-IF.

           MOVE SPACES                   TO WS-CVG-TYP-CD.

           EVALUATE TRUE

              WHEN RCVG-CVG-INS-TYP-SEG-FUND
                   SET WS-CVG-TYP-SEG-FUND  TO TRUE

              WHEN RCVG-CVG-INS-TYP-UL-INS-ANTY
              WHEN RCVG-CVG-INS-TYP-FPA
                   SET WS-CVG-TYP-CASH-FLOW TO TRUE

           END-EVALUATE.

       2120-EDIT-CVG-NUM-X.
           EXIT.


      *-----------------
       2130-EDIT-FND-ID.
      *-----------------

           IF MIR-FND-ID = SPACE
              GO TO 2130-EDIT-FND-ID-X
           END-IF.

           IF NOT WS-CVG-TYP-SEG-FUND
      *MSG: INVALID FUND (@1)
               MOVE MIR-FND-ID        TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000346'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2130-EDIT-FND-ID-X
           END-IF.

           MOVE MIR-POL-ID           TO  WFS-POL-ID.
           MOVE MIR-CVG-NUM          TO  WFS-CVG-NUM.
           MOVE MIR-FND-ID           TO  WFS-FND-ID.

           PERFORM  FS-1000-READ
               THRU FS-1000-READ-X.

           IF WFS-IO-NOT-FOUND
      *MSG: INVALID FUND (@1)
               MOVE MIR-FND-ID        TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000346'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
               GO TO 2130-EDIT-FND-ID-X
           END-IF.

           MOVE MIR-FND-ID          TO WS-SAVE-FND-ID.

       2130-EDIT-FND-ID-X.
           EXIT.


      *------------------
       2140-EDIT-START-DT.
      *------------------

021657*    MOVE MIR-DV-START-DT           TO L1640-EXTERNAL-DATE.
021657     MOVE MIR-DV-STRT-DT            TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF L1640-NOT-VALID
      *MSG: INVALID START DATE
               MOVE 'XS00000347'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
           ELSE
               MOVE L1640-INTERNAL-DATE
                                      TO WS-SAVE-EFF-DT
           END-IF.

       2140-EDIT-START-DT-X.
           EXIT.

      *-----------------------
       2150-EDIT-START-SEQ-NUM.
      *-----------------------

021657*    MOVE MIR-DV-START-SEQ-NUM      TO L0280-INPUT-DATA.
021657     MOVE MIR-DV-STRT-SEQ-NUM       TO L0280-INPUT-DATA.
021657*    MOVE LENGTH OF MIR-DV-START-SEQ-NUM TO L0280-INPUT-SIZE.
021657     MOVE LENGTH OF MIR-DV-STRT-SEQ-NUM  TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE          TO L0280-LENGTH.
           MOVE ZERO                      TO L0280-PRECISION.
           PERFORM 0280-1000-NUMERIC-EDIT
              THRU 0280-1000-NUMERIC-EDIT-X.

           IF NOT L0280-OK
      *MSG: INVALID START SEQUENCE NUMBER
               MOVE 'XS00000348'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET MIR-RETRN-RQST-FAILED TO TRUE
           ELSE
               MOVE L0280-OUTPUT          TO WS-SAVE-SEQ-NUM
           END-IF.

       2150-EDIT-START-SEQ-NUM-X.
           EXIT.

      /
      *-----------------------
       3000-POL-ACTIVITY-LIST.
      *-----------------------

      *
      * GET FIRST UH
      *
           MOVE WS-SAVE-EFF-DT          TO WS-SAVE-UH-EFF-DT.
           MOVE RPOL-POL-ISS-EFF-DT-DY  TO WS-SAVE-UH-EFF-DT-DY.

           IF  WS-SAVE-UH-EFF-DT > WS-SAVE-EFF-DT
               PERFORM  3110-SET-NEXT-UH-DATE
                   THRU 3110-SET-NEXT-UH-DATE-X
           END-IF.

           SET  WS-UH-REC-FOUND-NO      TO TRUE.
           PERFORM  3100-GET-NEXT-UH-REC
               THRU 3100-GET-NEXT-UH-REC-X
               UNTIL WS-UH-REC-FOUND-YES
               OR   WS-UH-REC-NO-MORE.

      *
      * GET FIRST PHST
      *
           MOVE RPOL-POL-ID         TO WPHST-POL-ID.
           MOVE WPHST-KEY           TO WPHST-ENDBR-KEY.
           MOVE WS-SAVE-EFF-IDT-NUM TO WPHST-PCHST-EFF-IDT-NUM.
           MOVE WS-SAVE-SEQ-NUM     TO WPHST-PCHST-SEQ-NUM.
           MOVE HIGH-VALUES         TO WPHST-ENDBR-PCHST-EFF-IDT-NUM.
030054*    MOVE +999                TO WPHST-ENDBR-PCHST-SEQ-NUM.
030054     MOVE WCNST-MAX-PCHST-SEQ-NUM-N
030054                              TO WPHST-ENDBR-PCHST-SEQ-NUM.

           PERFORM  PHST-1000-BROWSE
               THRU PHST-1000-BROWSE-X.

           SET WS-ACT-PHST-FOUND-NO TO TRUE.
           PERFORM  3300-READ-ACT-PHST
               THRU 3300-READ-ACT-PHST-X
               UNTIL WS-ACT-PHST-FOUND-YES
                  OR WPHST-IO-EOF.


           IF  WS-ACT-PHST-FOUND-NO
           AND WS-UH-REC-NO-MORE
      * MSG: NO FUND ACTIVITY TO DISPLAY
               MOVE 'CS78160001'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  PHST-3000-END-BROWSE
                   THRU PHST-3000-END-BROWSE-X
               GO TO 3000-POL-ACTIVITY-LIST-X
           END-IF.

           MOVE 1                  TO WS-SUB.
           SET WS-PROCESS-END-NO   TO TRUE.
           PERFORM  3500-ACTIVITY-LOOP
               THRU 3500-ACTIVITY-LOOP-X
               UNTIL  WS-SUB > WS-MAX-LINE
               OR     WS-PROCESS-END-YES.


           IF WS-PROCESS-END-YES
      * MSG: ** END OF LIST **
               MOVE 'XS00000015'      TO WGLOB-MSG-REF-INFO
           ELSE
      * MSG: INQUIRE COMPLETE - CONTINUE
               MOVE 'XS00000014'      TO WGLOB-MSG-REF-INFO
               SET WGLOB-MORE-DATA-EXISTS   TO TRUE

               PERFORM  3010-SET-MORE-KEY
                   THRU 3010-SET-MORE-KEY-X
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  PHST-3000-END-BROWSE
               THRU PHST-3000-END-BROWSE-X.

       3000-POL-ACTIVITY-LIST-X.
           EXIT.


      *-----------------
       3010-SET-MORE-KEY.
      *-----------------

030054*    IF  WS-SAVE-UH-EFF-DT NOT < WS-SAVE-PCHST-EFF-DT
030054     IF  WS-SAVE-UH-EFF-DT NOT < HPHST-PCHST-EFF-DT
               MOVE WS-SAVE-UH-EFF-DT     TO WS-SAVE-EFF-DT
               MOVE ZERO                  TO WS-SAVE-SEQ-NUM
           ELSE
030054*        MOVE WS-SAVE-PCHST-EFF-DT  TO WS-SAVE-EFF-DT
030054         MOVE HPHST-PCHST-EFF-DT    TO WS-SAVE-EFF-DT
030054*        MOVE WS-SAVE-PCHST-SEQ-NUM TO WS-SAVE-SEQ-NUM
030054         MOVE HPHST-PCHST-SEQ-NUM   TO WS-SAVE-SEQ-NUM
           END-IF.

           MOVE WS-SAVE-EFF-DT            TO  L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
021657*    MOVE L1640-EXTERNAL-DATE       TO  MIR-DV-START-DT.
021657     MOVE L1640-EXTERNAL-DATE       TO  MIR-DV-STRT-DT.

020874*    MOVE WS-SAVE-SEQ-NUM           TO L0290-INPUT-NUMBER.
           MOVE WS-SAVE-SEQ-NUM           TO L0290-INPUT-V00.
           MOVE 0                         TO L0290-PRECISION
021657*    MOVE LENGTH OF MIR-DV-START-SEQ-NUM
021657     MOVE LENGTH OF MIR-DV-STRT-SEQ-NUM
                                          TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS  TO TRUE.
           SET L0290-SIGN-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
021657*    MOVE L0290-OUTPUT-DATA         TO  MIR-DV-START-SEQ-NUM.
021657     MOVE L0290-OUTPUT-DATA         TO  MIR-DV-STRT-SEQ-NUM.

       3010-SET-MORE-KEY-X.
           EXIT.


      *---------------------
       3100-GET-NEXT-UH-REC.
      *---------------------

           INITIALIZE  WS-UH-OUTPUT-DATA.

           IF  WS-SAVE-UH-EFF-DT < RPOL-POL-ISS-EFF-DT
               SET WS-UH-REC-NO-MORE    TO TRUE
               MOVE SPACES              TO WS-SAVE-UH-EFF-DT
               GO TO 3100-GET-NEXT-UH-REC-X
           END-IF.

           MOVE WS-SAVE-POL-ID          TO WUH-POL-ID.
           MOVE WS-SAVE-UH-EFF-DT       TO WUH-MTHV-EFF-DT-NUM.
           MOVE ZERO                    TO WUH-MTHV-EFF-DT-NUM-DY.

           PERFORM  UH-1000-READ
               THRU UH-1000-READ-X.

           IF NOT WUH-IO-OK
              PERFORM  3110-SET-NEXT-UH-DATE
                  THRU 3110-SET-NEXT-UH-DATE-X
              GO TO 3100-GET-NEXT-UH-REC-X
           END-IF.

           MOVE RUH-KEY                 TO WUHCO-KEY.
           MOVE WS-SAVE-CVG             TO WUHCO-CVG-NUM.

           PERFORM  UHCO-1000-READ
               THRU UHCO-1000-READ-X.

           IF NOT WUHCO-IO-OK
              PERFORM  3110-SET-NEXT-UH-DATE
                  THRU 3110-SET-NEXT-UH-DATE-X
              GO TO 3100-GET-NEXT-UH-REC-X
           END-IF.

           PERFORM  3200-PROCESS-UH
               THRU 3200-PROCESS-UH-X.

           IF  WS-UH-REC-FOUND-NO
               PERFORM  3110-SET-NEXT-UH-DATE
                   THRU 3110-SET-NEXT-UH-DATE-X
               GO TO 3100-GET-NEXT-UH-REC-X
           END-IF.

       3100-GET-NEXT-UH-REC-X.
           EXIT.


      *---------------------
       3110-SET-NEXT-UH-DATE.
      *---------------------

           SUBTRACT 1            FROM WS-SAVE-UH-EFF-DT-MT.

           IF  WS-SAVE-UH-EFF-DT-MT = 0
               MOVE 12             TO WS-SAVE-UH-EFF-DT-MT
               SUBTRACT 1        FROM WS-SAVE-UH-EFF-DT-YR
           END-IF.

       3110-SET-NEXT-UH-DATE-X.
           EXIT.


      *----------------
       3200-PROCESS-UH.
      *----------------

           MOVE WS-SAVE-CVG                TO WS-CVG.

           EVALUATE TRUE

               WHEN WCVGS-CVG-INS-TYP-SEG-FUND (WS-CVG)
                    PERFORM  3210-MTH-DED-FA
                        THRU 3210-MTH-DED-FA-X

               WHEN WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-CVG)
               WHEN WCVGS-CVG-INS-TYP-FPA         (WS-CVG)
                    PERFORM  3250-MTH-DED-CFLW
                        THRU 3250-MTH-DED-CFLW-X

           END-EVALUATE.

       3200-PROCESS-UH-X.
           EXIT.


      *---------------
       3210-MTH-DED-FA.
      *---------------

           MOVE WS-SAVE-POL-ID           TO WFA-POL-ID.
           MOVE WS-SAVE-CVG              TO WFA-CVG-NUM.

           MOVE WS-SAVE-UH-EFF-DT        TO L1660-INTERNAL-DATE.
           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.
           MOVE L1660-INVERTED-DATE       TO WFA-CIA-IDT-NUM.

           MOVE WFA-KEY                  TO WFA-ENDBR-KEY.
           MOVE +000                     TO WFA-CIA-SEQ-NUM.
           MOVE +999                     TO WFA-ENDBR-CIA-SEQ-NUM.

           PERFORM  FA-1000-BROWSE
               THRU FA-1000-BROWSE-X.

           PERFORM  FA-2000-READ-NEXT
               THRU FA-2000-READ-NEXT-X.

           IF WFA-IO-EOF
              PERFORM  FA-3000-END-BROWSE
                  THRU FA-3000-END-BROWSE-X
              GO TO 3210-MTH-DED-FA-X
           END-IF.

           SET WS-ADM-REC-FOUND-NO       TO TRUE
           PERFORM  3220-MTH-DED-FA-LOOP
               THRU 3220-MTH-DED-FA-LOOP-X
              UNTIL WFA-IO-EOF
                 OR WS-ADM-REC-FOUND-YES.

           PERFORM  FA-3000-END-BROWSE
               THRU FA-3000-END-BROWSE-X.

           IF WS-ADM-REC-FOUND-NO
              GO TO 3210-MTH-DED-FA-X
           END-IF.

           MOVE RFA-POL-ID             TO WFD-POL-ID.
           MOVE RFA-CVG-NUM            TO WFD-CVG-NUM.
           MOVE WS-SAVE-FND-ID         TO WFD-FND-ID.
           MOVE RFA-CIA-IDT-NUM        TO WFD-FIA-IDT-NUM.
           MOVE RFA-CIA-SEQ-NUM        TO WFD-FIA-SEQ-NUM.

           PERFORM  FD-1000-READ
               THRU FD-1000-READ-X.

           IF NOT WFD-IO-OK
              GO TO 3210-MTH-DED-FA-X
           END-IF.

021239     PERFORM  7791-0000-INIT-PARM-INFO
021239         THRU 7791-0000-INIT-PARM-INFO-X.
021239
021239     MOVE RFD-KEY                TO RFDUT-KEY.
021239
021239     PERFORM  7791-1000-RETRIEVE-UNITS
021239         THRU 7791-1000-RETRIEVE-UNITS-X.
021239
021239     IF  NOT L7791-RETRN-OK
021239         GO TO 3210-MTH-DED-FA-X
021239     END-IF.
021239
           SET WS-ACTV-SOURCE-UH      TO TRUE.
           PERFORM  5100-FD-TO-OUTPUT
               THRU 5100-FD-TO-OUTPUT-X.

           MOVE  WS-OUTPUT-DATA       TO WS-UH-OUTPUT-DATA.
           SET   WS-UH-REC-FOUND-YES  TO TRUE.

       3210-MTH-DED-FA-X.
           EXIT.


      *--------------------
       3220-MTH-DED-FA-LOOP.
      *--------------------

           IF  RFA-CIA-TYP-ADMIN
           AND RFA-CIA-REASN-MORT-CHRG
               SET WS-ADM-REC-FOUND-YES  TO TRUE
               GO TO 3220-MTH-DED-FA-LOOP-X
           END-IF.

           PERFORM  FA-2000-READ-NEXT
               THRU FA-2000-READ-NEXT-X.

       3220-MTH-DED-FA-LOOP-X.
           EXIT.


      *------------------
       3250-MTH-DED-CFLW.
      *------------------

           MOVE WS-SAVE-POL-ID               TO WCFLW-POL-ID.
           MOVE WS-SAVE-CVG                  TO WCFLW-CVG-NUM.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG) TO WCFLW-CF-TYP-CD.
           MOVE WS-SAVE-UH-EFF-DT            TO WCFLW-CF-EFF-DT.
           MOVE WCFLW-KEY                    TO WCFLW-ENDBR-KEY.
           MOVE +000                         TO WCFLW-CF-SEQ-NUM.
           MOVE +999                         TO WCFLW-ENDBR-CF-SEQ-NUM.

           PERFORM  CFLW-1000-BROWSE
               THRU CFLW-1000-BROWSE-X.

           PERFORM  CFLW-2000-READ-NEXT
               THRU CFLW-2000-READ-NEXT-X.

           IF WCFLW-IO-EOF
              PERFORM  CFLW-3000-END-BROWSE
                  THRU CFLW-3000-END-BROWSE-X
              GO TO 3250-MTH-DED-CFLW-X
           END-IF.

           SET WS-ADM-REC-FOUND-NO       TO TRUE
           PERFORM  3260-MTH-DED-CFLW-LOOP
               THRU 3260-MTH-DED-CFLW-LOOP-X
              UNTIL WCFLW-IO-EOF
                 OR WS-ADM-REC-FOUND-YES.

           PERFORM  CFLW-3000-END-BROWSE
               THRU CFLW-3000-END-BROWSE-X.

           IF WS-ADM-REC-FOUND-NO
              GO TO 3250-MTH-DED-CFLW-X
           END-IF.

           SET WS-ACTV-SOURCE-UH      TO TRUE.
           PERFORM  5200-CFLW-TO-OUTPUT
               THRU 5200-CFLW-TO-OUTPUT-X.

           MOVE  WS-OUTPUT-DATA       TO WS-UH-OUTPUT-DATA.
           SET   WS-UH-REC-FOUND-YES  TO TRUE.

       3250-MTH-DED-CFLW-X.
           EXIT.


      *----------------------
       3260-MTH-DED-CFLW-LOOP.
      *----------------------

           IF (RCFLW-CF-TRXN-ADMIN-FEE
           OR  RCFLW-CF-TRXN-ADMIN-FEE-REVRS)
           AND RCFLW-CF-REASN-MORTALITY
               SET WS-ADM-REC-FOUND-YES   TO TRUE
               GO TO 3260-MTH-DED-CFLW-LOOP-X
           END-IF.

           PERFORM  CFLW-2000-READ-NEXT
               THRU CFLW-2000-READ-NEXT-X.

       3260-MTH-DED-CFLW-LOOP-X.
           EXIT.


      *-------------------
       3300-READ-ACT-PHST.
      *-------------------

           INITIALIZE  WS-PHST-OUTPUT-DATA.

           PERFORM  PHST-2000-READ-NEXT
               THRU PHST-2000-READ-NEXT-X.

           IF WPHST-IO-EOF
030054*       MOVE SPACES              TO WS-SAVE-PCHST-EFF-DT
030054        MOVE SPACES              TO HPHST-PCHST-EFF-DT
              GO TO 3300-READ-ACT-PHST-X
           END-IF.

           IF RPHST-PCHST-STAT-ACTIVE
           OR RPHST-PCHST-STAT-REVERSED
               CONTINUE
           ELSE
               GO TO 3300-READ-ACT-PHST-X
           END-IF.

           MOVE RPHST-POL-ACTV-TYP-ID TO WS-ACTIVITY-TYPE-ID.
           IF NOT WS-ACTIVITY-TYPE-VALID
               GO TO 3300-READ-ACT-PHST-X
           END-IF.

           IF  WS-ACTIVITY-TYPE-LOANS
           AND WS-COLLATERAL-FUND-NO
               GO TO 3300-READ-ACT-PHST-X
           END-IF.


           IF  WS-ACTIVITY-TYPE-AR
           OR (WS-ACTIVITY-TYPE-DCA
           AND RPHST-CVG-NUM NOT = WS-SAVE-CVG)
               PERFORM  3370-READ-AR-DCA
                   THRU 3370-READ-AR-DCA-X
               GO TO 3300-READ-ACT-PHST-X
           END-IF.

027315     IF  WS-ACTIVITY-TYPE-INTR
027315         PERFORM  3372-READ-INTR
027315             THRU 3372-READ-INTR-X
027315         GO TO 3300-READ-ACT-PHST-X
027315     END-IF.

           IF RPHST-CVG-NUM NOT = WS-SAVE-CVG
              GO TO 3300-READ-ACT-PHST-X
           END-IF.


           MOVE WS-SAVE-CVG                TO WS-CVG.

           IF  WS-ACTIVITY-TYPE-LOANS
               PERFORM  3310-READ-LHST
                   THRU 3310-READ-LHST-X
           END-IF.

           EVALUATE TRUE

               WHEN WCVGS-CVG-INS-TYP-SEG-FUND (WS-CVG)
                    PERFORM  3320-ACT-FA
                        THRU 3320-ACT-FA-X

               WHEN WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-CVG)
               WHEN WCVGS-CVG-INS-TYP-FPA         (WS-CVG)
                    PERFORM  3350-ACT-CFLW
                        THRU 3350-ACT-CFLW-X

           END-EVALUATE.

           IF  WS-ACT-PHST-FOUND-YES
030054*        MOVE RPHST-PCHST-SEQ-NUM     TO WS-SAVE-PCHST-SEQ-NUM
030054*        MOVE RPHST-PCHST-EFF-DT      TO WS-SAVE-PCHST-EFF-DT
030054*        MOVE RPHST-POL-ACTV-TYP-ID   TO WS-SAVE-POL-ACTV-TYP-ID
030054         MOVE RPHST-PCHST-SEQ-NUM     TO HPHST-PCHST-SEQ-NUM
030054         MOVE RPHST-PCHST-EFF-DT      TO HPHST-PCHST-EFF-DT
030054         MOVE RPHST-POL-ACTV-TYP-ID   TO HPHST-POL-ACTV-TYP-ID
           END-IF.

       3300-READ-ACT-PHST-X.
           EXIT.


      *---------------
       3310-READ-LHST.
      *---------------

           MOVE WS-SAVE-POL-ID     TO WLHST-POL-ID.
           MOVE 'C'                TO WLHST-POL-LOAN-ID.
           MOVE RPHST-PCHST-EFF-DT TO WLHST-POL-LOAN-EFF-DT.
           MOVE WLHST-KEY          TO WLHST-ENDBR-KEY.
           MOVE +000               TO WLHST-POL-LOAN-SEQ-NUM.
           MOVE +999               TO WLHST-ENDBR-POL-LOAN-SEQ-NUM.

           PERFORM  LHST-1000-BROWSE
               THRU LHST-1000-BROWSE-X.

           PERFORM  LHST-2000-READ-NEXT
               THRU LHST-2000-READ-NEXT-X.

           PERFORM  LHST-3000-END-BROWSE
               THRU LHST-3000-END-BROWSE-X.

       3310-READ-LHST-X.
           EXIT.

      *------------
       3320-ACT-FA.
      *------------

           MOVE WS-SAVE-POL-ID           TO WFA-POL-ID.
           MOVE WS-SAVE-CVG              TO WFA-CVG-NUM.
           MOVE RPHST-PCHST-EFF-IDT-NUM  TO WFA-CIA-IDT-NUM.

           IF  RPHST-PCHST-STAT-REVERSED
           AND WS-ACTIVITY-TYPE-REVRS
               MOVE RPHST-PCHST-OLD-VALU-TXT
                                         TO WS-SEQ
           ELSE
               MOVE RPHST-PCHST-NEW-VALU-TXT
                                         TO WS-SEQ
           END-IF.

           COMPUTE WS-FA-SEQ-NUM = 1000 - WS-SEQ-NUM.
           MOVE WS-FA-SEQ-NUM            TO WFA-CIA-SEQ-NUM.

           PERFORM  FA-1000-READ
               THRU FA-1000-READ-X.

           IF NOT WFA-IO-OK
               GO TO 3320-ACT-FA-X
           END-IF.

           MOVE RFA-POL-ID             TO WFD-POL-ID.
           MOVE RFA-CVG-NUM            TO WFD-CVG-NUM.
           MOVE WS-SAVE-FND-ID         TO WFD-FND-ID.
           MOVE RFA-CIA-IDT-NUM        TO WFD-FIA-IDT-NUM.
           MOVE RFA-CIA-SEQ-NUM        TO WFD-FIA-SEQ-NUM.

           PERFORM  FD-1000-READ
               THRU FD-1000-READ-X.

           IF NOT WFD-IO-OK
              GO TO 3320-ACT-FA-X
           END-IF.

021239     PERFORM  7791-0000-INIT-PARM-INFO
021239         THRU 7791-0000-INIT-PARM-INFO-X.
021239
021239     MOVE RFD-KEY                TO RFDUT-KEY.
021239
021239     PERFORM  7791-1000-RETRIEVE-UNITS
021239         THRU 7791-1000-RETRIEVE-UNITS-X.
021239
021239     IF  NOT L7791-RETRN-OK
021239         GO TO 3320-ACT-FA-X
021239     END-IF.
021239
           SET WS-ACTV-SOURCE-PHST      TO TRUE.
           PERFORM  5100-FD-TO-OUTPUT
               THRU 5100-FD-TO-OUTPUT-X

           MOVE  WS-OUTPUT-DATA         TO WS-PHST-OUTPUT-DATA.
           SET   WS-ACT-PHST-FOUND-YES  TO TRUE.

       3320-ACT-FA-X.
           EXIT.

      *
      *--------------
       3350-ACT-CFLW.
      *--------------

           MOVE WS-SAVE-POL-ID               TO WCFLW-POL-ID.
           MOVE WS-SAVE-CVG                  TO WCFLW-CVG-NUM.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG) TO WCFLW-CF-TYP-CD.
           MOVE RPHST-PCHST-EFF-DT           TO WCFLW-CF-EFF-DT.

           IF  RPHST-PCHST-STAT-REVERSED
           AND WS-ACTIVITY-TYPE-REVRS
               MOVE RPHST-PCHST-OLD-VALU-TXT
                                         TO WS-SEQ
           ELSE
               MOVE RPHST-PCHST-NEW-VALU-TXT
                                         TO WS-SEQ
           END-IF.

           MOVE WS-SEQ-NUM                   TO WCFLW-CF-SEQ-NUM-N.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

           IF NOT WCFLW-IO-OK
               GO TO 3350-ACT-CFLW-X
           END-IF.

           SET WS-ACTV-SOURCE-PHST      TO TRUE.
           PERFORM  5200-CFLW-TO-OUTPUT
               THRU 5200-CFLW-TO-OUTPUT-X.

           MOVE  WS-OUTPUT-DATA         TO WS-PHST-OUTPUT-DATA.
           SET   WS-ACT-PHST-FOUND-YES  TO TRUE.

       3350-ACT-CFLW-X.
           EXIT.


      *-----------------
       3370-READ-AR-DCA.
      *-----------------

           MOVE ZERO                    TO WS-SAVE-DEST-SEQ.

           IF  WS-ACTIVITY-TYPE-DCA
               SET  WCDSA-CDA-TYP-DCA         TO TRUE
           ELSE
               SET  WCDSA-CDA-TYP-ASSET-REBAL TO TRUE
           END-IF.

           MOVE WS-SAVE-POL-ID            TO WCDSA-POL-ID.
           MOVE RPHST-PCHST-OLD-VALU-TXT  TO WS-SEQ.
           COMPUTE WS-CDA-NUM = 100000 - WS-CDSA-NUM.
           MOVE WS-CDA-NUM                TO WCDSA-POL-PAYO-NUM.
           MOVE RPHST-PCHST-EFF-IDT-NUM   TO WCDSA-CDA-EFF-IDT-NUM.
026206*    MOVE +999                      TO WCDSA-CDA-SEQ-NUM.
026206     MOVE +0                        TO WCDSA-CDA-SEQ-NUM.

026206     MOVE WCDSA-KEY                 TO WCDSA-ENDBR-KEY.
026206     MOVE +999                      TO WCDSA-ENDBR-CDA-SEQ-NUM.

026206*    PERFORM  CDSA-1000-READ
026206*        THRU CDSA-1000-READ-X.

026206     PERFORM  CDSA-1000-BROWSE
026206         THRU CDSA-1000-BROWSE-X.

026206     PERFORM  CDSA-2000-READ-NEXT
026206         THRU CDSA-2000-READ-NEXT-X.

026206     PERFORM
026206         UNTIL  RCDSA-CDA-STAT-ACTIVE
026206            OR  NOT WCDSA-IO-OK
026206                PERFORM  CDSA-2000-READ-NEXT
026206                    THRU CDSA-2000-READ-NEXT-X
026206     END-PERFORM.
026206

           IF NOT WCDSA-IO-OK
026206        PERFORM  CDSA-3000-END-BROWSE
026206            THRU CDSA-3000-END-BROWSE-X
              GO TO 3370-READ-AR-DCA-X
           END-IF.

026206     PERFORM  CDSA-3000-END-BROWSE
026206         THRU CDSA-3000-END-BROWSE-X.

           MOVE RCDSA-KEY          TO WCDSD-KEY.
           MOVE ZEROES             TO WCDSD-CDAD-ALLOC-NUM.
           MOVE WCDSD-KEY          TO WCDSD-ENDBR-KEY.
           MOVE +999               TO WCDSD-ENDBR-CDAD-ALLOC-NUM.

           PERFORM  CDSD-1000-BROWSE
               THRU CDSD-1000-BROWSE-X.

           PERFORM  CDSD-2000-READ-NEXT
               THRU CDSD-2000-READ-NEXT-X.

           IF WCDSD-IO-EOF
              PERFORM  CDSD-3000-END-BROWSE
                  THRU CDSD-3000-END-BROWSE-X
              GO TO 3370-READ-AR-DCA-X
           END-IF.

           SET  WS-CDSD-FOUND-NO    TO TRUE
           PERFORM  3375-AR-DCA-LOOP
               THRU 3375-AR-DCA-LOOP-X
              UNTIL WCDSD-IO-EOF
                 OR WS-CDSD-FOUND-YES.

           PERFORM  CDSD-3000-END-BROWSE
               THRU CDSD-3000-END-BROWSE-X.

           IF WS-CDSD-FOUND-NO
              GO TO 3370-READ-AR-DCA-X
           END-IF.

           MOVE WS-SAVE-CVG                TO WS-CVG.

           EVALUATE TRUE

               WHEN WCVGS-CVG-INS-TYP-SEG-FUND (WS-CVG)
                    PERFORM  3380-DCA-AR-FA
                        THRU 3380-DCA-AR-FA-X

               WHEN WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-CVG)
               WHEN WCVGS-CVG-INS-TYP-FPA         (WS-CVG)
                    PERFORM  3390-DCA-AR-CFLW
                        THRU 3390-DCA-AR-CFLW-X

           END-EVALUATE.

           IF  WS-ACT-PHST-FOUND-YES
030054*        MOVE RPHST-PCHST-SEQ-NUM     TO WS-SAVE-PCHST-SEQ-NUM
030054*        MOVE RPHST-PCHST-EFF-DT      TO WS-SAVE-PCHST-EFF-DT
030054*        MOVE RPHST-POL-ACTV-TYP-ID   TO WS-SAVE-POL-ACTV-TYP-ID
030054         MOVE RPHST-PCHST-SEQ-NUM     TO HPHST-PCHST-SEQ-NUM
030054         MOVE RPHST-PCHST-EFF-DT      TO HPHST-PCHST-EFF-DT
030054         MOVE RPHST-POL-ACTV-TYP-ID   TO HPHST-POL-ACTV-TYP-ID
           END-IF.

       3370-READ-AR-DCA-X.
           EXIT.

027315*----------------
027315 3372-READ-INTR.
027315*----------------
027315
027315     MOVE ZERO                      TO WS-SAVE-DEST-SEQ.
027315
027315     MOVE WS-SAVE-POL-ID            TO WCDSA-POL-ID.
027315     SET  WCDSA-CDA-TYP-XFER        TO TRUE
027315
027315     MOVE +0                        TO WCDSA-POL-PAYO-NUM.
027315     MOVE RPHST-PCHST-EFF-IDT-NUM   TO WCDSA-CDA-EFF-IDT-NUM.
027315     MOVE RPHST-PCHST-OLD-VALU-TXT  TO WS-SEQ.
027315     COMPUTE WS-CDA-NUM = 1000 - WS-SEQ-NUM.
027315     MOVE WS-CDA-NUM                TO WCDSA-CDA-SEQ-NUM.
027315
027315     PERFORM  CDSA-1000-READ
027315         THRU CDSA-1000-READ-X.
027315
027315     IF NOT WCDSA-IO-OK
027315        GO TO 3372-READ-INTR-X
027315     END-IF.
027315
027315     MOVE RCDSA-KEY          TO WCDSD-KEY.
027315     MOVE ZEROES             TO WCDSD-CDAD-ALLOC-NUM.
027315     MOVE WCDSD-KEY          TO WCDSD-ENDBR-KEY.
027315     MOVE +999               TO WCDSD-ENDBR-CDAD-ALLOC-NUM.
027315
027315     PERFORM  CDSD-1000-BROWSE
027315         THRU CDSD-1000-BROWSE-X.
027315
027315     PERFORM  CDSD-2000-READ-NEXT
027315         THRU CDSD-2000-READ-NEXT-X.
027315
027315     IF WCDSD-IO-EOF
027315        PERFORM  CDSD-3000-END-BROWSE
027315            THRU CDSD-3000-END-BROWSE-X
027315        GO TO 3372-READ-INTR-X
027315     END-IF.
027315
027315     SET  WS-CDSD-FOUND-NO    TO TRUE
027315     PERFORM  3375-AR-DCA-LOOP
027315         THRU 3375-AR-DCA-LOOP-X
027315        UNTIL WCDSD-IO-EOF
027315           OR WS-CDSD-FOUND-YES.
027315
027315     PERFORM  CDSD-3000-END-BROWSE
027315         THRU CDSD-3000-END-BROWSE-X.
027315
027315     IF WS-CDSD-FOUND-NO
027315        GO TO 3372-READ-INTR-X
027315     END-IF.
027315
027315     MOVE WS-SAVE-CVG                TO WS-CVG.
027315
027315     EVALUATE TRUE
027315
027315         WHEN WCVGS-CVG-INS-TYP-SEG-FUND (WS-CVG)
027315              PERFORM  3380-DCA-AR-FA
027315                  THRU 3380-DCA-AR-FA-X
027315
027315         WHEN WCVGS-CVG-INS-TYP-UL-INS-ANTY (WS-CVG)
027315         WHEN WCVGS-CVG-INS-TYP-FPA         (WS-CVG)
027315              PERFORM  3390-DCA-AR-CFLW
027315                  THRU 3390-DCA-AR-CFLW-X
027315
027315     END-EVALUATE.
027315
027315     IF  WS-ACT-PHST-FOUND-YES
030054*        MOVE RPHST-PCHST-SEQ-NUM     TO WS-SAVE-PCHST-SEQ-NUM
030054*        MOVE RPHST-PCHST-EFF-DT      TO WS-SAVE-PCHST-EFF-DT
030054*        MOVE RPHST-POL-ACTV-TYP-ID   TO WS-SAVE-POL-ACTV-TYP-ID
030054         MOVE RPHST-PCHST-SEQ-NUM     TO HPHST-PCHST-SEQ-NUM
030054         MOVE RPHST-PCHST-EFF-DT      TO HPHST-PCHST-EFF-DT
030054         MOVE RPHST-POL-ACTV-TYP-ID   TO HPHST-POL-ACTV-TYP-ID
027315     END-IF.
027315
027315 3372-READ-INTR-X.
027315     EXIT.


      *----------------
       3375-AR-DCA-LOOP.
      *----------------

           IF  RCDSD-DEST-CVG-NUM-N = WS-SAVE-CVG
027315*        IF  WS-SAVE-FND-ID NOT = SPACE
027315*            IF  RCDSD-DEST-FND-ID = WS-SAVE-FND-ID
027315*                SET WS-CDSD-FOUND-YES     TO TRUE
027315*                MOVE RCDSD-DEST-SEQ-NUM-N TO WS-SAVE-DEST-SEQ
027315*                GO TO 3375-AR-DCA-LOOP-X
027315*            END-IF
027315*        ELSE
                   SET WS-CDSD-FOUND-YES     TO TRUE
                   MOVE RCDSD-DEST-SEQ-NUM-N TO WS-SAVE-DEST-SEQ
                   GO TO 3375-AR-DCA-LOOP-X
027315*        END-IF
           END-IF.

           PERFORM  CDSD-2000-READ-NEXT
               THRU CDSD-2000-READ-NEXT-X.

       3375-AR-DCA-LOOP-X.
           EXIT.

      *--------------
       3380-DCA-AR-FA.
      *--------------

           MOVE WS-SAVE-POL-ID           TO WFA-POL-ID.
           MOVE WS-SAVE-CVG              TO WFA-CVG-NUM.
           MOVE RPHST-PCHST-EFF-IDT-NUM  TO WFA-CIA-IDT-NUM.
           MOVE WS-SAVE-DEST-SEQ         TO WFA-CIA-SEQ-NUM.

           PERFORM  FA-1000-READ
               THRU FA-1000-READ-X.

           IF NOT WFA-IO-OK
               GO TO 3380-DCA-AR-FA-X
           END-IF.


           MOVE RFA-POL-ID             TO WFD-POL-ID.
           MOVE RFA-CVG-NUM            TO WFD-CVG-NUM.
           MOVE WS-SAVE-FND-ID         TO WFD-FND-ID.
           MOVE RFA-CIA-IDT-NUM        TO WFD-FIA-IDT-NUM.
           MOVE RFA-CIA-SEQ-NUM        TO WFD-FIA-SEQ-NUM.

           PERFORM  FD-1000-READ
               THRU FD-1000-READ-X.

           IF NOT WFD-IO-OK
              GO TO 3380-DCA-AR-FA-X
           END-IF.

021239     PERFORM  7791-0000-INIT-PARM-INFO
021239         THRU 7791-0000-INIT-PARM-INFO-X.
021239
021239     MOVE RFD-KEY                TO RFDUT-KEY.
021239
021239     PERFORM  7791-1000-RETRIEVE-UNITS
021239         THRU 7791-1000-RETRIEVE-UNITS-X.
021239
021239     IF  NOT L7791-RETRN-OK
021239         GO TO 3380-DCA-AR-FA-X
021239     END-IF.
021239
           SET WS-ACTV-SOURCE-PHST     TO TRUE.
           PERFORM  5100-FD-TO-OUTPUT
               THRU 5100-FD-TO-OUTPUT-X.

           MOVE  WS-OUTPUT-DATA         TO WS-PHST-OUTPUT-DATA.
           SET   WS-ACT-PHST-FOUND-YES  TO TRUE.

       3380-DCA-AR-FA-X.
           EXIT.
      *
      *-----------------
       3390-DCA-AR-CFLW.
      *-----------------

           MOVE WS-SAVE-POL-ID               TO WCFLW-POL-ID.
           MOVE WS-SAVE-CVG                  TO WCFLW-CVG-NUM.
           MOVE WCVGS-CVG-CF-TYP-CD (WS-CVG) TO WCFLW-CF-TYP-CD.
           MOVE RPHST-PCHST-EFF-DT           TO WCFLW-CF-EFF-DT.
           MOVE WS-SAVE-DEST-SEQ             TO WCFLW-CF-SEQ-NUM-N.

           PERFORM  CFLW-1000-READ
               THRU CFLW-1000-READ-X.

           IF NOT WCFLW-IO-OK
               GO TO 3390-DCA-AR-CFLW-X
           END-IF.

           SET WS-ACTV-SOURCE-PHST     TO TRUE.
           PERFORM  5200-CFLW-TO-OUTPUT
               THRU 5200-CFLW-TO-OUTPUT-X.

           MOVE  WS-OUTPUT-DATA         TO WS-PHST-OUTPUT-DATA.
           SET   WS-ACT-PHST-FOUND-YES  TO TRUE.

       3390-DCA-AR-CFLW-X.
           EXIT.

      *------------------
       3500-ACTIVITY-LOOP.
      *------------------

           EVALUATE TRUE

030054*        WHEN WS-SAVE-UH-EFF-DT NOT < WS-SAVE-PCHST-EFF-DT
030054         WHEN WS-SAVE-UH-EFF-DT NOT < HPHST-PCHST-EFF-DT
                    PERFORM  3510-PROCESS-UH-OUTPUT
                        THRU 3510-PROCESS-UH-OUTPUT-X

030054*        WHEN WS-SAVE-PCHST-EFF-DT > SPACE
030054         WHEN HPHST-PCHST-EFF-DT > SPACE
                    PERFORM  3520-PROCESS-PHST-OUTPUT
                        THRU 3520-PROCESS-PHST-OUTPUT-X

           END-EVALUATE.

           IF  WS-SAVE-UH-EFF-DT = SPACES
030054*    AND WS-SAVE-PCHST-EFF-DT = SPACES
030054     AND HPHST-PCHST-EFF-DT = SPACES
               SET WS-PROCESS-END-YES   TO TRUE
           END-IF.

       3500-ACTIVITY-LOOP-X.
           EXIT.


      *----------------------
       3510-PROCESS-UH-OUTPUT.
      *----------------------

           MOVE WS-UH-OUTPUT-DATA      TO WS-OUTPUT-DATA.
           PERFORM  5400-MOVE-TO-MIR
               THRU 5400-MOVE-TO-MIR-X.


           PERFORM  3110-SET-NEXT-UH-DATE
               THRU 3110-SET-NEXT-UH-DATE-X.

           IF  WS-SAVE-UH-EFF-DT < RPOL-POL-ISS-EFF-DT
               SET WS-UH-REC-NO-MORE    TO TRUE
               MOVE SPACES              TO WS-SAVE-UH-EFF-DT
               GO TO 3510-PROCESS-UH-OUTPUT-X
           END-IF.

           SET  WS-UH-REC-FOUND-NO      TO TRUE.
           PERFORM  3100-GET-NEXT-UH-REC
               THRU 3100-GET-NEXT-UH-REC-X
               UNTIL WS-UH-REC-FOUND-YES
               OR   WS-UH-REC-NO-MORE.

       3510-PROCESS-UH-OUTPUT-X.
           EXIT.


      *------------------------
       3520-PROCESS-PHST-OUTPUT.
      *------------------------

           MOVE WS-PHST-OUTPUT-DATA      TO WS-OUTPUT-DATA.
           PERFORM  5400-MOVE-TO-MIR
               THRU 5400-MOVE-TO-MIR-X.


           SET WS-ACT-PHST-FOUND-NO TO TRUE.
           PERFORM  3300-READ-ACT-PHST
               THRU 3300-READ-ACT-PHST-X
               UNTIL WS-ACT-PHST-FOUND-YES
                  OR WPHST-IO-EOF.

       3520-PROCESS-PHST-OUTPUT-X.
           EXIT.


      *-----------------
       5100-FD-TO-OUTPUT.
      *-----------------

           INITIALIZE        WS-OUTPUT-DATA.

021239*    COMPUTE WS-INIT-WORK =
021239*            RFD-FIA-INTG-IUNIT-QTY + RFD-FIA-DCML-IUNIT-QTY.
021239*    COMPUTE WS-ACUM-WORK =
021239*            RFD-FIA-INTG-AUNIT-QTY + RFD-FIA-DCML-AUNIT-QTY.
021239*    IF WS-ACUM-WORK NOT = ZERO
021239*        MOVE WS-ACUM-WORK          TO WS-TRXN-UNIT-QTY
021239*    ELSE
021239*        MOVE WS-INIT-WORK          TO WS-TRXN-UNIT-QTY
021239*    END-IF.
021239*
021239*    IF RFD-FIA-AUNIT-PRIC-AMT NOT = ZERO
021239*       MOVE RFD-FIA-AUNIT-PRIC-AMT TO WS-TRXN-UNIT-PRC-AMT
021239*    ELSE
021239*       MOVE RFD-FIA-IUNIT-PRIC-AMT TO WS-TRXN-UNIT-PRC-AMT
021239*    END-IF.
021239
021239     MOVE RFDUT-FIA-UNIT-QTY        TO WS-TRXN-UNIT-QTY.
021239     MOVE RFDUT-FIA-UNIT-PRIC-AMT   TO WS-TRXN-UNIT-PRC-AMT.
021239
           IF WS-ACTV-SOURCE-UH
              SET WS-TRXN-TYP-MTH       TO TRUE
              SET WS-TRXN-STAT-ACTIVE   TO TRUE
              MOVE WS-SAVE-UH-EFF-DT    TO WS-TRXN-EFF-DT
              MOVE RFD-FIA-FND-TRXN-AMT TO WS-TRXN-GRS-AMT
              GO TO 5100-FD-TO-OUTPUT-X
           ELSE
              PERFORM  5300-SET-TRXN-TYP
                  THRU 5300-SET-TRXN-TYP-X
           END-IF.


           COMPUTE WS-TRXN-GRS-AMT
                   = RFD-FIA-FND-TRXN-AMT + RFD-FIA-LOAD-AMT.

           MOVE RFD-FIA-FND-TRXN-AMT     TO WS-TRXN-NET-AMT.
           MOVE RFD-FIA-LOAD-AMT         TO WS-TRXN-CHRG-AMT.


           IF RFA-CIA-REVRS-PRCES-DT NOT = WWKDT-ZERO-DT
              MOVE ZERO                  TO WS-TRXN-NET-AMT
              MOVE ZERO                  TO WS-TRXN-CHRG-AMT
           END-IF.

       5100-FD-TO-OUTPUT-X.
           EXIT.

      *-------------------
       5200-CFLW-TO-OUTPUT.
      *-------------------

           INITIALIZE    WS-OUTPUT-DATA.

           IF WS-ACTV-SOURCE-UH
              SET WS-TRXN-TYP-MTH        TO TRUE
              SET WS-TRXN-STAT-ACTIVE    TO TRUE
              MOVE WS-SAVE-UH-EFF-DT     TO WS-TRXN-EFF-DT
              MOVE RCFLW-CF-FND-TRXN-AMT TO WS-TRXN-GRS-AMT
              GO TO 5200-CFLW-TO-OUTPUT-X
           ELSE
              PERFORM  5300-SET-TRXN-TYP
                  THRU 5300-SET-TRXN-TYP-X
           END-IF.

           MOVE RCFLW-CF-CLI-TRXN-AMT    TO WS-TRXN-GRS-AMT.
           MOVE RCFLW-CF-FND-TRXN-AMT    TO WS-TRXN-NET-AMT.
           MOVE RCFLW-CF-INT-PCT         TO WS-TRXN-INT-PCT.

           IF RCFLW-CF-TRXN-DEPOSIT
023478*    OR (RCFLW-CF-TRXN-INTRNL-XFER
023478*    AND RCFLW-CF-REASN-XFER-IN )
023478     OR (RCFLW-CF-TRXN-INTRNL-XFER
023478     AND (RCFLW-CF-REASN-XFER-IN
023478      OR  RCFLW-CF-REASN-STRT-BAL ))
              COMPUTE WS-TRXN-CHRG-AMT = WS-TRXN-GRS-AMT
                                       - WS-TRXN-NET-AMT
           ELSE
              COMPUTE WS-TRXN-CHRG-AMT = -1 * RCFLW-CF-SURR-CHRG-AMT
                                    + RCFLW-CF-MKTVAL-ADJ-AMT
           END-IF.

           IF RCFLW-CF-REVRS-PRCES-DT NOT = WWKDT-ZERO-DT
              COMPUTE WS-TRXN-GRS-AMT = -1 * WS-TRXN-GRS-AMT
              MOVE ZERO                  TO WS-TRXN-NET-AMT
              MOVE ZERO                  TO WS-TRXN-CHRG-AMT
           END-IF.


       5200-CFLW-TO-OUTPUT-X.
           EXIT.


      *------------------
       5300-SET-TRXN-TYP.
      *------------------

030054*    MOVE RPHST-POL-ACTV-TYP-ID   TO WS-SAVE-POL-ACTV-TYP-ID.
030054     MOVE RPHST-POL-ACTV-TYP-ID   TO HPHST-POL-ACTV-TYP-ID.

           EVALUATE TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4009'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5000'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4009'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5000'
031036         WHEN HPHST-POL-ACTV-TYP-ID = '7061'
031036         WHEN HPHST-POL-ACTV-TYP-ID = '7062'
                    IF WCVGS-PLAN-FND-TYP-SIDE (WS-CVG)
                       SET WS-TRXN-TYP-SDP    TO TRUE
                    ELSE
                       SET WS-TRXN-TYP-DEP    TO TRUE
                    END-IF

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4012'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4013'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4012'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4013'
                    SET WS-TRXN-TYP-IPD       TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4003'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4003'
                    SET WS-TRXN-TYP-IPT       TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4001'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5005'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4001'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5005'
031036         WHEN HPHST-POL-ACTV-TYP-ID = '7063'
031036         WHEN HPHST-POL-ACTV-TYP-ID = '7064'
                    SET WS-TRXN-TYP-SUR       TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4005'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5006'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4005'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5006'
                    SET WS-TRXN-TYP-PSR       TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4022'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5022'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4022'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5022'
                    SET WS-TRXN-TYP-AFR       TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4007'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4007'
                    SET WS-TRXN-TYP-ADM    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4008'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5004'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4008'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5004'
                    SET WS-TRXN-TYP-CDM    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5002'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5002'
                    SET WS-TRXN-TYP-AMF    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5003'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5003'
                    SET WS-TRXN-TYP-AFO    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4014'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4014'
                    SET WS-TRXN-TYP-TAF    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4019'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5019'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4019'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5019'
                    IF RLHST-POL-LOAN-TRXN-LOAN
                       SET WS-TRXN-TYP-LON TO TRUE
                    ELSE
                       IF RLHST-POL-LOAN-TRXN-REPAY-CSH
                       OR RLHST-POL-LOAN-TRXN-REPAY-TRMN
                       OR RLHST-POL-LOAN-TRXN-CNTRCT
                          SET WS-TRXN-TYP-RLN TO TRUE
                       END-IF
                    END-IF

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4011'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4011'
                    SET WS-TRXN-TYP-CSW    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4017'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5007'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4017'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5007'
                    SET WS-TRXN-TYP-FLT    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4021'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '7029'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4021'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '7029'
                    SET WS-TRXN-TYP-INT    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5021'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5001'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5021'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5001'
                    SET WS-TRXN-TYP-TRF    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4002'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4002'
023112              SET WS-TRXN-TYP-ROL    TO TRUE
023112
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4006'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4006'
                    SET WS-TRXN-TYP-SWP    TO TRUE

020463*       WHEN WS-SAVE-POL-ACTV-TYP-ID = '5009'
030054*       WHEN WS-SAVE-POL-ACTV-TYP-ID = '7030'
030054        WHEN HPHST-POL-ACTV-TYP-ID = '7030'
                    SET WS-TRXN-TYP-ASR    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '4018'
030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5008'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '4018'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5008'
                    SET WS-TRXN-TYP-DCA    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5010'
033899*        WHEN HPHST-POL-ACTV-TYP-ID = '5010'
033899         WHEN HPHST-POL-ACTV-TYP-ID = '5011'
                    SET WS-TRXN-TYP-MEX    TO TRUE

030054*        WHEN WS-SAVE-POL-ACTV-TYP-ID = '5100'
030054         WHEN HPHST-POL-ACTV-TYP-ID = '5100'
                    SET WS-TRXN-TYP-PUP    TO TRUE

           END-EVALUATE.


           MOVE RPHST-PCHST-STAT-CD     TO WS-TRXN-STAT-CD.
           MOVE RPHST-PCHST-EFF-DT      TO WS-TRXN-EFF-DT.

       5300-SET-TRXN-TYP-X.
           EXIT.


      *-----------------
       5400-MOVE-TO-MIR.
      *-----------------

           MOVE WS-TRXN-EFF-DT           TO L1640-INTERNAL-DATE.
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
                                 TO MIR-DV-FIN-TRXN-EFF-DT-T (WS-SUB).

           MOVE WS-TRXN-TYP-CD   TO MIR-DV-FIN-TRXN-TYP-CD-T (WS-SUB).
           MOVE WS-TRXN-STAT-CD  TO MIR-DV-FIN-TRXN-STAT-CD-T (WS-SUB).

020874*    COMPUTE L0290-INPUT-NUMBER = WS-TRXN-GRS-AMT * 100.
020874     MOVE WS-TRXN-GRS-AMT          TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-FIN-TRXN-GRS-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
                                TO MIR-DV-FIN-TRXN-GRS-AMT-T (WS-SUB).


020874*    COMPUTE L0290-INPUT-NUMBER = WS-TRXN-CHRG-AMT * 100.
020874     MOVE WS-TRXN-CHRG-AMT         TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-FIN-TRXN-CHRG-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
                               TO MIR-DV-FIN-TRXN-CHRG-AMT-T (WS-SUB).


020874*    COMPUTE L0290-INPUT-NUMBER = WS-TRXN-NET-AMT * 100.
020874     MOVE WS-TRXN-NET-AMT          TO L0290-INPUT-V02.
           MOVE 2                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-FIN-TRXN-NET-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-DISPLAY        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
                                TO MIR-DV-FIN-TRXN-NET-AMT-T (WS-SUB).


020874*    COMPUTE L0290-INPUT-NUMBER = WS-TRXN-INT-PCT * 10000.
020874     MOVE WS-TRXN-INT-PCT          TO L0290-INPUT-V04.
           MOVE 4                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CF-INT-PCT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA     TO MIR-CF-INT-PCT-T (WS-SUB).



020874*    COMPUTE L0290-INPUT-NUMBER = WS-TRXN-UNIT-QTY * 1000000000.
021239*    MOVE WS-TRXN-UNIT-QTY          TO L0290-INPUT-V09.
021239*    MOVE 9                         TO L0290-PRECISION.
021239     MOVE WS-TRXN-UNIT-QTY          TO L0290-INPUT-V06.
021239     MOVE +6                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-FIN-TRXN-UNIT-QTY-T (WS-SUB)
                                          TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS  TO TRUE.
           SET L0290-SIGN-SUPPRESS        TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
                               TO MIR-DV-FIN-TRXN-UNIT-QTY-T (WS-SUB).


020874*    COMPUTE L0290-INPUT-NUMBER
020874*                           = WS-TRXN-UNIT-PRC-AMT * 1000000000.
020874     MOVE WS-TRXN-UNIT-PRC-AMT     TO L0290-INPUT-V09.
           MOVE 9                        TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-UNIT-PRC-AMT-T (WS-SUB)
                                         TO L0290-MAX-OUT-LEN.
020874*    SET L0290-LEAD-ZEROS-SUPPRESS TO TRUE.
           SET L0290-SIGN-SUPPRESS       TO TRUE.
020874*    PERFORM  0290-1000-NUMERIC-FORMAT
020874*        THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA    TO MIR-DV-UNIT-PRC-AMT-T (WS-SUB).

           ADD +1                       TO WS-SUB.

       5400-MOVE-TO-MIR-X.
           EXIT.

      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY   TO TRUE.
           MOVE MIR-POL-ID         TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298
025970     PERFORM  7791-0000-INIT-PARM-INFO
025970         THRU 7791-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-WORK-AREA.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.

025970     MOVE SPACES               TO WWKDT-WORK-FIELDS.
025970     MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.
025970
025970     MOVE SPACES               TO MIR-OUTPUT-AREA.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFPCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

026057 COPY CCPPIHSD.
       COPY NCPPCVGS.
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
                               '$VAR2' BY 'POL'.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
025970 COPY XCPS1670.
025970 COPY XCPS8090.
021239 COPY SCPS7791.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
021239 COPY SCPL7791.

       COPY XCPL0260.
025970 COPY XCPS0280.
       COPY XCPL0280.
       COPY XCPL0290.
       COPY XCPS0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
026057 COPY XCPL1680.
       COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.
       COPY CCPNCVG.
       COPY CCPBCFLW.
       COPY CCPNCFLW.
       COPY SCPBFA.
       COPY SCPNFA.
       COPY SCPNFD.
       COPY SCPNFS.
026206 COPY CCPBCDSA.
       COPY CCPNCDSA.
       COPY CCPBCDSD.
       COPY CCPBPHST.
       COPY CCPBLHST.
       COPY CCPNUH.
       COPY CCPNUHCO.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      *****************************************************************
      **              END OF PROGRAM CSOM7816                        **
      *****************************************************************
