      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID.  CSOM6987.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM6987                                         **
      **  REMARKS:  POLI - POLICY INQUIRY SCREENS                    **
      **            THIS MODULE PERFORMS THE POLICY INQUIRY FUNCTION.**
      **            A SEPARATE FUNCTION DRIVER IS CALLED FOR EACH OF **
      **            THE AVAILABLE FUNCTION CODES.                    **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
013578**  6.0       NEW                                              **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014591**  6.2       COMBINE PLAN-ID & RS                             **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
017243**  6.4       REMOVE EXTRA FIELDS FROM POLICY INQUIRY          **
020462**  6.4       ISO DATE STANDARDIZATION                         **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023112**  6.5       CASH FLOW DESTINATION INSTRUCTIONS               **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM6987'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.
       COPY XCWWCVGM.

       01  WS-PGM-WORK-AREA.
016548*    05  WS-SUBD                      PIC S9(04)   COMP.
016548     05  WS-SUBD                      PIC S9(04)   BINARY.
           05  WS-FOUND-PRIMARY-SW          PIC X(01).
               88  WS-FOUND-PRIMARY               VALUE 'Y'.
               88  WS-NO-PRIMARY-EXISTS           VALUE 'N'.
016548*    05  WS-SUB                       PIC S9(04)   COMP.
016548     05  WS-SUB                       PIC S9(04)   BINARY.
           05  WS-DV-PRCES-DT               PIC X(10).

           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID             VALUE '6987'.
               88  WS-BUS-FCN-VALUSDP           VALUE '6987'.

           05  WS-ERROR-SW                  PIC X(01).
               88  WS-ERROR-FOUND           VALUE 'Y'.
               88  WS-NO-ERRORS-FOUND       VALUE 'N'.

           05  WS-CLIENT-FOUND-SW           PIC X(01).
               88  WS-CLIENT-FOUND          VALUE 'Y'.
               88  WS-NO-CLIENT-FOUND       VALUE 'N'.

      ************************************************************
      * COMMON WORKING STORAGE COPYBOOKS                         *
      ************************************************************
      *
       COPY CCWWINDX.
      *
      ************************************************************
      * FILE I/O WORKING STORAGE COPYBOOKS                       *
      ************************************************************
       COPY CCFWCVG.
       COPY CCFRCVG.
      *
       COPY CCFWPOL.
      *
      ************************************************************
      * LINKAGE WORKING STORAGE COPYBOOKS                        *
      ************************************************************
020478 COPY CCWL2626.
       COPY XCWL0290.
      *
       COPY CCWL0620.
      *
       COPY CCWL2430.
      *
       COPY CCWL5400.
      *
       COPY CCWL6987.
      *
       COPY XCWLDTLK.
016537*COPY XCWL0225.
       COPY XCWL0280.
       COPY XCWL1640.
      *
       COPY CCWLPGA.
       COPY CCFRPOL.
       COPY CCWWCVGS.
      *
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM6987.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514      
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM 0290-1000-BUILD-PARM-INFO
              THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      *---------------------
       2000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9500-SETUP-MSIN-REFERENCE
               THRU 9500-SETUP-MSIN-REFERENCE-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           SET WS-NO-ERRORS-FOUND      TO TRUE.

013578     MOVE MIR-BUS-FCN-ID         TO WS-BUS-FCN-ID.
013578     IF  NOT WS-BUS-FCN-VALID
013578         SET MIR-RETRN-INVALD-RQST
013578                                 TO TRUE
013578         GO TO 2000-PROCESS-REQUEST-X
013578     END-IF.
013578
           PERFORM  2200-INITIAL-EDITS
               THRU 2200-INITIAL-EDITS-X.

           IF  WS-ERROR-FOUND
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  2300-COMMON-LINE-SET
               THRU 2300-COMMON-LINE-SET-X.

           PERFORM  3000-DISPLAY-SCREEN
               THRU 3000-DISPLAY-SCREEN-X.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      *-------------------
       2200-INITIAL-EDITS.
      *-------------------

           MOVE MIR-POL-ID            TO WPOL-POL-ID.
           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-OK
               CONTINUE
           ELSE
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    POLICY RECORD NOT FOUND (@1)
               MOVE 'XS00000070'      TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-LENGTH.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE MIR-CVG-NUM           TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               IF L0280-OUTPUT > WCVGM-MAX-WCVGS-NUM
                   SET WS-ERROR-FOUND      TO TRUE
      *MSG:        COVERAGE MUST BE NUMERIC
                   MOVE 'XS00000079'  TO WGLOB-MSG-REF-INFO
                   MOVE MIR-CVG-NUM   TO WGLOB-MSG-PARM (1)
                   MOVE WCVGM-MAX-WCVGS-NUM
                                      TO  WGLOB-MSG-PARM (2)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           ELSE
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    COVERAGE MUST BE NUMERIC
               MOVE 'XS00000079'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-CVG-NUM        TO WGLOB-MSG-PARM (1)
               MOVE WCVGM-MAX-WCVGS-NUM
                                       TO  WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE MIR-DV-PRCES-DT        TO L1640-EXTERNAL-DATE.

020462*    PERFORM 1640-3000-EXTERNAL-TO-INT
020462*       THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-NOT-VALID
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    'DATE @1 INVALID'
               MOVE 'CS69870001'       TO WGLOB-MSG-REF-INFO
               MOVE MIR-DV-PRCES-DT    TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           MOVE L1640-INTERNAL-DATE    TO WS-DV-PRCES-DT.

           IF MIR-CF-EFF-DT > SPACES
               MOVE MIR-CF-EFF-DT      TO L1640-EXTERNAL-DATE
020462*        PERFORM 1640-3000-EXTERNAL-TO-INT
020462*           THRU 1640-3000-EXTERNAL-TO-INT-X
020462         PERFORM 1640-7000-MIR-TO-INT
020462            THRU 1640-7000-MIR-TO-INT-X
               IF  L1640-NOT-VALID
                   SET WS-ERROR-FOUND  TO TRUE
      *MSG:        'DEPOSIT DATE @1 INVALID'
                   MOVE 'CS69870002'   TO WGLOB-MSG-REF-INFO
                   MOVE MIR-CF-EFF-DT  TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF  MIR-CF-SEQ-NUM > SPACES
               MOVE 'N'                TO L0280-SIGN-IND
               MOVE 3                  TO L0280-LENGTH
               MOVE ZERO               TO L0280-PRECISION
               MOVE MIR-CF-SEQ-NUM     TO L0280-INPUT-DATA
               PERFORM  0280-1000-NUMERIC-EDIT
                   THRU 0280-1000-NUMERIC-EDIT-X
               IF  L0280-OK
020874*            MOVE L0280-OUTPUT   TO L0290-INPUT-NUMBER
020874             MOVE L0280-OUTPUT   TO L0290-INPUT-V00 
                   MOVE ZERO           TO L0290-PRECISION
                   MOVE LENGTH OF MIR-CF-SEQ-NUM TO L0290-MAX-OUT-LEN
020874*            PERFORM 0290-1000-NUMERIC-FORMAT
020874*               THRU 0290-1000-NUMERIC-FORMAT-X
020874            PERFORM  0290-2000-FORMAT-FOR-MIR
020874                THRU 0290-2000-FORMAT-FOR-MIR-X
                   MOVE L0290-OUTPUT-DATA TO MIR-CF-SEQ-NUM
               ELSE
                   SET WS-ERROR-FOUND  TO TRUE
      *MSG:        'SEQUENCE MUST BE NUMERIC'
                   MOVE 'CS69870003'   TO WGLOB-MSG-REF-INFO
                   MOVE MIR-CF-SEQ-NUM TO WGLOB-MSG-PARM (1)
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           IF  WS-ERROR-FOUND
               GO TO 2200-INITIAL-EDITS-X
           END-IF.

      *
      * PERFORM CONFIDENTIAL POLICY AND BRANCH LEVEL SECURITY CHECKS
      *
           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF L5400-CNFD-ACCS-RESTRICTED
           OR L5400-BRCH-ACCS-RESTRICTED
               SET WS-ERROR-FOUND      TO TRUE
               GO TO 2200-INITIAL-EDITS-X
           END-IF.

           PERFORM  2210-READ-ALL-CVG
               THRU 2210-READ-ALL-CVG-X
               VARYING WS-SUBD FROM 1 BY 1
               UNTIL   WS-SUBD > RPOL-POL-CVG-REC-CTR-N
               OR      WS-ERROR-FOUND.

       2200-INITIAL-EDITS-X.
           EXIT.
      *
      *------------------
       2210-READ-ALL-CVG.
      *------------------

           MOVE WPOL-POL-ID           TO WCVG-POL-ID.
           MOVE WS-SUBD               TO WCVG-CVG-NUM-N.

           PERFORM  CVG-1000-READ
               THRU CVG-1000-READ-X.

           IF  WCVG-IO-OK
               CONTINUE
           ELSE
               SET WS-ERROR-FOUND      TO TRUE
      *MSG:    'POLICY & COVERAGE (@1) OUT OF SYNC ...'
               MOVE 'XS00000084'       TO WGLOB-MSG-REF-INFO
               MOVE WCVG-CVG-NUM       TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2210-READ-ALL-CVG-X
           END-IF.

           MOVE RCVG-CVG-INFO          TO WCVGS-CVG-INFO (WS-SUBD).
           MOVE WS-SUBD                TO WCVGS-CVG-SEQ-NUM-N (WS-SUBD).

       2210-READ-ALL-CVG-X.
           EXIT.
      *
      *---------------------
       2300-COMMON-LINE-SET.
      *---------------------

           SET  WS-NO-CLIENT-FOUND TO TRUE.
      *
      * READ AND FORMAT OWNERS NAME
      *
           PERFORM  2320-GET-OWNER
               THRU 2320-GET-OWNER-X.

           INITIALIZE L0620-INPUT-PARM-INFO.
      *
           IF L2430-CLI-SEX-COMPANY
               MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
           ELSE
               MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
               MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
               MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
               MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
           END-IF.
      *
           MOVE L2430-CLI-SEX-CD      TO L0620-CLI-SEX-CD.
           PERFORM  0620-1000-FORMAT-SCREEN-NAME
               THRU 0620-1000-FORMAT-SCREEN-NAME-X.
           MOVE L0620-SCREEN-NAME     TO MIR-DV-OWN-CLI-NM.
           MOVE RPOL-POL-CSTAT-CD     TO MIR-POL-CSTAT-CD.
           MOVE RPOL-POL-CVG-REC-CTR  TO MIR-POL-CVG-REC-CTR.
           MOVE RPOL-SBSDRY-CO-ID     TO MIR-SBSDRY-CO-ID.

       2300-COMMON-LINE-SET-X.
           EXIT.
      *
      *---------------
       2320-GET-OWNER.
      *---------------

           MOVE +0                    TO I.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

       2320-GET-OWNER-X.
           EXIT.
      *
      *--------------------
       3000-DISPLAY-SCREEN.
      *--------------------

           PERFORM 3100-INITIALIZE-PARM-INFO
              THRU 3100-INITIALIZE-PARM-INFO-X.

           PERFORM 6987-1000-INQUIRE
              THRU 6987-1000-INQUIRE-X.

           PERFORM 3200-MOVE-INFO-TO-SCREEN
              THRU 3200-MOVE-INFO-TO-SCREEN-X.


       3000-DISPLAY-SCREEN-X.
           EXIT.
      *
      *--------------------------
       3100-INITIALIZE-PARM-INFO.
      *--------------------------
      *
           PERFORM  6987-1000-BUILD-PARM-INFO
               THRU 6987-1000-BUILD-PARM-INFO-X.
           MOVE MIR-CVG-NUM             TO L6987-CVG-NUM.
           MOVE MIR-CF-SEQ-NUM          TO L6987-SEQUENCE-NUM.
           MOVE MIR-CF-EFF-DT           TO L6987-DEPOSIT-DATE.
017243*    MOVE MIR-DV-PRCES-DT         TO L6987-SCREEN-DATE.
           MOVE WS-DV-PRCES-DT          TO L6987-EFF-DT.
           MOVE MIR-POL-ID              TO L6987-POLICY.
      *
       3100-INITIALIZE-PARM-INFO-X.
           EXIT.
      *
      *-------------------------
       3200-MOVE-INFO-TO-SCREEN.
      *-------------------------
      *
020874*    COMPUTE L0290-INPUT-NUMBER = L6987-ACVAL * 100.
020874     MOVE L6987-ACVAL                    TO L0290-INPUT-V02.
           MOVE 2                              TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-CF-DPOS-BAL-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY              TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-DV-CF-DPOS-BAL-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6987-SCHRG * 100.
020874     MOVE L6987-SCHRG                    TO L0290-INPUT-V02.
           MOVE 2                              TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-SURR-CHRG-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY              TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA              TO MIR-DV-SURR-CHRG-AMT.

013578     MOVE L6987-WO               TO MIR-CVG-WTHDR-ORDR-CD.
013578*    MOVE L6987-WO               TO MIR-DISP-WTHDR-ORDR-CD.

020874*    COMPUTE L0290-INPUT-NUMBER = L6987-LOANS * 100.
020874     MOVE L6987-LOANS                    TO L0290-INPUT-V02.
           MOVE 2                              TO L0290-PRECISION.
           MOVE LENGTH OF MIR-LOAN-AMT         TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY              TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA              TO MIR-LOAN-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6987-MKTAJ * 100.
020874     MOVE L6987-MKTAJ                    TO L0290-INPUT-V02.
           MOVE 2                              TO L0290-PRECISION.
           MOVE LENGTH OF MIR-CF-MKTVAL-ADJ-AMT TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY              TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA              TO MIR-CF-MKTVAL-ADJ-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6987-MTVAJ * 100.
020874     MOVE L6987-MTVAJ                    TO L0290-INPUT-V02.
           MOVE 2                              TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-MTHV-ADJ-AMT  TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY              TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA              TO MIR-DV-MTHV-ADJ-AMT.

020874*    COMPUTE L0290-INPUT-NUMBER = L6987-MXAVL * 100.
020874     MOVE L6987-MXAVL                    TO L0290-INPUT-V02.
           MOVE 2                              TO L0290-PRECISION.
           MOVE LENGTH OF MIR-DV-CF-DPOS-CSV-AMT  TO L0290-MAX-OUT-LEN.
           SET L0290-SIGN-DISPLAY              TO TRUE.
020874*    PERFORM 0290-1000-NUMERIC-FORMAT
020874*       THRU 0290-1000-NUMERIC-FORMAT-X.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA             TO MIR-DV-CF-DPOS-CSV-AMT.

014591*    MOVE L6987-PLNCD            TO MIR-PLAN-ID.
014591     MOVE L6987-PLAN-ID          TO MIR-PLAN-ID.



           PERFORM
               VARYING WS-SUB FROM 1 BY 1
               UNTIL   WS-SUB > 100
                  OR   L6987-CFSQ-T (WS-SUB) = SPACE

020874*        COMPUTE L0290-INPUT-NUMBER = L6987-CAMT-T(WS-SUB) * 100
020874         MOVE L6987-CAMT-T(WS-SUB)       TO L0290-INPUT-V02
               MOVE 2                          TO L0290-PRECISION
               MOVE LENGTH OF MIR-CF-CLI-TRXN-AMT-T (WS-SUB)
                                               TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY          TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA  TO MIR-CF-CLI-TRXN-AMT-T (WS-SUB)

               MOVE L6987-CFDT-T (WS-SUB)      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               IF  L1640-VALID
                   MOVE L1640-EXTERNAL-DATE  TO MIR-CF-EFF-DT-T (WS-SUB)
               ELSE
                   MOVE SPACE                TO MIR-CF-EFF-DT-T (WS-SUB)
               END-IF

               MOVE L6987-CFSQ-T (WS-SUB) TO MIR-CF-SEQ-NUM-T (WS-SUB)

020874*        COMPUTE L0290-INPUT-NUMBER = L6987-CNET-T(WS-SUB) * 100
020874         MOVE L6987-CNET-T(WS-SUB)       TO L0290-INPUT-V02
               MOVE 2                          TO L0290-PRECISION
               MOVE LENGTH OF MIR-CF-FND-TRXN-AMT-T (WS-SUB)
                                               TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY          TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA  TO MIR-CF-FND-TRXN-AMT-T (WS-SUB)

               MOVE L6987-CRSN-T (WS-SUB) TO MIR-CF-REASN-CD-T (WS-SUB)
               MOVE L6987-CSTA-T (WS-SUB) TO MIR-CF-STAT-CD-T (WS-SUB)
               MOVE L6987-CTYP-T (WS-SUB) TO MIR-CF-TRXN-CD-T (WS-SUB)

020874*        COMPUTE L0290-INPUT-NUMBER = L6987-FBAL-T(WS-SUB) * 100
020874         MOVE L6987-FBAL-T(WS-SUB)       TO L0290-INPUT-V02
               MOVE 2                          TO L0290-PRECISION
               MOVE LENGTH OF MIR-CF-FND-BAL-AMT-T (WS-SUB)
                                               TO L0290-MAX-OUT-LEN
               SET L0290-SIGN-DISPLAY          TO TRUE
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA   TO MIR-CF-FND-BAL-AMT-T (WS-SUB)

020874*        COMPUTE L0290-INPUT-NUMBER =  L6987-INRT-T (WS-SUB)
020874*                                    * 10000
020874         MOVE L6987-INRT-T (WS-SUB) TO L0290-INPUT-V04
               MOVE 4                     TO L0290-PRECISION
               MOVE LENGTH OF MIR-CF-INT-PCT-T (WS-SUB) TO
                                             L0290-MAX-OUT-LEN
020874*        PERFORM 0290-1000-NUMERIC-FORMAT
020874*           THRU 0290-1000-NUMERIC-FORMAT-X
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
               MOVE L0290-OUTPUT-DATA     TO MIR-CF-INT-PCT-T (WS-SUB)

               MOVE L6987-NXDT-T (WS-SUB)      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               IF  L1640-VALID
                   MOVE L1640-EXTERNAL-DATE  TO MIR-NXT-CF-DT-T (WS-SUB)
               ELSE
                   MOVE SPACE                TO MIR-NXT-CF-DT-T (WS-SUB)
               END-IF

               MOVE L6987-RLDT-T (WS-SUB)      TO L1640-INTERNAL-DATE
020462*        PERFORM 1640-2000-INTERNAL-TO-EXT
020462*           THRU 1640-2000-INTERNAL-TO-EXT-X
020462         PERFORM 1640-8000-INTERNAL-TO-MIR
020462            THRU 1640-8000-INTERNAL-TO-MIR-X
               IF  L1640-VALID
                   MOVE L1640-EXTERNAL-DATE
                                          TO MIR-ROLOVR-CF-DT-T (WS-SUB)
               ELSE
                   MOVE SPACE             TO MIR-ROLOVR-CF-DT-T (WS-SUB)
               END-IF

023112         MOVE L6987-ROLNUM-T (WS-SUB) TO L0290-INPUT-V00
023112         MOVE ZERO                    TO L0290-PRECISION
023112         MOVE LENGTH OF MIR-CF-ROLOVR-PAYO-NUM-T (WS-SUB)
023112                                      TO L0290-MAX-OUT-LEN
023112         PERFORM  0290-2000-FORMAT-FOR-MIR
023112             THRU 0290-2000-FORMAT-FOR-MIR-X
023112         MOVE L0290-OUTPUT-DATA       TO MIR-CF-ROLOVR-PAYO-NUM-T
023112                                        (WS-SUB)

           END-PERFORM.
      *
       3200-MOVE-INFO-TO-SCREEN-X.
           EXIT.
      *
      *--------------------------
       9500-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-POLICY      TO TRUE.
           MOVE MIR-POL-ID            TO WGLOB-REF-POLICY-ID.
           MOVE MIR-CVG-NUM           TO WGLOB-REF-COVERAGE-NUMBER.

       9500-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  6987-0000-INIT-PARM-INFO
025970         THRU 6987-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      *****************************************************************
      *  PROCESSING COPYBOOKS
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
020478 COPY CCPPFPCK.
       COPY XCPPINIT.
      *
       COPY XCPPEXIT.
      *
      *****************************************************************
      *  LINKAGE COPYBOOKS
      *****************************************************************
      *
       COPY CCPSPGA.
      *
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY CCPS0620.
       COPY CCPL0620.
      *
       COPY XCPS0290.
       COPY XCPL0290.
      *
       COPY CCPS2430.
018764*COPY CCCL2430.
018764 COPY CCPL2430.
      *
       COPY CCPS5400.
018764*COPY CCCL5400.
018764 COPY CCPL5400.
      *
       COPY CCPS6987.
018764*COPY CCCL6987.
018764 COPY CCPL6987.
      *
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      *
016537*COPY XCCL0225.
      *
025970 COPY XCPS0280.
       COPY XCPL0280.
      *
025970 COPY XCPS1640.
       COPY XCPL1640.
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY CCPNCVG.
      *
       COPY CCPNPOL.
      *
      *****************************************************************
      *  ERROR PROCESSING COPYPBOOKS
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
      *
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM CSOM6987                     **
      *****************************************************************


