      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM7762.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM7762                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE UPDATE FUNCTION         **
      **            FOR THE FUTP TABLE                               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
021239**  6.4       FUND UNIT VALUE                                  **
023309**  6.5       LOCK CONTENTION ON FH TABLE                      **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM7762'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-UPDATE         VALUE '7762'.
           05  WS-FND-UNIT-QTY               PIC S9(12)V9(06) COMP-3.
           05  WS-FND-UNIT-END-DT            PIC X(10).
023309     05  WS-FND-PREV-VALN-DT           PIC X(10).

       01  WS-CONSTANT-AREA.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970*                                      VALUE '7762'.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '7762'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWWWKDT.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY SCFWFH.
       COPY SCFRFH.

023309 COPY SCFWFDUP.
023309 COPY SCFRFDUT.
023309
       COPY SCFWFUTP.
       COPY SCFRFUTP.

       COPY CCFWEDIT.
       COPY CCFREDIT.

       COPY CCWWLOCK.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
       COPY XCWLDTLK.
       COPY XCWL1640.
       COPY XCWL8090.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM7762.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE WPGWS-CRNT-PGM-ID
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *-------------
       2000-UPDATE.
      *-------------

           PERFORM  2100-VALIDATE-DATA
               THRU 2100-VALIDATE-DATA-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               IF  NOT MIR-RETRN-TS-MISMATCH
                   PERFORM  FH-3000-UNLOCK
                       THRU FH-3000-UNLOCK-X
               END-IF
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  FUTP-1000-READ-FOR-UPDATE
               THRU FUTP-1000-READ-FOR-UPDATE-X.

           IF  NOT WFUTP-IO-OK
      *MSG: @2 RECORD (@1) NOT FOUND
               MOVE WFUTP-KEY               TO WGLOB-MSG-PARM (1)
               MOVE 'FUTP'                  TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000001'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  FH-3000-UNLOCK
                   THRU FH-3000-UNLOCK-X
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  9350-SETUP-AUDIT-INFO
               THRU 9350-SETUP-AUDIT-INFO-X.

           MOVE WS-FND-UNIT-QTY             TO RFUTP-FND-UNIT-QTY.
           MOVE WS-FND-UNIT-END-DT          TO RFUTP-FND-UNIT-END-DT.

           PERFORM  FUTP-2000-REWRITE
               THRU FUTP-2000-REWRITE-X.

           PERFORM  9350-SETUP-AUDIT-INFO
               THRU 9350-SETUP-AUDIT-INFO-X.

           PERFORM  FH-2000-REWRITE
               THRU FH-2000-REWRITE-X.

           PERFORM  FH-1000-READ-TWRK-TS
               THRU FH-1000-READ-TWRK-TS-X.

       2000-UPDATE-X.
           EXIT.

      *----------------------------
       2100-VALIDATE-DATA.
      *----------------------------

           PERFORM  2110-EDIT-FND-ID
               THRU 2110-EDIT-FND-ID-X.

           PERFORM  2120-EDIT-FND-UNIT-TYP-CD
               THRU 2120-EDIT-FND-UNIT-TYP-CD-X.

           PERFORM  2150-EDIT-FND-UNIT-END-DT
               THRU 2150-EDIT-FND-UNIT-END-DT-X.

       2100-VALIDATE-DATA-X.
           EXIT.

      *----------------------------
       2110-EDIT-FND-ID.
      *----------------------------

           MOVE MIR-FND-ID                  TO WFH-FND-ID.

           PERFORM  FH-2000-UPDATE-TWRK-TS
               THRU FH-2000-UPDATE-TWRK-TS-X.

           IF  WFH-IO-NOT-FOUND
      *MSG: @2 RECORD (@1) NOT FOUND
               MOVE WFH-KEY                 TO WGLOB-MSG-PARM (1)
               MOVE 'FH'                    TO WGLOB-MSG-PARM (2)
               MOVE 'XS00000001'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG: PROCESS FAILED - RE-ENTER DATA AS ANOTHER PROCESS HAS
      *     UPDATED - TABLE (@1), KEY @2
               MOVE 'XS00000303'            TO WGLOB-MSG-REF-INFO
               MOVE 'FH'                    TO WGLOB-MSG-PARM (1)
               MOVE WFH-KEY                 TO WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2110-EDIT-FND-ID-X.
           EXIT.

      *----------------------------
       2120-EDIT-FND-UNIT-TYP-CD.
      *----------------------------

           MOVE MIR-FND-UNIT-TYP-CD         TO WEDIT-ETBL-VALU-ID.

           PERFORM  UVTP-1000-EDIT
               THRU UVTP-1000-EDIT-X.

           IF  NOT WEDIT-IO-OK
      *MSG: UNIT TYPE MUST BE VALID
               MOVE 'SS77620001'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2120-EDIT-FND-UNIT-TYP-CD-X.
           EXIT.

      *----------------------------
       2150-EDIT-FND-UNIT-END-DT.
      *----------------------------

           IF  MIR-FND-UNIT-END-DT = SPACE
               MOVE WWKDT-ZERO-DT     TO WS-FND-UNIT-END-DT
               GO TO 2150-EDIT-FND-UNIT-END-DT-X
           END-IF.

           MOVE MIR-FND-UNIT-END-DT   TO L1640-EXTERNAL-DATE.
           PERFORM 1640-7000-MIR-TO-INT
              THRU 1640-7000-MIR-TO-INT-X.

           IF  L1640-VALID
               MOVE L1640-EXTERNAL-DATE
                                      TO MIR-FND-UNIT-END-DT
               MOVE L1640-INTERNAL-DATE
                                      TO WS-FND-UNIT-END-DT
           ELSE
      *MSG: RELATION END DATE MUST BE A VALID DATE AND FORMAT
               MOVE 'SS77620003'            TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2150-EDIT-FND-UNIT-END-DT-X
           END-IF.

023309     PERFORM  2151-FND-PREV-VALN-DT
023309         THRU 2151-FND-PREV-VALN-DT-X.
023309
023309*    IF  RFH-FND-PREV-VALN-DT NOT = WWKDT-ZERO-DT
023309*    AND WS-FND-UNIT-END-DT < RFH-FND-PREV-VALN-DT
023309     IF  WS-FND-PREV-VALN-DT NOT = WWKDT-ZERO-DT
023309     AND WS-FND-UNIT-END-DT < WS-FND-PREV-VALN-DT
      *MSG: FUND IS ACTIVE ON @1
               MOVE 'SS77620004'            TO WGLOB-MSG-REF-INFO
               MOVE WS-FND-UNIT-END-DT      TO L1640-INTERNAL-DATE
               PERFORM  1640-8000-INTERNAL-TO-MIR
                   THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE     TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2150-EDIT-FND-UNIT-END-DT-X.
           EXIT.

023309*----------------------------
023309 2151-FND-PREV-VALN-DT.
023309*----------------------------
023309
023309     MOVE LOW-VALUES               TO WFDUP-KEY.
023309     MOVE MIR-FND-ID               TO WFDUP-FND-ID.
023309     MOVE WWKDT-LOW-DT             TO WFDUP-FIA-UNIT-PRIC-DT.
023309
023309     MOVE WFDUP-KEY            TO WFDUP-ENDBR-KEY.
023309     MOVE WWKDT-HIGH-DT        TO WFDUP-ENDBR-FIA-UNIT-PRIC-DT.
023309
023309     PERFORM  FDUP-2000-READ-MAX
023309         THRU FDUP-2000-READ-MAX-X.
023309
023309     IF  WFDUP-IO-OK
023309         MOVE WFDUP-MAX-FIA-UNIT-PRIC-DT TO WS-FND-PREV-VALN-DT
023309     ELSE
023309         MOVE WWKDT-ZERO-DT              TO WS-FND-PREV-VALN-DT
023309     END-IF.
023309
023309 2151-FND-PREV-VALN-DT-X.
023309     EXIT.
023309

      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE MIR-FND-ID             TO WFUTP-FND-ID.
           MOVE MIR-FND-UNIT-TYP-CD    TO WFUTP-FND-UNIT-TYP-CD.

       7000-BUILD-KEYS-X.
           EXIT.
      /
      *-----------------
       9000-BLANK-DATA-FIELDS.
      *-----------------

           MOVE SPACE                       TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                     TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE         TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      *----------------------
       9350-SETUP-AUDIT-INFO.
      *----------------------

           IF  WGLOB-AUDIT-REQUESTED
               PERFORM  FUTP-1000-CALL-AUDIT
                   THRU FUTP-1000-CALL-AUDIT-X
           END-IF.

       9350-SETUP-AUDIT-INFO-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     MOVE SPACE                       TO WWKDT-WORK-FIELDS.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

025970     SET WS-TWRK-KEY-DEFAULT     TO TRUE.
025970
       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPEXIT.
       COPY XCPPINIT.
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  FH
                                '$VAR2'   BY 'FH'.
       COPY CCPEUVTP.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
025970 COPY XCPS8090.
025970 COPY XCPS1640.
       COPY XCPL1640.

       COPY XCPL8090.

       COPY SCPLFUTP.

      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY SCPNFH.
       COPY SCPUFH.

       COPY SCPUFUTP.

023309 COPY SCPFFDUP.
023309
       COPY CCPNEDIT.

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM SSOM7762                        **
      *****************************************************************
