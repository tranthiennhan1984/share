      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM3110.

       COPY XCWWCRHT.

      ****************************************************************
      **  MEMBER :  NSOM3110
      **  REMARKS:  PROCESS DRIVER FOR RQTB TRANSACTION
      **
      **  DOMAIN :  PR
      ****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
010303**  5.6       INITIAL CREATION                                 **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
014221**  6.2       LOGICAL LOCKING                                  **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
015788**  6.3       THE OCCURRENCES INCREASED FROM 13 TO 100         **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
017087**  6.4       CHANGE FIELD NAMES FROM GRP TO GR ABBREVIATION   **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.

       CONFIGURATION SECTION.
      *
       DATA DIVISION.

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM3110'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.

014590*COPY XCWL0030.

       01  WS-WORKING-STORAGE.
016548*    05  WSSUB                     PIC S9(4)  VALUE ZERO COMP.
016548     05  WSSUB                     PIC S9(4)  VALUE ZERO BINARY.
016548*    05  I                         PIC S9(4)  VALUE ZERO COMP.
016548     05  I                         PIC S9(4)  VALUE ZERO BINARY.
016548*    05  WS-MAX-BROWSE-LINES       PIC S9(4)  VALUE +13  COMP.
015788*    05  WS-MAX-BROWSE-LINES       PIC S9(4)  VALUE +13  BINARY.
025970*    05  WS-MAX-BROWSE-LINES       PIC S9(4)  VALUE +100  BINARY.
025970*    05  WS-EDITS                  PIC X(01)  VALUE '0'.
025970     05  WS-EDITS                  PIC X(01).
025970         88  WS-DEFAULT-EDITS-SW              VALUE '0'.
               88  WS-EDIT-ERROR                    VALUE '1'.
               88  WS-EDIT-OK                       VALUE '0'.
           05  WS-SEQ-NUM                PIC X(03).
           05  WS-SEQ-NUM-N              REDEFINES
               WS-SEQ-NUM                PIC 9(03).
           05  WS-BUS-FCN-ID             PIC X(04)  VALUE SPACE.
               88  WS-BUS-FCN-ID-VALID              VALUES ARE
                   '1640', '1641', '1642', '1643', '1644'.
               88  WS-BUS-FCN-RETRIEVE              VALUE '1640'.
               88  WS-BUS-FCN-CREATE                VALUE '1641'.
               88  WS-BUS-FCN-UPDATE                VALUE '1642'.
               88  WS-BUS-FCN-DELETE                VALUE '1643'.
               88  WS-BUS-FCN-LIST                  VALUE '1644'.
025970*    05  WS-TWRK-KEY               PIC X(04)  VALUE '1640'.
           05  WS-REQ-TYP-CD-CHECK       PIC X(05)  VALUE SPACES.
               88  WS-REQ-TYP-CD-VALID              VALUES ARE
                   'EREPL', 'IREPL', 'ISSRQ'.
025970*
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY               PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY             VALUE '1640'.
025970     05  WS-MAX-BROWSE-LINES       PIC S9(4) BINARY.
025970         88  WS-DEFAULT-MAX-BR-LINES         VALUE +100.
      *
      ***************************************************************
      * WORK AREA
      ***************************************************************
       COPY NCFREVRQ.
       COPY NCFWEVRQ.
       COPY CCFREDIT.
       COPY CCFWEDIT.
       COPY NCFRRTAB.
       COPY NCFWRTAB.
014221 COPY CCWWLOCK.
014221 COPY XCWL8090.
020874 COPY XCWL0290.
016537*COPY CCFRLGAS.
016537*COPY CCFWLGAS.
016537*COPY CCWZLGAS.
      *
      ****************
       LINKAGE SECTION.
      ****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY NCWM3110.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      *
      ***************************
       2000-PROCESS-REQUEST.
      ***************************

020874     PERFORM  0290-1000-BUILD-PARM-INFO
020874         THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

025970*    MOVE MIR-BUS-FCN-ID        TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-RETRIEVE
                    PERFORM  3000-PROCESS-RETRIEVE
                        THRU 3000-PROCESS-RETRIEVE-X

               WHEN WS-BUS-FCN-LIST
                    PERFORM  4000-PROCESS-LIST
                        THRU 4000-PROCESS-LIST-X

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  5000-PROCESS-CREATE
                        THRU 5000-PROCESS-CREATE-X

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  5500-PROCESS-UPDATE
                        THRU 5500-PROCESS-UPDATE-X

               WHEN WS-BUS-FCN-DELETE
                    PERFORM  6000-PROCESS-DELETE
                        THRU 6000-PROCESS-DELETE-X

           END-EVALUATE.

       2000-PROCESS-REQUEST-X.
           EXIT.
      *
      **************
       3000-PROCESS-RETRIEVE.
      **************

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  8500-EDIT-EVRQ-KEY-FIELDS
               THRU 8500-EDIT-EVRQ-KEY-FIELDS-X.
           IF WS-EDIT-ERROR
               GO TO  3000-PROCESS-RETRIEVE-X
           END-IF.

           PERFORM  3100-BUILD-EVRQ-READ-KEY
               THRU 3100-BUILD-EVRQ-READ-KEY-X.

014221*    PERFORM  EVRQ-1000-READ
014221*        THRU EVRQ-1000-READ-X.

014221     PERFORM  EVRQ-1000-READ-TWRK-TS
014221         THRU EVRQ-1000-READ-TWRK-TS-X.

           IF WEVRQ-IO-NOT-FOUND
      *MSG:   'NO RECORDS FOUND TO DISPLAY'
              MOVE 'XS00000034'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

           MOVE REVRQ-REQIR-ID        TO MIR-REQIR-ID.

      *MSG:'INQUIRE COMPLETE'
           MOVE 'XS00000002'          TO WGLOB-MSG-REF-INFO
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      *
      **************************
       3100-BUILD-EVRQ-READ-KEY.
      **************************

           MOVE MIR-EVNT-REQIR-TYP-CD TO WEVRQ-EVNT-REQIR-TYP-CD.
017087*    MOVE MIR-LOC-GRP-ID        TO WEVRQ-LOC-GRP-ID.
017087     MOVE MIR-LOC-GR-ID         TO WEVRQ-LOC-GR-ID.
           MOVE MIR-BUS-CLAS-CD       TO WEVRQ-BUS-CLAS-CD.
           MOVE MIR-EVNT-REQIR-SEQ-NUM                    TO WS-SEQ-NUM.
           MOVE WS-SEQ-NUM-N          TO WEVRQ-EVNT-REQIR-SEQ-NUM.

       3100-BUILD-EVRQ-READ-KEY-X.
           EXIT.
      *
      *************
       4000-PROCESS-LIST.
      *************

           SET WS-EDIT-OK                TO TRUE.
           PERFORM 8510-EDIT-REQTP-FIELD
              THRU 8510-EDIT-REQTP-FIELD-X.
           IF WS-EDIT-ERROR
              GO TO 4000-PROCESS-LIST-X
           END-IF.

           PERFORM  8000-BUILD-EVRQ-BROWSE-KEY
               THRU 8000-BUILD-EVRQ-BROWSE-KEY-X.

           IF WGLOB-MSG-ERROR-SW > ZERO
              GO TO 4000-PROCESS-LIST-X
           END-IF.

           PERFORM  EVRQ-1000-BROWSE
               THRU EVRQ-1000-BROWSE-X

           IF WEVRQ-IO-OK
              PERFORM  EVRQ-2000-READ-NEXT
                  THRU EVRQ-2000-READ-NEXT-X
              IF WEVRQ-IO-EOF
                 MOVE 'XS00000034'    TO WGLOB-MSG-REF-INFO
                 MOVE WEVRQ-KEY       TO WGLOB-MSG-PARM (1)
                 PERFORM  0260-1000-GENERATE-MESSAGE
                     THRU 0260-1000-GENERATE-MESSAGE-X
                 PERFORM  EVRQ-3000-END-BROWSE
                     THRU EVRQ-3000-END-BROWSE-X
                 GO TO 4000-PROCESS-LIST-X
              END-IF
           ELSE
              MOVE 'XS00000001'       TO WGLOB-MSG-REF-INFO
              MOVE WEVRQ-KEY          TO WGLOB-MSG-PARM (1)
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 4000-PROCESS-LIST-X
           END-IF.

           PERFORM  4600-MOVE-RECORD-TO-SCREEN
               THRU 4600-MOVE-RECORD-TO-SCREEN-X.

           IF WEVRQ-IO-OK
      *MSG:   'TO VIEW MORE DATA PRESS ENTER'
              SET WGLOB-MORE-DATA-EXISTS TO TRUE
              MOVE 'XS00000014'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:   'END OF FILE'
              MOVE 'XS00000025'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

           PERFORM  EVRQ-3000-END-BROWSE
               THRU EVRQ-3000-END-BROWSE-X.

       4000-PROCESS-LIST-X.
           EXIT.
      *
      ****************************
       4600-MOVE-RECORD-TO-SCREEN.
      ****************************

           PERFORM  4610-MOVE-EVRQ-TO-SCRN-1
               THRU 4610-MOVE-EVRQ-TO-SCRN-1-X
                 VARYING I FROM 1 BY 1
                    UNTIL (I > WS-MAX-BROWSE-LINES)
                    OR (WEVRQ-IO-EOF).
           IF NOT WEVRQ-IO-EOF
              MOVE REVRQ-EVNT-REQIR-TYP-CD
                                      TO MIR-EVNT-REQIR-TYP-CD
017087*       MOVE REVRQ-LOC-GRP-ID   TO MIR-LOC-GRP-ID
017087        MOVE REVRQ-LOC-GR-ID    TO MIR-LOC-GR-ID
              MOVE REVRQ-BUS-CLAS-CD  TO MIR-BUS-CLAS-CD
020874*       MOVE REVRQ-EVNT-REQIR-SEQ-NUM
020874*                               TO WS-SEQ-NUM-N
020874*       MOVE WS-SEQ-NUM         TO MIR-EVNT-REQIR-SEQ-NUM
020874        MOVE REVRQ-EVNT-REQIR-SEQ-NUM TO L0290-INPUT-V00
020874        MOVE 0                  TO L0290-PRECISION
020874        MOVE LENGTH OF MIR-EVNT-REQIR-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN
020874        PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU 0290-2000-FORMAT-FOR-MIR-X
020874        MOVE L0290-OUTPUT-DATA  TO MIR-EVNT-REQIR-SEQ-NUM
           END-IF.

       4600-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      *
      **************************
       4610-MOVE-EVRQ-TO-SCRN-1.
      **************************

017087*    MOVE REVRQ-LOC-GRP-ID      TO MIR-LOC-GRP-ID-T (I).
017087     MOVE REVRQ-LOC-GR-ID       TO MIR-LOC-GR-ID-T (I).
           MOVE REVRQ-BUS-CLAS-CD     TO MIR-BUS-CLAS-CD-T (I).
020874*    MOVE REVRQ-EVNT-REQIR-SEQ-NUM
020874*                               TO WS-SEQ-NUM-N.
020874*    MOVE WS-SEQ-NUM-N          TO MIR-EVNT-REQIR-SEQ-NUM-T (I).
020874     MOVE REVRQ-EVNT-REQIR-SEQ-NUM TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-EVNT-REQIR-SEQ-NUM-T (I)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-EVNT-REQIR-SEQ-NUM-T (I).
           MOVE REVRQ-REQIR-ID        TO MIR-REQIR-ID-T (I).

           PERFORM  EVRQ-2000-READ-NEXT
               THRU EVRQ-2000-READ-NEXT-X.

       4610-MOVE-EVRQ-TO-SCRN-1-X.
           EXIT.

      *
      *************
       5000-PROCESS-CREATE.
      *************

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  8500-EDIT-EVRQ-KEY-FIELDS
               THRU 8500-EDIT-EVRQ-KEY-FIELDS-X.
           IF WS-EDIT-ERROR
               GO TO  5000-PROCESS-CREATE-X
           END-IF.

           PERFORM  5050-BROWSE-NXT-SEQ
               THRU 5050-BROWSE-NXT-SEQ-X.

      *
      ***  CREATE RECORD AND SWITCH TO MAINTAIN MODE.
      *
           PERFORM  EVRQ-1000-CREATE
               THRU EVRQ-1000-CREATE-X.

           PERFORM  EVRQ-1000-WRITE
               THRU EVRQ-1000-WRITE-X.

014221     PERFORM  EVRQ-1000-READ-TWRK-TS
014221         THRU EVRQ-1000-READ-TWRK-TS-X.

           MOVE 'XS00000004'          TO WGLOB-MSG-REF-INFO.
           MOVE WEVRQ-KEY             TO WGLOB-MSG-PARM(1).
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.
      *MSG:MAINTAIN DETAILS MESSAGE
           MOVE WEVRQ-KEY             TO WGLOB-MSG-PARM (1)
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       5000-PROCESS-CREATE-X.
           EXIT.
      *
      *********************
       5050-BROWSE-NXT-SEQ.
      *********************

           MOVE LOW-VALUES            TO WEVRQ-KEY.
           MOVE HIGH-VALUES           TO WEVRQ-ENDBR-KEY.
           MOVE ZEROS                 TO WEVRQ-EVNT-REQIR-SEQ-NUM.
           MOVE +999                  TO WEVRQ-ENDBR-EVNT-REQIR-SEQ-NUM.

           MOVE MIR-EVNT-REQIR-TYP-CD TO WEVRQ-EVNT-REQIR-TYP-CD.
           MOVE MIR-EVNT-REQIR-TYP-CD TO WEVRQ-ENDBR-EVNT-REQIR-TYP-CD.

017087*    MOVE MIR-LOC-GRP-ID        TO WEVRQ-LOC-GRP-ID.
017087*    MOVE MIR-LOC-GRP-ID        TO WEVRQ-ENDBR-LOC-GRP-ID.
017087     MOVE MIR-LOC-GR-ID         TO WEVRQ-LOC-GR-ID.
017087     MOVE MIR-LOC-GR-ID         TO WEVRQ-ENDBR-LOC-GR-ID.

           MOVE MIR-BUS-CLAS-CD       TO WEVRQ-BUS-CLAS-CD.
           MOVE MIR-BUS-CLAS-CD       TO WEVRQ-ENDBR-BUS-CLAS-CD.

           INITIALIZE    REVRQ-REC-INFO.
           PERFORM  EVRQ-1000-BROWSE
               THRU EVRQ-1000-BROWSE-X.

           IF WEVRQ-IO-OK
              PERFORM  EVRQ-2000-READ-NEXT
                  THRU EVRQ-2000-READ-NEXT-X
                    UNTIL WEVRQ-IO-EOF
           END-IF.

           PERFORM  EVRQ-3000-END-BROWSE
               THRU EVRQ-3000-END-BROWSE-X.

           MOVE REVRQ-EVNT-REQIR-SEQ-NUM
                                      TO WS-SEQ-NUM.
           IF WS-SEQ-NUM NOT NUMERIC
              MOVE 1                  TO WS-SEQ-NUM-N
           ELSE
              ADD 1                TO WS-SEQ-NUM-N
           END-IF.
           MOVE WS-SEQ-NUM-N          TO WEVRQ-EVNT-REQIR-SEQ-NUM.

       5050-BROWSE-NXT-SEQ-X.
           EXIT.

      ***************************************************************
      *    MAINTAIN PROCESSING:
      *        FORCE = 1: USER HAS ENTERED KEY DETAILS
      *        FORCE = 2: USER HAS MODIFIED DATA FIELDS
      ***************************************************************
      ***************
       5500-PROCESS-UPDATE.
      ***************

           PERFORM  3100-BUILD-EVRQ-READ-KEY
               THRU 3100-BUILD-EVRQ-READ-KEY-X.

014221*    PERFORM  EVRQ-1000-READ-FOR-UPDATE
014221*        THRU EVRQ-1000-READ-FOR-UPDATE-X.

014221     PERFORM  EVRQ-2000-UPDATE-TWRK-TS
014221         THRU EVRQ-2000-UPDATE-TWRK-TS-X.

           IF WEVRQ-IO-NOT-FOUND
              MOVE WEVRQ-KEY          TO WGLOB-MSG-PARM (1)
      *MSG:   RECORD NOT FOUND'
              MOVE 'XS00000006'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              PERFORM  9100-BLANK-DATA-FIELDS
                  THRU 9100-BLANK-DATA-FIELDS-X
              GO TO 5500-PROCESS-UPDATE-X
           END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'EVRQ'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WEVRQ-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5500-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  8600-EDIT-EVRQ-DATA-FIELDS
               THRU 8600-EDIT-EVRQ-DATA-FIELDS-X.

           PERFORM  EVRQ-2000-REWRITE
               THRU EVRQ-2000-REWRITE-X

014221     PERFORM  EVRQ-1000-READ-TWRK-TS
014221         THRU EVRQ-1000-READ-TWRK-TS-X.

           IF WS-EDIT-OK
      *MSG:   'MAINTENANCE COMPLETE'
              MOVE 'XS00000007'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5500-PROCESS-UPDATE-X.
           EXIT.
      *
      *************
       6000-PROCESS-DELETE.
      *************

           PERFORM  3100-BUILD-EVRQ-READ-KEY
               THRU 3100-BUILD-EVRQ-READ-KEY-X.

014221*    PERFORM  EVRQ-1000-READ-FOR-UPDATE
014221*        THRU EVRQ-1000-READ-FOR-UPDATE-X

014221     PERFORM  EVRQ-2000-UPDATE-TWRK-TS
014221         THRU EVRQ-2000-UPDATE-TWRK-TS-X

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'EVRQ'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WEVRQ-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF WEVRQ-IO-OK
              PERFORM  EVRQ-1000-DELETE
                  THRU EVRQ-1000-DELETE-X
              IF WEVRQ-IO-OK
      *MSG:      'DELETE COMPLETED MESSAGE'
                 MOVE 'XS00000011'    TO WGLOB-MSG-REF-INFO
              ELSE
      *MSG:      'RECORD (@1) LOST IN DELETE'
                 MOVE WEVRQ-KEY       TO WGLOB-MSG-PARM (1)
                 MOVE 'XS00000010'    TO WGLOB-MSG-REF-INFO
              END-IF
           ELSE
      *MSG:   'RECORD (@1) LOST IN DELETE'
              MOVE WEVRQ-KEY          TO WGLOB-MSG-PARM (1)
              MOVE 'XS00000010'       TO WGLOB-MSG-REF-INFO
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

       6000-PROCESS-DELETE-X.
           EXIT.
      *
      ****************************
       8000-BUILD-EVRQ-BROWSE-KEY.
      ****************************

           MOVE LOW-VALUES            TO WEVRQ-KEY.
           MOVE HIGH-VALUES           TO WEVRQ-ENDBR-KEY.
           MOVE ZEROS                 TO WEVRQ-EVNT-REQIR-SEQ-NUM.
           MOVE +999                  TO WEVRQ-ENDBR-EVNT-REQIR-SEQ-NUM.

           MOVE MIR-EVNT-REQIR-TYP-CD TO WEVRQ-EVNT-REQIR-TYP-CD.
           MOVE MIR-EVNT-REQIR-TYP-CD TO WEVRQ-ENDBR-EVNT-REQIR-TYP-CD.

017087*    IF MIR-LOC-GRP-ID GREATER SPACES
017087*       MOVE MIR-LOC-GRP-ID     TO WEVRQ-LOC-GRP-ID
017087     IF MIR-LOC-GR-ID GREATER SPACES
017087        MOVE MIR-LOC-GR-ID      TO WEVRQ-LOC-GR-ID
           END-IF.

           IF MIR-BUS-CLAS-CD GREATER SPACES
              MOVE MIR-BUS-CLAS-CD    TO WEVRQ-BUS-CLAS-CD
           END-IF.

           IF MIR-EVNT-REQIR-SEQ-NUM NOT NUMERIC
020874*       MOVE ZERO               TO WS-SEQ-NUM-N
020874*       MOVE WS-SEQ-NUM         TO MIR-EVNT-REQIR-SEQ-NUM
020874        MOVE ZERO               TO L0290-INPUT-V00
020874        MOVE 0                  TO L0290-PRECISION
020874        MOVE LENGTH OF MIR-EVNT-REQIR-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN
020874        PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU 0290-2000-FORMAT-FOR-MIR-X
020874        MOVE L0290-OUTPUT-DATA  TO MIR-EVNT-REQIR-SEQ-NUM
           END-IF.

           MOVE MIR-EVNT-REQIR-SEQ-NUM                    TO WS-SEQ-NUM.
           MOVE WS-SEQ-NUM-N          TO WEVRQ-EVNT-REQIR-SEQ-NUM.

       8000-BUILD-EVRQ-BROWSE-KEY-X.
           EXIT.
      *
      ***************************
       8500-EDIT-EVRQ-KEY-FIELDS.
      ***************************

           SET WS-EDIT-OK                TO TRUE.

           PERFORM  8510-EDIT-REQTP-FIELD
               THRU 8510-EDIT-REQTP-FIELD-X.

           PERFORM  8520-EDIT-LOCGR-FIELD
               THRU 8520-EDIT-LOCGR-FIELD-X.

           PERFORM  8530-EDIT-CLASS-FIELD
               THRU 8530-EDIT-CLASS-FIELD-X.

           PERFORM  8540-EDIT-SEQ-NUM
               THRU 8540-EDIT-SEQ-NUM-X.

       8500-EDIT-EVRQ-KEY-FIELDS-X.
           EXIT.
      *
      ***********************
       8510-EDIT-REQTP-FIELD.
      ***********************

           MOVE MIR-EVNT-REQIR-TYP-CD TO WS-REQ-TYP-CD-CHECK.

           IF WS-REQ-TYP-CD-VALID
              CONTINUE
           ELSE
      *MSG:   'INVALID REQUIREMENT TYPE'
              SET WS-EDIT-ERROR          TO TRUE
              MOVE 'NS31100009'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 8510-EDIT-REQTP-FIELD-X
           END-IF.

       8510-EDIT-REQTP-FIELD-X.
           EXIT.
      *
      ************************
       8520-EDIT-LOCGR-FIELD.
      ************************

017087*    MOVE MIR-LOC-GRP-ID        TO WEDIT-ETBL-VALU-ID.
017087     MOVE MIR-LOC-GR-ID         TO WEDIT-ETBL-VALU-ID.

           PERFORM  LGAS-1000-EDIT-LGAS-LOCATION
               THRU LGAS-1000-EDIT-LGAS-LOCATION-X.

           IF WEDIT-IO-OK
              CONTINUE
           ELSE
              SET WS-EDIT-ERROR             TO TRUE
      *MSG:   'LOCATION GROUP MUST BE VALID IN EDIT/LOCGP'
              MOVE 'NS31100006'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 8520-EDIT-LOCGR-FIELD-X
           END-IF.

       8520-EDIT-LOCGR-FIELD-X.
           EXIT.
      *
      ***********************
       8530-EDIT-CLASS-FIELD.
      ***********************

           MOVE MIR-BUS-CLAS-CD       TO WEDIT-ETBL-VALU-ID.

           PERFORM  CLAS-1000-EDIT-CLASS
               THRU CLAS-1000-EDIT-CLASS-X.

           IF WEDIT-IO-OK
              CONTINUE
           ELSE
      *MSG:   'CLASS OF BUSINESS MUST BE VALID IN EDIT/CLASS'
              SET WS-EDIT-ERROR          TO TRUE
              MOVE 'NS31100007'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 8530-EDIT-CLASS-FIELD-X
           END-IF.

       8530-EDIT-CLASS-FIELD-X.
           EXIT.
      *
      *******************
       8540-EDIT-SEQ-NUM.
      *******************

           IF MIR-EVNT-REQIR-SEQ-NUM = SPACES
020874*       MOVE ZERO               TO WS-SEQ-NUM-N
020874*       MOVE WS-SEQ-NUM         TO MIR-EVNT-REQIR-SEQ-NUM
020874        MOVE ZERO               TO L0290-INPUT-V00
020874        MOVE 0                  TO L0290-PRECISION
020874        MOVE LENGTH OF MIR-EVNT-REQIR-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN
020874        PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU 0290-2000-FORMAT-FOR-MIR-X
020874        MOVE L0290-OUTPUT-DATA  TO MIR-EVNT-REQIR-SEQ-NUM
           END-IF.

           MOVE MIR-EVNT-REQIR-SEQ-NUM                    TO WS-SEQ-NUM.

           IF WS-SEQ-NUM NOT NUMERIC
      *MSG:   'INVALID SEQUENCE NUM'
              SET WS-EDIT-ERROR          TO TRUE
              MOVE 'NS31100008'       TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 8540-EDIT-SEQ-NUM-X
           END-IF.

           MOVE MIR-EVNT-REQIR-SEQ-NUM                    TO WS-SEQ-NUM.
           MOVE WS-SEQ-NUM-N          TO REVRQ-EVNT-REQIR-SEQ-NUM.

       8540-EDIT-SEQ-NUM-X.
           EXIT.
      *
      ****************************
       8600-EDIT-EVRQ-DATA-FIELDS.
      ****************************

           IF MIR-REQIR-ID = SPACES
              MOVE REVRQ-REQIR-ID     TO MIR-REQIR-ID
           END-IF.

           SET WS-EDIT-OK                TO TRUE.

           MOVE MIR-REQIR-ID          TO WRTAB-REQIR-ID.

           PERFORM  RTAB-1000-READ
               THRU RTAB-1000-READ-X.

           IF NOT WRTAB-IO-OK
      *MSG:   'REQUIREMENT ID NOT ON REQUIREMENT TABLE'
              MOVE 'NS31100011'       TO WGLOB-MSG-REF-INFO
              SET WS-EDIT-ERROR         TO TRUE
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 8600-EDIT-EVRQ-DATA-FIELDS-X
           END-IF.

           MOVE MIR-REQIR-ID          TO WEDIT-ETBL-VALU-ID.
           MOVE WGLOB-USER-LANG       TO WEDIT-ETBL-LANG-CD.
           MOVE 'REQTC'               TO WEDIT-ETBL-TYP-ID.

           PERFORM  REQT-1000-EDIT
               THRU REQT-1000-EDIT-X.

           IF WEDIT-IO-OK
              MOVE MIR-REQIR-ID       TO REVRQ-REQIR-ID
           ELSE
      *MSG:   'REQUIREMENT ID MUST BE VALID IN EDIT/REQTC'
              MOVE 'NS31100012'       TO WGLOB-MSG-REF-INFO
              SET WS-EDIT-ERROR         TO TRUE
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 8600-EDIT-EVRQ-DATA-FIELDS-X
           END-IF.

       8600-EDIT-EVRQ-DATA-FIELDS-X.
           EXIT.
      *
      ****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      ****************************************************************
      ************************
       9100-BLANK-DATA-FIELDS.
      ************************

           MOVE SPACES                TO MIR-REQIR-ID.
017087*    MOVE SPACES                TO MIR-LOC-GRP-ID-G.
017087     MOVE SPACES                TO MIR-LOC-GR-ID-G.
           MOVE SPACES                TO MIR-BUS-CLAS-CD-G.
           MOVE SPACES                TO MIR-EVNT-REQIR-SEQ-NUM-G.
           MOVE SPACES                TO MIR-REQIR-ID-G.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      *
      ****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN.
      ****************************************************************
      ****************************
       9200-MOVE-RECORD-TO-SCREEN.
      ****************************

           IF WS-BUS-FCN-LIST
              PERFORM  9210-MOVE-EVRQ-TO-SCRN-1
                  THRU 9210-MOVE-EVRQ-TO-SCRN-1-X
                    VARYING I FROM 1 BY 1
                       UNTIL I > WS-MAX-BROWSE-LINES
                       OR WEVRQ-IO-EOF
              IF NOT WEVRQ-IO-EOF
                 MOVE REVRQ-EVNT-REQIR-TYP-CD
                                      TO MIR-EVNT-REQIR-TYP-CD
017087*          MOVE REVRQ-LOC-GRP-ID                 TO MIR-LOC-GRP-ID
017087           MOVE REVRQ-LOC-GR-ID                  TO MIR-LOC-GR-ID
                 MOVE REVRQ-BUS-CLAS-CD
                                      TO MIR-BUS-CLAS-CD
020874*          MOVE REVRQ-EVNT-REQIR-SEQ-NUM
020874*                               TO WS-SEQ-NUM-N
020874*          MOVE WS-SEQ-NUM      TO MIR-EVNT-REQIR-SEQ-NUM
020874           MOVE REVRQ-EVNT-REQIR-SEQ-NUM TO L0290-INPUT-V00
020874           MOVE 0               TO L0290-PRECISION
020874           MOVE LENGTH OF MIR-EVNT-REQIR-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN
020874           PERFORM 0290-2000-FORMAT-FOR-MIR
020874              THRU 0290-2000-FORMAT-FOR-MIR-X
020874           MOVE L0290-OUTPUT-DATA TO MIR-EVNT-REQIR-SEQ-NUM
              END-IF
           ELSE
020874*       MOVE REVRQ-EVNT-REQIR-SEQ-NUM
020874*                               TO WS-SEQ-NUM-N
020874*       MOVE WS-SEQ-NUM         TO MIR-EVNT-REQIR-SEQ-NUM
020874        MOVE REVRQ-EVNT-REQIR-SEQ-NUM TO L0290-INPUT-V00
020874        MOVE 0                  TO L0290-PRECISION
020874        MOVE LENGTH OF MIR-EVNT-REQIR-SEQ-NUM
020874                                TO L0290-MAX-OUT-LEN
020874        PERFORM 0290-2000-FORMAT-FOR-MIR
020874           THRU 0290-2000-FORMAT-FOR-MIR-X
020874        MOVE L0290-OUTPUT-DATA  TO MIR-EVNT-REQIR-SEQ-NUM
              MOVE REVRQ-REQIR-ID     TO MIR-REQIR-ID
           END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      *
      **************************
       9210-MOVE-EVRQ-TO-SCRN-1.
      **************************

017087*    MOVE REVRQ-LOC-GRP-ID      TO MIR-LOC-GRP-ID-T (I).
017087     MOVE REVRQ-LOC-GR-ID       TO MIR-LOC-GR-ID-T (I).
           MOVE REVRQ-BUS-CLAS-CD     TO MIR-BUS-CLAS-CD-T (I).
020874*    MOVE REVRQ-EVNT-REQIR-SEQ-NUM
020874*                               TO WS-SEQ-NUM-N.
020874*    MOVE WS-SEQ-NUM            TO MIR-EVNT-REQIR-SEQ-NUM-T (I).
020874     MOVE REVRQ-EVNT-REQIR-SEQ-NUM TO L0290-INPUT-V00.
020874     MOVE 0                     TO L0290-PRECISION.
020874     MOVE LENGTH OF MIR-EVNT-REQIR-SEQ-NUM-T (I)
020874                                TO L0290-MAX-OUT-LEN.
020874     PERFORM 0290-2000-FORMAT-FOR-MIR
020874        THRU 0290-2000-FORMAT-FOR-MIR-X.
020874     MOVE L0290-OUTPUT-DATA     TO MIR-EVNT-REQIR-SEQ-NUM-T (I).
           MOVE REVRQ-REQIR-ID        TO MIR-REQIR-ID-T (I).

           PERFORM  EVRQ-2000-READ-NEXT
               THRU EVRQ-2000-READ-NEXT-X.

       9210-MOVE-EVRQ-TO-SCRN-1-X.
           EXIT.
      *
      ***************************
       9300-SETUP-MSIN-REFERENCE.
      ***************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE    TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                         WS-WORKING-STORAGE.
025970     INITIALIZE                         WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                         WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-TWRK-KEY            TO TRUE.
025970     SET WS-DEFAULT-MAX-BR-LINES        TO TRUE.
025970     SET WS-DEFAULT-EDITS-SW            TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID                TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.
      *
      ****************************************************************
      *                      PROCESSING COPYBOOKS
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY EVRQ
014221                         '$VAR2' BY 'EVRQ'.
014660*COPY XCPPMEXT.
      *
      ****************************************************************
      *                      LINK COPYBOOKS
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
020874 COPY XCPL0290.
025970 COPY XCPS8090.
020874 COPY XCPS0290.
      *
      ****************************************************************
      *                     FILE HANDLING COPYBOOKS
      ****************************************************************
       COPY NCPAEVRQ.
       COPY NCPBEVRQ.
       COPY NCPCEVRQ.
       COPY NCPNEVRQ.
016537*COPY NCPTEVRQ.
       COPY NCPUEVRQ.
       COPY NCPXEVRQ.
016537*COPY CCPAEDIT.
       COPY CCPNEDIT.
016537*COPY CCPBEDIT.
016537*COPY CCPCEDIT.
016537*COPY CCPXEDIT.
       COPY CCPELGAS.
       COPY CCPECLAS.
       COPY NCPEREQT.
016537*COPY NCPARTAB.
       COPY NCPNRTAB.
016537*COPY NCPBRTAB.
016537*COPY NCPCRTAB.
016537*COPY NCPXRTAB.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      ****************************************************************
      *                  END OF PROGRAM NSOM3110
      ****************************************************************
