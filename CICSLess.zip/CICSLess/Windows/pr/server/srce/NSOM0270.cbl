      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. NSOM0270.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  NSOM0270                                         **
      **  REMARKS:  ASBM - POLICY ASSEMBLY TABLE MAINTENANCE.        **
      **            THIS MODULE MAINTAINS THE ASBM TABLE. THE ASBM   **
      **            TABLE IS USED TO CONTROL WHICH DOCUMENTS ARE     **
      **            PRINTED AS PART OF THE POLICY CONTRACT, AND IN   **
      **            WHAT ORDER. POLICY CONTRACTS CAN BE PRINTED      **
      **            FOLLOWING A MANUAL REQUEST FROM THE PRINT REQUEST**
      **            (PRRQ) SCREEN, OR AUTOMATICALLY PRINTED AS PART  **
      **            OF THE ISSUE PROCESS.                            **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
554712**  5.5       DESCRIPTION BEING REMOVED FROM DOCM.  THIS       **
554712**            DESCRIPTION WILL COME FROM EDIT/DCOM USING       **
554712**            THE DOCUMENT ID AND DOCUMENT LANGAUGE            **
557708**  5.5       HANDLING OF CICS ABENDS                          **
007685**  5.6       NAIC MODULATION REGULATIONS                      **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
010302**  5.6       ARCHITECTURAL CHANGES - VARIATION BY             **
010302**            LOCATION                                         **
010418**  5.6       MULTI-COMPANY SUPPORT                            **
013578**  6.0       REMOVAL OF 3270 LOGIC, MIR RENAMES               **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017419**  6.2       PCR - ADD EDIT FOR NON-ASSEMBLY PAGE DOCUMENTS   **
015789**  6.3       INCREASED THE OCCURS FROM 10 TO 100              **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020462**  6.4       ISO DATE STANDARDIZATION                         **
023118**  6.5       CODE CLEAN-UP AND STANDARDIZATION                **
023447**  6.5       EXTERNALIZATION OF INGENIUM CLIENT PRINTING TO   **
023447**            3RD PARTY PACKAGE                                **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'NSOM0270'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.

       01  WS-PGM-WORK-AREA.
016548*    05  WS-LINE                      PIC S9(4)  COMP SYNC.
016548     05  WS-LINE                      PIC S9(4)  BINARY SYNC.
016548*    05  WS-INSTR-SUB                 PIC S9(4)  COMP SYNC.
016548     05  WS-INSTR-SUB                 PIC S9(4)  BINARY SYNC.
016548*    05  WS-NUM-DISPLAY-LINES         PIC S9(4)  COMP SYNC
015789*    05  WS-NUM-DISPLAY-LINES         PIC S9(4)  BINARY SYNC
015789*                                     VALUE +10.
025970*    05  WS-NUM-DISPLAY-LINES         PIC S9(4)  BINARY SYNC
025970*                                     VALUE +100.
           05  WS-ASMPT.
               10  WS-ASMPT-FIRST-CHAR      PIC X(01).
               10  FILLER                   PIC X(05).
           05  WS-VALID                     PIC X(01).
               88  WS-VALIDATE-PASSED       VALUE 'Y'.
               88  WS-VALIDATE-FAILED       VALUE 'N'.
           05  WS-ALL-EDITS                 PIC X(01).
               88  WS-EDITS-OK              VALUE 'Y'.
           05  WS-DOC-DESCR-IND             PIC X(01).
               88  WS-DOC-DESCR-FOUND       VALUE 'Y'.
           05  WS-BUS-FCN-ID                PIC X(04).
               88  WS-BUS-FCN-VALID         VALUE '0270' '0271' '0272'
                                                  '0273' '0274'.
               88  WS-RETRIEVE              VALUE '0270'.
               88  WS-CREATE                VALUE '0271'.
               88  WS-UPDATE                VALUE '0272'.
               88  WS-DELETE                VALUE '0273'.
               88  WS-LIST                  VALUE '0274'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '0270'.
           05  WS-EDIT-ASMRT                PIC X(02).
               88  FR-OR-CR-ASMRT           VALUE 'FR' 'CR'.
               88  AS-ASMRT                 VALUE 'AS'.
               88  TC-ASMRT                 VALUE 'TC'.
           05  WS-EFFECTIVE-DATE            PIC 9(07).
           05  WS-ASSEMBLY-SEQ-NUM          PIC 9(03).
           05  WS-ASSEMBLY-REC-NUM          PIC 9(02).
554712*    05  WS-DOCM-KEY                  PIC X(08).
010302*    05  WS-GENERIC-LOC               PIC X(02) VALUE 'XX'.
025970/
025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-DEFAULT-TWRK-KEY                VALUE '0270'.
025970     05  WS-NUM-DISPLAY-LINES         PIC S9(4)  BINARY SYNC.
025970         88  WS-DEFAULT-NUM-DISPLAY-LINES        VALUE +100.
      /
016537*COPY XCWWWKDT.
      /
016537*COPY XCWTATRB.
      /
010418 COPY CCFWSCOM.
      /
       COPY XCWEBLCH.
      /
       COPY NCWTASMB.
      /
       COPY XCWL1660.
       COPY XCWL0280.
       COPY XCWL1640.
       COPY XCWLDTLK.
014221 COPY XCWL8090.
      /
       COPY NCFWASMB.
       COPY NCFRASMB.
      /
023447*COPY NCFWDOCM.
023447*COPY NCFRDOCM.
023447 COPY XCFWDOCM.
023447 COPY XCFRDOCM.
      /
       COPY CCFWEDIT.
       COPY CCFREDIT.
       COPY CCFRSCOM.
014221 COPY CCWWLOCK.
      /
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      /
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY NCWM0270.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023118
023118     PERFORM  9990-INIT-WORKING-STORAGE
023118         THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    
557708
           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
           GOBACK.

       0000-MAINLINE-X.
           EXIT.
      /
      *--------------------------
       2000-PROCESS-REQUEST.
      *--------------------------

      *****************************************************************
      *  NORMAL PROCESSING:  CHECK SECURITY PERMISSION AND
      *  DISTRIBUTE CONTROL TO APPROPRIATE PROCESSING ROUTINE.
      *****************************************************************

023118*    MOVE MIR-BUS-FCN-ID             TO WS-BUS-FCN-ID.

      *
      *  HANDLE CASE WHERE DELETE IS NOT VERIFIED
      *
           IF WGLOB-MSG-ERROR-SW NOT = ZERO
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           IF WS-RETRIEVE
               PERFORM  3000-PROCESS-RETRIEVE
                   THRU 3000-PROCESS-RETRIEVE-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF WS-CREATE
               PERFORM  4000-PROCESS-CREATE
                   THRU 4000-PROCESS-CREATE-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF WS-UPDATE
               PERFORM  5000-PROCESS-UPDATE
                   THRU 5000-PROCESS-UPDATE-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.

           IF WS-DELETE
               PERFORM  6000-PROCESS-DELETE
                   THRU 6000-PROCESS-DELETE-X
               GO TO 2000-PROCESS-REQUEST-X
           END-IF.


           IF WS-LIST
               PERFORM  8000-PROCESS-LIST
                   THRU 8000-PROCESS-LIST-X
           END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-------------
       3000-PROCESS-RETRIEVE.
      *-------------

      ***************************************************************
      *    INQUIRY PROCESSING:  RETRIEVE RECORD AND DISPLAY
      ***************************************************************

           PERFORM  3500-EDIT-KEY
               THRU 3500-EDIT-KEY-X.

           IF WS-VALIDATE-FAILED
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

      *
      *  SETUP READ KEY
      *
           PERFORM  7100-BUILD-ASMB-KEY
               THRU 7100-BUILD-ASMB-KEY-X.

      *
      *  READ ASSEMBLY FILE
      *
014221*    PERFORM  ASMB-1000-READ
014221*        THRU ASMB-1000-READ-X.

014221     PERFORM  ASMB-1000-READ-TWRK-TS
014221         THRU ASMB-1000-READ-TWRK-TS-X.

           IF WASMB-IO-NOT-FOUND
               MOVE WASMB-KEY         TO WGLOB-MSG-PARM (1)
      *MSG: ASSEMBLY RECORD NOT FOUND
               MOVE 'XS00000171'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.

554712*    MOVE RASMB-CASM-DOC-ID TO WDOCM-DOC-ID.
554712*    PERFORM  9700-GET-DOCUMENT-DESCR
554712*        THRU 9700-GET-DOCUMENT-DESCR-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.
      /
      *--------------
       3500-EDIT-KEY.
      *--------------

      ***************************************************************
      *    EDIT KEY:  EDIT AND VALIDATE DATE AND NUMBERIC VALUES
      *    WITHIN KEY.
      ***************************************************************

           MOVE 'Y'                   TO WS-VALID.

      *
      *  EDIT EFFECTIVE DATE
      *
           IF WS-LIST
           AND (MIR-CASM-EFF-IDT-NUM = SPACES)
               MOVE ZEROES            TO WS-EFFECTIVE-DATE
           ELSE
               PERFORM  3510-EDIT-EFF-DATE
                   THRU 3510-EDIT-EFF-DATE-X
           END-IF.

      *
      *  EDIT SEQUENCE NUMBER
      *
           IF WS-LIST
           AND (MIR-CASM-SEQ-NUM = SPACES)
               MOVE ZEROES            TO WS-ASSEMBLY-SEQ-NUM
           ELSE
               PERFORM  3520-EDIT-SEQ-NUM
                   THRU 3520-EDIT-SEQ-NUM-X
           END-IF.

      *
      *  EDIT RECORD NUMBER
      *
           IF WS-LIST
           AND (MIR-CASM-REC-NUM = SPACES)
               MOVE ZEROES            TO WS-ASSEMBLY-REC-NUM
           ELSE
               PERFORM  3530-EDIT-REC-NUM
                   THRU 3530-EDIT-REC-NUM-X
           END-IF.

       3500-EDIT-KEY-X.
           EXIT.
      /
      *-------------------
       3510-EDIT-EFF-DATE.
      *-------------------

      *
      *  EDIT EFFECTIVE DATE
      *
           MOVE MIR-CASM-EFF-IDT-NUM  TO L1640-EXTERNAL-DATE.
020462*    PERFORM  1640-3000-EXTERNAL-TO-INT
020462*        THRU 1640-3000-EXTERNAL-TO-INT-X.
020462     PERFORM 1640-7000-MIR-TO-INT
020462        THRU 1640-7000-MIR-TO-INT-X.

           IF L1640-VALID
               MOVE L1640-INTERNAL-DATE
                                      TO L1660-INTERNAL-DATE
               PERFORM  1660-2000-CONVERT-INT-TO-INV
                   THRU 1660-2000-CONVERT-INT-TO-INV-X
               MOVE L1660-INVERTED-DATE
                                      TO WS-EFFECTIVE-DATE
           ELSE
               MOVE MIR-CASM-EFF-IDT-NUM
                                      TO WGLOB-MSG-PARM (1)
      *MSG: INVALID EFFECTIVE DATE
               MOVE 'NS02700006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-VALID
           END-IF.

       3510-EDIT-EFF-DATE-X.
           EXIT.
      /
      *------------------
       3520-EDIT-SEQ-NUM.
      *------------------

      *
      *  EDIT SEQUENCE NUMBER
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 3                     TO L0280-LENGTH.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE MIR-CASM-SEQ-NUM      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-ASSEMBLY-SEQ-NUM
           ELSE
               MOVE ZERO              TO WS-ASSEMBLY-SEQ-NUM
               MOVE MIR-CASM-SEQ-NUM  TO WGLOB-MSG-PARM (1)
      *MSG: SEQUENCE NUMBER MUST BE NUMERIC
               MOVE 'NS02700007'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-VALID
           END-IF.

       3520-EDIT-SEQ-NUM-X.
           EXIT.
      /
      *------------------
       3530-EDIT-REC-NUM.
      *------------------

      *
      *  EDIT RECORD NUMBER
      *
           MOVE 'N'                   TO L0280-SIGN-IND.
           MOVE 2                     TO L0280-LENGTH.
           MOVE ZERO                  TO L0280-PRECISION.
           MOVE MIR-CASM-REC-NUM      TO L0280-INPUT-DATA.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF L0280-OK
               MOVE L0280-OUTPUT      TO WS-ASSEMBLY-REC-NUM
           ELSE
               MOVE ZERO              TO WS-ASSEMBLY-REC-NUM
               MOVE MIR-CASM-REC-NUM  TO WGLOB-MSG-PARM (1)
      *MSG: RECORD NUMBER MUST BE NUMERIC
               MOVE 'NS02700009'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-VALID
           END-IF.

       3530-EDIT-REC-NUM-X.
           EXIT.
      /
      *------------
       4000-PROCESS-CREATE.
      *------------

      *****************************************************************
      *  CREATE PROCESSING:  CHECK RECORD DOES NOT EXIST, INIT NEW
      *  RECORD AND ALLOW USER TO MODIFY.
      *****************************************************************

           PERFORM  7000-VALIDATE-CONTROL-FIELDS
               THRU 7000-VALIDATE-CONTROL-FIELDS-X.

           IF WS-VALIDATE-FAILED
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

           PERFORM  7100-BUILD-ASMB-KEY
               THRU 7100-BUILD-ASMB-KEY-X.

           PERFORM  ASMB-1000-READ
               THRU ASMB-1000-READ-X.

           IF WASMB-IO-OK
               MOVE WASMB-KEY         TO WGLOB-MSG-PARM (1)
      *MSG: ASSEMBLY RECORD ALREADY EXISTS
               MOVE 'NS02700002'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 4000-PROCESS-CREATE-X
           END-IF.

007685*    PERFORM  4500-COMPUTE-RECORD-LENGTH
007685*        THRU 4500-COMPUTE-RECORD-LENGTH-X.

      *
      *  CREATE NEW RECORD
      *
           PERFORM  ASMB-1000-CREATE
               THRU ASMB-1000-CREATE-X.
           PERFORM  ASMB-1000-WRITE
               THRU ASMB-1000-WRITE-X.

014221     PERFORM  ASMB-1000-READ-TWRK-TS
014221         THRU ASMB-1000-READ-TWRK-TS-X.

      *MSG:  ASSEMBLY RECORD CREATED - CONTINUE
           MOVE 'NS02700003'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           MOVE SPACES                TO RASMB-CASM-DOC-ID.
554712*    MOVE SPACES            TO RDOCM-DOC-DESC-TXT.

554712*    PERFORM  9200-MOVE-RECORD-TO-SCREEN
554712*        THRU 9200-MOVE-RECORD-TO-SCREEN-X.

      *MSG:  MAINTAIN DETAILS
           MOVE 'XS00000016'          TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           MOVE '0272'                TO MIR-BUS-FCN-ID.

       4000-PROCESS-CREATE-X.
           EXIT.
      /
      *---------------------------
       4500-COMPUTE-RECORD-LENGTH.
      *---------------------------

      *****************************************************************
      *  COMPUTE RECORD LENGTH:  THIS ROUTINE WILL DETERMINE THE
      *  RECORD LENGTH OF THE RECORD THAT IS TO BE WRITTEN/REWRITTEN
      *  BY THE I/O MODULES.  THIS ROUTINE WILL ACCESS A WORKING
      *  STORAGE TABLE WHICH CONTAINS RECORD LENGTHS FOR ALL THE
      *  RECORD TYPES IN THE ASSEMBLY FILE.
      *****************************************************************

      *
      *  CHANGED ALL OCCURRENCES OF "ASMB" TO "TASMB".
      *
           SET TASMB-TABLE-SUB    TO 1.

           SEARCH TASMB-TABLE-OCCURRENCES

               WHEN (TASMB-RECORD-TYPE (TASMB-TABLE-SUB) =
007685             MIR-CASM-REC-TYP-CD)
007685*            WASMB-CASM-REC-TYP-CD)
                   MOVE '1'           TO TASMB-TABLE-VALID
                   MOVE TASMB-TABLE-LENGTH (TASMB-TABLE-SUB)
                                      TO WASMB-REC-LEN
               WHEN (TASMB-RECORD-TYPE (TASMB-TABLE-SUB) = '**')
                   MOVE ZERO          TO TASMB-TABLE-VALID
                   MOVE TASMB-TABLE-LENGTH (TASMB-TABLE-SUB)
                                      TO WASMB-REC-LEN

           END-SEARCH.

007685*    IF  TASMB-NOT-VALID
007685*        MOVE WASMB-CASM-REC-TYP-CD
007685*                           TO WGLOB-MSG-PARM (1)
007685*MSG:  WARNING - RECORD LENGTH NOT DEFINED
007685*        MOVE 'NS02700004'
007685*                           TO WGLOB-MSG-REF-INFO
007685*        PERFORM  0260-1000-GENERATE-MESSAGE
007685*            THRU 0260-1000-GENERATE-MESSAGE-X
007685*    END-IF.

       4500-COMPUTE-RECORD-LENGTH-X.
           EXIT.
      /
      *-----------------
       5000-PROCESS-UPDATE.
      *-----------------

      *****************************************************************
      *  MAINTAIN PROCESSING:  GET RECORD, EDIT DATA FIELDS AND
      *  UPDATE.
      *****************************************************************

           PERFORM  3500-EDIT-KEY
               THRU 3500-EDIT-KEY-X.

           IF WS-VALIDATE-FAILED
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

           PERFORM  7100-BUILD-ASMB-KEY
               THRU 7100-BUILD-ASMB-KEY-X.

014221*    PERFORM  ASMB-1000-READ-FOR-UPDATE
014221*        THRU ASMB-1000-READ-FOR-UPDATE-X.

014221     PERFORM  ASMB-2000-UPDATE-TWRK-TS
014221         THRU ASMB-2000-UPDATE-TWRK-TS-X.

           IF WASMB-IO-NOT-FOUND
               MOVE WASMB-KEY         TO WGLOB-MSG-PARM (1)
      *MSG:  LOST RECORD IN MAINTAIN...
               MOVE 'XS00000006'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5000-PROCESS-UPDATE-X
           END-IF.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'ASMB'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WASMB-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 5000-PROCESS-UPDATE-X
014221     END-IF.

           PERFORM  7500-EDIT-DATA-FIELDS
               THRU 7500-EDIT-DATA-FIELDS-X.

           PERFORM  ASMB-2000-REWRITE
               THRU ASMB-2000-REWRITE-X.

014221     PERFORM  ASMB-1000-READ-TWRK-TS
014221         THRU ASMB-1000-READ-TWRK-TS-X.

           IF WS-EDITS-OK
               MOVE  '0270'           TO MIR-BUS-FCN-ID
      *MSG:  MAINTENANCE COMPLETED - CONTINUE
               MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
      *MSG:  RECORD UPDATED
               MOVE 'XS00000008'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       5000-PROCESS-UPDATE-X.
           EXIT.
      /
      *------------
       6000-PROCESS-DELETE.
      *------------

      *****************************************************************
      *  DELETE PROCESSING:  DELETE IS VERIFIED, DELETE THE RECORD
      *****************************************************************

           PERFORM  3500-EDIT-KEY
               THRU 3500-EDIT-KEY-X.

           IF WS-VALIDATE-FAILED
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
           END-IF.

           PERFORM  7100-BUILD-ASMB-KEY
               THRU 7100-BUILD-ASMB-KEY-X.

014221*    PERFORM  ASMB-1000-READ-FOR-UPDATE
014221*        THRU ASMB-1000-READ-FOR-UPDATE-X.

014221     PERFORM  ASMB-2000-UPDATE-TWRK-TS
014221         THRU ASMB-2000-UPDATE-TWRK-TS-X.

014221     IF  MIR-RETRN-TS-MISMATCH
014221*MSG:    TIMESTAMP MISMATCH - TABLE (@1), KEY @2
014221*        - PROCESS NOT COMPLETE
014221         MOVE 'XS00000303'                 TO WGLOB-MSG-REF-INFO
014221         MOVE 'ASMB'                       TO WGLOB-MSG-PARM (01)
014221         MOVE WASMB-KEY                    TO WGLOB-MSG-PARM (02)
014221         PERFORM  0260-1000-GENERATE-MESSAGE
014221             THRU 0260-1000-GENERATE-MESSAGE-X
014221         GO TO 6000-PROCESS-DELETE-X
014221     END-IF.

           IF WASMB-IO-NOT-FOUND
               MOVE WASMB-KEY         TO WGLOB-MSG-PARM (1)
      *MSG:  LOST RECORD IN DELETE...
               MOVE 'XS00000010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               MOVE  '0270'           TO MIR-BUS-FCN-ID
      *MSG:  DELETE COMPLETED - CONTINUE
               MOVE 'XS00000011'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  ASMB-1000-DELETE
                   THRU ASMB-1000-DELETE-X
           END-IF.

       6000-PROCESS-DELETE-X.
           EXIT.
      /
      *-----------------------------
       7000-VALIDATE-CONTROL-FIELDS.
      *-----------------------------

      *****************************************************************
      *  EDIT CONTROL FIELDS:  CHECK VALIDITY OF ALL KEY FIELDS
      *  TO ENSURE THAT ALL NEW RECORDS ARE CREATED WITH VALID KEYS
      *****************************************************************

           MOVE 'Y'                   TO WS-VALID.

      *
      *  EDIT KEYS MUST BE PERFORM HERE SINCE IT WILL ALSO RESET
      *  WS-VALID TO 'Y'
      *
           PERFORM  3500-EDIT-KEY
               THRU 3500-EDIT-KEY-X.
      *
      *  EDIT ASSEMBLY POINTER
      *
           MOVE  MIR-CASM-ID          TO  WEDIT-ETBL-VALU-ID.
           PERFORM  ASMP-1000-EDIT-ASSEMBLY-PTR
               THRU ASMP-1000-EDIT-ASSEMBLY-PTR-X.

           IF  NOT WEDIT-IO-OK
      *MSG:  ASSEMBLY POINTER MUST BE ON EDIT TYPE 'ASMBP'
               MOVE 'NS02700011'      TO WGLOB-MSG-REF-INFO
               PERFORM 0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-VALID
           END-IF.

010418     MOVE MIR-SBSDRY-CO-ID      TO WSCOM-SBSDRY-CO-ID.

010418     PERFORM  SCOM-1000-READ
010418         THRU SCOM-1000-READ-X.

010418     IF  NOT WSCOM-IO-OK
010418*MSG: SUB-COMPANY MUST ON SUB-COMPANY PROFILE
010418         MOVE 'NS02700001'      TO WGLOB-MSG-REF-INFO
010418         PERFORM  0260-1000-GENERATE-MESSAGE
010418             THRU 0260-1000-GENERATE-MESSAGE-X
010418         MOVE 'N'               TO WS-VALID
010418     END-IF.

010302*
010302*  EDIT ISSUE LOCATION
010302*
010302*    IF  MIR-ISLOC NOT = WS-GENERIC-LOC
010302*        MOVE MIR-ISLOC     TO WEDIT-ETBL-VALU-ID
010302*        PERFORM  ILOC-1000-EDIT-ISSU-LOCATION
010302*            THRU ILOC-1000-EDIT-ISSU-LOCATION-X
010302*        IF WEDIT-IO-OK
010302*            CONTINUE
010302*        ELSE
010302*            MOVE MIR-ISLOC TO WGLOB-MSG-PARM (1)
010302*MSG: INVALID ISSUE LOCATION
010302*            MOVE 'XS00000065'
010302*                           TO WGLOB-MSG-REF-INFO
010302*            PERFORM  0260-1000-GENERATE-MESSAGE
010302*                THRU 0260-1000-GENERATE-MESSAGE-X
010302*            MOVE 'N'       TO WS-VALID
010302*            MOVE -1        TO MIR-ISLOC-L
010302*            MOVE TATRB-KEYS-ERROR
010302*                           TO MIR-ISLOC-A
010302*            MOVE 'P'       TO LTPI-CURSOR-POS-IND
010302*        END-IF
010302*    END-IF.

010302*
010302*  EDIT LOCATION GROUP
010302*
010302     MOVE MIR-LOC-GR-ID         TO WEDIT-ETBL-VALU-ID.
010302
010302     PERFORM  LCGP-1000-EDIT-LCGP-LOCATION
010302         THRU LCGP-1000-EDIT-LCGP-LOCATION-X.
010302
010302     IF  WEDIT-IO-OK
010302         CONTINUE
010302     ELSE
010302         MOVE MIR-LOC-GR-ID     TO WGLOB-MSG-PARM (1)
010302*MSG: INVALID LOCATION GROUP
010302         MOVE 'XS00000233'      TO WGLOB-MSG-REF-INFO
010302         PERFORM  0260-1000-GENERATE-MESSAGE
010302             THRU 0260-1000-GENERATE-MESSAGE-X
010302         MOVE 'N'               TO WS-VALID
010302     END-IF.
007685*
007685*  EDIT ASSEMBLY RECORD TYPE
007685*
007685*    MOVE MIR-CASM-REC-TYP-CD         TO WEDIT-ETBL-VALU-ID.
007685*    PERFORM  ASMT-1000-EDIT-ASSEMBLY-TYPE
007685*        THRU ASMT-1000-EDIT-ASSEMBLY-TYPE-X.
007685*
007685*    IF NOT WEDIT-IO-OK
007685*        MOVE MIR-CASM-REC-TYP-CD     TO WGLOB-MSG-PARM (1)
007685*MSG:  INVALID RECORD TYPE
007685*        MOVE 'NS02700008'  TO WGLOB-MSG-REF-INFO
007685*        PERFORM  0260-1000-GENERATE-MESSAGE
007685*            THRU 0260-1000-GENERATE-MESSAGE-X
007685*        MOVE 'N'           TO WS-VALID
007685*        MOVE -1            TO MIR-CASM-REC-TYP-CD-L
007685*        MOVE TATRB-KEYS-ERROR
007685*                           TO MIR-CASM-REC-TYP-CD-A
007685*        MOVE 'P'           TO LTPI-CURSOR-POS-IND
007685*    END-IF.

007685*  VALIDATE RECORD TYPE AND SET THE RECORD LENGTH
007685     PERFORM  4500-COMPUTE-RECORD-LENGTH
007685         THRU 4500-COMPUTE-RECORD-LENGTH-X.

007685     IF  TASMB-NOT-VALID
007685         MOVE MIR-CASM-REC-TYP-CD
                                      TO WGLOB-MSG-PARM (1)
007685*MSG:  INVALID RECORD TYPE
007685         MOVE 'NS02700008'      TO WGLOB-MSG-REF-INFO
007685         PERFORM  0260-1000-GENERATE-MESSAGE
007685             THRU 0260-1000-GENERATE-MESSAGE-X
007685         MOVE 'N'               TO WS-VALID
007685     END-IF.
      *
      *  VALIDATE THAT RECORD NUMBER IS NOT ZERO
      *
           IF WS-ASSEMBLY-REC-NUM = ZERO
      *MSG:  RECORD NUMBER MUST BE 1 OR GREATER
               MOVE 'NS02700015'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 'N'               TO WS-VALID
           END-IF.

      *
      *  CROSS CHECK SEQUENCE NUMBER/RECORD TYPE
      *
           MOVE MIR-CASM-REC-TYP-CD   TO WS-EDIT-ASMRT.
           IF WS-ASSEMBLY-SEQ-NUM = ZEROS
               IF FR-OR-CR-ASMRT
                   CONTINUE
               ELSE
                   MOVE MIR-CASM-SEQ-NUM
                                      TO WGLOB-MSG-PARM (1)
                   MOVE MIR-CASM-REC-TYP-CD
                                      TO WGLOB-MSG-PARM (2)
      *MSG:  MISMATCH SEQUENCE NUMBER/RECORD TYPE
                   MOVE 'NS02700010'
                                      TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-VALID
               END-IF
           END-IF.

           IF WS-ASSEMBLY-SEQ-NUM > ZERO
               IF FR-OR-CR-ASMRT
                   MOVE MIR-CASM-SEQ-NUM
                                      TO WGLOB-MSG-PARM (1)
                   MOVE MIR-CASM-REC-TYP-CD
                                      TO WGLOB-MSG-PARM (2)
      *MSG:  MISMATCH SEQUENCE NUMBER/RECORD TYPE
                   MOVE 'NS02700010'
                                      TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-VALID
               END-IF
           END-IF.

      *
      *  CROSS CHECK RECORD TYPE AND RECORD NUMBER
      *
           IF TC-ASMRT
           AND WS-ASSEMBLY-REC-NUM > 1
                   MOVE MIR-CASM-REC-TYP-CD
                                      TO WGLOB-MSG-PARM (1)
                   MOVE MIR-CASM-REC-NUM
                                      TO WGLOB-MSG-PARM (2)
      *MSG:  MISMATCH RECORD NUMBER/RECORD TYPE
                   MOVE 'NS02700014'
                                      TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE 'N'           TO WS-VALID
           END-IF.

       7000-VALIDATE-CONTROL-FIELDS-X.
           EXIT.
      /
      *--------------------
       7100-BUILD-ASMB-KEY.
      *--------------------

           MOVE MIR-CASM-ID           TO WASMB-CASM-ID.
010418     MOVE MIR-SBSDRY-CO-ID      TO WASMB-SBSDRY-CO-ID.
010302*    MOVE MIR-ISLOC         TO WASMB-CASM-ISS-LOC-CD.
010302     MOVE MIR-LOC-GR-ID         TO WASMB-LOC-GR-ID.
           MOVE WS-EFFECTIVE-DATE     TO WASMB-CASM-EFF-IDT-NUM.
           MOVE WS-ASSEMBLY-SEQ-NUM
                                      TO WASMB-CASM-SEQ-NUM.
           MOVE MIR-CASM-REC-TYP-CD   TO WASMB-CASM-REC-TYP-CD.
           MOVE WS-ASSEMBLY-REC-NUM
                                      TO WASMB-CASM-REC-NUM.

       7100-BUILD-ASMB-KEY-X.
           EXIT.
      /
      *----------------------
       7500-EDIT-DATA-FIELDS.
      *----------------------

      *****************************************************************
      *  FIELDS EDITS:  CHECK VALIDITY OF ALL DATA FIELDS
      *****************************************************************

           MOVE 'Y'                   TO WS-ALL-EDITS.

           PERFORM  7530-EDIT-DOCUMENT-NAME
               THRU 7530-EDIT-DOCUMENT-NAME-X.

           IF RASMB-CASM-REC-TYP-CD  NOT = 'AS'
017419     AND MIR-CASM-INSTR-INFO-G NOT = SPACES
               MOVE SPACES            TO MIR-CASM-INSTR-INFO-G
017419         MOVE 'NS02700004'      TO WGLOB-MSG-REF-INFO
017419         PERFORM  0260-1000-GENERATE-MESSAGE
017419             THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               PERFORM  7550-EDIT-ASSEMBLY-INSTRUCT
                   THRU 7550-EDIT-ASSEMBLY-INSTRUCT-X
           END-IF.

       7500-EDIT-DATA-FIELDS-X.
           EXIT.
      /
      *------------------------
       7530-EDIT-DOCUMENT-NAME.
      *------------------------

      *****************************************************************
      *  EDIT THE DOCUMENT NAME
      *****************************************************************

      *
      *  CHECK FOR BLANK INPUT
      *
           IF MIR-DOC-ID = SPACES
               MOVE RASMB-CASM-DOC-ID
                                      TO MIR-DOC-ID
           END-IF.

      *
      *  CHECK FOR BLANK FIELD CHARACTER
      *
           IF MIR-DOC-ID = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-DOC-ID
           END-IF.

      *
      *  DOCUMENT NAME NOT ALLOWED FOR AMMENDMENTS, EXCLUSIONS OR
      *  ENDORSEMENTS
      *
           IF  RASMB-CASM-REC-TYP-CD   =  'AM'
           OR  RASMB-CASM-REC-TYP-CD   =  'EN'
           OR  RASMB-CASM-REC-TYP-CD   =  'EX'
               IF  MIR-DOC-ID  =  SPACES
                   MOVE MIR-DOC-ID    TO RASMB-CASM-DOC-ID
013578*            MOVE SPACES        TO MIR-DODES
                   GO TO  7530-EDIT-DOCUMENT-NAME-X
               ELSE
                   MOVE SPACES        TO MIR-DOC-ID
      *MSG: DOCUMENT NAME NOT ALLOWED FOR RECORD TYPES 'AM, EN, EX'
                   MOVE 'NS02700017'
                                      TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   GO TO  7530-EDIT-DOCUMENT-NAME-X
               END-IF
           END-IF.

554712*    MOVE MIR-DOC-ID         TO WDOCM-DOC-ID.
554712*    PERFORM  9700-GET-DOCUMENT-DESCR
554712*        THRU 9700-GET-DOCUMENT-DESCR-X.
554712*    MOVE REDIT-ETBL-DESC-TXT TO MIR-DODES.
554712*    MOVE RDOCM-DOC-DESC-TXT
554712*                           TO MIR-DODES.

007685*    MOVE MIR-DOC-ID         TO WEDIT-ETBL-VALU-ID.
007685*    PERFORM  DOCM-1000-EDIT
007685*        THRU DOCM-1000-EDIT-X.

007685     MOVE MIR-DOC-ID            TO WDOCM-DOC-ID.
023447*    MOVE WGLOB-EDIT-LANG       TO WDOCM-DOC-LANG-CD.

007685     PERFORM  DOCM-1000-READ
007685         THRU DOCM-1000-READ-X.

007685*    IF  WEDIT-IO-OK
007685     IF  WDOCM-IO-OK
               MOVE MIR-DOC-ID        TO RASMB-CASM-DOC-ID
013578*        PERFORM  9700-GET-DOCUMENT-DESCR
013578*            THRU 9700-GET-DOCUMENT-DESCR-X
013578*        MOVE REDIT-ETBL-DESC-TXT
013578*                               TO MIR-DODES
           ELSE
               MOVE 'N'               TO WS-ALL-EDITS
007685         MOVE WDOCM-DOC-ID      TO WGLOB-MSG-PARM (1)
007685*MSG: DOCUMENT NAME MUST EXIST ON DOCM
554712         MOVE 'NS02700018'      TO WGLOB-MSG-REF-INFO
554712         PERFORM  0260-1000-GENERATE-MESSAGE
554712             THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       7530-EDIT-DOCUMENT-NAME-X.
           EXIT.
      /
      *----------------------------
       7550-EDIT-ASSEMBLY-INSTRUCT.
      *----------------------------

      *****************************************************************
      *  EDIT ASSEMBLY INSTRUCTIONS
      *****************************************************************

      *
      *  CHECK FOR BLANK FIELD CHARACTER
      *
           IF MIR-CASM-INSTR-INFO-T (01) = EBLCH-BLANK-FIELD-CHAR
               MOVE SPACES            TO MIR-CASM-INSTR-INFO-G
               MOVE SPACES            TO RASMB-CASM-INSTR-INFO-TXT
               GO TO 7550-EDIT-ASSEMBLY-INSTRUCT-X
           END-IF.

      *
      *  CHECK FOR BLANK INPUT
      *
           IF MIR-CASM-INSTR-INFO-G = SPACES
               MOVE RASMB-CASM-INSTR-INFO-TXT
                                      TO MIR-CASM-INSTR-INFO-G
               GO TO 7550-EDIT-ASSEMBLY-INSTRUCT-X
           END-IF.

           MOVE MIR-CASM-INSTR-INFO-G
                                      TO RASMB-CASM-INSTR-INFO-TXT.

       7550-EDIT-ASSEMBLY-INSTRUCT-X.
           EXIT.
      /
      *------------
       8000-PROCESS-LIST.
      *------------

      *****************************************************************
      *  BROWSE ASSEMBLY FILE:  DISPLAY ASSEMBLY RECORDS STARTING
      *  AT FIRST RECORD GREATER THAN OR EQUAL TO THE KEY GIVEN.
      *****************************************************************

      *    PERFORM  9100-BLANK-DATA-FIELDS
      *        THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  3500-EDIT-KEY
               THRU 3500-EDIT-KEY-X.

           IF WS-VALIDATE-FAILED
               GO TO 8000-PROCESS-LIST-X
           END-IF.

      *
      *  SETUP BROWSE KEY
      *
           PERFORM  7100-BUILD-ASMB-KEY
               THRU 7100-BUILD-ASMB-KEY-X.
           MOVE HIGH-VALUES           TO WASMB-ENDBR-KEY.

      *
      *  BROWSE FILE
      *
           PERFORM  ASMB-1000-BROWSE
               THRU ASMB-1000-BROWSE-X.

           IF WASMB-IO-OK
               PERFORM  ASMB-2000-READ-NEXT
                   THRU ASMB-2000-READ-NEXT-X
           ELSE
      *MSG:  NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 8000-PROCESS-LIST-X
           END-IF.

           PERFORM 8100-DISPLAY-RECORD-LOOP
              THRU 8100-DISPLAY-RECORD-LOOP-X
           VARYING WS-LINE FROM 1 BY 1
             UNTIL (WASMB-IO-EOF)
                OR WS-LINE > WS-NUM-DISPLAY-LINES.

           IF MIR-CASM-ID-T (1) = SPACES
      *MSG:  NO RECORDS FOUND TO DISPLAY
               MOVE 'XS00000034'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           ELSE
               IF WASMB-IO-EOF
      *MSG:  BROWSE COMPLETED - CONTINUE
                   MOVE 'XS00000025'
                                      TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               ELSE
      *MSG:  ** TO VIEW MORE DATA PRESS ENTER **
                   PERFORM  9230-MOVE-RECORD-KEY-FIELDS
                       THRU 9230-MOVE-RECORD-KEY-FIELDS-X
                   SET WGLOB-MORE-DATA-EXISTS TO TRUE
      *MSG: ** TO VIEW MORE DATA PRESS ENTER **
                   MOVE 'XS00000014'
                                      TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
               END-IF
           END-IF.

           PERFORM  ASMB-3000-END-BROWSE
               THRU ASMB-3000-END-BROWSE-X.

       8000-PROCESS-LIST-X.
           EXIT.
      /
      *-------------------------
       8100-DISPLAY-RECORD-LOOP.
      *-------------------------

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  ASMB-2000-READ-NEXT
               THRU ASMB-2000-READ-NEXT-X.

       8100-DISPLAY-RECORD-LOOP-X.
           EXIT.
      /
      *-----------------------
       9100-BLANK-DATA-FIELDS.
      *-----------------------

      *****************************************************************
      *  BLANK DATA FIELDS:  SET EACH DATA (NON-KEY AND NON-CONTROL)
      *  FIELD ON THE SCREEN TO SPACES
      *****************************************************************

           IF WS-LIST
               MOVE SPACES            TO MIR-CASM-ID
010418         MOVE SPACES            TO MIR-SBSDRY-CO-ID
010302*        MOVE SPACES        TO MIR-ISLOC-TABLE
010302         MOVE SPACES            TO MIR-LOC-GR-ID
               MOVE SPACES            TO MIR-CASM-EFF-IDT-NUM
               MOVE SPACES            TO MIR-CASM-SEQ-NUM
               MOVE SPACES            TO MIR-CASM-REC-TYP-CD
               MOVE SPACES            TO MIR-CASM-REC-NUM
               MOVE SPACES            TO MIR-DOC-ID
013578*        MOVE SPACES            TO MIR-DODES-TABLE
           ELSE
               MOVE SPACES            TO MIR-DOC-ID
013578*        MOVE SPACES            TO MIR-DODES
               MOVE SPACES            TO MIR-CASM-INSTR-INFO-G
           END-IF.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.
      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

      *****************************************************************
      *  RECORD TO SCREEN:  SHIFT DATA FROM RECORD BUFFER TO SCREEN
      *  INTERFACE RECORD IN PREPARATION FOR DISPLAYING DATA.
      *****************************************************************

           IF NOT WS-LIST
               PERFORM  9210-MOVE-RECORD-TO-SCREEN-1
                   THRU 9210-MOVE-RECORD-TO-SCREEN-1-X
           ELSE
               PERFORM  9220-MOVE-RECORD-TO-SCREEN-2
                   THRU 9220-MOVE-RECORD-TO-SCREEN-2-X
           END-IF.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *-----------------------------
       9210-MOVE-RECORD-TO-SCREEN-1.
      *-----------------------------

      *****************************************************************
      *  RECORD TO SCREEN 1:  MOVE RECORD BUFFER TO SCREEN 1 FIELDS
      *****************************************************************

           PERFORM  9230-MOVE-RECORD-KEY-FIELDS
               THRU 9230-MOVE-RECORD-KEY-FIELDS-X.

           MOVE RASMB-CASM-DOC-ID     TO MIR-DOC-ID.
554712*    MOVE RDOCM-DOC-DESC-TXT
554712*                           TO MIR-DODES.

           IF RASMB-CASM-REC-TYP-CD  = 'AS'
               MOVE RASMB-CASM-INSTR-INFO-TXT
                                      TO MIR-CASM-INSTR-INFO-G
           ELSE
               MOVE SPACES            TO MIR-CASM-INSTR-INFO-G
           END-IF.

013578*    PERFORM  9700-GET-DOCUMENT-DESCR
013578*        THRU 9700-GET-DOCUMENT-DESCR-X.
013578*    MOVE REDIT-ETBL-DESC-TXT   TO MIR-DODES.

       9210-MOVE-RECORD-TO-SCREEN-1-X.
           EXIT.
      /
      *-----------------------------
       9220-MOVE-RECORD-TO-SCREEN-2.
      *-----------------------------

      *****************************************************************
      *  RECORD TO SCREEN 2:  MOVE RECORD BUFFER TO SCREEN 2 FIELDS
      *****************************************************************


           MOVE RASMB-CASM-ID         TO MIR-CASM-ID-T (WS-LINE).
010418     MOVE RASMB-SBSDRY-CO-ID    TO MIR-SBSDRY-CO-ID-T (WS-LINE).
010302*    MOVE RASMB-CASM-ISS-LOC-CD
010302*                           TO MIR-ISLOC-T (WS-LINE).
010302     MOVE RASMB-LOC-GR-ID
010302                                TO MIR-LOC-GR-ID-T  (WS-LINE).
           MOVE RASMB-CASM-EFF-IDT-NUM
                                      TO L1660-INVERTED-DATE.
           PERFORM  1660-3000-CONVERT-INV-TO-INT
               THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE
                                      TO L1640-INTERNAL-DATE.

020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE
                                    TO MIR-CASM-EFF-IDT-NUM-T (WS-LINE).
           MOVE RASMB-CASM-SEQ-NUM
                                      TO MIR-CASM-SEQ-NUM-T (WS-LINE).
           MOVE RASMB-CASM-REC-TYP-CD
                                     TO MIR-CASM-REC-TYP-CD-T (WS-LINE).
           MOVE RASMB-CASM-REC-NUM
                                      TO MIR-CASM-REC-NUM-T (WS-LINE).
           MOVE RASMB-CASM-DOC-ID     TO MIR-DOC-ID-T (WS-LINE).
554712*    MOVE RASMB-CASM-DOC-ID TO WDOCM-DOC-ID.
013578*    PERFORM  9700-GET-DOCUMENT-DESCR
013578*        THRU 9700-GET-DOCUMENT-DESCR-X.
554712*    MOVE RDOCM-DOC-DESC-TXT
554712*                           TO MIR-DODES-T (WS-LINE).
013578*    MOVE REDIT-ETBL-DESC-TXT   TO MIR-DODES-T (WS-LINE).

       9220-MOVE-RECORD-TO-SCREEN-2-X.
           EXIT.
      /
      *----------------------------
       9230-MOVE-RECORD-KEY-FIELDS.
      *----------------------------

      *****************************************************************
      *  MOVE RECORD KEY FIELDS:  MOVE RECORD KEY FIELDS TO THEIR
      *  CORRESPONDING MAP INTERFACE FIELDS.
      *****************************************************************

           MOVE RASMB-CASM-ID         TO MIR-CASM-ID.
010418     MOVE RASMB-SBSDRY-CO-ID    TO MIR-SBSDRY-CO-ID.
010302*    MOVE RASMB-CASM-ISS-LOC-CD
010302*                           TO MIR-ISLOC.
010302     MOVE RASMB-LOC-GR-ID
010302                                TO MIR-LOC-GR-ID.
010302     MOVE RASMB-CASM-SEQ-NUM
                                      TO MIR-CASM-SEQ-NUM.
           MOVE RASMB-CASM-REC-TYP-CD
                                      TO MIR-CASM-REC-TYP-CD.
           MOVE RASMB-CASM-REC-NUM
                                      TO MIR-CASM-REC-NUM.

           MOVE RASMB-CASM-EFF-IDT-NUM
                                      TO L1660-INVERTED-DATE.
           PERFORM  1660-3000-CONVERT-INV-TO-INT
               THRU 1660-3000-CONVERT-INV-TO-INT-X.
           MOVE L1660-INTERNAL-DATE
                                      TO L1640-INTERNAL-DATE.

      *
      *  CONVERT DATE FROM INTERNAL TO EXTERNAL FORMAT
      *
020462*    PERFORM  1640-2000-INTERNAL-TO-EXT
020462*        THRU 1640-2000-INTERNAL-TO-EXT-X.
020462     PERFORM 1640-8000-INTERNAL-TO-MIR
020462        THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE   TO MIR-CASM-EFF-IDT-NUM.

       9230-MOVE-RECORD-KEY-FIELDS-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

      *****************************************************************
      *  SET REFERENCE:  MOVE DATA WHICH IDENTIFIES THE OBJECT THAT
      *  IS BEING WORKED ON TO THE GLOBAL AREA FOR MSIN AND MSAU
      *  PROCESSING.
      *****************************************************************

           MOVE SPACES                TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
                                      TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
013578*------------------------
013578*9700-GET-DOCUMENT-DESCR.
013578*------------------------
013578*
013578*    MOVE RASMB-CASM-DOC-ID     TO WEDIT-ETBL-VALU-ID.
013578*    IF  WEDIT-ETBL-VALU-ID = SPACES
013578*        MOVE SPACES            TO REDIT-ETBL-DESC-TXT
013578*        GO TO 9700-GET-DOCUMENT-DESCR-X
013578*    END-IF.
013578*
013578*    PERFORM  DOCM-2000-DESC
013578*        THRU DOCM-2000-DESC-X.
013578*    IF  NOT WEDIT-IO-OK
013578*        MOVE SPACES            TO REDIT-ETBL-DESC-TXT
013578*    END-IF.

554712*****************************************************************
554712* GET DOCUMENT DESCRIPTION: READ THE DOCUMENT MASTER FILE
554712* WITH THE DOCUMENT NAME IN THE ASSEMBLY RECORD AND THE
554712* USER'S CURRENT LANGUAGE SETTING AS THE KEY.   IF THE RECORD
554712* IS NOT FOUND THEN SET LANGUAGE TO SPACES AND START BROWSE
554712* TO FIND THE FIRST RECORD WITH THE DESIRED DOCUMENT NAME.
554712* IF NONE ARE FOUND THEN SET DOCUMENT DESCRIPTION TO SPACES.
554712*****************************************************************
554712*
554712*    MOVE 'Y'               TO WS-DOC-DESCR-IND.
554712*
554712*    IF WDOCM-DOC-ID        = SPACES
554712*        MOVE SPACES        TO RDOCM-DOC-DESC-TXT
554712*        GO TO 9700-GET-DOCUMENT-DESCR-X
554712*    END-IF.
554712*
554712*
554712* SETUP DOCM KEY
554712*
554712*    MOVE WGLOB-USER-LANG   TO WDOCM-DOC-LANG-CD.
554712*
554712*
554712* READ RECORD
554712*
554712*    PERFORM  DOCM-1000-READ
554712*        THRU DOCM-1000-READ-X.
554712*
554712*    IF WDOCM-IO-NOT-FOUND
554712*        PERFORM  9750-BROWSE-DOCM
554712*            THRU 9750-BROWSE-DOCM-X
554712*    END-IF.

013578*9700-GET-DOCUMENT-DESCR-X.
013578*    EXIT.
      /
554712*-----------------
554712*9750-BROWSE-DOCM.
554712*-----------------
554712*
554712*****************************************************************
554712* BROWSE DOCUMENT MASTER:   FIND THE FIRST DOCUMENT MASTER
554712* RECORD WITH THE SAME DOCUMENT NAME AS THE CURRENT ASSEMBLY
554712* RECORD.   IF NONE ARE FOUND THEN SET THE DOCUMENT DESCRIPTION
554712* TO SPACES.
554712*****************************************************************
554712*
554712*
554712* SAVE KEY FOR ERROR MESSAGE IN CASE BROWSE DOES NOT
554712* FIND THE ANY RECORD WITH THE DESIRED DOCUMENT NAME
554712*
554712*    MOVE WDOCM-KEY         TO WS-DOCM-KEY.
554712*
554712*
554712* SETUP BROWSE KEY
554712*
554712*    MOVE LOW-VALUES        TO WDOCM-DOC-LANG-CD.
554712*    MOVE WDOCM-DOC-ID      TO WDOCM-ENDBR-DOC-ID.
554712*    MOVE HIGH-VALUES       TO WDOCM-ENDBR-DOC-LANG-CD.
554712*
554712*
554712* BROWSE FILE
554712*
554712*    PERFORM  DOCM-1000-BROWSE
554712*        THRU DOCM-1000-BROWSE-X.
554712*
554712*    IF WDOCM-IO-OK
554712*        PERFORM  DOCM-2000-READ-NEXT
554712*            THRU DOCM-2000-READ-NEXT-X
554712*
554712*        IF WDOCM-IO-OK
554712*            NEXT SENTENCE
554712*        ELSE
554712*MSG:  DOCUMENT MASTER RECORD NOT FOUND
554712*            MOVE WS-DOCM-KEY  TO WGLOB-MSG-PARM (1)
554712*            MOVE 'NS02700001' TO WGLOB-MSG-REF-INFO
554712*            PERFORM  0260-1000-GENERATE-MESSAGE
554712*                THRU 0260-1000-GENERATE-MESSAGE-X
554712*            MOVE SPACES       TO RDOCM-DOC-DESC-TXT
554712*            MOVE 'N'          TO WS-DOC-DESCR-IND
554712*        END-IF
554712*    ELSE
554712*MSG:  DOCUMENT MASTER RECORD NOT FOUND
554712*        MOVE WS-DOCM-KEY      TO WGLOB-MSG-PARM (1)
554712*        MOVE 'NS02700001'     TO WGLOB-MSG-REF-INFO
554712*        PERFORM  0260-1000-GENERATE-MESSAGE
554712*            THRU 0260-1000-GENERATE-MESSAGE-X
554712*        MOVE SPACES           TO RDOCM-DOC-DESC-TXT
554712*        MOVE 'N'              TO WS-DOC-DESCR-IND
554712*        GO TO  9750-BROWSE-DOCM-X
554712*    END-IF.
554712*
554712*    PERFORM  DOCM-3000-END-BROWSE
554712*        THRU DOCM-3000-END-BROWSE-X.
554712*
554712*9750-BROWSE-DOCM-X.
554712*    EXIT.
023118/
023118*--------------------------
023118 9990-INIT-WORKING-STORAGE.
023118*--------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023118
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE                        WS-PGM-WORK-AREA.
025970     INITIALIZE                        TASMB-TABLE-VALID.
025970     INITIALIZE                        WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE                        WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-DEFAULT-NUM-DISPLAY-LINES  TO TRUE.
025970     SET WS-DEFAULT-TWRK-KEY           TO TRUE.
025970
025970     MOVE MIR-BUS-FCN-ID               TO WS-BUS-FCN-ID.
023118
023118 9990-INIT-WORKING-STORAGE-X.
023118     EXIT.
      /
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY ASMB
014221                         '$VAR2' BY 'ASMB'.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
010302 COPY CCPNSCOM.
      /
010302*COPY CCPEILOC.
010302 COPY CCPELCGP.
       COPY NCPEASMP.
      /
007685*COPY NCPEASMT.
      /
013578*COPY NCPEDOCM.
      /
       COPY NCPCASMB.
      /
      *****************************************************************
      *  LINKAGE COPYBOOKS
      *****************************************************************
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
      /
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOKS
      ****************************************************************
014660*COPY XCPPMEXT.
018764*COPY XCCL0260.
018764 COPY XCPL0260.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
       COPY NCPAASMB.
       COPY NCPBASMB.
       COPY NCPNASMB.
       COPY NCPUASMB.
       COPY NCPXASMB.
      /
554712*COPY NCPBDOCM.
023447*COPY NCPNDOCM.
023447 COPY XCPNDOCM.
      /
       COPY CCPNEDIT.
557708*COPY XCCPHNDL.
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM NSOM0270                     **
      *****************************************************************
