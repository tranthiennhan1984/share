      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM1921.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM1921                                         **
      **  REMARKS:  THIS MODULE PERFORMS THE TABLE CREATE FUNCTION   **
      **            FOR THE CLNM TABLE                               **
      **                                                             **
      **  DOMAIN :  CL                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ARCHITECTURAL CHANGES                            **
015508**  6.0       NAME ENHANCEMENTS                                **
014221**  6.2       LOGICAL RECORD LOCKING                           **
016548**  6.2       CHANGE COMP TO BINARY                            **
018732**  6.3       CLIENT RETRIEVAL ENHANCEMENTS                    **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
028298**  6.7       LINKS FOR FUTURE DATED TRANSACTIONS              **
034783**  7.0       INIT COPYBOOK IN PROCESS DRIVER                  **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM1921'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

014590*COPY XCWL0030.
      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                 PIC X(04).
               88  WS-BUS-FCN-CREATE         VALUE '1921'.
025970*    05  WS-TWRK-KEY                   PIC X(04)
025970*                                      VALUE '1920'.

016548*    05  WS-GR                         PIC 9(04) COMP SYNC.
016548     05  WS-GR                         PIC 9(04) BINARY SYNC.
016548*    05  WS-SEQ                        PIC 9(04) COMP SYNC.
016548     05  WS-SEQ                        PIC 9(04) BINARY SYNC.
016548*    05  WS-MAX-GR        VALUE 2      PIC 9(04) COMP SYNC.
025970*    05  WS-MAX-GR        VALUE 2      PIC 9(04) BINARY SYNC.
016548*    05  WS-MAX-SEQ       VALUE 3      PIC 9(04) COMP SYNC.
025970*    05  WS-MAX-SEQ       VALUE 3      PIC 9(04) BINARY SYNC.
           05  WS-PIC-999                    PIC 9(3).
               88  WS-PIC-001-003            VALUE 0 THRU 3.
025970*    05  WS-MAX-CLNM      VALUE 3      PIC 9(04) BINARY SYNC.
018732     05  WS-CLNM-COUNT                 PIC 9(04) BINARY SYNC.
020478     05  WS-EFF-DT                     PIC X(10).
020478     05  WS-DUR                        PIC 9(03).


025970 01  WS-CONSTANT-FIELDS.
025970     05  WS-TWRK-KEY                   PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT       VALUE '1920'.
025970     05  WS-MAX-GR                     PIC 9(04) BINARY SYNC.
025970         88  WS-MAX-GR-DEFAULT         VALUE 2.
025970     05  WS-MAX-SEQ                    PIC 9(04) BINARY SYNC.
025970         88  WS-MAX-SEQ-DEFAULT        VALUE 3.
025970     05  WS-MAX-CLNM                   PIC 9(04) BINARY SYNC.
025970         88  WS-MAX-CLNM-DEFAULT       VALUE 3.


      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
014221 COPY CCWWLOCK.
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFWCLI.
       COPY CCFRCLI.
      /
       COPY CCFWCLNM.
       COPY CCFRCLNM.
020478/
020478 COPY CCFWCLRQ.
020478 COPY CCFRCLRQ.
020478/
020478 COPY CCFWPCOM.
020478 COPY CCFRPCOM.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                          *
      *****************************************************************
028298 COPY CCWL2626.
020478 COPY XCWLDTLK.
036742*COPY XCWL0035.
       COPY XCWL0280.
020874 COPY XCWL0290.
020478 COPY XCWL1640.
020478 COPY XCWL1670.
020478 COPY XCWL1680.
014221 COPY XCWL8090.
018764*COPY XCWLPTR.
      /
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY CCWM1921.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

034783     PERFORM  INIT-1000-INITIALIZE
034783         THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

028298     PERFORM  FCCK-1000-CHECK-CLIENT
028298         THRU FCCK-1000-CHECK-CLIENT-X.
028298
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           MOVE MIR-BUS-FCN-ID
             TO WS-BUS-FCN-ID.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-CREATE
                    PERFORM  2000-CREATE
                        THRU 2000-CREATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID
                      TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM1921'
                      TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'
025999              MOVE 'XS00000237'
                      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST
                      TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *------------
       2000-CREATE.
      *------------

           PERFORM  2100-VALIDATE-KEYS
               THRU 2100-VALIDATE-KEYS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED
                 TO TRUE
               GO TO 2000-CREATE-X
           END-IF.

      *
      *  EDIT AND CREATE THE RECORDS
      *
           PERFORM  2200-EDIT-CREATE
               THRU 2200-EDIT-CREATE-X
            VARYING WS-GR FROM 1 BY 1
              UNTIL WS-GR > WS-MAX-GR.

      *
      *  UPDATE THE CLIENT RECORD
      *
020478*    EVALUATE TRUE
020478*
020478*        WHEN RCLI-PREV-INFO-NO-NAAD-INFO
020478*             SET  RCLI-PREV-INFO-NAME-ONLY     TO TRUE
020478*
020478*        WHEN RCLI-PREV-INFO-ADDR-ONLY
020478*             SET  RCLI-PREV-INFO-NAME-AND-ADDR TO TRUE
020478*
020478*    END-EVALUATE.

           PERFORM  CLI-2000-REWRITE
               THRU CLI-2000-REWRITE-X.

014221     MOVE MIR-CLI-ID          TO  WCLI-CLI-ID.
014221     PERFORM  CLI-1000-READ-TWRK-TS
014221         THRU CLI-1000-READ-TWRK-TS-X.

       2000-CREATE-X.
           EXIT.
      /

      *--------------------
       2100-VALIDATE-KEYS.
      *--------------------
      *
      *  FIND THE SEQUENCE NUMBER OF THE RECORD TO CREATE
      *
020478*    PERFORM  2110-FIND-SEQ-NUM
020478*        THRU 2110-FIND-SEQ-NUM-X
020478*     VARYING WS-SEQ FROM 1 BY 1
020478*       UNTIL WS-SEQ > WS-MAX-SEQ.
020478*
020478*    IF MIR-CLI-INDV-SEQ-NUM = '000'
020478*    OR MIR-CLI-INDV-SEQ-NUM = SPACES
020478*MSG:  SEQUENCE NUMBER (@1) MUST BE NUMERIC BETWEEN 001 - 003
020478*        MOVE MIR-CLI-INDV-SEQ-NUM
020478*                               TO WGLOB-MSG-PARM (1)
020478*        MOVE 'CS19210001'      TO WGLOB-MSG-REF-INFO
020478*        PERFORM  0260-1000-GENERATE-MESSAGE
020478*            THRU 0260-1000-GENERATE-MESSAGE-X
020478*        GO TO 2100-VALIDATE-KEYS-X
020478*    END-IF.
020478*
020478*    IF MIR-CLI-INDV-SEQ-NUM NOT = SPACES
020478*        MOVE 'Y'               TO L0280-SPACE-PERMITTED-IND
020478*        MOVE 'N'               TO L0280-SIGN-IND
020478*        MOVE 0                 TO L0280-PRECISION
020478*        MOVE 3                 TO L0280-LENGTH
020478*        MOVE 3                 TO L0280-INPUT-SIZE
020478*        MOVE MIR-CLI-INDV-SEQ-NUM
020478*                               TO L0280-INPUT-DATA
020478*        PERFORM  0280-1000-NUMERIC-EDIT
020478*            THRU 0280-1000-NUMERIC-EDIT-X
020478*
020478*        IF L0280-OK
020478*            CONTINUE
020478*        ELSE
020478*MSG:  SEQUENCE NUMBER (@1) MUST BE NUMERIC BETWEEN 001 - 003
020478*            MOVE MIR-CLI-INDV-SEQ-NUM
020478*                               TO WGLOB-MSG-PARM (1)
020478*            MOVE 'CS19210001'  TO WGLOB-MSG-REF-INFO
020478*            PERFORM  0260-1000-GENERATE-MESSAGE
020478*                THRU 0260-1000-GENERATE-MESSAGE-X
020478*            GO TO 2100-VALIDATE-KEYS-X
020478*        END-IF
020478*
020478*        MOVE L0280-OUTPUT  TO WS-PIC-999
020478*        MOVE L0280-OUTPUT  TO L0290-INPUT-V00
020478*
020478*        IF  WS-PIC-001-003
020874*            MOVE WS-PIC-999    TO MIR-CLI-INDV-SEQ-NUM
020478*            MOVE ZERO          TO L0290-PRECISION
020478*            MOVE LENGTH OF MIR-CLI-INDV-SEQ-NUM
020478*                               TO L0290-MAX-OUT-LEN
020478*            PERFORM 0290-2000-FORMAT-FOR-MIR
020478*               THRU 0290-2000-FORMAT-FOR-MIR-X
020478*            MOVE L0290-OUTPUT-DATA TO MIR-CLI-INDV-SEQ-NUM
020478*        ELSE
020478*MSG:  SEQUENCE NUMBER (@1) MUST BE NUMERIC BETWEEN 001 - 003
020478*            MOVE MIR-CLI-INDV-SEQ-NUM
020478*                               TO WGLOB-MSG-PARM (1)
020478*            MOVE 'CS19210001'  TO WGLOB-MSG-REF-INFO
020478*            PERFORM  0260-1000-GENERATE-MESSAGE
020478*                THRU 0260-1000-GENERATE-MESSAGE-X
020478*            GO TO 2100-VALIDATE-KEYS-X
020478*        END-IF
020478*
020478*    END-IF.
020478
020478     IF  MIR-CLI-INDV-EFF-DT = SPACES
020478         MOVE WGLOB-PROCESS-DATE   TO WS-EFF-DT
020478     ELSE
020478         MOVE MIR-CLI-INDV-EFF-DT
020478                                   TO L1640-EXTERNAL-DATE
020478         PERFORM  1640-7000-MIR-TO-INT
020478             THRU 1640-7000-MIR-TO-INT-X
020478
020478         IF  L1640-NOT-VALID
020478*MSG : INVALID NAME EFFECTIVE DATE
020478             MOVE 'CS19210005'     TO WGLOB-MSG-REF-INFO
020478             PERFORM  0260-1000-GENERATE-MESSAGE
020478                 THRU 0260-1000-GENERATE-MESSAGE-X
020478             GO TO 2100-VALIDATE-KEYS-X
020478         ELSE
020478             MOVE L1640-INTERNAL-DATE
020478                                   TO WS-EFF-DT
020478         END-IF
020478     END-IF.
020478
020478     PERFORM  PCOM-1000-READ
020478         THRU PCOM-1000-READ-X.
020478     MOVE ZERO                     TO L1680-NUMBER-OF-YEARS.
020478     MOVE RPCOM-CO-FUT-RQST-MO-DUR TO L1680-NUMBER-OF-MONTHS.
020478     MOVE ZERO                     TO L1680-NUMBER-OF-DAYS.
020478     MOVE WGLOB-PROCESS-DATE       TO L1680-INTERNAL-1.
020478
020478     PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
020478         THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.
020478
020478     IF  L1680-INTERNAL-2 < WS-EFF-DT
020478*MSG : EFFECTIVE DATE NOT ALLOWED BEYOND (@1) MONTHS OF CURRENT
020478*      PROCESSING DATE
020478         MOVE 'CS00000254'         TO WGLOB-MSG-REF-INFO
020478         MOVE RPCOM-CO-FUT-RQST-MO-DUR
020478                                   TO WS-DUR
020478         MOVE WS-DUR               TO WGLOB-MSG-PARM (1)
020478         PERFORM  0260-1000-GENERATE-MESSAGE
020478             THRU 0260-1000-GENERATE-MESSAGE-X
020478         GO TO 2100-VALIDATE-KEYS-X
020478     END-IF.

020478     MOVE WS-EFF-DT                TO L1640-INTERNAL-DATE.
020478     PERFORM  1640-8000-INTERNAL-TO-MIR
020478         THRU 1640-8000-INTERNAL-TO-MIR-X.
020478     MOVE L1640-EXTERNAL-DATE      TO MIR-CLI-INDV-EFF-DT.
020478
020478     PERFORM  7000-BUILD-KEYS
020478         THRU 7000-BUILD-KEYS-X.
020478
020478     MOVE ZERO                     TO WS-CLNM-COUNT.
020478     PERFORM  2400-CLNM-READ
020478         THRU 2400-CLNM-READ-X
020478         VARYING WS-GR FROM 1 BY 1
020478         UNTIL   WS-GR > WS-MAX-CLNM
020478         OR      WS-CLNM-COUNT NOT = ZERO.
020478
020478     IF  WS-CLNM-COUNT NOT = ZERO
020478*MSG:  CLIENT NAME RECORD ALREADY EXISTS FOR DATE ENTERED
020478         MOVE 'CS19210003'      TO WGLOB-MSG-REF-INFO
020478         PERFORM  0260-1000-GENERATE-MESSAGE
020478             THRU 0260-1000-GENERATE-MESSAGE-X
020478         GO TO 2100-VALIDATE-KEYS-X
020478     END-IF.

      *
      *    VALIDATE THE CLIENT EXISTS, AND LOCK FOR UPDATE OF PREV INFO
      *
           MOVE MIR-CLI-ID             TO WCLI-CLI-ID.

           PERFORM  CLI-1000-READ-FOR-UPDATE
               THRU CLI-1000-READ-FOR-UPDATE-X.

           IF  NOT WCLI-IO-OK
      *MSG:  CLIENT (@1) DOES NOT EXIST
               MOVE WCLI-CLI-ID        TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000076'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
           END-IF.

       2100-VALIDATE-KEYS-X.
           EXIT.

020478*-----------------
020478*2110-FIND-SEQ-NUM.
020478*-----------------
020478*
020478*  THE RECORD SHOULD NOT EXIST ON A CREATE
020478*
020874*    MOVE WS-SEQ                 TO WS-PIC-999.
020874*    MOVE WS-PIC-999             TO MIR-CLI-INDV-SEQ-NUM.
020478*    MOVE WS-SEQ                TO L0290-INPUT-V00.
020478*    MOVE ZERO                  TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-CLI-INDV-SEQ-NUM
020478*                               TO L0290-MAX-OUT-LEN.
020478*    PERFORM 0290-2000-FORMAT-FOR-MIR
020478*       THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA     TO MIR-CLI-INDV-SEQ-NUM.
020478*
020478*    PERFORM  7000-BUILD-KEYS
020478*        THRU 7000-BUILD-KEYS-X.
020478*
018732*    PERFORM  CLNM-1000-READ
018732*        THRU CLNM-1000-READ-X.
020478*    MOVE ZERO                   TO WS-CLNM-COUNT.
020478*    PERFORM  2400-CLNM-READ
020478*        THRU 2400-CLNM-READ-X
020478*        VARYING WS-GR FROM 1 BY 1
020478*        UNTIL   WS-GR > WS-MAX-CLNM
020478*        OR      WS-CLNM-COUNT NOT = ZERO.
020478*
018732*    IF  WCLNM-IO-OK
020478*    IF  WS-CLNM-COUNT NOT = ZERO
020478*    AND WS-SEQ = WS-MAX-SEQ
020478*MSG:  ALL PREVIOUS NAMES HAVE BEEN CREATED - USE UPDATE
020478*        MOVE 'CS19210002'      TO WGLOB-MSG-REF-INFO
020478*        PERFORM  0260-1000-GENERATE-MESSAGE
020478*            THRU 0260-1000-GENERATE-MESSAGE-X
020478*    END-IF.

018732*    IF  NOT WCLNM-IO-OK
020478*    IF  WS-CLNM-COUNT = ZERO
020478*        MOVE WS-MAX-SEQ         TO WS-SEQ
020478*    END-IF.
020478*
020478*2110-FIND-SEQ-NUM-X.
020478*    EXIT.
      /

      *-----------------
       2200-EDIT-CREATE.
      *-----------------
      *
      *  THE RECORD SHOULD NOT EXIST ON A CREATE
      *
           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           IF  WS-GR > 1

               IF  WGLOB-COUNTRY-JAPAN
                   CONTINUE
               ELSE
                   GO TO 2200-EDIT-CREATE-X
               END-IF

               SET  WCLNM-CLI-INDV-GR-KANJI    TO TRUE

           END-IF.

           PERFORM  CLNM-1000-READ
               THRU CLNM-1000-READ-X.

           IF  WCLNM-IO-OK
      *MSG: 'RECORD @1 ALREADY EXISTS'
               MOVE WCLNM-KEY
                 TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000003'
                 TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2200-EDIT-CREATE-X
           END-IF.
      *
      *  CREATE THE NEW RECORD
      *
           PERFORM  CLNM-1000-CREATE
               THRU CLNM-1000-CREATE-X.

020478     IF  RCLNM-CLI-INDV-EFF-DT > WGLOB-PROCESS-DATE
036742*        PERFORM  0035-5000-TIMESTAMP
036742*            THRU 0035-5000-TIMESTAMP-X
020478         MOVE RCLNM-CLI-ID  TO  WCLRQ-CLI-ID
036742*        MOVE L0035-TIMESTAMP
036742         MOVE WGLOB-TRXN-GR-TS
020478                            TO  WCLRQ-CLI-RQST-CREAT-TS
020478         PERFORM  CLRQ-1000-CREATE
020478             THRU CLRQ-1000-CREATE-X
020478         MOVE RCLNM-CLI-INDV-EFF-DT
020478                            TO RCLRQ-CLI-RQST-EFF-DT
020478         SET RCLRQ-CLI-RQST-INDV-NM-CHNG
020478                            TO TRUE
020478         MOVE MIR-BUS-FCN-ID
020478                            TO RCLRQ-BUS-FCN-ID
020478         MOVE WGLOB-USER-ID TO RCLRQ-USER-ID
020478         PERFORM  CLRQ-1000-WRITE
020478             THRU CLRQ-1000-WRITE-X
036742*        MOVE L0035-TIMESTAMP
036742         MOVE WGLOB-TRXN-GR-TS
020478                            TO RCLNM-CLI-RQST-CREAT-TS
020478     END-IF.

           PERFORM  CLNM-1000-WRITE
               THRU CLNM-1000-WRITE-X.

020478*MSG: CLIENT NAME RECORD CREATED WITH EFFECTIVE DATE @1
020478     MOVE 'CS19210004'            TO WGLOB-MSG-REF-INFO
020478     MOVE MIR-CLI-INDV-EFF-DT     TO WGLOB-MSG-PARM (1)
020478     PERFORM  0260-1000-GENERATE-MESSAGE
020478         THRU 0260-1000-GENERATE-MESSAGE-X.

       2200-EDIT-CREATE-X.
           EXIT.
018732/
018732*---------------
018732 2400-CLNM-READ.
018732*---------------
018732     EVALUATE  WS-GR
018732         WHEN  1
018732             SET WCLNM-CLI-INDV-GR-ALPHA TO TRUE
018732         WHEN  2
018732             SET WCLNM-CLI-INDV-GR-KANJI TO TRUE
018732         WHEN  3
018732             SET WCLNM-CLI-INDV-GR-KATAKANA TO TRUE
018732     END-EVALUATE.
018732
018732     PERFORM  CLNM-1000-READ
018732         THRU CLNM-1000-READ-X.
018732     IF  WCLNM-IO-OK
018732         ADD 1              TO WS-CLNM-COUNT
018732     END-IF.
018732
018732
018732 2400-CLNM-READ-X.
018732     EXIT.

      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES                 TO WCLNM-KEY.
           MOVE MIR-CLI-ID                 TO WCLNM-CLI-ID.

           EVALUATE TRUE

               WHEN WGLOB-COUNTRY-JAPAN
                    SET  WCLNM-CLI-INDV-GR-KATAKANA
                      TO TRUE

               WHEN OTHER
                    SET  WCLNM-CLI-INDV-GR-ALPHA
                      TO TRUE

           END-EVALUATE.

020478*    SET  WCLNM-CLI-INDV-NM-TYP-PREV TO TRUE.
020478*    MOVE MIR-CLI-INDV-SEQ-NUM       TO WCLNM-CLI-INDV-SEQ-NUM.
020478     MOVE WS-EFF-DT                  TO WCLNM-CLI-INDV-EFF-DT.

       7000-BUILD-KEYS-X.
           EXIT.


      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES
             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE
             TO WGLOB-REF-COMPANY-CODE.
           SET  WGLOB-REF-CLIENT
             TO TRUE.
           MOVE MIR-CLI-ID
             TO WGLOB-REF-CLIENT-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
023514
025970*    CONTINUE.
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
025970
028298     PERFORM  2626-0000-INIT-PARM-INFO
028298         THRU 2626-0000-INIT-PARM-INFO-X.
028298 
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE  WLOCK-TWRK-TIMESTAMP-INFO.
025970
025970     INITIALIZE  WLOCK-TWRK-OTHER-INFO.
025970     SET  WS-MAX-GR-DEFAULT              TO TRUE.
025970     SET  WS-MAX-CLNM-DEFAULT            TO TRUE.
025970     SET  WS-MAX-SEQ-DEFAULT             TO TRUE.
025970     SET  WS-TWRK-KEY-DEFAULT            TO TRUE.
025970     MOVE MIR-BUS-FCN-ID                 TO WS-BUS-FCN-ID.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.


      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
028298 COPY CCPPFCCK.
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY CLI
014221                         '$VAR2' BY 'CLI'.
034783 COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
018764*COPY XCCL0260.
028298 COPY CCPS2626.
028298 COPY CCPL2626.
036742*COPY XCPL0035.
018764 COPY XCPL0260.
025970 COPY XCPS1670.
025970 COPY XCPS8090.
025970 COPY XCPS0280.
       COPY XCPL0280.
020874 COPY XCPL0290.
020874 COPY XCPS0290.
025970 COPY XCPS1640.
020478 COPY XCPL1640.
025970 COPY XCPS1680.
020478 COPY XCPL1680.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
014221 COPY CCPNCLI.
       COPY CCPUCLI.
       COPY CCPNCLNM.
       COPY CCPACLNM.
       COPY CCPCCLNM.
020478 COPY CCPACLRQ.
020478 COPY CCPCCLRQ.
020478 COPY CCPNPCOM.
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **              END OF PROGRAM CSOM1921                        **
      *****************************************************************
