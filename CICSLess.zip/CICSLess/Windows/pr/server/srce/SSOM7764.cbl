      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. SSOM7764.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  SSOM7764                                         **
      **  REMARKS:  THIS MODULE PERFORMS TABLE LIST FUNCTION         **
      **            FOR THE FUTP TABLE                               **
      **                                                             **
      **  DOMAIN :  PR                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
021239**  6.4       FUND UNIT VALUE                                  **
026070**  6.6       ERROR HANDLER                                    **
025999**  6.6       MESSAGE CORRECTION                               **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026766**  6.6       PERFORMANCE MONITORING                           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM7764'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                       PIC X(04).
               88  WS-BUS-FCN-LIST                 VALUE '7764'.
           05  WS-SUB                              PIC S9(04) BINARY.
           05  WS-MAX-LIST-LINES                   PIC S9(04) BINARY.

       01  WS-CONSTANT-AREA.
           05  FILLER                              PIC X(01).
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
      /
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
      /
       COPY SCFWFUTP.
       COPY SCFRFUTP.
      /
      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************
      /
       COPY XCWLDTLK.
       COPY XCWL0290.
       COPY XCWL1640.
      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY SCWM7764.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.
 
026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME        
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.    

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME         
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.      
 
       0000-MAINLINE-X.
           GOBACK.

      /
      *--------------------
       1000-PROCESS-REQUEST.
      *--------------------

           PERFORM  0290-1000-BUILD-PARM-INFO
               THRU 0290-1000-BUILD-PARM-INFO-X.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-LIST
                    PERFORM  2000-LIST
                        THRU 2000-LIST-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID    TO WGLOB-MSG-PARM (1)
                    MOVE 'SSOM7764'        TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'      TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'      TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET  MIR-RETRN-INVALD-RQST  TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.

      /
      *----------
       2000-LIST.
      *----------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

           PERFORM  7000-BUILD-KEYS
               THRU 7000-BUILD-KEYS-X.

           PERFORM  FUTP-1000-BROWSE
               THRU FUTP-1000-BROWSE-X.

           PERFORM  FUTP-2000-READ-NEXT
               THRU FUTP-2000-READ-NEXT-X.

           IF  WFUTP-IO-EOF
               PERFORM  FUTP-3000-END-BROWSE
                   THRU FUTP-3000-END-BROWSE-X
      *MSG: 'NO RECORDS FOUND TO DISPLAY'
               MOVE 'XS00000034'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-LIST-X
           END-IF.

           MOVE ZERO                       TO WS-SUB.
           PERFORM  2010-BROWSE-FUTP
               THRU 2010-BROWSE-FUTP-X
               UNTIL   WS-SUB > WS-MAX-LIST-LINES
               OR      WFUTP-IO-EOF.

           IF  WFUTP-IO-EOF
               CONTINUE
           ELSE
               SET WGLOB-MORE-DATA-EXISTS    TO TRUE
               MOVE RFUTP-FND-UNIT-TYP-CD    TO MIR-FND-UNIT-TYP-CD
           END-IF.

           PERFORM  FUTP-3000-END-BROWSE
               THRU FUTP-3000-END-BROWSE-X.

       2000-LIST-X.
           EXIT.


      *-----------------
       2010-BROWSE-FUTP.
      *-----------------

           ADD 1                    TO WS-SUB.
           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

           PERFORM  FUTP-2000-READ-NEXT
               THRU FUTP-2000-READ-NEXT-X.

       2010-BROWSE-FUTP-X.
           EXIT.
      /
      *----------------
       7000-BUILD-KEYS.
      *----------------

           MOVE LOW-VALUES            TO WFUTP-KEY.
           MOVE HIGH-VALUES           TO WFUTP-ENDBR-KEY.

           MOVE MIR-FND-ID            TO WFUTP-FND-ID.
           MOVE MIR-FND-ID            TO WFUTP-ENDBR-FND-ID.
           MOVE MIR-FND-UNIT-TYP-CD   TO WFUTP-FND-UNIT-TYP-CD.

       7000-BUILD-KEYS-X.
           EXIT.

      /

      *-----------------------
       9000-BLANK-DATA-FIELDS.
      *-----------------------

           MOVE SPACES                TO MIR-OUTPUT-AREA.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *---------------------------
       9200-MOVE-RECORD-TO-SCREEN.
      *---------------------------

           IF  WS-SUB > WS-MAX-LIST-LINES
               GO TO 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           MOVE RFUTP-FND-ID
             TO MIR-FND-ID-T (WS-SUB).

           MOVE RFUTP-FND-UNIT-TYP-CD
             TO MIR-FND-UNIT-TYP-CD-T (WS-SUB).

           MOVE RFUTP-FND-UNIT-QTY         TO L0290-INPUT-V06.
           MOVE 6                          TO L0290-PRECISION.
           MOVE LENGTH OF MIR-FND-UNIT-QTY-T (WS-SUB)
                                           TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA
             TO MIR-FND-UNIT-QTY-T (WS-SUB).

           MOVE RFUTP-FND-UNIT-END-DT      TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE
             TO MIR-FND-UNIT-END-DT-T (WS-SUB).

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES             TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE TO WGLOB-REF-COMPANY-CODE.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.
      /
      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------
 
026766     PERFORM  TIMR-0000-INIT-PARM-INFO    
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.

           MOVE MIR-BUS-FCN-ID    TO WS-BUS-FCN-ID.

           COMPUTE WS-MAX-LIST-LINES =
                     LENGTH OF MIR-FND-ID-G
                   / LENGTH OF MIR-FND-ID-T (1).

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.
 
       COPY XCPPINIT.
       COPY XCPPEXIT.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0260.
       COPY XCPS0290.
       COPY XCPL0290.
025970 COPY XCPS1640.
       COPY XCPL1640.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY SCPBFUTP.
      /
      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.

      *****************************************************************
      **                 END OF PROGRAM XSOM7764
      *****************************************************************
