      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. CSOM7902.

       COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  CSOM7902                                         **
      **  REMARKS:  THIS IS THE UPDATE PROCESS DRIVER FOR THE OFF    **
      **            ANNIVERSARY POLICY UPDATE                        **
      **                                                             **
      **            IT MANAGES THE CHANGE ON THE POLICY MODAL        **
      **            FREQUENCIES, BILLING TYPE IN COMBINATION WITH FEE**
      **            FACTOR AND MODAL PREMIUM                         **
      **                                                             **
      **            THE EDITS AND UPDATES ARE PERFORMED THROUGH THE  **
      **            POLICY MAINTENANCE FUNCTION DRIVER.              **
      **                                                             **
      **  DOMAIN :  PO                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
023435**  6.5       OFF ANNIVERSARY PREMIUM                          **
020478**  6.6       FUTURE DATED TRANSACTION                         **
025970**  6.6       WORKING STORAGE INITIALISATION                   **
026070**  6.6       ERROR HANDLER                                    **
025102**  6.6       SUNDRY AMOUNT UPDATES                            **
025999**  6.6       MESSAGE CORRECTION                               **
026766**  6.6       PERFORMANCE MONITORING                           **
031037**  7.0       TAMRA OFF ANNIVERSARY PROCESSING                 **
030054**  7.0       PHST SEQUENCE NUMBER EXPANSION                   **
036742**  7.1       REPLACE TIMESTAMP FIELD IN PRIMARY KEY           **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSOM7902'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.

       COPY SQLCA.

      /
       01  WS-WORKING-STORAGE.
           05  WS-BUS-FCN-ID                   PIC X(04).
               88  WS-BUS-FCN-UPDATE           VALUE '7902'.

           05  WS-OFF-ANNV-POL-SW              PIC X(01).
               88  WS-OFF-ANNV-POL             VALUE 'Y'.
               88  WS-OFF-ANNV-POL-NOT-ALLOWED VALUE 'N'.
           05  WS-MODE                         PIC 9(02).
           05  WS-LAST-ANNV-DT                 PIC X(10).
           05  WS-OFFANNV-PD-TO-DT             PIC X(10).
           05  WS-POL-CRNT-MODE-FCT            PIC X(09).
           05  WS-POL-PFEE-FCT                 PIC X(09).
           05  WS-REDO-SWITCH                  PIC X(01).
               88  WS-REDO-OK                  VALUE 'Y'.
               88  WS-REDO-NOT-OK              VALUE 'N'.
           05  WS-EFF-DT                       PIC X(10).
           05  WS-ACTV-TYP-ID                  PIC 9(04).
               88 WS-ACTV-TYP-BILL-CHNG        VALUES
                                                    1003
                                                    1004
                                                    1005
020478*                                             1006
020478*                                             1020
020478*                                             1021
020478*                                             1022
020478*                                             1023
020478*                                             1024
020478*                                             1026
020478*                                             1027.
020478                                              1006.
020478     05  WS-BILL-CHNG-IND                PIC X(01).
020478         88  WS-BILL-CHNG-NXT            VALUE 'N'.
020478         88  WS-BILL-CHNG-CURR           VALUE 'C'.
020478     05  WS-HOLD-AREA.
020478         10  WS-H-POL-OFFANNV-PD-DT      PIC X(10).
020478         10  WS-H-POL-PMT-DRW-DY         PIC S9(3)      COMP-3.
020478         10  WS-H-POL-SNDRY-AMT          PIC S9(11)V99  COMP-3.
020478         10  WS-H-POL-SNDRY-REASN-CD     PIC X(01).
020478         10  WS-H-MODE-FCT-RESTR-IND     PIC X(01).
020478         10  WS-H-POL-CRNT-MODE-FCT      PIC S9(2)V9(7) COMP-3.
020478         10  WS-H-POL-PFEE-RESTR-IND     PIC X(01).
020478         10  WS-H-POL-PFEE-FCT           PIC S9(2)V9(7) COMP-3.
020478         10  WS-H-POL-BILL-TYP-CD        PIC X(01).
020478         10  WS-H-POL-BILL-MODE-CD       PIC X(02).

       01  WS-CONSTANT-AREA.
025970*    05  WS-TWRK-KEY                     PIC X(04)
025970*                                        VALUE '7902'.
025970
025970     05  WS-TWRK-KEY                     PIC X(04).
025970         88 WS-TWRK-KEY-DEFAULT          VALUE '7902'.
      /
      *****************************************************************
      *  COMMON COPYBOOKS                                             *
      *****************************************************************
       COPY XCWEBLCH.
      /
       COPY XCWWWKDT.
      /
       COPY CCWWINDX.
      /
       COPY XCWL8090.
      /
       COPY XCWLDTLK.
030054 COPY XCWWCNST.
      *****************************************************************
      *  I/O COPYBOOKS                                                *
      *****************************************************************
       COPY CCFRPH.
       COPY CCFWPH.
      /
       COPY CCFWPOL.
       COPY CCFRPOL.
       COPY CCFHPOL.
      /
020478     EXEC SQL INCLUDE CCFRPORQ END-EXEC.
020478     EXEC SQL INCLUDE CCFWPORQ END-EXEC.
020478/
       COPY CCFWCVG.
       COPY CCFRCVG.
      /
       COPY CCWWCVGS.
      /
       COPY CCWWLOCK.
      /
       COPY CCFRPHST.
       COPY CCFWPHST.
      /

      *****************************************************************
      *  CALLED MODULE PARAMETER INFORMATION                         *
      *****************************************************************

       COPY CCWL0201.

       COPY CCWL0289.

       COPY CCWL0620.
031037
031037 COPY CCWL2408.

       COPY CCWL2420.

       COPY CCWL2430.

020478 COPY CCWL2625.
020478
020478 COPY CCWL2626.
020478
       COPY CCWL3330.

       COPY CCWL4750.

       COPY CCWL4780.

       COPY CCWL5400.

       COPY CCWLPGA.

020478 COPY XCWL0035.
020478
       COPY XCWL0280.

       COPY XCWL1640.

       COPY XCWL1660.

       COPY XCWL1670.

       COPY XCWL1680.

       COPY XCWL0290.

       COPY XCWL8960.

      *****************
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.

       COPY CCWM7902.
      /
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.
      *--------------
       0000-MAINLINE.
      *--------------

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

           PERFORM  1000-PROCESS-REQUEST
               THRU 1000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

       0000-MAINLINE-X.
           GOBACK.

      /
      *---------------------
       1000-PROCESS-REQUEST.
      *---------------------

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.

           EVALUATE TRUE

               WHEN WS-BUS-FCN-UPDATE
                    PERFORM  2000-UPDATE
                        THRU 2000-UPDATE-X

               WHEN OTHER
      *MSG:  INVALID BUSINESS FUNCTION @1 FOR PROGRAM @2
                    MOVE MIR-BUS-FCN-ID   TO WGLOB-MSG-PARM (1)
                    MOVE 'CSOM7902'       TO WGLOB-MSG-PARM (2)
025999*             MOVE 'XS00000000'     TO WGLOB-MSG-REF-INFO
025999              MOVE 'XS00000237'     TO WGLOB-MSG-REF-INFO
                    PERFORM  0260-1000-GENERATE-MESSAGE
                        THRU 0260-1000-GENERATE-MESSAGE-X
                    SET MIR-RETRN-INVALD-RQST TO TRUE

           END-EVALUATE.

       1000-PROCESS-REQUEST-X.
           EXIT.
      /
      *-------------------
       2000-UPDATE.
      *-------------------

           PERFORM  8010-EDIT-KEY-FIELDS
               THRU 8010-EDIT-KEY-FIELDS-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.
020478
020478     PERFORM  2500-SAVE-RPOL-TO-HOLD
020478         THRU 2500-SAVE-RPOL-TO-HOLD-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           PERFORM  8015-XEDIT-KEY-FIELD
               THRU 8015-XEDIT-KEY-FIELD-X.

           PERFORM  8020-EDIT-BILL-CHNG-DT
               THRU 8020-EDIT-BILL-CHNG-DT-X.

           PERFORM  8025-EDIT-PLAN-OFF-ANNV-IND
               THRU 8025-EDIT-PLAN-OFF-ANNV-IND-X.

           PERFORM  8030-EDIT-OFF-ANNV-PD-DT
               THRU 8030-EDIT-OFF-ANNV-PD-DT-X.

           PERFORM  8035-CHECK-DIV-OPT
               THRU 8035-CHECK-DIV-OPT-X.

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-UPDATE-X
           END-IF

020478     IF  MIR-DV-PRCES-STATE-CD NOT = '3'
020478         PERFORM  2600-RESET-MIR
020478             THRU 2600-RESET-MIR-X
020478     END-IF.

           PERFORM  8040-PRELIM-2420-EDITS
               THRU 8040-PRELIM-2420-EDITS-X.

           PERFORM  8050-CHECK-PREV-CHNG
               THRU 8050-CHECK-PREV-CHNG-X

           IF  WGLOB-MSG-ERROR-SW > ZERO
               SET MIR-RETRN-RQST-FAILED  TO TRUE
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  2420-1000-BUILD-PARM-INFO
               THRU 2420-1000-BUILD-PARM-INFO-X.

           PERFORM  3000-LOAD-MIR-L2420
               THRU 3000-LOAD-MIR-L2420-X.

           SET L2420-PRCES-TYP-EDIT-ONLY    TO TRUE.
           SET L2420-REDO-WARNING           TO TRUE.

           PERFORM  2420-1000-MODIFY-POLICY
               THRU 2420-1000-MODIFY-POLICY-X.

020478*    PERFORM  9200-MOVE-RECORD-TO-MIR
020478*        THRU 9200-MOVE-RECORD-TO-MIR-X.
020478     IF  MIR-DV-PRCES-STATE-CD NOT = '3'
020478         PERFORM  9200-MOVE-RECORD-TO-MIR
020478             THRU 9200-MOVE-RECORD-TO-MIR-X
020478     ELSE
020478         PERFORM  9210-SET-CONFIRM-PAGE
020478             THRU 9210-SET-CONFIRM-PAGE-X
020478     END-IF.

           IF  L2420-RETRN-ERROR
           OR  L2420-EDIT-ERROR
               MOVE '1'               TO WGLOB-RETURN-CODE
               GO TO 2000-UPDATE-X
           END-IF.

           IF  MIR-DV-PRCES-STATE-CD NOT = '3'
020478         IF  WS-BILL-CHNG-NXT
020478* MSG : YOU ARE ABOUT TO SCHEDULE A FUTURE DATED REQUEST
020478             MOVE 'CS79020013'           TO WGLOB-MSG-REF-INFO
020478             PERFORM  0260-1000-GENERATE-MESSAGE
020478                 THRU 0260-1000-GENERATE-MESSAGE-X
020478         END-IF
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  POL-2000-UPDATE-TWRK-TS
               THRU POL-2000-UPDATE-TWRK-TS-X.

           IF  MIR-RETRN-TS-MISMATCH
      *MSG: 'TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2,
      *      PROCESS NOT COMPLETE'
               MOVE 'XS00000303'      TO WGLOB-MSG-REF-INFO
               MOVE 'POL'             TO WGLOB-MSG-PARM (01)
               MOVE WPOL-KEY          TO WGLOB-MSG-PARM (02)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  POL-3000-UNLOCK
               THRU POL-3000-UNLOCK-X.

           PERFORM  4000-INVOKE-REDO
               THRU 4000-INVOKE-REDO-X.

           IF  WS-REDO-NOT-OK
020478     AND NOT WS-BILL-CHNG-NXT
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  5000-INVOKE-UNDO
               THRU 5000-INVOKE-UNDO-X.

           PERFORM  8020-EDIT-BILL-CHNG-DT
               THRU 8020-EDIT-BILL-CHNG-DT-X.

           IF  WGLOB-RETURN-ERROR
               GO TO 2000-UPDATE-X
           END-IF.

           PERFORM  2420-1000-BUILD-PARM-INFO
               THRU 2420-1000-BUILD-PARM-INFO-X.

           PERFORM  3000-LOAD-MIR-L2420
               THRU 3000-LOAD-MIR-L2420-X.
031037
031037     PERFORM  2408-0000-INIT-PARM-INFO
031037         THRU 2408-0000-INIT-PARM-INFO-X.
031037     MOVE RPOL-POL-ID              TO L2408-POL-ID.
031037     MOVE L2420-EFF-DT             TO L2408-EFF-DT.
031037     PERFORM  2408-2000-NXT-PHST-SEQ
031037         THRU 2408-2000-NXT-PHST-SEQ-X.
031037     MOVE L2408-NXT-PCHST-SEQ-NUM  TO WGLOB-PCHST-REL-SEQ-NUM.
031037     MOVE L2408-NXT-PCHST-SEQ-NUM  TO L2420-PCHST-SEQ-NUM.
031037
           PERFORM  2420-1000-MODIFY-POLICY
               THRU 2420-1000-MODIFY-POLICY-X.
031037     MOVE ZERO                     TO WGLOB-PCHST-REL-SEQ-NUM.

           PERFORM  6000-GET-NEXT-ACTV
               THRU 6000-GET-NEXT-ACTV-X.

           PERFORM  CVGR-1000-REWRITE-CVGS-ARRAY
               THRU CVGR-1000-REWRITE-CVGS-ARRAY-X.

           PERFORM  POL-1000-READ-TWRK-TS
               THRU POL-1000-READ-TWRK-TS-X.

       2000-UPDATE-X.
           EXIT.

020478*-----------------------
020478 2500-SAVE-RPOL-TO-HOLD.
020478*-----------------------
020478
020478     MOVE RPOL-POL-OFFANNV-PD-DT      TO WS-H-POL-OFFANNV-PD-DT.
020478     MOVE RPOL-POL-PMT-DRW-DY         TO WS-H-POL-PMT-DRW-DY.
020478     MOVE RPOL-POL-SNDRY-AMT          TO WS-H-POL-SNDRY-AMT.
020478     MOVE RPOL-POL-SNDRY-REASN-CD     TO WS-H-POL-SNDRY-REASN-CD.
020478     MOVE RPOL-MODE-FCT-RESTR-IND     TO WS-H-MODE-FCT-RESTR-IND.
020478     MOVE RPOL-POL-CRNT-MODE-FCT      TO WS-H-POL-CRNT-MODE-FCT.
020478     MOVE RPOL-POL-PFEE-RESTR-IND     TO WS-H-POL-PFEE-RESTR-IND.
020478     MOVE RPOL-POL-PFEE-FCT           TO WS-H-POL-PFEE-FCT.
020478     MOVE RPOL-POL-BILL-TYP-CD        TO WS-H-POL-BILL-TYP-CD.
020478     MOVE RPOL-POL-BILL-MODE-CD       TO WS-H-POL-BILL-MODE-CD.
020478
020478 2500-SAVE-RPOL-TO-HOLD-X.
020478     EXIT.
020478
020478*---------------
020478 2600-RESET-MIR.
020478*---------------
020478
020478     MOVE SPACE            TO MIR-DV-MODE-FCT-RESTR-IND.
020478     MOVE SPACE            TO MIR-PFEE-RESTR-IND.
020478
020478 2600-RESET-MIR-X.
020478     EXIT.

      *-------------------------
       3000-LOAD-MIR-L2420.
      *-------------------------

           SET L2420-BILL-CHNG-CURR        TO  TRUE.

           IF  RPOL-POL-PD-TO-DT-NUM  > WGLOB-PROCESS-DATE
               SET L2420-BILL-CHNG-NXT     TO TRUE
           END-IF

           MOVE WGLOB-PROCESS-DATE         TO L2420-EFF-DT.

           IF  RPOL-POL-PD-TO-DT-NUM    <= WGLOB-PROCESS-DATE
               MOVE RPOL-POL-PD-TO-DT-NUM  TO L2420-EFF-DT
           END-IF.

           IF  WS-OFFANNV-PD-TO-DT       = EBLCH-BLANK-FIELD-CHAR
               MOVE WS-OFFANNV-PD-TO-DT    TO L2420-OFFANNV-PD-TO-DT
           ELSE
               MOVE MIR-POL-OFFANNV-PD-DT  TO L2420-OFFANNV-PD-TO-DT
           END-IF.

           MOVE RPOL-POL-PD-TO-DT-NUM      TO L1640-INTERNAL-DATE.
           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE        TO L2420-BILL-CHG-EFF-DT.

           IF  L2420-BILL-CHNG-CURR
               MOVE EBLCH-BLANK-FIELD-CHAR TO L2420-BILL-CHG-DT
           ELSE
               MOVE L1640-EXTERNAL-DATE    TO L2420-BILL-CHG-DT
           END-IF.

020478*    MOVE L2420-BILL-CHG-DT          TO MIR-POL-BILL-CHNG-DT.
020478     MOVE L2420-BILL-CHG-DT          TO MIR-PBRQST-EFF-DT.

020478*    IF  MIR-POL-NXT-BILL-CD   NOT  = SPACES
020478     IF  MIR-PBRQST-BILL-TYP-CD NOT  = SPACES
020478*        MOVE MIR-POL-NXT-BILL-CD    TO L2420-METHOD
020478         MOVE MIR-PBRQST-BILL-TYP-CD TO L2420-METHOD
           ELSE
               MOVE MIR-POL-BILL-TYP-CD    TO L2420-METHOD
           END-IF.

020478*    IF  MIR-POL-NXT-MODE-CD   NOT  = SPACES
020478     IF  MIR-BILL-MODE-CD   NOT  = SPACES
020478*        MOVE MIR-POL-NXT-MODE-CD   TO L2420-MODE
020478         MOVE MIR-BILL-MODE-CD      TO L2420-MODE
           ELSE
               MOVE MIR-POL-BILL-MODE-CD  TO L2420-MODE
           END-IF.

020478*    IF  MIR-POL-NXT-MODE-FCT  NOT  = SPACES
020478     IF  MIR-PBRQST-MODE-FCT  NOT  = SPACES
020478*        MOVE MIR-POL-NXT-MODE-FCT   TO L2420-MODFAC
020478         MOVE MIR-PBRQST-MODE-FCT    TO L2420-MODFAC
           ELSE
               MOVE MIR-POL-CRNT-MODE-FCT  TO L2420-MODFAC
           END-IF.

020478*    IF  MIR-NXT-FCT-RESTR-IND  NOT = SPACES
020478     IF  MIR-DV-MODE-FCT-RESTR-IND  NOT = SPACES
020478*        MOVE MIR-NXT-FCT-RESTR-IND  TO L2420-MODERST
020478         MOVE MIR-DV-MODE-FCT-RESTR-IND  TO L2420-MODERST
           ELSE
               MOVE MIR-MODE-FCT-RESTR-IND TO L2420-MODERST
           END-IF.

020478*    IF  MIR-POL-NXT-PFEE-FCT   NOT = SPACES
020478     IF  MIR-PBRQST-PFEE-FCT   NOT = SPACES
020478*        MOVE MIR-POL-NXT-PFEE-FCT   TO L2420-POLFCTR
020478         MOVE MIR-PBRQST-PFEE-FCT    TO L2420-POLFCTR
           ELSE
               MOVE MIR-POL-PFEE-FCT       TO L2420-POLFCTR
           END-IF.

020478*    IF  MIR-NXT-PFEE-RESTR-IND NOT = SPACES
020478     IF  MIR-PFEE-RESTR-IND NOT = SPACES
020478*        MOVE MIR-NXT-PFEE-RESTR-IND TO L2420-POLFRST
020478         MOVE MIR-PFEE-RESTR-IND TO L2420-POLFRST
           ELSE
               MOVE MIR-POL-PFEE-RESTR-IND TO L2420-POLFRST
           END-IF.

020478*    IF  MIR-POL-NXT-PMT-DRW-DY NOT = SPACES
020478     IF  MIR-PBRQST-PMT-DRW-DY NOT = SPACES
020478*        MOVE MIR-POL-NXT-PMT-DRW-DY TO L2420-POL-PMT-DRW-DY
020478         MOVE MIR-PBRQST-PMT-DRW-DY TO L2420-POL-PMT-DRW-DY
           ELSE
               MOVE MIR-POL-PMT-DRW-DY     TO L2420-POL-PMT-DRW-DY
           END-IF.

020478*    IF  MIR-POL-NXT-SNDRY-AMT  NOT = SPACES
020478     IF  MIR-PBRQST-SNDRY-AMT  NOT = SPACES
020478*        MOVE MIR-POL-NXT-SNDRY-AMT  TO L2420-POL-SNDRY-AMT-X
020478         MOVE MIR-PBRQST-SNDRY-AMT  TO L2420-POL-SNDRY-AMT-X
           ELSE
               MOVE MIR-POL-SNDRY-AMT      TO L2420-POL-SNDRY-AMT-X
           END-IF.

020478*    IF  MIR-NXT-SNDRY-REASN-CD  NOT = SPACES
020478     IF  MIR-SNDRY-REASN-CD  NOT = SPACES
020478*        MOVE MIR-NXT-SNDRY-REASN-CD TO L2420-POL-SNDRY-REASN-CD
020478         MOVE MIR-SNDRY-REASN-CD     TO L2420-POL-SNDRY-REASN-CD
           ELSE
               MOVE MIR-POL-SNDRY-REASN-CD TO L2420-POL-SNDRY-REASN-CD
           END-IF.

       3000-LOAD-MIR-L2420-X.
           EXIT.
      /

      *-------------------------
       4000-INVOKE-REDO.
      *-------------------------

           SET WS-REDO-OK                 TO  TRUE.

           IF (RPOL-POL-NXT-ACTV-DT    > WWKDT-ZERO-DT
           AND RPOL-POL-NXT-ACTV-DT    > WGLOB-PROCESS-DATE)
               GO TO 4000-INVOKE-REDO-X
           END-IF.

           MOVE WGLOB-PROCESS-DATE        TO WS-EFF-DT.

           IF  RPOL-POL-PD-TO-DT-NUM    <= WGLOB-PROCESS-DATE
               MOVE RPOL-POL-PD-TO-DT-NUM TO WS-EFF-DT
           END-IF.

           PERFORM  4780-1000-BUILD-PARM-INFO
               THRU 4780-1000-BUILD-PARM-INFO-X.

           SET L4780-REDO-WARNING         TO TRUE.
           SET L4780-MSG-SUPPRESS         TO TRUE.
           MOVE WS-EFF-DT                 TO L4780-EFF-DT.
           MOVE RPOL-PREV-BTCH-PRCES-DT   TO L4780-LAST-PROCESS-DATE.
           SET L4780-PRCES-INCLUSIVE      TO TRUE.

           PERFORM  4780-1000-GET-NEXT-ACT-DT
               THRU 4780-1000-GET-NEXT-ACT-DT-X.

           EVALUATE  TRUE

               WHEN  L4780-RETRN-ERROR
               WHEN  L4780-RETRN-INVALID-REQUEST

                     SET WS-REDO-NOT-OK   TO TRUE

               WHEN  (L4780-RETRN-OK
               AND    L4780-ACTIVITY-DUE
               AND    L4780-REDO-ALLOW)

                      MOVE WS-EFF-DT      TO L0201-EFF-DT
                      SET L0201-AUTO-REDO TO TRUE
                      PERFORM  0201-1000-AUTO-PROCESSING
                          THRU 0201-1000-AUTO-PROCESSING-X
                      PERFORM  0289-1000-INIT-PARM-INFO
                          THRU 0289-1000-INIT-PARM-INFO-X
                      MOVE WS-EFF-DT      TO L0289-LO-PAC-DT
                      MOVE WS-EFF-DT      TO L0289-LO-CRC-DT
                      MOVE WS-EFF-DT      TO L0289-LO-DD2-DT
                      MOVE WS-EFF-DT      TO L0289-PROC-EFF-DT
                      PERFORM  0289-1000-OBTAIN-NXT-ACTV
                          THRU 0289-1000-OBTAIN-NXT-ACTV-X
                      IF  L0289-RETRN-OK
                          MOVE L0289-NXT-ACTV-TYP-CD
                            TO RPOL-NXT-ACTV-TYP-CD
                          MOVE L0289-NXT-ACTV-DT
                            TO RPOL-POL-NXT-ACTV-DT
                      ELSE
                          MOVE 'RSH'      TO RPOL-NXT-ACTV-TYP-CD
                          MOVE WGLOB-PROCESS-DATE
                                          TO RPOL-POL-NXT-ACTV-DT
                      END-IF
                      IF  L0201-RETRN-OK
                           MOVE 'XS00000307'    TO  WGLOB-MSG-REF-INFO
      *MSG: 'AUTO REDO PROCESSING COMPLETED
                           PERFORM  0260-1000-GENERATE-MESSAGE
                               THRU 0260-1000-GENERATE-MESSAGE-X
                      ELSE
                          SET WS-REDO-NOT-OK    TO TRUE
                          IF  NOT L0201-INCOMPLETE-DUE-ACTV
                              MOVE 'XS00000308' TO WGLOB-MSG-REF-INFO
      *MSG: PROBLEM IN AUTO REDO PROCESSING
                              PERFORM  0260-1000-GENERATE-MESSAGE
                                  THRU 0260-1000-GENERATE-MESSAGE-X
                          END-IF
                      END-IF

           END-EVALUATE.

       4000-INVOKE-REDO-X.
           EXIT.
      /


      *-------------------------
       5000-INVOKE-UNDO.
      *-------------------------

           MOVE WGLOB-PROCESS-DATE        TO WS-EFF-DT.

           IF  RPOL-POL-PD-TO-DT-NUM    <= WGLOB-PROCESS-DATE
               MOVE RPOL-POL-PD-TO-DT-NUM TO WS-EFF-DT
           END-IF.

           PERFORM  4750-1000-BUILD-PARM-INFO
               THRU 4750-1000-BUILD-PARM-INFO-X.

           MOVE WS-EFF-DT                   TO L4750-EFF-DT.

           SET L4750-FCN-DRVR-SECONDARY     TO TRUE.
           SET L4750-PRCES-EXCLUSIVE        TO TRUE.

           PERFORM  4750-1000-UNDO-PROCESSING
               THRU 4750-1000-UNDO-PROCESSING-X.

           IF NOT L4750-RETRN-OK
               SET WGLOB-RETURN-ERROR       TO TRUE
           END-IF.

       5000-INVOKE-UNDO-X.
           EXIT.
      /

      *--------------------------
       6000-GET-NEXT-ACTV.
      *--------------------------

020478     PERFORM  2625-1000-BILL-CHNG-RETRIEVE
020478         THRU 2625-1000-BILL-CHNG-RETRIEVE-X.
020478     IF  L2625-PBRQST-EFF-DT = WWKDT-ZERO-DT
020478         PERFORM  6100-UPDT-CRNT-BILL-CHNG
020478             THRU 6100-UPDT-CRNT-BILL-CHNG-X
020478     END-IF.
020478
020478     PERFORM  2625-2000-BILL-CHNG-UPDATE
020478         THRU 2625-2000-BILL-CHNG-UPDATE-X.
020478
020478     IF  WS-BILL-CHNG-NXT
020478         MOVE MIR-POL-ID            TO WPORQ-POL-ID
020478
036742*        MOVE L2625-POL-RQST-CREAT-TS
036742*                                   TO WPORQ-POL-RQST-CREAT-TS
036742         MOVE L2625-PBRQST-GEN-ID
036742                                    TO WPORQ-POL-RQST-GEN-ID
036742         MOVE L2625-PBRQST-EFF-DT   TO WPORQ-POL-RQST-EFF-DT
020478         PERFORM  PORQ-1000-CREATE
020478             THRU PORQ-1000-CREATE-X
020478
036742*        MOVE L2625-PBRQST-EFF-DT   TO RPORQ-POL-RQST-EFF-DT
020478         SET RPORQ-POL-RQST-TYP-OFFANNV
020478                                    TO TRUE
020478         MOVE MIR-BUS-FCN-ID        TO RPORQ-BUS-FCN-ID
020478         MOVE WGLOB-USER-ID         TO RPORQ-USER-ID
020478         MOVE LENGTH OF MIR-PARM-AREA
020478                                TO RPORQ-POL-RQST-MSG-INFO-LENGTH
020478         MOVE MIR-PARM-AREA     TO RPORQ-POL-RQST-MSG-INFO-DATA
020478                                (1:RPORQ-POL-RQST-MSG-INFO-LENGTH)
020478         PERFORM  PORQ-1000-WRITE
020478             THRU PORQ-1000-WRITE-X
020478
020478* MSG : FUTURE DATED REQUEST HAS BEEN SCHEDULED. VIEW DETAILS ON
020478*       FUTURE DATED POLICY ACTIVITY BUSINESS PROCESS
020478         MOVE 'CS79020014'           TO WGLOB-MSG-REF-INFO
020478         PERFORM  0260-1000-GENERATE-MESSAGE
020478             THRU 0260-1000-GENERATE-MESSAGE-X
020478     END-IF.
020478
           MOVE RPOL-REC-INFO         TO HPOL-REC-INFO.
           MOVE MIR-POL-ID-BASE       TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX        TO WPOL-POL-ID-SFX.

           PERFORM  POL-1000-READ-FOR-UPDATE
               THRU POL-1000-READ-FOR-UPDATE-X.

           MOVE HPOL-REC-INFO         TO RPOL-REC-INFO.

           PERFORM  0289-1000-INIT-PARM-INFO
               THRU 0289-1000-INIT-PARM-INFO-X.

           MOVE WGLOB-PROCESS-DATE  TO L0289-LO-PAC-DT.
           MOVE WGLOB-PROCESS-DATE  TO L0289-LO-CRC-DT.
           MOVE WGLOB-PROCESS-DATE  TO L0289-PROC-EFF-DT.

           PERFORM  0289-1000-OBTAIN-NXT-ACTV
               THRU 0289-1000-OBTAIN-NXT-ACTV-X.

           IF L0289-RETRN-OK
               MOVE L0289-NXT-ACTV-TYP-CD TO RPOL-NXT-ACTV-TYP-CD
               MOVE L0289-NXT-ACTV-DT     TO RPOL-POL-NXT-ACTV-DT
           ELSE
               MOVE WGLOB-PROCESS-DATE    TO RPOL-POL-NXT-ACTV-DT
               MOVE 'RSH'                 TO RPOL-NXT-ACTV-TYP-CD
           END-IF.

           PERFORM  POL-2000-REWRITE
               THRU POL-2000-REWRITE-X.

       6000-GET-NEXT-ACTV-X.
           EXIT.

020478*-------------------------
020478 6100-UPDT-CRNT-BILL-CHNG.
020478*-------------------------
020478
020478     MOVE RPOL-POL-OFFANNV-PD-DT
020478                                   TO L2625-OFFANNV-PD-DT.
020478
020478     MOVE RPOL-POL-PMT-DRW-DY      TO L2625-PBRQST-PMT-DRW-DY.
020478
020478     MOVE RPOL-POL-SNDRY-AMT       TO L2625-PBRQST-SNDRY-AMT.
020478
020478     MOVE RPOL-POL-SNDRY-REASN-CD
020478                                   TO L2625-SNDRY-REASN-CD.
020478
020478     MOVE RPOL-MODE-FCT-RESTR-IND
020478                                   TO L2625-MODE-FCT-RESTR-IND.
020478
020478     MOVE RPOL-POL-CRNT-MODE-FCT
020478                                   TO L2625-PBRQST-MODE-FCT.
020478
020478     MOVE RPOL-POL-PFEE-RESTR-IND
020478                                   TO L2625-PFEE-RESTR-IND.
020478
020478     MOVE RPOL-POL-PFEE-FCT        TO L2625-PBRQST-PFEE-FCT.
020478
020478     MOVE RPOL-POL-BILL-TYP-CD     TO L2625-PBRQST-BILL-TYP-CD.
020478
020478     MOVE RPOL-POL-BILL-MODE-CD
020478                                   TO L2625-BILL-MODE-CD.
020478
020478     MOVE RPOL-POL-PD-TO-DT-NUM    TO L2625-PBRQST-EFF-DT.
020478     PERFORM  2625-3000-BILL-CHNG-CACHE
020478         THRU 2625-3000-BILL-CHNG-CACHE-X.
020478
020478 6100-UPDT-CRNT-BILL-CHNG-X.
020478     EXIT.

      /
      *--------------------------
       8010-EDIT-KEY-FIELDS.
      *--------------------------
      *
      * CHECK POLICY EXISTS
      *
           IF  MIR-POL-ID-BASE  = SPACES
           AND MIR-POL-ID-SFX   = SPACES
      *MSG: POLICY NUMBER IS REQUIRED
               MOVE 'CS79020001'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8010-EDIT-KEY-FIELDS-X
           END-IF.

           MOVE MIR-POL-ID               TO WPOL-POL-ID.

           PERFORM  POL-1000-READ
               THRU POL-1000-READ-X.

           IF  WPOL-IO-NOT-FOUND
      *MSG: RECORD NOT FOUND
               MOVE 'XS00000001'         TO WGLOB-MSG-REF-INFO
               MOVE WPOL-KEY             TO WGLOB-MSG-PARM (1)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8010-EDIT-KEY-FIELDS-X
           END-IF.


           IF  RPOL-POL-SUSPENDED
      *MSGS: POLICY CURRENTLY SUSPENDED - CANNOT MAINTAIN OR PROCESS
               MOVE 'XS00000240'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   MOVE 1                TO WGLOB-MSG-ERROR-SW
                   GO TO 8010-EDIT-KEY-FIELDS-X
               END-IF
           END-IF.

           IF  RPOL-POL-STAT-BEFORE-SETL
      *MSGS: PENDING POLICY - CANNOT MAINTAIN OR PROCESS
               MOVE 'XS00000238'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               IF  WGLOB-MSG-SEVRTY-FATAL
                   MOVE 1                TO WGLOB-MSG-ERROR-SW
                   GO TO 8010-EDIT-KEY-FIELDS-X
               END-IF
           END-IF.

020478     PERFORM  2625-0000-INIT-PARM-INFO
020478         THRU 2625-0000-INIT-PARM-INFO-X.
020478     PERFORM  2625-1000-BILL-CHNG-RETRIEVE
020478         THRU 2625-1000-BILL-CHNG-RETRIEVE-X.
020478
       8010-EDIT-KEY-FIELDS-X.
           EXIT.
      /

      *--------------------------
       8015-XEDIT-KEY-FIELD.
      *--------------------------
      *
      * CHECK POLICY CONFIDENTIAL AND SECURITY ARE SATISFIED
      *

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.

           SET L5400-STAT-MSG-NOT-REQD   TO TRUE.

           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.

           IF  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-CNFD-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
           OR  L5400-STAT-ACCS-RESTRICTED
           OR  L5400-XFER-ACCS-RESTRICTED
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
            END-IF.

       8015-XEDIT-KEY-FIELD-X.
           EXIT.

      *--------------------------
       8020-EDIT-BILL-CHNG-DT.
      *--------------------------
      *
020478*    IF  RPOL-POL-BILL-CHNG-DT =  WWKDT-ZERO-DT
020478*        GO TO  8020-EDIT-BILL-CHNG-DT-X
020478*    END-IF.

020478*    IF  RPOL-POL-PD-TO-DT-NUM = RPOL-POL-BILL-CHNG-DT
      *MSG  THERE IS AN ACTIVE BILL CHANGE ACTIVITY,
      *     PLEASE USE CHANGE HISTORY AND CHANGE THE
      *     BILL CHANGE ACTIVITY STATUS TO ERROR
020478*        MOVE 'CS79020002'        TO WGLOB-MSG-REF-INFO
020478*        PERFORM  0260-1000-GENERATE-MESSAGE
020478*            THRU 0260-1000-GENERATE-MESSAGE-X
020478*        MOVE 1                    TO WGLOB-MSG-ERROR-SW
020478*    END-IF.
020478
020478     IF  L2625-PBRQST-EFF-DT NOT =  WWKDT-ZERO-DT
020478*MSG: A FUTURE DATED BILLING REQUEST ALREADY EXISTS WITH PENDING
020478*     STATUS FOR THE SAME EFFECTIVE DATE.  CANCEL REQUEST BEFORE
020478*     CREATING A NEW ONE.
020478         MOVE 'CS79020015'        TO WGLOB-MSG-REF-INFO
020478         PERFORM  0260-1000-GENERATE-MESSAGE
020478             THRU 0260-1000-GENERATE-MESSAGE-X
020478         MOVE 1                    TO WGLOB-MSG-ERROR-SW
020478     END-IF.

       8020-EDIT-BILL-CHNG-DT-X.
           EXIT.
      /
      *--------------------------
       8025-EDIT-PLAN-OFF-ANNV-IND.
      *--------------------------
      *
      * ALL PLAN MUST ALLOW OFF ANNIVERSARY PREMIUM FOR THE POLICY
      *

           MOVE ZERO                        TO I.
           SET  WS-OFF-ANNV-POL             TO TRUE.

           PERFORM
              VARYING J FROM 1 BY 1
                UNTIL J > RPOL-POL-CVG-REC-CTR-N
                   OR WS-OFF-ANNV-POL-NOT-ALLOWED

               MOVE J                       TO I
               PERFORM  PLIN-1000-PLAN-HEADER-IN
                   THRU PLIN-1000-PLAN-HEADER-IN-X

               IF  RPH-PLAN-OFFANNV-NO
                   SET  WS-OFF-ANNV-POL-NOT-ALLOWED TO TRUE
               END-IF

            END-PERFORM.

            IF  WS-OFF-ANNV-POL-NOT-ALLOWED
      *MSG: THERE IS ONE PLAN WHICH DOES NOT ALLOW
      *     OFF-ANNIVERSARY PREMIUMS FOR THE POLICY
               MOVE 'CS79020003'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
            END-IF.

       8025-EDIT-PLAN-OFF-ANNV-IND-X.
           EXIT.

      /
      *--------------------------
       8030-EDIT-OFF-ANNV-PD-DT.
      *--------------------------

020478*    IF  MIR-POL-NXT-MODE-CD   NOT = SPACES
020478     IF  MIR-BILL-MODE-CD      NOT = SPACES
020478*        MOVE MIR-POL-NXT-MODE-CD   TO L0280-INPUT-DATA
020478         MOVE MIR-BILL-MODE-CD      TO L0280-INPUT-DATA
           ELSE
               MOVE MIR-POL-BILL-MODE-CD  TO L0280-INPUT-DATA
           END-IF.

           MOVE LENGTH OF MIR-POL-BILL-MODE-CD
                                         TO L0280-INPUT-SIZE.
           MOVE L0280-INPUT-SIZE         TO L0280-LENGTH.
           MOVE ZERO                     TO L0280-PRECISION.
           SET L0280-SIGN-NOT-PERMITTED  TO TRUE.
           SET L0280-SPACES-PERMITTED    TO TRUE.

           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.

           IF  L0280-OK
               MOVE L0280-OUTPUT-V00     TO WS-MODE
           ELSE
      *MSG: THE POLICY BILL MODE IS INVALID
               MOVE 'CS79020004'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8030-EDIT-OFF-ANNV-PD-DT-X
           END-IF

      *
      * THIS CONDITION WILL BE VALID ON CONFIRM PROCESS
      * AND IS TO MAKE SURE THE RPOL-POL-OFFANNV-PD-DT IS
      * RESET TO ZERO
      *

           IF  MIR-POL-OFFANNV-PD-DT  = WWKDT-ZERO-DT
               MOVE EBLCH-BLANK-FIELD-CHAR TO WS-OFFANNV-PD-TO-DT
               GO TO 8030-EDIT-OFF-ANNV-PD-DT-X
           END-IF.
      *
      * DEFAULT THE OFF ANNIVERSARY PAID TO DATE
      *
           IF  MIR-POL-OFFANNV-PD-DT = SPACES
               MOVE RPOL-POL-PD-TO-DT-NUM-R TO L1680-INTERNAL-1
               MOVE ZERO                    TO L1680-NUMBER-OF-DAYS
               MOVE WS-MODE              TO L1680-NUMBER-OF-MONTHS
               MOVE ZERO                 TO L1680-NUMBER-OF-YEARS
               PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
                   THRU 1680-3000-ADD-Y-M-D-TO-DATE-X
               MOVE L1680-INTERNAL-2     TO L1640-INTERNAL-DATE
               PERFORM  1640-8000-INTERNAL-TO-MIR
                   THRU 1640-8000-INTERNAL-TO-MIR-X
               MOVE L1640-EXTERNAL-DATE  TO MIR-POL-OFFANNV-PD-DT
           END-IF.

           MOVE MIR-POL-OFFANNV-PD-DT    TO L1640-EXTERNAL-DATE.

           PERFORM  1640-7000-MIR-TO-INT
               THRU 1640-7000-MIR-TO-INT-X.

           IF  NOT L1640-VALID
      *MSG THE OFF ANNIVERSARY PAID DATE FORMAT IS INVALID
               MOVE 'CS79020005'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8030-EDIT-OFF-ANNV-PD-DT-X
           END-IF.

           MOVE L1640-INTERNAL-DATE      TO HPOL-POL-OFFANNV-PD-DT.
020478     MOVE L1640-INTERNAL-DATE      TO WS-OFFANNV-PD-TO-DT.

      *
      * OFF-ANNIVERSARY PAID TO DATE DAY DOES NOT MATCH THE DAY PORTION
      * OF THE POLICY ISSUE EFFECTIVE DATE
      *
           IF  HPOL-POL-OFFANNV-PD-DT-DY NOT = RPOL-POL-ISS-EFF-DT-DY
      *MSG  THE DAY PORTION FOR OFF ANNIVERSARY PAID DATE MUST
      *     MATCH THE DAY PORTION ON THE POLICY ISSUE EFFECTIVE DATE
               MOVE 'CS79020006'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8030-EDIT-OFF-ANNV-PD-DT-X
           END-IF.

      *
      * OFF-ANNIVERSARY PAID TO DATE IS LESS THAN OR EQUAL TO THE
      * POLICY PAID TO DATE
      *

           IF  HPOL-POL-OFFANNV-PD-DT-R <= RPOL-POL-PD-TO-DT-NUM-R
      *MSG: THE OFF ANNIVERSARY PAID DATE MUST BE GREATER THAN POLICY
      *     PAID TO DATE
               MOVE 'CS79020007'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8030-EDIT-OFF-ANNV-PD-DT-X
           END-IF.

           MOVE RPOL-POL-PD-TO-DT-NUM    TO L1680-INTERNAL-1.
           MOVE ZERO                     TO L1680-NUMBER-OF-YEARS.
           MOVE WS-MODE                  TO L1680-NUMBER-OF-MONTHS.
           MOVE ZERO                     TO L1680-NUMBER-OF-DAYS.

           PERFORM  1680-5000-ADD-M-TO-DATE
               THRU 1680-5000-ADD-M-TO-DATE-X.

           IF  HPOL-POL-OFFANNV-PD-DT-R  > L1680-INTERNAL-2
      *MSG: THE COMBINATION OF OFF ANNIVERSARY PAID DATE AND THE NEXT
      *     MODE IS TOO FAR AHEAD BASED UPON POLICY PAID TO DATE
               MOVE 'CS79020008'         TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE 1                    TO WGLOB-MSG-ERROR-SW
               GO TO 8030-EDIT-OFF-ANNV-PD-DT-X
           END-IF.

      *
      * CALCULATE THE LAST ANNIVERSARY DATE FOR THE POLICY
      *
           MOVE RPOL-POL-ISS-EFF-DT-R    TO L1680-INTERNAL-1.
           MOVE ZERO                     TO L1680-NUMBER-OF-DAYS.
           MOVE ZERO                     TO L1680-NUMBER-OF-MONTHS.
           MOVE RPOL-POL-PREV-ANNV-DUR   TO L1680-NUMBER-OF-YEARS.

           PERFORM  1680-3000-ADD-Y-M-D-TO-DATE
               THRU 1680-3000-ADD-Y-M-D-TO-DATE-X.

           MOVE L1680-INTERNAL-2         TO WS-LAST-ANNV-DT.

      * SUBTRACT THE NEXT MODE (NUMBER OF MONTHS) FROM THE
      * OFF-ANNIVERSARY PAID TO DATE AND CONTINUE TO DO SO
      * UNTIL THE RESULT IS EITHER EQUAL TO OR LESS THAN THE
      * LAST ANNIVERSARY DATE.

           MOVE WS-MODE                  TO L1680-NUMBER-OF-MONTHS.
           MOVE HPOL-POL-OFFANNV-PD-DT   TO L1680-INTERNAL-1.
           PERFORM  1680-6000-SUB-M-FROM-DATE
               THRU 1680-6000-SUB-M-FROM-DATE-X.
           MOVE L1680-INTERNAL-2         TO L1680-INTERNAL-1.

           PERFORM
             UNTIL L1680-INTERNAL-2 <= WS-LAST-ANNV-DT
                   MOVE WS-MODE          TO L1680-NUMBER-OF-MONTHS
                   PERFORM  1680-6000-SUB-M-FROM-DATE
                       THRU 1680-6000-SUB-M-FROM-DATE-X
                   MOVE L1680-INTERNAL-2 TO L1680-INTERNAL-1
           END-PERFORM.

           IF  L1680-INTERNAL-2            = WS-LAST-ANNV-DT
           AND RPOL-POL-OFFANNV-PD-DT NOT  = WWKDT-ZERO-DT
      *MSG THE COMBINATION OF OFF ANNIVERSARY PAID DATE AND NEXT MODE
      *    CAUSES THE OFF-ANNIVERSARY POLICY TO BECOME ON-ANNIVERSARY
               MOVE 'CS79020010'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE EBLCH-BLANK-FIELD-CHAR TO WS-OFFANNV-PD-TO-DT
               GO TO 8030-EDIT-OFF-ANNV-PD-DT-X
           END-IF.

       8030-EDIT-OFF-ANNV-PD-DT-X.
           EXIT.
      /
      *------------------
       8035-CHECK-DIV-OPT.
      *------------------

           IF  RPOL-POL-DIV-OPT-REDC-PREM
           OR  RPOL-POL-DIV-XCES-PREM-PMT
      *MSG: CANNOT HAVE REDUCE PREMIUM IN DIVIDEND OPTION OR EXCESS
      *     OPTION
               MOVE 'CS79020011'        TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR      TO TRUE
           END-IF.

       8035-CHECK-DIV-OPT-X.
           EXIT.

      *-------------------------
       8040-PRELIM-2420-EDITS.
      *-------------------------

           IF  MIR-DV-PRCES-STATE-CD = '3'
020478         IF  RPOL-POL-PD-TO-DT-NUM  > WGLOB-PROCESS-DATE
020478             SET WS-BILL-CHNG-NXT     TO TRUE
020478         END-IF
               GO TO 8040-PRELIM-2420-EDITS-X
           END-IF.

           PERFORM  2420-1000-BUILD-PARM-INFO
               THRU 2420-1000-BUILD-PARM-INFO-X.

           SET L2420-PRCES-TYP-EDIT-ONLY    TO TRUE.
           SET L2420-REDO-WARNING           TO TRUE.

           IF  RPOL-POL-PD-TO-DT-NUM    > WGLOB-PROCESS-DATE
               SET L2420-BILL-CHNG-NXT     TO TRUE
020478         SET WS-BILL-CHNG-NXT        TO TRUE
           END-IF

           MOVE WGLOB-PROCESS-DATE         TO L2420-EFF-DT.

           IF  RPOL-POL-PD-TO-DT-NUM    <= WGLOB-PROCESS-DATE
               MOVE RPOL-POL-PD-TO-DT-NUM  TO L2420-EFF-DT
           END-IF.

           MOVE RPOL-POL-PD-TO-DT-NUM      TO L1640-INTERNAL-DATE.

           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.

           MOVE L1640-EXTERNAL-DATE        TO L2420-BILL-CHG-EFF-DT.

           PERFORM  2420-1000-MODIFY-POLICY
               THRU 2420-1000-MODIFY-POLICY-X.

       8040-PRELIM-2420-EDITS-X.
           EXIT.

      /
      *--------------------
       8050-CHECK-PREV-CHNG.
      *--------------------

           MOVE RPOL-POL-CRNT-MODE-FCT      TO L0290-INPUT-V07.
           MOVE 7                           TO L0290-PRECISION.
           MOVE LENGTH OF WS-POL-CRNT-MODE-FCT
                                            TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA           TO WS-POL-CRNT-MODE-FCT.

           MOVE RPOL-POL-PFEE-FCT           TO L0290-INPUT-V07
           MOVE 7                           TO L0290-PRECISION
           MOVE LENGTH OF WS-POL-PFEE-FCT   TO L0290-MAX-OUT-LEN.
           PERFORM  0290-2000-FORMAT-FOR-MIR
               THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA           TO WS-POL-PFEE-FCT.

           IF (MIR-POL-BILL-TYP-CD     = RPOL-POL-BILL-TYP-CD
           AND MIR-POL-BILL-MODE-CD    = RPOL-POL-BILL-MODE-CD
           AND MIR-POL-CRNT-MODE-FCT   = WS-POL-CRNT-MODE-FCT
           AND MIR-POL-PFEE-FCT        = WS-POL-PFEE-FCT
           AND MIR-MODE-FCT-RESTR-IND  = RPOL-MODE-FCT-RESTR-IND
           AND MIR-POL-PFEE-RESTR-IND  = RPOL-POL-PFEE-RESTR-IND)
               GO TO 8050-CHECK-PREV-CHNG-X
           END-IF.

           INITIALIZE                 RPHST-REC-INFO.
           MOVE RPOL-POL-ID           TO WPHST-POL-ID.
020478*    MOVE WGLOB-PROCESS-DATE    TO WS-EFF-DT.

020478*    IF  RPOL-POL-PD-TO-DT-NUM    <= WGLOB-PROCESS-DATE
020478*        MOVE RPOL-POL-PD-TO-DT-NUM  TO WS-EFF-DT
020478*    END-IF.
020478     MOVE RPOL-POL-PD-TO-DT-NUM TO WS-EFF-DT.
           MOVE WS-EFF-DT             TO L1660-INTERNAL-DATE.

           PERFORM  1660-2000-CONVERT-INT-TO-INV
               THRU 1660-2000-CONVERT-INT-TO-INV-X.

           MOVE L1660-INVERTED-DATE   TO WPHST-PCHST-EFF-IDT-NUM.
           MOVE ZEROS                 TO WPHST-PCHST-SEQ-NUM.

           MOVE WPHST-KEY             TO WPHST-ENDBR-KEY.
030054*    MOVE 999                   TO WPHST-ENDBR-PCHST-SEQ-NUM.
030054     MOVE WCNST-MAX-PCHST-SEQ-NUM-N
030054                                TO WPHST-ENDBR-PCHST-SEQ-NUM.

           PERFORM  PHST-1000-BROWSE
               THRU PHST-1000-BROWSE-X.

           PERFORM  PHST-2000-READ-NEXT
               THRU PHST-2000-READ-NEXT-X.

           IF  NOT WPHST-IO-OK
               PERFORM  PHST-3000-END-BROWSE
                   THRU PHST-3000-END-BROWSE-X
               GO TO 8050-CHECK-PREV-CHNG-X
           END-IF.
      *
      *  FIND ANY ACTIVE/REVERSE PHST RECORD FOR BILL CHANGE
      *
           MOVE RPHST-POL-ACTV-TYP-ID TO WS-ACTV-TYP-ID.
           PERFORM
              UNTIL WPHST-IO-EOF
                 OR (WS-ACTV-TYP-BILL-CHNG
                AND (RPHST-PCHST-STAT-ACTIVE  OR
                     RPHST-PCHST-STAT-REVERSED))
                PERFORM  PHST-2000-READ-NEXT
                    THRU PHST-2000-READ-NEXT-X
                MOVE RPHST-POL-ACTV-TYP-ID TO WS-ACTV-TYP-ID
           END-PERFORM.

           IF  WPHST-IO-OK
               MOVE WS-EFF-DT              TO L1640-INTERNAL-DATE
               PERFORM  1640-2000-INTERNAL-TO-EXT
                   THRU 1640-2000-INTERNAL-TO-EXT-X
               MOVE L1640-EXTERNAL-DATE    TO WGLOB-MSG-PARM (1)
      * MSG: EXISTING BILLING CHANGE ON SAME DAY, REVERSE AND ERROR OUT
      *       THE PREVIOUS CHANGE BEFORE MAKING THIS CHANGE
               MOVE 'CS79020012'           TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               SET WGLOB-RETURN-ERROR      TO TRUE
           END-IF.

           PERFORM  PHST-3000-END-BROWSE
               THRU PHST-3000-END-BROWSE-X.

       8050-CHECK-PREV-CHNG-X.
           EXIT.
      /

      *-------------------------
       9000-BLANK-DATA-FIELDS.
      *-------------------------


020478*    MOVE SPACE                  TO MIR-POL-BILL-CHNG-DT.
020478     MOVE SPACE                  TO MIR-PBRQST-EFF-DT.
           MOVE SPACE                  TO MIR-POL-OFFANNV-PD-DT.
           MOVE SPACE                  TO MIR-DV-OWN-CLI-NM.

           MOVE ZERO                   TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-MPREM-AMT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-MPREM-AMT.

           MOVE ZERO                   TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-POL-NXT-SNDRY-AMT
020478     MOVE LENGTH OF MIR-PBRQST-SNDRY-AMT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA      TO MIR-POL-NXT-SNDRY-AMT.
020478     MOVE L0290-OUTPUT-DATA      TO MIR-PBRQST-SNDRY-AMT.

           MOVE ZERO                   TO L0290-INPUT-V07.
           MOVE 7                      TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-POL-NXT-MODE-FCT
020478     MOVE LENGTH OF MIR-PBRQST-MODE-FCT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA      TO MIR-POL-NXT-MODE-FCT.
020478     MOVE L0290-OUTPUT-DATA      TO MIR-PBRQST-MODE-FCT.

           MOVE ZERO                   TO L0290-INPUT-V07.
           MOVE 7                      TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-POL-NXT-PFEE-FCT
020478     MOVE LENGTH OF MIR-PBRQST-PFEE-FCT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
020478*    MOVE L0290-OUTPUT-DATA      TO MIR-POL-NXT-PFEE-FCT.
020478     MOVE L0290-OUTPUT-DATA      TO MIR-PBRQST-PFEE-FCT.

020478*    MOVE SPACE                  TO MIR-POL-NXT-BILL-CD.
020478     MOVE SPACE                  TO MIR-PBRQST-BILL-TYP-CD.
           MOVE SPACE                  TO MIR-POL-BILL-MODE-CD.
           MOVE SPACE                  TO MIR-POL-BILL-MODE-CD.
020478*    MOVE SPACE                  TO MIR-POL-NXT-MODE-CD.
020478     MOVE SPACE                  TO MIR-BILL-MODE-CD.
           MOVE SPACE                  TO MIR-MODE-FCT-RESTR-IND.
020478*    MOVE SPACE                  TO MIR-NXT-FCT-RESTR-IND.
020478     MOVE SPACE                  TO MIR-DV-MODE-FCT-RESTR-IND.
           MOVE SPACE                  TO MIR-POL-PFEE-RESTR-IND.
020478*    MOVE SPACE                  TO MIR-NXT-PFEE-RESTR-IND.
020478     MOVE SPACE                  TO MIR-PFEE-RESTR-IND.
           MOVE SPACE                  TO MIR-POL-SNDRY-REASN-CD.
020478*    MOVE SPACE                  TO MIR-NXT-SNDRY-REASN-CD.
020478     MOVE SPACE                  TO MIR-SNDRY-REASN-CD.

           MOVE ZERO                    TO L0290-INPUT-V00.
           MOVE ZERO                    TO L0290-PRECISION.
020478*    MOVE LENGTH OF MIR-POL-NXT-PMT-DRW-DY
020478     MOVE LENGTH OF MIR-PBRQST-PMT-DRW-DY
                                        TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO MIR-POL-PMT-DRW-DY.
020478*    MOVE L0290-OUTPUT-DATA       TO MIR-POL-NXT-PMT-DRW-DY.
020478     MOVE L0290-OUTPUT-DATA       TO MIR-PBRQST-PMT-DRW-DY.

       9000-BLANK-DATA-FIELDS-X.
           EXIT.

      /
      *--------------------------
       9200-MOVE-RECORD-TO-MIR.
      *--------------------------

           PERFORM  9000-BLANK-DATA-FIELDS
               THRU 9000-BLANK-DATA-FIELDS-X.

020478     PERFORM  2625-1000-BILL-CHNG-RETRIEVE
020478         THRU 2625-1000-BILL-CHNG-RETRIEVE-X.
      *
      * OFF ANNIVERSARY PAID DATE
      *
020478*    MOVE RPOL-POL-OFFANNV-PD-DT  TO L1640-INTERNAL-DATE.
020478     IF  WS-OFFANNV-PD-TO-DT = EBLCH-BLANK-FIELD-CHAR
020478         MOVE WWKDT-ZERO-DT       TO L1640-INTERNAL-DATE
020478     ELSE
020478         MOVE WS-OFFANNV-PD-TO-DT TO L1640-INTERNAL-DATE
020478     END-IF.

           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
           MOVE L1640-EXTERNAL-DATE     TO MIR-POL-OFFANNV-PD-DT.

           IF  MIR-POL-OFFANNV-PD-DT    = SPACES
               IF  WS-OFFANNV-PD-TO-DT  = EBLCH-BLANK-FIELD-CHAR
                   MOVE WWKDT-ZERO-DT   TO MIR-POL-OFFANNV-PD-DT
               END-IF
           END-IF.

020478*    MOVE RPOL-POL-BILL-CHNG-DT   TO L1640-INTERNAL-DATE.
020478     IF  L2420-BILL-CHNG-CURR
020478         MOVE RPOL-POL-PD-TO-DT-NUM
020478                                  TO L1640-INTERNAL-DATE
020478     ELSE
020478         MOVE L2625-PBRQST-EFF-DT TO L1640-INTERNAL-DATE
020478     END-IF.

           PERFORM  1640-8000-INTERNAL-TO-MIR
               THRU 1640-8000-INTERNAL-TO-MIR-X.
020478*    MOVE L1640-EXTERNAL-DATE     TO MIR-POL-BILL-CHNG-DT.
020478     MOVE L1640-EXTERNAL-DATE     TO MIR-PBRQST-EFF-DT.

      *
      * NEXT BILLING TYPE
      *
020478*    MOVE RPOL-POL-NXT-BILL-CD    TO MIR-POL-NXT-BILL-CD.
020478     IF  L2625-PBRQST-BILL-TYP-CD = SPACES
020478         MOVE RPOL-POL-BILL-TYP-CD TO MIR-PBRQST-BILL-TYP-CD
020478     ELSE
020478         MOVE L2625-PBRQST-BILL-TYP-CD
020478                                  TO MIR-PBRQST-BILL-TYP-CD
020478     END-IF.
      *
      * NEXT BILLING MODE
      *
020478*    MOVE RPOL-POL-NXT-MODE-CD    TO MIR-POL-NXT-MODE-CD.
020478     IF  L2625-BILL-MODE-CD = SPACE
020478         MOVE RPOL-POL-BILL-MODE-CD
020478                                  TO MIR-BILL-MODE-CD
020478     ELSE
020478         MOVE L2625-BILL-MODE-CD  TO MIR-BILL-MODE-CD
020478     END-IF.

      *
      * NEXT MODE FACTOR
      *
           IF  L2420-BILL-CHNG-CURR
020478*        MOVE SPACES              TO MIR-POL-NXT-MODE-FCT
020478         MOVE RPOL-POL-CRNT-MODE-FCT
020478                                  TO L0290-INPUT-V07
020478         MOVE 7                   TO L0290-PRECISION
020478         MOVE LENGTH OF MIR-PBRQST-MODE-FCT
020478                                  TO L0290-MAX-OUT-LEN
020478         PERFORM 0290-2000-FORMAT-FOR-MIR
020478             THRU 0290-2000-FORMAT-FOR-MIR-X
020478         MOVE L0290-OUTPUT-DATA   TO MIR-PBRQST-MODE-FCT
           ELSE
020478*        MOVE RPOL-POL-NXT-MODE-FCT TO L0290-INPUT-V07
020478         MOVE L2625-PBRQST-MODE-FCT TO L0290-INPUT-V07
               MOVE 7                   TO L0290-PRECISION
020478*        MOVE LENGTH OF MIR-POL-NXT-MODE-FCT
020478         MOVE LENGTH OF MIR-PBRQST-MODE-FCT
                                        TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
020478*        MOVE L0290-OUTPUT-DATA   TO MIR-POL-NXT-MODE-FCT
020478         MOVE L0290-OUTPUT-DATA   TO MIR-PBRQST-MODE-FCT
           END-IF.

020478*    MOVE RPOL-NXT-FCT-RESTR-IND  TO MIR-NXT-FCT-RESTR-IND.
020478     IF  L2420-BILL-CHNG-CURR
020478         MOVE RPOL-MODE-FCT-RESTR-IND
020478                                  TO MIR-DV-MODE-FCT-RESTR-IND
020478     ELSE
020478         MOVE L2625-MODE-FCT-RESTR-IND
020478                                  TO MIR-DV-MODE-FCT-RESTR-IND
020478     END-IF.
      *
      * NEXT POLICY FEE FACTOR
      *
           IF  L2420-BILL-CHNG-CURR
020478*        MOVE SPACES              TO MIR-POL-NXT-PFEE-FCT
020478         MOVE RPOL-POL-PFEE-FCT    TO L0290-INPUT-V07
020478         MOVE 7                   TO L0290-PRECISION
020478         MOVE LENGTH OF MIR-PBRQST-PFEE-FCT
020478                                  TO L0290-MAX-OUT-LEN
020478         PERFORM 0290-2000-FORMAT-FOR-MIR
020478             THRU 0290-2000-FORMAT-FOR-MIR-X
020478         MOVE L0290-OUTPUT-DATA   TO MIR-PBRQST-PFEE-FCT
           ELSE
020478*        MOVE RPOL-POL-NXT-PFEE-FCT TO L0290-INPUT-V07
020478         MOVE L2625-PBRQST-PFEE-FCT TO L0290-INPUT-V07
               MOVE 7                   TO L0290-PRECISION
020478*        MOVE LENGTH OF MIR-POL-NXT-PFEE-FCT
020478         MOVE LENGTH OF MIR-PBRQST-PFEE-FCT
                                        TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
020478*        MOVE L0290-OUTPUT-DATA   TO MIR-POL-NXT-PFEE-FCT
020478         MOVE L0290-OUTPUT-DATA   TO MIR-PBRQST-PFEE-FCT
           END-IF.

020478*    MOVE RPOL-NXT-PFEE-RESTR-IND TO MIR-NXT-PFEE-RESTR-IND.
020478     IF  L2420-BILL-CHNG-CURR
020478         MOVE RPOL-POL-PFEE-RESTR-IND
020478                                  TO MIR-PFEE-RESTR-IND
020478     ELSE
020478         MOVE L2625-PFEE-RESTR-IND
020478                                  TO MIR-PFEE-RESTR-IND
020478     END-IF.
      *
      * NEXT DRAW DAY
      *
           IF  L2420-BILL-CHNG-CURR
020478*        MOVE SPACES              TO MIR-POL-NXT-PMT-DRW-DY
020478         MOVE RPOL-POL-PMT-DRW-DY TO L0290-INPUT-V00
020478         MOVE ZERO                TO L0290-PRECISION
020478         MOVE LENGTH OF MIR-PBRQST-PMT-DRW-DY
020478                                  TO L0290-MAX-OUT-LEN
020478         PERFORM 0290-2000-FORMAT-FOR-MIR
020478             THRU 0290-2000-FORMAT-FOR-MIR-X
020478         MOVE L0290-OUTPUT-DATA   TO MIR-PBRQST-PMT-DRW-DY
           ELSE
020478*        MOVE RPOL-POL-NXT-PMT-DRW-DY TO L0290-INPUT-V00
020478         MOVE L2625-PBRQST-PMT-DRW-DY TO L0290-INPUT-V00
               MOVE ZERO                TO L0290-PRECISION
020478*        MOVE LENGTH OF MIR-POL-NXT-PMT-DRW-DY
020478         MOVE LENGTH OF MIR-PBRQST-PMT-DRW-DY
                                        TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
020478*        MOVE L0290-OUTPUT-DATA   TO MIR-POL-NXT-PMT-DRW-DY
020478         MOVE L0290-OUTPUT-DATA   TO MIR-PBRQST-PMT-DRW-DY
           END-IF.

      *
      * NEXT SUNDRY AMOUNT
      *
           IF  L2420-BILL-CHNG-CURR
020478*        MOVE SPACES              TO MIR-POL-NXT-SNDRY-AMT
020478         MOVE RPOL-POL-SNDRY-AMT  TO L0290-INPUT-V02
020478         MOVE 2                   TO L0290-PRECISION
020478         MOVE LENGTH OF MIR-PBRQST-SNDRY-AMT
020478                                  TO L0290-MAX-OUT-LEN
020478         PERFORM 0290-2000-FORMAT-FOR-MIR
020478             THRU 0290-2000-FORMAT-FOR-MIR-X
020478         MOVE L0290-OUTPUT-DATA   TO MIR-PBRQST-SNDRY-AMT
           ELSE
020478*        MOVE RPOL-POL-NXT-SNDRY-AMT  TO L0290-INPUT-V02
020478         MOVE L2625-PBRQST-SNDRY-AMT   TO L0290-INPUT-V02
               MOVE 2                   TO L0290-PRECISION
020478*        MOVE LENGTH OF MIR-POL-NXT-SNDRY-AMT
020478         MOVE LENGTH OF MIR-PBRQST-SNDRY-AMT
                                        TO L0290-MAX-OUT-LEN
               PERFORM 0290-2000-FORMAT-FOR-MIR
                   THRU 0290-2000-FORMAT-FOR-MIR-X
020478*        MOVE L0290-OUTPUT-DATA   TO MIR-POL-NXT-SNDRY-AMT
020478         MOVE L0290-OUTPUT-DATA   TO MIR-PBRQST-SNDRY-AMT
           END-IF.
      *
      * NEXT SUNDRY REASON
      *
020478*    MOVE RPOL-NXT-SNDRY-REASN-CD TO MIR-NXT-SNDRY-REASN-CD.
020478     IF  L2420-BILL-CHNG-CURR
020478         MOVE RPOL-POL-SNDRY-REASN-CD
020478                                  TO MIR-SNDRY-REASN-CD
020478     ELSE
020478         MOVE L2625-SNDRY-REASN-CD
020478                                  TO MIR-SNDRY-REASN-CD
020478     END-IF.

      *
      * CURR BILLING TYPE
      *
020478*    MOVE RPOL-POL-BILL-TYP-CD    TO MIR-POL-BILL-TYP-CD.
020478     MOVE WS-H-POL-BILL-TYP-CD    TO MIR-POL-BILL-TYP-CD.
      *
      * CURR BILLING MODE
      *
020478*    MOVE RPOL-POL-BILL-MODE-CD   TO MIR-POL-BILL-MODE-CD.
020478     MOVE WS-H-POL-BILL-MODE-CD   TO MIR-POL-BILL-MODE-CD.
      *
      * CURR MODE FACTOR
      *
020478*    MOVE RPOL-POL-CRNT-MODE-FCT  TO L0290-INPUT-V07.
020478     MOVE WS-H-POL-CRNT-MODE-FCT  TO L0290-INPUT-V07.
           MOVE 7                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-CRNT-MODE-FCT
                                        TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO MIR-POL-CRNT-MODE-FCT.

      *
      * CURR POLICY FEE FACTOR
      *
020478*    MOVE RPOL-POL-PFEE-FCT      TO L0290-INPUT-V07.
020478     MOVE WS-H-POL-PFEE-FCT      TO L0290-INPUT-V07.
           MOVE 7                      TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-PFEE-FCT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-PFEE-FCT.

020478*    MOVE RPOL-MODE-FCT-RESTR-IND TO MIR-MODE-FCT-RESTR-IND.
020478     MOVE WS-H-MODE-FCT-RESTR-IND TO MIR-MODE-FCT-RESTR-IND.
020478*    MOVE RPOL-POL-PFEE-RESTR-IND TO MIR-POL-PFEE-RESTR-IND.
020478     MOVE WS-H-POL-PFEE-RESTR-IND TO MIR-POL-PFEE-RESTR-IND.

      *
      * CURR DRAW DAY
      *
020478*    MOVE RPOL-POL-PMT-DRW-DY     TO L0290-INPUT-V00.
020478     MOVE WS-H-POL-PMT-DRW-DY     TO L0290-INPUT-V00.
           MOVE ZERO                    TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-PMT-DRW-DY
                                        TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO MIR-POL-PMT-DRW-DY.

      *
      * CURR SUNDRY AMOUNT
      *
020478*    MOVE RPOL-POL-SNDRY-AMT     TO L0290-INPUT-V02.
020478     MOVE WS-H-POL-SNDRY-AMT     TO L0290-INPUT-V02.
           MOVE 2                      TO L0290-PRECISION.
025102*    MOVE LENGTH OF MIR-POL-NXT-SNDRY-AMT
025102     MOVE LENGTH OF MIR-POL-SNDRY-AMT
                                       TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA      TO MIR-POL-SNDRY-AMT.
      *
      * CURR SUNDRY REASON
      *
020478*    MOVE RPOL-POL-SNDRY-REASN-CD TO MIR-POL-SNDRY-REASN-CD.
020478     MOVE WS-H-POL-SNDRY-REASN-CD TO MIR-POL-SNDRY-REASN-CD.

           PERFORM  2430-1000-BUILD-PARM-INFO
               THRU 2430-1000-BUILD-PARM-INFO-X.

           MOVE RPOL-POL-ID             TO L2430-POL-ID.
           MOVE ZERO                    TO I.

           PERFORM  2430-2100-GET-OWNER
               THRU 2430-2100-GET-OWNER-X.

           IF L2430-RETRN-OK
               INITIALIZE                        L0620-INPUT-PARM-INFO
               IF L2430-CLI-SEX-COMPANY
                   MOVE L2430-CLI-ENTR-CO-NM  TO L0620-CLI-CO-NM
               ELSE
                   MOVE L2430-CLI-ENTR-GIV-NM TO L0620-CLI-GIV-NM
                   MOVE L2430-CLI-ENTR-SUR-NM TO L0620-CLI-SUR-NM
                   MOVE L2430-CLI-MID-INIT-NM TO L0620-CLI-MID-INIT-NM
                   MOVE L2430-CLI-SFX-NM      TO L0620-CLI-SFX-NM
               END-IF
               MOVE L2430-CLI-SEX-CD    TO L0620-CLI-SEX-CD
               PERFORM  0620-1000-FORMAT-SCREEN-NAME
                   THRU 0620-1000-FORMAT-SCREEN-NAME-X
               MOVE L0620-SCREEN-NAME   TO MIR-DV-OWN-CLI-NM
           ELSE
               MOVE SPACES              TO MIR-DV-OWN-CLI-NM
           END-IF.

           MOVE RPOL-POL-MPREM-AMT      TO L0290-INPUT-V02.
           MOVE 2                       TO L0290-PRECISION.
           MOVE LENGTH OF MIR-POL-MPREM-AMT
                                        TO L0290-MAX-OUT-LEN.
           PERFORM 0290-2000-FORMAT-FOR-MIR
              THRU 0290-2000-FORMAT-FOR-MIR-X.
           MOVE L0290-OUTPUT-DATA       TO MIR-POL-MPREM-AMT.

       9200-MOVE-RECORD-TO-MIR-X.
           EXIT.
020478
020478*-----------------------
020478 9210-SET-CONFIRM-PAGE.
020478*-----------------------
020478
020478*
020478* OFF ANNIVERSARY PAID DATE
020478*
020478     MOVE WS-OFFANNV-PD-TO-DT     TO L1640-INTERNAL-DATE
020478     IF  MIR-POL-OFFANNV-PD-DT    = SPACES
020478         IF  WS-OFFANNV-PD-TO-DT  = EBLCH-BLANK-FIELD-CHAR
020478             MOVE WWKDT-ZERO-DT   TO L1640-INTERNAL-DATE
020478         END-IF
020478     END-IF.
020478
020478     PERFORM  1640-8000-INTERNAL-TO-MIR
020478         THRU 1640-8000-INTERNAL-TO-MIR-X.
020478     MOVE L1640-EXTERNAL-DATE     TO MIR-POL-OFFANNV-PD-DT.
020478
020478 9210-SET-CONFIRM-PAGE-X.
020478     EXIT.
      /
      *--------------------------
       9300-SETUP-MSIN-REFERENCE.
      *--------------------------

           MOVE SPACES                   TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE       TO WGLOB-REF-COMPANY-CODE.

           SET  WGLOB-REF-POLICY         TO TRUE.
           MOVE MIR-POL-ID               TO WGLOB-REF-POLICY-ID.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

      /
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.

025970     PERFORM  0201-0000-INIT-PARM-INFO
025970         THRU 0201-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0289-0000-INIT-PARM-INFO
025970         THRU 0289-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0620-0000-INIT-PARM-INFO
025970         THRU 0620-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1640-0000-INIT-PARM-INFO
025970         THRU 1640-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1660-0000-INIT-PARM-INFO
025970         THRU 1660-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1670-0000-INIT-PARM-INFO
025970         THRU 1670-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1680-0000-INIT-PARM-INFO
025970         THRU 1680-0000-INIT-PARM-INFO-X.
031037
031037     PERFORM  2408-0000-INIT-PARM-INFO
031037         THRU 2408-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2420-0000-INIT-PARM-INFO
025970         THRU 2420-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2430-0000-INIT-PARM-INFO
025970         THRU 2430-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2625-0000-INIT-PARM-INFO
025970         THRU 2625-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  3330-0000-INIT-PARM-INFO
025970         THRU 3330-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4750-0000-INIT-PARM-INFO
025970         THRU 4750-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  4780-0000-INIT-PARM-INFO
025970         THRU 4780-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8960-0000-INIT-PARM-INFO
025970         THRU 8960-0000-INIT-PARM-INFO-X.
025970
           INITIALIZE WS-WORKING-STORAGE.
025970     INITIALIZE FREQUENTLY-USED-INDICES.
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970
025970     SET WS-TWRK-KEY-DEFAULT        TO TRUE.
025970
025970     MOVE SPACES                    TO WWKDT-WORK-FIELDS.

           MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.
020478     SET WS-BILL-CHNG-CURR          TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *****************************************************************
      *  PROCESSING COPYBOOKS                                         *
      *****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

       COPY XCPPEXIT.
      /
       COPY NCPPCVGR.
       COPY NCPPCVGS.
      /
       COPY XCPPINIT.
      /
       COPY CCPPPLIN.
       COPY CCPPMIDT.
      /
020478 COPY CCPPFPCK.
020478/
       COPY CCPPTWTS REPLACING ==:VAR1:== BY  POL
                                '$VAR2'   BY 'POL'.
       COPY XCPL8090.
      /
      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
025970 COPY XCPS1670.
025970 COPY XCPS8090.
       COPY CCPSPGA.

025970 COPY CCPS0201.
       COPY CCPL0201.
      /
       COPY CCPS0289.
       COPY CCPL0289.
      /
025970 COPY CCPS0620.
       COPY CCPL0620.
031037/
031037 COPY CCPS2408.
031037 COPY CCPL2408.
      /
       COPY CCPS2420.
       COPY CCPL2420.
      /
       COPY CCPS2430.
       COPY CCPL2430.
      /
020478 COPY CCPS2625.
020478 COPY CCPL2625.
020478/
020478 COPY CCPS2626.
020478 COPY CCPL2626.
020478/
       COPY CCPS3330.
       COPY CCPL3330.
      /
       COPY CCPS4750.
       COPY CCPL4750.
      /
       COPY CCPS4780.
       COPY CCPL4780.
      /
       COPY CCPS5400.
       COPY CCPL5400.
      /
020478 COPY XCPL0035.
020478/
       COPY XCPL0260.
      /
025970 COPY XCPS0280.
       COPY XCPL0280.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
025970 COPY XCPS1640.
       COPY XCPL1640.
025970 COPY XCPS1660.
       COPY XCPL1660.
025970 COPY XCPS1680.
       COPY XCPL1680.
      /
       COPY XCPS8960.
       COPY XCPL8960.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULES                                     *
      *****************************************************************
       COPY CCPNPOL.
       COPY CCPUPOL.
      /
020478 COPY CCPAPORQ.
020478 COPY CCPCPORQ.
020478/
       COPY CCPNCVG.
       COPY CCPUCVG.
      /
       COPY CCPNPH.
      /
       COPY CCPBPHST.
      /

      *****************************************************************
      *  ERROR HANDLING ROUTINES                                      *
      *****************************************************************
026070*COPY XCCPABND.
026070 COPY XCCPERR.
       COPY XCCP0030.
      /
      *****************************************************************
      **                 END OF PROGRAM 'CSOM7902'                   **
      *****************************************************************
