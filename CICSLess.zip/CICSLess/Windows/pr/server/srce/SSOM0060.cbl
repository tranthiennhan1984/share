       IDENTIFICATION DIVISION.
      *
       PROGRAM-ID. SSOM0060.
      *
       COPY XCWWCRHT.
      *
      *****************************************************************
      **  MEMBER :  SSOM0060                                         **
      **  REMARKS:  FMAS: MAINTAIN INVESTMENT COVERAGE (FC) AND      **
      **            COVERAGE FUND (FS) RECORDS.                      **
      **            THIS MODULE IS USED TO MAINTAIN FC AND FS        **
      **            RECORDS.  IN INQUIRE MODE, THE FUNDS CURRENTLY   **
      **            ASSOCIATED WITH THE SEGREGATED FUND COVERAGE     **
      **            ARE DISPLAYED.  IN MAINTAIN MODE, THESE FUNDS    **
      **            AND THE PERCENTAGES ALLOCATED TO EACH FUND FOR   **
      **            DEPOSITS AND WITHDRAWALS CAN BE ADDED OR         **
      **            CHANGED.                                         **
      **  DOMAIN :  CV                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
557660**  5.5       CODE CLEANUP                                     **
557708**  5.5       ABEND HANDLING                                   **
007766**  5.6       ARCHITECTURE CHANGES TO SUPPORT PASSING          **
007766**            PARAMETERS VIA AN ADDRESS                        **
012141**  5.6V      PORTFOLIO EXPANSION                              **
012146**  5.6V      MORTALITY AND EXPENSE CHARGES                    **
012696**  5.6V      POLICY ALLOCATIONS                               **
014035**  5.6V      CODE CLEANUP & STANDARDIZATION                   **
014468**  5.6V      SEG #KH2 - MAX NUMBER OF FUNDS ON FMAS, PALC.    **
012624**  6.0       POLICY ACCESS VERIFICATION CHANGES               **
013578**  6.0       ELIMINATE SUPPORT FOR CHARACTER INTERFACE        **
014588**  6.0       MIR CHANGES                                      **
014590**  6.0       ARCHITECTURAL CHANGES                            **
014660**  6.0       REMOVAL OF XCPPMEXT                              **
015543**  6.0       CODE CLEANUP                                     **
014221**  6.2       LOGICAL LOCKING                                  **
014591**  6.2       COMBINE PLAN-ID & RS                             **
015904**  6.2       CLEANUP MIR FIELD NAMES                          **
016440**  6.2       COMBINE NEWBUS AND ADMIN                         **
016537**  6.2       CODE CLEAN UP                                    **
016548**  6.2       CHANGE COMP TO BINARY                            **
017685**  6.2       PCR - PASSING BACK WRONG COVERAGE STATUS CODE    **
017310**  6.3       PASS COVERAGE NUMBER TO FSLC8200 SO THAT ONLY    **
017310**            FC RECORDS ARE CHECKED FOR CVG BEING PROCESSED   **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019444**  6.3       FIX FUND CONTRACT MASTER FOR INQUIRY/UPDATE      **
017364**  6.4       REMOVE VERSION COUNTERS FROM SEGFUND TABLES      **
020452**  6.4       FOREIGN CONTENT FOR RRSP PRODUCTS                **
020463**  6.4       INVESTOR PROFILES                                **
020874**  6.4       MIR STANDARDIZED NUMERIC FORMATTING              **
021311**  6.4       MULTI-PLATFORM SUPPORT                           **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023112**  6.5       CASH FLOW DESTINATION INSTRUCTIONS               **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
026070**  6.6       ERROR HANDLER                                    **
020478**  6.6       FUTURE DATED TRANSACTION                         **
026766**  6.6       PERFORMANCE MONITORING                           **
032329**  7.0       99 COVERAGES AND 98 FUNDS HANDLING               **
034802**  7.1       RESTRUCTURE NEXT SENTENCE STATEMENT              **
CVMQ71**  7.1       CICS REPLACEMENT                                 **
      *****************************************************************
       ENVIRONMENT DIVISION.
      **********************
      *
      ***************
       DATA DIVISION.
      ***************
      *
       WORKING-STORAGE SECTION.
      *
       COPY XCWWPGWS REPLACING '$VAR1' BY 'SSOM0060'.
026766 COPY XCWWTIMR.
026766 COPY XCWLTIMR.
      *

       COPY SQLCA.
018764*COPY XCWLPTR.


014590*COPY XCWL0030.
007766 COPY XCWWCVGM.
012141 COPY XCWWFNDM.
014221 COPY CCWWLOCK.

       01  WS-PGM-WORK-AREA.
013578*    05  WS-FUNC-CODE                 PIC X(01).
013578*        88  VALID-FUNC-CODE          VALUE 'I' 'M'.
013578*        88  FMAS-INQUIRE             VALUE 'I'.
013578*        88  FMAS-MAINTAIN            VALUE 'M'.
013578     05  WS-BUS-FCN-ID                PIC X(04).
013578         88  WS-BUS-FCN-VALID         VALUE '2300' '2302'.
013578         88  WS-BUS-FCN-RETRIEVE      VALUE '2300'.
013578         88  WS-BUS-FCN-UPDATE        VALUE '2302'.
025970*    05  WS-TWRK-KEY                  PIC X(04) VALUE '2300'.
           05  WS-DATA-EDITS                PIC X(01).
               88  WS-DATA-EDITS-OK         VALUE 'Y'.
               88  WS-DATA-EDITS-FAILED     VALUE 'N'.
           05  WS-CROSS-EDITS               PIC X(01).
               88  WS-CROSS-EDITS-OK        VALUE 'Y'.
               88  WS-CROSS-EDITS-FAILED    VALUE 'N'.
           05  WS-POLICY-READ               PIC X(01).
               88  WS-POLICY-READ-OK        VALUE 'Y'.
               88  WS-POLICY-READ-FAILED    VALUE 'N'.
           05  BLANK-OUT-FUND-SWITCH        PIC X(01).
025970*    05  WS-OK                        PIC X(01)  VALUE 'Y'.
025970*    05  WS-FAILED                    PIC X(01)  VALUE 'N'.
016548*    05  WS-DISPLAY-LINES             PIC S9(04)  COMP
025970*    05  WS-DISPLAY-LINES             PIC S9(04)  BINARY
025970*                                     VALUE +25.
016548*    05  WS-LINES                     PIC S9(04)  COMP.
016548     05  WS-LINES                     PIC S9(04)  BINARY.
016548*    05  WS-CVG                       PIC S9(04)  COMP.
016548     05  WS-CVG                       PIC S9(04)  BINARY.
016548*    05  I                            PIC S9(04)  COMP.
016548     05  I                            PIC S9(04)  BINARY.
016548*    05  J                            PIC S9(04)  COMP.
016548     05  J                            PIC S9(04)  BINARY.
016548*    05  WS-FUND-COUNT                PIC S9(04)  COMP.
016548     05  WS-FUND-COUNT                PIC S9(04)  BINARY.

025970 01  WS-CONSTANTS.
025970     05  WS-TWRK-KEY                  PIC X(04).
025970         88  WS-TWRK-KEY-DEFAULT      VALUE '2300'.
025970     05  WS-OK                        PIC X(01).
025970         88  WS-OK-DEFAULT            VALUE 'Y'.
025970     05  WS-FAILED                    PIC X(01).
025970         88  WS-FAILED-DEFAULT        VALUE 'N'.
025970     05  WS-DISPLAY-LINES             PIC S9(04) BINARY.
032329*        88  WS-DISPLAY-LINES-DEFAULT VALUE +25.
032329         88  WS-DISPLAY-LINES-DEFAULT VALUE 98.

       01  WS-EDIT-FIELDS.
017685     05  WS-CVG-NUM                   PIC 9(02).
           05  WS-EDIT-2-0                  PIC 9(02).
           05  WS-EDIT-3-4                  PIC 9(03).9(04).

       01  WS-OUTPUT-FIELDS.
           05  WS-OUTPUT                    PIC S9(18)       COMP-3.
           05  WS-OUTPUT-4                  REDEFINES  WS-OUTPUT
                                            PIC S9(14)V9(04) COMP-3.

012696 01  WS-CDSI-FIELDS.
012696     05  WS-CDSI-EDITS                PIC X(01).
012696         88  WS-CDSI-EDITS-OK         VALUE 'Y'.
012696         88  WS-CDSI-EDITS-FAILED     VALUE 'N'.
012696     05  WS-CDSI-FUND-TABLE.
012696         10  WS-CDSI-FUND-ID          OCCURS  139 TIMES
012696                                      PIC X(005).
012696     05  WS-FMAS-FUND-TABLE.
032329*        10  WS-FMAS-FUND-ERROR-IND   OCCURS  25 TIMES
032329         10  WS-FMAS-FUND-ERROR-IND   OCCURS  98 TIMES
012696                                      PIC X(001).
012696         88  WS-FMAS-FUND-ERROR       VALUE 'Y'.
012696
016548*    05  WS-IX1                       PIC S9(04)  COMP.
016548     05  WS-IX1                       PIC S9(04)  BINARY.
016548*    05  WS-IX2                       PIC S9(04)  COMP.
016548     05  WS-IX2                       PIC S9(04)  BINARY.
016548*    05  WS-IX3                       PIC S9(04)  COMP.
016548     05  WS-IX3                       PIC S9(04)  BINARY.
012696     05  WS-CDSI-REC-SAVED-IND        PIC X(01).
012696         88  WS-CDSI-RECORD-SAVED     VALUE 'Y'.
012696         88  WS-CDSI-RECORD-NOT-SAVED VALUE 'N'.
012696     05  WS-CDSI-NEED-EDIT-IND        PIC X(01).
012696         88  WS-CDSI-NO-EDIT-NEEDED   VALUE 'N'.
012696         88  WS-CDSI-EDIT-NEEDED      VALUE 'Y'.
012696     05  WS-MESG-IND                  PIC X(01).
012696         88  WS-MESSAGE-DISPLAYED     VALUE 'Y'.
012696         88  WS-MESSAGE-NOT-DISPLAYED VALUE 'N'.
      *
       COPY XCWWWKDT.
014035*COPY XCWEBLCH.
      *
014588*COPY CCWCCOMM.
      *
      *
012696 COPY CCFWCAIN.
012696 COPY CCFRCAIN.
      *
012696 COPY CCFWCDSI.
012696 COPY CCFRCDSI.
      *
       COPY CCFWCVG.
       COPY CCFRCVG.
      *
       COPY CCFWPOL.
      *
       COPY SCFRFC.
      *
       COPY SCFRFS.
      *
020463 COPY CCFRPD.
020463 COPY CCFWPD.
      /
020478 COPY CCWL2626.
       COPY SCWL0500.
      *
020452 COPY CCWLFRNE.
020452*
       COPY SCWLSEGF.
      *
020463 COPY CCWL2735.
      *
       COPY CCWL5400.
      *
       COPY XCWL0280.
020874 COPY XCWL0290.
020452 COPY XCWL0316.
      *
014221 COPY XCWL8090.
      *
007766*01  WGLOB-GLOBAL-AREA.
007766*COPY XCWWGLOB.
      *
      *
       COPY CCWLPGA.
      *
       COPY CCFRPOL.
       COPY CCWWCVGS.
014468*
014468 COPY FCWLFUND.
014468*
014468 COPY FCWL8200.
014468*
       LINKAGE SECTION.
      *****************

CVMQ71 COPY XCWWDFHQ.
      *
007766 01 WGLOB-GLOBAL-AREA.
007766 COPY XCWWGLOB.
       COPY SCWM0060.
      *
CVMQ71*PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA
CVMQ71*                         MIR-PARM-AREA.
CVMQ71 PROCEDURE DIVISION USING DFHEIBLK
CVMQ71                          DFHCOMMAREA
CVMQ71                          WGLOB-GLOBAL-AREA
CVMQ71                          MIR-PARM-AREA.

      ***************
       0000-MAINLINE.
      ***************

026070*    PERFORM  ABND-1000-HANDLE-ABEND
026070*        THRU ABND-1000-HANDLE-ABEND-X.

021311     PERFORM  9990-INIT-WORKING-STORAGE
021311         THRU 9990-INIT-WORKING-STORAGE-X.

026766     PERFORM  TIMR-6000-MAIN-ENTRY-TIME
026766         THRU TIMR-6000-MAIN-ENTRY-TIME-X.

           PERFORM  INIT-1000-INITIALIZE
               THRU INIT-1000-INITIALIZE-X.

014588*    IF  CCOMM-PROGRAM-NUMBER NOT = WGLOB-MAIN-PGM-NUMBER
014588*        MOVE SPACES           TO CCOMM-SPECIFIC-AREA
014588*    END-IF.

021311*    MOVE WFNDM-MAX-WFUND-NUM  TO  WS-DISPLAY-LINES.

           PERFORM  2000-PROCESS-REQUEST
               THRU 2000-PROCESS-REQUEST-X.

020478     PERFORM  FPCK-1000-CHECK-POLICY
020478         THRU FPCK-1000-CHECK-POLICY-X.
020478
           PERFORM  EXIT-1000-FINALIZE
               THRU EXIT-1000-FINALIZE-X.

026766     PERFORM  TIMR-7000-MAIN-EXIT-TIME
026766         THRU TIMR-7000-MAIN-EXIT-TIME-X.

           GOBACK.

       0000-MAINLINE-X.
           EXIT.

      *****************************************************************
      *  PERFORM SECURITY PROCESSING AND INVOKE MODULES TO
      *  PROCESS USER REQUEST
      *****************************************************************
       2000-PROCESS-REQUEST.

014588*    IF  MIR-POL-ID-BASE = SPACES
014588*    AND MIR-POL-ID-SFX = SPACES
014588*        MOVE CCOMM-POL-ID-BASE     TO MIR-POL-ID-BASE
014588*        MOVE CCOMM-POL-ID-SFX      TO MIR-POL-ID-SFX
014588*        MOVE '01'                  TO MIR-CVG-NUM
014588*    END-IF.

           PERFORM  9300-SETUP-MSIN-REFERENCE
               THRU 9300-SETUP-MSIN-REFERENCE-X.
      *
      *    MOVE ENTER CODE TO A WORK FIELD.
      *
025970*    MOVE MIR-BUS-FCN-ID            TO WS-BUS-FCN-ID.
017685     MOVE MIR-CVG-NUM               TO WS-CVG-NUM.

      *
      *    VALIDATE KEY INPUT FOR NUMERICS AND CORRECT DATE FORMATS
      *
           PERFORM  7200-FORMAT-KEY-INPUT
               THRU 7200-FORMAT-KEY-INPUT-X.
           IF  WS-DATA-EDITS-FAILED
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  WS-BUS-FCN-RETRIEVE
               PERFORM  3000-PROCESS-RETRIEVE
                   THRU 3000-PROCESS-RETRIEVE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

           IF  WS-BUS-FCN-UPDATE
               PERFORM  5000-PROCESS-UPDATE
                   THRU 5000-PROCESS-UPDATE-X
               GO TO 2000-PROCESS-REQUEST-X
557660     END-IF.

       2000-PROCESS-REQUEST-X.
           EXIT.

      *****************************************************************
      *  INQUIRY PROCESSING: SETUP BROWSE KEYS, BEGIN BROWSE, AND
      *  LOAD DATA UNTIL END-OF-FILE OR SCREEN IS FULL.
      *****************************************************************
       3000-PROCESS-RETRIEVE.

           PERFORM  9100-BLANK-DATA-FIELDS
               THRU 9100-BLANK-DATA-FIELDS-X.

           PERFORM  9112-FORMAT-FUND-NO
               THRU 9112-FORMAT-FUND-NO-X
               VARYING I FROM 1 BY 1
012141         UNTIL   I > WFNDM-MAX-WFUND-NUM.

      *
      *  READ THE POLICY AND COVERAGE
      *
           PERFORM  3110-POLICY-READ
               THRU 3110-POLICY-READ-X.
           IF  WS-POLICY-READ-FAILED
               GO TO 3000-PROCESS-RETRIEVE-X
557660     END-IF.
      *
      *    SET UP KEY FOR FC/FS READ
      *
           PERFORM  7100-BUILD-FMAS-KEY
               THRU 7100-BUILD-FMAS-KEY-X.
      *
      *    THE LINK TO SSLS0500 WILL READ THE FC AND ALL FS RECORDS
      *
           SET  LSEGF-INV-CVG-CFN-OPT-READ-INQ TO TRUE.
           PERFORM  0500-1000-PROCESS-FC-FS
               THRU 0500-1000-PROCESS-FC-FS-X.
           IF  L0500-RETRN-ERROR
               GO TO 3000-PROCESS-RETRIEVE-X
           END-IF.
      *
      *    DISPLAY DATA ON THE SCREEN
      *
           PERFORM  3100-DISPLAY-RECORD
               THRU 3100-DISPLAY-RECORD-X.
      *
      *  COMPLETION MESSAGE
      *
           MOVE 'XS00000002'      TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

       3000-PROCESS-RETRIEVE-X.
           EXIT.

      *****************************************************************
      *  INQUIRY DISPLAY PROCESSING: DISPLAY THE CURRENT FC AND FS
      *  RECORDS ON THE SCREEN
      *****************************************************************
       3100-DISPLAY-RECORD.
      *
      *  DISPLAY POLICY AND COVERAGE INFORMATION
      *

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       3100-DISPLAY-RECORD-X.
           EXIT.

      *****************************************************************
      *  POLICY-READ: READ THE POLICY AND COVERAGE RECORDS
      *****************************************************************
       3110-POLICY-READ.

           MOVE WS-OK             TO WS-POLICY-READ.
      *
      *  READ THE POLICY
      *
           MOVE MIR-POL-ID-BASE   TO WPOL-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX    TO WPOL-POL-ID-SFX.

014221*    PERFORM  POL-1000-READ
014221*        THRU POL-1000-READ-X.

014221     EVALUATE TRUE
014221       WHEN  WS-BUS-FCN-RETRIEVE
014221             PERFORM  POL-1000-READ-TWRK-TS
014221                 THRU POL-1000-READ-TWRK-TS-X
014221       WHEN  WS-BUS-FCN-UPDATE
014221             PERFORM  POL-2000-UPDATE-TWRK-TS
014221                 THRU POL-2000-UPDATE-TWRK-TS-X
014221             IF  MIR-RETRN-TS-MISMATCH
014221*  TIMESTAMP MISMATCH - TABLE (@1) WITH KEY @2, PROCESS
014221*  NOT COMPLETE
014221                 MOVE 'XS00000303'    TO WGLOB-MSG-REF-INFO
014221                 MOVE 'POL'           TO WGLOB-MSG-PARM (01)
014221                 MOVE WPOL-KEY        TO WGLOB-MSG-PARM (02)
014221                 PERFORM  0260-1000-GENERATE-MESSAGE
014221                     THRU 0260-1000-GENERATE-MESSAGE-X
014221                 MOVE WS-FAILED       TO WS-POLICY-READ
014221                 GO TO 3110-POLICY-READ-X
014221             ELSE
014221                 IF  WPOL-IO-OK
014221                     PERFORM  POL-3000-UNLOCK
014221                         THRU POL-3000-UNLOCK-X
014221                 END-IF
014221             END-IF
014221     END-EVALUATE.

           IF  WPOL-IO-NOT-FOUND
               MOVE WPOL-KEY      TO WGLOB-MSG-PARM (1)
               MOVE 'XS00000070'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED     TO WS-POLICY-READ
               GO TO 3110-POLICY-READ-X
557660     END-IF.
      *
      *  UPDATE COMM AREA WITH THE CURRENT POLICY
      *
014588*    MOVE MIR-POL-ID-BASE   TO CCOMM-POL-ID-BASE.
014588*    MOVE MIR-POL-ID-SFX    TO CCOMM-POL-ID-SFX.
      *
      *  READ IN ALL COVERAGES
      *
           PERFORM  3115-COVERAGE-READ
               THRU 3115-COVERAGE-READ-X.

           PERFORM  PGA-1000-BUILD-PARMS
               THRU PGA-1000-BUILD-PARMS-X.

       3110-POLICY-READ-X.
           EXIT.

      *****************************************************************
      *  COVERAGE READ: READ THE COVERAGE RECORDS
      *****************************************************************
       3115-COVERAGE-READ.

           MOVE ZERO TO WGLOB-MSG-ERROR-SW.

           PERFORM  CVGS-1000-LOAD-CVGS-ARRAY
               THRU CVGS-1000-LOAD-CVGS-ARRAY-X.

           IF  WGLOB-MSG-ERROR-SW NOT = ZERO
               MOVE WS-FAILED     TO WS-POLICY-READ
               GO TO 3115-COVERAGE-READ-X
           END-IF.

           MOVE MIR-CVG-NUM       TO WS-EDIT-2-0.
           MOVE WS-EDIT-2-0       TO I.
           IF  I > RPOL-POL-CVG-REC-CTR-N
               MOVE MIR-CVG-NUM   TO WGLOB-MSG-PARM (1)
      *        MSG: COVERAGE DOES NOT EXIST
               MOVE 'XS00000080'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED     TO WS-POLICY-READ
               GO TO 3115-COVERAGE-READ-X
           END-IF.

014591*    MOVE WCVGS-PLAN-ID-BASE (I)    TO LSEGF-PLAN-ID-BASE.
014591*    MOVE WCVGS-PLAN-ID-RS (I)      TO LSEGF-PLAN-ID-RS.
014591     MOVE WCVGS-PLAN-ID (I)         TO LSEGF-PLAN-ID.
012146     MOVE WCVGS-CVG-UNIT-TYP-CD (I) TO LSEGF-CVG-UNIT-TYP-CD.
           IF  NOT WCVGS-CVG-INS-TYP-SEG-FUND (I)
               MOVE MIR-CVG-NUM   TO WGLOB-MSG-PARM (1)
               MOVE 'SS00600014'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED     TO WS-POLICY-READ
           END-IF.

       3115-COVERAGE-READ-X.
           EXIT.

      *****************************************************************
      *  UPDATE PROCESSING:
      *****************************************************************
       5000-PROCESS-UPDATE.

           PERFORM  5200-PROCESS-UPDATE
               THRU 5200-PROCESS-UPDATE-X.

       5000-PROCESS-UPDATE-X.
           EXIT.

       5200-PROCESS-UPDATE.

           PERFORM  9112-FORMAT-FUND-NO
               THRU 9112-FORMAT-FUND-NO-X
               VARYING I FROM 1 BY 1
012141         UNTIL   I > WFNDM-MAX-WFUND-NUM.

      *
      *  READ THE POLICY AND COVERAGE
      *
           PERFORM  3110-POLICY-READ
               THRU 3110-POLICY-READ-X.

020463* NEED TO GET INVESTOR PROFILE INFORMATION.

020463     PERFORM 2735-1000-BUILD-PARM-INFO
020463        THRU 2735-1000-BUILD-PARM-INFO-X.
020463     MOVE RPOL-POL-ID                TO L2735-POL-ID.
020463     PERFORM 2735-1000-GET-PRFL
020463        THRU 2735-1000-GET-PRFL-X.

020463     IF  L2735-RETRN-PRFL-NOT-FND
020463         CONTINUE
020463     ELSE
020463* CHECK IF CVG SIDE FUND TYPE F
020463         MOVE WCVGS-PLAN-ID (WS-CVG-NUM)  TO  WPD-PLAN-ID
020463
020463         PERFORM  PD-1000-READ
020463             THRU PD-1000-READ-X
020463
020463         IF (RPD-PLAN-FND-TYP-SIDE
020463         OR  RPD-PLAN-COLFND)
020463         AND WCVGS-CVG-INS-TYP-SEG-FUND (WS-CVG-NUM)
020463             CONTINUE
020463         ELSE
020463*MSG: NO UPDATES ALLOWED ON FC/FS WHEN A PROFILE EXISTS
020463             MOVE 'SS00600004'        TO WGLOB-MSG-REF-INFO
020463             PERFORM  0260-1000-GENERATE-MESSAGE
020463                 THRU 0260-1000-GENERATE-MESSAGE-X
020463             GO TO 5200-PROCESS-UPDATE-X
020463         END-IF
020463     END-IF.

           PERFORM  7100-BUILD-FMAS-KEY
               THRU 7100-BUILD-FMAS-KEY-X.
      *
      *    THE LINK TO SSLS0500 WILL READ THE FC AND ALL FS RECORDS
      *
           SET  LSEGF-INV-CVG-CFN-OPT-READ-INQ TO TRUE.
           PERFORM  0500-1000-PROCESS-FC-FS
               THRU 0500-1000-PROCESS-FC-FS-X.
           MOVE LSEGF-INV-CVG-REC-INFO TO RFC-REC-INFO.
      *
      *    MSG: LOST RECORD (@1) IN MAINTAIN - CONTACT SYSTEMS
      *
           IF  WS-POLICY-READ-FAILED
           OR  L0500-RETRN-ERROR
               MOVE 'XS00000006'  TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               GO TO 5200-PROCESS-UPDATE-X
557660     END-IF.

           PERFORM  7300-DATA-EDITS
               THRU 7300-DATA-EDITS-X.

012696*    PERFORM  7400-CROSS-EDITS
012696*        THRU 7400-CROSS-EDITS-X.
      *
      *  EXIT WHEN EDIT ERRORS HAVE OCCURED
      *
           IF  WS-DATA-EDITS-OK
012696*    AND WS-CROSS-EDITS-OK
034802*        NEXT SENTENCE
034802         CONTINUE
           ELSE
               GO TO 5200-PROCESS-UPDATE-X
557660     END-IF.
      *
      *  NO ERROR - LINK TO FC/FS MODULE FOR UPDATE
      *

           MOVE WGLOB-PROCESS-DATE      TO LSEGF-INV-CVG-CFN-EFF-DT.

012696     PERFORM  7600-CDSI-EDITS
012696         THRU 7600-CDSI-EDITS-X.
012696
012696     IF  WS-CDSI-EDITS-FAILED
012696         SET WS-MESSAGE-NOT-DISPLAYED TO TRUE
012696         COMPUTE WS-LINES = RFC-CVG-CFN-REC-CTR + 1
012696         PERFORM  9515-SET-CDSI-ERR-ATTRIB-2-1
012696             THRU 9515-SET-CDSI-ERR-ATTRIB-2-1-X
012696             VARYING WS-LINES FROM 1 BY 1
012696             UNTIL WS-LINES > LSEGF-FND-CTR
012696         PERFORM  3100-DISPLAY-RECORD
012696             THRU 3100-DISPLAY-RECORD-X
012696         GO TO 5200-PROCESS-UPDATE-X
012696     END-IF.

           SET  LSEGF-INV-CVG-CFN-OPT-UPD-FILE TO TRUE.
           PERFORM  0500-1000-PROCESS-FC-FS
               THRU 0500-1000-PROCESS-FC-FS-X.

020452     IF  RPOL-POL-REG
020452         PERFORM  7320-EDIT-FC-REBAL-INSTR
020452             THRU 7320-EDIT-FC-REBAL-INSTR-X
020452         IF  WS-DATA-EDITS-OK
020452             CONTINUE
020452         ELSE
020452             PERFORM  3100-DISPLAY-RECORD
020452                 THRU 3100-DISPLAY-RECORD-X
020452             GO TO 5200-PROCESS-UPDATE-X
020452         END-IF
020452     END-IF.
      *
      *  EXIT WHEN FC/FS UPDATE ERRORS HAVE OCCURED
      *
           IF  L0500-RETRN-ERROR
               PERFORM  3100-DISPLAY-RECORD
                   THRU 3100-DISPLAY-RECORD-X
               GO TO 5200-PROCESS-UPDATE-X
014221     ELSE
014221*  REWRITE POLICY TO GET NEW TIMESTAMP
014221         PERFORM  POL-1000-READ-FOR-UPDATE
014221             THRU POL-1000-READ-FOR-UPDATE-X
014221         PERFORM  POL-2000-REWRITE
014221             THRU POL-2000-REWRITE-X
014221         PERFORM  POL-1000-READ-TWRK-TS
014221             THRU POL-1000-READ-TWRK-TS-X
           END-IF.

014468     PERFORM  7700-COUNT-LFUND-RECS
014468         THRU 7700-COUNT-LFUND-RECS-X.
014468
014468     IF  NOT L8200-RETRN-OK
014468         MOVE 'SS00600021'  TO WGLOB-MSG-REF-INFO
014468         PERFORM  0260-1000-GENERATE-MESSAGE
014468             THRU 0260-1000-GENERATE-MESSAGE-X
014468         PERFORM  3100-DISPLAY-RECORD
014468             THRU 3100-DISPLAY-RECORD-X
014468         GO TO 5200-PROCESS-UPDATE-X
014468     END-IF.
014468
014468     IF  LFUND-FND-CTR = LFUND-FND-MAX-CTR
014468         AND L8200-MORE-DATA-EXISTS
014468*MSG 'WARNING! MAXIMUM NUMBER OF FUNDS (139) EXCEEDED.'
014468         MOVE 'SS00600022'  TO WGLOB-MSG-REF-INFO
014468         PERFORM  0260-1000-GENERATE-MESSAGE
014468             THRU 0260-1000-GENERATE-MESSAGE-X
014468     END-IF.

      *
      *    MAINTENANCE COMPLETE (POP THE STACK IF REQUIRED IN FUTURE)
      *

           MOVE 'XS00000007'      TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.

           PERFORM  9111-BLANK-FC-FS
               THRU 9111-BLANK-FC-FS-X.

           PERFORM  9200-MOVE-RECORD-TO-SCREEN
               THRU 9200-MOVE-RECORD-TO-SCREEN-X.

       5200-PROCESS-UPDATE-X.
           EXIT.

      *****************************************************************
      *  BUILD FMAS KEY:  SET UP KEY TO BE USED IN SUBSEQUENT READ.
      *****************************************************************
       7100-BUILD-FMAS-KEY.

           MOVE MIR-POL-ID-BASE     TO LSEGF-INV-CVG-POL-ID-BASE.
           MOVE MIR-POL-ID-SFX      TO LSEGF-INV-CVG-POL-ID-SFX.
           MOVE MIR-CVG-NUM         TO LSEGF-INV-CVG-CVG-NUM.

       7100-BUILD-FMAS-KEY-X.
           EXIT.

      *****************************************************************
      *  FORMAT KEY INPUT: ALL DATE FIELDS MUST BE VALIDATED AS BEING
      *  IN THE CORRECT FORMAT OF DDMMMYYYY. ALL NUMERIC FIELDS MUST BE
      *  NUMERIC AND THE NUMBERS MUST BE RIGHT JUSTIFIED AND ZERO
      *  FILLED.
      *****************************************************************
       7200-FORMAT-KEY-INPUT.

           MOVE WS-OK             TO WS-DATA-EDITS.

           PERFORM  7510-EDIT-COVERAGE-NO
               THRU 7510-EDIT-COVERAGE-NO-X.

       7200-FORMAT-KEY-INPUT-X.
           EXIT.

      *****************************************************************
      *  EDIT DATA FIELDS ACCORDING TO THE DATA DICTIONARY
      *****************************************************************
       7300-DATA-EDITS.

           MOVE WS-OK             TO WS-DATA-EDITS.
012696
012696     MOVE ZERO              TO WS-FUND-COUNT.

012696*    PERFORM  7310-EDIT-ALLOC-OUT-IND
012696*        THRU 7310-EDIT-ALLOC-OUT-IND-X.

           PERFORM  7340-EDIT-FS-DATA
               THRU 7340-EDIT-FS-DATA-X
               VARYING I FROM 1 BY 1
               UNTIL I > WS-DISPLAY-LINES.

       7300-DATA-EDITS-X.
           EXIT.

      *****************************************************************
      *  ALLOCATION OUT IND: EDIT FOR VALID VALUES
      *****************************************************************
012696*7310-EDIT-ALLOC-OUT-IND.
012696*
012696*    MOVE LSEGF-INV-CVG-REC-INFO TO RFC-REC-INFO.
012696*
012696*    IF MIR-AOIND = SPACE
012696*        MOVE RFC-OUT-FND-ALLOC-CD TO MIR-AOIND
012696*    END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
012696*    IF MIR-AOIND = EBLCH-BLANK-FIELD-CHAR
012696*        MOVE 'D'            TO MIR-AOIND
012696*    END-IF.
      *
      *  EDIT ALLOCATION OUT INDICATOR TO SEE IF IT HAS CHANGED
      *
012696*    IF MIR-AOIND = 'A'
012696*    OR MIR-AOIND = 'P'
012696*    OR MIR-AOIND = 'D'
012696*        IF MIR-AOIND = RFC-OUT-FND-ALLOC-CD
012696*            NEXT SENTENCE
012696*        ELSE
012696*            MOVE MIR-AOIND  TO RFC-OUT-FND-ALLOC-CD
012696*            MOVE 'Y'        TO LSEGF-ALLOC-OUT-IND
012696*        END-IF
012696*    ELSE
012696*        MOVE 'SS00600001'   TO WGLOB-MSG-REF-INFO
012696*        PERFORM  0260-1000-GENERATE-MESSAGE
012696*            THRU 0260-1000-GENERATE-MESSAGE-X
012696*        MOVE WS-FAILED      TO WS-DATA-EDITS
012696*    END-IF.
012696*
012696*    MOVE RFC-REC-INFO       TO LSEGF-INV-CVG-REC-INFO.
012696*
012696*7310-EDIT-ALLOC-OUT-IND-X.
012696*    EXIT.

020452*---------------------------
020452 7320-EDIT-FC-REBAL-INSTR.
020452*---------------------------
020452
020452* LOOK FOR A REGION EXIT ON THE DATABASE WHICH IS 'FRNE' FOR THE
020452* SPECIFIC COUNTRY CODE.
020452
020452* ERROR MESSAGE WILL BE GENERATED IN THE REGIONAL EXIT PROGRAM
020452*
020452
020452     PERFORM  0316-1000-BUILD-PARM-INFO
020452         THRU 0316-1000-BUILD-PARM-INFO-X.
020452
020452     SET L0316-RGN-EXIT-FRGN-CNTNT-EDIT   TO TRUE.
020452     MOVE RPOL-POL-CTRY-CD                TO L0316-CTRY-CD.
020452
020452     PERFORM  0316-1000-GET-RGN-EXIT-PGM
020452         THRU 0316-1000-GET-RGN-EXIT-PGM-X.
020452
020452     IF  NOT L0316-RETRN-OK
020452         MOVE WS-FAILED           TO WS-DATA-EDITS
020452*MSG: NO FOREIGN CONTENT INSTRUCTION REGIONAL EXIT FOUND
020452*     FOR @1 COUNTRY CODE
020452         MOVE 'SS00600005'        TO WGLOB-MSG-REF-INFO
020452         MOVE RPOL-POL-CTRY-CD    TO WGLOB-MSG-PARM (1)
020452         PERFORM  0260-1000-GENERATE-MESSAGE
020452             THRU 0260-1000-GENERATE-MESSAGE-X
020452         GO TO 7320-EDIT-FC-REBAL-INSTR-X
020452     END-IF.
020452
020452     IF  L0316-RGN-EXIT-STAT-ACTV
020452         PERFORM  FRNE-1000-BUILD-PARM-INFO
020452             THRU FRNE-1000-BUILD-PARM-INFO-X
020452         MOVE RPOL-POL-ID                 TO LFRNE-POL-ID
020452         MOVE WGLOB-PROCESS-DATE          TO LFRNE-EFF-DT
020452         SET LFRNE-RQST-FC-EDIT           TO TRUE
020452         PERFORM  FRNE-1000-REGION-EXIT
020452             THRU FRNE-1000-REGION-EXIT-X
025970         IF  NOT LFRNE-RETRN-OK
025970             MOVE WS-FAILED               TO WS-DATA-EDITS
025970         END-IF
020452     END-IF.
020452
025970*    IF  NOT LFRNE-RETRN-OK
025970*        MOVE WS-FAILED        TO WS-DATA-EDITS
025970*    END-IF.
020452
020452 7320-EDIT-FC-REBAL-INSTR-X.
020452     EXIT.


      *****************************************************************
      *  EDIT FS DATA FIELDS WHEN THEY HAVE BEEN ENTERED
      *****************************************************************
       7340-EDIT-FS-DATA.

      *
      *  EXIT WHEN NO DATA HAS BEEN ENTERED FOR THIS LINE
      *
           IF  MIR-FND-ID-T (I)      = SPACES
           AND MIR-CFN-STAT-CD-T (I) = SPACES
012696*    AND MIR-IPCTI-T (I) = SPACES
012696*    AND MIR-PCTI-T (I) = SPACES
012696*    AND MIR-PCTO-T (I) = SPACES
               GO TO 7340-EDIT-FS-DATA-X
557660     END-IF.

012696     ADD +1                      TO WS-FUND-COUNT.
012696
012696     IF  WS-FUND-COUNT < I
012696         MOVE MIR-FND-ID-T (I)   TO MIR-FND-ID-T (WS-FUND-COUNT)
012696         MOVE MIR-CFN-STAT-CD-T (I) TO
012696                                 MIR-CFN-STAT-CD-T (WS-FUND-COUNT)
012696         MOVE SPACES             TO MIR-FND-ID-T (I)
012696         MOVE SPACES             TO MIR-CFN-STAT-CD-T (I)
012696         MOVE WS-FUND-COUNT      TO I
012696     END-IF.
012696
           MOVE LSEGF-CFN-REC-INFO (I) TO RFS-REC-INFO.
           MOVE RFC-POL-ID             TO RFS-POL-ID.
           MOVE RFC-CVG-NUM-N          TO RFS-CVG-NUM-N.
           MOVE I                      TO LSEGF-FND-CTR.
           MOVE I                      TO WS-EDIT-2-0.
           MOVE WS-EDIT-2-0            TO MIR-DV-FND-CTR-T (I).
           MOVE 'N'                    TO BLANK-OUT-FUND-SWITCH.

           PERFORM  7345-EDIT-FUND-CODE
               THRU 7345-EDIT-FUND-CODE-X.

           PERFORM  7350-EDIT-FUND-STATUS
               THRU 7350-EDIT-FUND-STATUS-X.

012696*    PERFORM  7355-EDIT-INIT-ALLOC
012696*        THRU 7355-EDIT-INIT-ALLOC-X.

012696*    PERFORM  7360-EDIT-ALLOC-IN
012696*        THRU 7360-EDIT-ALLOC-IN-X.

012696*    PERFORM  7365-EDIT-ALLOC-OUT
012696*        THRU 7365-EDIT-ALLOC-OUT-X.

           IF  BLANK-OUT-FUND-SWITCH = 'Y'
               PERFORM  7341-BLANK-OUT-FS-REC
                   THRU 7341-BLANK-OUT-FS-REC-X
557660     END-IF.

           MOVE RFS-REC-INFO           TO LSEGF-CFN-REC-INFO (I).

       7340-EDIT-FS-DATA-X.
           EXIT.

       7341-BLANK-OUT-FS-REC.

           MOVE SPACES                 TO RFS-REC-INFO.
           MOVE 0                      TO RFS-CVG-NUM-N.
017364*    MOVE +0                     TO RFS-CFN-VERS-CTR.
           MOVE WWKDT-ZERO-DT          TO RFS-CFN-STAT-CHNG-DT.
012696*    MOVE +0                     TO RFS-INIT-IN-ALLOC-PCT.
012696*    MOVE +0                     TO RFS-CFN-IN-ALLOC-PCT.
012696*    MOVE +0                     TO RFS-CFN-OUT-ALLOC-PCT.
           MOVE +0                     TO RFS-CDN-NRLZ-GAIN-AMT.
           MOVE +0                     TO RFS-FRGN-NRLZ-GAIN-AMT.
           MOVE ZEROS                  TO RFS-LATST-FIA-IDT-NUM.
           MOVE +0                     TO RFS-LATST-FIA-SEQ-NUM.
           MOVE +0                     TO RFS-CFN-ACB-AMT.

           MOVE SPACES                 TO MIR-FND-ID-T (I).
           MOVE SPACES                 TO MIR-CFN-STAT-CD-T (I).
012696*    MOVE SPACES                 TO MIR-IPCTI-T (I).
012696*    MOVE SPACES                 TO MIR-PCTI-T (I).
012696*    MOVE SPACES                 TO MIR-PCTO-T (I).

           MOVE I                      TO WS-LINES.

       7341-BLANK-OUT-FS-REC-X.
           EXIT.

      *****************************************************************
      *  FUND CODE: EDIT FOR VALID VALUES
      *****************************************************************
       7345-EDIT-FUND-CODE.

           IF  MIR-FND-ID-T (I) = SPACES
               MOVE RFS-FND-ID           TO MIR-FND-ID-T (I)
               GO TO 7345-EDIT-FUND-CODE-X
557660     END-IF.
      *
      *  EDIT FUND CODE, CHECK FOR DUPLICATES
      *
           PERFORM
               VARYING J FROM 1 BY 1
               UNTIL MIR-FND-ID-T (J) = MIR-FND-ID-T (I)
015543         CONTINUE
           END-PERFORM.
      *
      *  EQUAL INDEXES IMPLY THAT NO DUPLICATE WAS FOUND
      *
           IF  J = I
               MOVE MIR-FND-ID-T (I)     TO RFS-FND-ID
           ELSE
012696         IF  MIR-CFN-STAT-CD-T (J)   = 'D'
012696         OR  MIR-CFN-STAT-CD-T (I)   = 'D'
012696             MOVE MIR-FND-ID-T (I) TO RFS-FND-ID
012696         ELSE
                   MOVE MIR-FND-ID-T (I) TO WGLOB-MSG-PARM (1)
                   MOVE 'SS00600002'     TO WGLOB-MSG-REF-INFO
                   PERFORM  0260-1000-GENERATE-MESSAGE
                       THRU 0260-1000-GENERATE-MESSAGE-X
                   MOVE WS-FAILED        TO WS-DATA-EDITS
012696         END-IF
           END-IF.

       7345-EDIT-FUND-CODE-X.
           EXIT.

      *****************************************************************
      *  FUND STATUS: EDIT FOR VALID VALUES
      *****************************************************************
       7350-EDIT-FUND-STATUS.

           IF  MIR-CFN-STAT-CD-T (I) = SPACE
               MOVE RFS-CFN-STAT-CD   TO MIR-CFN-STAT-CD-T (I)
           END-IF.
      *
      *  SET UP FLAG TO AID PROCESSING IN SSLS0500
      *
           IF  I > RFC-CVG-CFN-REC-CTR
           AND MIR-CFN-STAT-CD-T (I) = 'D'
               MOVE 'Y'               TO BLANK-OUT-FUND-SWITCH
           END-IF.

           IF  I > RFC-CVG-CFN-REC-CTR
           AND MIR-CFN-STAT-CD-T (I) NOT = 'D'
               MOVE 'I'               TO MIR-CFN-STAT-CD-T (I)
               MOVE MIR-CFN-STAT-CD-T (I)   TO RFS-CFN-STAT-CD
               MOVE 'A'               TO LSEGF-CFN-STAT-IND (I)
               GO TO 7350-EDIT-FUND-STATUS-X
           ELSE
               IF  NOT (I > RFC-CVG-CFN-REC-CTR)
               AND MIR-CFN-STAT-CD-T (I) = 'D'
                   MOVE 'D'           TO LSEGF-CFN-STAT-IND (I)
               ELSE
                   MOVE 'U'           TO LSEGF-CFN-STAT-IND (I)
               END-IF
           END-IF.

      *
      *  EDIT FUND STATUS FOR VALID VALUES
      *  NOTE: 'D' INDICATES - DELETE THE FUND
      *        ALL OTHER STATUS ARE CONTROLLED IN SSSL0500
      *
           IF  MIR-CFN-STAT-CD-T (I) NOT = 'A'
           AND MIR-CFN-STAT-CD-T (I) NOT = 'C'
           AND MIR-CFN-STAT-CD-T (I) NOT = 'D'
           AND MIR-CFN-STAT-CD-T (I) NOT = 'I'
               MOVE RFS-CFN-STAT-CD   TO MIR-CFN-STAT-CD-T (I)
               MOVE 'SS00600003'      TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
557660     END-IF.

       7350-EDIT-FUND-STATUS-X.
           EXIT.

      *****************************************************************
      *  INITIAL ALLOCATION IN: EDIT FOR VALID NUMERIC
      *****************************************************************
012696*7355-EDIT-INIT-ALLOC.
      *
      *  DEFAULT FIELD TO ZEROES WHEN FS RECORD IS FIRST CREATED
      *
012696*    IF MIR-IPCTI-T (I) = SPACES
012696*        IF RFS-INIT-IN-ALLOC-PCT = 0
016537*MSG: INITIAL ALLOCATION IN DEFAULTED TO ZERO FOR FUND @1
012696*            MOVE 'SS00600004'     TO WGLOB-MSG-REF-INFO
012696*            MOVE MIR-FND-ID-T (I) TO WGLOB-MSG-PARM (1)
012696*            PERFORM  0260-1000-GENERATE-MESSAGE
012696*                THRU 0260-1000-GENERATE-MESSAGE-X
012696*        END-IF
012696*        MOVE RFS-INIT-IN-ALLOC-PCT TO WS-EDIT-3-4
012696*        MOVE WS-EDIT-3-4           TO MIR-IPCTI-T (I)
012696*        GO TO 7355-EDIT-INIT-ALLOC-X
012696*    END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
012696*    IF MIR-IPCTI-T (I) = EBLCH-BLANK-FIELD-CHAR
012696*        MOVE ZEROES           TO WS-EDIT-3-4
012696*        MOVE WS-EDIT-3-4      TO MIR-IPCTI-T (I)
012696*    END-IF.
      *
      *  EDIT INITIAL ALLOCATION IN, FOR VALID NUMERIC
      *
012696*    MOVE 'N'                  TO L0280-SIGN-IND.
012696*    MOVE '3'                  TO L0280-LENGTH.
012696*    MOVE '4'                  TO L0280-PRECISION.
012696*    MOVE MIR-IPCTI-T (I)      TO L0280-INPUT-DATA.
012696*    PERFORM  0280-1000-NUMERIC-EDIT
012696*        THRU 0280-1000-NUMERIC-EDIT-X.
012696*    IF L0280-OK
012696*        MOVE L0280-OUTPUT     TO WS-OUTPUT
012696*        MOVE WS-OUTPUT-4      TO WS-EDIT-3-4
012696*        MOVE WS-EDIT-3-4      TO MIR-IPCTI-T (I)
012696*        MOVE WS-OUTPUT-4      TO RFS-INIT-IN-ALLOC-PCT
012696*    ELSE
012696*        MOVE 'SS00600005'     TO WGLOB-MSG-REF-INFO
012696*        MOVE MIR-FND-ID-T (I) TO WGLOB-MSG-PARM (1)
012696*        PERFORM  0260-1000-GENERATE-MESSAGE
012696*            THRU 0260-1000-GENERATE-MESSAGE-X
012696*        MOVE WS-FAILED        TO WS-DATA-EDITS
012696*        GO TO 7355-EDIT-INIT-ALLOC-X
012696*    END-IF.
      *
      *  CANNOT ENTER A PERCENT > 100
      *
012696*    IF RFS-INIT-IN-ALLOC-PCT > 100.00
012696*        MOVE 'SS00600006'     TO WGLOB-MSG-REF-INFO
012696*        MOVE MIR-FND-ID-T (I) TO WGLOB-MSG-PARM (1)
012696*        PERFORM  0260-1000-GENERATE-MESSAGE
012696*            THRU 0260-1000-GENERATE-MESSAGE-X
012696*        MOVE WS-FAILED        TO WS-DATA-EDITS
012696*        GO TO 7355-EDIT-INIT-ALLOC-X
012696*    END-IF.

012696*7355-EDIT-INIT-ALLOC-X.
012696*    EXIT.
      *
      *****************************************************************
      *  ALLOCATION IN: EDIT FOR VALID NUMERIC
      *****************************************************************
012696*7360-EDIT-ALLOC-IN.
      *
      *  DEFAULT FIELD TO ZEROES WHEN FS RECORD IS FIRST CREATED
      *
012696*    IF MIR-PCTI-T (I) = SPACES
012696*        IF RFS-CFN-IN-ALLOC-PCT = 0
012696*            MOVE 'SS00600007'     TO WGLOB-MSG-REF-INFO
016537*MSG: ALLOCATION IN DEFAULTED TO ZERO FOR FUND @1
012696*            MOVE MIR-FND-ID-T (I) TO WGLOB-MSG-PARM (1)
012696*            PERFORM  0260-1000-GENERATE-MESSAGE
012696*                THRU 0260-1000-GENERATE-MESSAGE-X
012696*        END-IF
012696*        MOVE RFS-CFN-IN-ALLOC-PCT  TO WS-EDIT-3-4
012696*        MOVE WS-EDIT-3-4           TO MIR-PCTI-T (I)
012696*        GO TO 7360-EDIT-ALLOC-IN-X
012696*    END-IF.
      *
      *  RESET FIELD TO BLANK VALUE
      *
012696*    IF MIR-PCTI-T (I) = EBLCH-BLANK-FIELD-CHAR
012696*        MOVE ZEROES           TO WS-EDIT-3-4
012696*        MOVE WS-EDIT-3-4      TO MIR-PCTI-T (I)
012696*    END-IF.
      *
      *  EDIT ALLOCATION IN, FOR VALID NUMERIC
      *
012696*    MOVE 'N'                  TO L0280-SIGN-IND.
012696*    MOVE '3'                  TO L0280-LENGTH.
012696*    MOVE '4'                  TO L0280-PRECISION.
012696*    MOVE MIR-PCTI-T (I)       TO L0280-INPUT-DATA.
012696*    PERFORM  0280-1000-NUMERIC-EDIT
012696*        THRU 0280-1000-NUMERIC-EDIT-X.
012696*    IF L0280-OK
012696*        MOVE L0280-OUTPUT     TO WS-OUTPUT
012696*        MOVE WS-OUTPUT-4      TO WS-EDIT-3-4
012696*        MOVE WS-EDIT-3-4      TO MIR-PCTI-T (I)
012696*        IF WS-OUTPUT-4 = RFS-CFN-IN-ALLOC-PCT
012696*            NEXT SENTENCE
012696*        ELSE
012696*            MOVE WS-OUTPUT-4  TO RFS-CFN-IN-ALLOC-PCT
012696*            MOVE 'Y'          TO LSEGF-ALLOC-IN-IND
012696*        END-IF
012696*    ELSE
012696*        MOVE 'SS00600008'     TO WGLOB-MSG-REF-INFO
012696*        MOVE MIR-FND-ID-T (I)   TO WGLOB-MSG-PARM (1)
012696*        PERFORM  0260-1000-GENERATE-MESSAGE
012696*            THRU 0260-1000-GENERATE-MESSAGE-X
012696*        MOVE WS-FAILED        TO WS-DATA-EDITS
012696*        GO TO 7360-EDIT-ALLOC-IN-X
012696*    END-IF.
      *
      *  CANNOT ENTER A PERCENT > 100
      *
012696*    IF RFS-CFN-IN-ALLOC-PCT > 100.00
012696*        MOVE 'SS00600009'     TO WGLOB-MSG-REF-INFO
012696*        MOVE MIR-FND-ID-T (I)   TO WGLOB-MSG-PARM (1)
012696*        PERFORM  0260-1000-GENERATE-MESSAGE
012696*            THRU 0260-1000-GENERATE-MESSAGE-X
012696*        MOVE WS-FAILED        TO WS-DATA-EDITS
012696*        GO TO 7360-EDIT-ALLOC-IN-X
012696*    END-IF.

012696*7360-EDIT-ALLOC-IN-X.
012696*    EXIT.
      *
      *****************************************************************
      *  ALLOCATION OUT: EDIT FOR VALID NUMERIC
      *****************************************************************
012696*7365-EDIT-ALLOC-OUT.
      *
      *  DEFAULT FIELD TO ZEROES WHEN FS RECORD IS FIRST CREATED
      *
012696*    IF MIR-PCTO-T (I) = SPACES
012696*        IF RFS-CFN-OUT-ALLOC-PCT = 0
012696*            MOVE 'SS00600010'      TO WGLOB-MSG-REF-INFO
012696*            MOVE MIR-FND-ID-T (I)    TO WGLOB-MSG-PARM (1)
012696*            PERFORM  0260-1000-GENERATE-MESSAGE
012696*                THRU 0260-1000-GENERATE-MESSAGE-X
012696*        END-IF
012696*        MOVE RFS-CFN-OUT-ALLOC-PCT TO WS-EDIT-3-4
012696*        MOVE WS-EDIT-3-4           TO MIR-PCTO-T (I)
012696*        GO TO 7365-EDIT-ALLOC-OUT-X
012696*    END-IF.

      *
      *  RESET FIELD TO BLANK VALUE
      *
012696*    IF MIR-PCTO-T (I) = EBLCH-BLANK-FIELD-CHAR
012696*        MOVE ZEROES           TO WS-EDIT-3-4
012696*        MOVE WS-EDIT-3-4      TO MIR-PCTO-T (I)
012696*    END-IF.
      *
      *  EDIT INITIAL ALLOCATION IN, FOR VALID NUMERIC
      *
012696*    MOVE 'N'                  TO L0280-SIGN-IND.
012696*    MOVE '3'                  TO L0280-LENGTH.
012696*    MOVE '4'                  TO L0280-PRECISION.
012696*    MOVE MIR-PCTO-T (I)       TO L0280-INPUT-DATA.
012696*    PERFORM  0280-1000-NUMERIC-EDIT
012696*        THRU 0280-1000-NUMERIC-EDIT-X.
012696*    IF L0280-OK
012696*        MOVE L0280-OUTPUT     TO WS-OUTPUT
012696*        MOVE WS-OUTPUT-4      TO WS-EDIT-3-4
012696*        MOVE WS-EDIT-3-4      TO MIR-PCTO-T (I)
012696*        IF WS-OUTPUT-4 = RFS-CFN-OUT-ALLOC-PCT
012696*            NEXT SENTENCE
012696*        ELSE
012696*            MOVE WS-OUTPUT-4  TO RFS-CFN-OUT-ALLOC-PCT
012696*            MOVE 'Y'          TO LSEGF-ALLOC-OUT-IND
012696*        END-IF
012696*    ELSE
012696*        MOVE 'SS00600011'     TO WGLOB-MSG-REF-INFO
012696*        MOVE MIR-FND-ID-T (I)   TO WGLOB-MSG-PARM (1)
012696*        PERFORM  0260-1000-GENERATE-MESSAGE
012696*            THRU 0260-1000-GENERATE-MESSAGE-X
012696*        MOVE WS-FAILED        TO WS-DATA-EDITS
012696*        GO TO 7365-EDIT-ALLOC-OUT-X
012696*    END-IF.
      *
      *  CANNOT ENTER A PERCENT > 100
      *
012696*    IF RFS-CFN-OUT-ALLOC-PCT > 100.00
012696*        MOVE 'SS00600012'     TO WGLOB-MSG-REF-INFO
012696*        MOVE MIR-FND-ID-T (I)   TO WGLOB-MSG-PARM (1)
012696*        PERFORM  0260-1000-GENERATE-MESSAGE
012696*            THRU 0260-1000-GENERATE-MESSAGE-X
012696*        MOVE WS-FAILED        TO WS-DATA-EDITS
012696*        GO TO 7365-EDIT-ALLOC-OUT-X
012696*    END-IF.

012696*7365-EDIT-ALLOC-OUT-X.
012696*    EXIT.
      *
      *****************************************************************
      *  CROSS EDITS: WHEN APPLICABLE
      *****************************************************************
012696*7400-CROSS-EDITS.
012696*
012696*    MOVE WS-OK             TO WS-CROSS-EDITS.
012696*
012696*    PERFORM  7410-XEDIT-ALLOC-OUT
012696*        THRU 7410-XEDIT-ALLOC-OUT-X
012696*        VARYING I FROM 1 BY 1
012696*        UNTIL I > WS-DISPLAY-LINES.
012696*
012696*
012696*7400-CROSS-EDITS-X.
012696*    EXIT.
      *
012696*7410-XEDIT-ALLOC-OUT.
012696*
012696***EXIT WHEN NO DATA ENTERED FOR THIS LINE
012696*
012696*    IF MIR-PCTO-T (I) = SPACES
012696*        GO TO 7410-XEDIT-ALLOC-OUT-X
012696*    END-IF.
012696*
012696*    MOVE MIR-PCTO-T (I)       TO L0280-INPUT-DATA.
012696*    PERFORM  0280-1000-NUMERIC-EDIT
012696*        THRU 0280-1000-NUMERIC-EDIT-X.
012696*    IF L0280-OK
012696*        MOVE L0280-OUTPUT     TO WS-OUTPUT
012696*    ELSE
012696*        GO TO 7410-XEDIT-ALLOC-OUT-X
012696*    END-IF.
012696*
012696*    IF MIR-AOIND = 'P'
012696*        IF WS-OUTPUT-4 > ZERO
012696*            MOVE 'SS00600017'     TO WGLOB-MSG-REF-INFO
012696*            PERFORM  0260-1000-GENERATE-MESSAGE
012696*                THRU 0260-1000-GENERATE-MESSAGE-X
012696*            MOVE '000.0000'     TO MIR-PCTO-T (I)
012696*            MOVE WS-FAILED        TO WS-CROSS-EDITS
012696*            MOVE 'N'              TO LSEGF-ALLOC-OUT-IND
012696*        END-IF
012696*    END-IF.
012696*
012696*7410-XEDIT-ALLOC-OUT-X.
012696*    EXIT.

      *****************************************************************
      *  EDIT COVERAGE NO: FOR VALID NUMERICS
      *****************************************************************
       7510-EDIT-COVERAGE-NO.

      *
      *  EDIT COVERAGE NUMBER FOR NUMERICS
      *
           MOVE 'N'               TO L0280-SIGN-IND.
           MOVE '2'               TO L0280-LENGTH.
           MOVE '0'               TO L0280-PRECISION.
           MOVE MIR-CVG-NUM       TO L0280-INPUT-DATA.
           PERFORM  0280-1000-NUMERIC-EDIT
               THRU 0280-1000-NUMERIC-EDIT-X.
           IF  L0280-OK
           AND L0280-OUTPUT > ZEROES
007766*    AND L0280-OUTPUT < 21
007766     AND L0280-OUTPUT NOT > WCVGM-MAX-WCVGS-NUM
               MOVE L0280-OUTPUT  TO WS-EDIT-2-0
020874*        MOVE WS-EDIT-2-0   TO MIR-CVG-NUM
020874         MOVE L0280-OUTPUT          TO L0290-INPUT-V00
020874         MOVE ZERO                  TO L0290-PRECISION
020874         MOVE LENGTH OF MIR-CVG-NUM
020874                                    TO L0290-MAX-OUT-LEN
020874         PERFORM 0290-2000-FORMAT-FOR-MIR
020874            THRU 0290-2000-FORMAT-FOR-MIR-X
020874         MOVE L0290-OUTPUT-DATA     TO MIR-CVG-NUM
               MOVE L0280-OUTPUT  TO WS-CVG
           ELSE
               MOVE 'XS00000079'  TO WGLOB-MSG-REF-INFO
007766         MOVE MIR-CVG-NUM   TO  WGLOB-MSG-PARM (1)
007766         MOVE WCVGM-MAX-WCVGS-NUM  TO  WGLOB-MSG-PARM (2)
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               MOVE WS-FAILED     TO WS-DATA-EDITS
557660     END-IF.

       7510-EDIT-COVERAGE-NO-X.
           EXIT.

012696 7600-CDSI-EDITS.
012696
012696     SET WS-CDSI-EDITS-OK       TO TRUE.
012696     SET WS-CDSI-NO-EDIT-NEEDED TO TRUE.
012696
012696     PERFORM
012696         VARYING WS-IX1 FROM 1 BY 1
012696         UNTIL WS-IX1 > LSEGF-FND-CTR
012696         OR WS-CDSI-EDIT-NEEDED
012696         IF  LSEGF-CFN-STAT-IND (WS-IX1) = 'D'
012696             SET WS-CDSI-EDIT-NEEDED TO TRUE
012696         END-IF
012696     END-PERFORM.
012696
012696     IF  WS-CDSI-NO-EDIT-NEEDED
012696         GO TO 7600-CDSI-EDITS-X
012696     END-IF.
012696
012696     PERFORM  7610-LOAD-CDSI-TABLE
012696         THRU 7610-LOAD-CDSI-TABLE-X
012696
012696* IN THOSE CASES WHERE FMAS IS TRYING TO DELETE A FUND,
012696* COMPARE THE FUND IN LSEGF WITH THE FUND LOADED FROM THE
012696* CDSI FILE.  IF THEY MATCH THEN WE HAVE AN ERROR
012696
012696     PERFORM
012696         VARYING WS-IX1 FROM 1 BY 1
012696         UNTIL WS-IX1 > LSEGF-FND-CTR
012696         IF  LSEGF-CFN-STAT-IND (WS-IX1) = 'D'
012696             PERFORM
012696                 VARYING WS-IX3 FROM 1 BY 1
012696                 UNTIL WS-IX3 > WFNDM-MAX-POL-FUND-NUM
012696                 OR WS-CDSI-FUND-ID(WS-IX3) = SPACES
012696
012696                 IF  WS-CDSI-FUND-ID(WS-IX3) =
012696                                     LSEGF-CFN-FND-ID(WS-IX1)
012696                     SET WS-CDSI-EDITS-FAILED        TO TRUE
012696                     SET WS-FMAS-FUND-ERROR (WS-IX1) TO TRUE
012696                 END-IF
012696             END-PERFORM
012696         END-IF
012696     END-PERFORM.
012696
012696 7600-CDSI-EDITS-X.
012696     EXIT.
012696
012696*---------------------
012696 7610-LOAD-CDSI-TABLE.
012696*---------------------
012696
012696     MOVE SPACES TO WS-CDSI-FUND-TABLE.
012696     MOVE SPACES TO WS-FMAS-FUND-TABLE.
012696
012696     PERFORM  7620-SETUP-CAIN-BROWSE
012696         THRU 7620-SETUP-CAIN-BROWSE-X.
012696
012696     PERFORM
012696         VARYING WS-IX1 FROM 1 BY 1
012696         UNTIL WCAIN-IO-EOF
012696         OR WS-IX1 > WFNDM-MAX-POL-FUND-NUM
012696
012696         PERFORM  7630-READ-CDSI
012696             THRU 7630-READ-CDSI-X
012696
012696         PERFORM  CAIN-2000-READ-NEXT
012696             THRU CAIN-2000-READ-NEXT-X
012696
012696     END-PERFORM.
012696
012696     PERFORM  CAIN-3000-END-BROWSE
012696         THRU CAIN-3000-END-BROWSE-X.
012696
012696 7610-LOAD-CDSI-TABLE-X.
012696     EXIT.
012696
012696*-----------------------
012696 7620-SETUP-CAIN-BROWSE.
012696*-----------------------
012696
012696     MOVE LOW-VALUES              TO WCAIN-KEY.
012696     MOVE HIGH-VALUES             TO WCAIN-ENDBR-KEY.
012696     MOVE RPOL-POL-ID             TO WCAIN-POL-ID.
012696     MOVE RPOL-POL-ID             TO WCAIN-ENDBR-POL-ID.
012696     MOVE ZEROES                  TO WCAIN-POL-PAYO-NUM.
023112     MOVE +001                    TO WCAIN-CDI-SEQ-NUM.
012696     MOVE +99999                  TO WCAIN-ENDBR-POL-PAYO-NUM.
023112     MOVE +999                    TO WCAIN-ENDBR-CDI-SEQ-NUM.
012696
012696     PERFORM  CAIN-1000-BROWSE
012696         THRU CAIN-1000-BROWSE-X.
012696
012696     PERFORM  CAIN-2000-READ-NEXT
012696         THRU CAIN-2000-READ-NEXT-X.
012696
012696     IF  NOT WCAIN-IO-OK
012696         IF  WCAIN-IO-EOF
012696             CONTINUE
012696         ELSE
012696*MSG 'A PROBLEM HAS OCCURRED READING CAIN RECORDS'
012696             MOVE 'SS00600018'    TO WGLOB-MSG-REF-INFO
012696             MOVE WCAIN-IO-STATUS TO WGLOB-MSG-PARM (1)
012696             PERFORM  0260-1000-GENERATE-MESSAGE
012696                 THRU 0260-1000-GENERATE-MESSAGE-X
012696             PERFORM  CAIN-3000-END-BROWSE
012696                 THRU CAIN-3000-END-BROWSE-X
012696         END-IF
012696     END-IF.
012696
012696 7620-SETUP-CAIN-BROWSE-X.
012696     EXIT.
012696
012696 7630-READ-CDSI.
012696
012696     PERFORM  7640-SETUP-CDSI-BROWSE
012696         THRU 7640-SETUP-CDSI-BROWSE-X.
012696
012696     PERFORM  CDSI-1000-BROWSE
012696         THRU CDSI-1000-BROWSE-X.
012696
012696      PERFORM  CDSI-2000-READ-NEXT
012696          THRU CDSI-2000-READ-NEXT-X.
012696
012696     IF  NOT WCDSI-IO-OK
012696         IF  WCDSI-IO-EOF
012696             CONTINUE
012696         ELSE
012696*MSG 'A PROBLEM HAS OCCURRED READING CDSI RECORDS'
012696             MOVE 'SS00600019'    TO WGLOB-MSG-REF-INFO
012696             MOVE WCDSI-IO-STATUS TO WGLOB-MSG-PARM (1)
012696             PERFORM  0260-1000-GENERATE-MESSAGE
012696                 THRU 0260-1000-GENERATE-MESSAGE-X
012696             PERFORM  CDSI-3000-END-BROWSE
012696                 THRU CDSI-3000-END-BROWSE-X
012696             GO TO 7630-READ-CDSI-X
012696         END-IF
012696     END-IF.
012696     INITIALIZE WS-IX3.
012696     PERFORM
012696         UNTIL WCDSI-IO-EOF
012696         OR WS-IX3 > WFNDM-MAX-POL-FUND-NUM
012696
012696         IF  RCDSI-CDI-ALLOC-CD = 'P'
012696             IF  RCDSI-CDI-ALLOC-PCT NOT = ZERO
012696                 PERFORM  7650-SAVE-THIS-CDSI-FND-ID
012696                     THRU 7650-SAVE-THIS-CDSI-FND-ID-X
012696             END-IF
012696         END-IF
012696
012696         PERFORM  CDSI-2000-READ-NEXT
012696             THRU CDSI-2000-READ-NEXT-X
012696
012696     END-PERFORM.
012696
012696     PERFORM  CDSI-3000-END-BROWSE
012696         THRU CDSI-3000-END-BROWSE-X.
012696
012696 7630-READ-CDSI-X.
012696     EXIT.
012696
012696*-----------------------
012696 7640-SETUP-CDSI-BROWSE.
012696*-----------------------
012696
012696     MOVE LOW-VALUES               TO WCDSI-KEY.
012696     MOVE WCAIN-POL-ID             TO WCDSI-POL-ID.
012696     MOVE WCAIN-CDI-TYP-CD         TO WCDSI-CDI-TYP-CD.
012696     MOVE ZERO                     TO WCDSI-POL-PAYO-NUM.
012696     MOVE WCAIN-CDI-EFF-IDT-NUM    TO WCDSI-CDI-EFF-IDT-NUM.
023112     MOVE WCAIN-CDI-SEQ-NUM        TO WCDSI-CDI-SEQ-NUM.
012696     MOVE +001                     TO WCDSI-CDI-ALLOC-NUM.
012696     MOVE WCDSI-KEY                TO WCDSI-ENDBR-KEY.
012696     MOVE +999                     TO WCDSI-ENDBR-CDI-ALLOC-NUM.
012696
012696 7640-SETUP-CDSI-BROWSE-X.
012696     EXIT.
012696
012696 7650-SAVE-THIS-CDSI-FND-ID.
012696
012696      SET WS-CDSI-RECORD-NOT-SAVED   TO TRUE.
012696
012696     PERFORM
012696         VARYING WS-IX3 FROM 1 BY 1
012696         UNTIL WS-IX3 > WFNDM-MAX-POL-FUND-NUM
012696         OR WS-CDSI-RECORD-SAVED
012696
012696         IF  WS-CDSI-FUND-ID(WS-IX3) = SPACES
012696             MOVE RCDSI-DEST-FND-ID TO WS-CDSI-FUND-ID(WS-IX3)
012696             SET WS-CDSI-RECORD-SAVED TO TRUE
012696         ELSE
012696             IF  WS-CDSI-FUND-ID(WS-IX3) = RCDSI-DEST-FND-ID
012696                 MOVE RCDSI-DEST-FND-ID TO WS-CDSI-FUND-ID(WS-IX3)
012696                 SET WS-CDSI-RECORD-SAVED TO TRUE
012696             END-IF
012696         END-IF
012696     END-PERFORM.
012696
012696     IF  WS-IX3 > WFNDM-MAX-POL-FUND-NUM
012696*MSG 'A PROBLEM HAS OCCURRED READING CDSI RECORDS'
012696         MOVE 'SS00600019'    TO WGLOB-MSG-REF-INFO
012696         MOVE WCDSI-IO-STATUS TO WGLOB-MSG-PARM (1)
012696         PERFORM  0260-1000-GENERATE-MESSAGE
012696             THRU 0260-1000-GENERATE-MESSAGE-X
012696         GO TO 7650-SAVE-THIS-CDSI-FND-ID-X
012696     END-IF.
012696
012696 7650-SAVE-THIS-CDSI-FND-ID-X.
012696     EXIT.
014468
014468*----------------------
014468 7700-COUNT-LFUND-RECS.
014468*----------------------
014468
014468     PERFORM  8200-1000-BUILD-PARM-INFO
014468         THRU 8200-1000-BUILD-PARM-INFO-X.
014468
014468     INITIALIZE LFUND-FND-CTR.
014468     MOVE SPACES                  TO L8200-CDI-TYP-CD.
017310     MOVE RFC-CVG-NUM             TO L8200-CVG-NUM.

014468
014468     PERFORM  8200-1000-INIT-INSTR
014468         THRU 8200-1000-INIT-INSTR-X.
014468
014468 7700-COUNT-LFUND-RECS-X.
014468     EXIT.

      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES
      *****************************************************************
       9100-BLANK-DATA-FIELDS.

      *
      *    BLANK OUT DATA ON GIVEN SCREEN
      *
           PERFORM  9110-BLANK-DATA-FIELDS-1
               THRU 9110-BLANK-DATA-FIELDS-1-X.

       9100-BLANK-DATA-FIELDS-X.
           EXIT.

      *****************************************************************
      *  SET EACH NON-KEY FIELD TO SPACES ON SCREEN 1
      *****************************************************************
       9110-BLANK-DATA-FIELDS-1.

015904*    MOVE SPACES            TO MIR-INV-CVG-STAT-CD.
015904     MOVE SPACES            TO MIR-DV-INV-CVG-STAT-CD.
           MOVE SPACES            TO MIR-POL-CSTAT-CD.
016440     MOVE SPACES            TO MIR-PLAN-ID.
           MOVE SPACES            TO MIR-CVG-CSTAT-CD.

           PERFORM  9111-BLANK-FC-FS
               THRU 9111-BLANK-FC-FS-X.

       9110-BLANK-DATA-FIELDS-1-X.
           EXIT.

      *****************************************************************
      *  SET FC AND FS FIELDS TO SPACES ON SCREEN 1
      *****************************************************************
       9111-BLANK-FC-FS.

012696*    MOVE SPACES            TO MIR-AOIND.
           MOVE SPACES            TO MIR-DV-FND-CTR-G.
           MOVE SPACES            TO MIR-FND-ID-G.
           MOVE SPACES            TO MIR-CFN-STAT-CD-G.
012696*    MOVE SPACES            TO MIR-IPCTI-TABLE.
012696*    MOVE SPACES            TO MIR-PCTI-TABLE.
012696*    MOVE SPACES            TO MIR-PCTO-TABLE.

       9111-BLANK-FC-FS-X.
           EXIT.

       9112-FORMAT-FUND-NO.

           MOVE I                 TO WS-EDIT-2-0.
           MOVE WS-EDIT-2-0       TO MIR-DV-FND-CTR-T (I).

       9112-FORMAT-FUND-NO-X.
           EXIT.

      *****************************************************************
      *  MOVE FILE VALUES TO THE SCREEN
      *****************************************************************
       9200-MOVE-RECORD-TO-SCREEN.

           PERFORM  5400-1000-BUILD-PARM-INFO
               THRU 5400-1000-BUILD-PARM-INFO-X.
           SET  L5400-STAT-MSG-NOT-REQD      TO TRUE.
012624*    SET  L5400-CTL-MSG-NOT-REQD       TO TRUE.
019444     SET  L5400-CRCY-MSG-NOT-REQD      TO TRUE.
016440     SET  L5400-POL-XFER-UPDATE        TO TRUE.
           PERFORM  5400-1000-POL-CHK
               THRU 5400-1000-POL-CHK-X.
           IF  L5400-CNFD-ACCS-RESTRICTED
019444*    OR  L5400-CRCY-ACCS-RESTRICTED
           OR  L5400-BRCH-ACCS-RESTRICTED
016440     OR  L5400-XFER-ACCS-RESTRICTED
               PERFORM  9100-BLANK-DATA-FIELDS
                   THRU 9100-BLANK-DATA-FIELDS-X
               GO TO 9200-MOVE-RECORD-TO-SCREEN-X
           END-IF.

           PERFORM  9210-MOVE-RECORD-TO-SCREEN-1
               THRU 9210-MOVE-RECORD-TO-SCREEN-1-X.

       9200-MOVE-RECORD-TO-SCREEN-X.
           EXIT.

      *****************************************************************
      *  MOVE FILE VALUES TO SCREEN 1
      *****************************************************************
       9210-MOVE-RECORD-TO-SCREEN-1.

      *
      *  DISPLAY POLICY/COVERAGE STATUS INFORMATION
      *
           MOVE  RPOL-POL-CSTAT-CD  TO  MIR-POL-CSTAT-CD.
016440     MOVE  WCVGS-PLAN-ID (WS-CVG-NUM)  TO  MIR-PLAN-ID.
017685*    MOVE  RCVG-CVG-CSTAT-CD  TO  MIR-CVG-CSTAT-CD.
017685     MOVE  WCVGS-CVG-CSTAT-CD (WS-CVG-NUM)  TO  MIR-CVG-CSTAT-CD.
      *
      *  DISPLAY THE FC INFORMATION
      *
           MOVE LSEGF-INV-CVG-REC-INFO TO RFC-REC-INFO.
012696*    MOVE RFC-OUT-FND-ALLOC-CD  TO MIR-AOIND.
015904*    MOVE RFC-INV-CVG-STAT-CD   TO MIR-INV-CVG-STAT-CD.
015904     MOVE RFC-INV-CVG-STAT-CD   TO MIR-DV-INV-CVG-STAT-CD.
      *
      *  DISPLAY THE FS INFORMATION
      *
           PERFORM  9211-MOVE-FS-TO-SCREEN
               THRU 9211-MOVE-FS-TO-SCREEN-X
               VARYING WS-LINES FROM 1 BY 1
               UNTIL WS-LINES > LSEGF-FND-CTR.

       9210-MOVE-RECORD-TO-SCREEN-1-X.
           EXIT.

      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *  TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
       9211-MOVE-FS-TO-SCREEN.

           MOVE LSEGF-CFN-REC-INFO (WS-LINES) TO RFS-REC-INFO.

           MOVE WS-LINES               TO WS-EDIT-2-0.
           MOVE WS-EDIT-2-0            TO MIR-DV-FND-CTR-T (WS-LINES).
           MOVE RFS-FND-ID             TO MIR-FND-ID-T (WS-LINES).
           MOVE RFS-CFN-STAT-CD        TO MIR-CFN-STAT-CD-T (WS-LINES).
012696*    MOVE RFS-INIT-IN-ALLOC-PCT  TO WS-EDIT-3-4.
012696*    MOVE WS-EDIT-3-4            TO MIR-IPCTI-T (WS-LINES).
012696*    MOVE RFS-CFN-IN-ALLOC-PCT   TO WS-EDIT-3-4.
012696*    MOVE WS-EDIT-3-4            TO MIR-PCTI-T (WS-LINES).
012696*    MOVE RFS-CFN-OUT-ALLOC-PCT  TO WS-EDIT-3-4.
012696*    MOVE WS-EDIT-3-4            TO MIR-PCTO-T (WS-LINES).

       9211-MOVE-FS-TO-SCREEN-X.
           EXIT.

      *****************************************************************
      *  MOVE INFORMATION IDENTIFYING THE OBJECT BEING WORKED ON
      *  TO THE GLOBAL AREA FOR MSIN AND MSAU PROCESSING
      *****************************************************************
       9300-SETUP-MSIN-REFERENCE.

           MOVE SPACES               TO WGLOB-MSIN-REFERENCE.
           MOVE WGLOB-COMPANY-CODE   TO WGLOB-REF-COMPANY-CODE.
           MOVE 'P'                  TO WGLOB-REF-POLICY-OR-CLIENT.
           MOVE MIR-POL-ID-BASE      TO WGLOB-REF-POLICY-NUMBER.
           MOVE MIR-POL-ID-SFX       TO WGLOB-REF-POLICY-SUFFIX.
           MOVE MIR-CVG-NUM          TO WGLOB-REF-COVERAGE-NUMBER.

       9300-SETUP-MSIN-REFERENCE-X.
           EXIT.

012696*****************************************************************
012696*  LOOP THROUGH EACH LINE ON THE SCREEN AND SET ATTRIBUTES
012696*****************************************************************
012696 9515-SET-CDSI-ERR-ATTRIB-2-1.
012696
012696*
012696*  ATTRIBUTES ARE DIFFERENT FOR NON-EXISTENT/EXISTENT FUND
012696*
012696     IF  MIR-FND-ID-T (WS-LINES) = SPACES
012696         GO TO 9515-SET-CDSI-ERR-ATTRIB-2-1-X
012696     END-IF.
012696
012696     IF WS-FMAS-FUND-ERROR (WS-LINES)
012696*MSG 'ALLOCATION INSTRUCTIONS EXIST, CANNOT DELETE FUND.
012696         MOVE 'SS00600020'       TO WGLOB-MSG-REF-INFO
012696         IF  WS-MESSAGE-NOT-DISPLAYED
012696             SET WS-MESSAGE-DISPLAYED TO TRUE
012696             PERFORM  0260-1000-GENERATE-MESSAGE
012696                 THRU 0260-1000-GENERATE-MESSAGE-X
012696         END-IF
012696     END-IF.
012696
012696 9515-SET-CDSI-ERR-ATTRIB-2-1-X.
012696     EXIT.

021311*--------------------------
021311 9990-INIT-WORKING-STORAGE.
021311*--------------------------

026766     PERFORM  TIMR-0000-INIT-PARM-INFO
026766         THRU TIMR-0000-INIT-PARM-INFO-X.
021311
025970     PERFORM  0280-0000-INIT-PARM-INFO
025970         THRU 0280-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0290-0000-INIT-PARM-INFO
025970         THRU 0290-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0316-0000-INIT-PARM-INFO
025970         THRU 0316-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0500-0000-INIT-PARM-INFO
025970         THRU 0500-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2626-0000-INIT-PARM-INFO
025970         THRU 2626-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  2735-0000-INIT-PARM-INFO
025970         THRU 2735-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  5400-0000-INIT-PARM-INFO
025970         THRU 5400-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8090-0000-INIT-PARM-INFO
025970         THRU 8090-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  8200-0000-INIT-PARM-INFO
025970         THRU 8200-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  FRNE-0000-INIT-PARM-INFO
025970         THRU FRNE-0000-INIT-PARM-INFO-X.
025970
025970     INITIALIZE WLOCK-TWRK-TIMESTAMP-INFO.
025970     INITIALIZE WLOCK-TWRK-OTHER-INFO.
025970     INITIALIZE WS-PGM-WORK-AREA.
025970     INITIALIZE WS-EDIT-FIELDS.
025970     INITIALIZE WS-OUTPUT-FIELDS.
025970     INITIALIZE WS-CDSI-FIELDS.
021311     INITIALIZE LSEGF-PARM-INFO.

025970     SET WS-TWRK-KEY-DEFAULT   TO TRUE.
025970     SET WS-OK-DEFAULT         TO TRUE.
025970     SET WS-FAILED-DEFAULT     TO TRUE.
025970     MOVE SPACES               TO WWKDT-WORK-FIELDS.
021311     MOVE WFNDM-MAX-WFUND-NUM  TO WS-DISPLAY-LINES.

025970     MOVE MIR-BUS-FCN-ID       TO WS-BUS-FCN-ID.
021311
021311 9990-INIT-WORKING-STORAGE-X.
021311     EXIT.
021311
      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************
026766 COPY XCPSTIMR.
026766 COPY XCCPTIMR.

020478 COPY CCPPFPCK.
       COPY NCPPCVGS.
      *
025970 COPY XCPS8090.
       COPY CCPSPGA.
      *
       COPY XCPPEXIT.
      *
020478 COPY CCPS2626.
020478 COPY CCPL2626.
025970 COPY XCPS0280.
       COPY XCPL0280.
      *
       COPY XCPPINIT.
      *
014660*COPY XCPPMEXT.
      *
014221 COPY CCPPTWTS REPLACING ==:VAR1:== BY POL
014221                         '$VAR2' BY 'POL'.
      *
020452 COPY CCPSFRNE.
020452 COPY CCPLFRNE.
      *
018764*COPY SCCL0500.
025970 COPY SCPS0500.
018764 COPY SCPL0500.
      *
020463 COPY CCPS2735.
020463 COPY CCPL2735.
      *
018764*COPY CCCL5400.
018764 COPY CCPL5400.
       COPY CCPS5400.
      *
014468 COPY FCPS8200.
018764*COPY FCCL8200.
018764 COPY FCPL8200.
014468*
021930*COPY XCPS8090.
018764*COPY XCCL8090.
018764 COPY XCPL8090.
      *
020452 COPY XCPS0316.
020452 COPY XCPL0316.
      *
      ****************************************************************
      * MESSAGE PROCESSING COPYBOOK                                  *
      ****************************************************************
018764*COPY XCCL0260.
018764 COPY XCPL0260.
020874 COPY XCPL0290.
020874 COPY XCPS0290.
      *****************************************************************
      *  FILE I/O PROCESS MODULES
      *****************************************************************
016537*COPY CCPNCDSI.
012696 COPY CCPBCDSI.
      *
012696*COPY CCPNCAIN.
012696 COPY CCPBCAIN.
      *
       COPY CCPNCVG.
      *
       COPY CCPNPOL.
014221 COPY CCPUPOL.
      *
020463 COPY CCPNPD.
020463*
026070*COPY XCCPABND.
026070 COPY XCCPERR.
557708*COPY XCCPHNDL.
       COPY XCCP0030.
      *****************************************************************
      **                 END OF PROGRAM SSOM0060                     **
      *****************************************************************


