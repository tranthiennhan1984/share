@rem Start INGENIUM region 
@echo Start INGENIUM region
@echo off
@set DEVANIM=
for %%A in (01 02 03 04 05 06 07 08 09 10) do start /min runqwrk.cmd %%A
@echo done!