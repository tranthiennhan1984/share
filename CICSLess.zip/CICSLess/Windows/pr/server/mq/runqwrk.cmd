@rem Start INGENIUM Queue Worker
@rem Input parameter: Instance

@echo off

set MQSERVER=INGCLIENT/TCP/159.249.172.194(2399)
set QENV=mq

set INSTANCE=01
if %1A == A goto ingenium_start
  set INSTANCE=%1

:ingenium_start

del %DEVDIR%\%QENV%\out\XSBUQWRK_%INSTANCE%.out
echo 'MQSERVER=' %MQSERVER%
set COBSW=+S5
set XSBCF=%DEVDIR%\%QENV%\I00QWRK
set XSOCF=%DEVDIR%\%QENV%\out\XSBUQWRK_%INSTANCE%.out

if %DEVANIM%A == +AA goto anim:
goto run

:anim 
mfnetx /debug:%DEVDIR%\binbatch\XSBUQWRK.gnt %DEVDB% %DEVUSER% %DEVPASS% %INSTANCE%
goto end

:run
run %DEVDIR%\binbatch\XSBUQWRK.gnt %DEVDB% %DEVUSER% %DEVPASS% %INSTANCE%

if %ERRORLEVEL% NEQ 1 goto run

:end
exit
