@rem Run INGENIUM Queue Worker

@echo off

set MQSERVER=INGCLIENT/TCP/159.249.172.194(2399)
set QENV=mq

del %DEVDIR%\%QENV%\out\XSBUQEND.out
echo 'MQSERVER=' %MQSERVER%
set COBSW=+S5

set XSBCF=%DEVDIR%\%QENV%\I00QWRK
set XSOCF=%DEVDIR%\%QENV%\out\XSBUQEND.out

if %DEVANIM%A == +AA goto anim:
goto run

:anim 
mfnetx /debug:%DEVDIR%\binbatch\XSBUQEND.gnt
goto end

:run
run %DEVDIR%\binbatch\XSBUQEND.gnt

:end

@echo INGENIUM shutdown completed