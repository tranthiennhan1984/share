@rem Run one instance of Queue Worker
del out\*.out
cmd /k runqwrk