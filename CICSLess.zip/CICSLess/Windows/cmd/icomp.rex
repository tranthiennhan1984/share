/********************************************************************/
/*                                                                  */
/*  ALL RIGHT, TITLE AND INTEREST IN AND TO THE SOFTWARE            */
/*  (THE "SOFTWARE") AND THE ACCOMPANYING DOCUMENTATION OR          */
/*  MATERIALS (THE "DOCUMENTATION"), INCLUDING ALL PROPRIETARY      */
/*  RIGHTS, THEREIN INCLUDING ALL PATENT RIGHTS, TRADE SECRETS,     */
/*  TRADEMARKS AND COPYRIGHTS, SHALL REMAIN THE EXCLUSIVE           */
/*  PROPERTY OF ELECTRONIC DATA SYSTEMS CORPORATION. NO             */
/*  INTEREST, LICENCE OR ANY RIGHT RESPECTING THE SOFTWARE          */
/*  AND THE DOCUMENTATION, OTHER THAN EXPRESSLY GRANTED IN          */
/*  THE SOFTWARE LICENCE AGREEMENT, IS GRANTED BY IMPLICATION       */
/*  OR OTHERWISE.                                                   */
/*                                                                  */
/*  �  2007 ELECTRONIC DATA SYSTEMS CORPORATION.                    */
/*                ALL RIGHTS RESERVED                               */
/********************************************************************/
/************************************************************************/
/* Name            ICOMP.REX                                            */
/*                                                                      */
/* Description     This rexx is used to perform a MicroFocus compile    */
/*                 on INGENIUM COBOL source programs.                   */
/*                                                                      */
/* Called by       ICOMP.CMD                                            */
/*                                                                      */
/* Usage           icomp <program name>.<ext>                           */
/*                 icomp         shows the syntax                       */
/*                 icomp ?       shows the syntax                       */
/*                                                                      */
/* Example         When submitting from a DOS prompt wild cards may     */
/*                 be used                                              */
/*                 icomp *.*                                            */
/*                 icomp *.cbl                                          */
/*                 icomp ?SOM*.*                                        */
/************************************************************************/
/* Environment Variables Required                                       */
/*                                                                      */
/*   DEVSRCE       This contains the INGENIUM SERVER Directory          */
/*                                                                      */
/*   DEVRGN        Description Only. Shows the current Region           */
/*                                                                      */
/*   DEVINST       This contains the DB2 instance/Node for the database */
/*                                                                      */
/*   DEVDB         This contains the current Database in use            */
/*                                                                      */
/*   DEVSCHEMA     This contains the table schema (qualifier)           */
/*                                                                      */
/*   DEVUSER       This contains the login userid for the Database      */
/*                                                                      */
/*   DEVPASS       This contains the login password for the Database    */
/*                                                                      */
/*   COBSRCE       This contains the appended path of the INGENIUM      */
/*                 Source Code                                          */
/*                                                                      */
/*   COBCPY        This contains the appended path of the INGENIUM      */
/*                 COPY books.                                          */
/*                                                                      */
/*   CICSCPY       This contains the appended path of the INGENIUM      */
/*                 CICS COPY books.                                     */
/*                                                                      */
/*   COBPATH       This contains the appended path of the INGENIUM      */
/*                 DYNAMIC CALL executables                             */
/*                                                                      */
/*   HCOBND        This contains the path to store DB2 .bnd files       */
/*                                                                      */
/*   PATH          Search Path for command and DYANMIC LINK executables */
/*                                                                      */
/*   INGENIUMDRV   Drive used for INGENIUM                              */
/*                                                                      */
/************************************************************************/
/* Files Required                                                       */
/*                                                                      */
/*   IngeniumDrv'\cmd\sqlprecomp.lst'                                   */
/*                                                                      */
/************************************************************************/
if arg(1) = '?' | arg(1) = '' then
  do i = 1 to 100
    if left(sourceline(i),2) = '/*' then
      say sourceline(i)
    else
      exit
  end

/*trace ?R*/
parse arg Infile .

if address() = 'CMD' then
  slash = '\'
else
  slash = '/'

DevDir      = value('DEVDIR',,'ENVIRONMENT')||slash
DevRgn      = value('DEVRGN',,'ENVIRONMENT')
DevDb       = value('DEVDB',,'ENVIRONMENT')
DevUser     = value('DEVUSER',,'ENVIRONMENT')
DevPass     = value('DEVPASS',,'ENVIRONMENT')
DevSchema   = value('DEVSCHEMA',,'ENVIRONMENT')
CobSrce     = value('COBSRCE',,'ENVIRONMENT')
CobCpy      = value('COBCPY',,'ENVIRONMENT')
CicsCpy     = value('CICSCPY',,'ENVIRONMENT')
IngeniumDrv = value('INGENIUMDRV',,'ENVIRONMENT')
CurrentDir  = directory()

DB2Options = 'UDB-VERSION=V9 DB='DevDb 'QUALIFIER='DevSchema 'BIND FORMAT=ISO NOGEN-INIT-FLAG'
CobolDirectiveFile = IngeniumDrv || slash'cmd'slash'cobol.dir'


/* Exception List file for Programs requiring DB2 Precompiles */
SQLEXCEPTION_LIST     = IngeniumDrv || slash'cmd'slash'sqlprecomp.lst'

/* Output Destinations for CICS Programs */
BINCICS = DevDir'bincics'slash
IDYCICS = DevDir'idycics'slash
LSTCICS = DevDir'lstcics'slash

/* Output Destinations for BATCH Programs */
BINBATCH   = DevDir'binbatch'slash
IDYBATCH   = DevDir'idybatch'slash
LSTBATCH   = DevDir'lstbatch'slash

/* Output Destinations for DBIO Programs */
BINDBIO    = DevDir'bindbio'slash
IDYDBIO    = DevDir'idydbio'slash
LSTDBIO    = DevDir'lstdbio'slash

/* Get the Exception list */

if stream(SQLEXCEPTION_LIST,'C','open read shared') \= 'READY:' then
do
  say '** Unable to open file' SQLEXCEPTION_LIST
  exit
end

sqlPrecomp. = 0
do while lines(SQLEXCEPTION_LIST) \= 0
  parse upper value linein(SQLEXCEPTION_LIST) with exfile .
  sqlPrecomp.exfile = 1
end
call stream SQLEXCEPTION_LIST,'c','close'

say "Currrent INGENIUM Configuration:"
say "Base Directory:      "DevDir
say "CICS Region:         "DevRgn
say "DB2 Database:        "DevDb
say "DB2 Schema:          "DevSchema
say "Infile:              "Infile

BaseFileName = filespec('name',Infile)
parse upper var BaseFileName BaseFileWithoutExt '.' FileExt

/*----------------------------------------------------------------------*/
/*  Search for Source to compile based on the CurrentDir||COBSRCE       */
/*    COBSRCE - specifies the search order,must be set in setenv XX     */
/*             where XX - pr,st,ut,lc                                   */
/*----------------------------------------------------------------------*/
FullFileName = Locate(Infile,CurrentDir';'CobSrce)
if FullFileName = '' then
do
  say '--!'
  say 'Could Not Locate the Program' Infile 'in'
  say 'COBSRCE='CobSrce
  say '--!'
  exit
end

say 'Compiling Program :' FullFileName
select
  when BaseFileWithoutExt = 'XSDU0035' then
  do  
    call CompileCOBOL BINDBIO,IDYDBIO,LSTDBIO,'CALL-RECOVERY"1" DATA-CONTEXT db2('DB2Options')' 
  end

  when substr(BaseFileWithoutExt,2,2) = 'SI' then
  do  
    call CompileCOBOL BINDBIO,IDYDBIO,LSTDBIO,'CALL-RECOVERY"1" DATA-CONTEXT db2('DB2Options')'
  end

  when substr(BaseFileWithoutExt,2,2) = 'SD' then
  do
    if sqlPrecomp.BaseFileWithoutExt then
    do
      call CompileCOBOL BINBATCH,IDYBATCH,LSTBATCH,'db2('DB2Options')'
/*      call CompileCICS BINCICS,IDYCICS,LSTCICS,'db2('DB2Options')' */
    end
    else
    do
      call CompileCOBOL BINBATCH,IDYBATCH,LSTBATCH
/*      call CompileCICS BINCICS,IDYCICS,LSTCICS */
    end
  end

  when substr(BaseFileWithoutExt,2,2) = 'SR' then
    call CompileCOBOL BINBATCH,IDYBATCH,LSTBATCH

  when substr(BaseFileWithoutExt,2,2) = 'SB' then
  do
    if sqlPrecomp.BaseFileWithoutExt then
      call CompileCOBOL BINBATCH,IDYBATCH,LSTBATCH,'db2('DB2Options')'
    else
      call CompileCOBOL BINBATCH,IDYBATCH,LSTBATCH
  end

  when substr(BaseFileWithoutExt,2,2) = 'SL' then
    call CompileCICS BINCICS,IDYCICS,LSTCICS

  when substr(BaseFileWithoutExt,2,3) = 'SOM' then
  do
    if sqlPrecomp.BaseFileWithoutExt then
/*      call CompileCICS BINCICS,IDYCICS,LSTCICS,'db2('DB2Options')' */
      call CompileCOBOL BINBATCH,IDYBATCH,LSTBATCH,'db2('DB2Options')'
    else
/*      call CompileCICS BINCICS,IDYCICS,LSTCICS */
      call CompileCOBOL BINBATCH,IDYBATCH,LSTBATCH
  end

  otherwise
    say 'Program' Infile 'is not a valid INGENIUM type'
end

exit

/*----------------------------------------------------------------------*/
/*Locates and Returns Program in the COBSRCE Variable                   */
/*----------------------------------------------------------------------*/
Locate:
parse arg mLocalName,mSearchPath

if right(mSearchPath,1) \= ';' then
  mSearchPath = mSearchPath || ';'


parse var mSearchPath mPath ';' rempath
mFileFound= 0

do while mPath \= ''
  mFile = mPath || slash || mLocalName
  call SysFileTree mFile,'search','FO'
  if search.0 > 0 then
  do
    mFileFound = 1
    mFile = search.1
    leave
  end
  parse var rempath mPath ';' rempath
end

if \mFileFound then
   mFile = ''

return mFile

/*----------------------------------------------------------------------*/
/* Compiles CICS Programs                                               */
/* Arguments    -> executable_location                                  */
/*              -> IDY_location                                         */
/*              -> listing_location                                     */
/*              -> comp_options (optional for DB2 precompiles)          */
/*                                                                      */
/* Note INT directive is used to redirect temporary .int file to a      */
/* folder with proper write permissions to prevent compile I-O error    */
/*----------------------------------------------------------------------*/
CompileCICS:
parse arg executable_location,idy_location,listing_location,comp_options

/* Change the COBCPY Environment Variable so that the cicscopy directory is first */
call value 'COBCPY',CICSCPY';'COBCPY,'ENVIRONMENT'

SavedDir = directory(executable_location)

RunCommand = 'cobol' FullFileName',,,,GNT"'executable_location'" INT"'executable_location'"',
                 'LISTPATH"'listing_location'" ANIM COBIDY"'idy_location'"',
             'NOASM USE"'CobolDirectiveFile'" CICSECM() CALL-RECOVERY"1" DATA-CONTEXT' comp_options';'
say RunCommand
RunCommand
call SysFileDelete executable_location || BaseFileWithoutExt'.int' 

/* Revert to original dir and COBCPY */
call directory SavedDir
call value 'COBCPY',COBCPY,'ENVIRONMENT'

return

/*----------------------------------------------------------------------*/
/* Compiles COBOL Programs                                              */
/* Arguments    -> executable_location                                  */
/*              -> IDY_location                                         */
/*              -> listing_location                                     */
/*              -> comp_options (optional for DB2 precompiles)          */
/*                                                                      */
/* Note INT directive is used to redirect temporary .int file to a      */
/* folder with proper write permissions to prevent compile I-O error    */
/*----------------------------------------------------------------------*/
CompileCOBOL:
parse arg executable_location,idy_location,listing_location,comp_options

SavedDir = directory(executable_location)

RunCommand = 'cobol' FullFileName',,,,GNT"'executable_location'" INT"'executable_location'"',
                 'LISTPATH"'listing_location'" ANIM COBIDY"'idy_location'"',
             'NOASM OUTDD"$SYSOUT" USE"'CobolDirectiveFile'"' comp_options';'
say RunCommand
RunCommand
call SysFileDelete executable_location || BaseFileWithoutExt'.int'

/* Revert to original dir */
call directory SavedDir

return

