@rem                                                              
@rem  ALL RIGHT, TITLE AND INTEREST IN AND TO THE SOFTWARE        
@rem  (THE "SOFTWARE") AND THE ACCOMPANYING DOCUMENTATION OR      
@rem  MATERIALS (THE "DOCUMENTATION"), INCLUDING ALL PROPRIETARY  
@rem  RIGHTS, THEREIN INCLUDING ALL PATENT RIGHTS, TRADE SECRETS, 
@rem  TRADEMARKS AND COPYRIGHTS, SHALL REMAIN THE EXCLUSIVE       
@rem  PROPERTY OF ELECTRONIC DATA SYSTEMS CORPORATION. NO         
@rem  INTEREST, LICENCE OR ANY RIGHT RESPECTING THE SOFTWARE      
@rem  AND THE DOCUMENTATION, OTHER THAN EXPRESSLY GRANTED IN      
@rem  THE SOFTWARE LICENCE AGREEMENT, IS GRANTED BY IMPLICATION   
@rem  OR OTHERWISE.                                               
@rem                                                              
@rem  �  2007 ELECTRONIC DATA SYSTEMS CORPORATION.                
@rem                ALL RIGHTS RESERVED                           
@rem
@echo off
Rem **********************************************************
Rem * Module Name   : imq.cmd                                *
Rem *                                                        *
Rem * Calls         : setenv.cmd XX                          *
Rem *                                                        *
Rem *                 where XX = LC ,UT, ST, PR              *
Rem *                                                        *
Rem * Restrictions  : None                                   *
Rem *                                                        *
Rem * Usage         : imq <level>                            *
Rem *               : Type imq to disaplay Syntax            *
Rem **********************************************************

Rem **********************************************************
Rem * Set the location of                                    *
Rem * %INGENIUMDRV% -    INGENIUM APPLICATION SERVER         *
Rem * %LOCALDRV%    -    LOCAL Working Directory             *
Rem **********************************************************

call GlobalVars.cmd

Rem **********************************************************
Rem * Determine the Level                                    *
Rem **********************************************************
:step1
if /i '%1' == 'LC' goto stepLC
if /i '%1' == 'LCST' goto steplc
if /i '%1' == 'LCPR' goto steplc
if /i '%1' == 'UT' goto step2
if /i '%1' == 'ST' goto step2
if /i '%1' == 'ST2' goto step2
if /i '%1' == 'STJ' goto step2
if /i '%1' == 'BT' goto step2
if /i '%1' == 'BT3' goto step2
if /i '%1' == 'PR' goto step2
goto echosyntax

Rem **********************************************************
Rem * Set the Level and Environment File for Local setups    *
Rem **********************************************************
:stepLC
set LEVEL=%1
call setenv %1 batch
%LOCALDRV%
cd %LOCALDRV%\WB\mq
title Ingenium Prompt for COBOL MQ - %LEVEL% - Env.
echo ----------------------------------------------------------
echo  Environment variables setup for - %LEVEL% - are in effect
echo ----------------------------------------------------------
goto exit_batch

Rem **********************************************************
Rem * Set the Level and Environment File                     *
Rem **********************************************************
:step2
set LEVEL=%1
call setenv %1 batch
%INGENIUMDRV%
cd %INGENIUMDRV%\%LEVEL%\server\mq
title Ingenium Prompt for COBOL MQ - %LEVEL% - Env.
echo ----------------------------------------------------------
echo  Environment variables setup for - %LEVEL% - are in effect
echo ----------------------------------------------------------
goto exit_batch

:echosyntax

echo "--------------------------------------------------------"
echo "    Valid Syntax is :                                   "
echo "           imq  <level>                                 "
echo "           Mandatory fields:                            "
echo "                <level>                                 "
echo "                   level =LC , UT, ST , PR              "
echo "--------------------------------------------------------"
:exit_batch
