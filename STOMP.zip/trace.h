/******************************************************************************
 * All right, title and interest in and to the software         
 * (the "Software") and the accompanying documentation or       
 * materials (the "Documentation"), including all proprietary   
 * rights, therein including all patent rights, trade secrets,  
 * trademarks and copyrights, shall remain the exclusive        
 * property of DXC Technology Company.            
 * No interest, license or any right respecting the Software       
 * and the Documentation, other than expressly granted in       
 * the Software License Agreement, is granted by implication    
 * or otherwise.                                                
 *                                                              
 * (C) Copyright 2006-2017 DXC Technology Company.
 * All rights reserved.                                         
 ******************************************************************************/

#ifndef __TRACE_H__

#define __TRACE_H__ 1

#include "platform.h"
#include "mutex.h"

/******************************************************************************
 * TRACE definitions
 *****************************************************************************/

/**
 * Name of the environment variable containing the file name where responses
 * will be written
 */
#define TRACE_RESPONSE_FILE_NAME_VARIABLE	"ConnectorResponseLogFile"

/**
 * Name of the environment variable containing the file name where responses
 * will be written
 */
#define TRACE_REQUEST_FILE_NAME_VARIABLE	"ConnectorRequestLogFile"

/**
 * Name of the variable that determines if tracing is turned on or not.  If
 * this variable is set to 1 then tracing is enabled.  0 turns off tracing.
 */
#define TRACE_ENABLE_VARIABLE		"ConnectorTrace"

/**
 * This struct contains information needed to log the operation of the 
 * socket calls.
 */
typedef struct
{
	char* responseLogFileName;
	char* requestLogFileName;
	BOOL tracingEnabled;
	MUTEX responseLogFileMutex;
	MUTEX requestLogFileMutex;
} TRACE;

/**
 * Initialize the tracing subsystem.
 */
BOOL initTrace();
void ntrace(_In_z_ _Printf_format_string_ char const* const _Format, ...);

#endif
