/******************************************************************************
 * All right, title and interest in and to the software
 * (the "Software") and the accompanying documentation or
 * materials (the "Documentation"), including all proprietary
 * rights, therein including all patent rights, trade secrets,
 * trademarks and copyrights, shall remain the exclusive
 * property of DXC Technology Company.
 * No interest, license or any right respecting the Software
 * and the Documentation, other than expressly granted in
 * the Software License Agreement, is granted by implication
 * or otherwise.
 *
 * (C) Copyright 2002-2017 DXC Technology Company.
 * All rights reserved.
 ******************************************************************************/

#include "STOMP.h"
#include "log.h"
#include "sockcalls.h"

static int INITIALIZED = false;

/*****************************************************************************
 * Entry point - CICS EXEC LINK starts here.
 * Dispacth a request based on the function specified in the
 * COMMAREA. All request parameters are sanity checked; bad values
 * generate status L0003_RETRN_INVALD_RQST.
 ****************************************************************************/

__declspec(dllexport) void __stdcall STOMP(STMH* handler, STMO* obj, BYTE* buffer, LENGTH* length) {
    errno_t* err = &(handler->err);
    if (handler == NULL) {
        *err = 1;
        nlog("Missing handler.\n");
        return;
    }

    if ((*err = assertInit()) != 0) {
        nlog("Initialize fail.\n");
        handler->status = STMR_ERR_SOCKET;
        return;
    }

    switch (handler->func) {

    case STMF_CONN:
        *err = getManager(&(handler->manager));
        handler->status = GetStatus(*err, STMR_ERR_CONNECT);
        break;

    case STMF_DISC:
        *err = 0;
        handler->status = GetStatus(*err, STMR_ERR_DISCONNECT);
        break;

    case STMF_OPEN:
        *err = openObj(&(handler->manager), &(handler->odesc), obj);
        handler->status = GetStatus(*err, STMR_ERR_OPEN);
        break;

    case STMF_CLOSE:
        *err = closeObj(&(handler->manager), obj);
        handler->status = GetStatus(*err, STMR_ERR_CLOSE);
        break;

    case STMF_PUT:
        *err = put(&(handler->manager), obj, &(handler->mdesc), buffer, *length);
        handler->status = GetStatus(*err, STMR_ERR_PUT);
        break;

    case STMF_GET:
        *err = get(&(handler->manager), obj, &(handler->gopt), &(handler->mdesc), buffer, length);
        handler->status = GetStatus(*err, STMR_ERR_GET);
        break;

    default:
        *err = 2;
        nlog("invalid request\n");
        handler->status = STMR_INVALD_RQST;
        break;
    }

    return;
}

static char* rtrim(char* s, LENGTH length) {
    char* back = s + length - 1;
    while (isspace(*--back));
    *(back + 1) = '\0';
    return s;
}
static STMS GetStatus(errno_t err, STMS defErrSts) {
    return err == 0 ? STMR_OK
        : err == STMR_ERR_TIMEOUT ? STMR_ERR_TIMEOUT : defErrSts;
}
static errno_t assertInit() {
    int err = 0;
    if (INITIALIZED) return 0;
    nlog("Initializing.\n");
    errno = 0;
    err = init();
    if (err == 0) INITIALIZED = true;
    return err;
}

static errno_t cleanBuff(char* buf, errno_t err) {
    free(buf);
    return err;
}

static errno_t getEnvText(const char* varName, char* value, size_t valueSize) {
    errno_t err;
    char* buffer;

    err = getEnvironmentVariable(&buffer, varName);
    if (err != 0 || buffer == NULL) {
        fprintf(stderr, "Connector: Unable to get the %s environment variable. errno: %d", varName, err);
        return err == 0 ? 1 : 0;
    }

    strncpy_s(value, valueSize, buffer, valueSize);

    free(buffer);

    return 0;
}
static errno_t getEnvVal(const char* varName, int* value) {
    errno_t err;
    char* buffer;

    err = getEnvironmentVariable(&buffer, varName);
    if (err != 0 || buffer == NULL) {
        fprintf(stderr, "Connector: Unable to get the %s environment variable. errno: %d", varName, err);
        return err == 0 ? 1 : 0;
    }

    *value = atoi(buffer);

    free(buffer);

    return 0;
}
static errno_t sendText(STMO* obj, char* txt, BOOL isEnd) {
    LENGTH length = strlen(txt);
    if (isEnd)++length;
    return writeData(obj, (BYTE*)txt, length);
}

static errno_t getManager(STMC* manager) {
    errno_t err;

    if (strlen(manager->hostname) == 0) {
        err = getEnvText(MQ_HOST_VARIABLE, manager->hostname, MAXHOSTNAME);
        if (err != 0) return 2;
    }

    if (manager->address == 0) {
        err = lookupIP(manager->hostname, &(manager->address));
        if (err != 0) return 3;
    }

    if (manager->port == 0) {
        err = getEnvVal(MQ_PORT_VARIABLE, &(manager->port));
        if (err != 0) return 4;
    }
    if (manager->timeOut == 0) {
        err = getEnvVal(MQ_TIMEOUT_VARIABLE, &(manager->timeOut));
        if (err != 0) manager->timeOut = 30;
    }

    if (strlen(manager->user) == 0) {
        err = getEnvText(MQ_USER_VARIABLE, manager->user, MAXNORMNAME);
        if (err != 0) return 5;
    }
    if (strlen(manager->pass) == 0) {
        err = getEnvText(MQ_PASS_VARIABLE, manager->pass, MAXNORMNAME);
        if (err != 0) return 6;
    }

    return 0;
}

static errno_t openObj(STMC* manager, STMOD* desc, STMO* obj) {
    errno_t err = 0;
    sprintf_s(obj->destination, MAXNORMNAME, "%s%s", desc->object_type == MQOT_QUEUE ? "/queue/" : "/topic/", rtrim(desc->object_name, MAXNORMNAME));
    nlog("destination: %s\n", obj->destination);
    if ((err = createSocket(manager, obj)) != 0) return err;
    if ((err = sendConnect(manager, obj)) != 0) return err;
    return err;
}
static errno_t sendConnect(STMC* manager, STMO* obj) {
    errno_t err = 0;
    STMMD* desc = malloc(sizeof(STMMD));
    char* buf = malloc(MAXHEADER);
    char* cmd = malloc(12);
    if (buf == 0) return 1;


    sprintf_s(buf, MAXHEADER, "\nCONNECT\nlogin:%s\npasscode:%s\nversion:1.0\n\n\0", manager->user, manager->pass);
    if ((err = sendText(obj, buf, true)) != 0) cleanBuff(buf, err);

    memset(buf, 0, MAXHEADER);
    if ((err = readEmptyMessage(manager, obj, 0, desc, cmd, buf)) != 0) return cleanBuff(buf, err);

    if (cmd == 0 || desc == 0 || strcmp(cmd, "CONNECTED") != 0)return cleanBuff(buf, 2);
    strcpy(obj->version, desc->version);

    return cleanBuff(buf, err);
}

static errno_t closeObj(STMC* manager, STMO* obj) {
    errno_t err = 0;
    if ((err = sendDisconnect(manager, obj)) != 0) return err;
    if ((err = closeSocket(obj)) != 0) return err;
    return err;
}
static errno_t sendDisconnect(STMC* manager, STMO* obj) {
    errno_t err = 0;
    if ((err = sendText(obj, "\nDISCONNECT\n\n\0", true)) != 0) return err;
    return err;
}

static errno_t put(STMC* manager, STMO* obj, STMMD* desc, BYTE* content, LENGTH length) {
    errno_t err = 0;
    char* buf = malloc(MAXHEADER);
    if (buf == 0) return 1;

    sprintf_s(buf, MAXHEADER, "\nSEND\ndestination:%s\n", rtrim(obj->destination, MAXNORMNAME));
    if ((err = sendText(obj, buf, false)) != 0) return cleanBuff(buf, err);

    if (strlen(rtrim(desc->correlation_id, MAXNORMNAME)) != 0) {
        sprintf_s(buf, MAXHEADER, "correlation-id:%s\n", desc->correlation_id);
        if ((err = sendText(obj, buf, false)) != 0) return cleanBuff(buf, err);
    }

    if (strlen(rtrim(desc->receipt_id, MAXNORMNAME)) != 0) {
        sprintf_s(buf, MAXHEADER, "receipt-id:%s\n", desc->receipt_id);
        if ((err = sendText(obj, buf, false)) != 0) return cleanBuff(buf, err);
    }

    if (length == 0) {
        if ((err = sendText(obj, "\n\0", true)) != 0) return cleanBuff(buf, err);
        return 0;
    }



    if ((err = sendText(obj, "\n", false)) != 0) return cleanBuff(buf, err);
    if ((err = writeData(obj, content, length)) != 0) return cleanBuff(buf, err);
    if ((err = sendText(obj, "\0", true)) != 0) return cleanBuff(buf, err);

    return cleanBuff(buf, err);
}
static errno_t get(STMC* manager, STMO* obj, STMGO* options, STMMD* desc, BYTE* content, LENGTH* recvLen) {
    errno_t err = 0;
    char* ack = "auto";
    char* cmd = malloc(12);
    char* buf = malloc(MAXHEADER);

    if (buf == 0) return 1;
    memset(desc->message_id, 0, sizeof(desc->message_id));
    memset(desc->receipt_id, 0, sizeof(desc->receipt_id));

    rtrim(desc->correlation_id, MAXNORMNAME);
    if (options->client_ack || strlen(desc->correlation_id) > 0) ack = "client";

    if ((err = subcribe(manager, obj, options, ack, MAXHEADER, buf)) != 0) return cleanBuff(buf, err);

    while (true) {
        if ((err = readMessage(manager, obj, options->wait_interval, desc, cmd, content, recvLen, buf)) != 0) {
            unsubcribe(manager, obj, MAXHEADER, buf);
            return cleanBuff(buf, err);
        }
        if (strlen(desc->correlation_id) <= 0) break;
        if (strcmp(desc->correlation_id, desc->message_id) == 0) break;
    }

    if ((err = unsubcribe(manager, obj, MAXHEADER, buf)) != 0) return cleanBuff(buf, err);

    return cleanBuff(buf, err);
}
static errno_t subcribe(STMC* manager, STMO* obj, STMGO* options, char* ack, size_t bufLen, char* buf) {
    errno_t err = 0;

    sprintf_s(buf, bufLen, "\nSUBSCRIBE\ndestination:%s\nack:%s\n\n\0", obj->destination, ack);
    if ((err = sendText(obj, buf, true)) != 0) return err;

    return err;
}
static errno_t unsubcribe(STMC* manager, STMO* obj, size_t bufLen, char* buf) {
    errno_t err = 0;
    sprintf_s(buf, bufLen, "\nUNSUBSCRIBE\ndestination:%s\n\n\0", obj->destination);
    if ((err = sendText(obj, buf, true)) != 0) return err;

    return err;
}

static errno_t readEmptyMessage(STMC* manager, STMO* obj, int waitInterval, STMMD* desc, char* cmd, char* buf) {
    errno_t err = 0;
    BYTE* content = malloc(MAXHEADER);
    LENGTH revc = 0;
    err = readMessage(manager, obj, waitInterval, desc, cmd, content, &revc, buf);
    return cleanBuff(content, err);
}
static errno_t readMessage(STMC* manager, STMO* obj, int waitInterval, STMMD* desc, char* cmd, BYTE* content, LENGTH* recvLen, char* buf) {
    errno_t err = 0;
    char* empty = "\0";
    char* header = malloc(MAXHEADER);
    char* value = malloc(MAXHEADER);

    if ((err = readCommand(manager, obj, waitInterval, cmd, buf)) != 0) return err;

    strcpy(desc->message_id, empty);
    strcpy(desc->correlation_id, empty);
    strcpy(desc->receipt_id, empty);
    strcpy(desc->version, empty);
    strcpy(desc->destination, empty);

    while (true) {
        err = readHeader(manager, obj, waitInterval, header, value, buf);
        if (err > 0) return err;
        if (err == -1) break;
        if (header == 0) continue;
        if (value == 0) value = "\0";

        if (strcmp(header, "destination") == 0) strcpy(desc->destination, value);
        if (strcmp(header, "message-id") == 0) strcpy(desc->message_id, value);
        if (strcmp(header, "correlation-id") == 0) strcpy(desc->correlation_id, value);
        if (strcmp(header, "receipt-id") == 0) strcpy(desc->receipt_id, value);
        if (strcmp(header, "version") == 0) strcpy(desc->version, value);
    }

    if ((err = readContent(manager, obj, waitInterval, content, recvLen)) != 0) return err;
    return err;
}
static errno_t readCommand(STMC* manager, STMO* obj, int waitInterval, char* cmd, char* buf) {
    errno_t err = 0;
    LENGTH recvLen = 0;
    if ((err = readData(manager, obj, waitInterval, '\n', true, buf, &recvLen)) != 0) return err;
    strcpy(cmd, buf);
    return err;
}

static errno_t readHeader(STMC* manager, STMO* obj, int waitInterval, char* header, char* value, char* buf) {
    errno_t err = 0;
    LENGTH recvLen = 0;
    if ((err = readData(manager, obj, waitInterval, ':', false, buf, &recvLen)) != 0) return err;
    if (recvLen == 0) return -1;
    strcpy(header, buf);

    if ((err = readData(manager, obj, waitInterval, '\n', false, buf, &recvLen)) != 0) return err;
    strcpy(value, buf);

    return err;
}

static errno_t readContent(STMC* manager, STMO* obj, int waitInterval, BYTE* content, LENGTH* recvLen) {
    errno_t err = 0;
    if ((err = readData(manager, obj, waitInterval, '\0', false, content, recvLen)) != 0) return err;
    return err;
}