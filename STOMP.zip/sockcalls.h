/******************************************************************************
 * All right, title and interest in and to the software         
 * (the "Software") and the accompanying documentation or       
 * materials (the "Documentation"), including all proprietary   
 * rights, therein including all patent rights, trade secrets,  
 * trademarks and copyrights, shall remain the exclusive        
 * property of DXC Technology Company.            
 * No interest, license or any right respecting the Software       
 * and the Documentation, other than expressly granted in       
 * the Software License Agreement, is granted by implication    
 * or otherwise.                                                
 *                                                              
 * (C) Copyright 2005-2017 DXC Technology Company.
 * All rights reserved.                                         
 ******************************************************************************/
/******************************************************************************
 *  Chg#    Release  Description
 *
 *  040426  7.2     Cannot enable PX calculator
 ******************************************************************************/

#ifndef __SOCKCALLS_H__

#define __SOCKCALLS_H__  1

#include "STOMP.h"
#include "platform.h"

/**
 * This method will return the socket error in a platform dependent manner.
 */
int getSockError();

/**
 * This is the name of an environment variable that specifies how long a read
 * operation will wait before timing out.
 */
#define TIME_OUT_VARIABLE "ConnectorTimeOut"

/*  
 * Prototypes for COBOL compatible externals defined below.  These will
 * be called from COBOL as an alternative to the "handleRequest"
 * interface.
 */

errno_t init();
errno_t lookupIP(char* serverName, IP_ADDRESS* address);
errno_t createSocket(STMC* mgr, STMO* obj);
errno_t closeSocket(STMO* obj);
errno_t writeData(STMO* obj, BYTE* buf, LENGTH length);
errno_t readData(STMC* manager, STMO* obj, int waitInterval, char endChar, BOOL trimStart, BYTE* buf, LENGTH* recvBufLength);

#endif
