/******************************************************************************
 * All right, title and interest in and to the software         
 * (the "Software") and the accompanying documentation or       
 * materials (the "Documentation"), including all proprietary   
 * rights, therein including all patent rights, trade secrets,  
 * trademarks and copyrights, shall remain the exclusive        
 * property of DXC Technology Company.            
 * No interest, license or any right respecting the Software       
 * and the Documentation, other than expressly granted in       
 * the Software License Agreement, is granted by implication    
 * or otherwise.                                                
 *                                                              
 * (C) Copyright 2006-2017 DXC Technology Company.
 * All rights reserved.                                         
 ******************************************************************************/

#include "mutex.h"
#include "platform.h"

#ifdef _WIN32

/**
 *
 */
MUTEX createMutex(const char* mutexName)
{
	MUTEX mutex = CreateMutex(0, false, mutexName);

	if (mutex == 0)
	{
		fprintf(stderr, "Connector: Unable to create mutex %s\n", mutexName);
		return 0;
	}

	return mutex;
}

/**
 * Release the mutex
 */
void shutdownMutex(MUTEX mutex)
{
	CloseHandle(mutex);
}

/**
 * Get the lock so only this thread can access the code
 */
int lockMutex(MUTEX mutex)
{
	int aReturn = WaitForSingleObject(mutex, 5000L);

	switch (aReturn)
	{
	case WAIT_OBJECT_0:
	case WAIT_ABANDONED:
	case WAIT_TIMEOUT:
		/* Just return the return code. */
		break;

	case WAIT_FAILED:
		/* Return the last error code. */
		aReturn = GetLastError();
		break;
	}

	return aReturn;
}

/**
 * Release the lock so another thread can try to access the code
 */
BOOL unlockMutex(MUTEX mutex)
{
	if (ReleaseMutex(mutex) == 0)
	{
		fprintf(stderr, "Connector: Unable to unlock mutex\n");
		return false;
	}

	return true;
}

#else 

/**
 * Initialize the mutex used to control access to the log file
 */
MUTEX createMutex(const char* mutexName)
{
	MUTEX mutex = malloc(sizeof(pthread_mutex_t));

    int returnCode = pthread_mutex_init(mutex, 0);
	if (returnCode != 0)
	{
		fprintf(stderr, "Connector: Unable to create mutex %s: %d\n",
		                 mutexName, returnCode);
		return 0;
	}

	return mutex;
}

/**
 * Release the mutex
 */
void shutdownMutex(MUTEX mutex)
{
	pthread_mutex_destroy(mutex);

	if (mutex != 0)
	{
		free(mutex);
	}
}

/**
 * Get the lock so only this thread can access the code
 */
int lockMutex(MUTEX mutex)
{
	return pthread_mutex_lock(mutex);
}

/**
 * Release the lock so another thread can try to access the code
 */
BOOL unlockMutex(MUTEX mutex)
{
	if (pthread_mutex_unlock(mutex) != 0)
	{
		fprintf(stderr, "Connector: Unable to unlock mutex\n");
		return false;
	}

	return true;
}

#endif
