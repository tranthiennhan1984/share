/******************************************************************************
 * All right, title and interest in and to the software         
 * (the "Software") and the accompanying documentation or       
 * materials (the "Documentation"), including all proprietary   
 * rights, therein including all patent rights, trade secrets,  
 * trademarks and copyrights, shall remain the exclusive        
 * property of DXC Technology Company.            
 * No interest, license or any right respecting the Software       
 * and the Documentation, other than expressly granted in       
 * the Software License Agreement, is granted by implication    
 * or otherwise.                                                
 *                                                              
 * (C) Copyright 2006-2017 DXC Technology Company.
 * All rights reserved.                                         
 ******************************************************************************/

#include "platform.h"

#include <string.h>
#include <errno.h>

/**
 * Platform neutral file open function.
 */
errno_t openFile(FILE** file, const char* fileName, const char* mode) 
{
#ifdef _WIN32
	return fopen_s(file, fileName, mode);
#else
	*file = fopen(fileName, mode);
	return errno;
#endif
}

/*
 * Platform neutral local time function.
 */
errno_t getLocalTime(struct tm* localTime)
{
	time_t now;
	time(&now);

#ifdef _WIN32
	return localtime_s(localTime, &now);
#else
	errno=0;
	memcpy(localTime, localtime(&now), sizeof(struct tm));
	return errno;
#endif
}

/*
 * Returns a pointer to an environment variable.  You are responsible for calling
 * free on the buffer after you're done.
 */
errno_t getEnvironmentVariable(char** buffer, const char* name)
{
#ifdef _WIN32
	size_t bufferSize;
	return _dupenv_s(buffer, &bufferSize, name);
#else
	char* variable = getenv(name);
	if (variable == NULL) 
	{
		*buffer = NULL;
		return 1;
	}

	*buffer = strdup(variable);

	return errno;
#endif

}


