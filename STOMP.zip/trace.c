/******************************************************************************
 * All right, title and interest in and to the software
 * (the "Software") and the accompanying documentation or
 * materials (the "Documentation"), including all proprietary
 * rights, therein including all patent rights, trade secrets,
 * trademarks and copyrights, shall remain the exclusive
 * property of DXC Technology Company.
 * No interest, license or any right respecting the Software
 * and the Documentation, other than expressly granted in
 * the Software License Agreement, is granted by implication
 * or otherwise.
 *
 * (C) Copyright 2006-2017 DXC Technology Company.
 * All rights reserved.
 ******************************************************************************/
 /******************************************************************************
  *  Chg#    Release  Description
  *
  *  040426  7.2     Cannot enable PX calculator
  ******************************************************************************/

#include "trace.h"
#include "platform.h"
#include "mutex.h"

  /**
   * This variable contains the configuration for the trace system.
   */
static TRACE m_trace;

/**
 * Static functions
 */
BOOL setRequestLogFileName();
BOOL setResponseLogFileName();
BOOL isTracingEnabled();


/**
 * Initialize the trace infrastructure by getting configuration parameters from
 * INI variables and initializing the TRACE struct.  This method will return
 * true if we successfully initialized the system or false if we failed.
 */
BOOL initTrace()
{
    m_trace.tracingEnabled = isTracingEnabled();

    if (m_trace.tracingEnabled == true)
    {
        if (!setResponseLogFileName()) {
            m_trace.tracingEnabled = false;
            return false;
        }

        if (!setRequestLogFileName()) {
            m_trace.tracingEnabled = false;
            return false;
        }

        m_trace.responseLogFileMutex = createMutex("response");
        if (m_trace.responseLogFileMutex == 0)
        {
            m_trace.tracingEnabled = false;
            fprintf(stderr, "Connector: Unable to create the response mutex\n");
            return false;
        }

        m_trace.requestLogFileMutex = createMutex("request");
        if (m_trace.requestLogFileMutex == 0)
        {
            m_trace.tracingEnabled = false;
            fprintf(stderr, "Connector: Unable to create the request mutex\n");
            return false;
        }
    }

    return true;
}

/**
 * Check to see if tracing has been enabled.
 */
static BOOL isTracingEnabled()
{
    char* buffer;
    errno_t errno;

    errno = getEnvironmentVariable(&buffer, TRACE_ENABLE_VARIABLE);
    if (errno != 0 || buffer == NULL) {
        return false;
    }

    /* A value of 1 means tracing is enabled.  Anything else is disabled */

    if (strcmp(buffer, "1") == 0)
    {
        free(buffer);
        return true;
    }

    free(buffer);

    return false;
}

/**
 * Set the name of the file where we will be writing response trace
 * information.  The name of the file to use is contained in the
 * TRACE_RESPONSE_FILE_NAME_VARIABLE variable.
 * If we can't find the environment variable then we'll return false.
 * The buffer holding the file name must be freed()
 */
static BOOL setResponseLogFileName()
{
    errno_t errno;

    errno = getEnvironmentVariable(&m_trace.responseLogFileName, TRACE_RESPONSE_FILE_NAME_VARIABLE);
    if (errno != 0 || m_trace.responseLogFileName == NULL) {
        fprintf(stderr,
            "Connector: Unable to get the %s environment variable",
            TRACE_RESPONSE_FILE_NAME_VARIABLE);
        return false;
    }

    return true;
}

/**
 * Set the name of the file where we will be writing request trace
 * information.  The name of the file to use is contained in the
 * TRACE_RESPONSE_FILE_NAME_VARIABLE variable.
 * If we can't find the environment variable then we'll return false.
 * The buffer holding the file name must be freed()
 */
static BOOL setRequestLogFileName()
{
    char* buffer = '\0';
    errno_t errno;

    errno = getEnvironmentVariable(&m_trace.requestLogFileName, TRACE_REQUEST_FILE_NAME_VARIABLE);
    if (errno != 0 || m_trace.requestLogFileName == NULL) {
        fprintf(stderr,
            "Connector: Unable to get the %s environment variable",
            TRACE_REQUEST_FILE_NAME_VARIABLE);
    }

    return true;
}

void ntrace(_In_z_ _Printf_format_string_ char const* const _Format, ...) {
    va_list _ArgList;
    FILE* file;
    errno_t errno;

    if (m_trace.tracingEnabled == false) return;

    lockMutex(m_trace.responseLogFileMutex);

    errno = openFile(&file, m_trace.responseLogFileName, "a");
    if (errno) {
        unlockMutex(m_trace.responseLogFileMutex);
        m_trace.tracingEnabled = false;
        fprintf(stderr, "Connector: Unable to open the response log file %s\n",
            m_trace.responseLogFileName);
        return;
    }


    __crt_va_start(_ArgList, _Format);
    _vfprintf_l(file, _Format, NULL, _ArgList);
    __crt_va_end(_ArgList);

    fclose(file);
    unlockMutex(m_trace.responseLogFileMutex);
}
