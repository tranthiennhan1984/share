/******************************************************************************
 * All right, title and interest in and to the software         
 * (the "Software") and the accompanying documentation or       
 * materials (the "Documentation"), including all proprietary   
 * rights, therein including all patent rights, trade secrets,  
 * trademarks and copyrights, shall remain the exclusive        
 * property of DXC Technology Company.            
 * No interest, license or any right respecting the Software       
 * and the Documentation, other than expressly granted in       
 * the Software License Agreement, is granted by implication    
 * or otherwise.                                                
 *                                                              
 * (C) Copyright 2006-2017 DXC Technology Company.
 * All rights reserved.                                         
 ******************************************************************************/

#ifndef __MUTEX_H__
#define __MUTEX_H__ 1

#include "platform.h"

#ifdef _WIN32
	typedef HANDLE MUTEX;
#else
	typedef pthread_mutex_t* MUTEX;
#endif

MUTEX createMutex(const char* mutexName);
void shutdownMutex(MUTEX mutex);
int lockMutex(MUTEX mutex);
BOOL unlockMutex(MUTEX mutex);

#endif

