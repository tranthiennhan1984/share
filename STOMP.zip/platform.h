/******************************************************************************
 * All right, title and interest in and to the software         
 * (the "Software") and the accompanying documentation or       
 * materials (the "Documentation"), including all proprietary   
 * rights, therein including all patent rights, trade secrets,  
 * trademarks and copyrights, shall remain the exclusive        
 * property of DXC Technology Company.            
 * No interest, license or any right respecting the Software       
 * and the Documentation, other than expressly granted in       
 * the Software License Agreement, is granted by implication    
 * or otherwise.                                                
 *                                                              
 * (C) Copyright 2002-2017 DXC Technology Company.
 * All rights reserved.                                         
 ******************************************************************************/

#ifndef __PLATFORM_H__

#define __PLATFORM_H__ 1

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#ifndef NULL
#define NULL 0
#endif

/*****************************************************************************
 * Windows definitions.
 *****************************************************************************/
#ifdef _WIN32

/* Define a minimalist windows environment */

#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0500
#endif

#define CLOSE closesocket
/* Network functions */
#include <winsock2.h>
typedef unsigned int   SOCK;			/* PIC 9(8) COMP-5 */

/****************************************************************************
 * Non-windows definitions (Linux)
 ****************************************************************************/
#else 
/* The linux socket call returns an int */
typedef int SOCK;                       /* PIC S9(8) COMP-5 */
/* Thus a negative return code... */
#define SOCKET_ERROR -1
#define INVALID_SOCKET -1
#define CLOSE close

/* Network functions */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>

/*
 * Threading library
 */
#include <pthread.h>

#ifdef _INSTALLATION_HPUX
#include <string.h>
#endif

/*
 * Macros to get around difference between Microsoft and Unix library functions.
 */
#define sprintf_s(buffer, bufferSize, template, ...) sprintf(buffer, template, __VA_ARGS__)
#define strncpy_s(dest, destSize, src, count) strncpy(dest, src, count)

typedef int errno_t;

#endif  /* Not Windows */

/******************************************************************************
 * Generic definitions.
 *****************************************************************************/

/*
 * Platform neutral file open function.
 */
errno_t openFile(FILE** file, const char* fileName, const char* mode);

/*
 * Platform neutral local time function.
 */
errno_t getLocalTime(struct tm* localTime);

/*
 * Returns a pointer to an environment variable.  You are responsible for calling
 * free on the buffer after you're done.
 */
errno_t getEnvironmentVariable(char** buffer, const char* name);

typedef unsigned long  IP_ADDRESS;		/* PIC S9(8) COMP-5 */

/* Note that the PORT is actually a 16 bit number - we're using an int
 * to simplify the COBOL interface (avoid alignment problems). The code
 * casts the int to short where necessary. 
 */
typedef unsigned int   PORT;			/* PIC S9(18) COMP-5 */
typedef unsigned long int   LENGTH;		/* PIC S9(18) COMP-5 */

#ifdef _INSTALLATION_HPUX
typedef char  BYTE;
#else
typedef unsigned char  BYTE;
#endif

#define MAXHOSTNAME 255				/* Max hostname length for lookup call */

#ifdef _INSTALLATION_HPUX
typedef int BOOL;
#else
typedef enum 
{
	false = 0,
	true = 1
} BOOL;
#endif


#endif // __PLATFORM_H__

