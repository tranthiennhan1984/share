/******************************************************************************
 * All right, title and interest in and to the software
 * (the "Software") and the accompanying documentation or
 * materials (the "Documentation"), including all proprietary
 * rights, therein including all patent rights, trade secrets,
 * trademarks and copyrights, shall remain the exclusive
 * property of DXC Technology Company.
 * No interest, license or any right respecting the Software
 * and the Documentation, other than expressly granted in
 * the Software License Agreement, is granted by implication
 * or otherwise.
 *
 * (C) Copyright 2002-2017 DXC Technology Company.
 * All rights reserved.
 ******************************************************************************/
 /******************************************************************************
  *  Chg#    Release  Description
  *
  *  039602  7.2     Enhanced error messages from PX connection
  ******************************************************************************/

#ifndef __STOMP_H__

#define __STOMP_H__ 1

#include "platform.h"

#define MAXNORMNAME 80
#define MAXOBJNAME 255
#define MAXHEADER 300

#define MQ_HOST_VARIABLE	"STM_HOST"
#define MQ_PORT_VARIABLE	"STM_PORT"
#define MQ_TIMEOUT_VARIABLE	"STM_TIMEOUT"
#define MQ_USER_VARIABLE	"STM_USER"
#define MQ_PASS_VARIABLE	"STM_PASS"

typedef enum {
    STMF_CONN = 0,
    STMF_DISC = 1,
    STMF_OPEN = 2,
    STMF_CLOSE = 3,
    STMF_PUT = 4,
    STMF_GET = 5
} STMF;

typedef enum {
    STMR_OK = 0,
    STMR_ERR_SOCKET = 1,
    STMR_ERR_CONNECT = 11,
    STMR_ERR_DISCONNECT = 12,
    STMR_ERR_OPEN = 13,
    STMR_ERR_CLOSE = 14,
    STMR_ERR_PUT = 15,
    STMR_ERR_GET = 16,
    STMR_ERR_TIMEOUT = 55,
    STMR_INVALD_RQST = 99
} STMS;

/********************************************************
 * MQ Connection Factory
 *******************************************************/
typedef struct {
    char        hostname[MAXHOSTNAME];  /* The hostname. POINTER */
    IP_ADDRESS  address;                /* The returned IP Address. PIC S9(8) COMP-5 */
    PORT        port;                   /* PIC S9(18) COMP-5 */
    INT32       timeOut;
    char        user[MAXNORMNAME];
    char        pass[MAXNORMNAME];
} STMC;

typedef enum {
    MQOT_QUEUE = 1,
    MQOT_TOPIC = 2,
} STMOT;
/********************************************************
 * MQ Object descriptor structure
 *******************************************************/
typedef struct {
    STMOT     object_type;
    char            object_name[MAXNORMNAME];
} STMOD;

/********************************************************
 * MQ Object structure
 *******************************************************/
typedef struct {
    char            destination[MAXNORMNAME];
    SOCK            sock;
    char            version[MAXNORMNAME];
} STMO;

/********************************************************
 * MQ Message descriptor structure
 *******************************************************/
typedef struct {
    char            version[MAXNORMNAME];
    char            destination[MAXNORMNAME];
    char            message_id[MAXOBJNAME];
    char            correlation_id[MAXOBJNAME];
    char            receipt_id[MAXOBJNAME];
} STMMD;

/********************************************************
 * MQ Get option
 *******************************************************/
typedef struct {
    int             wait_interval;
    BOOL            client_ack;
} STMGO;

/********************************************************
 * MQ Object structure
 *******************************************************/
typedef struct {
    STMF         func;
    STMC          manager;
    STMS       status;
    errno_t         err;
    STMOD           odesc;
    STMGO           gopt;
    STMMD           mdesc;
} STMH;
/*
 * Function dispatcher
 */

__declspec(dllexport) void __stdcall STOMP(STMH* handler, STMO* obj, BYTE* buffer, LENGTH* length);
//
//__declspec(dllexport) void __stdcall MQCONN(STMC* manager, STMS* status, errno_t* err);
//__declspec(dllexport) void __stdcall MQDISC(STMC* manager, STMS* status, errno_t* err);
//__declspec(dllexport) void __stdcall MQOPEN(STMC* manager, STMOD* desc, STMO* obj, STMS* status, errno_t* err);
//__declspec(dllexport) void __stdcall MQCLOSE(STMC* manager, STMO* obj, STMS* status, errno_t* err);
//
//__declspec(dllexport) void __stdcall MQPUT(STMC* manager, STMO* obj, STMMD* desc, LENGTH length, BYTE* content, STMS* status, errno_t* err);
//__declspec(dllexport) void __stdcall MQGET(STMC* manager, STMO* obj, STMGO* options, STMMD* desc, BYTE* content, LENGTH* recvLen, STMS* status, errno_t* err);

#endif
