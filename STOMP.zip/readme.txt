/********************************************************************/ 
/*  All right, title and interest in and to the software            */
/*  (the "Software") and the accompanying documentation or          */
/*  materials (the "Documentation"), including all proprietary      */
/*  rights, therein including all patent rights, trade secrets,     */
/*  trademarks and copyrights, shall remain the exclusive           */
/*  property of DXC Technology Company.                             */
/*  No interest, license or any right respecting the Software       */
/*  and the Documentation, other than expressly granted in          */
/*  the Software License Agreement, is granted by implication       */
/*  or otherwise.                                                   */
/*                                                                  */
/*  (C) Copyright 2002-2017 DXC Technology Company.                 */
/*  All rights reserved.                                            */
/********************************************************************/ 

This project contains code that allows INGENIUM COBOL code to make socket calls.  It adds the ability
to log the data being sent back and forth plus it can trace the request and response messages.