/******************************************************************************
 * All right, title and interest in and to the software         
 * (the "Software") and the accompanying documentation or       
 * materials (the "Documentation"), including all proprietary   
 * rights, therein including all patent rights, trade secrets,  
 * trademarks and copyrights, shall remain the exclusive        
 * property of DXC Technology Company.            
 * No interest, license or any right respecting the Software       
 * and the Documentation, other than expressly granted in       
 * the Software License Agreement, is granted by implication    
 * or otherwise.                                                
 *                                                              
 * (C) Copyright 2005-2017 DXC Technology Company.
 * All rights reserved.                                         
 ******************************************************************************/

#ifndef __LOG_H__

#define __LOG_H__ 1

#include "STOMP.h"
#include "platform.h"
#include "mutex.h"
#include "trace.h"

/******************************************************************************
 * Log definitions
 *****************************************************************************/

/**
 * This is the name of the environment variable that specifies the name of a 
 * text file where logging information is going to be written.  If this variable
 * doesn't exist then logging is disabled.
 */
#define LOG_FILE_NAME_VARIABLE	"STM_LOG_FILE"

/**
 * This is the name of the environment variable that specifies the level of
 * logging information that should be implemented.  The value of this
 * variable should correspond to a value in the enum LOGLEVEL.  If this variable
 * doesn't exist then logging is disabled.
 */
#define LOG_LEVEL_VARIABLE		"STM_LOG_LEVEL"

/**
 * This enumeration defines the level of log information to log.
 */
typedef enum 
{
	LOG_NONE = 0,
	LOG_LOW = 1,
	LOG_HIGH = 2
} LOGLEVEL;

/**
 * This struct contains information needed to log the operation of the 
 * socket calls.
 */
typedef struct
{
	LOGLEVEL level;	/* What log level are we operating at? */
	char fileName[200];	/* Log file name */
	MUTEX mutex;	/* Controls access to the log file */
} LOG;

/**
 * Initialize the log subsystem.
 */
BOOL initLog();
int nlog(_In_z_ _Printf_format_string_ char const* const _Format, ...);

#endif // #ifndef __LOG_H__
