/******************************************************************************
 * All right, title and interest in and to the software
 * (the "Software") and the accompanying documentation or
 * materials (the "Documentation"), including all proprietary
 * rights, therein including all patent rights, trade secrets,
 * trademarks and copyrights, shall remain the exclusive
 * property of DXC Technology Company.
 * No interest, license or any right respecting the Software
 * and the Documentation, other than expressly granted in
 * the Software License Agreement, is granted by implication
 * or otherwise.
 *
 * (C) Copyright 2005-2017 DXC Technology Company.
 * All rights reserved.
 ******************************************************************************/
 /******************************************************************************
  *  Chg#    Release  Description
  *
  *  040426  7.2     Cannot enable PX calculator
  ******************************************************************************/

#include <stdio.h>
#include <stdarg.h>
#include "log.h"
#include "platform.h"
#include "mutex.h"

  /**
  * This variable contains the configuration for the log system.
  */
static LOG m_log;

/**
* Static functions
*/
LOGLEVEL getLogLevel();
errno_t setLogFileName(char* fileName, size_t fileNameBufferSize);

/**
* Initialize the log infrastructure by getting configuration parameters from
* INI variables and initializing the log structure.  This method will return
* true if we successfully initialized the system or false if we failed.
*/
BOOL initLog()
{
    m_log.level = getLogLevel();

    if (m_log.level != LOG_NONE)
    {
        if (setLogFileName(m_log.fileName, sizeof(m_log.fileName)) == 0)
        {
            m_log.level = LOG_NONE;
            fprintf(stderr, "Connector: Unable to open the log file\n");
            return false;
        }

        /*
        * Initialize the mutex functionality to protect against concurrent
        * writes to the log file
        */
        m_log.mutex = createMutex("log");
        if (m_log.mutex == 0)
        {
            return false;
        }
    }

    return true;
}

int __CRTDECL nlog(
    _In_z_ _Printf_format_string_ char const* const _Format,
    ...)
{
    va_list _ArgList;
    int _Result;

    if (m_log.level == LOG_NONE) return 0;

    lockMutex(m_log.mutex);

    __crt_va_start(_ArgList, _Format);
    _Result = writeLog(_Format, _ArgList);
    __crt_va_end(_ArgList);

    unlockMutex(m_log.mutex);
    return _Result;
}

static int writeLog(_In_z_ _Printf_format_string_ char const* const _Format, va_list _ArgList) {
    struct tm localTime;
    FILE* file;
    errno_t errno;
    int _Result;

    /*
    * Get the current date and time to write to the log file
    */
    errno = getLocalTime(&localTime);
    if (errno) {
        fprintf(stderr, "Connector: Unable to retrieve the local time: errno %d\n",
            errno);
        m_log.level = LOG_NONE;
        return errno;
    }

    /*
    * Try to open the file for appending.  If this succeeds then 0 is returned.
    */
    errno = openFile(&file, m_log.fileName, "a");
    if (errno) {
        fprintf(stderr, "Connector: Unable to open the log file %s: errno %d\n",
            m_log.fileName, errno);
        m_log.level = LOG_NONE;
        return errno;
    }

    _Result = _vfprintf_l(file, _Format, NULL, _ArgList);

    fclose(file);
    return _Result;
}


/**
* Get the log level from the LOG_LEVEL_VARIABLE environment variable
*/
static LOGLEVEL getLogLevel()
{
    char* variable;
    errno_t errno;
    LOGLEVEL logLevel;

    errno = getEnvironmentVariable(&variable, LOG_LEVEL_VARIABLE);
    if (errno != 0 || variable == NULL) {
        return LOG_NONE;
    }

    switch (atoi(variable))
    {
    case LOG_LOW:
        logLevel = LOG_LOW;
        break;

    case LOG_HIGH:
        logLevel = LOG_HIGH;
        break;

    default:
        logLevel = LOG_NONE;
        break;
    }

    free(variable);

    return logLevel;
}

/**
* Set the name of the file where we will be writing log information.  The name
* of the file to use is contained in the LOG_FILE_NAME_VARIABLE variable.
* If we can't find the environment variable then we'll return 0.
*/
static errno_t setLogFileName(char* fileName, size_t fileNameBufferSize)
{
    errno_t errno;
    char* buffer;

    errno = getEnvironmentVariable(&buffer, LOG_FILE_NAME_VARIABLE);
    if (errno != 0 || buffer == NULL) {
        fprintf(stderr,
            "Connector: Unable to get the %s environment variable. errno: %d",
            LOG_FILE_NAME_VARIABLE, errno);
        return 0;
    }

    strncpy_s(fileName, fileNameBufferSize, buffer, fileNameBufferSize);

    free(buffer);

    return 1;
}


