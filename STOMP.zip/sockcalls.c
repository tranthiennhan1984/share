/******************************************************************************
 * All right, title and interest in and to the software
 * (the "Software") and the accompanying documentation or
 * materials (the "Documentation"), including all proprietary
 * rights, therein including all patent rights, trade secrets,
 * trademarks and copyrights, shall remain the exclusive
 * property of DXC Technology Company.
 * No interest, license or any right respecting the Software
 * and the Documentation, other than expressly granted in
 * the Software License Agreement, is granted by implication
 * or otherwise.
 *
 * (C) Copyright 2002-2017 DXC Technology Company.
 * All rights reserved.
 ******************************************************************************/
 /******************************************************************************
  *  Chg#    Release  Description
  *
  *  039602  7.2     Enhanced error messages from PX connection
  *  040426  7.2     Cannot enable PX calculator
  ******************************************************************************/

#include <errno.h>		/* 039602 */
#include "sockcalls.h"
#include "STOMP.h"
#include "log.h"
#include "trace.h"

  /******************************************************************************
   * Static member definitions
   ******************************************************************************/

BOOL readStatusOk(int readTimeout, SOCK targetSocket);
void initializeTimeOut();

/******************************************************************************
 * Static variables
 *****************************************************************************/

 /*
  * This is the amount of time (in seconds) that a read operation will wait
  * for a reply.  If it doesn't come back in this amount of time, then an
  * error will be logged.
  */
int m_timeOutValue;

/******************************************************************************
 * Perform a DNS lookup - return an IP address given a hostname.
 * The hostname is a COBOL fixed length string (no trailing null).
 *****************************************************************************/

errno_t lookupIP(char* serverName, IP_ADDRESS* address) {
    struct hostent* lpHostEntry;
    lpHostEntry = gethostbyname(serverName);
    if (lpHostEntry == NULL) return 1;
    /* TODO: fix address type assumption. */
    memcpy((BYTE*)address, lpHostEntry->h_addr_list[0],
        lpHostEntry->h_length);
    return 0;
}

errno_t createSocket(STMC* mgr, STMO* obj) {
    IP_ADDRESS addr = mgr->address;
    PORT nPort = mgr->port;

    struct sockaddr_in saServer = { .sin_family = AF_INET };

    SOCK newSocket;
    int nRet;

    if (addr == 0 || nPort == 0) {
        nlog("createSocket failed: invalid ip_address or port\n");
        return 1;
    }

    nlog("createSocket started\n");

    newSocket = socket(AF_INET,				/* Address family */
        SOCK_STREAM,			/* Socket type */
        IPPROTO_TCP);		/* Protocol */

    if (newSocket == INVALID_SOCKET) {
        nlog("createSocket failed: invalid socket\n");
        return getSockError();
    }

    /* Fill in the address structure */

    saServer.sin_family = AF_INET;
    /* Server's address */
    saServer.sin_addr.s_addr = addr;
    /* Port number from command line */
    saServer.sin_port = htons((unsigned short)nPort);

    /* connect to the server */

    nRet = connect(newSocket,
        (struct sockaddr*)&saServer,
        sizeof(saServer));

    if (nRet == SOCKET_ERROR) {
        nlog("createSocket failed: socket error while connecting\n");
        return getSockError();
    }

    obj->sock = newSocket;

    nlog("createSocket ended\n");
    return 0;
}
errno_t closeSocket(STMO* obj) {
    SOCK targetSocket = obj->sock;
    if (targetSocket == 0) {
        nlog("closeSocket failed: invalid\n");
        return 1;
    }

    nlog("closeSocket started\n");

    shutdown(targetSocket, SD_BOTH);
    CLOSE(targetSocket);

    obj->sock = 0;
    nlog("closeSocket ended\n");
    return 0;
}

errno_t writeData(STMO* obj, BYTE* buf, LENGTH length) {
    SOCK targetSocket = obj->sock;
    int sizeSent = 0;
    int nRet;

    if (targetSocket == 0 || buf == 0 || length == 0) {
        nlog("writeBuffer failed: invalid socket or buffer\n");
        return 1;
    }

    nlog("writeBuffer started: %d\n", targetSocket);
    ntrace("%.*s\n", length, buf);

    while (sizeSent < length) {
        nRet = send(targetSocket,			/* Connected socket */
            buf + sizeSent,			/* Data buffer */
            length - sizeSent,	/* Length of data */
            0);					/* Flags */

        if (nRet == SOCKET_ERROR) {
            nlog("writeBuffer failed: socket error on send\n");
            return getSockError();
        }

        sizeSent += nRet;
    }

    nlog("writeBuffer ended\n");
    return 0;
}
errno_t readData(STMC* manager, STMO* obj, int waitInterval, char endChar, BOOL trimStart, BYTE* buf, LENGTH* recvBufLength) {
    SOCK targetSocket = obj->sock;
    BYTE* startPoint = buf;
    BYTE* endOfBuffer = buf;
    int timeOut = waitInterval > 0 ? waitInterval : manager->timeOut;

    /*  Total bytes received. */
    int sizeRead = 0;
    int nRet;

    if (targetSocket == 0 || buf == 0) {
        nlog("readBuffer failed: invalid socket or buffer\n");
        return 1;
    }

    nlog("readBuffer started\n");

    /*
     * What is the size of szBuf maxBufLength, or maxBufLength+1
     * if it is maxBufLength then this must be bytesToRead-1
     * because '\0' is added to the end of the buffer
     */
    while (true)
    {
        if (!readStatusOk(timeOut, targetSocket)) {
            nlog("readBuffer failed: timeout error\n");
            if (waitInterval < 0) continue;
            return STMR_ERR_TIMEOUT;
        }

        nRet = recv(targetSocket,		/* Connected socket */
            startPoint + sizeRead,		/* Receive buffer */
            1,                   		/* Size of receive buffer */
            0);							/* Flags */

        if (nRet == SOCKET_ERROR) {
            nlog("readBuffer failed: error reading socket\n");
            return getSockError();
        }

        if (nRet == 0) {
            *(startPoint + sizeRead) = '\0';
            break;
        }

        if (sizeRead == 0 && *(startPoint + sizeRead) == '\n') {
            *(startPoint + sizeRead) = '\0';
            if (trimStart) continue;
            else break;
        }

        if (*(startPoint + sizeRead) == endChar) {
            *(startPoint + sizeRead) = '\0';
            break;
        }
        sizeRead += nRet;
    }
    *recvBufLength = sizeRead;

    if (sizeRead == 0) ntrace("\n");
    else ntrace("%s%c", buf, endChar);
    nlog("readBuffer ended\n");
    return 0;
}

/*****************************************************************************
 * Check the status of a socket for readability
 *****************************************************************************/

static BOOL readStatusOk(int readTimeout, SOCK targetSocket)
{
    struct timeval timeout = { .tv_usec = 0 };
    fd_set readfd = { .fd_count = 0 };
    int nbSockets;
    int nRet = 0;

    if (readTimeout == 0)
    {
        return true;
    }

    FD_ZERO(&readfd);
    FD_SET(targetSocket, &readfd);

    timeout.tv_sec = readTimeout;
    timeout.tv_usec = 0;

    nbSockets = select(targetSocket + 1, &readfd, 0, 0, &timeout);

    if (nbSockets <= 0)
    {
        nlog("select() failed with errno: %d\n", errno);
        return false;
    }

    return true;
}


/****************************************************************************
 * Performs system initialization
 ****************************************************************************/

errno_t init()
{
#ifdef _WIN32
    int err = 0;
    WORD wVersionRequested = MAKEWORD(2, 0);
    WSADATA wsaData;
#endif

    /* Initialize the log subsystem */

    if (initLog() == false)
    {
        return false;
    }

    /* Tracing records the input and output messages */

    if (initTrace() == false)
    {
        return false;
    }

    /*
     * The timeout value might be specified in an environment variable.  This
     * routine will set it to its value.
     */
    initializeTimeOut();

#ifdef _WIN32
    err = WSAStartup(wVersionRequested, &wsaData);

    if (err != 0 || wsaData.wVersion != wVersionRequested)
    {
        fprintf(stderr, "erro code: %d", err);
        nlog("init failed with incorrect requested version\n");
        return err;
    }
#endif

    nlog("init ended\n");

    return err;
}

/***************************************************************************
 * Initialize the timeout value
 ***************************************************************************/

static void initializeTimeOut()
{
    char* buffer;
    errno_t errno;

    /*
     * If the variable isn't defined then we'll go with a default value.
     */
    errno = getEnvironmentVariable(&buffer, TIME_OUT_VARIABLE);
    if (errno != 0 || buffer == NULL) {
        /* set the errno to 0 as the timeout variable is optional so
         * we can disregard the errno */
        errno = 0;
        m_timeOutValue = 30;
        free(buffer);
        return;
    }

    m_timeOutValue = atoi(buffer);
    free(buffer);
}

int getSockError()
{
#ifdef _WIN32
    int error = WSAGetLastError();
#else
    int error = errno;
#endif
    return error;
}
