@echo off

@rem ******************************************************************************
@rem All right, title and interest in and to the software
@rem (the "Software") and the accompanying documentation or
@rem materials (the "Documentation"), including all proprietary
@rem rights, therein including all patent rights, trade secrets,
@rem trademarks and copyrights, shall remain the exclusive
@rem property of Hewlett Packard Enterprise Development LP.
@rem No interest, license or any right respecting the Software
@rem and the Documentation, other than expressly granted in
@rem the Software License Agreement, is granted by implication
@rem or otherwise.
@rem
@rem (C) Copyright 2015-2016 Hewlett Packard Enterprise Development LP.
@rem All rights reserved.
@rem ******************************************************************************

setlocal

@rem ******************************************************************************
@rem Set the environment variables used in this batch file.
@rem ******************************************************************************

call setWasPfEnv

@echo Registering server %APPLICATION_SERVER_NAME%%REGION_SUFFIX% as a Windows service

set ARGUMENTS=-add "%APPLICATION_SERVER_NAME%%REGION_SUFFIX%"
set ARGUMENTS=%ARGUMENTS% -serverName "%APPLICATION_SERVER_NAME%%REGION_SUFFIX%"
set ARGUMENTS=%ARGUMENTS% -profilePath %WAS_HOME%\profiles\%PROFILENAME%
set ARGUMENTS=%ARGUMENTS% -encodeParams
set ARGUMENTS=%ARGUMENTS% -stopArgs "-username %USERNAME% -password %PASSWORD%"
set ARGUMENTS=%ARGUMENTS% -startType automatic
set ARGUMENTS=%ARGUMENTS% -restart true
set ARGUMENTS=%ARGUMENTS% -logRoot %WAS_HOME%\profiles\%PROFILENAME%\logs

call %WAS_HOME%\bin\wasservice.exe %ARGUMENTS%

endlocal
