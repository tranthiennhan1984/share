#******************************************************************************
# All right, title and interest in and to the software        
# (the "Software") and the accompanying documentation or      
# materials (the "Documentation"), including all proprietary  
# rights, therein including all patent rights, trade secrets, 
# trademarks and copyrights, shall remain the exclusive       
# property of Hewlett Packard Enterprise Development LP.            
# No interest, license or any right respecting the Software      
# and the Documentation, other than expressly granted in      
# the Software License Agreement, is granted by implication   
# or otherwise.                                               
#                                                            
# (C) Copyright 2010-2016 Hewlett Packard Enterprise Development LP.
# All rights reserved.                                        
#******************************************************************************

import java
from utilityFunctions import *
from serverConfiguration import *
from ingeniumServerConfiguration import *

#---------------------------------------------------------------------
# This method will be called by the initialize.main() method.
# Perform any HPE Ingenium specific initialization here.
#---------------------------------------------------------------------

def initializeAdministrationServer():
    if usingCluster():
        scope = getScope(None, None, websphere.cluster.name)
    else:
        scope = getScope(websphere.standAlone.nodeName, websphere.standAlone.serverName)
        
    if ingenium.usePFC:
        configurePFCResources(scope)
    
    if ingenium.gateway == 'IBMCICS':
        configureCICSAdapter()

    if ingenium.gateway == 'JMS':
        configureIngeniumAJMSGateway()
#        configureIngeniumJMSGateway(scope)
    return
#---------------------------------------------------------------------
# Create resources used by PathfinderConnector
#---------------------------------------------------------------------

def configurePFCResources(scope):
    if ingenium.applications.pfc.useQueue:
        # Create the user alias used to access the queue
        configureSecurityDomainAuthenticationAlias(websphere.server.security.domainName,
                                                   ingenium.mq.pfc.authenticationAlias.name,
                                                   ingenium.mq.pfc.authenticationAlias.userId,
                                                   ingenium.mq.pfc.authenticationAlias.password)
        createMQConnectionFactory(scope, ingenium.mq.pfc.connectionFactory, ingenium.mq.pfc.authenticationAlias.name)
        createMQQueue(scope, ingenium.mq.pfc.connectionFactory, ingenium.mq.pfc.requestQueue)
        createMQQueue(scope, ingenium.mq.pfc.connectionFactory, ingenium.mq.pfc.responseQueue)
        createMQActivationSpecs(scope, ingenium.mq.pfc.connectionFactory, ingenium.mq.pfc.activation, ingenium.mq.pfc.authenticationAlias.name)
    return

# ----------------------------------------------------
# Install the CICS resource adapter 
# ----------------------------------------------------

def configureCICSAdapter():
    # Resource adapters must be installed at the node level.

    if (usingCluster()):
        for  clusterNode in websphere.cluster.nodes:
            nodeName = clusterNode[0]

            print 'INFO: Installing CICS resource adapter %s in node %s' % (ingenium.jca.cicseci.rarName, nodeName)

            installResourceAdapter(nodeName, 
                                    ingenium.jca.cicseci.rarName,
                                    ingenium.jca.cicseci.rarFile, 
                                    ingenium.jca.cicseci.rarOptions,
                                    ingenium.jca.cicseci.factoryAttributes.list, 
                                    ingenium.jca.cicseci.attributes.list)
    else:
        print 'INFO: Installing CICS resource adapter %s' % (ingenium.jca.cicseci.rarName)

        installResourceAdapter(websphere.standAlone.nodeName, 
                                ingenium.jca.cicseci.rarName,
                                ingenium.jca.cicseci.rarFile, 
                                ingenium.jca.cicseci.rarOptions,
                                ingenium.jca.cicseci.factoryAttributes.list,
                                ingenium.jca.cicseci.attributes.list)
    return

# ----------------------------------------------------
# Create the JMS resources needed by the JMSGateway
# ----------------------------------------------------

def configureIngeniumJMSGateway(scope):
    print 'INFO: Creating resources used by the JMS Gateway'

    configureSecurityDomainAuthenticationAlias(websphere.server.security.domainName,
                                               ingenium.JMSGateway.authenticationAlias.name,
                                               ingenium.JMSGateway.authenticationAlias.userId,
                                               ingenium.JMSGateway.authenticationAlias.password)

    createMQConnectionFactory(scope, ingenium.JMSGateway.connectionFactory, ingenium.JMSGateway.authenticationAlias.name)
    
    createMQQueue(scope, ingenium.JMSGateway.connectionFactory, ingenium.JMSGateway.dispatchQueue)
    createMQQueue(scope, ingenium.JMSGateway.connectionFactory, ingenium.JMSGateway.inQueue)
    createMQQueue(scope, ingenium.JMSGateway.connectionFactory, ingenium.JMSGateway.outQueue)
    return
    
def configureIngeniumAJMSGateway():
    print 'INFO: Creating resources used by the Active MQ JMS Gateway'
    
    cellName = websphere.cellName
    nodeName = websphere.standAlone.nodeName
    serverName = websphere.standAlone.serverName
    
    scope = '/Cell:%s/Node:%s/Server:%s' % (cellName, nodeName, serverName)
        
    configureSecurityDomainAuthenticationAlias(websphere.server.security.domainName,
                                               ingenium.AJMSGateway.authenticationAlias.name,
                                               ingenium.AJMSGateway.authenticationAlias.userId,
                                               ingenium.AJMSGateway.authenticationAlias.password)

    createJMSProvider(scope, ingenium.AJMSGateway.provider)
    
    jmspId = '%s/JMSProvider:%s/' % (scope, ingenium.AJMSGateway.provider.name)
    
    createGenericJMSConnectionFactory(jmspId, ingenium.AJMSGateway.queueFactory)
    
    createGenericJMSQueue(jmspId, ingenium.AJMSGateway.dispatchQueue)
    createGenericJMSQueue(jmspId, ingenium.AJMSGateway.inQueue)
    createGenericJMSQueue(jmspId, ingenium.AJMSGateway.outQueue)
    
    return
