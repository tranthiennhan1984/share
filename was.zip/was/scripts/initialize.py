#******************************************************************************
# All right, title and interest in and to the software        
# (the "Software") and the accompanying documentation or      
# materials (the "Documentation"), including all proprietary  
# rights, therein including all patent rights, trade secrets, 
# trademarks and copyrights, shall remain the exclusive       
# property of Hewlett Packard Enterprise Development LP.            
# No interest, license or any right respecting the Software      
# and the Documentation, other than expressly granted in      
# the Software License Agreement, is granted by implication   
# or otherwise.                                               
#                                                            
# (C) Copyright 2010-2016 Hewlett Packard Enterprise Development LP.
# All rights reserved.                                        
#******************************************************************************

import sys, java, javaos

#---------------------------------------------------------------------------
# Add the wsadmin objects to the sys.modules dictionary, this is needed
# so that we can use the objects in modules
#---------------------------------------------------------------------------

WSASobjects = {
    'AdminApp':AdminApp ,
    'AdminConfig':AdminConfig ,
    'AdminControl':AdminControl,
    'Help':Help
    }

if 'AdminTask' in dir():
    WSASobjects['AdminTask'] = AdminTask

sys.modules.update(WSASobjects)
sys.path.append('.')

def main():
    if usingCluster():
        createPathFinderCluster()
        scope = getScope(None, None, websphere.cluster.name)
    else:
        createPathFinderServer()
        scope = getScope(websphere.standAlone.nodeName, websphere.standAlone.serverName)

    configurePathFinderServers()

    initializeSecurity()

    configureJDBC(scope)

    configureJMS(scope)

    initializeAdministrationServer()

    print 'INFO: Saving Configuration'
    AdminConfig.save()
    return

def createPathFinderServer():
    nodeName = websphere.standAlone.nodeName
    serverName = websphere.standAlone.serverName

    serverExists = AdminServerManagement.checkIfServerExists(nodeName, serverName) == 'true'

    if not serverExists:
        print 'INFO: Creating server %s.%s' % (nodeName, serverName)
        AdminServerManagement.createApplicationServer(nodeName, serverName, 'default')
    else:
        print 'INFO: Using existing server %s' % serverName
    return

def createPathFinderCluster():
    clusterName = websphere.cluster.name

    # Check to see if the cluster exists. If it does then use it.  If not then
    # create the cluster.

    cluster = 'cell=%s,type=Cluster,name=%s,*' % (websphere.cellName, clusterName)
    cluster_id = AdminControl.completeObjectName(cluster)

    if len(cluster_id) > 0:
        print 'INFO: Using existing cluster %s' % clusterName
        return

    # First Create the cluster
    print 'INFO: Creating cluster %s' % clusterName

    clusterOpts = '[-clusterConfig [[%s true]]  -replicationDomain [[true]]]' % clusterName
    AdminTask.createCluster(clusterOpts)

    # Now Create the servers in the cluster
    for  clusterNode in websphere.cluster.nodes:
        nodeName = clusterNode[0]
        serverNames = clusterNode[1]
        for serverName in serverNames:
            print 'INFO: Creating server %s at node %s' % (serverName, nodeName)

            options = '[-clusterName %s -memberConfig [-memberNode %s -memberName %s -genUniquePorts true -replicatorEntry true]]' % (clusterName, nodeName, serverName)
            AdminTask.createClusterMember(options)
    return

def configurePathFinderServers():
    if usingCluster():
        for  clusterNode in websphere.cluster.nodes:
            nodeName = clusterNode[0]
            serverNames = clusterNode[1]
            for serverName in serverNames:
                configurePathFinderServer(nodeName, serverName)
    else:
        configurePathFinderServer(websphere.standAlone.nodeName, websphere.standAlone.serverName)
    return

def configurePathFinderServer(nodeName, serverName):
    print 'INFO: Modifying properties for %s' % serverName
    serverId = AdminConfig.getid('/Node:%s/Server:%s/' % (nodeName, serverName))
    if len(serverId) == 0:
        print "ERROR: Could not modify settings for server" + serverName
    else:
        webserverId = AdminConfig.list('WebserverPluginSettings', serverId)
        AdminConfig.modify(webserverId, '[[ServerIOTimeout %s]]' % websphere.webServer.pluginTimeOut)

    print 'INFO: Setting JVM properties'
    AdminServerManagement.setJVMProperties(nodeName, 
                                           serverName, 
                                           '',  # Classpath 
                                           '',  # BootClasspath
                                           websphere.server.heap.initialHeapSize, 
                                           websphere.server.heap.maximumHeapSize, 
                                           '',  # debugMode 
                                           '')  # debugArgs

    # Create JVM property for BIRT reports

    name = ['name', 'reports.folder']
    description = ['description', 'Folder where BIRT reports are located']
    value = ['value', pathfinder.applications.bamServer.reportsLocation]

    createJvmProperty(nodeName, serverName, [name, description, value])

    # enable J2 security at the server level
    setSecurity('false', websphere.cellName, websphere.standAlone.nodeName)
    return

def initializeSecurity():
    # We need to do things a little differently because of a problem in WAS 8.5.5
    # We cannot create users in the security domain until we restart the admin server
    # so the approach we take is to create the users and groups in the global
    # security domain, then create the Pathfinder security domain by copying
    # and customizing the global domain, then deleting the users and groups from
    # the global domain.

    verifyGroupDefinitions()

    deleteUsersFromGlobalDomain()
    deleteGroupsFromGlobalDomain()

    createUsersInGlobalDomain()
    createGroupsInGlobalDomain()

    mapUsersToGroups()

    createSecurityDomain()

    deleteUsersFromGlobalDomain()
    deleteGroupsFromGlobalDomain()

    if websphere.server.security.useldap=='true':
        print 'INFO: Configuring LDAP Security'

        ldap = websphere.server.security

        AdminTask.configureAppLDAPUserRegistry('-securityDomainName %s -ldapServerType %s -ldapHost %s -ldapPort %s -searchTimeout 300 -reuseConnection true -baseDN %s -bindDN %s -bindPassword %s -realmName %s' % (ldap.domainName, ldap.ldapServerType, ldap.ldapHost, ldap.ldapPort, ldap.baseDN, ldap.bindDN, ldap.bindPassword, ldap.realmNameLDAP))
        AdminTask.setAppActiveSecuritySettings ('-securityDomainName %s -activeUserRegistry LDAPUserRegistry'  % (ldap.domainName))

def verifyGroupDefinitions():
    # We want to be sure that each of the three Pathfinder users are in unique groups. For example,
    # we don't want the PathFinderClient and the Enterprise Designer debugger client to be in the same
    # group.

    print 'INFO: Verify PathFinder user groups'

    groups = [users.pathFinderClient.group, users.consoleServerAdmin.group, users.enterpriseDesignerClient.group]

    unique = []
    for group in groups:
        if group not in unique:
            unique.append(group)

    if len(groups) != len(unique):
        print 'ERROR: Each user must be defined in a unique group'
        sys.exit()

def deleteGroupsFromGlobalDomain():
    for pfGroup in [users.pathFinderClient.group, users.consoleServerAdmin.group, users.enterpriseDesignerClient.group]:
        group = AdminTask.searchGroups('[-cn %s]' % pfGroup)
        if (len(group) > 0):
            print 'INFO: Deleting group in global domain %s' % pfGroup
            AdminTask.deleteGroup('[-uniqueName %s]' % group)

def createGroupsInGlobalDomain():
    for pfGroup in [users.pathFinderClient.group, users.consoleServerAdmin.group, users.enterpriseDesignerClient.group]:
        print 'INFO: Creating group in global domain %s' % pfGroup
        AdminTask.createGroup('[-cn %s -description PathFinderGroup]' % pfGroup)

def deleteUsersFromGlobalDomain():
    for pfUser in [users.pathFinderClient.id, users.consoleServerAdmin.id, users.enterpriseDesignerClient.id]:
        user = AdminTask.searchUsers ('[-principalName %s]' % pfUser)
        if (len(user) > 0):
            print 'INFO: Deleting user %s' % pfUser
            AdminTask.deleteUser('[-uniqueName %s]' % user)

def createUsersInGlobalDomain():
    for client in [users.pathFinderClient, users.consoleServerAdmin, users.enterpriseDesignerClient]:
        print 'INFO: Creating user %s' % client.id
        AdminTask.createUser('-uid %s -password %s -sn %s -cn %s' % (client.id, client.password, client.id, client.id))

def mapUsersToGroups():
    for client in [users.pathFinderClient, users.consoleServerAdmin, users.enterpriseDesignerClient]:
        AdminTask.addMemberToGroup('-memberUniqueName uid=%s,o=defaultWIMFileBasedRealm -groupUniqueName cn=%s,o=defaultWIMFileBasedRealm' % (client.id, client.group))

def createSecurityDomain():
    domainName = websphere.server.security.domainName

    securityDomains = AdminTask.listSecurityDomains()
    securityDomains_list = securityDomains.split(lineSeparator)

    for domain in securityDomains_list:
        if domain == websphere.server.security.domainName:
            print 'INFO: Deleting existing security domain %s' % domainName
            AdminTask.deleteSecurityDomain('-securityDomainName %s -force true' % domainName)

    print 'INFO: Creating security domain %s' % domainName

    AdminTask.copySecurityDomainFromGlobalSecurity('-securityDomainName %s -securityDomainDescription "%s" -realmName defaultWIMFileBasedRealm' % (domainName, websphere.server.security.domainDescription))

    AdminTask.configureCSIInbound('-securityDomainName %s -transportLayer Supported' % (websphere.server.security.domainName))

    # Enable application security for the domain to ensure that valid credentials are used to call secure EJBs

    AdminTask.setAppActiveSecuritySettings('[-securityDomainName %s -appSecurityEnabled true]' % (websphere.server.security.domainName))

    if usingCluster():
        AdminTask.mapResourceToSecurityDomain('-securityDomainName %s -resourceName Cell=:ServerCluster=%s' % (websphere.server.security.domainName, websphere.cluster.name))
    else:
        AdminTask.mapResourceToSecurityDomain('-securityDomainName %s -resourceName Cell=:Node=%s:Server=%s' % (websphere.server.security.domainName, websphere.standAlone.nodeName, websphere.standAlone.serverName))

def configureJDBC(scope):
    nodeName = websphere.standAlone.nodeName
    serverName = websphere.standAlone.serverName

    for jdbc in pathfinder.jdbc.list:
        connectionProperties = jdbc[0]
        provider = jdbc[1]
        authAlias = jdbc[2]
        wasProviderList = AdminJDBC.listJDBCProviders(provider.name)
        if (len(wasProviderList) == 0):
            print 'INFO: Creating JDBC Provider ' + provider.name
            wasProvider = AdminJDBC.createJDBCProviderAtScope(scope, 
                                            provider.dbtype,
                                            provider.providerType,
                                            provider.implementationType,
                                            provider.name,
                                            provider.attributes)
        else:
            wasProvider = wasProviderList[0]

        # Create the user alias used to access the Database
        configureSecurityDomainAuthenticationAlias(websphere.server.security.domainName,
                                                   authAlias.name,
                                                   authAlias.userId,
                                                   authAlias.password)

        if usingCluster():
            cluster = websphere.cluster.name
        else:
            cluster = None

        configureJDBCDataSource(websphere.standAlone.nodeName,
                                websphere.standAlone.serverName,
                                cluster,
                                scope, 
                                wasProvider,
                                connectionProperties,
                                authAlias.name)
    return

def configureJMS(scope):
    createBus(websphere.sib.busName, websphere.standAlone.nodeName, websphere.sib.secure)

    if usingCluster():
        addBusMemberFileStore(websphere.sib.busName, None, None, websphere.cluster.name, websphere.sib.optionsME1)

        # One messaging engine will be created for each node in the cluster.
        for meOpts in  websphere.sib.additionalMessagingEngines:
            addMessagingEngineWithFileStore(websphere.sib.busName, websphere.cluster.name, meOpts)
    else:
        addBusMemberFileStore(websphere.sib.busName, websphere.standAlone.nodeName, websphere.standAlone.serverName, None, None)

    # Create the JMS connection factories
    for connectionFactory in pathfinder.jms.connectionFactoryList:
        createJMSConnectionFactory(scope, 
                                   connectionFactory.connectionFactoryName,
                                   connectionFactory.connectionFactoryJNDIName,
                                   connectionFactory.connectionType, 
                                   websphere.sib.busName)

    # Create the JMS Queues and bus destinations
    for queue in pathfinder.jms.queueList:
        createQueue(scope, 
                    queue.queueName,
                    queue.queueName,
                    queue.queueJNDIName,
                    websphere.sib.busName)

        if usingCluster():
            createBusDestination(websphere.standAlone.nodeName, 
                                 None,
                                 websphere.cluster.name,
                                 websphere.sib.busName,
                                 queue.queueName, 
                                 'Queue')
        else:
            createBusDestination(websphere.standAlone.nodeName, 
                                 websphere.standAlone.serverName, 
                                 None,
                                 websphere.sib.busName,
                                 queue.queueName, 
                                 'Queue')

    # Create the JMS Topics and bust destinations
    for topic in pathfinder.jms.topicList:
        createTopic(scope,
                    topic.topicName,
                    topic.topicJNDIName,
                    websphere.sib.busName)

        if usingCluster():
            createBusDestination(websphere.standAlone.nodeName, 
                                 None,
                                 websphere.cluster.name,
                                 websphere.sib.busName,
                                 topic.topicName, 
                                 'TopicSpace')
        else:
            createBusDestination(websphere.standAlone.nodeName, 
                                 websphere.standAlone.serverName, 
                                 None,
                                 websphere.sib.busName,
                                 topic.topicName, 
                                 'TopicSpace')

    if usingCluster():
        activationScope = '/ServerCluster:' + websphere.cluster.name + '/J2CResourceAdapter:SIB JMS Resource Adapter'
    else:
        activationScope = '/Node:' + websphere.standAlone.nodeName + '/Server:' + websphere.standAlone.serverName + '/J2CResourceAdapter:SIB JMS Resource Adapter'

    for activationSpec in pathfinder.jms.activationSpecList:
        createActivationSpec(activationScope, 
                             activationSpec.mdbName, 
                             activationSpec.mdbJNDIName, 
                             activationSpec.mdbDestJNDIName, 
                             activationSpec.mdbMaxEndPoints, 
                             websphere.sib.busName, 
                             activationSpec.mdbDestType)
    return

if (__name__ == '__main__'):
    print 'INFO: Starting initialize.py'

    from ibmfixes import *
    from utilityFunctions import *
    from serverConfiguration import *

    serverConfigurationScript = getEnvironmentVariable('SERVER_CONFIGURATION_SCRIPT')
    print 'INFO: Importing the server configuration script ' + serverConfigurationScript
    exec 'from ' + serverConfigurationScript + ' import *'

    serverInitializeScript = getEnvironmentVariable('SERVER_INITIALIZE_SCRIPT')
    print 'INFO: Importing the server initialization script ' + serverInitializeScript
    exec 'from ' + serverInitializeScript + ' import *'

    main()
else:
    print 'ERROR: Entry point main not found - script aborts'    
