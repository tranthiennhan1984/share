#******************************************************************************
# All right, title and interest in and to the software        
# (the "Software") and the accompanying documentation or      
# materials (the "Documentation"), including all proprietary  
# rights, therein including all patent rights, trade secrets, 
# trademarks and copyrights, shall remain the exclusive       
# property of Hewlett Packard Enterprise Development LP.            
# No interest, license or any right respecting the Software      
# and the Documentation, other than expressly granted in      
# the Software License Agreement, is granted by implication   
# or otherwise.                                               
#                                                            
# (C) Copyright 2010-2016 Hewlett Packard Enterprise Development LP.
# All rights reserved.                                        
#******************************************************************************

import sys, java, javaos

#---------------------------------------------------------------------------
# Add the wsadmin objects to the sys.modules dictionary, this is needed
# so that we can use the objects in modules
#---------------------------------------------------------------------------

WSASobjects = {
    'AdminApp':AdminApp ,
    'AdminConfig':AdminConfig ,
    'AdminControl':AdminControl,
    'Help':Help
    }

if 'AdminTask' in dir():
    WSASobjects['AdminTask'] = AdminTask

sys.modules.update(WSASobjects)
sys.path.append('.')

#---------------------------------------------------------------------------
# Main entry point
#---------------------------------------------------------------------------

def main():
    uninstallApps()
    removeResources()
    
    if usingCluster():
        command = "[-clusterName \"" + websphere.cluster.name + "\" -replicationDomain [-deleteRepDomain true] ]"
        AdminTask.deleteCluster( command )
    else:
        removeServer(websphere.standAlone.nodeName, websphere.standAlone.serverName)
    
    print 'INFO: Saving Configuration'
    AdminConfig.save()
    return

#---------------------------------------------------------------------------
# Remove resources
#---------------------------------------------------------------------------

def removeResources():
    removeSecurityDomain()
    deleteBus(websphere.sib.busName, websphere.standAlone.nodeName)
    return

#---------------------------------------------------------------------------
# Remove security domain
#---------------------------------------------------------------------------

def removeSecurityDomain():
    securityDomains = AdminTask.listSecurityDomains()
    securityDomains_list = securityDomains.split(lineSeparator)
    
    for domain in securityDomains_list:
    	if domain == websphere.server.security.domainName:
    	    print 'INFO: Deleting security domain %s' % websphere.server.security.domainName
    	    
    	    AdminTask.deleteSecurityDomain('-securityDomainName %s -force true' % (websphere.server.security.domainName))

#---------------------------------------------------------------------------
# Uninstall all applications installed in the server, list of 
# applications defined in configuration script
#---------------------------------------------------------------------------
    
def uninstallApps():
    for app in websphere.server.applications:
        uninstallApp(app)
    return

#---------------------------------------------------------------------------
# Uninstall application 
#---------------------------------------------------------------------------

def uninstallApp(appName):
    id = AdminConfig.getid('/Deployment:' + appName + '/')
    if len(id) > 0:
        print 'INFO: Uninstalling application ' + appName
        AdminApp.uninstall(appName)
    return

#---------------------------------------------------------------------------
# Entry point
#---------------------------------------------------------------------------

if (__name__ == '__main__'):
    print 'INFO: Starting delete.py'

    from ibmfixes import *
    from utilityFunctions import *
    from serverConfiguration import *

    serverConfigurationScript = getEnvironmentVariable('SERVER_CONFIGURATION_SCRIPT')
    print 'INFO: Importing the server configuration script ' + serverConfigurationScript
    exec 'from ' + serverConfigurationScript + ' import *'

    main()
else:
    print 'ERROR: Entry main not found - script aborts'    
