#******************************************************************************
# All right, title and interest in and to the software        
# (the "Software") and the accompanying documentation or      
# materials (the "Documentation"), including all proprietary  
# rights, therein including all patent rights, trade secrets, 
# trademarks and copyrights, shall remain the exclusive       
# property of Hewlett Packard Enterprise Development LP.            
# No interest, license or any right respecting the Software      
# and the Documentation, other than expressly granted in      
# the Software License Agreement, is granted by implication   
# or otherwise.                                               
#                                                            
# (C) Copyright 2010-2016 Hewlett Packard Enterprise Development LP.
# All rights reserved.                                        
#******************************************************************************

import os, sys
from utilityFunctions import *
from serverConfiguration import *

# ------------------------------------------------------------------
# This file contains configuration entries for Pathfinder with 
# HPE Ingenium and should be updated to match your configuration.
# Please inspect all items marked with the UPDATE HERE comment
# and ensure they match your environment.
# ------------------------------------------------------------------

class ingenium:
    # ------------------------------------------------------------------
    # This property is automatically set to the value of the 
    # INGENIUM_GATEWAY environment variable defined in setWasPfEnv.cmd 
    # ------------------------------------------------------------------

    gateway = getEnvironmentVariable('INGENIUM_GATEWAY').upper()

    # ------------------------------------------------------------------
    # The USE_PATHFINDERCONNECTOR environment variable will be set in
    # the setWASPFEnv batch file to true if PFC should be installed.
    # ------------------------------------------------------------------

    usePFC = getEnvironmentVariable('USE_PATHFINDERCONNECTOR').upper() == 'TRUE'

    class applications:
        class pfc:
            appName = 'PathFinderConnector' + regionSuffix
            appFileName = '../../PathFinderConnectorEar.ear'
            userId = users.pathFinderClient.id
            password = users.pathFinderClient.password
            contextRoot = '/PathFinderConnector' + regionSuffix
            virtualHost = defaultVirtualHost
            useQueue = getEnvironmentVariable('PATHFINDERCONNECTOR_LISTENER').upper() == 'QUEUE'
            deploy = getEnvironmentVariable('DEPLOY_PATHFINDERCONNECTOR').upper() == 'TRUE'

    class jdbc:
        class ingeniumDBAlias:
            # -------------------- UPDATE HERE ---------------------------------
            # The user used to connect to the HPE Ingenium database
            # -------------------- UPDATE HERE ---------------------------------
            name = 'IngeniumDatabaseUserID' + regionSuffix
            userId = 'IPPV26'
            password = 'P@ssw0rd'
        #----------------------------------------------------------------------------
        # The dsHelperClassName is typically 
        #      com.ibm.websphere.rsadapter.DB2UniversalDataStoreHelper
        # for DB2 on Windows or Z/OS. If using DB2 on AS/400 then the class is
        #      com.ibm.websphere.rsadapter.DB2AS400DataStoreHelper
        # For Oracle, the dsHelperClassName is 
        #      com.ibm.websphere.rsadapter.Oracle11gDataStoreHelper
        #----------------------------------------------------------------------------                      
        class ingeniumDatabaseConnection:
            # -------------------- UPDATE HERE ---------------------------------
            # Update these entries with the server name, database name and
            # port of the database server hosting the HPE Ingenium database.
            # -------------------- UPDATE HERE ---------------------------------
            dbType = 'db2'
            dbHost = 'VNVA016AIE.sunlifecorp.com'
            dbName = 'UDIPPV26'
            dbPort = '20330'
            dsName = 'INGENIUM Datasource'
            dsJNDIName = 'jdbc/IngeniumDataSource'
            transacted = 'false'
            dsHelperClassName = 'com.ibm.websphere.rsadapter.DB2UniversalDataStoreHelper'
            #----------------------------------------------------------------------------
            # Use this property to add custom attributes to the DataSource
            #----------------------------------------------------------------------------
            additionalProperties = []
        list = [ingeniumDatabaseConnection(), pathfinder.jdbc.providers.DB2(), ingeniumDBAlias()]

    class jms:
        class pfc:
            class connectionFactory:
                connectionFactoryName = 'PFC-ConnectionFactory'
                connectionFactoryJNDIName = 'jms/PFCConnectionFactory'
                connectionType = 'Queue'
            class responseQueue:
                queueName='PFCTransmitResponseQueue'
                queueJNDIName='jms/PFCTransmitResponseQueue'
            class requestQueue:
                queueName='PFCTransmitRequestQueue'
                queueJNDIName='jms/PFCTransmitRequestQueue'
            class activation:
                mdbName         = 'TransmittalMessageProvider'
                mdbJNDIName     = 'jms/TransmittalMessageProvider'
                mdbDestType     = 'Queue'
                mdbDestJNDIName = 'jms/PFCTransmitRequestQueue'
                mdbMaxEndPoints = '1'
            queueList = [responseQueue(), requestQueue()]
        class synchronizer:
            class activation:
                class pageserver:
                    mdbName = 'PageServerSynchronizerProvider'
                    mdbJNDIName = 'jms/PageServerSynchronizerProvider'
                    mdbDestType = 'Topic'
                    mdbDestJNDIName = 'jms/SynchronizerDestination'
                    mdbMaxEndPoints = '1'
                class ingenium:
                    mdbName = 'IngeniumSynchronizerProvider'
                    mdbJNDIName = 'jms/IngeniumSynchronizerProvider'
                    mdbDestType = 'Topic'
                    mdbDestJNDIName = 'jms/SynchronizerDestination'
                    mdbMaxEndPoints = '1'
                
    # ------------------------------------------------------------
    # This section is only relevant if Pathfinder Connector is
    # deployed and will be using MQ to receive messages instead
    # of using sockets.
    # ------------------------------------------------------------
    class mq:
        class pfc:
            class authenticationAlias:
                name     = 'MQPathFinderConnectorAuthenticationAliasID'
                # -------------------- UPDATE HERE ---------------------------------
                # This is the username and password used to connect to the MQ manager
                # -------------------- UPDATE HERE ---------------------------------
                userId   = 'pfclient'
                password = 'solcorp-1234'
            # -------------------- UPDATE HERE ---------------------------------
            # Specify all the connection factory properties needed to connect to the
            # MQ manager.
            # -------------------- UPDATE HERE ---------------------------------
            class connectionFactory:
                name         = 'MQPFCConnectionFactory'
                jndiName     = 'mq/PFCConnectionFactory'
                type         = 'QCF'
                queueManager = 'PFP01'
                hostname     = '<servername>'
                port         = '1414'
                channel      = 'PFCLIENT'
                ttype        = 'CLIENT' 
            # -------------------- UPDATE HERE ---------------------------------
            # Specify the properties to set up the queue where Pathfinder 
            # Connector will subscribe to listen for message from HPE Ingenium.
            # -------------------- UPDATE HERE ---------------------------------
            class requestQueue:
                name      = 'MQPFCRequestQueue'
                jndiName  = 'mq/PFCRequestQueue'
                queueName = 'PF.PFC.PR.REQUEST'
            # -------------------- UPDATE HERE ---------------------------------
            # Specify the properties to set up the queue where Pathfinder will
            # post any response to HPE Ingenium
            # -------------------- UPDATE HERE ---------------------------------
            class responseQueue:
                name      = 'MQPFCResponseQueue'
                jndiName  = 'mq/PFCResponseQueue'
                queueName = 'PF.PFC.PR.RESPONSE'
            # -------------------- UPDATE HERE ---------------------------------
            # Specify the activation specs properties the pathfinder MDB needs to
            # subscribe to the MQ queue.
            # -------------------- UPDATE HERE ---------------------------------
            class activation:
                name         = 'MQPFCProvider'
                jndiName     = 'mq/PFCProvider'
                destType     = 'javax.jms.Queue'
                destJNDIName = 'mq/PFCRequestQueue'
                maxEndPoints = '1'

    class jca:
        class cicseci:
            # -------------------- UPDATE HERE ---------------------------------
            # Specify the fully qualified name of the cicseci.rar file 
            # provided by the CICS Transaction Gateway.  We recommend using
            # the 8 character short name for any directory names that have
            # spaces in them.  This section is only relevant if using the
            # IBMCICS gateway.
            # -------------------- UPDATE HERE ---------------------------------
			# VN-PAWKS
            rarFile = 'C:\Sunlife\D\drivers/cicseci.rar'
            rarName = 'CICSECI'
            rarOptions = '[-rar.name ' + rarName + ' -rar.desc "CICS ECI Resource Adapter"]'
            class factoryAttributes:
                name = ['name', 'IngeniumConnectionFactory' + regionSuffix]
                jndiName = ['jndiName', 'cics/INGENIUMConnectionFactory' + regionSuffix]
                list = [name, jndiName]
            class attributes:
                # -------------------- UPDATE HERE ---------------------------------
                # Specify the name, URL and port number of the CTG server.  If
                # you are using a local CTG then the connectionURL should be the
                # string 'local:'.  If using a remote CTG then connectionURL will
                # be 'tcp://server.name.com'.
                # Set userName and password to the name and password of the CICS
                # user under which the call to HPE Ingenium will be made.
                # -------------------- UPDATE HERE ---------------------------------
				# VN-PAWKS
                serverName = ['serverName', 'LOCAL']
                connectionURL = ['connectionURL', 'tcp://VNVA016AIE.sunlifecorp.com']
                portNumber = ['portNumber', '2006']
                userName = ['userName', 'SYSAD']
                password = ['password', 'SYSAD']
                list = [serverName, connectionURL, portNumber, userName, password]

    class JMSGateway:
        # -------------------- UPDATE HERE ---------------------------------
        # This is the username and password used to connect to the MQ manager
        # -------------------- UPDATE HERE ---------------------------------
        class authenticationAlias:
            name     = 'JMSGatewayAuthenticationAliasID'
            userId   = 'admin'
            password = 'admin'
        # -------------------- UPDATE HERE ---------------------------------
        # Specify all the connection factory properties needed to connect to 
        # the MQ manager.
        # -------------------- UPDATE HERE ---------------------------------
        class connectionFactory:
            name         = 'IngeniumGatewayConnectionFactory'
            jndiName     = 'jms/IngeniumGatewayConnectionFactory'
            type         = 'QCF'
            queueManager = 'PFP01'
            hostname     = 'VNVA016AIE.sunlifecorp.com'
            port         = '61616'
            channel      = 'PFCLIENT'
            ttype        = 'CLIENT' 
        # -------------------- UPDATE HERE ---------------------------------
        # Specify the properties for the dispatch queue that HPE Ingenium uses
        # to indicate that it is ready to process a request.
        #
        # The queue definition can have an options element to specify
        # other parameters that are passed directly to the AdminTask
        # createWMQQueue command.  The parameter name must start with -.
        # -------------------- UPDATE HERE ---------------------------------
        class dispatchQueue:
            name      = 'IngeniumDispatchQueue'
            jndiName  = 'jms/IngeniumDispatchQueue'
            queueName = 'PF.INGENIUM.LC.D'
            options   = '-persistence NON -useRFH2 false'
        # -------------------- UPDATE HERE ---------------------------------
        # Specify the properties for the input queue that HPE Ingenium uses
        # to receive requests from the Pathfinder.
        #
        # The queue definition can have an options element to specify
        # other parameters that are passed directly to the AdminTask
        # createWMQQueue command.  The parameter name must start with -.
        # -------------------- UPDATE HERE ---------------------------------
        class inQueue:
            name      = 'IngeniumInQueue'
            jndiName  = 'jms/IngeniumInQueue'
            queueName = 'PF.INGENIUM.LC.I'
            options   = '-persistence NON -useRFH2 false'
        # -------------------- UPDATE HERE ---------------------------------
        # Specify the properties for the output queue that HPE Ingenium uses
        # to send responses back to the Pathfinder.
        #
        # The queue definition can have an options element to specify
        # other parameters that are passed directly to the AdminTask
        # createWMQQueue command.  The parameter name must start with -.
        # -------------------- UPDATE HERE ---------------------------------
        class outQueue:
            name      = 'IngeniumOutQueue'
            jndiName  = 'jms/IngeniumOutQueue'
            queueName = 'PF.INGENIUM.LC.O'
            options   = '-persistence NON -useRFH2 false'
 
    class AJMSGateway:
        # -------------------- UPDATE HERE ---------------------------------
        # This is the username and password used to connect to the MQ manager
        # -------------------- UPDATE HERE ---------------------------------
        class authenticationAlias:
            name     = 'JMSGatewayAuthenticationAliasID'
            userId   = 'admin'
            password = 'admin'
            
        # -------------------- UPDATE HERE ---------------------------------
        # Specify all the provider properties needed to connect to Active MQ
        # -------------------- UPDATE HERE ---------------------------------
        class provider:
            name         = 'AMQJmsProvider'
            classpath    = 'C:\Sunlife\D\drivers/activemq.jar'
            extICF       = 'org.apache.activemq.jndi.ActiveMQWASInitialContextFactory'
            extPURL      = 'tcp://localhost:61616'
        
        # -------------------- UPDATE HERE ---------------------------------
        # Specify all the provider properties needed to connect to Active MQ
        # -------------------- UPDATE HERE ---------------------------------
        class queueFactory:
            name         = 'IngeniumGatewayConnectionFactory1'
            qtype        = 'QUEUE'
            jndiName     = 'jms/IngeniumGatewayConnectionFactory1'

# ------------------------------------------------------------------
# Add the HPE Ingenium and PageServer or PageBuilder activation Spec.
# ------------------------------------------------------------------

pathfinder.jms.activationSpecList.append(ingenium.jms.synchronizer.activation.ingenium())
if pathfinder.usePageServer:
    pathfinder.jms.activationSpecList.append(ingenium.jms.synchronizer.activation.pageserver())
else:
    pathfinder.jms.activationSpecList.append(pathfinder.jms.synchronizer.activation.pagebuilder())

# ------------------------------------------------------------------
# Add the PathfinderConnector application to the list of applications.
# This list is used when deleting all installed applications.
# ------------------------------------------------------------------

if ingenium.usePFC:
    websphere.server.applications.append(ingenium.applications.pfc.appName)
    pathfinder.jms.queueList.append(ingenium.jms.pfc.requestQueue())
    pathfinder.jms.queueList.append(ingenium.jms.pfc.responseQueue())
    pathfinder.jms.connectionFactoryList.append(ingenium.jms.pfc.connectionFactory())
    pathfinder.jms.activationSpecList.append(ingenium.jms.pfc.activation())

# ------------------------------------------------------------------
# Add the HPE Ingenium specific JDBC connections to the list that
# will be initialized.
# ------------------------------------------------------------------

pathfinder.jdbc.list.append(ingenium.jdbc.list)

