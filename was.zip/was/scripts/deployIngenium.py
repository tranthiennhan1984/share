#******************************************************************************
# All right, title and interest in and to the software        
# (the "Software") and the accompanying documentation or      
# materials (the "Documentation"), including all proprietary  
# rights, therein including all patent rights, trade secrets, 
# trademarks and copyrights, shall remain the exclusive       
# property of Hewlett Packard Enterprise Development LP.            
# No interest, license or any right respecting the Software      
# and the Documentation, other than expressly granted in      
# the Software License Agreement, is granted by implication   
# or otherwise.                                               
#                                                            
# (C) Copyright 2010-2016 Hewlett Packard Enterprise Development LP.
# All rights reserved.                                        
#******************************************************************************

import java
from utilityFunctions import *
from serverConfiguration import *
from ingeniumServerConfiguration import *

#----------------------------------------------------------------------------
# This method is called by the deploy script and gives you an opportunity
# to perform any administration server specific functions.
# For HPE Ingenium, we need to deploy the PathfinderConnector application if
# it's being used.
#----------------------------------------------------------------------------

def deployAdministrationServerApps():
    if ingenium.usePFC:
        deployPathFinderConnector()
    return

#----------------------------------------------------------------------------
# Add any HPE Ingenium specific deployment options and their parameters to the
# deployment options for the Pathfinder application. The options parameter
# is of the CommandOptions type defined in utilityFunctions.py
#----------------------------------------------------------------------------

def addPathFinderDeployOptions(options):
    application = pathfinder.applications.pathFinder

    #----------------------------------------------------------------------------
    # Resolve the reference to the ExtensionInitializer EJB that's defined
    # in the web.xml for PageServer and PageBuilder.
    #----------------------------------------------------------------------------

    options['MapEJBRefToEJB'].extend([
        '.* .* .* ejb/extension/initializers/IngeniumExtensionInitializer com.solcorp.common.servlet.initializer.ExtensionInitializer ejblocal:ejb/IngeniumExtensionInitializerBean'
        ])

    #----------------------------------------------------------------------------
    # Assign a JNDI name to the HPE Ingenium ExtensionInitializer EJB.
    #----------------------------------------------------------------------------

    options['BindJndiForEJBBusiness'].extend([
        'Ingenium.jar IngeniumConsoleBean Ingenium.jar,META-INF/ejb-jar.xml com.solcorp.consoleserver.ingenium.IngeniumConsole ejb/IngeniumConsole',
        'Ingenium.jar IngeniumExtensionInitializerBean Ingenium.jar,META-INF/ejb-jar.xml com.solcorp.common.servlet.initializer.ExtensionInitializer ejblocal:ejb/IngeniumExtensionInitializerBean'
        ])

    #----------------------------------------------------------------------------
    # Bind the MDB that listens for ConsoleServer notifications to the JNDI
    # name for the ConsoleServer's topic.
    #----------------------------------------------------------------------------

    options['BindJndiForEJBMessageBinding'].extend([
        'Ingenium.jar IngeniumNotificationListener Ingenium.jar,META-INF/ejb-jar.xml "" %s "" ""' % (ingenium.jms.synchronizer.activation.ingenium.mdbJNDIName)
        ])

    #----------------------------------------------------------------------------
    # The HPE Ingenium ExtensionInitializer EJB has a resource reference to the
    # JDBC connection to the HPE Ingenium database.  This option resolves that
    # reference.
    #----------------------------------------------------------------------------

    options['MapResRefToEJB'].extend([
        'Ingenium.jar IngeniumExtensionInitializerBean Ingenium.jar,META-INF/ejb-jar.xml jdbc/IngeniumDataSource javax.sql.DataSource %s "" "" ""' % (ingenium.jdbc.ingeniumDatabaseConnection.dsJNDIName)
        ])

    #----------------------------------------------------------------------------
    # If we're using IBM CICS to communicate with HPE Ingenium then resolve the 
    # resource reference to the ECI connection factory
    #----------------------------------------------------------------------------

    if ingenium.gateway == 'IBMCICS':
        options['MapResRefToEJB'].extend([
            '.* .* .* cics/INGENIUMConnectionFactory javax.resource.cci.ConnectionFactory %s "" "" ""' % (ingenium.jca.cicseci.factoryAttributes.jndiName[1])
            ])

    #----------------------------------------------------------------------------
    # If we're using JMS to communicate with HPE Ingenium then we need to map the 
    # message destination references that are specified in the JMS gateway EJB.  
    # jms/DQConnectionFactory is used to create the input and output queues.
    #----------------------------------------------------------------------------

    if ingenium.gateway == 'JMS':
        options['MapResRefToEJB'].extend([
            'JmsGateway.jar JmsGateway JmsGateway.jar,META-INF/ejb-jar.xml jms/IngeniumGatewayConnectionFactory javax.jms.QueueConnectionFactory %s' % (ingenium.JMSGateway.connectionFactory.jndiName)
            ])

        options['MapMessageDestinationRefToEJB'].extend([
            'JmsGateway.jar JmsGateway JmsGateway.jar,META-INF/ejb-jar.xml jms/IngeniumDispatchQueue %s' % (ingenium.JMSGateway.dispatchQueue.jndiName),
            'JmsGateway.jar JmsGateway JmsGateway.jar,META-INF/ejb-jar.xml jms/IngeniumInQueue %s' % (ingenium.JMSGateway.inQueue.jndiName),
            'JmsGateway.jar JmsGateway JmsGateway.jar,META-INF/ejb-jar.xml jms/IngeniumOutQueue %s' % (ingenium.JMSGateway.outQueue.jndiName)
            ])

    #----------------------------------------------------------------------------
    # If we're using LDAP then we need to map the user roles to groups
    #----------------------------------------------------------------------------

    if websphere.server.security.useldap=='true':	
        ldap = websphere.server.security

        options['MapRolesToUsers'].extend([
            'IngeniumGroup AppDeploymentOption.No AppDeploymentOption.No "" cn=IngeniumGroup,%s AppDeploymentOption.No "" group:%s/cn=IngeniumGroup,%s' % (ldap.baseDN, ldap.realmNameLDAP, ldap.baseDN),
            ])
    return

#----------------------------------------------------------------------------
# Add any HPE Ingenium specific deployment options and their parameters to the
# deployment options for the ConsoleServer application. The options parameter
# is of the CommandOptions type defined in utilityFunctions.py
#----------------------------------------------------------------------------

def addConsoleServerDeployOptions(options):
    #----------------------------------------------------------------------------
    # Resolve EJB references for the HPE Ingenium ConsoleServer components.
    #----------------------------------------------------------------------------

    options['MapEJBRefToEJB'].extend([
        'ConsoleServer "" ConsoleServer.war,WEB-INF/web.xml ejb/IngeniumConsole com.solcorp.consoleserver.ingenium.IngeniumConsole ejb/IngeniumConsole',
        'ConsoleServerEjb.jar ConsoleServerNotificationListener ConsoleServerEjb.jar,META-INF/ejb-jar.xml ejb/IngeniumConsole com.solcorp.consoleserver.ingenium.IngeniumConsole ejb/IngeniumConsole',
        ])
    return

#----------------------------------------------------------------------------
# Add any HPE Ingenium specific deployment options and their parameters to the
# deployment options for the BAMServer application. The options parameter
# is of the CommandOptions type defined in utilityFunctions.py
#----------------------------------------------------------------------------

def  addBAMServerDeployOptions(options):
    return

#----------------------------------------------------------------------------
# Add any HPE Ingenium specific deployment options and their parameters to the
# deployment options for the WebServices application. The options parameter
# is of the CommandOptions type defined in utilityFunctions.py
#----------------------------------------------------------------------------

def addWebServiceDeployOptions(options):
    return

def deployPathFinderConnector():
    application = ingenium.applications.pfc

    if not application.deploy:
        return

    jms = ingenium.jms.pfc

    print 'INFO: Deploying ' + application.appName

    options = CommandOptions({
        'appname':application.appName,
        'asyncRequestDispatchType':'DISABLED',
        'createMBeansForResources':None,
        'distributeApp':None,
        'filepermission':'.*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755',
        'noallowDispatchRemoteInclude':None,
        'noallowServiceRemoteInclude':None,
        'nodeployejb':None,
        'nodeployws':None,
        'nopreCompileJSPs':None,
        'noprocessEmbeddedConfig':None,
        'noreloadEnabled':None,
        'nouseAutoLink':None,
        'nouseMetaDataFromBinary':None,
        'validateinstall':'warn',
        'MapResRefToEJB':[
            '.* "" PathFinderConnectorWar.war,WEB-INF/web.xml jms/PFCConnectionFactory javax.jms.QueueConnectionFactory %s "" "" ""' % (jms.connectionFactory.connectionFactoryJNDIName),
            'PathFinderConnector.jar QueueTransmitResponseHandler PathFinderConnector.jar,META-INF/ejb-jar.xml jms/PFCConnectionFactory javax.jms.QueueConnectionFactory %s "" "" ""' % (jms.connectionFactory.connectionFactoryJNDIName),
            'PathFinderConnector.jar XMLProtocolHandler PathFinderConnector.jar,META-INF/ejb-jar.xml jms/PFCConnectionFactory javax.jms.QueueConnectionFactory %s "" "" ""' % (jms.connectionFactory.connectionFactoryJNDIName),
            'PathFinderConnector.jar ResponseQueueAccessor PathFinderConnector.jar,META-INF/ejb-jar.xml jms/PFCConnectionFactory javax.jms.QueueConnectionFactory %s "" "" ""' % (jms.connectionFactory.connectionFactoryJNDIName)
            ],
        'MapEJBRefToEJB':[
            'PathFinderConnectorWar "" PathFinderConnectorWar.war,WEB-INF/web.xml ejb/BamGateway com.solcorp.bamserver.gateway.BAMGateway ejb/BamGateway',
            'PathFinderConnectorWar "" PathFinderConnectorWar.war,WEB-INF/web.xml ejb/PathFinder com.solcorp.pathfinder.ejb.PathFinderRemote ejb/PathFinder',
            'PathFinderConnectorWar "" PathFinderConnectorWar.war,WEB-INF/web.xml com.solcorp.pathfinderconnector.backbean.PathFinderConnectorStatus/m_responseQueueAccessor com.solcorp.pathfinder.connector.ejb.QueueAccessor ejblocal:ejb/ResponseQueueAccessor',
            'PathFinderConnector.jar TransmittalMessageListener PathFinderConnector.jar,META-INF/ejb-jar.xml ejb/TransmitResponseHandler com.solcorp.pathfinder.connector.ejb.TransmitResponseHandler ejblocal:ejb/QueueTransmitResponseHandler'
            ],
        'MapModulesToServers':[
            'PathFinderConnector.jar PathFinderConnector.jar,META-INF/ejb-jar.xml ' + getModuleToServerMappingString(),
            '.* PathFinderConnectorWar.war,WEB-INF/web.xml ' + getModuleToServerMappingString()
            ],
        'CtxRootForWebMod':[
            '.* .* ' + application.contextRoot
            ],
        'MapWebModToVH':[
            '.* PathFinderConnectorWar.war,WEB-INF/web.xml ' + application.virtualHost
            ],
        'MapEnvEntryForWebMod':[
            '.* PathFinderConnectorWar.war,WEB-INF/web.xml PathFinderConnector/PathFinderUserId .* .* ' + application.userId,
            '.* PathFinderConnectorWar.war,WEB-INF/web.xml PathFinderConnector/PathFinderUserPassword .* .* ' + application.password
            ],
        'BindJndiForEJBMessageBinding':[
            'PathFinderConnector.jar TransmittalMessageListener PathFinderConnector.jar,META-INF/ejb-jar.xml "" %s "" ""' % (jms.activation.mdbJNDIName),
            ],
        'BindJndiForEJBBusiness':[
            ' PathFinderConnector.jar QueueTransmitResponseHandler PathFinderConnector.jar,META-INF/ejb-jar.xml com.solcorp.pathfinder.connector.ejb.TransmitResponseHandler ejblocal:ejb/QueueTransmitResponseHandler',
            ' PathFinderConnector.jar NullTransmitResponseHandler PathFinderConnector.jar,META-INF/ejb-jar.xml com.solcorp.pathfinder.connector.ejb.TransmitResponseHandler ejblocal:ejb/NullTransmitResponseHandler',
            ' PathFinderConnector.jar ResponseQueueAccessor PathFinderConnector.jar,META-INF/ejb-jar.xml com.solcorp.pathfinder.connector.ejb.QueueAccessor ejblocal:ejb/ResponseQueueAccessor'
            ],
        'MapMessageDestinationRefToEJB':[
            '.* "" PathFinderConnectorWar.war,WEB-INF/web.xml jms/PFCTransmitRequestQueue %s' % (jms.requestQueue.queueJNDIName),
            '.* "" PathFinderConnectorWar.war,WEB-INF/web.xml jms/PFCTransmitResponseQueue %s' % (jms.responseQueue.queueJNDIName),
            'PathFinderConnector.jar XMLProtocolHandler PathFinderConnector.jar,META-INF/ejb-jar.xml %s %s' % (jms.requestQueue.queueJNDIName, jms.requestQueue.queueJNDIName),
            'PathFinderConnector.jar QueueTransmitResponseHandler PathFinderConnector.jar,META-INF/ejb-jar.xml %s %s' % (jms.responseQueue.queueJNDIName, jms.responseQueue.queueJNDIName),
            'PathFinderConnector.jar ResponseQueueAccessor PathFinderConnector.jar,META-INF/ejb-jar.xml %s %s' % (jms.responseQueue.queueJNDIName, jms.responseQueue.queueJNDIName)
            ]
        })
   
    #----------------------------------------------------------------------------
    # If PFC is using a queue to communicate with HPE Ingenium then we need to 
    # configure the queue parameters.
    #----------------------------------------------------------------------------

    if application.useQueue:
        options['MapResRefToEJB'].extend([
            'PathFinderConnectorEjb.jar PathFinderConnectorMDB PathFinderConnectorEjb.jar,META-INF/ejb-jar.xml mq/PFCConnectionFactory javax.jms.QueueConnectionFactory %s "" "" ""' % (ingenium.mq.pfc.connectionFactory.jndiName)
            ])
        options['MapModulesToServers'].extend([
            'PathFinderConnectorEjb.jar PathFinderConnectorEjb.jar,META-INF/ejb-jar.xml '  + getModuleToServerMappingString()
            ])
        options['BindJndiForEJBMessageBinding'].extend([
            'PathFinderConnectorEjb.jar PathFinderConnectorMDB PathFinderConnectorEjb.jar,META-INF/ejb-jar.xml "" %s "" ""' % (ingenium.mq.pfc.activation.jndiName)
            ])
        options['MapMessageDestinationRefToEJB'].extend([
            'PathFinderConnectorEjb.jar PathFinderConnectorMDB PathFinderConnectorEjb.jar,META-INF/ejb-jar.xml  mq/PFCResponseQueue ' + ingenium.mq.pfc.responseQueue.jndiName
            ])

    deployApplication(application.appName, application.appFileName, options.getString())

    setAttributes(application.appName, 'deployedObject', [['startingWeight', '5']])
    return
