#******************************************************************************
# All right, title and interest in and to the software
# (the "Software") and the accompanying documentation or
# materials (the "Documentation"), including all proprietary
# rights, therein including all patent rights, trade secrets,
# trademarks and copyrights, shall remain the exclusive
# property of Hewlett Packard Enterprise Development LP.
# No interest, license or any right respecting the Software
# and the Documentation, other than expressly granted in
# the Software License Agreement, is granted by implication
# or otherwise.
#
# (C) Copyright 2010-2016 Hewlett Packard Enterprise Development LP.
# All rights reserved.
#******************************************************************************

WSASobjects = {
    'AdminApp':AdminApp ,
    'AdminConfig':AdminConfig ,
    'AdminControl':AdminControl,
    'Help':Help
    }

if 'AdminTask' in dir():
    WSASobjects['AdminTask'] = AdminTask

sys.modules.update(WSASobjects)
sys.path.append('.')

from ibmfixes import *
from utilityFunctions import *
from serverConfiguration import *

cluster = 'cell=' + websphere.cellName + ',type=Cluster,name=' + websphere.cluster.name + ',*'
cluster_id = AdminControl.completeObjectName(cluster)
if len(cluster_id) == 0:
    print "ERROR: Could not get a reference to cluster " + websphere.cluster.name
    sys.exit(1)

AdminControl.invoke(cluster_id, 'rippleStart')
