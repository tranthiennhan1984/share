#******************************************************************************
# All right, title and interest in and to the software        
# (the "Software") and the accompanying documentation or      
# materials (the "Documentation"), including all proprietary  
# rights, therein including all patent rights, trade secrets, 
# trademarks and copyrights, shall remain the exclusive       
# property of Hewlett Packard Enterprise Development LP.            
# No interest, license or any right respecting the Software      
# and the Documentation, other than expressly granted in      
# the Software License Agreement, is granted by implication   
# or otherwise.                                               
#                                                            
# (C) Copyright 2010-2016 Hewlett Packard Enterprise Development LP.
# All rights reserved.                                        
#******************************************************************************

import os, sys
from utilityFunctions import *

# ------------------------------------------------------------------
# Please inspect all items marked with the UPDATE HERE comment
# and ensure they match your environment.
# ------------------------------------------------------------------

# ------------------------------------------------------------------
# This property is automatically set to the value of the 
# REGION_SUFFIX environment variable defined in setWasPfEnv.cmd 
# ------------------------------------------------------------------

regionSuffix = getEnvironmentVariable('REGION_SUFFIX')

# ------------------------------------------------------------------
# This is the default virtual host where the web modules will be 
# deployed.  You can override this on an app by app basis by setting 
# the pathfinder.applications.XXX.virtualHost property for each 
# individual application.
# ------------------------------------------------------------------

defaultVirtualHost = 'default_host'

# -------------------- UPDATE HERE ---------------------------------
# Set the path to the folder where the JDBC drivers are located.
# -------------------- UPDATE HERE ---------------------------------
# VN-PAWKS
jdbcDriverPath = 'C:\Sunlife\D\drivers'

# ------------------------------------------------------------------
# This section defines WebSphere users that have permission to call
# secured EJBS and debug the Pathfinder. You must specify the id,
# or name of the client, their password, and the WebSphere group
# that the client belongs to. These clients will be mapped to
# their appropriate role as part of the deployment process. Each
# client must be in a different group.
# ------------------------------------------------------------------
class users:
    # --------------------------------------------------------------
    # This client will be mapped to the "pfrole" role allowing it
    # to call the Pathfinder EJB.
    # --------------------------------------------------------------
    class pathFinderClient:
        id = 'pfclient'
        password = 'solcorp-1234'
        group = 'pfrole'
    # --------------------------------------------------------------
    # This client will be mapped to the "csrole" role allowing it
    # to call functions provided by the ConsoleServer.
    # --------------------------------------------------------------
    class consoleServerAdmin:
        id = 'csadmin'
        password = 'solcorp-1234'
        group = 'csrole'
    # --------------------------------------------------------------
    # This client will be mapped to the "debugrole" role allowing it
    # to be used by Enterprise Designer when debugging the
    # Pathfinder.
    # --------------------------------------------------------------
    class enterpriseDesignerClient:
        id = 'edclient'
        password = 'solcorp-1234'
        group = 'debugrole'

#------------------------------------
# WebSphere Information
#------------------------------------

class websphere:
    # -------------------- UPDATE HERE ---------------------------------
    # Set useCluster to 1 if deploying to a cluster.  Set to 0 to deploy
    # to a standalone server.
    # -------------------- UPDATE HERE ---------------------------------
    useCluster = 0

    # -------------------- UPDATE HERE ---------------------------------
    # Set the cell name
    # -------------------- UPDATE HERE ---------------------------------
	# VN-PAWKS
    cellName = 'BINEAN-SVR01Node01Cell'
    class webServer:
        # -------------------- UPDATE HERE ---------------------------------
        # This section is relevant if using the IBM HTTP server.
        # Set the name of the webserver and the node where it is running.
        # the pluginTimeOut defines the amount of time that the webserver
        # will wait for a response from the AppServer.  You must run the
        # HTTP server if running in a cluster.
        # -------------------- UPDATE HERE ---------------------------------
        name = 'webserver1'
        nodeName = 'BINEAN-SVR01.sunlifecorp.com-node'
        pluginTimeOut = '900'
    class standAlone:
        # -------------------- UPDATE HERE ---------------------------------
        # This section is relevant if not deploying to a cluster.
        # Update the nodeName.  The name of the single server to use is 
        # specified as the value of the APPLICATION_SERVER_NAME environment
        # variable.
        # If using the built-in HTTP server in a non-production environment
        # then set useWebServer to 0.  If using the IBM HTTP server then 
        # set useWebServer to 1.  
        # -------------------- UPDATE HERE ---------------------------------
		# VN-PAWKS
        nodeName = 'BINEAN-SVR01Node01'
        serverName = getEnvironmentVariable('APPLICATION_SERVER_NAME') + regionSuffix
        useWebServer = 0
    class cluster:
        # -------------------- UPDATE HERE ---------------------------------
        # This section is relevant if deploying to a cluster. The cluster
        # name is specified as the value of the CLUSTER_NAME environment
        # variable.  The nodes array variable contains two elements. The
        # first is the name of the node and the second is an array containing
        # the names of the servers within that node.
        # -------------------- UPDATE HERE ---------------------------------
        name = getEnvironmentVariable('CLUSTER_NAME')
        nodes = [['BINEAN-SVR01AANode01', [
                        getEnvironmentVariable('APPLICATION_SERVER_NAME') + '1' + regionSuffix, 
                        getEnvironmentVariable('APPLICATION_SERVER_NAME') + '2' + regionSuffix
                    ]
                ]
            ]
    class server:
        applications = [
            'PathFinder' + regionSuffix, 
            'BamServer' + regionSuffix, 
            'ConsoleServer' + regionSuffix, 
            'PFWebServices' + regionSuffix
            ]
        class security:
            # -------------------- UPDATE HERE ---------------------------------
            # If using LDAP then set useldap = 'true', otherwise 'false'
            #
            # ldapServerType specifies the type of LDAP server being used. 
            #   Allowable values are:
            #   IBM Tivoli Directory Server - IBM_DIRECTORY_SERVER 
            #   IBM SecureWay Directory Server - SECUREWAY
            #   Sun Java System Directory Server - IPLANET
            #   IBM Lotus Domino - DOMINO502 
            #   Microsoft Active Directory - ACTIVE_DIRECTORY
            #   Novell eDirectory - NDS 
            #   Custom - CUSTOM
            # ldapHost is the name or IP address of the LDAP server
            # ldapPort is the LDAP server port. Typically 389
            # baseDN is the base distinguished name of the directory service
            # bindDN is the distinguised name to use when connecting to the 
            #   directory server
            # bindPassword is the password to use when connecting to the server
            # realmNameLDAP is the realm name to create
            # -------------------- UPDATE HERE ---------------------------------
            useldap = 'false'
            ldapServerType = 'IBM_DIRECTORY_SERVER'
            ldapHost = '000.000.0.00'
            ldapPort = '389'
            baseDN = 'dc=solcorp,dc=com'
            bindDN = 'cn=root'
            bindPassword = 'ldap'
            realmNameLDAP = '<servername>'

            domainName = 'PathFinderSecurityDomain' + regionSuffix
            domainDescription = 'Security domain for Pathfinder server ' + regionSuffix
        class heap:
            initialHeapSize =  '256'
            maximumHeapSize = '1024'
    class sib:
        busName = 'PathFinderBus' + regionSuffix
        secure = 'FALSE'       # Can be TRUE or FALSE

        # ---------------------------------- UPDATE HERE ---------------------------------
        # The messaging engine options are mandatory if creating a cluster. If not 
        # creating a cluster then the websphere defaults will be used. In a cluster there
        # should be one messaging engine for each server. The directories for logDirectory,
        # permanentStoreDirectory and temporaryStoreDirectory must exist and be empty 
        # before running initialize.
        # ---------------------------------- UPDATE HERE ---------------------------------
        optionsME1 = {'enableAssistance'            : 'true',
                      'policyName'                  : 'SCALABILITY_HA',
                      'logSize'                     : '100',
                      'logDirectory'                : 'c:/cluster/sibus/me1/log',
                      'minPermanentStoreSize'       : '200',
                      'unlimitedPermanentStoreSize' : 'FALSE',
                      'maxPermanentStoreSize'       : '500',
                      'permanentStoreDirectory'     : 'c:/cluster/sibus/me1/store',
                      'minTemporaryStoreSize'       : '200',
                      'unlimitedTemporaryStoreSize' : 'FALSE',
                      'maxTemporaryStoreSize'       : '500',
                      'temporaryStoreDirectory'     : 'c:/cluster/sibus/me1/store'}

        optionsME2 = {'logSize'                     : '100',
                      'logDirectory'                : 'c:/cluster/sibus/me2/log',
                      'minPermanentStoreSize'       : '200',
                      'unlimitedPermanentStoreSize' : 'FALSE',
                      'maxPermanentStoreSize'       : '500',
                      'permanentStoreDirectory'     : 'c:/cluster/sibus/me2/store',
                      'minTemporaryStoreSize'       : '200',
                      'unlimitedTemporaryStoreSize' : 'FALSE',
                      'maxTemporaryStoreSize'       : '500',
                      'temporaryStoreDirectory'     : 'c:/cluster/sibus/me2/store'}
        # ---------------------------------- UPDATE HERE ---------------------------------
        # The additionalMessagingEngines variable should contain the names of any 
        # messaging engines defined above with the exception of optionsME1 which will be
        # created by default. The optionsME1 engine is created by default when the cluster
        # is created. Messaging engines other than optionsME1 do not specify 
        # enableAssistance or policyName parameters as they are specified for optionsME1.
        # There should be as many messaging engines as there are application servers in 
        # the cluster.
        # ---------------------------------- UPDATE HERE ---------------------------------
        additionalMessagingEngines   = [optionsME2]
        schemaName = 'pfbus'

#--------------------------------------
# Pathfinder Configuration Information
#--------------------------------------
class pathfinder:
    # ------------------------------------------------------------------
    # This property is set to true if the value of the PAGE_SOURCE  
    # environment variable defined in setWasPfEnv.cmd is 'HTML'
    # ------------------------------------------------------------------
    usePageServer = getEnvironmentVariable('PAGE_SOURCE').upper() == 'HTML'

    class applications:
        class pathFinder:
            appName = 'PathFinder' + regionSuffix
            appFileName = '../../PathFinderEar.ear'
            configFileName = 'C:\Sunlife\D\presentation\ini\PathFinderConfig.xml'
            contextRoot = '/ingenium' + regionSuffix
            virtualHost = defaultVirtualHost
            deploy = getEnvironmentVariable('DEPLOY_PATHFINDER').upper() == 'TRUE'
        class bamServer:
            appName = 'BamServer' + regionSuffix
            appFileName = '../../BamServerEar.ear'
            contextRoot = '/BamServer' + regionSuffix
            virtualHost = defaultVirtualHost
            birtWar = 'birt-2.6.2.war'
            # -------------------- UPDATE HERE ---------------------------------
            # This is the directory where BAM report templates are stored.
            # This value will be assigned to the reports.folder JVM property.
            # -------------------- UPDATE HERE ---------------------------------
            reportsLocation = 'C:\Sunlife\D\presentation\BamServer\reports'
            # -------------------- UPDATE HERE ---------------------------------
            # This is the fully qualified name of the file where data
            # generated by the gateway will be written. In the case of HPE Ingenium,
            # this is the MIR log. This value can be updated after deployment
            # by editing the GatewayLogLogger/GatewayLogFileName environment 
            # entry for the BamServer.
            # -------------------- UPDATE HERE ---------------------------------
            gatewayLogFileName = 'C:\Sunlife\D\presentation\logs\GatewayLog.txt'
            # -------------------- UPDATE HERE ---------------------------------
            # This is the maximum number of days of BAM data that will be kept 
            # in the database.  This value can be updated after deployment by
            # editing the BAMServer/NumberOfDaysToKeepData  environment entry
            # for the BamServer.
            # -------------------- UPDATE HERE ---------------------------------
            numberOfDaysToKeepData = '10'
            deploy = getEnvironmentVariable('DEPLOY_BAMSERVER').upper() == 'TRUE'
        class consoleServer:
            appName = 'ConsoleServer' + regionSuffix
            appFileName = '../../ConsoleServerEar.ear'
            userId = users.consoleServerAdmin.id
            password = users.consoleServerAdmin.password
            contextRoot = '/ConsoleServer' + regionSuffix
            virtualHost = defaultVirtualHost
            deploy = getEnvironmentVariable('DEPLOY_CONSOLESERVER').upper() == 'TRUE'
        class webServices:
            appName = 'PFWebServices' + regionSuffix
            appFileName = '../../PFWebServices.ear'
            userId = users.pathFinderClient.id
            password = users.pathFinderClient.password
            virtualHost = defaultVirtualHost
            deploy = getEnvironmentVariable('DEPLOY_WEBSERVICES').upper() == 'TRUE'
    class jdbc:
        class authenticationAlias:
            class processPoolAlias:
                # -------------------- UPDATE HERE ---------------------------------
                # The user ID used to connect to the Pathfinder process pool database
                # VN-PAWKS
                # -------------------- UPDATE HERE ---------------------------------
                name = 'PathfinderProcessPoolUserID' + regionSuffix
                userId = 'IPPV26'
                password = 'P@ssw0rd'
            class bamLoggingDBAlias:
                # -------------------- UPDATE HERE ---------------------------------
                # The user used to connect to the BAM logging database
                # VN-PAWKS
                # -------------------- UPDATE HERE ---------------------------------
                name = 'BamLoggingDatabaseUserID' + regionSuffix
                userId = 'IPPV26'
                password = 'P@ssw0rd'
        class providers:
            class DB2:
                 dbtype = 'DB2' # needed by new Function createJDBCProviderAtScope - Valid values include DB2, Derby, Informix, Oracle, Sybase, SQL Server, and user-defined values.
                 providerType = 'DB2 Universal JDBC Driver Provider'
                 name = 'DB2' + regionSuffix
                 implementationType = 'Connection pool data source'
                 attributes = [['classpath', '%s/db2jcc.jar;%s/db2jcc_license_cu.jar' % (jdbcDriverPath, jdbcDriverPath)],
                              ['description', 'DB2 Universal JDBC Driver Provider']]
            class Oracle:
                 dbtype = 'Oracle'
                 providerType = 'Oracle JDBC Driver'
                 name = 'Oracle' + regionSuffix
                 implementationType = 'Connection pool data source'
                 attributes = [['classpath', '%s/ojdbc8.jar' % (jdbcDriverPath)],
                              ['description', 'Oracle Universal JDBC Driver Provider']]
        #----------------------------------------------------------------------------
        # The dsHelperClassName is typically 
        #      com.ibm.websphere.rsadapter.DB2UniversalDataStoreHelper
        # for DB2 on Windows or Z/OS. If using DB2 on AS/400 then the class is
        #      com.ibm.websphere.rsadapter.DB2AS400DataStoreHelper
        # For Oracle, the dsHelperClassName is 
        #      com.ibm.websphere.rsadapter.Oracle11gDataStoreHelper
        #----------------------------------------------------------------------------                      
        class processPoolConnection:
            # -------------------- UPDATE HERE ---------------------------------
            # Update these entries with the server name, database name and
            # port of the database server hosting the Pathfinder process pool
            # database.
            # -------------------- UPDATE HERE ---------------------------------
            dbType = 'db2'
            dbHost = 'BINEAN-SVR01.sunlifecorp.com'
            dbName = 'UDIPPV26'
            dbPort = '20330'
            dsName = 'PathFinder Process Pool Datasource'
            dsJNDIName = 'jdbc/ProcessPoolDataSource'
            transacted = 'false'
            dsHelperClassName = 'com.ibm.websphere.rsadapter.DB2UniversalDataStoreHelper'
            #----------------------------------------------------------------------------
            # Use this property to add custom attributes to the DataSource
            #----------------------------------------------------------------------------
            additionalProperties = []
        class bamLoggingConnection:
            # -------------------- UPDATE HERE ---------------------------------
            # Update these entries with the server name, database name and
            # port of the database server hosting the BamServer database.
            # -------------------- UPDATE HERE ---------------------------------
            dbType = 'db2'
            dbHost = 'BINEAN-SVR01.sunlifecorp.com'
            dbName = 'UDIPPV26'
            dbPort = '20330'
            dsName = 'BAM Logging DataSource'
            dsJNDIName = 'jdbc/BamServerDataSource'
            transacted = 'false'
            dsHelperClassName = 'com.ibm.websphere.rsadapter.DB2UniversalDataStoreHelper'
            #----------------------------------------------------------------------------
            # Use this property to add custom attributes to the DataSource
            #----------------------------------------------------------------------------
            additionalProperties = []
        list = [[processPoolConnection(), providers.DB2(), authenticationAlias.processPoolAlias()],
                [bamLoggingConnection(), providers.DB2(), authenticationAlias.bamLoggingDBAlias()]]
    class jms:
        class bam:
            class factory:
                connectionFactoryName = 'PathFinder-BamserverConnectionFactory'
                connectionFactoryJNDIName = 'jms/BamServerConnectionFactory'
                connectionType = 'Queue'
            class queue:
                queueName = 'PathFinder-BamServerDestination'
                queueJNDIName = 'jms/BamServerDestination'
            class activation:
                mdbName         = 'BamServerMessageProvider'
                mdbJNDIName     = 'jms/BamServerMessageProvider'
                mdbDestType     = 'Queue'
                mdbDestJNDIName = 'jms/BamServerDestination'
                mdbMaxEndPoints = '10'
        class synchronizer:
            class factory:
                connectionFactoryName = 'PathFinder-SynchronizerConnectionFactory'
                connectionFactoryJNDIName = 'jms/SynchronizerConnectionFactory'
                connectionType = 'Topic'
            class topic:
                topicName = 'Pathfinder-SynchronizerDestination'
                topicJNDIName = 'jms/SynchronizerDestination'
            class activation:
                class bamserver:
                    mdbName = 'BamServerSynchronizerProvider'
                    mdbJNDIName = 'jms/BamServerSynchronizerProvider'
                    mdbDestType = 'Topic'
                    mdbDestJNDIName = 'jms/SynchronizerDestination'
                    mdbMaxEndPoints = '1'
                class codeserver:
                    mdbName = 'CodeServerSynchronizerProvider'
                    mdbJNDIName = 'jms/CodeServerSynchronizerProvider'
                    mdbDestType = 'Topic'
                    mdbDestJNDIName = 'jms/SynchronizerDestination'
                    mdbMaxEndPoints = '1'
                class consoleserver:
                    mdbName = 'ConsoleServerSynchronizerProvider'
                    mdbJNDIName = 'jms/ConsoleServerSynchronizerProvider'
                    mdbDestType = 'Topic'
                    mdbDestJNDIName = 'jms/SynchronizerDestination'
                    mdbMaxEndPoints = '1'
                class pathfinder:
                    mdbName = 'PathFinderSynchronizerProvider'
                    mdbJNDIName = 'jms/PathFinderSynchronizerProvider'
                    mdbDestType = 'Topic'
                    mdbDestJNDIName = 'jms/SynchronizerDestination'
                    mdbMaxEndPoints = '1'
                class pagebuilder:
                    mdbName = 'PageBuilderSynchronizerProvider'
                    mdbJNDIName = 'jms/PageBuilderSynchronizerProvider'
                    mdbDestType = 'Topic'
                    mdbDestJNDIName = 'jms/SynchronizerDestination'
                    mdbMaxEndPoints = '1'
        connectionFactoryList = [bam.factory(), synchronizer.factory()]
        queueList = [bam.queue()]
        topicList = [synchronizer.topic()]
        activationSpecList = [bam.activation(), 
                              synchronizer.activation.bamserver(), 
                              synchronizer.activation.codeserver(), 
                              synchronizer.activation.consoleserver(), 
                              synchronizer.activation.pathfinder()]


# --------------------------------------------------------------
# This function will return the string that maps a module to its 
# server.  This will differ based upon whether or not they're
# using the HTTP server or using the server built in to WAS. 
# --------------------------------------------------------------

def getModuleToServerMappingString():
    cellName = websphere.cellName

    if usingCluster():
        nodeName = websphere.webServer.nodeName
        webServer = websphere.webServer.name
        deployType = 'cluster'
        deployTo = websphere.cluster.name
        return 'WebSphere:cell=%s,node=%s,server=%s+WebSphere:cell=%s,node=%s,%s=%s' % \
            (cellName, nodeName, webServer, cellName, nodeName, deployType, deployTo)
    else:
        # If not using a cluster then the string will vary based upon whether or
        # not the IBM HTTP server is being used.

        serverName = websphere.standAlone.serverName

        if websphere.standAlone.useWebServer:
            webServer = websphere.webServer.name
            nodeName = websphere.webServer.nodeName
            deployType = 'server'
            deployTo = serverName
            return 'WebSphere:cell=%s,node=%s,server=%s+WebSphere:cell=%s,node=%s,%s=%s' % \
                (cellName, nodeName, webServer, cellName, nodeName, deployType, deployTo)
        else:
            nodeName = websphere.standAlone.nodeName
            return 'WebSphere:cell=%s,node=%s,server=%s' % (cellName, nodeName, serverName)

# --------------------------------------------------------------
# This function will return 1 if the system is configured to
# use a cluster and 0 if not.
# --------------------------------------------------------------

def usingCluster():
    return websphere.useCluster
