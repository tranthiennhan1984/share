#******************************************************************************
# All right, title and interest in and to the software        
# (the "Software") and the accompanying documentation or      
# materials (the "Documentation"), including all proprietary  
# rights, therein including all patent rights, trade secrets, 
# trademarks and copyrights, shall remain the exclusive       
# property of Hewlett Packard Enterprise Development LP.            
# No interest, license or any right respecting the Software      
# and the Documentation, other than expressly granted in      
# the Software License Agreement, is granted by implication   
# or otherwise.                                               
#                                                            
# (C) Copyright 2010-2016 Hewlett Packard Enterprise Development LP.
# All rights reserved.                                        
#******************************************************************************

import sys, java, javaos

#---------------------------------------------------------------------------
# Add the wsadmin objects to the sys.modules dictionary, this is needed
# so that we can use the objects in modules
#---------------------------------------------------------------------------

WSASobjects = {
    'AdminApp':AdminApp ,
    'AdminConfig':AdminConfig ,
    'AdminControl':AdminControl,
    'Help':Help
    }

if 'AdminTask' in dir():
    WSASobjects['AdminTask'] = AdminTask

sys.modules.update(WSASobjects)
sys.path.append('.')

def main():
    deployPathFinder()
    deployConsoleServer()
    deployBamServer()

    if os.path.exists(pathfinder.applications.webServices.appFileName):
        deployWebServices()

    #---------------------------------------------------------------------------
    # Deploy any administration server specific applications
    #---------------------------------------------------------------------------

    deployAdministrationServerApps()

    print 'INFO: Saving Configuration'
    AdminConfig.save()
    return

#---------------------------------------------------------------------------
# Deploy the Pathfinder application. The addPathFinderDeployOptions(options)
# method in your administration server specific deployment script will be 
# called giving you an opportunity to add any deployment options that are
# unique to your administration server.
#---------------------------------------------------------------------------

def deployPathFinder():
    application = pathfinder.applications.pathFinder

    if not application.deploy:
        return

    print 'INFO: Deploying ' + application.appName

    #---------------------------------------------------------------------------
    # Create a dictionary of options to pass to the AdminConfig.install 
    # command.
    #---------------------------------------------------------------------------

    options = CommandOptions({
        'appname':application.appName,
        'asyncRequestDispatchType':'DISABLED',
        'createMBeansForResources':None,
        'distributeApp':None,
        'filepermission':'.*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755',
        'noallowDispatchRemoteInclude':None,
        'noallowServiceRemoteInclude':None,
        'nodeployejb':None,
        'nodeployws':None,
        'nopreCompileJSPs':None,
        'noprocessEmbeddedConfig':None,
        'noreloadEnabled':None,
        'nouseAutoLink':None,
        'nouseMetaDataFromBinary':None,
        'validateinstall':'warn',
        'MapEJBRefToEJB':[
            'PathFinderEjb.jar PathFinder PathFinderEjb.jar,META-INF/ejb-jar.xml ejb/PathFinderProcessPool com.solcorp.pathfinder.processpool.ProcessPoolLocal ejblocal:ejb/ProcessPoolDataBase',
            '.* .* .* ejb/BamGateway com.solcorp.bamserver.gateway.BAMGateway ejb/BamGateway'
            ],
        'MapModulesToServers':[
            '.* .* ' + getModuleToServerMappingString()
            ],
        'MapRolesToUsers':[
            'pfrole AppDeploymentOption.No AppDeploymentOption.No "" %s AppDeploymentOption.No "" group:defaultWIMFileBasedRealm/cn=%s,o=defaultWIMFileBasedRealm' % (users.pathFinderClient.group, users.pathFinderClient.group),
            'debugrole AppDeploymentOption.No AppDeploymentOption.No "" %s AppDeploymentOption.No "" group:defaultWIMFileBasedRealm/cn=%s,o=defaultWIMFileBasedRealm' % (users.enterpriseDesignerClient.group, users.enterpriseDesignerClient.group),
            'csrole AppDeploymentOption.No AppDeploymentOption.No "" %s AppDeploymentOption.No "" group:defaultWIMFileBasedRealm/cn=%s,o=defaultWIMFileBasedRealm' % (users.consoleServerAdmin.group, users.consoleServerAdmin.group)
            ],
        'MapWebModToVH':[
            '.* .* ' + application.virtualHost
            ],
        'CtxRootForWebMod':[
            '.* .* ' + application.contextRoot
            ],
        'MapEnvEntryForWebMod':[
            '.* .* PathFinder/ConfigFileName .* .* ' + application.configFileName
            ],
        'MapResRefToEJB':[
            'PathFinderEjb.jar ProcessPoolDataBase PathFinderEjb.jar,META-INF/ejb-jar.xml jdbc/ProcessPoolDataSource javax.sql.DataSource %s "" "" ""' % (pathfinder.jdbc.list[0][0].dsJNDIName),
            '.* "" .* jms/SynchronizerConnectionFactory javax.jms.TopicConnectionFactory %s "" "" ""' % (pathfinder.jms.synchronizer.factory.connectionFactoryJNDIName)
            ],
        'BindJndiForEJBBusiness':[
            'CodeServerEjb.jar CodeServer CodeServerEjb.jar,META-INF/ejb-jar.xml com.solcorp.codeserver.ejb.CodeServerRemote ejb/CodeServer',
            'CodeServerEjb.jar CodeServerConsoleBean CodeServerEjb.jar,META-INF/ejb-jar.xml com.solcorp.consoleserver.codeserver.CodeServerConsole ejb/CodeServerConsole',
            'PathFinderEjb.jar ProcessPoolDataBase PathFinderEjb.jar,META-INF/ejb-jar.xml com.solcorp.pathfinder.processpool.ProcessPoolLocal ejblocal:ejb/ProcessPoolDataBase',
            'PathFinderEjb.jar PathFinderDebug PathFinderEjb.jar,META-INF/ejb-jar.xml com.solcorp.pathfinder.debug.PathFinderDebugRemote ejb/PathFinderDebug',
            'PathFinderEjb.jar ProcessPoolCache PathFinderEjb.jar,META-INF/ejb-jar.xml com.solcorp.pathfinder.processpool.ProcessPoolLocal ejblocal:ejb/ProcessPoolCache',
            'PathFinderEjb.jar PathFinder PathFinderEjb.jar,META-INF/ejb-jar.xml com.solcorp.pathfinder.ejb.PathFinderRemote ejb/PathFinder',
            'PathFinderEjb.jar PathFinderConsoleBean PathFinderEjb.jar,META-INF/ejb-jar.xml com.solcorp.consoleserver.pathfinder.PathFinderConsole ejb/PathFinderConsole'
            ],
        'MapMessageDestinationRefToEJB':[
            '.* "" .* jms/SynchronizerDestination ' + pathfinder.jms.synchronizer.topic.topicJNDIName
            ],
        'BindJndiForEJBMessageBinding':[
            'CodeServerEjb.jar CodeServerNotificationListener CodeServerEjb.jar,META-INF/ejb-jar.xml "" %s "" ""' % (pathfinder.jms.synchronizer.activation.codeserver.mdbJNDIName),
            'PathFinderEjb.jar PathFinderNotificationListener PathFinderEjb.jar,META-INF/ejb-jar.xml "" %s "" ""' % (pathfinder.jms.synchronizer.activation.pathfinder.mdbJNDIName)
            ]
        })

    #----------------------------------------------------------------------------
    # If we're using LDAP then we need to map the user roles to groups
    #----------------------------------------------------------------------------

    if websphere.server.security.useldap=='true':	
        ldap = websphere.server.security

        options['MapRolesToUsers'].extend([
            'csrole AppDeploymentOption.No AppDeploymentOption.No "" cn=csgroup,%s AppDeploymentOption.No "" group:%s/cn=csgroup,%s' % (ldap.baseDN, ldap.realmNameLDAP, ldap.baseDN),
            'pfrole AppDeploymentOption.No AppDeploymentOption.No "" cn=pfrole,%s AppDeploymentOption.No "" group:%s/cn=pfrole,%s' % (ldap.baseDN, ldap.realmNameLDAP, ldap.baseDN),
            'debugrole AppDeploymentOption.No AppDeploymentOption.No "" cn=debugrole,%s AppDeploymentOption.No "" group:%s/cn=debugrole,%s' % (ldap.baseDN, ldap.realmNameLDAP, ldap.baseDN)
            ])

    #---------------------------------------------------------------------------
    # If we're deploying PageServer then we need to assign a JNDI name to the 
    # PageServerConsole and ServletConsole. The PageBuilder only implements 
    # ServletConsole.
    #---------------------------------------------------------------------------

    if pathfinder.usePageServer:
        options['BindJndiForEJBBusiness'].extend([
            'PageServerEjb.jar PageServerConsoleBean PageServerEjb.jar,META-INF/ejb-jar.xml com.solcorp.consoleserver.pageserver.PageServerConsole ejb/PageServerConsole',
            'PageServerEjb.jar PageServerConsoleBean PageServerEjb.jar,META-INF/ejb-jar.xml com.solcorp.consoleserver.servlet.ServletConsole ejb/ServletConsole'
            ])
        options['BindJndiForEJBMessageBinding'].extend([
            'PageServerEjb.jar PageServerNotificationListener PageServerEjb.jar,META-INF/ejb-jar.xml "" %s "" ""' % (ingenium.jms.synchronizer.activation.pageserver.mdbJNDIName)
            ])
    else:
        options['BindJndiForEJBBusiness'].extend([
            'PageBuilderEjb.jar PageBuilderConsoleBean PageBuilderEjb.jar,META-INF/ejb-jar.xml com.solcorp.consoleserver.servlet.ServletConsole ejb/ServletConsole'
            ])
        options['BindJndiForEJBMessageBinding'].extend([
            'PageBuilderEjb.jar PageBuilderNotificationListener PageBuilderEjb.jar,META-INF/ejb-jar.xml "" %s "" ""' % (pathfinder.jms.synchronizer.activation.pagebuilder.mdbJNDIName)
            ])

    addPathFinderDeployOptions(options)

    deployApplication(application.appName, application.appFileName, options.getString())

    setAttributes(application.appName, 'deployedObject', [['startingWeight', '3'], ['warClassLoaderPolicy', 'SINGLE']])
    return

#---------------------------------------------------------------------------
# Deploy the ConsoleServer application. The addConsoleServerDeployOptions(options)
# method in your administration server specific deployment script will be 
# called giving you an opportunity to add any deployment options that are
# unique to your administration server.
#---------------------------------------------------------------------------

def deployConsoleServer():
    application = pathfinder.applications.consoleServer

    if not application.deploy:
        return

    print 'INFO: Deploying ' + application.appName

    options = CommandOptions({
        'appname':application.appName,
        'asyncRequestDispatchType':'DISABLED',
        'createMBeansForResources':None,
        'distributeApp':None,
        'filepermission':'.*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755',
        'noallowDispatchRemoteInclude':None,
        'noallowServiceRemoteInclude':None,
        'nodeployejb':None,
        'nodeployws':None,
        'nopreCompileJSPs':None,
        'noprocessEmbeddedConfig':None,
        'noreloadEnabled':None,
        'nouseAutoLink':None,
        'nouseMetaDataFromBinary':None,
        'validateinstall':'warn',
        'MapResRefToEJB':[
            'ConsoleServer "" ConsoleServer.war,WEB-INF/web.xml jms/SynchronizerConnectionFactory javax.jms.TopicConnectionFactory %s "" "" ""' % (pathfinder.jms.synchronizer.factory.connectionFactoryJNDIName)
            ],
        'MapModulesToServers':[
            '.* .* ' + getModuleToServerMappingString()
            ],
        'MapEJBRefToEJB':[
            'ConsoleServer "" ConsoleServer.war,WEB-INF/web.xml ejb/BamServerConsole com.solcorp.consoleserver.bamserver.BamServerConsole ejb/BamServerConsole',
            'ConsoleServer "" ConsoleServer.war,WEB-INF/web.xml ejb/PathFinderConsole com.solcorp.consoleserver.pathfinder.PathFinderConsole ejb/PathFinderConsole',
            'ConsoleServer "" ConsoleServer.war,WEB-INF/web.xml ejb/ServletConsole com.solcorp.consoleserver.servlet.ServletConsole ejb/ServletConsole',
            'ConsoleServer "" ConsoleServer.war,WEB-INF/web.xml ejb/CodeServerConsole com.solcorp.consoleserver.codeserver.CodeServerConsole ejb/CodeServerConsole',
            'ConsoleServerEjb.jar ConsoleServerNotificationListener ConsoleServerEjb.jar,META-INF/ejb-jar.xml ejb/BamServerConsole com.solcorp.consoleserver.bamserver.BamServerConsole ejb/BamServerConsole',
            'ConsoleServerEjb.jar ConsoleServerNotificationListener ConsoleServerEjb.jar,META-INF/ejb-jar.xml ejb/PathFinderConsole com.solcorp.consoleserver.pathfinder.PathFinderConsole ejb/PathFinderConsole',
            'ConsoleServerEjb.jar ConsoleServerNotificationListener ConsoleServerEjb.jar,META-INF/ejb-jar.xml ejb/ServletConsole com.solcorp.consoleserver.servlet.ServletConsole ejb/ServletConsole'
            ],
        'MapWebModToVH':[
            '.* ConsoleServer.war,WEB-INF/web.xml ' + application.virtualHost
            ],
        'CtxRootForWebMod':[
            '.* .* ' + application.contextRoot
            ],
        'MapEnvEntryForWebMod':[
            '.* .* ConsoleServer/UserId .* .* ' + application.userId,
            '.* .* ConsoleServer/Password .* .* ' + application.password
            ],
        'MapMessageDestinationRefToEJB':[
            'ConsoleServer "" ConsoleServer.war,WEB-INF/web.xml jms/SynchronizerDestination ' + pathfinder.jms.synchronizer.topic.topicJNDIName
            ],
        'BindJndiForEJBMessageBinding':[
            'ConsoleServerEjb.jar ConsoleServerNotificationListener ConsoleServerEjb.jar,META-INF/ejb-jar.xml "" %s "" ""' % (pathfinder.jms.synchronizer.activation.consoleserver.mdbJNDIName)
            ],
        'MapRolesToUsers':[
            'csrole AppDeploymentOption.No AppDeploymentOption.No "" %s AppDeploymentOption.No "" group:defaultWIMFileBasedRealm/cn=%s,o=defaultWIMFileBasedRealm' % (users.consoleServerAdmin.group, users.consoleServerAdmin.group) 
            ]
        })

    #---------------------------------------------------------------------------
    # If we're deploying PageServer then we need to add the reference to 
    # PageServerConsole.
    #---------------------------------------------------------------------------
    
    if pathfinder.usePageServer:
        options['MapEJBRefToEJB'].extend([
            'ConsoleServer "" ConsoleServer.war,WEB-INF/web.xml ejb/PageServerConsole com.solcorp.consoleserver.pageserver.PageServerConsole ejb/PageServerConsole'
            ])
        options['MapEJBRefToEJB'].extend([
            'ConsoleServerEjb.jar ConsoleServerNotificationListener ConsoleServerEjb.jar,META-INF/ejb-jar.xml ejb/PageServerConsole com.solcorp.consoleserver.pageserver.PageServerConsole ejb/PageServerConsole'
            ])
	
    #---------------------------------------------------------------------------
    # If we're not using a cluster then disable the refresh function of the
    # ConsoleServer control panel to avoid sending refresh requests to the 
    # server. Refresh is only needed if using a cluster where multiple
    # ConsoleServers could be updating the same environment.
    #---------------------------------------------------------------------------

    if websphere.useCluster == 0:
        options['MapEnvEntryForWebMod'].extend([
        'ConsoleServer ConsoleServer.war,WEB-INF/web.xml ConsoleServer/AutoRefreshingTime Integer "Time interval in milliseconds after which the console control page will check to see if the page should be automatically refreshed. A value of 0 disables the refresh checking." 0'
        ])

    addConsoleServerDeployOptions(options)

    deployApplication(application.appName, application.appFileName, options.getString())

    setAttributes(application.appName, 'deployedObject', [['startingWeight', '7'], ['warClassLoaderPolicy', 'SINGLE']])
    return

#---------------------------------------------------------------------------
# Deploy the BAM server application. The addBAMServerDeployOptions(options)
# method in your administration server specific deployment script will be 
# called giving you an opportunity to add any deployment options that are
# unique to your administration server.
#---------------------------------------------------------------------------

def deployBamServer():
    application = pathfinder.applications.bamServer

    if not application.deploy:
        return

    print 'INFO: Deploying ' + application.appName

    options = CommandOptions({
        'appname':application.appName,
        'asyncRequestDispatchType':'DISABLED',
        'createMBeansForResources':None,
        'distributeApp':None,
        'filepermission':'.*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755',
        'noallowDispatchRemoteInclude':None,
        'noallowServiceRemoteInclude':None,
        'nodeployejb':None,
        'nodeployws':None,
        'nopreCompileJSPs':None,
        'noprocessEmbeddedConfig':None,
        'noreloadEnabled':None,
        'nouseAutoLink':None,
        'nouseMetaDataFromBinary':None,
        'validateinstall':'warn',
        'MapResRefToEJB':[
            'BamServerEjb.jar BamServerMessengerBean BamServerEjb.jar,META-INF/ejb-jar.xml jms/BamServerConnectionFactory javax.jms.QueueConnectionFactory %s "" "" ""' % (pathfinder.jms.bam.factory.connectionFactoryJNDIName),
            #'BamServerEjb.jar BamServerMessageDrivenBean BamServerEjb.jar,META-INF/ejb-jar.xml jdbc/BamServerDataSourceRef javax.sql.DataSource %s "" "" ""' % (pathfinder.jdbc.bamLoggingConnection.dsJNDIName),
            '"Eclipse BIRT Report Viewer" "" %s,WEB-INF/web.xml jdbc/BamServerDataSource javax.sql.DataSource %s "" "" ""' % (application.birtWar, pathfinder.jdbc.bamLoggingConnection.dsJNDIName),
            'bamserver "" BamServerWar.war,WEB-INF/web.xml jms/SynchronizerConnectionFactory javax.jms.TopicConnectionFactory %s "" "" ""' % (pathfinder.jms.synchronizer.factory.connectionFactoryJNDIName)
            #'bamserver "" BamServerWar.war,WEB-INF/web.xml jdbc/BamServerDataSourceRef javax.sql.DataSource %s "" "" ""' % (pathfinder.jdbc.bamLoggingConnection.dsJNDIName),
            ],
        'BindJndiForEJBBusiness':[
            'BamServerEjb.jar BamGatewayBean BamServerEjb.jar,META-INF/ejb-jar.xml com.solcorp.bamserver.gateway.BAMGateway ejb/BamGateway',
            'BamServerEjb.jar BamServerConsoleBean BamServerEjb.jar,META-INF/ejb-jar.xml com.solcorp.consoleserver.bamserver.BamServerConsole ejb/BamServerConsole'
            ],
        'MapModulesToServers':[
            'BamServerEjb.jar BamServerEjb.jar,META-INF/ejb-jar.xml ' + getModuleToServerMappingString(),
            'bamserver BamServerWar.war,WEB-INF/web.xml ' + getModuleToServerMappingString(),
            '"Eclipse BIRT Report Viewer" %s,WEB-INF/web.xml %s' % (application.birtWar, getModuleToServerMappingString())
            ], 
        'MapRolesToUsers':[
            'csrole AppDeploymentOption.No AppDeploymentOption.No "" %s AppDeploymentOption.No "" group:defaultWIMFileBasedRealm/cn=%s,o=defaultWIMFileBasedRealm' % (users.consoleServerAdmin.group, users.consoleServerAdmin.group)
            ],
        'MapWebModToVH':[
            'bamserver BamServerWar.war,WEB-INF/web.xml ' + application.virtualHost,
            '"Eclipse BIRT Report Viewer" %s,WEB-INF/web.xml %s' % (application.birtWar, application.virtualHost)
            ],
        'MapEnvEntryForWebMod':[
            'bamserver BamServerWar.war,WEB-INF/web.xml GatewayLogLogger/GatewayLogFileName .* .* ' + application.gatewayLogFileName,
            'bamserver BamServerWar.war,WEB-INF/web.xml BAMServer/NumberOfDaysToKeepData .* .* ' + application.numberOfDaysToKeepData
            ],
        'CtxRootForWebMod':[
            'bamserver BamServerWar.war,WEB-INF/web.xml ' + application.contextRoot,
            '"Eclipse BIRT Report Viewer" %s,WEB-INF/web.xml  "%s/Reports"' % (application.birtWar, pathfinder.applications.consoleServer.contextRoot)
            ],
        'MapMessageDestinationRefToEJB':[
            'BamServerEjb.jar BamServerMessengerBean BamServerEjb.jar,META-INF/ejb-jar.xml jms/BamServerQueue ' + pathfinder.jms.bam.queue.queueJNDIName,
            'bamserver "" BamServerWar.war,WEB-INF/web.xml jms/SynchronizerDestination ' + pathfinder.jms.synchronizer.topic.topicJNDIName
            ],
        'BindJndiForEJBMessageBinding':[
            'BamServerEjb.jar BamServerMessageDrivenBean BamServerEjb.jar,META-INF/ejb-jar.xml "" %s "" ""' % (pathfinder.jms.bam.activation.mdbJNDIName),
            'BamServerEjb.jar BamServerNotificationListener BamServerEjb.jar,META-INF/ejb-jar.xml "" %s "" ""' % (pathfinder.jms.synchronizer.activation.bamserver.mdbJNDIName)
            ]
        })

    #----------------------------------------------------------------------------
    # If we're using LDAP then we need to map the user roles to groups
    #----------------------------------------------------------------------------

    if websphere.server.security.useldap=='true':	
        ldap = websphere.server.security

        options['MapRolesToUsers'].extend([
            'csrole AppDeploymentOption.No AppDeploymentOption.No "" cn=csgroup,%s AppDeploymentOption.No "" group:%s/cn=csgroup,%s' % (ldap.baseDN, ldap.realmNameLDAP, ldap.baseDN)
            ])

    addBAMServerDeployOptions(options)

    deployApplication(application.appName, application.appFileName, options.getString())

    setAttributes(application.appName, 'deployedObject', [['startingWeight', '1'], ['warClassLoaderPolicy', 'SINGLE']])
    return

#---------------------------------------------------------------------------
# Deploy the web services. The addWebServiceDeployOptions(options)
# method in your administration server specific deployment script will be 
# called giving you an opportunity to add any deployment options that are
# unique to your administration server.
#---------------------------------------------------------------------------

def deployWebServices():
    application = pathfinder.applications.webServices

    if not application.deploy:
        return

    print 'INFO: Deploying ' + application.appName

    options = CommandOptions({
        'appname':application.appName,
        'asyncRequestDispatchType':'DISABLED',
        'createMBeansForResources':None,
        'distributeApp':None,
        'filepermission':'.*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755',
        'noallowDispatchRemoteInclude':None,
        'noallowServiceRemoteInclude':None,
        'nodeployejb':None,
        'nodeployws':None,
        'nopreCompileJSPs':None,
        'noprocessEmbeddedConfig':None,
        'noreloadEnabled':None,
        'nouseAutoLink':None,
        'nouseMetaDataFromBinary':None,
        'validateinstall':'warn',
        'MapEJBRefToEJB':[
            '.* "" .* ejb/PathFinder com.solcorp.pathfinder.ejb.PathFinderRemote ejb/PathFinder',
            '.* "" .* ejb/BamGateway com.solcorp.bamserver.gateway.BAMGateway ejb/BamGateway'
            ],
        'MapModulesToServers':[
            '.* .* ' + getModuleToServerMappingString(),
            ],
        'MapWebModToVH':[
            '.* .* ' + application.virtualHost,
            ],
        'MapEnvEntryForWebMod':[
            '.* .* WebService/PathFinderUserId .* "" ' + application.userId,
            '.* .* WebService/PathFinderUserPassword .* "" ' + application.password
            ]
        })

    addWebServiceDeployOptions(options)

    deployApplication(application.appName, application.appFileName, options.getString())

    setAttributes(application.appName, 'deployedObject', [['startingWeight', '5']])
    return

#---------------------------------------------------------------------------
# Main entry point
#---------------------------------------------------------------------------

if (__name__ == '__main__'):
    print 'INFO: Starting Pathfinder deployment'

    from ibmfixes import *
    from utilityFunctions import *
    from serverConfiguration import *

    serverConfigurationScript = getEnvironmentVariable('SERVER_CONFIGURATION_SCRIPT')
    print 'INFO: Importing the administration server configuration script ' + serverConfigurationScript
    exec 'from ' + serverConfigurationScript + ' import *'

    serverDeployScript = getEnvironmentVariable('SERVER_DEPLOY_SCRIPT')
    print 'INFO: Importing the administration server deploy script ' + serverDeployScript
    exec 'from ' + serverDeployScript + ' import *'

    main()
else:
    print 'ERROR: Entry main not found - script aborts'

