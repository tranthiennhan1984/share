#******************************************************************************
# All right, title and interest in and to the software        
# (the "Software") and the accompanying documentation or      
# materials (the "Documentation"), including all proprietary  
# rights, therein including all patent rights, trade secrets, 
# trademarks and copyrights, shall remain the exclusive       
# property of Hewlett Packard Enterprise Development LP.            
# No interest, license or any right respecting the Software      
# and the Documentation, other than expressly granted in      
# the Software License Agreement, is granted by implication   
# or otherwise.                                               
#                                                            
# (C) Copyright 2010-2016 Hewlett Packard Enterprise Development LP.
# All rights reserved.                                        
#******************************************************************************

import sys, java, javaos

#---------------------------------------------------------------------------
# This is a fix to workaround a bug in the version of Jython shipped
# with WAS. Any Windows OS newer than XP isn't recognized as being
# Windows so it assumes that it's posix and tries to run a sh command to
# get the environment.
#---------------------------------------------------------------------------

try:
    if javaos._osType == 'posix' and java.lang.System.getProperty('os.name').startswith('Windows'):
        sys.registry.setProperty('python.os', 'nt')
        reload(javaos)
except:
    pass
