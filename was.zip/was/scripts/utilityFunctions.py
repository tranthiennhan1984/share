#******************************************************************************
# All right, title and interest in and to the software
# (the 'Software') and the accompanying documentation or
# materials (the 'Documentation'), including all proprietary
# rights, therein including all patent rights, trade secrets,
# trademarks and copyrights, shall remain the exclusive
# property of Hewlett Packard Enterprise Development LP.
# No interest, license or any right respecting the Software
# and the Documentation, other than expressly granted in
# the Software License Agreement, is granted by implication
# or otherwise.
#
# (C) Copyright 2010-2016 Hewlett Packard Enterprise Development LP.
# All rights reserved.
#******************************************************************************

import sys
from java.lang import System
import AdminConfig, AdminControl, AdminApp, Help
import java
import os
from UserDict import UserDict

try:
    import AdminTask
except:
    print 'ERROR: Required WebSphere Administrative object missing: AdminTask'
    sys.exit(-1)

lineSeparator = java.lang.System.getProperty('line.separator')

# ------------------------------------------------------------------------------
# This function will remove a application server
# ------------------------------------------------------------------------------
def removeServer(nodeName, serverName):
    serverId = AdminConfig.getid('/Node:' + nodeName + '/Server:' + serverName + '/')
    if (len(serverId) == 0):
        print 'INFO: Could not locate server ' + serverName + ' at node ' + nodeName
    else:
        print 'INFO: Removing server ' + serverName
        AdminConfig.remove(serverId)

    return

# ------------------------------------------------------------------------------
# This function enable/disable security on the cell or at the server
# if security is enabled at the server level, we need to provide a security
# template as this doc is not created by default in websphere
# ------------------------------------------------------------------------------
def setSecurity(state, cellName=None, nodeName=None, serverName=None):
    if (state != 'true') and (state != 'false'):
        print 'ERROR: Invalid Security state specified : ' + state + '(can only be true/false)'
        return

    if (cellName is not None) and (nodeName is not None) and (serverName is not None):
        print 'INFO: Enabling security at the Server Level'
        secDoc = 'cells/' + cellName + '/nodes/' + nodeName + '/servers/' + serverName + '/security.xml'
        secDocTemplate = 'security.xml'
        if not os.path.exists(secDocTemplate):
            print 'ERROR: Could not locate security document template ' + secDocTemplate + ', security not set.'
            return

        #Check if the security.xml exists
        if (AdminConfig.existsDocument(secDoc) == 0):
            AdminConfig.createDocument(secDoc, secDocTemplate)

        # get the id of the document and modify it
        serverId = AdminConfig.getid('/Cell:' + cellName + '/Node:' + nodeName + '/Server:' + serverName + '/Security:/')
        if (len(serverId) == 0):
            print 'ERROR: Could not locate security scope for server ' + serverName + ' at node ' + nodeName
            return
        else:
            AdminConfig.modify(serverId, [['enforceJava2Security', state]])
    else:
        print 'INFO: Enabling security at the Cell Level'
        security = AdminConfig.list('Security')
        if (security != ''):
            AdminConfig.modify(security, [['enforceJava2Security', state]])
        else:
            print 'ERROR: Could not get Security object'
    return

# -------------------------------------------------------------------------
# This function will return the scope want to work with
# -------------------------------------------------------------------------
def getScope(nodeName=None, serverName=None, clusterName=None):
    scope = None
    if (clusterName is not None):
        ourScope = '/ServerCluster:' + clusterName + '/'
        scope = AdminConfig.getid(ourScope)
    elif((nodeName is not None) and (serverName is not None)):
        ourScope = '/Node:' + nodeName + '/Server:' + serverName + '/'
        scope = AdminConfig.getid(ourScope)
    elif (serverName is None):
        ourScope = '/Node:' + nodeName + '/'
        scope = AdminConfig.getid(ourScope)

    if ((scope is None) or (scope == '')):
        print 'ERROR: Unable to locate the scope.  Check the server and node name.'
        sys.exit()

    if (len(scope) == 0):
        print 'ERROR: Error getting scope for nodeName=' + nodeName + ', serverName=' + serverName
        sys.exit()

    return scope

# -------------------------------------------------------------------------
# Get the value of an environment variable.
# -------------------------------------------------------------------------
def getEnvironmentVariable(variableName):
    try:
        return os.environ[variableName]
    except:
        return ''


def changeJvmProperties(message, serverName, attrList, property=None):
    print 'INFO: ' + message
    jvmId = AdminConfig.getid('/Server:' + serverName + '/JavaProcessDef:/JavaVirtualMachine:/')

    if (property is not None):
        jvmProps = AdminConfig.showall(jvmId)
        jvmProps_list = jvmProps.split(lineSeparator)
        search_str = 'name ' + property

        print 'INFO: Searching for property : ' + property
        property = None
        for i in jvmProps_list:
            if i.find(search_str) > 0:
                property = i
                print 'INFO: Property ' + property + ' already exists'
                break

    if property is None:
        AdminConfig.modify(jvmId, [attrList])

    return

# -----------------------------------------------------------
# Creates new properties for the JVM inside a Application
# Server
# Note that the attribute list has to be setup properly for example
#
#    name        = ['name', ['java.security.policy']]
#    value       = ['value', '/projects/ingenium70/pr/presentation/java.policy']
#    description = ['description', ['Pathfinder Security Policy']]
#    property1   = [name, value, description]
#
#    attrList = [property1]
# -----------------------------------------------------------

def createJvmProperty(nodeName, serverName, attrList):
    jvmId = AdminConfig.getid('/Node:%s/Server:%s/JavaProcessDef:/JavaVirtualMachine:/' % (nodeName, serverName))
    AdminConfig.create('Property', jvmId, attrList)
    return

# -----------------------------------------------------------
#  Delete a SIB Bus
# -----------------------------------------------------------

def deleteBus(busName, nodeName=None):
    if (nodeName is None) :
        print 'ERROR: Invalid node/server name.'
        sys.exit()

    # First check if the bus exists
    installedBusName = None
    busEntries = AdminConfig.list('SIBus')
    if (busEntries != ''):
        busEntryList = busEntries.split(lineSeparator)
        for busEntry in busEntryList:
            entry = AdminConfig.showAttribute(busEntry, 'name')
            if (entry == busName):
                installedBusName = busEntry
                break
            else:
                print 'INFO: Bus ' + busName + ' does not exist'
    else:
        print 'INFO: Bus ' + busName + ' does not exist'

    if (installedBusName is not None):
        print 'INFO: Deleting the Bus ' + busName

        deleteBusDestinations(busName)

        AdminTask.deleteSIBus(['-bus', busName])

    return

#end def

# -----------------------------------------------------------
#  Delete all BUS destinations
# -----------------------------------------------------------
def deleteBusDestinations(busName):
    destDoc = AdminTask.listSIBDestinations('-bus ' + busName + ' -type Queue')

    if destDoc == '':
        return

    destList = destDoc.split(lineSeparator)

    for dest in destList:
        destName = AdminConfig.showAttribute(dest, 'identifier')
        # Make sure to not delete the System destination
        if destName.find('_SYSTEM') == -1 :
            print 'INFO: Deleting destination: ' + destName
            AdminTask.deleteSIBDestination('-bus ' + busName + ' -name ' + destName)
        #end if
    #end for

    return
#end def

# -----------------------------------------------------------
#  Create a SIB Bus
# -----------------------------------------------------------
def createBus(busName, nodeName=None, secure=None):
    print 'INFO: Creating the bus ' + busName

    if (nodeName is None) :
        print 'ERROR: invalid node/server name '
        sys.exit()

    # First delete the bus if it already exists
    deleteBus(busName, nodeName)

    if secure is None:
        bus = ['-bus', busName]
    else:
         bus = ['-bus', busName, '-secure', secure]

    AdminTask.createSIBus(bus)

    return

# -----------------------------------------------------------
# Add a SIB Bus Member with the DataStore Option
# -----------------------------------------------------------
def addBusMemberDataStore(busName, nodeName, serverName, sib_authAlias, sib_schemaName, sib_jndiName):
    print 'INFO: Adding bus member to datastore ' + busName

    # Now add the member
    busMember = None

    busMembers = AdminTask.listSIBusMembers('-bus ' + busName)

    if (len(busMembers) != 0):
        bmsplit = busMembers.split(lineSeparator)
        for busM in bmsplit:
            busMemberName = AdminConfig.showAttribute(busM, 'server')
            if (busMemberName == serverName):
                print 'INFO: Server ' + serverName + ' is already a member'
                busMember = busM
                break

    if (busMember is None):
        # datastore, we assume that the alias and jdbc provider have been created earlier
        #' -dataStore -createTables true -authAlias ' + sib_authAlias
        print 'INFO:  DataStore filestore configured'
        addMember = '[-bus ' + busName + ' -node ' + nodeName + ' -server ' + serverName + \
            ' -dataStore -createDefaultDatasource FALSE -createTables true -authAlias ' + sib_authAlias + \
            ' -schemaName ' + sib_schemaName + ' -datasourceJndiName ' + sib_jndiName + ']'

        AdminTask.addSIBusMember(addMember)

    return

# -----------------------------------------------------------
# Add a SIB Bus Member with the FileStore Option
# -----------------------------------------------------------
def addBusMemberFileStore(busName, nodeName, serverName, clusterName, ME_Options=None):
    # Now add the member
    busMember = None

    args = '-bus ' + busName
    busMembers = AdminTask.listSIBusMembers(args)

    if (len(busMembers) != 0):
        bmsplit = busMembers.split(lineSeparator)
        for busM in bmsplit:
            busMemberName = AdminConfig.showAttribute(busM, 'server')
            if (busMemberName == serverName):
                print 'INFO: Server ' + serverName + ' is already a member'
                busMember = busM
                break

    if (busMember is None):
        # Add the member
        if (clusterName is not None):
            print 'INFO: Adding cluster member ' + clusterName
        else:
            print 'INFO: Adding bus member ' + serverName

        if (ME_Options is None):  # default filestore
            if (clusterName is not None):
                print 'ERROR: Log details have to be set when adding a cluster as Member'
            else:
                addMember = '[-bus ' + busName + ' -node ' + nodeName + ' -server ' +  serverName + ']'
        else:
            print 'INFO: log details  configured'
            if (clusterName is not None):
                addMember = '[-bus ' + busName + ' -cluster ' + clusterName
            else:
                addMember = '[-bus ' + busName + ' -node ' + nodeName + ' -server ' + serverName


            addMember = addMember + \
            ' -enableAssistance '            + ME_Options['enableAssistance'] + \
            ' -policyName '                  + ME_Options['policyName'] + \
            ' -fileStore ' + \
            ' -logSize '                     + ME_Options['logSize'] + \
            ' -logDirectory '                + ME_Options['logDirectory'] + \
            ' -minPermanentStoreSize '       + ME_Options['minPermanentStoreSize'] + \
            ' -unlimitedPermanentStoreSize ' + ME_Options['unlimitedPermanentStoreSize'] + \
            ' -maxPermanentStoreSize '       + ME_Options['maxPermanentStoreSize'] + \
            ' -permanentStoreDirectory '     + ME_Options['permanentStoreDirectory'] + \
            ' -minTemporaryStoreSize '       + ME_Options['minTemporaryStoreSize'] + \
            ' -unlimitedTemporaryStoreSize ' + ME_Options['unlimitedTemporaryStoreSize'] + \
            ' -maxTemporaryStoreSize '       + ME_Options['maxTemporaryStoreSize'] + \
            ' -temporaryStoreDirectory '     + ME_Options['temporaryStoreDirectory'] +']'

        AdminTask.addSIBusMember(addMember)

    return

# ------------------------------------------------------------------
# This function will create a messaging engine on the Bus
# This is only needed in a cluster.
# ------------------------------------------------------------------
def addMessagingEngineWithFileStore (busName, clusterName=None, ME_Options=None):
    print 'INFO: adding Messaging engine to bus ' + busName
    # First check and then if needed create the bus
    busExists = None
    busEntries = AdminConfig.list('SIBus')
    if (busEntries != ''):
        busEntryList=busEntries.split(lineSeparator)
        for busEntry in busEntryList:
            entry =  AdminConfig.showAttribute(busEntry, 'name')
            if (entry == busName):
                print 'INFO: Bus ' + busName + ' already exists'
                busExists = entry
                break
            else:
                busExists = None

    if (busExists is None):
        print 'ERROR - bus ' + busName + ' does not exist.'
        sys.exit(1)

    if (clusterName is not None):
        engineOpts = '-bus ' + busName + ' -cluster ' + clusterName
    else:
        engineOpts = '-bus ' + busName

    engineOpts = engineOpts + \
                ' -fileStore ' + \
                ' -logSize '                     + ME_Options['logSize'] + \
                ' -logDirectory '                + ME_Options['logDirectory'] + \
                ' -minPermanentStoreSize '       + ME_Options['minPermanentStoreSize'] + \
                ' -unlimitedPermanentStoreSize ' + ME_Options['unlimitedPermanentStoreSize'] + \
                ' -maxPermanentStoreSize '       + ME_Options['maxPermanentStoreSize'] + \
                ' -permanentStoreDirectory '     + ME_Options['permanentStoreDirectory'] + \
                ' -minTemporaryStoreSize '       + ME_Options['minTemporaryStoreSize'] + \
                ' -unlimitedTemporaryStoreSize ' + ME_Options['unlimitedTemporaryStoreSize'] + \
                ' -maxTemporaryStoreSize '       + ME_Options['maxTemporaryStoreSize'] + \
                ' -temporaryStoreDirectory '     + ME_Options['temporaryStoreDirectory'] +']'

    AdminTask.createSIBEngine(engineOpts)

    return


# -----------------------------------------------------------------------
# This procedure will create the destinations on the Bus
# the type argument is either 'Queue' or 'TopicSpace'
# -----------------------------------------------------------------------
def createBusDestination(nodeName, serverName, clusterName, busName, destination, destType):
    arg = '-bus ' + busName + ' -type ' + destType
    destDoc = AdminTask.listSIBDestinations(arg)

    destList = destDoc.split(lineSeparator)

    destExists = None
    for destName in destList:
        name = AdminConfig.showAttribute(destName, 'identifier')
        if (name == destination):
            destExists = name
            print 'INFO: destination ' + destination + ' already exists'
            break

    if (destExists is None):
        if (clusterName is not None):
            print 'INFO: Creating Bus Destination (for cluster)' + destination
            arg = '-cluster ' + clusterName + ' -bus ' + busName + ' -name ' + destination + ' -type ' + destType
        else:
            print 'INFO: Creating Bus Destination ' + destination
            arg = '-node ' + nodeName + ' -server ' + serverName + ' -bus ' + busName + ' -name ' + destination + ' -type ' + destType

        AdminTask.createSIBDestination(arg)
    return

# -----------------------------------------------------------------------
#This procedure will create a JAAS Authentication Alias for a security 
#domain if the Alias already exists it will delete it
# -----------------------------------------------------------------------
def configureSecurityDomainAuthenticationAlias(domainName, authAliasName, userId, password):
    print 'INFO: Creating Security Domain JAAS Authentication Alias: ' + authAliasName
    
    authDataEntry = AdminTask.listAuthDataEntries('-securityDomainName %s' % (domainName))
    
    if (authDataEntry.find(authAliasName) > 0):
        AdminTask.deleteAuthDataEntry('-securityDomainName %s -alias %s' % (domainName, authAliasName))
    #end if
    
    AdminTask.createAuthDataEntry('-securityDomainName %s -alias %s -user %s -password %s' % (domainName, authAliasName, userId, password))
    AdminTask.addTrustedRealms('[-securityDomainName %s -communicationType inbound -realmList defaultWIMFileBasedRealm]' % (domainName))  
    AdminTask.listTrustedRealms('[-securityDomainName %s -communicationType inbound]' % (domainName))  
    
    return
#end def

# -----------------------------------------------------------------------
#This procedure will create a JAAS Authentication  Alias
#if the Alias already exists it will just ignore
#creation
# -----------------------------------------------------------------------
def configureAuthenticationAlias(cellName, authAliasName, userId, password):
    print 'INFO: Creating JAAS Authentication Alias: ' + authAliasName

    # Create Authorization Data at the cell level
    security = AdminConfig.getid('/Cell:' + cellName + '/Security:/')

    jaasEntries = AdminConfig.list('JAASAuthData', security)

    if (len(jaasEntries) != 0):
        jaasEntriesList = jaasEntries.split(lineSeparator)
        for eachJaasEntry in jaasEntriesList:
            entryAlias = AdminConfig.showAttribute(eachJaasEntry, 'alias')
            if (entryAlias == authAliasName):
                print 'INFO: Deleting existing authentication alias ' + authAliasName
                AdminConfig.remove(eachJaasEntry)
                break

    jaasAttrs = [['alias', authAliasName], ['userId', userId], ['password', password]]
    Alias = AdminConfig.create('JAASAuthData', security, jaasAttrs)
    return

# --------------------------------------------------------------------------
# This procedure will create a JDBC datasource, if the datasource exists
# it will ignore creating it.
# --------------------------------------------------------------------------

def configureJDBCDataSource(nodeName, serverName, clusterName, scope, provider, connectionProperties, authAliasName):
    print 'INFO: Creating JDBC DataSource ' + connectionProperties.dsName

    # Set Datasource properties
    statementCacheSize = 60

    # Set Connection pool properties
    connectionTimeout = 1800
    maxConnections = 50
    minConnections = 1
    reapTime = 180
    unusedTimeout = 1800
    agedTimeout = 0

    # ----------------------------------------------------------------------------------------
    # Check if the datasource exists
    # ----------------------------------------------------------------------------------------

    dataSource = None
    dataSourceEntries = AdminConfig.list('DataSource', scope)
    if (dataSourceEntries != ''):
        dataSourceEntryList = dataSourceEntries.split(lineSeparator)

        for dataSourceEntry in dataSourceEntryList:
            thisDataSourceEntry = AdminConfig.showAttribute(dataSourceEntry, 'name')
            if (connectionProperties.dsName == thisDataSourceEntry):
                print 'INFO: DataSource ' + connectionProperties.dsName + ' already exists'
                dataSource = dataSourceEntry
                break
            else:
                dataSource = None
    else:
        dataSource = None

    # If the DataSource does not exist, create a new one

    if (dataSource is None):
        if (connectionProperties.dbType.lower() == 'db2'):
            dataSourceDescription = 'Pathfinder DB2 JDBC Datasource'
        elif (connectionProperties.dbType.lower() == 'oracle'):
            dataSourceDescription = 'Pathfinder Oracle JDBC Datasource'

        datasource = AdminConfig.create('DataSource', provider, [
            ['name', connectionProperties.dsName], 
            ['description', dataSourceDescription]
            ])

        print 'INFO: Adding custom properties'

        propertySet = AdminConfig.create('J2EEResourcePropertySet', datasource, [])

        if (connectionProperties.dbType.lower() == 'db2'):
            AdminConfig.create('J2EEResourceProperty', propertySet, [
                ['name', 'driverType'],
                ['type', 'java.lang.Integer'],
                ['value', '4']
                ])

            AdminConfig.create('J2EEResourceProperty', propertySet, [
                ['name', 'serverName'],
                ['type', 'java.lang.String'],
                ['value', connectionProperties.dbHost]
                ])

            # DB2 on AS/400 doesn't need or define a dbPort or dbName attribute.

            if hasattr(connectionProperties, 'dbPort'):
                AdminConfig.create('J2EEResourceProperty', propertySet, [
                    ['name', 'portNumber'], 
                    ['type', 'java.lang.Integer'],
                    ['value', connectionProperties.dbPort]
                    ])

            if hasattr(connectionProperties, 'dbName'):
                AdminConfig.create('J2EEResourceProperty', propertySet, [
                    ['name', 'databaseName'], 
                    ['type', 'java.lang.String'],
                    ['value', connectionProperties.dbName]
                    ])
        elif (connectionProperties.dbType.lower() == 'oracle'):
            AdminConfig.create('J2EEResourceProperty', propertySet, [
                ['name', 'URL'],
                ['type', 'java.lang.String'],
                ['value', 'jdbc:oracle:thin:@%s:%s:%s' % (
                    connectionProperties.dbHost,
                    connectionProperties.dbPort,
                    connectionProperties.dbName)]
                ])

        # Adding custom properties to the new DataSource

        for prop in connectionProperties.additionalProperties:
            AdminConfig.create('J2EEResourceProperty', propertySet, [
                ['name', prop[0]],
                ['type', prop[2]],
                ['value', prop[1]]
                ])

        if connectionProperties.transacted.lower() == 'false':
            AdminConfig.create('J2EEResourceProperty', propertySet, [
                ['name', 'nonTransactionalDataSource'],
                ['type', 'java.lang.String'],
                ['value', 'true']
                ])

        AdminConfig.modify(datasource, [
            ['jndiName', connectionProperties.dsJNDIName],
            ['statementCacheSize', statementCacheSize],
            ['authDataAlias', authAliasName],
            ['datasourceHelperClassname', connectionProperties.dsHelperClassName]
            ])

        print 'INFO: Creating connection pool'

        connectionPool = AdminConfig.create('ConnectionPool', datasource, [
            ['connectionTimeout', connectionTimeout],
            ['maxConnections', maxConnections],
            ['minConnections', minConnections],
            ['reapTime', reapTime],
            ['unusedTimeout', unusedTimeout],
            ['agedTimeout', agedTimeout]
            ])

        # Needed for Radience Connection Pool
        # dataSource = AdminConfig.getid('/DataSource:' + connectionProperties.dsName)
        # cp = AdminConfig.showAttribute(dataSource, 'connectionPool')

        AdminConfig.modify(connectionPool, [['properties', [[
            ['name', 'SetBigStringTryClob'],
            ['value', 'true'],
            ['description', 'Needed for Clobs']
            ]]]])

        # Create ra adapter reference, we do this based on the nodename and servername
        # args passed to us, if both of them are None we assume its a cell scope, if
        # both args are passed we assume its server scope otherwise its node scope.

        if ((nodeName is None) and (serverName is None) and (clusterName is None)):  # Cell Scope
            # figure out what cell we're in
            cell = AdminConfig.list('Cell')
            if (cell == ''):
                print 'ERROR: Cell is not available.'
                print 'ERROR: This script assumes that there is one and only one cell available.'
                print 'ERROR: Script execution stopped.'
                sys.exit(-1)
            else:
                cellName = AdminControl.getCell()

            adapterName = '/Cell:' + cellName + '/J2CResourceAdapter:WebSphere Relational Resource Adapter/'
        elif (clusterName is not None): # Cluster Scope
            adapterName = '/ServerCluster:' + clusterName +  '/J2CResourceAdapter:WebSphere Relational Resource Adapter/'
        elif ((nodeName is not None) and (serverName is not None)):   # Server Scope
            adapterName = '/Node:' + nodeName + '/Server:' + serverName + '/J2CResourceAdapter:WebSphere Relational Resource Adapter/'
        elif ((nodeName is not None) and (serverName is None)):  # Node Scope
            adapterName = '/Node:' + nodeName + '/J2CResourceAdapter:WebSphere Relational Resource Adapter/'
        else:
            print 'ERROR: Invalid arguments for RA adapter'
            sys.exit(-1)

        radapter = AdminConfig.getid(adapterName)
        if (len(radapter) <= 0):
            print 'ERROR: Could not get reference to ra adapter ' + adapterName
            sys.exit(-1)
    return

# ---------------------------------------------------------------------
# Creates a JMS Connection factory of Topic or Queue depending on the
# args passed.
# JmsType should be 'Queue' or 'Topic'
# ---------------------------------------------------------------------
def createJMSConnectionFactory(scope, CFname, CFjndiName, JmsType, BusName):
    print 'INFO: Creating JMS Connection Factory ' + CFname

    ConnectionFactory = None
    j2cFactory = AdminConfig.list('J2CConnectionFactory', scope)
    j2cFactoryList = j2cFactory.split(lineSeparator)

    for j2cFactory in j2cFactoryList:
        if len(j2cFactory) == 0:
            continue
        factoryName = AdminConfig.showAttribute(j2cFactory, 'name')
        if (CFname == factoryName):
            print 'INFO: JMS Connection Factory ' + CFname + ' already exists'
            ConnectionFactory = j2cFactory
            break

    if (ConnectionFactory is  None):
        addTopicFactory = '[-name ' + CFname + ' -jndiName ' + CFjndiName + ' -busName ' + BusName + ' -type ' + JmsType + ']'
        AdminTask.createSIBJMSConnectionFactory(scope, addTopicFactory)

    return

# ---------------------------------------------------------------------
# Creates a Topic
# ---------------------------------------------------------------------
def createTopic(scope, topicName, topicJNDIName, busName):
    print 'INFO: Creating Topic Destination ' + topicName

    topicList = AdminTask.listSIBJMSTopics(scope)

    if (len(topicList) != 0):
        topicListEntries = topicList.split(lineSeparator)

        for eachTopicEntry in topicListEntries:
            thisTopic = AdminConfig.showAttribute(eachTopicEntry, 'name')
            if (topicName == thisTopic):
                print 'INFO: Deleting existing topic ' + topicName
                AdminTask.deleteSIBJMSTopic(eachTopicEntry)
                break

    addTopic = '[-name ' + topicName + ' -jndiName ' + topicJNDIName + ' -topicSpace Default.Topic.Space -busName ' + busName + ']'
    AdminTask.createSIBJMSTopic(scope, addTopic)

    return


# ---------------------------------------------------------------------
# Creates a Activation spec
# ---------------------------------------------------------------------
def createActivationSpec(scope, ASname, ASjndiName, destinationJndiName, maxConcurrency, busName, destinationType):
    print 'INFO: Adding activation entry ' + ASname + ' of type ' + destinationType

    # scope format -> '/Node:jupiterNode01/Server:PathFinderServer/J2CResourceAdapter:SIB JMS Resource Adapter'

    adapter = AdminConfig.getid(scope)

    if (len(adapter) == 0):
        print 'ERROR: Could not get scope for Activation Entry, scope: ' + scope
        sys.exit()


    J2CActivationSpecEntries = AdminConfig.list('J2CActivationSpec', adapter)

    ActivationEntry = None
    if (len(J2CActivationSpecEntries) != 0):   #only if entries found search list
        J2CActivationSpecEntriesList = J2CActivationSpecEntries.split(lineSeparator)
        for eachEntry in J2CActivationSpecEntriesList:
            entry = AdminConfig.list('J2CActivationSpec', eachEntry)
            name = AdminConfig.showAttribute(entry, 'name')
            if (ASname == name):
                ActivationEntry = entry
                print 'INFO: Activation Entry ' + ASname + ' already exists'
                break
            else:
                ActivationEntry = None

    if (ActivationEntry is None):
        activationSpecifications = '[-name ' + ASname + ' -jndiName ' + ASjndiName + ' -destinationJndiName ' + destinationJndiName + ' -busName ' + busName + ' -destinationType ' + destinationType + ' -maxConcurrency ' + maxConcurrency + ']'
        AdminTask.createSIBJMSActivationSpec(adapter, activationSpecifications)

    return

# ---------------------------------------------------------------------
# Create a Queue
# ---------------------------------------------------------------------
def createQueue(scope, name, queueName, queueJNDIName, busName):
    print 'INFO: Creating queue ' + name

    queueList = AdminTask.listSIBJMSQueues(scope)

    if (len(queueList) != 0):
        queueListEntries = queueList.split(lineSeparator)

        for eachQueueEntry in queueListEntries:
          thisQueue = AdminConfig.showAttribute(eachQueueEntry, 'name')
          if (name == thisQueue):
              print 'INFO: Deleting existing queue ' + name
              AdminTask.deleteSIBJMSQueue(eachQueueEntry);
              break

    addQueue = '[-name ' + name + ' -queueName ' + queueName + ' -jndiName ' + queueJNDIName + ' -busName ' + busName + ']'
    AdminTask.createSIBJMSQueue(scope, addQueue)

    return

# ---------------------------------------------------------------------
# Creates a new activation specs for Websphere MQ
# ---------------------------------------------------------------------
def createMQActivationSpecs(scope, connection, activation, aliasId):
    print 'INFO: Creating Activation Specs ' + activation.name

    activationList = AdminTask.listWMQActivationSpecs(scope)

    if (len(activationList) != 0):
        activationListEntries = activationList.splitlines()

        for activationEntry in activationListEntries:
            activationName = AdminConfig.showAttribute(activationEntry, 'name')
            if (activation.name == activationName):
                print 'INFO: Deleting existing activation specs ' + activationName
                AdminTask.deleteWMQActivationSpec(activationEntry)
                break
            #end if
        #end for
    #end if

    addActivation = '[ -name %s -jndiName %s -destinationJndiName %s -destinationType %s -qmgrName %s\
                    -wmqTransportType %s -qmgrHostname %s -qmgrPortNumber %s -qmgrSvrconnChannel %s -maxPoolSize %s -authAlias %s]' %\
                    (activation.name, activation.jndiName, activation.destJNDIName, activation.destType, connection.queueManager,\
                    connection.ttype, connection.hostname, connection.port, connection.channel, activation.maxEndPoints, aliasId)
    AdminTask.createWMQActivationSpec(scope, addActivation)
    return
#end def

# ---------------------------------------------------------------------
# Creates a queue for Websphere MQ
# ---------------------------------------------------------------------
def createMQQueue(scope, connectionFactory, queue):
    print 'INFO: Creating Queue Destination ' + queue.name

    queueList = AdminTask.listWMQQueues(scope)
    if (len(queueList) != 0):
        queueListEntries = queueList.splitlines()

        for queueEntry in queueListEntries:
            queueName = AdminConfig.showAttribute(queueEntry, 'name')
            if (queue.name == queueName):
                print 'INFO: Deleting existing queue ' + queueName
                AdminTask.deleteWMQQueue(queueEntry)
                break

    if hasattr(queue, 'options'):
        options = queue.options
    else:
        options = ''

    addQueue = '[-name %s -jndiName %s -queueName %s -qmgr %s %s]' % (queue.name, queue.jndiName, queue.queueName, connectionFactory.queueManager, options)
    AdminTask.createWMQQueue(scope, addQueue)

    return
#end def

# ---------------------------------------------------------------------
# Creates a connection factory for Websphere MQ
# ---------------------------------------------------------------------
def createMQConnectionFactory(scope, connectionFactory, aliasId):
    print 'INFO: Creating MQ Connection Factory ' + connectionFactory.name

    factoryList = AdminTask.listWMQConnectionFactories(scope, '[ -type %s]' % (connectionFactory.type))
    if (len(factoryList) != 0):
        factoryListEntries = factoryList.splitlines()

        for factoryEntry in factoryListEntries:
            factoryName = AdminConfig.showAttribute(factoryEntry, 'name')
            if (connectionFactory.name == factoryName):
                print 'INFO: Deleting existing MQ connection factory ' + connectionFactory.name
                AdminTask.deleteWMQConnectionFactory(factoryEntry)

    addQueueFactory = '[-name %s -jndiName %s -type %s -qmgrName %s -qmgrHostname %s -qmgrPortNumber %s -qmgrSvrconnChannel %s -wmqTransportType %s -containerAuthAlias %s]' %\
                      (connectionFactory.name, connectionFactory.jndiName, connectionFactory.type, connectionFactory.queueManager, connectionFactory.hostname,\
                      connectionFactory.port, connectionFactory.channel, connectionFactory.ttype, aliasId)
    AdminTask.createWMQConnectionFactory(scope, addQueueFactory)

    return
#end def

# ---------------------------------------------------------------------
# Creates a JMS Provider
# ---------------------------------------------------------------------
def createJMSProvider(scope, provider):
    print 'INFO: Creating JMS Provider ' + provider.name
    
    jmspId      = AdminConfig.getid('%s/JMSProvider:%s' % (scope, provider.name))
    if (len(jmspId) > 0):
        AdminConfig.remove(jmspId)
    
    name        = ['name', provider.name]
    classpath   = ['classpath', provider.classpath]
    extICF      = ['externalInitialContextFactory', provider.extICF] 
    extPURL     = ['externalProviderURL', provider.extPURL] 
    jmspAttrs   = [name, classpath, extICF, extPURL]
    
    jmsp        = AdminConfig.create('JMSProvider', AdminConfig.getid(scope), jmspAttrs)
    
    return
    
# ---------------------------------------------------------------------
# add J2EE Resource Property
# ---------------------------------------------------------------------
def addJ2EEResourceProperty(jmspId, name, value):
    jmsp        = AdminConfig.getid(jmspId)
    if (len(jmsp) == 0):
        return
        
    props       = AdminConfig.list('J2EEResourcePropertySet', jmsp)
    if (len(props) == 0):
        props   = AdminConfig.create('J2EEResourcePropertySet', jmsp, [])
    
    AdminConfig.create('J2EEResourceProperty', props, [['name', name],['value', value]])    
    return
    
# ---------------------------------------------------------------------
# Creates a queue connection factory for Active MQ
# ---------------------------------------------------------------------
def createGenericJMSConnectionFactory(jmspId, factory, secName):
    print 'INFO: Creating Generic JMS Connection Factory ' + factory.name
    
    jmsp        = AdminConfig.getid(jmspId)
    if (len(jmsp) == 0):
        return
        
    name        = ['name', factory.name]
    jndi        = ['jndiName', 'jms/%s' % factory.name]
    qtype       = ['type', 'QUEUE']
    extJndi     = ['externalJNDIName', 'jms/%s' % factory.name]
    
    print secName
    mcAlias     = ['mappingConfigAlias', 'DefaultPrincipalMapping']
    secAlias    = ['authDataAlias', secName]
    #mappingModuleAttr  = AdminConfig.list('mapping',  [list mappingConfigAlias DefaultPrincipalMapping]]]
    
    jmscfAttrs  = [name, jndi, extJndi, qtype, ['mapping', [secAlias, mcAlias]]]
    
    cf = AdminConfig.create('GenericJMSConnectionFactory', jmsp, jmscfAttrs )
    
    addJ2EEResourceProperty(jmspId, 'java.naming.connectionFactoryNames', 'jms/%s' % factory.name)
    
    return
    
    
# ---------------------------------------------------------------------
# Creates a queue connection factory for Active MQ
# ---------------------------------------------------------------------
def createGenericJMSQueue (jmspId, queue):
    print 'INFO: Creating Generic JMS Queue ' + queue.name
    
    jmsp = AdminConfig.getid(jmspId)
    if (len(jmsp) == 0):
        return
    
    name        = ['name', queue.name]
    jndi        = ['jndiName', 'jms/%s' % queue.name]
    qtype       = ['type', 'QUEUE']
    extJndi     = ['externalJNDIName', 'jms/%s' % queue.name]
    jmsdAttrs   = [name, jndi, extJndi, qtype]
    
    AdminConfig.create('GenericJMSDestination', jmsp, jmsdAttrs)
    addJ2EEResourceProperty(jmspId, 'java.naming.queue.jms.%s' % queue.name, queue.queueName)    
    
    return
    
# -------------------------------------------------------------------
# Create a SharedLibrary environment variable
# -------------------------------------------------------------------
def createEnvironmentSharedLibrary(scope, sharedVariableName, clientJar):
    # Check if the Library already Exists
    libraries = AdminConfig.list('Library', scope)
    libraryList = libraries.split(lineSeparator)

    isLibraryFound = None
    for library in libraryList:
        if len(library)==0: 
            continue
        libName = AdminConfig.showAttribute(library, 'name')
        if (libName == sharedVariableName):
            isLibraryFound = 1
            break

    if (isLibraryFound is None):
        # Add the Library
        myAttr = ['name', sharedVariableName]
        myAttr2 = ['classPath', clientJar ]
        attrs = [myAttr, myAttr2]
        print 'INFO: Creating Environment Shared Library Variable ' + sharedVariableName
        library = AdminConfig.create('Library', scope, attrs)
    else:
        print 'INFO: Shared Library ' + sharedVariableName + ' already exists '
    return


# -------------------------------------------------------------------
# Create a reference to a shared library in a deployed app, we assume
# that the shared library exists already.
# -------------------------------------------------------------------
def createLibraryReference(sharedVariableName, appName):
    print 'INFO: Adding reference to variable ' + sharedVariableName + ' to application ' + appName

    # Now add the reference to the Application EAR
    deployment = AdminConfig.getid('/Deployment:' + appName + '/')
    if (len(deployment) == 0):
        print 'ERROR - Could not get a reference to application ' + appName
        sys.exit()

    appDeploy = AdminConfig.showAttribute(deployment, 'deployedObject')
    classLoad1 = AdminConfig.showAttribute(appDeploy, 'classloader')

    # Search for the Reference to the Library in the App EAR
    isFoundLibReference = 0
    searchLibName = 'libraryName ' + sharedVariableName
    liblistEntries = AdminConfig.showall(classLoad1)
    liblistEntriesList = liblistEntries.split(lineSeparator)
    for liblistEntry in liblistEntriesList:
        if (liblistEntry.find(searchLibName) > 0):
            isFoundLibReference = 1
            break

    if (isFoundLibReference == 1):
        print 'INFO: Reference to Library ' + sharedVariableName + ' already exists for application ' + appName
    else:
        appDeploy = AdminConfig.showAttribute(deployment, 'deployedObject')
        classLoad1 = AdminConfig.showAttribute(appDeploy, 'classloader')
        print AdminConfig.create('LibraryRef', classLoad1, [['libraryName', sharedVariableName], ['sharedClassloader', 'true']])

    return

# ----------------------------------------------------------------------
# This proc will create a variable for the process execution environment
# the property will have to be passed in the following format
#propertyName = ['name', 'FOOBAR']
#propertyValue   = ['value', '/tmp']
#propertyDesc   = ['description', 'Path Needed for PX Calculator']
#property = [propertyName, propertyValue, propertyDesc]
# ----------------------------------------------------------------------
def createProcessEnvironmentVar(nodeName, serverName, varName, property):
    print 'INFO: Adding process execution variable ' + varName

    scope = '/Node:' + nodeName + '/Server:' + serverName + '/JavaProcessDef:/'
    processDef = AdminConfig.getid(scope)

    if len(processDef) == 0:
        print 'ERROR: Could not get reference process execution scope : ' + scope
        return

    list = AdminConfig.show(processDef)
    listSplit = list.split(lineSeparator)
    added = None
    for i in listSplit:
        if ((i.find('environment') > 0) and (i.find(varName + '(') > 0)):
            print 'INFO: Process execution variable ' + varName + ' already exists'
            added = 'yes'
            break

    if added is None:
        AdminConfig.modify(processDef, [['environment', [property]]])

    return


# -------------------------------------------------------------
# This procedure will create/modify a websphere variable
# -------------------------------------------------------------
def createWebSphereVariable(variable, value, cellName=None, nodeName=None, serverName=None):
    print 'INFO: Creating variable ' + variable

    if serverName is None:
        scopestr = '/Cell:' + cellName + '/Node:' + nodeName
    elif nodeName is None:
        scopestr = '/Cell:' + cellName
    else:
        scopestr = '/Cell:' + cellName + '/Node:' + nodeName + '/Server:' + serverName

    scope = AdminConfig.getid(scopestr)
    if len(scope) == 0:
        print 'ERROR: could not get scope for variable substitution for variable: ' + variable + 'in scope: ' + scopestr
        return

    varList = AdminConfig.list('VariableSubstitutionEntry', scope)
    varListEntries = varList.split(lineSeparator)

    added = None
    for entry in varListEntries:
        varName = AdminConfig.showAttribute(entry, 'symbolicName')
        if varName == variable:
            print 'INFO: modifing environment variable ' + variable
            AdminConfig.modify(entry, [['value', value]])
            added = 'yes'
            break

    if added is None:
        vm = scopestr + '/VariableMap:/'
        id = AdminConfig.getid(vm)
        if len(id) == 0:
            print 'ERROR: Could not get Variable Map id - variable ' + variable + ' not set.'
            return

        a = [['symbolicName', variable], ['value', value]]
        AdminConfig.create('VariableSubstitutionEntry', id, a)

    return

# ---------------------------------------------------------------------
# Install a resource adapter.
# ---------------------------------------------------------------------
def installResourceAdapter(scope, adapterName, rarFile, rarOptions, factoryAttributes, attributes):
    print 'INFO: Installing resource adapter ' + adapterName + ' from RAR file ' + rarFile

    resourceAdapters = AdminConfig.list('J2CResourceAdapter', getScope(scope))
    resourceAdaptersList = resourceAdapters.split(lineSeparator)

    # If the resource adapter has already been installed then don't install it again.

    eciAdapter = None
    for resourceAdapter in resourceAdaptersList:
        name = AdminConfig.showAttribute(resourceAdapter, 'name')
        if adapterName == name:
            print 'INFO: The resource adapter %s exists and will be reused.' % adapterName
            print 'INFO: The resource adapter must be manually deleted as it can be shared between multiple servers.'
            eciAdapter = resourceAdapter
            break

    if eciAdapter == None:
        eciAdapter = AdminConfig.installResourceAdapter(rarFile, scope, rarOptions)

    connectionFactories = AdminConfig.list('J2CConnectionFactory', getScope(scope))
    connectionFactoriesList = connectionFactories.split(lineSeparator)

    # Check to see if the connection factory already exists.  If it does
    # then just return without trying to create it again.

    for connectionFactory in connectionFactoriesList:
       name = AdminConfig.showAttribute(connectionFactory, 'name')
       if factoryAttributes[0][1] == name:
           print 'INFO: Removing existing connection factory ' + name
           AdminConfig.remove(connectionFactory)
           break

    factory = AdminConfig.create('J2CConnectionFactory', eciAdapter, factoryAttributes)

    propertySet = AdminConfig.showAttribute(factory, 'propertySet')
    properties = AdminConfig.list('J2EEResourceProperty', propertySet)
    propertiesList = properties.split(lineSeparator)

    for property in propertiesList:
        name = AdminConfig.showAttribute(property, 'name')
        for attribute in attributes:
            if attribute[0] == name:
                AdminConfig.modify(property, [['value', attribute[1]]])

    AdminConfig.save()
    return

# -------------------------------------------------------------
# This procedure will create a custom property for the security
# configuration within the cell.
# -------------------------------------------------------------
def setSecurityCustomProperty(cellName, propertyName, property):
    securityId = AdminConfig.getid('/Cell:' + cellName + '/Security:/')
    if (len(securityId) == 0):
        print 'ERROR: Could not locate security scope for cell  ' + cellName
        return

    # Search for the property to see if it alread exists
    app_props = AdminConfig.showall(securityId)
    app_props_list = app_props.split(lineSeparator)
    search_str = 'name ' + propertyName

    found = None
    for i in app_props_list:
        if i.find(search_str) > 0:
            found = i
            print 'INFO: Property ' + propertyName + ' already exists'
            break

    if found is None:
        AdminConfig.modify(securityId, [property])

    return

#------------------------------------------------------------------
# This procedure will deploy an ear file with the specified
# options.  The application will be undeployed if it is already
# deployed.
#------------------------------------------------------------------

def deployApplication(applicationName, applicationFileName, options):
    #------------------------------------------------------------------
    # First Check if the application is already deployed and undeploy
    # if it does
    #------------------------------------------------------------------

    if applicationName in AdminApp.list().splitlines():
        print 'INFO: %s  is already deployed and will be uninstalled.' % (applicationName)

        try:
            AdminApp.uninstall(applicationName)
        except ScriptingException, ex:
            print 'ERROR: Failed to uninstall application %s with exception %s' % (applicationName, ex)
            sys.exit(1)
    AdminConfig.save()

    try:
        AdminApp.install(applicationFileName, options)
    except ScriptingException, ex:
        print 'ERROR: Failed to deploy application %s with exception %s' % (applicationFileName, ex)
        if ex.getMessage().find('WASX7111E:') >= 0:
            print 'Possible reasons: If security is enabled than security role needs to be added to the deployment descriptor of application'
        sys.exit(1)

    AdminConfig.save()
    return

#-------------------------------------------------------------------
# This method will set the attributes of the configurationObject
# for the application.  The configurationObject is the name
# of the XML elements of the Deployment:appName element.  For
# example, 'deployedObject/classloader' refers to the hierarchy
# of elements starting with deployedObject and ending with classloader
# attributes is an array of tuples in this form:
# [['startingWeight', '7'], ['warClassLoaderPolicy', 'SINGLE']]
#-------------------------------------------------------------------

def setAttributes(applicationName, configurationObject, attributes):
    element = AdminConfig.getid('/Deployment:%s/' % (applicationName))
    if len(element) == 0:
        print 'ERROR: Could not set the deployment attributes of application %s' % (applicationName)
        return

    print 'INFO: Setting the attributes of the %s object in the %s application' % (configurationObject, applicationName)

    splitName = configurationObject.split('/')

    count = 0
    while count < len(splitName):
        element = AdminConfig.showAttribute(element, splitName[count])
        count += 1

    for attribute in attributes:
        print 'INFO: %s=%s' % (attribute[0], attribute[1])

    AdminConfig.modify(element, attributes)
    return

# -----------------------------------------------------
# Returns a platform specific info, based on 
# Operating system type
# -----------------------------------------------------
def getPlatformSpecificInfo(infoType):
    # Check if the args passed are valid
    validArgs = ['libpath','osname']
    if infoType not in validArgs:
        print 'ERROR: Invalid syntax for getPlatformSpecificInfo'
        print '       This function supports the following args:'
        print '      ' + validArgs
        sys.exit(-1)

    # Valid OS Names ...may need to be updated for additional os'es
    AIX = ['AIX']
    UNIX = ['HP-UX','SunOS']
    WINDOWS = ['Windows 7']

    # Get the name of the OS
    OS_Name = java.lang.System.getProperty('os.name')

    if infoType == 'osname':
        return OS_Name
    elif (infoType == 'libpath' and  OS_Name in UNIX):
        return 'LD_LIBRARY_PATH'
    elif (infoType == 'libpath' and  OS_Name in AIX):
        return 'LIBPATH'
    elif (infoType == 'libpath' and  OS_Name in WINDOWS):
        return 'PATH'

    print 'ERROR: Could not determine operating system type'
    print 'ERROR: Operating System : ' + OS_Name
    print 'ERROR: ' + OS_Name + ' may have to be added to the list of valid Operating Systems'
    sys.exit(1)

# -----------------------------------------------------------------    
# This function will remove a shared library
# -----------------------------------------------------------------    
def removeEnvironmentSharedLibrary(scope, sharedVariableName):
    # Check if the Library already Exists
    libraries = AdminConfig.list('Library', scope)
    libraryList = libraries.split(lineSeparator)
    
    for library in libraryList:
        if len(library)==0: continue
        libName = AdminConfig.showAttribute(library, 'name')
        if (libName == sharedVariableName):
            print 'INFO: removing shared library ' + sharedVariableName
            AdminConfig.remove(library)
            break

#---------------------------------------------------------------------------
# This class is used to build an option string that will be passed
# to WebSphere scripting objects.  It maintains a dictionary of options
# and their parameters.
#---------------------------------------------------------------------------

class CommandOptions(UserDict):
    #---------------------------------------------------------------------------
    # Constructor that initializes the dictionary that will store the options
    # and their parameters.
    #---------------------------------------------------------------------------

    #---------------------------------------------------------------------------
    # Return a string of the options that have been set.
    #---------------------------------------------------------------------------

    def getString(self):
        import types

        #---------------------------------------------------------------------------
        # We're going to build a string by putting each component in the string
        # into a list then converting the list to a string. This is much more
        # efficient than building the string by concatenating the string to
        # itself.
        #---------------------------------------------------------------------------

        optionList = []

        optionList.append('[ ')

        #---------------------------------------------------------------------------
        # Iterate through each item in the dictionary.  The item name is the
        # option name while the value is either None for options with no value,
        # a string for a simple option or a list of strings for options that
        # take multiple parameters.
        #---------------------------------------------------------------------------

        for item in self.items():
            #---------------------------------------------------------------------------
            # Prefix a - to the name of the option
            #---------------------------------------------------------------------------

            optionList.append('-')
            optionList.append(item[0])
            optionList.append(' ')

            value = item[1]

            #---------------------------------------------------------------------------
            # If the value is a list then we need to build a string where each
            # parameter is enclosed in [] and the entire collection is also enclosed
            # in [].  For example, if the parameters are 'a','b','c' then the
            # generated string will be [[a][b][c]]
            #---------------------------------------------------------------------------

            if isinstance(value, types.ListType):
                optionList.append('[')
                for row in value:
                    optionList.append('[ ')
                    optionList.append(row)
                    optionList.append(' ]')

                optionList.append(']')
                optionList.append(' ')
            elif value != None:
                #---------------------------------------------------------------------------
                # If the value is None then no value is appended otherwise just append
                # the single value since we're assuming that it's a single string.
                #---------------------------------------------------------------------------
                optionList.append(value)
                optionList.append(' ')

        optionList.append(']')

        #---------------------------------------------------------------------------
        # Concatenate every value in the options list into a single string and
        # return it.
        #---------------------------------------------------------------------------

        return ''.join(optionList)

    #----------------------------------------------------------------------------
    # If you request an option that isn't already in the dictionary then
    # we'll create a new list for it and return it back to you so that
    # you can extend it.  Note that the assumption is that the missing
    # option has a value which is a list of strings.  If that's not the case
    # then just set the option to None or a string as the case may be.
    #----------------------------------------------------------------------------

    def __getitem__(self, key):
        if key not in self.data.keys():
            self.data[key] = []

        return self.data[key]
