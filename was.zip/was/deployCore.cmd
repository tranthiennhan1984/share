@echo off

@rem ******************************************************************************
@rem All right, title and interest in and to the software        
@rem (the "Software") and the accompanying documentation or      
@rem materials (the "Documentation"), including all proprietary  
@rem rights, therein including all patent rights, trade secrets, 
@rem trademarks and copyrights, shall remain the exclusive       
@rem property of Hewlett Packard Enterprise Development LP.            
@rem No interest, license or any right respecting the Software      
@rem and the Documentation, other than expressly granted in      
@rem the Software License Agreement, is granted by implication   
@rem or otherwise.                                               
@rem                                                            
@rem (C) Copyright 2010-2016 Hewlett Packard Enterprise Development LP.
@rem All rights reserved.                                        
@rem ******************************************************************************

@rem ******************************************************************************
@rem This command file should not be run directly since it requires that the
@rem DEPLOY_* environment variables be set.
@rem ******************************************************************************

if (%DEPLOY_PATHFINDER%)==() (
	@echo This command file cannot be run directly. 
	exit /B 1
)

@rem ******************************************************************************
@rem Set the environment variables used in this batch file.
@rem ******************************************************************************

@echo Starting deployment: %DATE% %TIME%
call setWasPfEnv
if %ERRORLEVEL% NEQ 0 exit /B 1

pushd ..

@rem ******************************************************************************
@rem Create the EAR files for the different components before we deploy them.
@rem ******************************************************************************

call buildEars.cmd
if %ERRORLEVEL% NEQ 0 exit /B 1

popd

pushd scripts

if DEFINED USERNAME (
	set SECURITYARGS=-username %USERNAME% -password %PASSWORD%
) else (
	set SECURITYARGS=
)
@rem VN-PAWKS (-usejython21 true ^)
call %WSADMIN% -host %SERVERNAME% -port %SOAPPORT% %SECURITYARGS% ^
              -lang jython ^
              -tracefile %LOGDIR%\deploy.log ^
              -profileName %PROFILENAME% ^
			  -usejython21 true ^
              -f deploy.py

popd

@echo Finished deployment: %DATE% %TIME%

endlocal
