# ******************************************************************************
# All right, title and interest in and to the software        
# (the "Software") and the accompanying documentation or      
# materials (the "Documentation"), including all proprietary  
# rights, therein including all patent rights, trade secrets, 
# trademarks and copyrights, shall remain the exclusive       
# property of Hewlett Packard Enterprise Development LP.            
# No interest, license or any right respecting the Software      
# and the Documentation, other than expressly granted in      
# the Software License Agreement, is granted by implication   
# or otherwise.                                               
#                                                            
# (C) Copyright 2010-2016 Hewlett Packard Enterprise Development LP.
# All rights reserved.                                        
# ******************************************************************************

# ******************************************************************************
# Environment Setup for the Pathfinder Installation Scripts
# ******************************************************************************

export WAS_HOME=/usr/IBM/WebSphere8.5.5/AppServer

export JAVA_HOME=$WAS_HOME/java

export WSADMIN=$WAS_HOME/bin/wsadmin.sh

# ******************************************************************************
# SERVER_CONFIGURATION_SCRIPT specifies the name of a jython file that contains
# configuration information specific to your administration server. This is
# going to be Jython classes that provide variables used in your administration
# server specific scripts.
#
# SERVER_INITIALIZE_SCRIPT is the name of a script containing routines to 
# perform initialization that is specific to your administration server. This
# script must contain a method called initializeAdministrationServer() as this
# will be called by the initialize.py script.
#
# SERVER_DEPLOY_SCRIPT is the name of the a script containing routines to
# perform custom deployment actions for your administration server. This allows
# you to add any custom deployment parameters to the commands that deploy
# the Pathfinder, ConsoleServer and BAM server.  Your script must contain
# the following methods, even if they don't do anything:
#
# addPathFinderDeployOptions(options)
# addConsoleServerDeployOptions(options)
# addBAMServerDeployOptions(options)
# addWebServiceDeployOptions(options)
# 
# After these applications have been deployed the deploy.py script will
# call the deployAdministrationServerApps() method, giving you a chance
# to deploy any applications that are specific to your administration server.
# You must specify this method even if it doesn't do anything.
#
# Do not include the .py extension in the script name.
# ******************************************************************************
export SERVER_CONFIGURATION_SCRIPT=ingeniumServerConfiguration
export SERVER_INITIALIZE_SCRIPT=initializeIngenium
export SERVER_DEPLOY_SCRIPT=deployIngenium

# ******************************************************************************
# The server name where the DeployManager is located
# ******************************************************************************

export SERVERNAME=casps221

# ******************************************************************************
# The name of the WebSphere profile where the server is going to be created.
# ******************************************************************************

export PROFILENAME=AppSrv01

# ******************************************************************************
# The APPLICATION_SERVER_NAME variable is the name of the WebSphere application
# server that will be created. The region suffix will be appended to this name 
# if it's specified.  This variable must be specified. Note that this is not 
# the name of the Windows server that is hosting WebSphere.
#
# The REGION_SUFFIX allows you to run multiple WebSphere application servers
# on a single WebSphere profile. This variable is used by the 
# StartPathFinderServer and StopPathFinderServer batch files to build the name 
# of the server to start or stop. Example values would be UT, PR, HEAD, etc. 
# If no region suffix is required then ensure that there are no spaces after the =
#
# The CLUSTER_NAME variable must be export if Pathfinder is being deployed in a
# cluster. If no CLUSTER_NAME is required then ensure that there are no spaces 
# after the =
# ******************************************************************************
export REGION_SUFFIX=
export APPLICATION_SERVER_NAME=PathFinderServer
export CLUSTER_NAME=

# ******************************************************************************
# WebSphere SOAP port (Default is 8880) For Network Deployment Edition or 
# Network Deployment profile: In WebSphere Console, click Deployment manager 
# under System administration. Click the "Ports" option, you will find 
# SOAP_CONNECTOR_ADDRESS = xxxx. This is your WebSphere SOAP port. 
#
# For Single server Edition or Application Server Profile: In WebSphere Console, 
# click Server1 under Application servers. Click the "Ports" option, you will 
# find SOAP_CONNECTOR_ADDRESS = xxxx. This is your WebSphere SOAP port.
# ******************************************************************************

export SOAPPORT=8882

# ******************************************************************************
# WebSphere Console user name and password
# ******************************************************************************

export USERNAME=wsadmin
export PASSWORD=solcorp1

# ******************************************************************************
# Directory where the log files generated during the initialization or deploy 
# process will be written.
# ******************************************************************************

export LOGDIR=/tmp

# ******************************************************************************
# The ADMIN_SERVER variable identifies the administration server that the
# Pathfinder is being used with.  Valid values are INGENIUM or RADIENCE.
#
# The PAGE_SOURCE variable identifies the type of pages being used.  PageBuilder
# uses JSP pages while PageServer uses HTML templates.
# Valid values are HTML or JSP.
# ******************************************************************************

export ADMIN_SERVER=INGENIUM
export PAGE_SOURCE=JSP

# ******************************************************************************
# HPE Ingenium specific environment variables
#
# If using HPE Ingenium then you need to specify a Gateway implementation that is
# used by Pathfinder when it needs to communicate with the HPE Ingenium server.
# The variable INGENIUM_GATEWAY must be set to one of the folowing values:
#
# IBMCICS	The IBMCicsGateway is used
# AS400		The AS400Gateway is used
# MQ		The MQGateway is used
# JMS		The JMSGateway is used
#
# Each gateway is configured in the Pathfinder configuration file.  If using
# the IBMCICS gateway then additional parameters are specified in the 
# initializeIngenium.cmd batch file.
#
# The USE_PATHFINDERCONNECTOR variable identifies whether to use Pathfinder 
# Connector or not. Valid values are true or false.
#
# The PATHFINDERCONNECTOR_LISTENER variable identifies whether to use socket or
# Websphere MQ. Valid values are SOCKET or QUEUE. Please make sue you also update
# the PathFinderConnectorConfig file to reflect the appropriate processor class.
#
# ******************************************************************************

export INGENIUM_GATEWAY=JMS
export USE_PATHFINDERCONNECTOR=true
export PATHFINDERCONNECTOR_LISTENER=QUEUE

# ******************************************************************************
# HPE Radience specific environment variables
# ******************************************************************************

# Set PHNX_HOME_DIR if manually deploying Pathfinder
export PHNX_HOME_DIR=
