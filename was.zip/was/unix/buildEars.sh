#!/usr/bin/ksh
# ******************************************************************************
# All right, title and interest in and to the software        
# (the "Software") and the accompanying documentation or      
# materials (the "Documentation"), including all proprietary  
# rights, therein including all patent rights, trade secrets, 
# trademarks and copyrights, shall remain the exclusive       
# property of Hewlett Packard Enterprise Development LP.         
# No interest, license or any right respecting the Software      
# and the Documentation, other than expressly granted in      
# the Software License Agreement, is granted by implication   
# or otherwise.                                               
#                                                            
# (C) Copyright 2010-2016 Hewlett Packard Enterprise Development LP.
# All rights reserved.                                        
# ******************************************************************************

# ******************************************************************************
# This command file should not be run directly since it requires that the
# DEPLOY_* environment variables be set.
# ******************************************************************************

if [[ $DEPLOY_PATHFINDER = "" ]];  then
	echo This command file cannot be run directly. 
	exit 1
fi

export WORKING_DIR=$1

if [[ -n $WORKING_DIR ]]; then
   echo "Changing to working directiory $WORKING_DIR"
   cd $WORKING_DIR
fi

# ******************************************************************************
# This command file builds the Pathfinder EAR files.  It expects to be called
# from a batch file which has set the ADMIN_SERVER environment variable.  This
# variable identifies the back end administration server being used with
# Pathfinder.
# ******************************************************************************

if [[ $ADMIN_SERVER = "" ]]; then
	echo The ADMIN_SERVER environment variable has not been set.
	exit 1
fi

# ******************************************************************************
# Set the path to the Jar utility.
# ******************************************************************************

export JAR=$JAVA_HOME/bin/jar

if [[ $DEPLOY_PATHFINDER = "true" ]]; then 
	if [[ -d PathFinderEar ]]; then
		if [[ -e PathFinderEar.ear ]]; then
			rm PathFinderEar.ear
		fi

		# ******************************************************************************
		echo Creating PathFinderEar
		# ******************************************************************************
		
		cd PathFinderEar

		# Remove any existing jars or WARs that will copied over
		
		if [[ -e IBMCicsGateway.jar ]]; then
			rm IBMCicsGateway.jar
		fi
		if [[ -e AS400Gateway.jar ]]; then
			rm AS400Gateway.jar
		fi
		if [[ -e MQGateway.jar ]]; then
			rm MQGateway.jar
		fi
		if [[ -e JmsGateway.jar ]]; then
			rm JmsGateway.jar
		fi
		if [[ -e PageBuilder.war ]]; then
			rm PageBuilder.war
		fi
		if [[ -e PageServer.war ]]; then
			rm PageServer.war
		fi

		if [[ $ADMIN_SERVER = "INGENIUM" ]]; then 
			# Only one of the gateway jars will be added to the ear based upon the value 
			# of the INGENIUM_GATEWAY variable.  Each gateway is an EJB so the jar needs
			# to go into the root of the ear.
			
			case $INGENIUM_GATEWAY in
				IBMCICS) cp Gateways/IBMCicsGateway.jar . 
		 		;;	
				AS400) cp Gateways/AS400Gateway.jar . 
		 		;;	
				MQ) cp Gateways/MQGateway.jar .
		 		;;	
				JMS) cp Gateways/JmsGateway.jar . 
		 		;;	
				*) echo "Invalid INGENIUM_GATEWAY specified"
				;;
			esac
		
			if [[ $PAGE_SOURCE = "HTML" ]]; then 
				$JAR c0Mf PageServer.war -C PageServer .
				$JAR c0Mf PageServerEjb.jar -C PageServerEjb .
				if [[ $WAR_CONTENT != ""  ]]; then
					echo "Adding contents of $WAR_CONTENT to PageServer.war"
					$JAR u0Mf PageServer.war -C $WAR_CONTENT .
				fi	
			elif [[ $PAGE_SOURCE = "JSP" ]]; then 
				$JAR c0Mf PageBuilder.war -C PageBuilder .
				$JAR c0Mf PageBuilderEjb.jar -C PageBuilderEjb .
				if [[ $WAR_CONTENT != "" ]]; then 
					echo "Adding contents of $WAR_CONTENT to PageBuilder.war"
					$JAR u0Mf PageBuilder.war -C $WAR_CONTENT .
				fi
			fi
		elif [[ $ADMIN_SERVER = "RADIENCE" ]]; then 
			rm ingenium.jar 
			$JAR c0Mf PageBuilder.war -C PageBuilder .
			$JAR c0Mf PageBuilderEjb.jar -C PageBuilderEjb .
			if [[ $WAR_CONTENT  != "" ]]; then 
				echo "Adding contents of $WAR_CONTENT to PageBuilder.war"
				$JAR u0Mf PageBuilder.war -C $WAR_CONTENT .
			fi	
		fi	

		$JAR c0Mf lib/PathFinderConfig.jar -C PathFinderConfig .
		$JAR c0Mf ../PathFinderEar.ear *.war *.jar lib
		cd ..
		
	fi	
fi	

if [[ $DEPLOY_BAMSERVER = "true" ]]; then  
	if [[ -d BamServerEar ]]; then 

		if [[ -e BamServerEar.ear ]]; then
			rm BamServerEar.ear
		fi

		# ******************************************************************************
		echo Creating BamServerEar
		# ******************************************************************************

		cd BamServerEar
		$JAR c0Mf lib/BamServerConfig.jar -C BamServerConfig .
		$JAR c0Mf BamServerWar.war -C BamServerWar .
		$JAR c0Mf ../BamServerEar.ear *.war *.jar lib META-INF
		cd ..
	fi	
fi

if [[ $DEPLOY_CONSOLESERVER = "true" ]]; then 
	if [[ -d ConsoleServerEar ]]; then 
		if [[ -e ConsoleServerEar.ear ]]; then
			rm ConsoleServerEar.ear
		fi

		# ******************************************************************************
		echo Creating ConsoleServerEar
		# ******************************************************************************
		
		cd ConsoleServerEar
		$JAR c0Mf ConsoleServer.war -C ConsoleServer .
		$JAR c0Mf ../ConsoleServerEar.ear *.war *.jar lib META-INF
		cd ..
	fi	
fi

if [[ $DEPLOY_PATHFINDERCONNECTOR = "true" ]]; then 
	if [[ $USE_PATHFINDERCONNECTOR = "true" ]]; then  
		if [[ -e PathFinderConnectorEar.ear ]]; then
			rm PathFinderConnectorEar.ear
		fi

		# ******************************************************************************
		echo Creating PathFinderConnectorEar
		# ******************************************************************************
		
		cd PathFinderConnectorEar
		$JAR c0Mf lib/PathFinderConnectorConfig.jar -C PathFinderConnectorConfig .
		
		rm PathFinderConnectorEjb.jar

		if [[ $PATHFINDERCONNECTOR_LISTENER = "QUEUE" ]]; then 
			$JAR c0Mf PathFinderConnectorEjb.jar -C PathFinderConnectorEjb .
		fi	
		 
		$JAR c0Mf PathFinderConnectorWar.war -C PathFinderConnectorWar .
		$JAR c0Mf ../PathFinderConnectorEar.ear *.war *.jar lib META-INF
	    cd ..	
	fi
fi

if [[ WORKINGDIR != ""  ]]; then 
	cd $WORKDINGDIR
fi

