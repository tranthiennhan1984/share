#!/usr/bin/ksh

# ******************************************************************************
# All right, title and interest in and to the software        
# (the "Software") and the accompanying documentation or      
# materials (the "Documentation"), including all proprietary  
# rights, therein including all patent rights, trade secrets, 
# trademarks and copyrights, shall remain the exclusive       
# property of Hewlett Packard Enterprise Development LP.            
# No interest, license or any right respecting the Software      
# and the Documentation, other than expressly granted in      
# the Software License Agreement, is granted by implication   
# or otherwise.                                               
#                                                            
# (C) Copyright 2010-2016 Hewlett Packard Enterprise Development LP.
# All rights reserved.                                        
# ******************************************************************************

# ******************************************************************************
# This command file should not be run directly since it requires that the
# DEPLOY_* environment variables be set.
# ******************************************************************************

if [[ $DEPLOY_PATHFINDER  == "" ]];  then
	echo This command file cannot be run directly. 
	exit 1
fi

# ******************************************************************************
# Set the environment variables used in this batch file.
# ******************************************************************************

echo Starting deployment: $DATE $TIME
. ./setWasPfEnv.sh

if [[ -z $USERNAME || -z $PASSWORD ]]; then
    SECURITYARGS=""
else
    SECURITYARGS="-username $USERNAME -password $PASSWORD"
fi

cd ../..

# ******************************************************************************
# Create the EAR files for the different components before we deploy them.
# ******************************************************************************

./was/unix/buildEars.sh

cd was/scripts

$WSADMIN -host $SERVERNAME -port $SOAPPORT $SECURITYARGS \
              -lang jython \
              -tracefile $LOGDIR/deploy.log \
              -profileName $PROFILENAME \
              -f deploy.py

cd ../unix

echo Finished deployment: $DATE $TIME
