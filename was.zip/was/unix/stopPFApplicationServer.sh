#!/usr/bin/ksh

# ******************************************************************************
# All right, title and interest in and to the software        
# (the "Software") and the accompanying documentation or      
# materials (the "Documentation"), including all proprietary  
# rights, therein including all patent rights, trade secrets, 
# trademarks and copyrights, shall remain the exclusive       
# property of Hewlett Packard Enterprise Development LP.            
# No interest, license or any right respecting the Software      
# and the Documentation, other than expressly granted in      
# the Software License Agreement, is granted by implication   
# or otherwise.                                               
#                                                            
# (C) Copyright 2008-2016 Hewlett Packard Enterprise Development LP.
# All rights reserved.                                        
# ******************************************************************************


# ******************************************************************************
# Set the environment variables used in this batch file.
# ******************************************************************************

. ./setWasPfEnv.sh

if [[ -z $USERNAME || -z $PASSWORD ]]; then
    SECURITYARGS=""
else
    SECURITYARGS="-username $USERNAME -password $PASSWORD"
fi

cd ../scripts

if [[ -z $CLUSTER_NAME ]]; then
	echo Stopping server $APPLICATION_SERVER_NAME$REGION_SUFFIX
	$WAS_HOME/bin/stopServer.sh -profileName $PROFILENAME $APPLICATION_SERVER_NAME$REGION_SUFFIX $SECURITYARGS
else
	echo Stopping Cluster $CLUSTER_NAME$REGION_SUFFIX
	$WSADMIN -host $SERVERNAME -port $SOAPPORT $SECURITYARGS \
             -lang jython \
             -tracefile $LOGDIR/stopCluster.log \
             -profileName $PROFILENAME \
             -f stopCluster.py
fi

cd ../unix
