#!/usr/bin/ksh
# ******************************************************************************
# All right, title and interest in and to the software        
# (the "Software") and the accompanying documentation or      
# materials (the "Documentation"), including all proprietary  
# rights, therein including all patent rights, trade secrets, 
# trademarks and copyrights, shall remain the exclusive       
# property of Hewlett Packard Enterprise Development LP.            
# No interest, license or any right respecting the Software      
# and the Documentation, other than expressly granted in      
# the Software License Agreement, is granted by implication   
# or otherwise.                                               
#                                                            
# (C) Copyright 2010-2016 Hewlett Packard Enterprise Development LP.
# All rights reserved.                                        
# ******************************************************************************


. ./setWasPfEnv.sh

if [[ -z $USERNAME || -z $PASSWORD ]]; then
    SECURITYARGS=""
else
    SECURITYARGS="-username $USERNAME -password $PASSWORD"
fi

cd ../scripts

$WSADMIN -host $SERVERNAME -port $SOAPPORT $SECURITYARGS \
             -lang jython \
             -tracefile $LOGDIR/initialize.log \
             -profileName $PROFILENAME \
             -f initialize.py

cd ../unix

echo Finished initialization: $DATE $TIME
