@echo off

@rem ******************************************************************************
@rem All right, title and interest in and to the software        
@rem (the "Software") and the accompanying documentation or      
@rem materials (the "Documentation"), including all proprietary  
@rem rights, therein including all patent rights, trade secrets, 
@rem trademarks and copyrights, shall remain the exclusive       
@rem property of Hewlett Packard Enterprise Development LP.            
@rem No interest, license or any right respecting the Software      
@rem and the Documentation, other than expressly granted in      
@rem the Software License Agreement, is granted by implication   
@rem or otherwise.                                               
@rem                                                            
@rem (C) Copyright 2010-2016 Hewlett Packard Enterprise Development LP.
@rem All rights reserved.                                        
@rem ******************************************************************************

setlocal
setlocal enableextensions
setlocal enabledelayedexpansion

@rem ******************************************************************************
@rem Set the environment variables used in this batch file.
@rem ******************************************************************************

call setWasPfEnv

pushd scripts

if DEFINED USERNAME (
	set SECURITYARGS=-username %USERNAME% -password %PASSWORD%
) else (
	set SECURITYARGS=
)
@rem VN-PAWKS (-usejython21 true ^)
call %WSADMIN% -host %SERVERNAME% -port %SOAPPORT% %SECURITYARGS% ^
             -lang jython ^
             -tracefile %LOGDIR%\initialize.log ^
             -profileName %PROFILENAME% ^
			 -usejython21 true ^
             -f initialize.py

popd

@echo Finished initialization: %DATE% %TIME%

endlocal
