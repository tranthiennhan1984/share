@rem ******************************************************************************
@rem All right, title and interest in and to the software        
@rem (the "Software") and the accompanying documentation or      
@rem materials (the "Documentation"), including all proprietary  
@rem rights, therein including all patent rights, trade secrets, 
@rem trademarks and copyrights, shall remain the exclusive       
@rem property of Hewlett Packard Enterprise Development LP.            
@rem No interest, license or any right respecting the Software      
@rem and the Documentation, other than expressly granted in      
@rem the Software License Agreement, is granted by implication   
@rem or otherwise.                                               
@rem                                                            
@rem (C) Copyright 2010-2016 Hewlett Packard Enterprise Development LP.
@rem All rights reserved.                                        
@rem ******************************************************************************

@rem ******************************************************************************
@rem Environment Setup for the Pathfinder Installation Scripts
@rem ******************************************************************************
@rem VN-PAWKS
set WAS_HOME=C:\IBM\WebSphere\AppServer
if not exist %WAS_HOME% (
	echo The WAS_HOME variable refers to a directory that doesn't exist: %WAS_HOME%
	exit /B 1
)

@rem VN-PAWKS
set JAVA_HOME=%WAS_HOME%/java/8.0
set WSADMIN=%WAS_HOME%/bin/wsadmin.bat

@rem ******************************************************************************
@rem The WAR_CONTENT variable specifies a folder containing content that will
@rem be added to the WAR file prior to deployment. The variable should point to
@rem a folder that contains a directory structure that matches the WAR file
@rem structure since the contents will be added to the WAR as-is. If there is
@rem no content to add then comment out the setting of the WAR_CONTENT environment
@rem variable. 
@rem ******************************************************************************
@rem VN-PAWKS
set WAR_CONTENT=N:\ut\Deployment/PathFinderEar/PageServer

if defined WAR_CONTENT (
	if not exist "%WAR_CONTENT%" (
		echo The WAR_CONTENT variable refers to a directory that doesn't exist: %WAR_CONTENT%
		exit /B 1
	)
)

@rem ******************************************************************************
@rem SERVER_CONFIGURATION_SCRIPT specifies the name of a jython file that contains
@rem configuration information specific to your administration server. This is
@rem going to be Jython classes that provide variables used in your administration
@rem server specific scripts.
@rem
@rem SERVER_INITIALIZE_SCRIPT is the name of a script containing routines to 
@rem perform initialization that is specific to your administration server. This
@rem script must contain a method called initializeAdministrationServer() as this
@rem will be called by the initialize.py script.
@rem
@rem SERVER_DEPLOY_SCRIPT is the name of the a script containing routines to
@rem perform custom deployment actions for your administration server. This allows
@rem you to add any custom deployment parameters to the commands that deploy
@rem the Pathfinder, ConsoleServer and BAM server.  Your script must contain
@rem the following methods, even if they don't do anything:
@rem
@rem addPathFinderDeployOptions(options)
@rem addConsoleServerDeployOptions(options)
@rem addBAMServerDeployOptions(options)
@rem addWebServiceDeployOptions(options)
@rem 
@rem After these applications have been deployed the deploy.py script will
@rem call the deployAdministrationServerApps() method, giving you a chance
@rem to deploy any applications that are specific to your administration server.
@rem You must specify this method even if it doesn't do anything.
@rem
@rem Do not include the .py extension in the script name.
@rem ******************************************************************************

set SERVER_CONFIGURATION_SCRIPT=ingeniumServerConfiguration
set SERVER_INITIALIZE_SCRIPT=initializeIngenium
set SERVER_DEPLOY_SCRIPT=deployIngenium

@rem ******************************************************************************
@rem The server name where the DeployManager is located. For example,
@rem casps243.americas.hpqcorp.net
@rem ******************************************************************************

set SERVERNAME=VNVA016AIE.sunlifecorp.com

@rem ******************************************************************************
@rem The name of the WebSphere profile where the server is going to be created.
@rem ******************************************************************************

set PROFILENAME=AppSrv01

@rem ******************************************************************************
@rem The APPLICATION_SERVER_NAME variable is the name of the WebSphere application
@rem server that will be created. The region suffix will be appended to this name 
@rem if it's specified.  This variable must be specified. Note that this is not 
@rem the name of the Windows server that is hosting WebSphere.
@rem
@rem The REGION_SUFFIX allows you to run multiple WebSphere application servers
@rem on a single WebSphere profile. This variable is used by the 
@rem StartPathFinderServer and StopPathFinderServer batch files to build the name 
@rem of the server to start or stop. Example values would be UT, PR, HEAD, etc. 
@rem If no region suffix is required then ensure that there are no spaces after the =
@rem
@rem The CLUSTER_NAME variable must be set if Pathfinder is being deployed in a
@rem cluster. If no CLUSTER_NAME is required then ensure that there are no spaces 
@rem after the =
@rem ******************************************************************************

set APPLICATION_SERVER_NAME=PathFinderServer
set REGION_SUFFIX=
set CLUSTER_NAME=

@rem ******************************************************************************
@rem WebSphere SOAP port (Default is 8880) For Network Deployment Edition or 
@rem Network Deployment profile: In WebSphere Console, click Deployment manager 
@rem under System administration. Click the "Ports" option, you will find 
@rem SOAP_CONNECTOR_ADDRESS = xxxx. This is your WebSphere SOAP port. 
@rem
@rem For Single server Edition or Application Server Profile: In WebSphere Console, 
@rem click Server1 under Application servers. Click the "Ports" option, you will 
@rem find SOAP_CONNECTOR_ADDRESS = xxxx. This is your WebSphere SOAP port.
@rem ******************************************************************************
@rem VN-PAWKS
set SOAPPORT=8881

@rem ******************************************************************************
@rem WebSphere Console user name and password
@rem ******************************************************************************
@rem VN-PAWKS
set USERNAME="admin"
set PASSWORD="P@ssw0rd"

@rem ******************************************************************************
@rem Directory where the log files generated during the initialization or deploy 
@rem process will be written.
@rem ******************************************************************************
@rem VN-PAWKS
set LOGDIR=N:\ut\Deployment\was\logs

@rem ******************************************************************************
@rem The ADMIN_SERVER variable identifies the administration server that the
@rem Pathfinder is being used with.  Valid values are INGENIUM or RADIENCE.
@rem
@rem The PAGE_SOURCE variable identifies the type of pages being used.  PageBuilder
@rem uses JSP pages while PageServer uses HTML templates.
@rem Valid values are HTML or JSP.
@rem ******************************************************************************

set ADMIN_SERVER=INGENIUM
set PAGE_SOURCE=HTML

@rem ******************************************************************************
@rem HPE Ingenium specific environment variables
@rem
@rem The USE_PATHFINDERCONNECTOR variable identifies whether to use Pathfinder 
@rem Connector or not. Valid values are true or false.
@rem
@rem The PATHFINDERCONNECTOR_LISTENER variable identifies whether to use socket or
@rem Websphere MQ. Valid values are SOCKET or QUEUE. Please make sure you also update
@rem the PathFinderConnectorConfig file to reflect the appropriate processor class.
@rem
@rem If using HPE Ingenium then you need to specify a Gateway implementation that is
@rem used by Pathfinder when it needs to communicate with the HPE Ingenium server.
@rem The variable INGENIUM_GATEWAY must be set to one of the following values:
@rem
@rem IBMCICS The IBMCicsGateway is used
@rem AS400   The AS400Gateway is used
@rem MQ      The MQGateway is used
@rem JMS     The JMSGateway is used
@rem
@rem The IBMCICS gateway is configured in the ingeniumServerConfiguration.py file.
@rem ******************************************************************************

set INGENIUM_GATEWAY=JMS
set USE_PATHFINDERCONNECTOR=false
set PATHFINDERCONNECTOR_LISTENER=SOCKET

@rem ******************************************************************************
@rem HPE Radience specific environment variables
@rem PHNX_HOME_DIR will be picked up if maven phoenix:pathfinder goal is run
@rem otherwise uncomment and set it to the right value like C:/Radience/Release_2_1_2
@rem ******************************************************************************

SET PHNX_HOME_DIR=
