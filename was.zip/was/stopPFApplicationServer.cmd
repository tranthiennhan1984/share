@echo off

@rem ******************************************************************************
@rem All right, title and interest in and to the software        
@rem (the "Software") and the accompanying documentation or      
@rem materials (the "Documentation"), including all proprietary  
@rem rights, therein including all patent rights, trade secrets, 
@rem trademarks and copyrights, shall remain the exclusive       
@rem property of Hewlett Packard Enterprise Development LP.            
@rem No interest, license or any right respecting the Software      
@rem and the Documentation, other than expressly granted in      
@rem the Software License Agreement, is granted by implication   
@rem or otherwise.                                               
@rem                                                            
@rem (C) Copyright 2008-2016 Hewlett Packard Enterprise Development LP.
@rem All rights reserved.                                        
@rem ******************************************************************************

setlocal

@rem ******************************************************************************
@rem Set the environment variables used in this batch file.
@rem ******************************************************************************

call setWasPfEnv

pushd scripts

if DEFINED USERNAME (
	set SECURITYARGS=-username %USERNAME% -password %PASSWORD%
) else (
	set SECURITYARGS=
)

if defined CLUSTER_NAME  (
	@echo Stopping cluster %CLUSTER_NAME%
	call %WSADMIN% -host %SERVERNAME% -port %SOAPPORT% %SECURITYARGS% ^
              -lang jython ^
              -tracefile %LOGDIR%\stopCluster.log ^
              -profileName %PROFILENAME% ^
              -f stopCluster.py
) else (
	@echo Stopping server %APPLICATION_SERVER_NAME%%REGION_SUFFIX%
	call %WAS_HOME%\bin\StopServer -profileName %PROFILENAME% %APPLICATION_SERVER_NAME%%REGION_SUFFIX% -username %USERNAME% -password %PASSWORD%
)

popd

endlocal
