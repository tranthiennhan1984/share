﻿using Binean.Command;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Binean {
    internal sealed class Program {
        static void Main() {
            var debug = Environment.GetEnvironmentVariable("CMD_DEBUG")?.ToUpper();
            //if (debug == "Y")System.Diagnostics.Debugger.Launch();

            var args = Host.Arguments;
            args.ClearUsage();
            RegisterArgs(args);
            args.Read(Environment.GetCommandLineArgs());

            Process(args);
        }

        private static void Process(Arguments args) {
            var searchFolder = args.GetArg("searchFolder", true).CastAs<string>();
            var txt = args.GetArg("copyList", true).CastAs<string>();
            var filters = args.GetArg("f", true).CastAs<string>();
            var promptPath = args.GetArg("p", true).CastAs<bool>(false);

            if (!Directory.Exists(searchFolder)) {
                Console.Out.WriteLine($"Search folder doesn't exist {searchFolder}");
                return;
            }
            if (string.IsNullOrWhiteSpace(txt)) {
                Console.Out.WriteLine("Missing copy list");
                return;
            }

            var list = new List<string>();
            if (txt.IndexOf(';') > 0) {
                list.AddRange(txt.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries));
            } else if (File.Exists(txt)) {
                using (var reader = File.OpenText(txt)) {
                    string line;
                    while ((line = reader.ReadLine()) != null) {
                        if (!string.IsNullOrWhiteSpace(line)) list.Add(line);
                    }
                }
            } else list.Add(txt);


            Process(searchFolder, list, filters, promptPath);
        }
        private static void Process(string input, IList<string> list, string filters, bool promptPath) {
            foreach (var item in Directory.GetDirectories(input)) {
                var name = Path.GetFileName(item);
                Process(Path.Combine(input, name), list, filters, promptPath);
            }
            var fils = filters.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);

            var length = fils.Length;
            for (int i = 0; i < length; i++) {
                foreach (var file in Directory.GetFiles(input, fils[i], SearchOption.TopDirectoryOnly)) {
                    var name = Path.GetFileName(file);
                    using (var reader = File.OpenText(file)) {
                        string line;
                        while ((line = reader.ReadLine()) != null) {
                            var index = FindCode(line, list);
                            if (index == -1) continue;
                            Console.WriteLine(promptPath ? file : name);
                        }
                    }
                }
            }
        }
        private static int FindCode(string line, IList<string> list) {
            if (string.IsNullOrEmpty(line)) return -1;
            if (line.Length < 7 || "*/".IndexOf(line[6]) > -1) return -1;

            var length = list.Count;
            for (int i = 0; i < length; i++) {
                var index = FindCode(line, list[i]);
                if (index > -1) return index;
            }
            return -1;
        }
        private static int FindCode(string line, string txt) {
            if (string.IsNullOrEmpty(line)) return -1;
            if (line.Length < 7 || "*/".IndexOf(line[6]) > -1) return -1;

            var index = line.IndexOf(txt);
            if (index < 0) return -1;

            var end = index + txt.Length;
            if (index <= 6 || end > 72) return -1;

            if (!char.IsWhiteSpace(line[index - 1])) return -1;
            if (end < line.Length) {
                var chr = line[end];
                if (chr == '-' || char.IsLetterOrDigit(chr)) return -1;
            }
            return index;
        }

        private static void RegisterArgs(Arguments args) {
            args.Register("searchFolder", "Search folder")
                .Register("copyList", "Copy list separeate with ; or list file")
                .RegisterOptions("f", "File filters separate with ;", null, "*.cbl;*.cpy;*.ccp;")
                .RegisterOptions("p", "Prompt file path", null, false);
        }
    }
}

