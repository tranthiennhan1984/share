﻿
using System.Formats.Asn1;
using System.Text;

namespace Template {
    internal class Program {
        static void Main(string[] args) {
            var inputFile = args[0];
            var outputFile = args[1];
            var tempFile = args[2];
            var preText = args.Length > 3 ? File.ReadAllText(args[3]) : string.Empty;
            var postText = args.Length > 4 ? File.ReadAllText(args[4]) : string.Empty;

            using (var input = File.OpenText(inputFile)) {
                var csvReader = new CsvReader(input, true);
                var context = new CsvContext(csvReader);
                var temp = new Template(File.ReadAllText(tempFile));
                using (var output = File.CreateText(outputFile)) {
                    if (!string.IsNullOrEmpty(preText)) output.Write(preText);
                    while (csvReader.Next()) {
                        temp.Write(output, context);
                    }
                    if (!string.IsNullOrEmpty(postText)) output.Write(postText);
                }
            }
        }
    }

    internal class Template {
        readonly List<IEntry> _entries = new();
        public Template(string template) {
            using (var reader = new StringReader(template))
                Parse(reader);
        }
        private void Parse(TextReader reader) {
            var sb = new StringBuilder();
            var isVar = false;
            var isEscape = false;
            int value;
            while ((value = reader.Peek()) > 0) {
                var chr = (char)value;

                if (isVar) {
                    if (char.IsLetterOrDigit(chr) || chr == '_') {
                        sb.Append(chr);
                        reader.Read();
                    } else {
                        _entries.Add(new VarEntry(sb.ToString()));
                        sb.Clear();
                        isVar = false;
                    }
                    continue;
                }

                if (isEscape) {
                    isEscape = false;
                    var index = "rnt".IndexOf(chr);
                    if (index < 0) sb.Append(chr);
                    else sb.Append("\r\n\t"[index]);
                    reader.Read();
                    continue;
                }
                if (chr == '\\') {
                    isEscape = true;
                    reader.Read();
                    continue;
                }
                if (chr == '@') {
                    _entries.Add(new TextEntry(sb.ToString()));
                    sb.Clear();
                    reader.Read();
                    isVar = true;
                    continue;
                }
                sb.Append(chr);
                reader.Read();
            }
            if (sb.Length > 0) {
                if (isVar) _entries.Add(new VarEntry(sb.ToString()));
                else _entries.Add(new TextEntry(sb.ToString()));
            }
        }
        public void Write(StreamWriter writer, IDataContext context) {
            var length = _entries.Count;
            for (int i = 0; i < length; i++) {
                var entry = _entries[i];
                entry.Write(writer, context);
            }
        }
    }

    interface IDataContext {
        bool TryGetValue(string name, out string? value);
    }
    internal class CsvContext : IDataContext {
        readonly CsvReader _reader;
        public CsvContext(CsvReader reader) {
            _reader = reader;
        }
        public bool TryGetValue(string name, out string? value) {
            if (string.IsNullOrEmpty(name) || _reader.Names == null || _reader.Values == null) {
                value = null;
                return false;
            }

            var index = -1;
            var length = _reader.Names.Length;
            for (int i = 0; i < length; i++) {
                if (_reader.Names[i] == name) {
                    index = i;
                    break;
                }
            }

            if (index < 0) {
                value = null;
                return false;
            }

            value = _reader.Values[index];
            return true;
        }
    }

    internal interface IEntry {
        void Write(StreamWriter writer, IDataContext context);
    }
    internal class TextEntry : IEntry {
        public TextEntry(string text) {
            Text = text;
        }

        public string Text { get; }
        public void Write(StreamWriter writer, IDataContext context) {
            if (string.IsNullOrEmpty(Text)) return;
            writer.Write(Text);
        }
    }
    internal sealed class VarEntry : IEntry {
        public VarEntry(string name) {
            Name = name;
        }
        public string Name { get; }
        public void Write(StreamWriter writer, IDataContext context) {
            if (string.IsNullOrEmpty(Name)) throw new InvalidOperationException();
            if (!context.TryGetValue(Name, out string? value)) throw new InvalidOperationException();
            if (!string.IsNullOrEmpty(value)) writer.Write(value);
        }
    }
}