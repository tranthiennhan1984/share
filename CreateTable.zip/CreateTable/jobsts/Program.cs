﻿using Binean.Command;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Binean {
    internal sealed class Program {
        static void Main() {
            var debug = Environment.GetEnvironmentVariable("CMD_DEBUG")?.ToUpper();
            //if (debug == "Y")System.Diagnostics.Debugger.Launch();

            var args = Host.Arguments;
            args.ClearUsage();
            RegisterArgs(args);
            args.Read(Environment.GetCommandLineArgs());

            Process(args);
        }

        private static void Process(Arguments args) {
            var input = args.GetArg("inputFile", true).CastAs<string>();
            var output = args.GetArg("outputFolder", true).CastAs<string>();

            if (!File.Exists(input)) {
                Console.Out.WriteLine($"Input file doesn't exist {input}");
                return;
            }

            if (string.IsNullOrEmpty(output)) {
                Console.Out.WriteLine($"Missing output {output}");
                return;
            }

            if (!Directory.Exists(output)) Directory.CreateDirectory(output);

            Console.Out.WriteLine($"Split '{input}' to '{output}'");
            Process(File.OpenText(input), output);
        }
        private static void Process(TextReader input, string folder) {
            TextWriter output = null;
            var processor = new Processor(FirstLine);
            string line;
            while ((line = input.ReadLine()) != null) {
                processor(ref processor, folder, ref output, line);
            }
        }
        private static void FirstLine(ref Processor processor, string folder, ref TextWriter output, string line) {
            if (line.Length > 0 && line[0] == '_') processor = NewFile;
        }
        private static void NewFile(ref Processor processor,  string folder, ref TextWriter output, string line) {
            var record = ReadLine(line);
            var fileName = Path.Combine(folder, $"Status_{record.Start:yyyyMMdd_HHmmss}.csv");
            output = File.CreateText(fileName);
            output.WriteLine("Name,Start,End,Status");
            WriteRecord(output, record);
            processor = new Processor(NewLine);
        }
        private static void NewLine(ref Processor processor, string folder, ref TextWriter output, string line) {
            if(line.Length == 0|| line[0] == '\0') {
                output.Flush();
                output.Close();
                output = null;
                processor = new Processor(FirstLine);
                return;
            }
            var record = ReadLine(line);
            WriteRecord(output, record);
        }
        private static void WriteRecord(TextWriter output, Record record) {
            output.Write(record.Name);
            output.Write(",");
            output.Write(record.Start.ToString("yyyy-MM-dd HH.mm.ss"));
            output.Write(",");
            output.Write(record.End.ToString("yyyy-MM-dd HH.mm.ss"));
            output.Write(",");
            output.WriteLine(record.Status);
        }
        private static Record ReadLine(string line) {
            return new Record {
                Name = line.Substring(0, 64).Trim(),
                Start = ToDate(line.Substring(65, 20).Trim()),
                End = ToDate(line.Substring(86, 20).Trim()),
                Status = ToStatus(line.Substring(107, 5).Trim()),
            };
        }
        private static DateTime ToDate(string txt) {
            return DateTime.TryParseExact(txt, "MM/dd/yyyy HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime value) ? value : DateTime.MaxValue;
        }
        private static string ToStatus(string txt) {
            switch (txt) {
                case "SU": return "SUCCESS";
                case "TE": return "TERMINATED";
                case "IN": return "INACTIVE";
                case "SU/NE": return "ON_NOEXEC";
                default: return txt;
            }
        }
        private delegate void Processor(ref Processor processor, string folder, ref TextWriter output, string line);
        private static void RegisterArgs(Arguments args) {
            args.Register("inputFile", "Input file")
                .Register("outputFolder", "Output folder");
        }
        class Record {
            public string Name { get; set; }
            public DateTime Start { get; set; }
            public DateTime End { get; set; }
            public string Status { get; set; }
        }
    }
}

