﻿using Binean.Command;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Binean {
    internal sealed class Program {
        static void Main() {
            var debug = Environment.GetEnvironmentVariable("CMD_DEBUG")?.ToUpper();
            //if (debug == "Y")System.Diagnostics.Debugger.Launch();

            var args = Host.Arguments;
            args.ClearUsage();
            RegisterArgs(args);
            args.Read(Environment.GetCommandLineArgs());

            Process(args);
        }

        private static void Process(Arguments args) {
            var inputFile = args.GetArg("inputFile", true).CastAs<string>();
            var outputFile = args.GetArg("outputFile", true).CastAs<string>();

            if (!File.Exists(inputFile)) {
                Console.Out.WriteLine($"Input file doesn't exist {inputFile}");
                return;
            }
            if (string.IsNullOrWhiteSpace(outputFile)) {
                Console.Out.WriteLine("Missing output file");
                return;
            }

            Process(inputFile, outputFile);
        }
        private static void Process(string inputFile, string outputFile) {
            var config = new ConfigReader();
            using(var reader = File.OpenText(inputFile)) {
                config.ReadAll(reader);
            }
            using(var writer = File.CreateText(outputFile)) {
                using(var csvWriter = new CsvWriter(writer, config.GetColumns(), true)) {
                    csvWriter.WriteAll(config, true, false);
                }
            }
        }

        private static void RegisterArgs(Arguments args) {
            args.Register("inputFile", "Input configure file")
                .Register("outputFile", "Output csv file");
        }
    }
}

