# Giới thiệu

Mọi sáng kiến trên thế gian này đều bắt đầu từ ý tưởng.

Binean là môi trường sống và phát triển của ý tưởng.
Trong binean mọi ý tưởng sẽ sinh tồn phát triển sinh sôi và chết đi.

Binean cũng là một ý tưởng!

# Ý tưởng

## Sự sống và cái chết

Tuần hoàn là yếu tố quyết định sự trường tồn và phát triển.
Sự sống phải đi kèm Cái chết.

Ý tưởng có thể ra đời trong thoáng chốc và chết đi cũng nhanh như vậy, chỉ một phần rất nhỏ ý tưởng có thể trưởng thành được.
Sự chết đi của một ý tưởng có thể là nền tảng cho một ý tưởng khác lớn hơn.

Hệ thống phải đáp ứng được tốc độ này.

Tất nhiên một ý tưởng cũng có người sinh thành, anh em họ hàng chung huyết mạch.
Một ý tưởng còn có giông loài, nó có thể tham khảo và phát triền theo định hướng chung của giống loài (một tập các ý tưởng cùng loại).

Một ý tưởng cũng có các chỉ số sinh tồn của nó có thời niên thiếu, trai tráng của tuổi trẻ, có sự già yếu và chết đi.
Một ý tưởng sẽ có bệnh tật, có các khó khăn và thử thách; những điều này có thể đến từ chính bản thân ý tưởng cũng có thể đến từ môi trường sống!

Binean cũng vậy nó cần phát triển để các ý tưởng trong nó có thể thăng hoa và tiến hóa đến tận cùng!
Nó là quá trình và không phải là yêu cầu lúc này!

### Mô tả về sự ra đời của một ý tưởng

Vì ý tưởng là thoáng qua, rất nhanh nên cần một cơ chế thật nhanh để nắm bắt được thời điểm này.
Tối ưu việc nhập liệu cho một ý tưởng.

Mọi sinh linh đều hình thành một cách tự nhiên trong im lặng, chỉ có lúc chào đời thì mới có phong vân vần vũ.
Hệ thống nên cho phép marketing, kêu gọi đầu tư... để chào đón một ý tưởng sinh ra (đã phát triển thành hình hài).

### Một mô tả về cái chết của một ý tưởng

Vì ý tưởng cũng chết rất nhanh, nên hệ thống sẽ làm chậm quá trình này để một ý tưởng được tồn tại lâu hơn.
Chuyển trạng thái chết thành ngủ đông.

Quá trình delete nên confirm nhiều bước nếu cần có thể bỏ chức năng này.
Chuyển thành một quá trình delete hàng loạt bởi hệ thống dựa vào dấu hiệu nhận biết sự sống của ý tưởng.

Tuy nhiên Cái chết là bắt buộc là một yếu tố cân bằng vời sự sống, để đảm bảo hệ thống tồn tại lâu dài.
Bằng cách giới hạn tài nguyên của mỗi user, chúng ta có thể để ý tưởng chết đi một các tự nhiên như cách nó đã sinh ra.

Hệ thống hướng tới luân hồi, thay vì giết chết một ý tưởng và thay bằng một cái mới tốt hơn thì hệ thống sẽ khuyến khích ý tưởng đó tiến hóa, hoặc luân hồi.
Một ý tưởng có thể có tiền thân của nó; một ý tưởng có thể có các thể hiện khác nhau; chuyển hóa thành một hình hài khác khi trưởng thành
Một ý tưởng tiến hóa sẽ được nhiều quyền lợi hơn một ý tưởng mới.

### Dấu hiện nhận biết sự sống của một ý tưởng

Trong thời điểm bắt đầu tất cả ý tưởng sẽ ko chết, cần thời gian để xác định như thế nào là một ý tưởng đang sống và có thể đưa ra nhiều trạng thái khác nhau của cái chết.

## Đa dạng loài

Hệ thống sẽ cho phép đa dạng hóa giống loài.
Tuy nhiên một ý tưởng thường sẽ phát triển thành một project, trước tiên sẽ đi theo hướng này.
Cần định nghĩa con đường này (con đường tiến hóa của 1 ý tưởng)
Sự tiến hóa của loài gần như được định nghĩa sẵn bởi hệ thống.

### Hình dạng của ý tưởng

Theo Tôi mọi vật trên đời này kể cả con người đều vật để chứa đựng Thông tin. Đều có hình dáng của Thông tin.
Ý tưởng cũng cũng như các sinh vật khác trong Binean sẽ có hình dáng của Thông tin.

Vậy Thông tin có hình dáng gì? Với Tôi Thông tin là các đoạn dữ liệu nó nên có dạng là những đoạn thẳng. Hình dáng thật của Thế Giới có thể là một đường thẳng.

Thế giới cả ta là thế giới 3 chiều nên khi các đoạn thẳng nối với nhau sẽ có hình dáng như một bộ rễ cây.
Còn nếu chúng ta cố nhồi nhét thật nhiều Thông tin vào một sinh vật hữu hạn thì ta sẽ có hình dáng sinh vật như giới này.

Binean là một thế giới 2 chiều nên sẽ có dạng như một bộ rễ 2 chiều trên mặt phẳng.

Hãy tưởng tượng chúng ta có 1 bó rễ, và ta muốn truy suất đến từng cộng rễ một như vậy ta buộc phải đánh địa chỉ cho từng cộng rễ 1. Có 2 cách để đánh index.
1. Đánh theo số thứ tự
2. Đánh theo tên

Hay nói cách khác mọi sinh vật trong Binean sẽ có hình dạng như file json là tập hợp các đoạn thông tin; array cho tổ hợp đánh index và object cho tổ hợp được đặt tên.
Luôn nhớ rằng một sinh vật bất kỳ có thể là bộ phận trong 1 sinh vật khác lớn hơn, nó cũng là một đoạn rễ trong một bộ rễ khác lớn hơn.

Vì vậy dùng mindmap để capture Ý tưởng là hợp lý nhất! Nó cũng sẽ là hình dáng thật của Loài. Tức các hình thái tiến hóa sau này của Ý tưởng cũng có sẽ có hình dáng này.


