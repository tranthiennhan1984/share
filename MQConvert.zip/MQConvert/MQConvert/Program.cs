﻿using System.Text;

namespace MQConvert {
    public static class MQConverter {
        const string remark = "AMQCNV";
        const string descript = "**  15JAN2024 NHANTT CICS REPLACEMENT                          **";
        public static void Main() {
            var output = Environment.GetEnvironmentVariable("OUT_DIR");
            //if (string.IsNullOrEmpty(output)) output = "D:\\srce";

            if (string.IsNullOrEmpty(output)) output = "W:\\mserver";

            if (!Directory.Exists(output)) {
                Console.WriteLine($"Missing OUT_DIR: '{output}'");
                return;
            }

            var input = Environment.GetEnvironmentVariable("IN_DIR");
            if (string.IsNullOrEmpty(input)) input = "N:\\ut\\server";
            if (!Directory.Exists(input)) {
                Console.WriteLine($"Missing IN_DIR: '{input}'");
                return;
            }

            ConvertCopy(Path.Combine(output,"copy"), Path.Combine(input, "copy"));
            ConvertOnline(Path.Combine(output,"srce"), Path.Combine(input, "srce"));
            ConvertSource(Path.Combine(output,"srce"), Path.Combine(input, "srce"));
        }

        private static void ConvertCopy(string outFolder, string inFolder) {
            var files = Directory.GetFiles(inFolder, "*.cpy");
            for (int i = 0; i < files.Length; i++) {
                var infile = files[i];
                var outfile = Path.Combine(outFolder, Path.GetFileName(infile));
                var isOk = true;
                using (var writer = File.CreateText(outfile)) {
                    using (var reader = File.OpenText(infile)) {
                        isOk = ConvertCopy(writer, reader);
                    }
                }
                if (!isOk) {
                    File.Move(outfile, Path.ChangeExtension(outfile, ".errcpy"), true);
                }
            }

        }
        private static bool ConvertCopy(TextWriter writer, TextReader reader) {
            string? line;
            while ((line = reader.ReadLine()) != null) {
                writer.WriteLine(line);
                if (line.IsCommentBlock()) break;
            }
            if (line == null) return false;

            while ((line = reader.ReadLine()) != null) {
                writer.WriteLine(line);
                if (line.IsCommentBlock()) break;
            }
            if (line == null) return false;

            while ((line = reader.ReadLine()) != null) {
                if (line.IsCommentBlock()) break;
                writer.WriteLine(line);
            }
            if (line == null) return false;
            writer.Write(remark);
            writer.WriteLine(descript);
            writer.WriteLine(line);

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.TrimEnd().EndsWith("DFHEIBLK")) break;
                writer.WriteLine(line);
            }
            if (line == null) return false;
            writer.Write(remark);
            writer.Write('*');
            var useLine = line[7..].TrimEnd();
            writer.WriteLine(useLine);

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.TrimEnd().EndsWith("DFHCOMMAREA")) break;
                writer.WriteLine(line);
            }
            if (line == null) return false;
            writer.Write(remark);
            writer.Write('*');
            writer.WriteLine(line[7..]);

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.TrimEnd().EndsWith("WGLOB-GLOBAL-AREA")) break;
                writer.WriteLine(line);
            }
            if (line == null) return false;
            writer.Write(remark);
            writer.Write('*');
            writer.WriteLine(line[7..]);
            writer.Write(remark);
            writer.Write(' ');
            writer.WriteLine(useLine.Replace("DFHEIBLK", "WGLOB-GLOBAL-AREA"));

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.IsErrCopy()) break;
                writer.WriteLine(line);
            }
            if (line == null) return true;
            writer.Write(remark);
            writer.Write('*');
            writer.WriteLine("COPY XCCPERR.");
            while ((line = reader.ReadLine()) != null) {
                writer.WriteLine(line);
            }
            return true;
        }
        private static void ConvertSource(string outFolder, string inFolder) {
            var files = Directory.GetFiles(inFolder, "*.cbl");
            for (int i = 0; i < files.Length; i++) {
                var infile = files[i];
                var outfile = Path.Combine(outFolder, Path.GetFileName(infile));
                var count = 0;
                using (var writer = File.CreateText(outfile)) {
                    using (var reader = File.OpenText(infile)) {
                        count = ConvertSource(writer, reader);
                    }
                }
                if (count < 0) {
                    File.Move(outfile, Path.ChangeExtension(outfile, ".errcbl"), true);
                }else if(count == 0) {
                    File.Delete(outfile);
                }
            }

        }
        private static int ConvertSource(TextWriter writer, TextReader reader) {
            int retVal = 0;
            string? line;
            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.IsXCWWCRHT()) {
                    writer.Write(remark);
                    writer.Write('*');
                    writer.WriteLine(line[7..]);
                    retVal++;
                } else writer.WriteLine(line);
                if (line.IsCommentBlock()) break;
            }
            if (line == null) return -retVal;

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.IsXCWWCRHT()) {
                    writer.Write(remark);
                    writer.Write('*');
                    writer.WriteLine(line[7..]);
                    retVal++;
                } else writer.WriteLine(line);
                if (line.IsCommentBlock()) break;
            }
            if (line == null) return -retVal;

            while ((line = reader.ReadLine()) != null) {
                if (line.IsCommentBlock()) break;
                if (!line.IsCommentLine() && line.IsXCWWCRHT()) {
                    writer.Write(remark);
                    writer.Write('*');
                    writer.WriteLine(line[7..]);
                    retVal++;
                } else writer.WriteLine(line);
            }
            if (line == null) return -retVal;
            writer.Write(remark);
            writer.WriteLine(descript);
            writer.WriteLine(line);

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.TrimEnd().EndsWith("DFHEIBLK")) break;
                if (!line.IsCommentLine() && line.IsXCWWCRHT()) {
                    writer.Write(remark);
                    writer.Write('*');
                    writer.WriteLine(line[7..]);
                    retVal++;
                } else writer.WriteLine(line);
            }
            if (line == null) return -retVal;
            writer.Write(remark);
            writer.Write('*');
            var useLine = line[7..].TrimEnd();
            writer.WriteLine(useLine);

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.TrimEnd().EndsWith("DFHCOMMAREA")) break;
                writer.WriteLine(line);
            }
            if (line == null) return -retVal;
            writer.Write(remark);
            writer.Write('*');
            writer.WriteLine(line[7..]);

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.TrimEnd().EndsWith("WGLOB-GLOBAL-AREA")) break;
                writer.WriteLine(line);
            }
            if (line == null) return -retVal;
            writer.Write(remark);
            writer.Write('*');
            writer.WriteLine(line[7..]);
            writer.Write(remark);
            writer.Write(' ');
            writer.WriteLine(useLine.Replace("DFHEIBLK", "WGLOB-GLOBAL-AREA"));
            retVal++;

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine()) {
                    if (line.IsErrCopy()) break;
                    if (line.IsXCWWCRHT()) {
                        writer.Write(remark);
                        writer.Write('*');
                        writer.WriteLine(line[7..]);
                        continue;
                    }
                }
                writer.WriteLine(line);
            }
            if (line == null) return retVal;
            writer.Write(remark);
            writer.Write('*');
            writer.WriteLine("COPY XCCPERR.");
            retVal++;
            while ((line = reader.ReadLine()) != null) {
                writer.WriteLine(line);
            }
            return retVal;
        }
        private static void ConvertOnline(string outFolder, string inFolder) {
            var files = Directory.GetFiles(inFolder, "*.ccp");
            for (int i = 0; i < files.Length; i++) {
                var infile = files[i];
                var outfile = Path.ChangeExtension(Path.Combine(outFolder, Path.GetFileName(infile)), ".ccp");
                var isOk = true;
                using (var writer = File.CreateText(outfile)) {
                    using (var reader = File.OpenText(infile)) {
                        isOk = ConvertOnline(writer, reader);
                    }
                }
                if (!isOk) {
                    File.Move(outfile, Path.ChangeExtension(outfile, ".errccp"), true);
                }
            }

        }
        private static bool ConvertOnline(TextWriter writer, TextReader reader) {
            string? line;
            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.IsXCWWCRHT()) {
                    writer.Write(remark);
                    writer.Write('*');
                    writer.WriteLine(line[7..]);
                } else writer.WriteLine(line);
                if (line.IsCommentBlock()) break;
            }
            if (line == null) return false;

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.IsXCWWCRHT()) {
                    writer.Write(remark);
                    writer.Write('*');
                    writer.WriteLine(line[7..]);
                } else writer.WriteLine(line);
                if (line.IsCommentBlock()) break;
            }
            if (line == null) return false;

            while ((line = reader.ReadLine()) != null) {
                if (line.IsCommentBlock()) break;
                if (!line.IsCommentLine() && line.IsXCWWCRHT()) {
                    writer.Write(remark);
                    writer.Write('*');
                    writer.WriteLine(line[7..]);
                } else writer.WriteLine(line);
            }
            if (line == null) return false;
            writer.Write(remark);
            writer.WriteLine(descript);
            writer.WriteLine(line);

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine()) {
                    if (line.IsErrCopy()) break;
                    if (line.IsXCWWCRHT()) {
                        writer.Write(remark);
                        writer.Write('*');
                        writer.WriteLine(line[7..]);
                        continue;
                    }
                }
                writer.WriteLine(line);
            }
            if (line == null) return true;
            writer.Write(remark);
            writer.Write('*');
            writer.WriteLine("COPY XCCPERR.");
            while ((line = reader.ReadLine()) != null) {
                writer.WriteLine(line);
            }
            return true;
        }

        private static bool IsCommentLine(this string line) => line.Length <= 6 || "/*".Contains(line[6]);
        private static bool IsCommentBlock(this string line) => line.Length > 50 && line[7..].StartsWith("***************************************************************");
        private static bool IsErrCopy(this string line) => line.Length > 19 && line.IndexOf("XCCPERR", 7) > 7;
        private static bool IsXCWWCRHT(this string line) => line.Length > 19 && line.IndexOf("XCWWCRHT", 7) > 7;


        private static bool IsLinkage(this string line) {
            if (line.Length < 20) return false;
            line = line[7..].TrimEnd('.');
            if (line.Length < 14) return false;
            var worlds = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            return worlds.Length == 2 && worlds[0] == "LINKAGE" && worlds[1] == "SECTION";
        }
    }
}