﻿using Microsoft.CSharp.RuntimeBinder;

namespace MQConvert {
    public static class MQConverter {
        public static void Main() {
            var output = Environment.GetEnvironmentVariable("OUT_DIR");
            //if (string.IsNullOrEmpty(output)) output = "D:\\srce";

            if (string.IsNullOrEmpty(output)) output = "W:\\server\\mqsrce";

            if (!Directory.Exists(output)) {
                Console.WriteLine($"Missing OUT_DIR: '{output}'");
                return;
            }

            var input = Environment.GetEnvironmentVariable("IN_DIR");
            if (string.IsNullOrEmpty(input)) input = "N:\\ut\\server\\srce";
            if (!Directory.Exists(input)) {
                Console.WriteLine($"Missing IN_DIR: '{input}'");
                return;
            }

            Convert(output, input);

            //var infile = "D:\\CSOM0031.ccp";
            //var outfile = "D:\\CSOM0031.cbl";

            //if (!File.Exists(infile)) {
            //    Console.WriteLine($"Missing file '{infile}'.");
            //    return;
            //}

            //using (var writer = File.CreateText(outfile)) {
            //    using (var reader = File.OpenText(infile)) {
            //        Convert(writer, reader);
            //    }
            //}
        }

        private static void Convert(string outFolder, string inFolder) {
            var files = Directory.GetFiles(inFolder, "*.ccp");
            for (int i = 0; i < files.Length; i++) {
                var infile = files[i];
                var outfile = Path.ChangeExtension(Path.Combine(outFolder, Path.GetFileName(infile)), ".ccp");
                var isOk = true;
                using (var writer = File.CreateText(outfile)) {
                    using (var reader = File.OpenText(infile)) {
                        isOk = Convert(writer, reader);
                    }
                }
                if (!isOk) {
                    File.Move(outfile, Path.ChangeExtension(outfile, ".err"), true);
                }
            }

        }
        private static bool Convert(TextWriter writer, TextReader reader) {
            string? line;
            while ((line = reader.ReadLine()) != null) {
                writer.WriteLine(line);
                if (line.IsCommentBlock()) break;
            }
            if (line == null) return false;

            while ((line = reader.ReadLine()) != null) {
                writer.WriteLine(line);
                if (line.IsCommentBlock()) break;
            }
            if (line == null) return false;

            while ((line = reader.ReadLine()) != null) {
                if (line.IsCommentBlock()) break;
                writer.WriteLine(line);
            }
            if (line == null) return false;
            writer.WriteLine("AMQCNV**  15JAN2024 NHANTT CICS REPLACEMENT                          **");
            writer.WriteLine(line);

            //while ((line = reader.ReadLine()) != null) {
            //    writer.WriteLine(line);
            //    if (line.IsLinkage()) break;
            //}
            //if (line == null) return false;

            //while ((line = reader.ReadLine()) != null) {
            //    if (!line.IsCommentLine()) break;
            //    writer.WriteLine(line);
            //}
            //if (line == null) return false;

            //writer.WriteLine();
            //writer.WriteLine("AMQCNV COPY XCWWDFHQ.");
            //writer.WriteLine();
            //writer.WriteLine(line);

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.IsErrCopy()) break;
                writer.WriteLine(line);
            }
            if (line == null) return true;
            writer.WriteLine("AMQCNV*COPY XCCPERR.");
            while ((line = reader.ReadLine()) != null) {
                writer.WriteLine(line);
            }
            return true;
        }

        private static bool IsCommentLine(this string line) => line.Length <= 6 || "/*".Contains(line[6]);
        private static bool IsCommentBlock(this string line) => line.Length > 50 && line[7..].StartsWith("***************************************************************");
        private static bool IsErrCopy(this string line) => line.Length > 19 && line.IndexOf("XCCPERR", 7) > 7;


        private static bool IsLinkage(this string line) {
            if (line.Length < 20) return false;
            line = line[7..].TrimEnd('.');
            if (line.Length < 14) return false;
            var worlds = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            return worlds.Length == 2 && worlds[0] == "LINKAGE" && worlds[1] == "SECTION";
        }
    }
}