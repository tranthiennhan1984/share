﻿using System.Runtime.CompilerServices;
using System.Text;

namespace MQConvert {
    public static class MQConverter {
        const string remark = "AMQCNV";
        const string descript = "**  15JAN2024 NHANTT CICS REPLACEMENT                          **";
        public static void Main() {
            var output = Environment.GetEnvironmentVariable("OUT_DIR");
            if (string.IsNullOrEmpty(output)) output = "D:\\mserver";

            //if (string.IsNullOrEmpty(output)) output = "W:\\mserver";

            if (!Directory.Exists(output)) {
                Console.WriteLine($"Missing OUT_DIR: '{output}'");
                return;
            }

            var input = Environment.GetEnvironmentVariable("IN_DIR");
            if (string.IsNullOrEmpty(input)) input = "N:\\ut\\server";
            if (!Directory.Exists(input)) {
                Console.WriteLine($"Missing IN_DIR: '{input}'");
                return;
            }

            Directory.Delete(output, true);

            Console.WriteLine("Location\tName\tChanges");
            ConvertCopy(Path.Combine(output, "copy"), Path.Combine(input, "copy"));
            ConvertOnline(Path.Combine(output, "srce"), Path.Combine(input, "srce"));
            ConvertSource(Path.Combine(output, "srce"), Path.Combine(input, "srce"));
        }

        private static void ConvertCopy(string outFolder, string inFolder) {
            if (!Directory.Exists(outFolder)) Directory.CreateDirectory(outFolder);
            var files = Directory.GetFiles(inFolder, "*.cpy");
            for (int i = 0; i < files.Length; i++) {
                var infile = files[i];
                var outfile = Path.Combine(outFolder, Path.GetFileName(infile));
                var count = 0;
                using (var writer = File.CreateText(outfile)) {
                    using (var reader = File.OpenText(infile)) {
                        count = ConvertCopy(writer, reader);
                    }
                }
                if (count < 0) {
                    Console.WriteLine($"{outfile}\t{Path.ChangeExtension(Path.GetFileName(outfile), ".errcbl")}\t{-count}");
                    File.Move(outfile, Path.ChangeExtension(outfile, ".errcbl"), true);
                } else if (count == 0) {
                    File.Delete(outfile);
                } else {
                    Console.WriteLine($"{outfile}\t{Path.GetFileName(outfile)}\t{count}");
                }
            }

        }
        private static int ConvertCopy(TextWriter writer, TextReader reader) {
            var retVal = 0;
            string? line;
            while ((line = reader.ReadLine()) != null) {
                writer.WriteLine(line);
                if (line.IsCommentBlock()) break;
            }
            if (line == null) return -retVal;

            while ((line = reader.ReadLine()) != null) {
                writer.WriteLine(line);
                if (line.IsCommentBlock()) break;
            }
            if (line == null) return -retVal;

            while ((line = reader.ReadLine()) != null) {
                if (line.IsCommentBlock()) break;
                writer.WriteLine(line);
            }
            if (line == null) return -retVal;
            writer.Write(remark);
            writer.WriteLine(descript);
            writer.WriteLine(line);

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine()) {
                    if (line.IsVariable()) return 0;
                    if (line.TrimEnd().EndsWith("DFHEIBLK")) break;
                }
                writer.WriteLine(line);
            }
            if (line == null) return -retVal;
            retVal++;
            writer.Write(remark);
            writer.Write('*');
            var useLine = line[7..].TrimEnd();
            writer.WriteLine(useLine);

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.TrimEnd().EndsWith("DFHCOMMAREA")) break;
                writer.WriteLine(line);
            }
            if (line == null) return -retVal;
            writer.Write(remark);
            writer.Write('*');
            writer.WriteLine(line[7..]);

            bool hasDot = false;
            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.IsWGLOB(out hasDot)) break;
                writer.WriteLine(line);
            }
            if (line == null) return -retVal;
            writer.Write(remark);
            writer.Write('*');
            writer.WriteLine(line[7..]);
            writer.Write(remark);
            writer.Write(' ');
            writer.WriteLine(useLine.Replace("DFHEIBLK", $"WGLOB-GLOBAL-AREA{(hasDot ? "." : "")}"));
            retVal += 4;

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.IsErrCopy()) break;
                writer.WriteLine(line);
            }
            if (line == null) return retVal;
            writer.Write(remark);
            writer.Write('*');
            writer.WriteLine("COPY XCCPERR.");
            retVal++;
            while ((line = reader.ReadLine()) != null) {
                writer.WriteLine(line);
            }
            return retVal;
        }
        private static void ConvertSource(string outFolder, string inFolder) {
            if (!Directory.Exists(outFolder)) Directory.CreateDirectory(outFolder);
            var files = Directory.GetFiles(inFolder, "*.cbl");
            for (int i = 0; i < files.Length; i++) {
                var infile = files[i];
                var outfile = Path.Combine(outFolder, Path.GetFileName(infile));
                var count = 0;
                using (var writer = File.CreateText(outfile)) {
                    using (var reader = File.OpenText(infile)) {
                        count = ConvertSource(writer, reader);
                    }
                }
                if (count < 0) {
                    Console.WriteLine($"{outfile}\t{Path.ChangeExtension(Path.GetFileName(outfile), ".errcbl")}\t{-count}");
                    File.Move(outfile, Path.ChangeExtension(outfile, ".errcbl"), true);
                } else if (count == 0) {
                    File.Delete(outfile);
                } else {
                    Console.WriteLine($"{outfile}\t{Path.GetFileName(outfile)}\t{count}");
                }
            }

        }
        private static int ConvertSource(TextWriter writer, TextReader reader) {
            int retVal = 0;
            string? line;
            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.IsXCWWCRHT()) {
                    writer.Write(remark);
                    writer.Write('*');
                    writer.WriteLine(line[7..]);
                    retVal++;
                } else writer.WriteLine(line);
                if (line.IsCommentBlock()) break;
            }
            if (line == null) return -retVal;

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.IsXCWWCRHT()) {
                    writer.Write(remark);
                    writer.Write('*');
                    writer.WriteLine(line[7..]);
                    retVal++;
                } else writer.WriteLine(line);
                if (line.IsCommentBlock()) break;
            }
            if (line == null) return -retVal;

            while ((line = reader.ReadLine()) != null) {
                if (line.IsCommentBlock()) break;
                if (!line.IsCommentLine() && line.IsXCWWCRHT()) {
                    writer.Write(remark);
                    writer.Write('*');
                    writer.WriteLine(line[7..]);
                    retVal++;
                } else writer.WriteLine(line);
            }
            if (line == null) return -retVal;
            writer.Write(remark);
            writer.WriteLine(descript);
            writer.WriteLine(line);

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.TrimEnd().EndsWith("DFHEIBLK")) break;
                if (!line.IsCommentLine() && line.IsXCWWCRHT()) {
                    writer.Write(remark);
                    writer.Write('*');
                    writer.WriteLine(line[7..]);
                    retVal++;
                } else writer.WriteLine(line);
            }
            if (line == null) return retVal;
            retVal++;
            writer.Write(remark);
            writer.Write('*');
            var useLine = line[7..].TrimEnd();
            writer.WriteLine(useLine);

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.TrimEnd().EndsWith("DFHCOMMAREA")) break;
                writer.WriteLine(line);
            }
            if (line == null) return -retVal;
            writer.Write(remark);
            writer.Write('*');
            writer.WriteLine(line[7..]);

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.TrimEnd().EndsWith("WGLOB-GLOBAL-AREA")) break;
                writer.WriteLine(line);
            }
            if (line == null) return -retVal;
            writer.Write(remark);
            writer.Write('*');
            writer.WriteLine(line[7..]);
            writer.Write(remark);
            writer.Write(' ');
            writer.WriteLine(useLine.Replace("DFHEIBLK", "WGLOB-GLOBAL-AREA"));
            retVal += 4;

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine()) {
                    if (line.IsErrCopy()) break;
                    if (line.IsXCWWCRHT()) {
                        writer.Write(remark);
                        writer.Write('*');
                        writer.WriteLine(line[7..]);
                        continue;
                    }
                }
                writer.WriteLine(line);
            }
            if (line == null) return retVal;
            writer.Write(remark);
            writer.Write('*');
            writer.WriteLine("COPY XCCPERR.");
            retVal++;
            while ((line = reader.ReadLine()) != null) {
                writer.WriteLine(line);
            }
            return retVal;
        }
        private static void ConvertOnline(string outFolder, string inFolder) {
            if (!Directory.Exists(outFolder)) Directory.CreateDirectory(outFolder);
            var files = Directory.GetFiles(inFolder, "*.ccp");
            for (int i = 0; i < files.Length; i++) {
                var infile = files[i];
                var outfile = Path.ChangeExtension(Path.Combine(outFolder, Path.GetFileName(infile)), ".ccp");
                var count = 0;
                using (var writer = File.CreateText(outfile)) {
                    using (var reader = File.OpenText(infile)) {
                        count = ConvertOnline(writer, reader);
                    }
                }
                if (count < 0) {
                    Console.WriteLine($"{outfile}\t{Path.ChangeExtension(Path.GetFileName(outfile), ".errccp")}\t{-count}");
                    File.Move(outfile, Path.ChangeExtension(outfile, ".errccp"), true);
                } else if (count == 0) {
                    File.Delete(outfile);
                } else {
                    Console.WriteLine($"{outfile}\t{Path.GetFileName(outfile)}\t{count}");
                }
            }

        }
        private static int ConvertOnline(TextWriter writer, TextReader reader) {
            var retVal = 1;
            string? line;
            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.IsXCWWCRHT()) {
                    writer.Write(remark);
                    writer.Write('*');
                    writer.WriteLine(line[7..]);
                    ++retVal;
                } else writer.WriteLine(line);
                if (line.IsCommentBlock()) break;
            }
            if (line == null) return -retVal;

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine() && line.IsXCWWCRHT()) {
                    writer.Write(remark);
                    writer.Write('*');
                    writer.WriteLine(line[7..]);
                    ++retVal;
                } else writer.WriteLine(line);
                if (line.IsCommentBlock()) break;
            }
            if (line == null) return -retVal;

            while ((line = reader.ReadLine()) != null) {
                if (line.IsCommentBlock()) break;
                if (!line.IsCommentLine() && line.IsXCWWCRHT()) {
                    writer.Write(remark);
                    writer.Write('*');
                    writer.WriteLine(line[7..]);
                    ++retVal;
                } else writer.WriteLine(line);
            }
            if (line == null) return -retVal;
            writer.Write(remark);
            writer.WriteLine(descript);
            writer.WriteLine(line);

            while ((line = reader.ReadLine()) != null) {
                if (!line.IsCommentLine()) {
                    if (line.IsErrCopy()) break;
                    if (line.IsXCWWCRHT()) {
                        writer.Write(remark);
                        writer.Write('*');
                        writer.WriteLine(line[7..]);
                        ++retVal;
                        continue;
                    }
                }
                writer.WriteLine(line);
            }
            if (line == null) return retVal;
            writer.Write(remark);
            writer.Write('*');
            writer.WriteLine("COPY XCCPERR.");
            ++retVal;
            while ((line = reader.ReadLine()) != null) {
                writer.WriteLine(line);
            }
            return retVal;
        }

        private static bool IsCommentLine(this string line) => line.Length <= 6 || "/*".Contains(line[6]);
        private static bool IsCommentBlock(this string line) => line.Length > 50 && line[7..].StartsWith("***************************************************************");
        private static bool IsErrCopy(this string line) => line.Length > 19 && line.IndexOf("XCCPERR", 7) > 7;
        private static bool IsXCWWCRHT(this string line) => line.Length > 19 && line.IndexOf("XCWWCRHT", 7) > 7;
        private static bool IsVariable(this string line) {
            if (line.Length < 10) return false;
            line = line[7..].TrimStart();
            var index = line.IndexOf(' ');
            if (index < 0) return false;
            return int.TryParse(line[..index], out _);
        }


        private static bool IsWGLOB(this string line, out bool hasDot) {
            hasDot = false;
            if (line.Length < 20) return false;
            line = line[7..].TrimEnd();
            if (hasDot = line.EndsWith('.')) line = line.TrimEnd('.');
            return line.EndsWith("WGLOB-GLOBAL-AREA");
        }
    }
}