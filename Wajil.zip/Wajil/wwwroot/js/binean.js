(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('backbone'), require('jquery')) :
        typeof define === 'function' && define.amd ? define(['exports', 'backbone', 'jquery', 'joint'], factory) :
            (global = global || self, factory(global.binean = {}, global.Backbone, global.$, global.joint));

}(this, function (exports, Backbone, $, joint) {
    'use strict';
    var berequest = function (url, tag, done, req) {
        $.ajax({
            type: 'PUT',
            crossDomain: false,
            url: url,
            contentType: 'application/json',
            dataType: 'json',
            async: false,
            data: JSON.stringify(req), // access in body
        }).done(function (d) {
            if (done) done(d, tag);
        }).fail(function (msg) {
            console.log('FAIL' + msg);
        })
    }
    //#region :: Joint Helpers ::
    class Beevent {
        #triggers = {};
        on(event, callback) {
            var funcs = this.#triggers[event];
            if (!funcs) this.#triggers[event] = funcs = [];
            funcs.push(callback);
        }
        off(event, callback) {
            if (!event) return;
            var funcs = this.#triggers[event];
            if (!funcs) return;
            if (!callback) {
                delete this.#triggers[event];
                return;
            }
            delete funcs[callback];
        }
        raise(event, ...params) {
            var funcs = this.#triggers[event];
            if (!funcs) return;
            var length = funcs.length
            for (var i = 0; i < length; i++) {
                funcs[i](...params);
            }
        }
    }
    class Beselection {
        #highlighterName = 'beselection';
        #selected = 'selected';
        #highlighted = 'highlighted';
        #anim = 'anim';

        #events = new Beevent();
        #paper;

        #selectedElements = [];
        #highlightedCells = [];

        #highlightElement(el, isSelected) {
            let className = isSelected ? this.#selected : this.#highlighted
            V(el.el).addClass(className);
            joint.highlighters.mask.add(el, { selector: 'root' }, this.#highlighterName, {
                deep: true,
                attrs: { 'stroke-width': 3 }
            });
            V(joint.dia.HighlighterView.get(el, this.#highlighterName).el).addClass(className);
        };
        #unhighlightElement(el) {
            joint.dia.HighlighterView.remove(el, this.#highlighterName);
            var vel = V(el.el);
            vel.removeClass(this.#highlighted);
            vel.removeClass(this.#selected);
        }

        #highlightCell(cell, add) {
            if (this.#highlightedCells.includes(cell)) return;
            if (!add) return;
            V(cell.el).addClass(this.#anim);
            this.#highlightedCells.push(cell)
        }
        #unhighlightCell(cell, remove) {
            V(cell.el).removeClass(this.#anim);
            if (!remove) return;
            var index = this.#highlightedCells.indexOf(cell);
            if (index > -1) this.#highlightedCells.splice(index, 1);
        }

        #selectElement(el) {
            var sel = this.getSelected();
            if (sel === el) return;
            this.#unselect();
            if (!el) return;


            this.#highlightElement(el, true);
            this.#selectedElements.splice(0, 0, el);
            var paper = this.#paper.getPaper();
            this.#getNeighbors(el).forEach((cell) => this.#highlightCell(paper.findViewByModel(cell), true));
        }
        #unselect() {
            let selel = this.getSelected();
            if (selel) this.#unhighlightElement(selel);
            this.#selectedElements.splice(0, this.#selectedElements.length);
            this.#unhighlight();
        }
        #unhighlight() {
            var list = this.#highlightedCells;
            var length = list.length;
            for (var i = 0; i < length; i++) {
                let cell = list[i];
                this.#unhighlightCell(cell);
            }
            list.splice(0, length);
        }

        #getNeighbors(el) {
            var graph = this.#paper.assertPageGraph();

            var models = [];
            var stack = [];
            stack.push({ model: el.model, opt: { inbound: true } });
            stack.push({ model: el.model, opt: { outbound: true } });
            while (stack.length > 0) {
                let item = stack.pop();
                let model = item.model;
                let opt = item.opt;
                _.each(graph.getNeighbors(model, opt), function (cell) {
                    if (models.indexOf(cell) >= 0) return;
                    models.push(cell);
                    if (!cell.defaults.isJob) stack.push({ model: cell, opt: opt });
                });
            }
            if (models.indexOf(el.model) < 0) models.push(el.model);

            var retVal = graph.getSubgraph(models, { deep: true });

            var g = this.#paper.getGraph();
            if (g !== graph) {
                _.each(retVal, function (cell) {
                    if (!cell.isLink()) return;
                    var c = g.getCell(cell.id);
                    if (!c) cell.addTo(g);
                });
            }

            return retVal;
        }

        getSelected() {
            if (this.#selectedElements.length == 0) return null;
            return this.#selectedElements[0];
        }
        highlight(cells) {
            this.#unhighlight();
            var item = this;
            _.each(cells, function (cell) {
                item.#highlightCell(cell, true);
            });
        }

        on(event, callback) {
            this.#events.on(event, callback);
        }
        off(event, callback) {
            this.#events.off(event, callback);
        }
        paper(value) {
            if (!value) return this.#paper;
            this.#paper = value;
        }
        selectOn(elm) {
            var paper = this.#paper.getPaper();
            paper.freeze();
            let isElement = elm.model.isElement();
            if (isElement) {
                this.#selectElement(elm);
                if (elm.model.defaults.isJob) {
                    this.#events.raise(this.#selected, elm, elm.model.jobName);
                }
            }
            paper.unfreeze();
        }
        selecteOff() {
            this.#unselect();
        }
    }
    class Bepaper {
        #dx;
        #dy;

        #paper;
        #viewer;
        #page;

        #selection;
        #events = new Beevent();

        constructor(viewer, paper, dx, dy) {
            this.#dx = dx ? dx : 100;
            this.#dy = dy ? dy : 100;
            this.#viewer = viewer;
            this.#paper = paper;
            this.#initalize();
            this.setSelection(new Beselection());
        }
        #initalize() {
            var paper = this.#paper;
            //paper.options.linkView = BelinkView;
            //paper.options.elementView = BecellView;

            paper.on('blank:mousewheel', function (e, x, y, delta) {
                if (!e.altKey) return;
                this.scale(this.scale() + delta * 0.1);
            }.bind(this))

            $(document).on('keydown', function (e) {
                if (e.ctrlKey) {
                    switch (e.keyCode) {
                        case 13:
                            this.fitToContent();
                            break;
                        case 37:
                            if (e.shiftKey) this.#expandRight(true);
                            else this.#expandLeft();
                            break;
                        case 38:
                            if (e.shiftKey) this.#expandBottom(true);
                            else this.#expandTop();
                            break;
                        case 39:
                            if (e.shiftKey) this.#expandLeft(true);
                            else this.#expandRight();
                            break;
                        case 40:
                            if (e.shiftKey) this.#expandTop(true);
                            else this.#expandBottom();
                            break;
                    }
                }
            }.bind(this));

            this.#selectionInitialize(paper);
        }

        minWidth = 1240;
        minHeight = 1754;
        padding = { left: 40, top: 40, right: 40, bottom: 40 };

        getPage() { return this.#page }
        getPaper() { return this.#paper }
        getViewer() { return this.#viewer }
        getGraph() { return this.#paper.model }

        assertPageGraph() {
            if (!this.#page || !this.#page.isLarge()) return this.getGraph();
            return this.#page.getGraph();
        }
        isLarge() {
            if (!this.#page) return false;
            return this.#page.isLarge();
        }

        setSelection(value) {
            if (this.#selection) this.#selection.off('selected', this.#onJobSelected.bind(this));
            if (!value) return this.#selection;
            this.#selection = value;
            value.paper(this);
            this.#selection.on('selected', this.#onJobSelected.bind(this));
        };
        selectCell(cell, scroll) {
            var paper = this.getPaper();
            var view = paper.findViewByModel(cell);
            if (!view) return;
            this.#selection.selectOn(view);
            if (scroll) view.el.scrollIntoView();
        }
        highlight(cells) {
            this.#selection.highlight(cells);
        }

        #expandLeft(isCollapse) {
            var paper = this.#paper;
            var pRect = paper.getArea();
            var origin = paper.options.origin;

            var dx = (isCollapse ? -1 : 1) * this.#dx;
            if (dx < 0 && pRect.width <= this.minWidth) return;

            paper.setDimensions(pRect.width + dx, pRect.height);
            paper.translate(origin.x + dx, origin.y);
            this.#viewer.scrollLeft += dx;
        }
        #expandTop(isCollapse) {
            var paper = this.#paper;
            var pRect = paper.getArea();
            var origin = paper.options.origin;

            var dy = (isCollapse ? -1 : 1) * this.#dy;
            if (dy < 0 && pRect.height <= this.minHeight) return;

            paper.setDimensions(pRect.width, pRect.height + dy);
            paper.translate(origin.x, origin.y + dy);
            this.#viewer.scrollTop += dy;
        }
        #expandRight(isCollapse) {
            var paper = this.#paper;
            var pRect = paper.getArea();
            var dx = (isCollapse ? -1 : 1) * this.#dx;
            if (dx < 0 && pRect.width <= this.minWidth) return;
            paper.setDimensions(pRect.width + dx, pRect.height);
        }
        #expandBottom(isCollapse) {
            var paper = this.#paper;
            var pRect = paper.getArea();
            var dy = (isCollapse ? -1 : 1) * this.#dy;
            if (dy < 0 && pRect.height <= this.minHeight) return;
            paper.setDimensions(pRect.width, pRect.height + dy);
        }

        #selectionInitialize(paper) {

            paper.on("element:pointerclick", (elm) => {
                if (this.#selection && this.#selection.selectOn) this.#selection.selectOn(elm);
            });
            paper.on("blank:pointerclick", (elm) => {
                if (this.#selection && this.#selection.selecteOff) this.#selection.selecteOff(elm);
            });

            paper.svg.prepend(
                V.createSVGStyle(`
                    .joint-highlight-mask.highlighted {
                        fill: #3465FF;
                    }
                    .joint-highlight-mask.selected {
                        fill: #FF4365;
                    }
                    .joint-type-binean-joint-job-link {
                        opacity: 0.2;
                    }
                    .joint-type-binean-joint-job-jcell {
                        opacity: 0.4;
                    }
                    .joint-type-binean-joint-job-jcell.anim {
                        opacity: 1;
                    }
                    .joint-type-binean-joint-job-jcell.selected {
                        opacity: 1;
                    }
                    .joint-type-binean-joint-job-ccell {
                        opacity: 0.2;
                    }
                    .joint-type-binean-joint-job-ccell.anim {
                        opacity: 1;
                    }
                    .joint-type-binean-joint-job-ccell.selected {
                        opacity: 1;
                    }
                    .joint-type-binean-joint-job-link.anim {
                        opacity: 1;
                        stroke-dasharray: 5;
                        stroke-dashoffset: 10;
                        animation: dash 0.5s infinite linear;
                    }
                    @keyframes dash {
                        to {
                            stroke-dashoffset: 0;
                        }
                    }
                `)
            );
        }
        #onJobSelected(...parms) {
            this.#events.raise('job:selected', ...parms);
        }
        on(event, callback) {
            this.#events.on(event, callback);
        }
        off(event, callback) {
            this.#events.off(event, callback);
        }

        scale(s) {
            let paper = this.#paper;
            if (!s) return paper.scale().sx;
            paper.scale(s, s);
            this.fitToContent();
            //let pRect = paper.getArea();
            //paper.setDimensions(pRect.width * s, pRect.height * s);
        }
        correctPageSize() {
            var paper = this.#paper;
            var pRect = paper.getArea();
            if (pRect.width < this.minWidth || pRect.height < this.minHeight) {
                paper.setDimensions(this.minWidth, this.minHeight);
            }
        }
        fitToContent(padding) {
            if (!padding) padding = this.padding;

            let paper = this.#paper;
            let crect = paper.getContentArea();
            let scale = paper.scale();

            let w = Math.max(this.minWidth, Math.ceil(crect.width) + padding.left + padding.right);
            let h = Math.max(this.minHeight, Math.ceil(crect.height) + padding.top + padding.bottom);

            var ox = Math.ceil((w - crect.width) / 2) - crect.x;
            var oy = Math.ceil((h - crect.height) / 2) - crect.y;
            paper.model.translate(ox, oy);

            paper.setDimensions(w * scale.sx, h * scale.sy);
            paper.translate(0, 0);
        }


        loadPage(info) {
            if (!info) return;

            var graph = this.getGraph();
            var paper = this.getPaper();

            paper.freeze();
            graph.clear();
            var page = info.type === 'bejpage'
                ? binean.joint.job.Page.fromJSON(info)
                : binean.joint.job.Page.fromBinean(info);
            this.#page = page;
            page.addTo(graph);
            paper.unfreeze();
            this.fitToContent();
        }

        static createPaper(pageElememt, width, height) {
            if (!width) width = 1754;
            if (!height) height = 11240;

            var namespace = joint.shapes;
            return new joint.dia.Paper({
                el: pageElememt,
                model: new joint.dia.Graph({}, { cellNamespace: namespace }),
                width: width,
                height: height,
                gridSize: 10,
                drawGrid: {
                    name: 'doubleMesh',
                    args: [
                        { color: '#FBFBFB', thickness: 1 }, // settings for the primary mesh
                        { color: '#E8E8E8', scaleFactor: 5, thickness: 1 } //settings for the secondary mesh
                    ],
                    update: function (el, opt) {
                        var d;
                        var width = opt.width;
                        var height = opt.height;
                        var thickness = opt.thickness;

                        if (width - thickness >= 0 && height - thickness >= 0) {
                            d = ['M', width, 0, 'H0 M0 0 V0', height].join(' ');
                        } else {
                            d = 'M 0 0 0 0';
                        }
                        V(el).attr({ 'd': d, stroke: opt.color, 'stroke-width': opt.thickness });
                    }
                },
                interactive: true,
                //async: true,
                cellViewNamespace: namespace
            });
        }
    }
    class TextUtil {
        #svgDocument;
        #textElement;

        constructor(styles) {
            this.initialize(styles);
        }

        initialize(styles) {
            if (this.#svgDocument) return;
            this.#svgDocument = V('svg').node;
            document.body.appendChild(this.#svgDocument);
            if (styles) this.applyStyle(styles);
        }

        finalize() {
            if (!this.#svgDocument) return;
            document.body.removeChild(this.#svgDocument);
        }
        applyStyle(styles) {
            if (!this.#svgDocument) return;
            if (this.#textElement) this.#svgDocument.removeChild(this.#textElement);
            this.#textElement = V('<text></text>').attr(styles || {}).node;
            this.#svgDocument.appendChild(this.#textElement);

        }
        getTextBBox(text) {
            if (!this.#textElement) return;
            var textElement = this.#textElement;
            textElement.textContent = text;
            return textElement.getBBox();
        }
    }
    //#endregion

    //var BelinkView = joint.dia.LinkView.extend({
    //    init: function () {
    //        joint.dia.LinkView.prototype.init.apply(this, arguments);
    //        var model = this.model;
    //        this.listenTo(model, 'change:anim', this.updateType);
    //    },
    //    render: function () {
    //        joint.dia.LinkView.prototype.render.apply(this, arguments);
    //        this.updateAnim();
    //    },
    //    updateAnim: function () {
    //        var model = this.model;
    //        var anim = model.attr('anim');
    //        var vline = V(this.findBySelector('line')[0]);
    //        if (anim) vline.addClass('anim');
    //        else vline.removeClass('anim')
    //    },
    //});

    //var BecellView = joint.dia.ElementView.extend({
    //    init: function () {
    //        joint.dia.ElementView.prototype.init.apply(this, arguments);
    //        var model = this.model;

    //        //this.listenTo(model, 'change:anim', this.updateType);
    //    },
    //    render: function () {
    //        joint.dia.ElementView.prototype.render.apply(this, arguments);
    //        //V(this.findBySelector('line')[0]).addClass('binean-link');
    //        //this.updateAnim();
    //    },
    //});
    //#region ::Cells::
    var Belink = joint.shapes.standard.Link.define('binean.joint.job.Link', {}, {},
        {
            fromBinean: function (page, link) {
                var jobs = page.getJobs();
                var source = jobs[link.From];
                var target = jobs[link.To];

                var retVal = new this({
                    source: { id: source.id, port: 'out' },
                    target: { id: target.id, port: 'in' },
                    router: { name: 'metro' }
                    //connector: { name: 'rounded' },
                    //router: { name: 'orthogonal' }

                });

                var ltype = link.LinkType;
                if (!ltype) ltype = 'o';

                var color = 'black';
                var strokeDasharray = null;

                if (ltype == 's') color = 'green';
                else if (ltype == 't') color = 'red';
                else if (ltype == 'f') color = 'orange';
                else if (ltype == 'd') color = 'blue';

                if (link.ReferenceType != '') {
                    strokeDasharray = '5 10';
                }

                retVal.attr({
                    linkType: ltype,
                    line: {
                        sourceMarker: null,
                        'stroke-width': 1,
                        stroke: color,
                        'stroke-dasharray': strokeDasharray,
                        targetMarker: {
                            type: 'path',
                            'stroke-width': 1,
                            stroke: color,
                            fill: color,
                            d: 'M 13 -3 0 0 13 3 8 0 Z',
                        }
                    }
                });
                return retVal;
            }
        });
    var Becond = joint.shapes.standard.Ellipse.define('binean.joint.job.CCell',
        {
            attrs: {
                root: { highlighterSelector: 'body' },
                body: { strokeWidth: 1 }
            },
        }, {},
        {
            fromBinean: function (cell, markup) {
                var retVal = new this({
                    ports: {
                        groups: {
                            'in': { position: { name: 'top' }, markup: markup },
                            'out': { position: { name: 'bottom' }, markup: markup },
                        }
                    }
                });
                var ctype = cell.CellType;

                retVal.resize(20, 20);
                retVal.attr({
                    label: {
                        text: ctype == 'And' ? '&' : '|',
                        fontSize: 10
                    }
                });
                //retVal.jobName = cell.Name;

                retVal.addPorts([{ group: 'in', id: 'in', }, { group: 'out', id: 'out', }]);
                return retVal;
            }
        });
    var Bejob = joint.shapes.standard.Rectangle.define('binean.joint.job.JCell',
        {
            attrs: {
                body: {
                    rx: 8,
                    strokeWidth: 1,
                },
            },
            isJob: true,
        },
        {
            set: function (attrs, opt) {
                if (attrs.isJob) this.isJob = attrs.isJob;
                if (attrs.jobName) this.jobName = attrs.jobName;
                joint.shapes.standard.Rectangle.prototype.set.call(this, attrs, opt);
            }
        },
        {
            fromBinean: function (cell, util, markup) {
                var retVal = new this({
                    ports: {
                        groups: {
                            'in': { position: { name: 'top' }, markup: markup },
                            'out': { position: { name: 'bottom' }, markup: markup },
                        }
                    },
                    jobName: cell.Name,
                });
                var stroke = '#AEAEAE';
                var fill = undefined;
                var color = '#AEAEAE'

                var ctype = cell.CellType;
                if (ctype == 'Job') {
                    fill = 'white';
                    color = 'black';
                    stroke = 'black';

                    var jsts = cell.Status.Status;
                    if (jsts == 'SUCCESS') stroke = 'green';
                    else if (jsts == 'TERMINATED') stroke = 'red';
                    else if (jsts == 'FAIL') stroke = 'orange';
                    else if (jsts == 'ON_NOEXEC') stroke = 'blue';
                    else if (jsts == 'INACTIVE') fill = '#DFDFDF';
                }

                var rx = 12;
                var jtype = cell.JobType;
                if (jtype == 'BOX') rx = 0;
                else if (jtype == 'FW') rx = 30;

                retVal.attr({
                    root: {
                        highlighterSelector: 'body',
                    },
                    body: {
                        rx: rx,
                        fill: fill,
                        stroke: stroke,
                    },
                    label: {
                        text: cell.Name,
                        fill: color
                    },
                });

                var bbox;
                if (!util) {
                    util = new TextUtil(retVal.attr().label);
                    bbox = util.getTextBBox(cell.Name)
                    util.finalize();
                } else {
                    util.applyStyle(retVal.attr().label);
                    bbox = util.getTextBBox(cell.Name)
                }

                var w = Math.floor((bbox.width + 10) / 20 + 1) * 20;
                if (bbox) retVal.resize(w, 30);

                retVal.addPorts([{ group: 'in', id: 'in', }, { group: 'out', id: 'out', }]);
                return retVal;
            },

        });
    class Bepage {
        #jobs = {};
        #cells = {};
        #links = [];

        #graph;

        #processList = [];

        padding = 15;
        getJobs() { return this.#jobs; }

        isLarge() { return this.#links.length > 700; }
        getGraph() {
            if (this.#graph) return this.#graph;
            var graph = new joint.dia.Graph({}, { cellNamespace: joint.shapes });
            this.#addTo(graph, true);
            return this.#graph = graph;
        }

        getProcessCount() { return this.#processList.length; }
        getProcessTime(value) {
            if (value > 0 && value <= this.#processList.length) return this.#processList[value - 1];
        }
        getProcess(time) {
            var retVal = [];
            var jobs = this.#jobs;
            for (const jn in jobs) {
                var job = jobs[jn];
                var sts = job.Status;
                if (!sts) continue;
                if (sts.Status === 'INACTIVE') continue;
                if (sts.Start <= time && sts.End >= time) {
                    retVal.push(job.id);
                }
            }
            return retVal;
        }
        timeToProcess(time) {
            var list = this.#processList;
            var length = list.length;
            for (var i = 0; i < length; i++) {
                if (list[i] >= time) return i + 1;
            }
            return length;
        }

        #loadBejobs(becells, cells, items, utils, portMarkup) {
            for (const cn in items) {
                var item = items[cn];
                let c = (item.CellType == 'And' || item.CellType == 'Or')
                    ? Becond.fromBinean(item, portMarkup) : Bejob.fromBinean(item, utils, portMarkup);
                c.belevel = item.Level;
                c.jobName = item.Name;
                cells[c.id] = c;
                item.id = c.id;
                becells[cn] = item;
                var sts = item.Status;
                if (sts) {
                    sts.Start = Date.parse(sts.Start);
                    sts.End = Date.parse(sts.End);
                }
            }
        }
        #loadBelinks(links, belinks) {
            for (const cn in belinks) {
                var l = Belink.fromBinean(this, belinks[cn]);
                links.push(l);
            }
        }
        #addTo(graph, all) {
            _.each(this.#cells, function (cell) {
                cell.addTo(graph);
            });

            if (!all && this.isLarge()) return;

            _.each(this.#links, function (link) {
                link.addTo(graph);
            });
        }

        findCellByJobName(name) {
            if (!this.#jobs[name]) return;
            var id = this.#jobs[name].id;
            return this.#cells[id];
        }
        getJobByName(name) {
            return this.#jobs[name];
        }

        toJSON() {
            return {
                type: 'bejpage',
                jobs: this.#jobs,
                graph: this.getGraph().toJSON()
            };
        }
        addTo(graph) {
            return this.#addTo(graph);
        }

        remove() {
            _.each(this.#cells, function (cell) {
                cell.remove();
            });
        }

        #bineanlayout(layout) {
            var length = layout.length;
            var x = 0;
            for (var i = 0; i < length; i++) {
                var table = layout[i];
                x = this.#btlayout(table, 60, 80, x);
            }
        }
        #btlayout(table, dx, dy, x) {
            var opt = {
                dx: dx,
                dy: dy,
                maxWidth: 0,
                rows: [],
                widths: []
            }
            this.#bvlayout(table, opt);
            return this.#bhlayout(opt, x);
        }
        #bvlayout(table, opt) {
            var length = table.length;
            var y = 0;
            for (var i = 0; i < length; i++) {
                opt.rows.push([]);
                opt.widths.push(0);
                y += Math.ceil(this.#brlayout(table[i], opt, i, y) + opt.dy);
            }
        }
        #brlayout(items, opt, index, y) {
            var row = opt.rows[index];
            var width = opt.widths[index];

            var height = 30;
            var length = items.length;
            for (var i = 0; i < length; i++) {
                var cell = this.findCellByJobName(items[i]);
                if (!cell) continue;

                row.push(cell);
                cell.position(width + opt.dx, y);
                var box = cell.getBBox();
                opt.widths[index] = (width += Math.ceil(opt.dx + box.width));
                if (width > opt.maxWidth) opt.maxWidth = width;

                let h = box.height + cell.belevel * (20 + opt.dy);
                if (h > height) height = h;
            }
            var oy = height - 30;
            if (oy > 0) {
                var length = items.length;
                for (var i = 0; i < length; i++) {
                    var cell = this.findCellByJobName(items[i]);
                    if (!cell) continue;
                    var pos = cell.position();
                    cell.position(pos.x, pos.y + oy);
                }
            }
            return height;
        }
        #bhlayout(opt, x) {
            var rows = opt.rows;
            var maxWidth = opt.maxWidth - opt.dx;
            var length = rows.length;
            for (var i = 0; i < length; i++) {
                var ox = Math.ceil(x + (maxWidth - opt.widths[i]) / 2);
                var cells = rows[i];
                var count = cells.length;
                for (var j = 0; j < count; j++) {
                    var cell = cells[j];
                    var pos = cell.position();
                    cell.position(pos.x + ox, pos.y)
                }
            }
            return opt.maxWidth + x;
        }

        #bineanlayout2(layout) {
            for (var name in layout) {
                var cell = this.findCellByJobName(name);
                if (!cell) continue;
                var box = cell.getBBox();
                this.#blayout2(layout[name], Math.ceil(box.x + box.width / 2), Math.ceil(box.y), 80, 80);
            }
        }
        #blayout2(names, x, y, dx, dy) {
            y -= dy;
            var row = [];
            var width = 0;
            var length = names.length;
            if (length % 2 == 1) x -= 40;
            for (var i = 0; i < length; i++) {
                var name = names[i];
                var cell = this.findCellByJobName(name);
                if (!cell) continue;
                row.push(cell);
                cell.position(x + width, y);
                var box = cell.getBBox();
                width += box.width + dx;
            }
            var ox = -Math.ceil((width -= dx) / 2);

            var length = row.length;
            for (var i = 0; i < length; i++) {
                var cell = row[i];
                var pos = cell.position();
                cell.position(pos.x + ox, pos.y)
            }
        }

        #loadProcess() {
            var jobs = this.#jobs;
            var list = [];
            for (var name in jobs) {
                var job = jobs[name];
                if (job.CellType === 'RJob') continue;
                var sts = job.Status;
                if (!sts) continue;
                if (sts.Status === 'INACTIVE') continue;
                var start = sts.Start;
                if (list.indexOf(start) < 0) list.push(start);
                var end = sts.End;
                if (list.indexOf(end) < 0) list.push(end);
            }
            this.#processList = list.sort();
        }

        static fromBinean(page) {
            var retVal = new this();
            if (!page) return retVal;

            var portMarkup = [{
                tagName: 'rect',
                attributes: {
                    r: 0,
                    opacity: 0
                }
            }];
            var utils = new TextUtil();
            retVal.#loadBejobs(retVal.#jobs, retVal.#cells, page.Cells, utils, portMarkup);
            retVal.#loadBelinks(retVal.#links, page.Links);
            utils.finalize();

            retVal.#bineanlayout(page.Layout);
            retVal.#bineanlayout2(page.Layout2);
            var jobs = retVal.#jobs;
            _.each(page.Rcells, function (rc) {
                var job = jobs[rc.CellName];
                if (job) rc.id = job.id
                jobs[rc.Name] = rc;
                var sts = rc.Status;
                if (sts) {
                    sts.Start = Date.parse(sts.Start);
                    sts.End = Date.parse(sts.End);
                }
            });

            retVal.#loadProcess();
            return retVal;
        }
        static fromJSON(info) {
            var retVal = new this();
            retVal.#jobs = info.jobs;
            var graph = new joint.dia.Graph({}, { cellNamespace: joint.shapes });
            graph.fromJSON(info.graph);

            var links = retVal.#links;
            var cells = retVal.#cells;
            _.each(graph.getCells(), function (cell) {
                if (cell.isLink()) links.push(cell);
                else cells[cell.id] = cell;
            });

            retVal.#loadProcess();
            return retVal;
        }
    };
    //#endregion

    //#region :: namespaces ::
    var bejob = ({
        Page: Bepage,
        Link: Belink,
        //BCell: Bebox,
        JCell: Bejob,
        CCell: Becond,
    });
    var bejoint = ({
        Selection: Beselection,
        Paper: Bepaper,
        job: bejob,
    });
    binean.Event = Beevent;
    binean.joint = bejoint;
    binean.request = berequest;
    //#endregion

    return binean;
}));
