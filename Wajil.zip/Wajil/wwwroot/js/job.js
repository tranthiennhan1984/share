﻿var _selenv;
var _selPage;

var bepaper = new binean.joint.Paper(document.getElementById("main"), binean.joint.Paper.createPaper(document.getElementById("paper"), 800, 1200));
bepaper.on('job:selected', on_job_selected);

refreshPage();

function refreshPage() {
    var pathArray = window.location.pathname.split('/');
    if (pathArray.length < 3) return;
    _selenv = pathArray[2];
    if (pathArray.length < 4) return;
    _selPage = pathArray[3];
    loadPages(_selenv);
}
function loadPages(env) {
    const func = function (pages) {
        var selValue = _selPage;
        var el = document.getElementById("bi_page");

        el.innerHTML = "";
        var length = pages.length;
        if (length == 0) {
            loadPage();
            return;
        }

        var opts = el.options;
        var selIndex = -1;
        for (var i = 0; i < length; i++) {
            var optn = document.createElement("OPTION");
            var text = pages[i];
            if (selValue && text == selValue) selIndex = i;
            optn.text = text;
            optn.value = text;
            opts.add(optn);
        }
        el.selectedIndex = selIndex;
        on_page_changed();
    }
    binean.request("/api/job/page_list", null, func, env);
}

function on_env_changed() {
}
function on_page_changed() {
    var f = function () {
        var wse = document.getElementById("bi_page");
        if (wse.options.length == 0) return undefined;
        var si = wse.selectedIndex;
        if (si < 0) return _selPage;
        return wse.options[si].value;
    }
    var selPage = f();
    if (!selPage) return;
    _selPage = selPage;
    loadPage();
}
function on_job_selected(el, name) {
    var bi_job = document.getElementById("bi_job");
    bi_job.value = name;

    var page = bepaper.getPage();
    var job = page.getJobByName(name);
    propertyTable(job);
}

function loadPage(info) {
    if (!info) {
        info = {
            Env: _selenv,
            Page: _selPage
        }
    }
    const func = function (model) {
        if (!model) return;
        bepaper.loadPage(model);
    }
    binean.request("/api/job/page_load", null, func, info);
}
function savePage() {
    var page = bepaper.getPage();
    if (!page) return;

    var info = {
        Env: _selenv,
        Page: _selPage,
        Content: JSON.stringify(bepaper.getPage().toJSON())
    };
    binean.request("/api/job/page_save", null, null, info);
}

function getTable(id) {
    var table = document.getElementById(id);
    if (table) return table;
    var panel = document.getElementById("panel");
    var div = document.createElement('DIV');
    div.classList.add('container');
    panel.appendChild(div);
    div.appendChildhi 

    table = document.createElement("TABLE");
    table.id = id;
    table.classList.add('table');
    table.classList.add('table-bordered');
    div.appendChild(table);
    return table;
}
function removeTable(id) {
    var table = document.getElementById(id);
    if (!table) return;
    var panel = document.getElementById("panel");
    panel.removeChild(table);
}

function propertyTable(job) {
    const table_id = 'tb_job_prop';
    removeTable(table_id);
    if (job == undefined) return;
    var table = getTable(table_id);

    var header = table.createTHead();
    var row = header.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "<b>Attribute Name</b>";
    cell.scope = 'col';
    cell = row.insertCell()
    cell.innerHTML = "<b>Attribute Value</b>";

    var body = table.createTBody();
    row = body.insertRow();
    cell = row.insertCell();
    cell.innerHTML = "Name";
    cell = row.insertCell();
    cell.innerHTML = job.Name;

    if (job.Description != undefined) {
        row = body.insertRow();
        cell = row.insertCell();
        cell.innerHTML = "Description";
        cell = row.insertCell();
        cell.innerHTML = job.Description;
    }
    if (job.BoxName != undefined) {
        row = body.insertRow();
        cell = row.insertCell();
        cell.innerHTML = "Box Name";
        cell = row.insertCell();
        //cell.innerHTML = "<span class='link' onclick='javascript:selectNode(\"" + job.BoxName + "\");'>" + job.box_name + "</span>";
        cell.innerHTML = job.BoxName;
    }
    if (job.BoxSuccess !== undefined) {
        row = body.insertRow();
        cell = row.insertCell();
        cell.innerHTML = "Box Success";
        cell = row.insertCell();
        cell.innerHTML = job.BoxSuccess;
    }
    if (job.WatchFile !== undefined) {
        row = body.insertRow();
        cell = row.insertCell();
        cell.innerHTML = "Watch file";
        cell = row.insertCell();
        cell.innerHTML = job.WatchFile;
    }
    if (job.Command !== undefined) {
        row = body.insertRow();
        cell = row.insertCell();
        cell.innerHTML = "Command";
        cell = row.insertCell();
        cell.innerHTML = job.Command;
    }
    if (job.Condition !== undefined) {
        row = body.insertRow();
        cell = row.insertCell();
        cell.innerHTML = "Condition";
        cell = row.insertCell();
        cell.innerHTML = job.Condition;
    }
    if (job.Status != undefined) {
        row = body.insertRow();
        cell = row.insertCell();
        cell.innerHTML = "Status";
        cell = row.insertCell();
        cell.innerHTML = job.Status;
    }
}