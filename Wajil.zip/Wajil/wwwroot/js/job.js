﻿var _selenv;
var _selPage;

var bepaper = new binean.joint.Paper(document.getElementById("main"), binean.joint.Paper.createPaper(document.getElementById("paper"), 800, 1200));
bepaper.on('job:selected', on_job_selected);

refreshPage();

function refreshPage() {
    var pathArray = window.location.pathname.split('/');
    if (pathArray.length < 3) return;
    _selenv = pathArray[2];
    if (pathArray.length < 4) return;
    _selPage = pathArray[3];
    loadPages(_selenv);
}
function loadPages(env) {
    const func = function (pages) {
        var selValue = _selPage;
        var el = document.getElementById("bi_page");

        el.innerHTML = "";
        var length = pages.length;
        if (length == 0) {
            loadPage();
            return;
        }

        var opts = el.options;
        var selIndex = -1;
        for (var i = 0; i < length; i++) {
            var optn = document.createElement("OPTION");
            var text = pages[i];
            if (selValue && text == selValue) selIndex = i;
            optn.text = text;
            optn.value = text;
            opts.add(optn);
        }
        el.selectedIndex = selIndex;
        on_page_changed();
    }
    binean.request("/api/job/page_list", null, func, env);
}

function on_env_changed() {
}
function on_page_changed() {
    var f = function () {
        var wse = document.getElementById("bi_page");
        if (wse.options.length == 0) return undefined;
        var si = wse.selectedIndex;
        if (si < 0) return _selPage;
        return wse.options[si].value;
    }
    var selPage = f();
    if (!selPage) return;
    _selPage = selPage;
    loadPage();
}
function on_job_selected(el, name) {
    var bi_job = document.getElementById("bi_job");
    bi_job.value = name;

    var page = bepaper.getPage();
    var job = page.getJobByName(name);
    if (!job) return;

    var sts = job.Status;
    if (sts.Start) {
        var brg_process = document.getElementById("brg_process");
        var time = sts.Start;
        brg_process.value = page.timeToProcess(sts.Start);
        var lbl_process = document.getElementById("lbl_process");
        if (time) {
            lbl_process.innerHTML = ['Process time: ', toTimeString(time)].join('');
        } else {
            lbl_process.innerHTML = 'Process time';
        }
    }

    propertyTable(job);
    condTable(job);
    dependTable(job);
}
function on_process_changed(e) {
    var brg_process = document.getElementById("brg_process");
    var page = bepaper.getPage();

    var time = page.getProcessTime(parseInt(brg_process.value));
    var lbl_process = document.getElementById("lbl_process");
    if (time || time === 0) {
        lbl_process.innerHTML = ['Process time: ', toTimeString(time)].join('');
    } else {
        lbl_process.innerHTML = 'Process time';
    }

    var jobs = page.getProcess(time);
    var graph = page.getGraph();
    var paper = bepaper.getPaper();
    var cells = [];
    var length = jobs.length;
    for (var i = 0; i < length; i++) {
        cells.push(paper.findViewByModel(graph.getCell(jobs[i])));
    }
    bepaper.highlight(cells);
}

function loadPage(info) {
    if (!info) {
        info = {
            Env: _selenv,
            Page: _selPage
        }
    }
    const func = function (model) {
        if (!model) return;
        bepaper.loadPage(model);

        var brg_process = document.getElementById("brg_process");
        var page = bepaper.getPage();
        brg_process.min = 0;
        brg_process.value = 0;
        brg_process.max = page.getProcessCount() + 1;
    }
    binean.request("/api/job/page_load", null, func, info);
}
function savePage() {
    var page = bepaper.getPage();
    if (!page) return;

    var info = {
        Env: _selenv,
        Page: _selPage,
        Content: JSON.stringify(bepaper.getPage().toJSON())
    };
    binean.request("/api/job/page_save", null, null, info);
}
function selectJob(name) {
    if (!name) {
        var bi_job = document.getElementById("bi_job");
        name = bi_job.value;
    }
    if (!name) return;
    var page = bepaper.getPage();
    var cell = page.findCellByJobName(name);
    if (!cell) return;
    bepaper.selectCell(cell, true);
}

function getTable(id) {
    var table = document.getElementById(id);
    if (table) return table;
    var panel = document.getElementById("job_card");

    table = document.createElement("TABLE");
    panel.appendChild(table);
    table.id = id;
    table.classList.add('table');
    table.classList.add('table-bordered');
    table.classList.add('h6');
    table.classList.add('small');
    return table;
}
function removeTable(id) {
    var div = document.getElementById(id);
    if (!div) return;
    var panel = document.getElementById("job_card");
    panel.removeChild(div);
}

function propertyTable(job) {
    const table_id = 'tb_job_prop';
    removeTable(table_id);
    if (!job) return;
    var table = getTable(table_id);

    var header = table.createTHead();
    var row = header.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "<b>Attribute Name</b>";
    cell.scope = 'col';
    cell = row.insertCell()
    cell.innerHTML = "<b>Attribute Value</b>";

    var body = table.createTBody();
    row = body.insertRow();
    cell = row.insertCell();
    cell.innerHTML = "Name";
    cell = row.insertCell();
    cell.innerHTML = job.Name;

    if (job.Status) {
        row = body.insertRow();
        cell = row.insertCell();
        cell.innerHTML = "Status";
        cell = row.insertCell();
        var sts = job.Status;
        var status = sts.Status;
        var diff = sts.End - sts.Start;
        if (diff || diff === 0) {
            diff /= 1000;
            var h = Math.floor(diff / 3600);
            diff = diff % 3600
            var m = Math.floor(diff / 60);
            var s = diff % 60;
            status = [status, ' [', ("0" + h).slice(-2), ':', ("0" + m).slice(-2), ':', ("0" + s).slice(-2), ']'].join('');
        }
        cell.innerHTML = [status, toTimeString(sts.Start), toTimeString(sts.End)].join('</br>');
    }
    if (job.Description) {
        row = body.insertRow();
        cell = row.insertCell();
        cell.innerHTML = "Description";
        cell = row.insertCell();
        cell.innerHTML = job.Description;
    }
    if (job.BoxName) {
        row = body.insertRow();
        cell = row.insertCell();
        cell.innerHTML = "Box Name";
        cell = row.insertCell();
        //cell.innerHTML = "<span class='link' onclick='javascript:selectNode(\"" + job.BoxName + "\");'>" + job.box_name + "</span>";
        cell.innerHTML = job.BoxName;
    }
    if (job.BoxSuccess) {
        row = body.insertRow();
        cell = row.insertCell();
        cell.innerHTML = "Box Success";
        cell = row.insertCell();
        cell.innerHTML = job.BoxSuccess;
    }
    if (job.WatchFile) {
        row = body.insertRow();
        cell = row.insertCell();
        cell.innerHTML = "Watch file";
        cell = row.insertCell();
        cell.innerHTML = job.WatchFile;
    }
    if (job.Command) {
        row = body.insertRow();
        cell = row.insertCell();
        cell.innerHTML = "Command";
        cell = row.insertCell();
        cell.innerHTML = job.Command;
    }
    if (job.Condition) {
        row = body.insertRow();
        cell = row.insertCell();
        cell.innerHTML = "Condition";
        cell = row.insertCell();
        cell.innerHTML = job.Condition;
    }
}
function condTable(job) {
    const table_id = 'tb_job_cond';
    removeTable(table_id);
    if (!job) return;
    var table = getTable(table_id);

    var scons = job.JobConditionList;
    if (!scons) return;
    var lenght = scons.length;
    if (lenght == 0) return;

    var header = table.createTHead();
    var row = header.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "<b>Condition</b>";
    cell.scope = 'col';
    cell = row.insertCell()
    cell.innerHTML = "<b>Expected</b>";
    cell.scope = 'col';
    cell = row.insertCell()
    cell.innerHTML = "<b>Value</b>";
    cell.scope = 'col';
    cell = row.insertCell()
    cell.innerHTML = "<b>Pass</b>";
    cell.scope = 'col';

    var body = table.createTBody();
    for (var i = 0; i < lenght; i++) {
        var scon = scons[i];
        row = body.insertRow();
        cell = row.insertCell();
        cell.innerHTML = "<span class='link' onclick='javascript:selectJob(\"" + scon.Name + "\");'>" + scon.Name + "</span>";
        cell = row.insertCell();
        cell.innerHTML = scon.Expected;
        cell = row.insertCell();
        cell.innerHTML = scon.Status;
        cell = row.insertCell();
        cell.innerHTML = scon.IsPass;
    }
}
function dependTable(job) {
    const table_id = 'tb_job_depend';
    removeTable(table_id);
    if (!job) return;
    var table = getTable(table_id);

    var depends = job.DependList;
    if (!depends) return;
    var lenght = depends.length;
    if (lenght == 0) return;

    var header = table.createTHead();
    var row = header.insertRow(0);
    var cell = row.insertCell(0);
    cell.innerHTML = "<b>Dependent Job</b>";
    cell.scope = 'col';
    cell = row.insertCell()
    cell.innerHTML = "<b>Expected</b>";
    cell.scope = 'col';
    cell = row.insertCell()
    cell.innerHTML = "<b>Status</b>";
    cell.scope = 'col';
    cell = row.insertCell()
    cell.innerHTML = "<b>Pass</b>";
    cell.scope = 'col';

    var body = table.createTBody();
    for (var i = 0; i < lenght; i++) {
        var depend = depends[i];
        row = body.insertRow();
        cell = row.insertCell();
        cell.innerHTML = "<span class='link' onclick='javascript:selectJob(\"" + depend.Name + "\");'>" + depend.Name + "</span>";
        cell = row.insertCell();
        cell.innerHTML = depend.Expected;
        cell = row.insertCell();
        cell.innerHTML = depend.Status;
        cell = row.insertCell();
        cell.innerHTML = depend.IsPass;
    }
}

function toTimeString(time) {
    return new Date(time).toISOString().replace('T', ' ').replace('.000Z', '');
}