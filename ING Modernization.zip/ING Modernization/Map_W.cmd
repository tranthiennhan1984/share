@echo off
echo ----------------------------------------------
echo Map drive W
subst W: /d
subst W: "%cd%"
rem echo ----------------------------------------------