      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSOMTIMR.

AMQCNV*COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  XSOMTIMR                                         **
      **  REMARKS:  TIME THE TIMER                                   **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
026766**  6.6       PERFORMANCE MONITORING                           **
AMQCNV**  15JAN2024 NHANTT CICS REPLACEMENT                          **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSOMTIMR'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       01 WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.

       01  WS-WORK-AREAS.
           05  I                                PIC S9(08)
                                                COMP-3.
           05  WS-TEST-CNT                      PIC S9(08)
                                                COMP-3.

       LINKAGE SECTION.
       01  DFHCOMMAREA.
           05  FILLER      PIC X(1)      OCCURS 640 TO 32767
                                         DEPENDING ON EIBCALEN.

      ********************
       PROCEDURE DIVISION.
      ********************

      *-------------
       0000-MAINLINE.
      *-------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  1000-TIME-LOOP
               THRU 1000-TIME-LOOP-X.

           PERFORM  2000-TIME-TIMER
               THRU 2000-TIME-TIMER-X.

           PERFORM  3000-TIME-LOG-WRITE
               THRU 3000-TIME-LOG-WRITE-X.

           PERFORM  4000-TIME-LOG
               THRU 4000-TIME-LOG-X.

AMQCNV*    EXEC CICS RETURN
AMQCNV*    END-EXEC.

       0000-MAINLINE-X.
           GOBACK.

      *----------------------------
       1000-TIME-LOOP.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           MOVE 'LOOP'                 TO WTIMR-TASK-ID.

           PERFORM  TIMR-1000-ENTRY-TIME
               THRU TIMR-1000-ENTRY-TIME-X.

           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL I > WS-TEST-CNT

               MOVE I                  TO WTIMR-STAT-LEVEL

           END-PERFORM.

           PERFORM  TIMR-4000-EXIT-TIME
               THRU TIMR-4000-EXIT-TIME-X.

       1000-TIME-LOOP-X.
           EXIT.

      *----------------------------
       2000-TIME-TIMER.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           MOVE 'GTTI'                 TO WTIMR-TASK-ID.

           PERFORM  TIMR-1000-ENTRY-TIME
               THRU TIMR-1000-ENTRY-TIME-X.

           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL I > WS-TEST-CNT

               PERFORM  TIMR-0000-GET-TIME
                   THRU TIMR-0000-GET-TIME-X

               MOVE I                  TO WTIMR-STAT-LEVEL

           END-PERFORM.

           PERFORM  TIMR-4000-EXIT-TIME
               THRU TIMR-4000-EXIT-TIME-X.

       2000-TIME-TIMER-X.
           EXIT.

      *----------------------------
       3000-TIME-LOG-WRITE.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           MOVE 'WRIT'                 TO WTIMR-TASK-ID.
           PERFORM  TIMR-1000-ENTRY-TIME
               THRU TIMR-1000-ENTRY-TIME-X.

           MOVE SPACE                  TO WTIMR-TASK-ID.

           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL I > WS-TEST-CNT

               PERFORM  TIMR-5000-LOG-TIME
                   THRU TIMR-5000-LOG-TIME-X

               MOVE I                  TO WTIMR-STAT-LEVEL

           END-PERFORM.

           MOVE 'WRIT'                 TO WTIMR-TASK-ID.
           PERFORM  TIMR-4000-EXIT-TIME
               THRU TIMR-4000-EXIT-TIME-X.

       3000-TIME-LOG-WRITE-X.
           EXIT.

      *----------------------------
       4000-TIME-LOG.
      *----------------------------

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           MOVE 'LOG'                  TO WTIMR-TASK-ID.
           PERFORM  TIMR-1000-ENTRY-TIME
               THRU TIMR-1000-ENTRY-TIME-X.

           MOVE SPACE                  TO WTIMR-TASK-ID.

           PERFORM
               VARYING I FROM 1 BY 1
               UNTIL I > WS-TEST-CNT

               PERFORM  TIMR-4000-EXIT-TIME
                   THRU TIMR-4000-EXIT-TIME-X

               MOVE I                  TO WTIMR-STAT-LEVEL

           END-PERFORM.

           MOVE 'LOG'                  TO WTIMR-TASK-ID.
           PERFORM  TIMR-4000-EXIT-TIME
               THRU TIMR-4000-EXIT-TIME-X.

       4000-TIME-LOG-X.
           EXIT.

      *----------------------------
       9990-INIT-WORKING-STORAGE.
      *----------------------------

           INITIALIZE WGLOB-GLOBAL-AREA.

           PERFORM  TIMR-0000-INIT-PARM-INFO
               THRU TIMR-0000-INIT-PARM-INFO-X.

           INITIALIZE WS-WORK-AREAS.
           MOVE +10000                     TO WS-TEST-CNT.
           SET WGLOB-GENERATE-STATS-ALL    TO TRUE.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      ****************************************************************
      * PROCESSING COPYBOOKS                                         *
      ****************************************************************

       COPY XCPSTIMR.
       COPY XCCPTIMR.

      *****************************************************************
      **                 END OF PROGRAM XSOMTIMR                     **
      *****************************************************************
