      *****************************************************************
      **  MEMBER :  XSBUQEND                                         **
      **  REMARKS:  INGENIUM QUEUE WORKER CLEANER                    **
      **            THIS PROGRAM CLEAR ALL INGENIUM QUEUES           **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
AMQCNV**  7.1       NEW PROGRAM                                      **
      *****************************************************************

      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSBUQEND.

       COPY XCWWCRHT.

      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

       CONFIGURATION SECTION.
MFWIN  special-names.
MFWIN  call-convention 74 is winapi.

       INPUT-OUTPUT SECTION.
       FILE-CONTROL.

      /
      ***************
       DATA DIVISION.
      ***************

       FILE SECTION.

      *************************
       WORKING-STORAGE SECTION.
      *************************

       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSBUQEND'.
       COPY CCWWINDX.
       COPY XCWTFCMD.
       COPY XCWWWKDT.
      /
      * WEBSPHERE MQ COPY BOOKS START
       01  MQM-DESC.
       COPY MQDESC.
      * WEBSPHERE MQ COPY BOOKS END

UNIX  *01 WS-POINTERS.
UNIX  *   05 WS-MQ-POINTER PROCEDURE-POINTER.


       01 WS-MQ-WORK-AREA.
      *---------------------------------------------------------------
      *    DISPATCH QUEUE
      *---------------------------------------------------------------
020955 COPY MQOBJ  REPLACING ==:ID:==  BY DQ.
      *---------------------------------------------------------------
      *    INPUT QUEUE
      *---------------------------------------------------------------
020955 COPY MQOBJ  REPLACING ==:ID:==  BY IQ.
      *---------------------------------------------------------------
      *    OUTPUT QUEUE
      *---------------------------------------------------------------
020955 COPY MQOBJ  REPLACING ==:ID:==  BY OQ.
      *---------------------------------------------------------------
      *    COMMON
      *---------------------------------------------------------------
          05  WS-MSG-LEN                 PIC S9(08) COMP-5.
          05  WS-MAX-MSG-LEN             PIC S9(08) COMP-5.
          05  WS-STMR                    PIC S9(08) COMP-5.
          05  WS-STME                    PIC S9(08) COMP-5.

      *
      * TRACE MESSAGE
      *
       01 WS-TRACE-MSG.
          05  WS-TRACE-TIMESTAMP    PIC X(16).
          05  FILLER                PIC X(01) VALUE SPACE.
      * MQ ACTION
          05  FILLER                PIC X(03) VALUE 'OP='.
          05  WS-TRACE-OPERATION    PIC X(10).
              88  WS-TRACE-CONN     VALUE 'MQCONN'.
              88  WS-TRACE-OPEN     VALUE 'MQOPEN'.
              88  WS-TRACE-CLOSE    VALUE 'MQCLOSE'.
              88  WS-TRACE-PUT      VALUE 'MQPUT'.
              88  WS-TRACE-GET      VALUE 'MQGET'.
              88  WS-TRACE-DISC     VALUE 'MQDISC'.
          05  FILLER                PIC X(01) VALUE SPACE.
          05  FILLER                PIC X(04) VALUE 'OBJ='.
          05  WS-TRACE-OBJ          PIC X(04).
              88  WS-TRACE-OBJ-NONE VALUE SPACE.
              88  WS-TRACE-OBJ-DISP VALUE 'DISP'.
              88  WS-TRACE-OBJ-IN   VALUE 'IN  '.
              88  WS-TRACE-OBJ-OUT  VALUE 'OUT '.
              88  WS-TRACE-OBJ-LOG  VALUE 'LOG '.

          05  FILLER                PIC X(01) VALUE SPACE.
          05  FILLER                PIC X(06) VALUE 'MSGID='.
          05  WS-TRACE-MSG-ID       PIC X(01).
          05  FILLER                PIC X(01) VALUE SPACE.
          05  FILLER                PIC X(05) VALUE 'COMP='.
          05  WS-TRACE-COMP-CODE    PIC 9(01).
          05  FILLER                PIC X(01) VALUE SPACE.
          05  FILLER                PIC X(03) VALUE 'RC='.
          05  WS-TRACE-REASON-CODE  PIC 9(04).

       01  WS-BCF-PARM.
           05  WS-DISPATCH-QUEUE-NAME             PIC X(48).
           05  WS-IN-QUEUE-NAME                   PIC X(48).
           05  WS-OUT-QUEUE-NAME                  PIC X(48).
           05  WS-DEBUG-FLAG                      PIC X(01).
               88  WS-DEBUG-FLAG-VALID            VALUE 'Y' 'N'.
               88  WS-DEBUG-YES                   VALUE 'Y'.
               88  WS-DEBUG-NO                    VALUE 'N'.
           05  WS-DISPLAY-PARM                    PIC X(20).
           05  WS-TRACE-FLAG                      PIC X(01).
               88  WS-TRACE-FLAG-VALID            VALUE 'Y' 'N'.
               88  WS-TRACE-YES                   VALUE 'Y'.
               88  WS-TRACE-NO                    VALUE 'N'.
           05  WS-VERBOSE-FLAG                    PIC X(01).
               88  WS-VERBOSE-FLAG-VALID          VALUE 'Y' 'N'.
               88  WS-VERBOSE-YES                 VALUE 'Y'.
               88  WS-VERBOSE-NO                  VALUE 'N'.


       01  WS-WORK-AREA.
           05  WS-WAIT-TIME                       PIC S9(09) BINARY
                                                  VALUE 5000.
           05  WS-DEVANIM                         PIC X(03).


       01  WS-MSG-GR.
           05  WS-ERROR-MSG.
               10  FILLER                         PIC X(20) VALUE
                   'CONTROL CARD ERROR: '.
               10  WS-ERROR-TXT                   PIC X(112).
           05  WS-ERR-MSG                         PIC X(80).

       01  WS-DUMMY-MSG                           PIC X(01).
      *
       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
      /
       COPY XCWWPARM.
      /
      *------------
      * FILE LAYOUT
      *------------

       COPY XCSRBCF.
       COPY XCSWSEQ  REPLACING ==:ID:==  BY BCF
                               ==':ID:'==  BY =='BCF'==.
      /
       COPY XCSROCF.
       COPY XCSWPRT  REPLACING ==:ID:==  BY OCF
                               ==':ID:'==  BY =='OCF'==.
      /
       LINKAGE SECTION.

       PROCEDURE DIVISION.
      *
      *--------------
       0000-MAINLINE.
      *--------------

           DISPLAY 'DEVANIM'  UPON ENVIRONMENT-NAME.
           ACCEPT  WS-DEVANIM FROM ENVIRONMENT-VALUE.

           IF  WS-DEVANIM = '+A'
               CALL 'CBL_DEBUGBREAK'
           END-IF.

           CANCEL 'STOMP.dll'

           PERFORM  1000-INITIALIZE
               THRU 1000-INITIALIZE-X.

           PERFORM  3000-PROCESS-TRANSACTION
               THRU 3000-PROCESS-TRANSACTION-X.

           PERFORM  9000-FINALIZE
               THRU 9000-FINALIZE-X.

           STOP RUN.

       0000-MAINLINE-X.
           EXIT.
      /
      *----------------
       1000-INITIALIZE.
      *----------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           PERFORM  1100-OPEN-FILES
               THRU 1100-OPEN-FILES-X.

           PERFORM  1200-PRCES-CTL-CARDS
               THRU 1200-PRCES-CTL-CARDS-X.

           PERFORM  1300-HANDLE-DEBUG
               THRU 1300-HANDLE-DEBUG-X.

      * CONNECT TO MQ QUEUE MANAGER AND OPEN QUEUES
           PERFORM  1400-CONNECT-MQ
               THRU 1400-CONNECT-MQ-X.

       1000-INITIALIZE-X.
           EXIT.

      *----------------
       1100-OPEN-FILES.
      *----------------

           PERFORM  OCF-3000-OPEN-OUTPUT
               THRU OCF-3000-OPEN-OUTPUT-X.

           PERFORM  BCF-1000-OPEN-INPUT
               THRU BCF-1000-OPEN-INPUT-X.

       1100-OPEN-FILES-X.
           EXIT.

      *---------------------
       1200-PRCES-CTL-CARDS.
      *---------------------

           PERFORM  BCF-1000-READ
               THRU BCF-1000-READ-X.

           PERFORM
               UNTIL NOT WBCF-SEQ-IO-OK

               MOVE RBCF-SEQ-REC-INFO   TO WPARM-CARD-AREA

               EVALUATE TRUE

                   WHEN WPARM-DESCRIPTION = 'DISPATCH QUEUE NAME'
                        IF WPARM-VALUE NOT = SPACE
                            MOVE WPARM-VALUE   TO WS-DISPATCH-QUEUE-NAME
                        ELSE
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF

                   WHEN WPARM-DESCRIPTION = 'IN QUEUE NAME'
                        IF WPARM-VALUE NOT = SPACE
                            MOVE WPARM-VALUE   TO WS-IN-QUEUE-NAME
                        ELSE
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF

                   WHEN WPARM-DESCRIPTION = 'OUT QUEUE NAME'
                        IF WPARM-VALUE NOT = SPACE
                            MOVE WPARM-VALUE   TO WS-OUT-QUEUE-NAME
                        ELSE
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF

                   WHEN WPARM-DESCRIPTION = 'MAX TASK PER QUEUE'
                        CONTINUE

                   WHEN WPARM-DESCRIPTION = 'DEBUG'
                        MOVE WPARM-VALUE   TO WS-DEBUG-FLAG
                        IF  NOT WS-DEBUG-FLAG-VALID
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF

                   WHEN WPARM-DESCRIPTION = 'DEBUG DISPLAY'
                        CONTINUE

                   WHEN WPARM-DESCRIPTION = 'TRACE'
                        MOVE WPARM-VALUE   TO WS-TRACE-FLAG
                        IF  NOT WS-TRACE-FLAG-VALID
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF

                   WHEN WPARM-DESCRIPTION = 'VERBOSE'
                        MOVE WPARM-VALUE   TO WS-VERBOSE-FLAG
                        IF  NOT WS-VERBOSE-FLAG-VALID
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF

                   WHEN OTHER
                        PERFORM  1220-INVALID-CTL-CARD
                            THRU 1220-INVALID-CTL-CARD-X

               END-EVALUATE

               PERFORM  BCF-1000-READ
                   THRU BCF-1000-READ-X

           END-PERFORM.

       1200-PRCES-CTL-CARDS-X.
           EXIT.

      *----------------------
       1220-INVALID-CTL-CARD.
      *----------------------

           MOVE WPARM-CARD-AREA     TO WS-ERROR-TXT.
           DISPLAY WS-ERROR-MSG.
           STOP RUN.

       1220-INVALID-CTL-CARD-X.
           EXIT.

      *------------------
       1300-HANDLE-DEBUG.
      *------------------

      * IF CONTROL CARD INDICATES DEBUG AND DEVANIM IS NOT SET
           IF  WS-DEBUG-YES AND WS-DEVANIM NOT = '+A'
               CALL 'CBL_DEBUGBREAK'
           END-IF.

       1300-HANDLE-DEBUG-X.
           EXIT.

      *----------------
       1400-CONNECT-MQ.
      *----------------

      *
      * CONNECT TO QUEUE MANAGER
      *

      * ON UNIX, THE PROGRAM IS COMPILED AND LINK TO libmqicb_r
      * ON Windows, MQICCB32.dll MUST BE IN THE PATH

UNIX  *    SET WS-MQ-POINTER
UNIX  *        TO ENTRY 'MQICCB32'.

UNIX  *    IF WS-MQ-POINTER = NULL
UNIX  *        SET WS-MQ-POINTER
UNIX  *            TO ENTRY 'MQMCB32'
UNIX  *    END-IF.

UNIX  *    IF WS-MQ-POINTER = NULL
UNIX  *        MOVE 'MQ SHARE OBJECT NOT FOUND' TO
UNIX  *            WS-ERR-MSG
UNIX  *        PERFORM  9100-ABORT-ERR
UNIX  *            THRU 9100-ABORT-ERR-X
UNIX  *    END-IF.

           PERFORM  1410-CONNECT-QMGR
               THRU 1410-CONNECT-QMGR-X.
      *
      * OPEN DISPATCH, INPUT AND OUTPUT QUEUE
      *
           PERFORM  1420-OPEN-DISPATCH-QUEUE
               THRU 1420-OPEN-DISPATCH-QUEUE-X.

           PERFORM  1430-OPEN-INPUT-QUEUE
               THRU 1430-OPEN-INPUT-QUEUE-X.

           PERFORM  1440-OPEN-OUTPUT-QUEUE
               THRU 1440-OPEN-OUTPUT-QUEUE-X.

       1400-CONNECT-MQ-X.
           EXIT.

      *------------------
       1410-CONNECT-QMGR.
      *------------------
      *
           SET STMF-DQ-CONN        TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-DQ
                                   BY REFERENCE WS-DUMMY-MSG
                                   BY REFERENCE WS-MSG-LEN.
      *
      * OUTPUT TRACE IF REQUIRED
      *
           SET WS-TRACE-CONN       TO TRUE.
           SET WS-TRACE-OBJ-NONE   TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-DQ            TO WS-STMR.
           MOVE STME-DQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-DQ-OK
               MOVE '*** MQ CONNECT ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.

       1410-CONNECT-QMGR-X.
           EXIT.

      *-------------------------
       1420-OPEN-DISPATCH-QUEUE.
      *-------------------------
      *
           SET  STMOD-DQ-TYPE-QUEUE TO TRUE.
           MOVE WS-DISPATCH-QUEUE-NAME TO STMOD-DQ-NAME.
           MOVE 1                  TO WS-MSG-LEN.
      *
           SET STMF-DQ-OPEN        TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-DQ
                                   BY REFERENCE WS-DUMMY-MSG
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-OPEN      TO TRUE.
           SET  WS-TRACE-OBJ-DISP  TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-DQ            TO WS-STMR.
           MOVE STME-DQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-DQ-OK
               MOVE '*** MQ DISPATCH QUEUE OPEN ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.

       1420-OPEN-DISPATCH-QUEUE-X.
           EXIT.

      *----------------------
       1430-OPEN-INPUT-QUEUE.
      *----------------------

           SET  STMOD-IQ-TYPE-QUEUE TO TRUE.
           MOVE WS-IN-QUEUE-NAME   TO STMOD-IQ-NAME.
           MOVE 1                  TO WS-MSG-LEN.
      *
           SET STMF-IQ-OPEN        TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-IQ
                                   BY REFERENCE WS-DUMMY-MSG
                                   BY REFERENCE WS-MSG-LEN.
      *
           SET  WS-TRACE-OPEN      TO TRUE.
           SET  WS-TRACE-OBJ-IN    TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-IQ            TO WS-STMR.
           MOVE STME-IQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-IQ-OK
               MOVE '*** MQ INPUT QUEUE OPEN ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.

       1430-OPEN-INPUT-QUEUE-X.
           EXIT.

      *-----------------------
       1440-OPEN-OUTPUT-QUEUE.
      *-----------------------

           SET  STMOD-OQ-TYPE-QUEUE TO TRUE.
           MOVE WS-OUT-QUEUE-NAME  TO STMOD-OQ-NAME.
           MOVE 1                  TO WS-MSG-LEN.
      *
           SET STMF-OQ-OPEN        TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-OQ
                                   BY REFERENCE WS-DUMMY-MSG
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-OPEN      TO TRUE.
           SET  WS-TRACE-OBJ-OUT   TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-OQ            TO WS-STMR.
           MOVE STME-OQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-OQ-OK
               MOVE '*** MQ OUTPUT QUEUE OPEN ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.

       1440-OPEN-OUTPUT-QUEUE-X.
           EXIT.

      *-------------------------
       3000-PROCESS-TRANSACTION.
      *-------------------------
      *
      * READ DISPATCH QUEUE FOR ACTIVE QUEUE WORKERS AND
      * INSTRUCT COBOL QUEUE WORKERS TO STOP
      *
           SET STMR-DQ-OK TO TRUE.
           PERFORM  8500-READ-DISPATCH-QUEUE
               THRU 8500-READ-DISPATCH-QUEUE-X
               UNTIL NOT STMR-DQ-OK.

      * FLUSH OUTPUT QUEUE FOR LEFT OVER RESULTS
           SET STMR-OQ-OK TO TRUE.
           PERFORM  8700-READ-OUTPUT-QUEUE
               THRU 8700-READ-OUTPUT-QUEUE-X
               UNTIL NOT STMR-OQ-OK.

      * FLUSH INPUT QUEUE JUST IN CASE
           SET STMR-IQ-OK TO TRUE.
           PERFORM  8800-READ-INPUT-QUEUE
               THRU 8800-READ-INPUT-QUEUE-X
               UNTIL NOT STMR-IQ-OK.
       
       3000-PROCESS-TRANSACTION-X.
           EXIT.


      *----------------------------
       3100-CLEAR-DISP-INPUT-QUEUE.
      *----------------------------

           SET STMR-DQ-OK TO TRUE.

           PERFORM  8500-READ-DISPATCH-QUEUE
               THRU 8500-READ-DISPATCH-QUEUE-X.

       3100-CLEAR-DISP-INPUT-QUEUE-X.
           EXIT.


      *-------------------------
       8500-READ-DISPATCH-QUEUE.
      *-------------------------
      *
      * GET ALL ENTRIES FROM DISPATCH QUEUE
      *
           MOVE SPACES             TO STMMD-DQ-CORE-ID.
           SET STMGO-DQ-WAIT-NONE  TO TRUE.
           MOVE 0                  TO WS-MSG-LEN.
      *
           SET STMF-DQ-GET         TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-DQ
                                   BY REFERENCE WS-DUMMY-MSG
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-GET       TO TRUE.
           SET  WS-TRACE-OBJ-DISP  TO TRUE.
           MOVE STMMD-DQ-MSG-ID    TO WS-TRACE-MSG-ID.
           MOVE STMR-DQ            TO WS-STMR.
           MOVE STME-DQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

       8500-READ-DISPATCH-QUEUE-X.
           EXIT.

      *-------------------------
       8700-READ-OUTPUT-QUEUE.
      *-------------------------
      *
      * GET ALL ENTRIES FROM OUTPUT QUEUE
      *
           MOVE SPACES             TO STMMD-OQ-CORE-ID.
           SET STMGO-OQ-WAIT-NONE  TO TRUE.
           MOVE 0                  TO WS-MSG-LEN.

           SET STMF-OQ-GET         TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-OQ
                                   BY REFERENCE WS-DUMMY-MSG
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-PUT       TO TRUE.
           SET  WS-TRACE-OBJ-OUT   TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-OQ            TO WS-STMR.
           MOVE STME-OQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

       8700-READ-OUTPUT-QUEUE-X.
           EXIT.


      *----------------------
       8800-READ-INPUT-QUEUE.
      *----------------------
      *
      * GET ALL ENTRIES FROM INPUT QUEUE
      *
           MOVE SPACES             TO STMMD-IQ-CORE-ID.
           SET STMGO-IQ-WAIT-NONE  TO TRUE.
           MOVE 0                  TO WS-MSG-LEN.

           SET STMF-IQ-GET         TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-IQ
                                   BY REFERENCE WS-DUMMY-MSG
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-PUT       TO TRUE.
           SET  WS-TRACE-OBJ-OUT   TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-IQ            TO WS-STMR.
           MOVE STME-IQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

       8800-READ-INPUT-QUEUE-X.
           EXIT.

      *---------------
       9000-FINALIZE.
      *---------------

           PERFORM  9200-CLOSE-DISPATCH-QUEUE
               THRU 9200-CLOSE-DISPATCH-QUEUE-X.

           PERFORM  9300-CLOSE-INPUT-QUEUE
               THRU 9300-CLOSE-INPUT-QUEUE-X.

           PERFORM  9400-CLOSE-OUTPUT-QUEUE
               THRU 9400-CLOSE-OUTPUT-QUEUE-X.

           PERFORM  9700-CLOSE-QMGR-CONNECTION
               THRU 9700-CLOSE-QMGR-CONNECTION-X.

           PERFORM  9999-CLOSE-FILES
               THRU 9999-CLOSE-FILES-X.

       9000-FINALIZE-X.
           EXIT.

      *---------------
       9100-ABORT-ERR.
      *---------------

           DISPLAY WS-ERR-MSG.
           STOP RUN.

       9100-ABORT-ERR-X.
           EXIT.

      *--------------------------
       9200-CLOSE-DISPATCH-QUEUE.
      *--------------------------

           MOVE 1                  TO WS-MSG-LEN.
           SET STMF-DQ-CLOSE       TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-DQ
                                   BY REFERENCE WS-DUMMY-MSG
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-CLOSE     TO TRUE.
           SET  WS-TRACE-OBJ-DISP  TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-DQ            TO WS-STMR.
           MOVE STME-DQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-DQ-OK
               MOVE '*** MQ DISPATCH QUEUE CLOSE ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.

       9200-CLOSE-DISPATCH-QUEUE-X.
           EXIT.

      *-----------------------
       9300-CLOSE-INPUT-QUEUE.
      *-----------------------

           MOVE 1                  TO WS-MSG-LEN.
           SET STMF-IQ-CLOSE       TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-IQ
                                   BY REFERENCE WS-DUMMY-MSG
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-CLOSE     TO TRUE.
           SET  WS-TRACE-OBJ-IN    TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-IQ            TO WS-STMR.
           MOVE STME-IQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-IQ-OK
               MOVE '*** MQ INPUT QUEUE CLOSE ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.

       9300-CLOSE-INPUT-QUEUE-X.
           EXIT.

      *------------------------
       9400-CLOSE-OUTPUT-QUEUE.
      *------------------------

           MOVE 1                  TO WS-MSG-LEN.
           SET STMF-OQ-CLOSE       TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-OQ
                                   BY REFERENCE WS-DUMMY-MSG
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-CLOSE     TO TRUE.
           SET  WS-TRACE-OBJ-OUT   TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-OQ            TO WS-STMR.
           MOVE STME-OQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-OQ-OK
               MOVE '*** MQ OUTPUT QUEUE CLOSE ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.

       9400-CLOSE-OUTPUT-QUEUE-X.
           EXIT.

      *-------------------
       9600-GEN-TRACE-MSG.
      *-------------------

           IF  WS-TRACE-YES OR WS-VERBOSE-YES
               MOVE FUNCTION CURRENT-DATE TO WS-TRACE-TIMESTAMP
               MOVE WS-STMR               TO WS-TRACE-COMP-CODE
               MOVE WS-STME               TO WS-TRACE-REASON-CODE
           END-IF.


           IF  WS-VERBOSE-YES
               DISPLAY WS-TRACE-MSG
           END-IF.

       9600-GEN-TRACE-MSG-X.
           EXIT.

      *---------------------------
       9700-CLOSE-QMGR-CONNECTION.
      *---------------------------
      *
      * DISCONNECT FROM QUEUE MANAGER
      *
           MOVE 1                  TO WS-MSG-LEN.
           SET STMF-DQ-DISC        TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-DQ
                                   BY REFERENCE WS-DUMMY-MSG
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-DISC      TO TRUE.
           SET  WS-TRACE-OBJ-NONE  TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-DQ            TO WS-STMR.
           MOVE STME-DQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-DQ-OK
               MOVE '*** MQ DISCONNECT ERROR' TO
                   WS-ERR-MSG
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.

       9700-CLOSE-QMGR-CONNECTION-X.
           EXIT.

      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------

           MOVE SPACES           TO WWKDT-WORK-FIELDS.
           INITIALIZE            WS-BCF-PARM.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.

      /
      *-----------------
       9999-CLOSE-FILES.
      *-----------------

           PERFORM  BCF-4000-CLOSE
               THRU BCF-4000-CLOSE-X.

           PERFORM  OCF-4000-CLOSE
               THRU OCF-4000-CLOSE-X.

       9999-CLOSE-FILES-X.
           EXIT.

      /
      *
      * FILE COPYBOOKS
      *
       COPY XCSLFILE REPLACING ==:ID:==  BY OCF
                               ==':PGM:'== BY =='XSRQOCF'==.
       COPY XCSOFILE REPLACING ==:ID:==  BY OCF.
      /
       COPY XCSLFILE REPLACING ==:ID:==  BY BCF
                               ==':PGM:'== BY =='XSRQBCF'==.
       COPY XCSNSEQ  REPLACING ==:ID:==  BY BCF.
       COPY XCSOFILE REPLACING ==:ID:==  BY BCF.

      *
      * PROCESSING COPYBOOKS
      /
      *
      *****************************************************************
      **                 END OF PROGRAM XSBUQEND                     **
      *****************************************************************
