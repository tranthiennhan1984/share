
      *****************************************************************
      **  MEMBER :  XSBUQWRK                                         **
      **  REMARKS:  INGENIUM QUEUE WORKER FOR WEBSPHERE MQ           **
      **            THIS PROGRAM USES WEBSPHERE MQ TO PASS           **
      **            MESSAGE BETWEEN PATHFINDER AND INGENIUM.         **
      **                                                             **
      **  DOMAIN :  SY                                               **
      **                                                             **
      **  ENVIRONMENT VARIABLE:                                      **
      **      DEVANIM - Input                                        **
      **      DISPLAY - Output                                       **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
AMQCNV**  15JAN2024 NHANTT CICS REPLACEMENT                          **
      *****************************************************************

      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSBUQWRK.

       COPY XCWWCRHT.

      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

       CONFIGURATION SECTION.
MFWIN  special-names.
MFWIN  call-convention 74 is winapi.

       INPUT-OUTPUT SECTION.
       FILE-CONTROL.

      /
      ***************
       DATA DIVISION.
      ***************

       FILE SECTION.

      *************************
       WORKING-STORAGE SECTION.
      *************************

       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSBUQWRK'.
       COPY XCWWTIMR.
       COPY XCWLTIMR.

       COPY SQLCA.

      * WEBSPHERE MQ COPY BOOKS START
       01  MQM-DESC.
       COPY MQDESC.
      * WEBSPHERE MQ COPY BOOKS END
              
UNIX  *01 WS-POINTERS.
UNIX  *   05 WS-MQ-POINTER PROCEDURE-POINTER.

       
       01 WS-MQ-WORK-AREA.
      *---------------------------------------------------------------
      *    DISPATCH QUEUE
      *---------------------------------------------------------------
020955 COPY MQOBJ  REPLACING ==:ID:==  BY DQ.
      *---------------------------------------------------------------
      *    INPUT QUEUE
      *---------------------------------------------------------------
020955 COPY MQOBJ  REPLACING ==:ID:==  BY IQ.
      *---------------------------------------------------------------
      *    OUTPUT QUEUE
      *---------------------------------------------------------------
020955 COPY MQOBJ  REPLACING ==:ID:==  BY OQ.
      *---------------------------------------------------------------
      *    COMMON
      *---------------------------------------------------------------    
          05  WS-MSG-LEN                 PIC S9(09) COMP-5.
          05  WS-MAX-MSG-LEN             PIC S9(09) COMP-5.
          05  WS-DISPATCH-ENTRY-LEN      PIC S9(09) COMP-5.
          05  WS-STMR                    PIC S9(08) COMP-5.
          05  WS-STME                    PIC S9(08) COMP-5.

      *
      * TRACE MESSAGE
      *                 
       01 WS-TRACE-MSG.
          05  WS-TRACE-TIMESTAMP    PIC X(16).
          05  FILLER                PIC X(01) VALUE SPACE.          
      * MQ ACTION 
          05  FILLER                PIC X(03) VALUE 'OP='.
          05  WS-TRACE-OPERATION    PIC X(10).
              88  WS-TRACE-CONN     VALUE 'MQCONN'.
              88  WS-TRACE-OPEN     VALUE 'MQOPEN'.
              88  WS-TRACE-CLOSE    VALUE 'MQCLOSE'.
              88  WS-TRACE-PUT      VALUE 'MQPUT'.
              88  WS-TRACE-GET      VALUE 'MQGET'.
              88  WS-TRACE-DISC     VALUE 'MQDISC'.              
          05  FILLER                PIC X(01) VALUE SPACE.
          05  FILLER                PIC X(04) VALUE 'OBJ='.
          05  WS-TRACE-OBJ          PIC X(04).
              88  WS-TRACE-OBJ-NONE VALUE SPACE.
              88  WS-TRACE-OBJ-DISP VALUE 'DISP'.
              88  WS-TRACE-OBJ-IN   VALUE 'IN  '.
              88  WS-TRACE-OBJ-OUT  VALUE 'OUT '.
              88  WS-TRACE-OBJ-LOG  VALUE 'LOG '.
                            
          05  FILLER                PIC X(01) VALUE SPACE.                    
          05  FILLER                PIC X(06) VALUE 'MSGID='.          
          05  WS-TRACE-MSG-ID       PIC X(01).
          05  FILLER                PIC X(01) VALUE SPACE.
          05  FILLER                PIC X(05) VALUE 'COMP='.                    
          05  WS-TRACE-COMP-CODE    PIC 9(01).
          05  FILLER                PIC X(01) VALUE SPACE.
          05  FILLER                PIC X(03) VALUE 'RC='.                    
          05  WS-TRACE-REASON-CODE  PIC 9(04).               
      /
       COPY XCWL0040.
      /
       COPY XCWWHDG.
       COPY CCWWINDX.
      /
       COPY XCWTFCMD.
       COPY XCWWWKDT.

       01  WS-BCF-PARM.
           05  WS-DISPATCH-QUEUE-NAME             PIC X(48).
           05  WS-IN-QUEUE-NAME                   PIC X(48).
           05  WS-OUT-QUEUE-NAME                  PIC X(48).
           05  WS-MAX-TASK-X                      PIC X(08).
           05  WS-MAX-TASK-PER-QUEUE REDEFINES WS-MAX-TASK-X PIC 9(08).
           05  WS-DEBUG-FLAG                      PIC X(01).
               88  WS-DEBUG-FLAG-VALID            VALUE 'Y' 'N'.
               88  WS-DEBUG-YES                   VALUE 'Y'.
               88  WS-DEBUG-NO                    VALUE 'N'.
           05  WS-DISPLAY-PARM                    PIC X(20).
           05  WS-TRACE-FLAG                      PIC X(01).
               88  WS-TRACE-FLAG-VALID            VALUE 'Y' 'N'.
               88  WS-TRACE-YES                   VALUE 'Y'.
               88  WS-TRACE-NO                    VALUE 'N'.
           05  WS-VERBOSE-FLAG                    PIC X(01).
               88  WS-VERBOSE-FLAG-VALID          VALUE 'Y' 'N'.
               88  WS-VERBOSE-YES                 VALUE 'Y'.
               88  WS-VERBOSE-NO                  VALUE 'N'.               

       01  WS-WORK-AREA.
           05  WS-ING-PGM-NAME                    PIC X(10)
                                                  VALUE 'XSOM0010'.
           05  WS-TASK-CNT                        PIC 9(08) BINARY
                                                  VALUE 0.                                                             
           05  WS-INPUT-TEXT                      PIC X(80).
           05  WS-DATABASE-NM              PIC X(08) VALUE SPACES.
           05  WS-USER-ID                  PIC X(08) VALUE SPACES.
           05  WS-PASSWORD                 PIC X(08) VALUE SPACES.
           05  WS-DUMMY                           PIC X(01).
           05  WS-CURR-DATE-TIME.
               10 WS-CURR-YYYY                    PIC X(04).
               10 WS-CURR-MM                      PIC X(02).
               10 WS-CURR-DD                      PIC X(02).
               10 WS-CURR-HH                      PIC X(02).
               10 WS-CURR-MM                      PIC X(02).
               10 WS-CURR-SS                      PIC X(02).
               10 WS-CURR-HS                      PIC X(02).
           05  WS-RETURN-CODE                     PIC 9(02).
               88  WS-NORMAL-END                  VALUE 0.
               88  WS-NO-RESTART-END              VALUE 1.
           05  WS-DEVANIM                         PIC X(03).
           05  WS-DISPLAY-VAR-NM                  PIC X(07) VALUE
               'DISPLAY'.
           05  WS-DISPLAY-VAR                     PIC X(20).

      * DATA AREA FOR CALLING PSEUDO RANDOM API FOR EIBTASKN REPLACEMENT
       01  WS-RANDOM-AREA.
      * IT SHOULD BE BEST TO USE PROCESS ID AS SEED
           05 WS-RANDOM-SEED                      PIC 9(06).
           05 WS-NEXT-RANDOM-SEQ                  PIC 9(6)V9(12).              

       01  WS-DISPATCH-ENTRY.
           05  WS-PROCESS-ID                      PIC 9(06).
           05  WS-PROCESS-ID-X REDEFINES WS-PROCESS-ID PIC X(06).                 
           05  FILLER                             PIC X(01) VALUE
                                                  SPACE.
           05  WS-DISP-DATE-TIME                  PIC X(16).

       01  WS-MSG-GR.
           05  WS-ERROR-MSG.
               10  FILLER                         PIC X(20) VALUE
                   'CONTROL CARD ERROR: '.
               10  WS-ERROR-TXT                   PIC X(112).               
      /
      * DFH BLOCK
       01  DFHEIBLK.
           05  EIBTASKN                           PIC S9(7) COMP-3.
       01  DFHCOMMAREA                            PIC X(32767).
       01  WS-COMMAREA REDEFINES DFHCOMMAREA.
           05  WS-TRAN-ID                         PIC X(04).
           05  FILLER                             PIC X(32763).

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
      /
       COPY XCWWPARM.
       COPY XCWL0035.
       COPY XCWL0290.
      /
      *------------
      * FILE LAYOUT
      *------------

       COPY XCSRBCF.
       COPY XCSWSEQ  REPLACING ==:ID:==  BY BCF
                               ==':ID:'==  BY =='BCF'==.
      /
       COPY XCSROCF.
       COPY XCSWPRT  REPLACING ==:ID:==  BY OCF
                               ==':ID:'==  BY =='OCF'==.
      /
       LINKAGE SECTION.

       PROCEDURE DIVISION.
      *
      *--------------
       0000-MAINLINE.
      *--------------

           DISPLAY 'DEVANIM'  UPON ENVIRONMENT-NAME.
           ACCEPT  WS-DEVANIM FROM ENVIRONMENT-VALUE.

           IF  WS-DEVANIM = '+A'
               CALL 'CBL_DEBUGBREAK'
           END-IF.
           
           CANCEL 'STOMP.dll'

           PERFORM  1000-INITIALIZE
               THRU 1000-INITIALIZE-X.

           PERFORM  3000-PROCESS-TRANSACTION
               THRU 3000-PROCESS-TRANSACTION-X.

           PERFORM  9000-FINALIZE
               THRU 9000-FINALIZE-X.

           MOVE WS-RETURN-CODE  TO RETURN-CODE.
           STOP RUN.

       0000-MAINLINE-X.
           EXIT.
      /
      *----------------
       1000-INITIALIZE.
      *----------------

           PERFORM  9990-INIT-WORKING-STORAGE
               THRU 9990-INIT-WORKING-STORAGE-X.

           MOVE 0 TO RETURN-CODE.

      * ACCEPT DATABASE, UNIX PROCESS ID FROM COMMAND-LINE
           MOVE SPACE        TO WS-INPUT-TEXT.
           ACCEPT WS-INPUT-TEXT FROM COMMAND-LINE.
           UNSTRING WS-INPUT-TEXT
               DELIMITED BY SPACES
               INTO 
                   WS-DATABASE-NM
                   WS-USER-ID
                   WS-PASSWORD
                   WS-PROCESS-ID-X
           END-UNSTRING.
           
      * IF PROCESS ID IS NOT PASSED AS PARAMETER, USE ZERO.
           IF WS-PROCESS-ID-X NOT NUMERIC
               MOVE 0 TO WS-PROCESS-ID
           END-IF.

           PERFORM  1100-OPEN-FILES
               THRU 1100-OPEN-FILES-X.

           PERFORM  1200-PRCES-CTL-CARDS
               THRU 1200-PRCES-CTL-CARDS-X.
           
           PERFORM  1300-HANDLE-DEBUG                                           
               THRU 1300-HANDLE-DEBUG-X.

      * CONNECT TO MQ QUEUE MANAGER AND OPEN QUEUES
           PERFORM  1400-CONNECT-MQ
               THRU 1400-CONNECT-MQ-X.

      * INITIALIZE PSEUDO RANDOM NUMBER SEQUENCE
           PERFORM  1500-INIT-RANDOM-SEQ
               THRU 1500-INIT-RANDOM-SEQ-X.

            PERFORM  1600-CONNECT-DATABASE
                THRU 1600-CONNECT-DATABASE-X.
                                                       
       1000-INITIALIZE-X.
           EXIT.

      *----------------
       1100-OPEN-FILES.
      *----------------

           PERFORM  OCF-3000-OPEN-OUTPUT
               THRU OCF-3000-OPEN-OUTPUT-X.

           PERFORM  BCF-1000-OPEN-INPUT
               THRU BCF-1000-OPEN-INPUT-X.

       1100-OPEN-FILES-X.
           EXIT.

      *---------------------
       1200-PRCES-CTL-CARDS.
      *---------------------

           PERFORM  BCF-1000-READ
               THRU BCF-1000-READ-X.

           PERFORM
               UNTIL NOT WBCF-SEQ-IO-OK

               MOVE RBCF-SEQ-REC-INFO   TO WPARM-CARD-AREA

               EVALUATE TRUE

                   WHEN WPARM-DESCRIPTION = 'DISPATCH QUEUE NAME'
                        IF WPARM-VALUE NOT = SPACE
                            MOVE WPARM-VALUE   TO WS-DISPATCH-QUEUE-NAME
                        ELSE
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF

                   WHEN WPARM-DESCRIPTION = 'IN QUEUE NAME'
                        IF WPARM-VALUE NOT = SPACE
                            MOVE WPARM-VALUE   TO WS-IN-QUEUE-NAME
                        ELSE
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF
                   
                   WHEN WPARM-DESCRIPTION = 'OUT QUEUE NAME'
                        IF WPARM-VALUE NOT = SPACE
                            MOVE WPARM-VALUE   TO WS-OUT-QUEUE-NAME
                        ELSE
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF

                   WHEN WPARM-DESCRIPTION = 'MAX TASK PER QUEUE'
                        MOVE WPARM-VALUE   TO WS-MAX-TASK-X
                        IF WS-MAX-TASK-X NOT NUMERIC
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF

                   WHEN WPARM-DESCRIPTION = 'DEBUG'
                        MOVE WPARM-VALUE   TO WS-DEBUG-FLAG
                        IF  NOT WS-DEBUG-FLAG-VALID
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF

                   WHEN WPARM-DESCRIPTION = 'DEBUG DISPLAY'
                        IF WPARM-VALUE NOT = SPACE
                            MOVE WPARM-VALUE   TO WS-DISPLAY-PARM
                        END-IF

                   WHEN WPARM-DESCRIPTION = 'TRACE'
                        MOVE WPARM-VALUE   TO WS-TRACE-FLAG
                        IF  NOT WS-TRACE-FLAG-VALID
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF

                   WHEN WPARM-DESCRIPTION = 'VERBOSE'
                        MOVE WPARM-VALUE   TO WS-VERBOSE-FLAG
                        IF  NOT WS-VERBOSE-FLAG-VALID
                            PERFORM  1220-INVALID-CTL-CARD
                                THRU 1220-INVALID-CTL-CARD-X
                        END-IF

                   WHEN OTHER
                        PERFORM  1220-INVALID-CTL-CARD
                            THRU 1220-INVALID-CTL-CARD-X

               END-EVALUATE

               PERFORM  BCF-1000-READ
                   THRU BCF-1000-READ-X

           END-PERFORM.

       1200-PRCES-CTL-CARDS-X.
           EXIT.

      *----------------------
       1220-INVALID-CTL-CARD.
      *----------------------
      
           MOVE WPARM-CARD-AREA     TO WS-ERROR-TXT.
           MOVE WS-ERROR-MSG        TO L0040-INPUT-LINE.
           PERFORM  0040-3000-WRITE-OTHER
               THRU 0040-3000-WRITE-OTHER-X.
           SET  WS-NO-RESTART-END TO TRUE.
           MOVE WS-RETURN-CODE      TO RETURN-CODE.           
           STOP RUN.
           
       1220-INVALID-CTL-CARD-X.
           EXIT.

      *------------------
       1300-HANDLE-DEBUG.
      *------------------
      
      * IF CONTROL CARD INDICATES DEBUG AND DEVANIM IS NOT SET
           IF  WS-DEBUG-YES AND WS-DEVANIM NOT = '+A'
      * CHECK WHETHER DISPLAY ENV VAR IS SET     
               DISPLAY WS-DISPLAY-VAR-NM UPON ENVIRONMENT-NAME
               ACCEPT  WS-DISPLAY-VAR    FROM ENVIRONMENT-VALUE
               IF  WS-DISPLAY-VAR = SPACE AND
                   WS-DISPLAY-PARM NOT = SPACE
                   DISPLAY WS-DISPLAY-VAR-NM UPON ENVIRONMENT-NAME
                   DISPLAY WS-DISPLAY-PARM   UPON ENVIRONMENT-VALUE
               END-IF
               CALL 'CBL_DEBUGBREAK'
           END-IF.       
       
       1300-HANDLE-DEBUG-X.
           EXIT.

      *-------------------
       1300-RETR-JOB-INFO.
      *-------------------
      *
      * RETRIEVE JOB NUMBER FOR DISPATCH QUEUE ENTRY
      *
       1300-RETR-JOB-INFO-X.
           EXIT.

      *----------------
       1400-CONNECT-MQ.
      *----------------
      
      *
      * CONNECT TO QUEUE MANAGER
      *
      
      * ON UNIX, THE PROGRAM IS COMPILED AND LINK TO libmqicb_r
      * ON Windows, MQICCB32.dll MUST BE IN THE PATH 
      
UNIX  *    SET WS-MQ-POINTER 
UNIX  *        TO ENTRY 'MQICCB32'.

UNIX  *    IF WS-MQ-POINTER = NULL
UNIX  *    SET WS-MQ-POINTER
UNIX  *        TO ENTRY 'MQMCB32'.

UNIX  *    IF WS-MQ-POINTER = NULL
UNIX  *        MOVE 'MQ SHARE OBJECT NOT FOUND' TO
UNIX  *            L0040-INPUT-LINE
UNIX  *        PERFORM  9100-ABORT-ERR
UNIX  *            THRU 9100-ABORT-ERR-X
UNIX  *    END-IF.
       
           PERFORM  1410-CONNECT-QMGR
               THRU 1410-CONNECT-QMGR-X.
      *
      * OPEN DISPATCH, INPUT AND OUTPUT QUEUE
      *
           PERFORM  1420-OPEN-DISPATCH-QUEUE
               THRU 1420-OPEN-DISPATCH-QUEUE-X.
      
           PERFORM  1430-OPEN-INPUT-QUEUE
               THRU 1430-OPEN-INPUT-QUEUE-X.
                   
           PERFORM  1440-OPEN-OUTPUT-QUEUE
               THRU 1440-OPEN-OUTPUT-QUEUE-X.

       1400-CONNECT-MQ-X.
           EXIT.
      *
      *------------------
       1410-CONNECT-QMGR.
      *------------------
      *
           SET STMF-DQ-CONN        TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-DQ
                                   BY REFERENCE DFHCOMMAREA
                                   BY REFERENCE WS-MSG-LEN.
      *
      * OUTPUT TRACE IF REQUIRED
           SET WS-TRACE-CONN       TO TRUE.
           SET WS-TRACE-OBJ-NONE   TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-DQ            TO WS-STMR.
           MOVE STME-DQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-DQ-OK
               MOVE '*** MQ CONNECT ERROR' TO
                   L0040-INPUT-LINE
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.
      *
       1410-CONNECT-QMGR-X.
           EXIT.
      *
      *-------------------------
       1420-OPEN-DISPATCH-QUEUE.
      *-------------------------
      *
           SET  STMOD-DQ-TYPE-QUEUE TO TRUE.
           MOVE WS-DISPATCH-QUEUE-NAME TO STMOD-DQ-NAME.
      *
           SET STMF-DQ-OPEN        TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-DQ
                                   BY REFERENCE DFHCOMMAREA
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-OPEN      TO TRUE.
           SET  WS-TRACE-OBJ-DISP  TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-DQ            TO WS-STMR.
           MOVE STME-DQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-DQ-OK
               MOVE '*** MQ DISPATCH QUEUE OPEN ERROR' TO
                   L0040-INPUT-LINE
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.

       1420-OPEN-DISPATCH-QUEUE-X.
           EXIT.
      *
      *----------------------
       1430-OPEN-INPUT-QUEUE.
      *----------------------

           SET  STMOD-IQ-TYPE-QUEUE TO TRUE.
           MOVE WS-IN-QUEUE-NAME   TO STMOD-IQ-NAME.
      *
           SET STMF-IQ-OPEN        TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-IQ
                                   BY REFERENCE DFHCOMMAREA
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-OPEN      TO TRUE.
           SET  WS-TRACE-OBJ-IN    TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-IQ            TO WS-STMR.
           MOVE STME-IQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-IQ-OK
               MOVE '*** MQ INPUT QUEUE OPEN ERROR' TO
                   L0040-INPUT-LINE
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.

       1430-OPEN-INPUT-QUEUE-X.
           EXIT.
      *
      *-----------------------
       1440-OPEN-OUTPUT-QUEUE.
      *-----------------------

           SET  STMOD-OQ-TYPE-QUEUE TO TRUE.
           MOVE WS-OUT-QUEUE-NAME  TO STMOD-OQ-NAME.
      *
           SET STMF-OQ-OPEN        TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-OQ
                                   BY REFERENCE DFHCOMMAREA
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-OPEN      TO TRUE.
           SET  WS-TRACE-OBJ-OUT   TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-OQ            TO WS-STMR.
           MOVE STME-OQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-OQ-OK
               MOVE '*** MQ OUTPUT QUEUE OPEN ERROR' TO
                   L0040-INPUT-LINE
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.

       1440-OPEN-OUTPUT-QUEUE-X.
           EXIT.
           
      *---------------------          
       1500-INIT-RANDOM-SEQ.
      *---------------------                
       
           MOVE WS-PROCESS-ID TO WS-RANDOM-SEED.
           COMPUTE WS-NEXT-RANDOM-SEQ = 
               FUNCTION RANDOM(WS-RANDOM-SEED).
       
       1500-INIT-RANDOM-SEQ-X.
           EXIT.
           
      *----------------------
       1600-CONNECT-DATABASE.
      *----------------------

           MOVE WS-DATABASE-NM              TO  L0035-SERVER-NM.
           MOVE WS-USER-ID                  TO  L0035-USER-ID.
           MOVE WS-PASSWORD                 TO  L0035-PASSWORD.
           PERFORM  0035-3000-CONNECT
               THRU 0035-3000-CONNECT-X.

       1600-CONNECT-DATABASE-X.
           EXIT.
           
      *-------------------------
       3000-PROCESS-TRANSACTION.
      *-------------------------
      *
      * WRITE AN ENTRY TO DISPATCH QUEUE TO NOTIFY
      * AVAILABILITY OF THIS QUEUE WORKER INSTANCE
      *
           PERFORM  8700-WRITE-DISPATCH-QUEUE
               THRU 8700-WRITE-DISPATCH-QUEUE-X.

           PERFORM  8400-READ-DATA-QUEUE
               THRU 8400-READ-DATA-QUEUE-X.

           PERFORM  3100-CALL-MAIN-PGM
               THRU 3100-CALL-MAIN-PGM-X
               UNTIL WS-TRAN-ID = 'EXIT' OR
                     WS-TASK-CNT > WS-MAX-TASK-PER-QUEUE.

           IF  WS-TRAN-ID = 'EXIT'
               SET  WS-NO-RESTART-END TO TRUE
           ELSE IF WS-TASK-CNT > WS-MAX-TASK-PER-QUEUE
               SET  WS-NORMAL-END TO TRUE
           END-IF.

       3000-PROCESS-TRANSACTION-X.
           EXIT.

      *-------------------
       3100-CALL-MAIN-PGM.
      *-------------------
      *
      * GENERATE TASK NUMBER FROM PSEUDO RANDOM NUMBER
           PERFORM  8100-GEN-TASK-NUM
               THRU 8100-GEN-TASK-NUM-X.

      * CALL INGENIUM ONLINE ENTRY PROGRAM
           CALL WS-ING-PGM-NAME USING DFHEIBLK
                                      DFHCOMMAREA.

      * OUTPUT PROCESSED RESULT TO OUTGOING QUEUE
           PERFORM  8500-WRITE-DATA-QUEUE
               THRU 8500-WRITE-DATA-QUEUE-X.

      * COMMIT DATABASE CHANGES
           PERFORM  0035-1000-COMMIT
               THRU 0035-1000-COMMIT-X.

      * INCREMENT THE TASK COUNT FOR NEW TRANSACTION
           ADD 1 TO WS-TASK-CNT.
           IF WS-TASK-CNT > WS-MAX-TASK-PER-QUEUE
               GO TO 3100-CALL-MAIN-PGM-X
           END-IF.

      * CREATE NEW ENTRY TO DISPATCH QUEUE
           PERFORM  8700-WRITE-DISPATCH-QUEUE
               THRU 8700-WRITE-DISPATCH-QUEUE-X.

           PERFORM  8400-READ-DATA-QUEUE
               THRU 8400-READ-DATA-QUEUE-X.

       3100-CALL-MAIN-PGM-X.
           EXIT.

      *------------------
       8100-GEN-TASK-NUM.
      *------------------
      *
      * GET NEXT PSUEDO RANDOM NUMBER BETWEEN 0 AND 1
      *
           COMPUTE WS-NEXT-RANDOM-SEQ = FUNCTION RANDOM.

      * TAKE THE FIRST 4 DIGITS AS EIBTASKN
           COMPUTE EIBTASKN = WS-NEXT-RANDOM-SEQ * 10000.

       8100-GEN-TASK-NUM-X.
           EXIT.

      *-----------------------
       8200-DELETE-DATA-QUEUE.
      *-----------------------
      *
      * THERE IS NO NEED TO DELETE INPUT AND OUTPUT QUEUES
      * ANYMORE
      *
       8200-DELETE-DATA-QUEUE-X.
           EXIT.

      *---------------------
       8400-READ-DATA-QUEUE.
      *---------------------
      *
      * GET ANY INCOMING REQUEST FROM INPUT QUEUE
      *
      
      * NO CORRELATION ID FOR INPUT MESSAGE
           MOVE SPACES             TO STMMD-IQ-CORE-ID.

      * WAIT FOR UNLIMITED TIME
           SET STMGO-IQ-WAIT-UNLIMITED TO TRUE.
      *
      * SET MAXIMUM LENGTH ACCORDING TO DFHCOMMAREA
           MOVE WS-MAX-MSG-LEN     TO WS-MSG-LEN.
      *
           SET STMF-IQ-GET         TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-IQ
                                   BY REFERENCE DFHCOMMAREA
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-GET       TO TRUE.
           SET  WS-TRACE-OBJ-IN    TO TRUE.
           MOVE STMMD-IQ-MSG-ID    TO WS-TRACE-MSG-ID.
           MOVE STMR-IQ            TO WS-STMR.
           MOVE STME-IQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-IQ-OK
               MOVE '*** MQ INPUT QUEUE GET ERROR' TO
                   L0040-INPUT-LINE
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.

       8400-READ-DATA-QUEUE-X.
           EXIT.
      *
      *----------------------
       8500-WRITE-DATA-QUEUE.
      *----------------------
      *
      * PUT REPLY FROM INGENIUM WITH CORRELATION ID TO OUTPUT QUEUE
      *
           MOVE STMMD-IQ-MSG-ID    TO STMMD-OQ-CORE-ID.
		   
           SET STMF-OQ-PUT         TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-OQ
                                   BY REFERENCE DFHCOMMAREA
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-PUT       TO TRUE.
           SET  WS-TRACE-OBJ-OUT   TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-OQ            TO WS-STMR.
           MOVE STME-OQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-OQ-OK
               MOVE '*** MQ OUTPUT QUEUE PUT ERROR' TO
                   L0040-INPUT-LINE
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.

       8500-WRITE-DATA-QUEUE-X.
           EXIT.

      *--------------------------
       8700-WRITE-DISPATCH-QUEUE.
      *--------------------------
      *
      * NO CORRELATION ID FOR DISPATCH ENTRY
      *
           MOVE SPACES             TO STMMD-DQ-CORE-ID.
      *
      * PUT DISPATCH QUEUE MESSAGE TO ANNOUNCE READY STATUS
      *
           MOVE FUNCTION CURRENT-DATE TO WS-DISP-DATE-TIME.

           SET STMF-DQ-PUT         TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-DQ
                                   BY REFERENCE WS-DISPATCH-ENTRY
                                   BY REFERENCE WS-DISPATCH-ENTRY-LEN.

           SET  WS-TRACE-PUT       TO TRUE.
           SET  WS-TRACE-OBJ-DISP  TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-DQ            TO WS-STMR.
           MOVE STME-DQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-DQ-OK
               MOVE '*** MQ DISPATCH QUEUE PUT ERROR' TO
                   L0040-INPUT-LINE
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.

       8700-WRITE-DISPATCH-QUEUE-X.
           EXIT.
      *
      *---------------
       9000-FINALIZE.
      *---------------
      *
           PERFORM  9200-CLOSE-DISPATCH-QUEUE
               THRU 9200-CLOSE-DISPATCH-QUEUE-X.

           PERFORM  9300-CLOSE-INPUT-QUEUE
               THRU 9300-CLOSE-INPUT-QUEUE-X.

           PERFORM  9400-CLOSE-OUTPUT-QUEUE
               THRU 9400-CLOSE-OUTPUT-QUEUE-X.

           PERFORM  9500-CLOSE-QMGR-CONNECTION
               THRU 9500-CLOSE-QMGR-CONNECTION-X.
      
           PERFORM  9999-CLOSE-FILES
               THRU 9999-CLOSE-FILES-X.

       9000-FINALIZE-X.
           EXIT.
                     
      *---------------
       9100-ABORT-ERR.
      *---------------
                         
           PERFORM  0040-3000-WRITE-OTHER
               THRU 0040-3000-WRITE-OTHER-X.
           SET  WS-NO-RESTART-END         TO TRUE.
           MOVE WS-RETURN-CODE            TO RETURN-CODE.           
           STOP RUN.
           
       9100-ABORT-ERR-X.
           EXIT.                                                                       

      *--------------------------
       9200-CLOSE-DISPATCH-QUEUE.
      *--------------------------
      *
           SET STMF-DQ-CLOSE       TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-DQ
                                   BY REFERENCE DFHCOMMAREA
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-CLOSE     TO TRUE.
           SET  WS-TRACE-OBJ-DISP  TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-DQ            TO WS-STMR.
           MOVE STME-DQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-DQ-OK
               MOVE '*** MQ DISPATCH QUEUE CLOSE ERROR' TO
                   L0040-INPUT-LINE
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.
      *
       9200-CLOSE-DISPATCH-QUEUE-X.
           EXIT.
      *
      *-----------------------
       9300-CLOSE-INPUT-QUEUE.
      *-----------------------

           SET STMF-IQ-CLOSE       TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-IQ
                                   BY REFERENCE DFHCOMMAREA
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-CLOSE     TO TRUE.
           SET  WS-TRACE-OBJ-IN    TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-IQ            TO WS-STMR.
           MOVE STME-IQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-IQ-OK
               MOVE '*** MQ INPUT QUEUE CLOSE ERROR' TO
                   L0040-INPUT-LINE
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.

       9300-CLOSE-INPUT-QUEUE-X.
           EXIT.
      *
      *------------------------
       9400-CLOSE-OUTPUT-QUEUE.
      *------------------------

           SET STMF-OQ-CLOSE       TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-OQ
                                   BY REFERENCE DFHCOMMAREA
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-CLOSE     TO TRUE.
           SET  WS-TRACE-OBJ-OUT   TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-OQ            TO WS-STMR.
           MOVE STME-OQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-OQ-OK
               MOVE '*** MQ OUTPUT QUEUE CLOSE ERROR' TO
                   L0040-INPUT-LINE
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.

       9400-CLOSE-OUTPUT-QUEUE-X.
           EXIT.
      *
      *---------------------------
       9500-CLOSE-QMGR-CONNECTION.
      *---------------------------
      *
      * DISCONNECT FROM QUEUE MANAGER
      *
           SET STMF-DQ-DISC        TO TRUE.
           CALL winapi 'STOMP'     USING
                                   BY REFERENCE STMH
                                   BY REFERENCE WS-STMO-DQ
                                   BY REFERENCE DFHCOMMAREA
                                   BY REFERENCE WS-MSG-LEN.

           SET  WS-TRACE-DISC      TO TRUE.
           SET  WS-TRACE-OBJ-NONE  TO TRUE.
           MOVE SPACE              TO WS-TRACE-MSG-ID.
           MOVE STMR-DQ            TO WS-STMR.
           MOVE STME-DQ            TO WS-STME.
           PERFORM  9600-GEN-TRACE-MSG
               THRU 9600-GEN-TRACE-MSG-X.

           IF NOT STMR-DQ-OK
               MOVE '*** MQ DISCONNECT ERROR' TO
                   L0040-INPUT-LINE
               PERFORM  9100-ABORT-ERR
                   THRU 9100-ABORT-ERR-X
           END-IF.

       9500-CLOSE-QMGR-CONNECTION-X.
           EXIT.
           
      *-------------------
       9600-GEN-TRACE-MSG.
      *-------------------
           
           IF  WS-TRACE-YES OR WS-VERBOSE-YES               
               MOVE FUNCTION CURRENT-DATE TO WS-TRACE-TIMESTAMP
               MOVE WS-STMR               TO WS-TRACE-COMP-CODE
               MOVE WS-STME               TO WS-TRACE-REASON-CODE
           END-IF.
 
           IF  WS-TRACE-YES
               MOVE WS-TRACE-MSG        TO L0040-INPUT-LINE
               PERFORM  0040-3000-WRITE-OTHER
                   THRU 0040-3000-WRITE-OTHER-X
           END-IF.
           
           IF  WS-VERBOSE-YES
               DISPLAY WS-TRACE-MSG
           END-IF.
      
       9600-GEN-TRACE-MSG-X.
           EXIT.
       
      *--------------------------
       9990-INIT-WORKING-STORAGE.
      *--------------------------

           PERFORM  0040-0000-INIT-PARM-INFO
               THRU 0040-0000-INIT-PARM-INFO-X.

           PERFORM  0290-0000-INIT-PARM-INFO
               THRU 0290-0000-INIT-PARM-INFO-X.

           MOVE 1                TO WS-TASK-CNT.
           SET  WS-NORMAL-END    TO TRUE.
           MOVE SPACE            TO DFHEIBLK.
           MOVE SPACE            TO DFHCOMMAREA.
           MOVE LENGTH OF DFHCOMMAREA TO WS-MAX-MSG-LEN.
           MOVE LENGTH OF WS-DISPATCH-ENTRY TO WS-DISPATCH-ENTRY-LEN.
           MOVE SPACES           TO WWKDT-WORK-FIELDS.
           INITIALIZE            WS-BCF-PARM.
           MOVE 'XSOM0010'       TO WS-ING-PGM-NAME.
           
           INITIALIZE WS-RANDOM-AREA.

       9990-INIT-WORKING-STORAGE-X.
           EXIT.
      /
      *-----------------
       9999-CLOSE-FILES.
      *-----------------

           PERFORM  BCF-4000-CLOSE
               THRU BCF-4000-CLOSE-X.

           PERFORM  OCF-4000-CLOSE
               THRU OCF-4000-CLOSE-X.

       9999-CLOSE-FILES-X.
           EXIT.

      /
      *
      * FILE COPYBOOKS
      *
       COPY XCSLFILE REPLACING ==:ID:==  BY OCF
                               ==':PGM:'== BY =='XSRQOCF'==.
       COPY XCSOFILE REPLACING ==:ID:==  BY OCF.
      /
       COPY XCSLFILE REPLACING ==:ID:==  BY BCF
                               ==':PGM:'== BY =='XSRQBCF'==.
       COPY XCSNSEQ  REPLACING ==:ID:==  BY BCF.
       COPY XCSOFILE REPLACING ==:ID:==  BY BCF.

      *
      * PROCESSING COPYBOOKS
      *
       COPY XCPS0040.
       COPY XCPL0040.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
       COPY XCCP0030.
       COPY XCPL0035.
      *
      *****************************************************************
      **                 END OF PROGRAM XSBUQWRK                     **
      *****************************************************************

