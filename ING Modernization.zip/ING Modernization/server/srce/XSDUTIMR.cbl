      $set mf
      **************************
       IDENTIFICATION DIVISION.
      **************************

       PROGRAM-ID. XSDUTIMR.

AMQCNV*COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  XSDUTIMR                                         **
      **  REMARKS:  CALL THE TIMER FUNCTION.                         **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
026766**  6.6       PERFORMANCE MONITORING                           **
AMQCNV**  15JAN2024 NHANTT CICS REPLACEMENT                          **
      *****************************************************************

      ***********************
       ENVIRONMENT DIVISION.
      ***********************

       CONFIGURATION SECTION.
       DATA DIVISION.

      **************************
       WORKING-STORAGE SECTION.
      **************************

       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSDUTIMR'.

       01  WS-GETMICROS    PIC X(08) VALUE 'XSCU0006'.

       01  WS-WORKING-STORAGE.
           05  WS-NS9          PIC S9(09) BINARY.

      ******************
       LINKAGE SECTION.
      ******************
       COPY XCWWDFH.
       COPY XCWLTIMR.
      /
      *********************
AMQCNV*PROCEDURE DIVISION USING DFHEIBLK
AMQCNV*                         DFHCOMMAREA
AMQCNV*                         LTIMR-PARM-INFO.
AMQCNV PROCEDURE DIVISION USING LTIMR-PARM-INFO.
      *********************

      *---------------
       0000-MAINLINE.
      *---------------

DEVENV     CALL WS-GETMICROS  RETURNING WS-NS9.
ZOS   *    CALL 'XSCU0006'    RETURNING WS-NS9.
OS/400*    CALL PROCEDURE 'XSCU0006' RETURNING WS-NS9.

           MOVE WS-NS9                   TO LTIMR-NS9.

       0000-MAINLINE-X.
           GOBACK.
      /
      *****************************************************************
      **                 END OF PROGRAM XSDUTIMR                     **
      *****************************************************************
