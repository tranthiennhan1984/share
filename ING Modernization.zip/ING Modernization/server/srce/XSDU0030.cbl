      *************************
       IDENTIFICATION DIVISION.
      *************************

       PROGRAM-ID. XSDU0030.

AMQCNV*COPY XCWWCRHT.

      *****************************************************************
      **  MEMBER :  XSDU0030                                         **
      **  REMARKS: THIS ROUTINE HANDLES BOTH BATCH AND CICS ERRORS   **
      **                                                             **
      **  BATCH  : BATCH ERROR ROLLBACK AND LOG PROGRAM.  THIS       **
      **           PROGRAM HANDLES SQL, QSAM, CONTROL CARD AND       **
      **           LOGIC ERRORS ENCOUNTERED BY BATCH PROGRAMS.  IT   **
      **           ALSO HANDLES SQL OPTIMIZATION WARNING MESSAGES.   **
      **           FOR THE DB2 PLATFORM, AN SQL ROLLBACK IS          **
      **           PERFORMED FOR ALL ERROR CONDITIONS TO ROLLBACK    **
      **           THE UNIT OF WORK.  FOR BOTH ERROR AND WARNING     **
      **           CONDITIONS, A RECORD IS WRITTEN TO THE ERROR LOG  **
      **           TABLE.  ERROR CONDITIONS ARE ALSO DISPLAYED ON    **
      **           OCF PRINT.                                        **
      **                                                             **
      **  CICS   :  HANDLE CICS AND SQL ERROR CONDITIONS BY ROLLING  **
      **            BACK UPDATES AND ADDING AN ERROR LOG ENTRY.      **
      **            THIS MODULE HANDLES CICS AND SQL ERRORS BY       **
      **            PERFORMING CICS SYNCPOINT ROLLBACK TO UNDO THE   **
      **            UNIT OF WORK.  IT ALSO WRITES A RECORD TO THE    **
      **            ERROR LOG CONTAINING INFORMATION ABOUT THE ERROR **
      **            AND DELETES TSQS.  THE ERROR SCREEN IS DISPLAYED **
      **            TO THE TERMINAL OPERATOR.                        **
      **                                                             **
      **            USED ONLY BY XSOM0010 AND THE FIRST PROGRAM      **
      **            (ENTRY POINT) OF A BACKGROUND TASK               **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
018763**  6.3       CODE CLEANUP - DEVENV/PROD ENVIRONMENT TAGS      **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019632**  6.3.1     PRODUCT XPRESS CONNECTOR 1.0                     **
019523**  6.4       ADD RECORD KEY TO ERROR LOG FOR SQL ERRORS       **
021351**  6.4       RENAME SYNCPOINT TO ROLLBACK                     **
021620**  6.4       CODE CLEAN-UP AND STANDARDIZATION                **
021890**  6.4       BATCH ABEND HANDLING                             **
021930**  6.4       REMOVE UNUSED COPYBOOKS                          **
023514**  6.5       PERFORMANCE ENHANCEMENT                          **
025489**  6.5       ERROR HANDLING UPDATES                           **
026070**  6.6       ERROR HANDLER                                    **
025970**  6.6       WORKING STORAGE INITIALIZATION                   **
AMQCNV**  15JAN2024 NHANTT CICS REPLACEMENT                          **
      *****************************************************************
      /
      **********************
       ENVIRONMENT DIVISION.
      **********************

      ***************
       DATA DIVISION.
      ***************

       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'XSDU0030'.

       COPY SQLCA.

       01  WS-WORK-FIELDS.
           05  WS-SUB.
               10  WS-SUB-N                 PIC 9(05).
           05  WS-RETURN-CODE               PIC S9(4) BINARY VALUE ZERO.
           05  WS-FORMAT-TIME.
               10  WS-FORMAT-HOUR           PIC X(02).
               10  FILLER                   PIC X(01)  VALUE '.'.
               10  WS-FORMAT-MIN            PIC X(02).
               10  FILLER                   PIC X(01)  VALUE '.'.
               10  WS-FORMAT-SEC            PIC X(02).
           05  WS-SQLCODE                   PIC -9(05).
           05  WS-OPTM-SQL-MSG-IND          PIC X(01).
               88  WS-OPTM-SQL-MSG-FOUND     VALUE 'F'.
               88  WS-OPTM-SQL-MSG-NOT-FOUND VALUE 'N'.


       01  WS-ABEND-DESC-TABLE-FILLER.
           05  FILLER                            PIC X(95) VALUE SPACE.
           05  FILLER                            PIC X(95) VALUE SPACE.
           05  FILLER                            PIC X(95) VALUE SPACE.
           05  WS-ABEND-DESC-LINE1               PIC X(95).
           05  FILLER                            PIC X(95) VALUE SPACE.
           05  FILLER                            PIC X(95) VALUE SPACE.
           05  WS-ABEND-DESC-LINE2               PIC X(95).
           05  WS-ABEND-DESC-LINE3               PIC X(95).
           05  FILLER                            PIC X(95) VALUE SPACE.
           05  WS-ABEND-DESC-LINE4               PIC X(95).
           05  WS-ABEND-DESC-LINE5               PIC X(95).
           05  FILLER                            PIC X(95) VALUE SPACE.
           05  WS-ABEND-DESC-LINE6               PIC X(95).
           05  WS-ABEND-DESC-LINE7               PIC X(95).
           05  WS-ABEND-DESC-LINE8               PIC X(95).
           05  WS-ABEND-DESC-LINE9               PIC X(95).
           05  WS-ABEND-DESC-LINE10              PIC X(95).
           05  FILLER                            PIC X(95) VALUE SPACE.
           05  WS-AD-ERLG-MSG                    PIC X(95) VALUE SPACE.
           05  FILLER                            PIC X(95) VALUE SPACE.

       01  WS-ABEND-DESC-TABLE                   REDEFINES
           WS-ABEND-DESC-TABLE-FILLER.
           05  WS-AD-LINE                        OCCURS 20 PIC X(95).
019523
019523 01  WS-ABEND-KEY-TABLE-FILLER.
019523     05  FILLER                            PIC X(124) VALUE SPACE.
019523     05  WS-ABEND-KEY-LINE1.
019523         10  WS-ABEND-KEY-LINE1-DESC       PIC X(24).
019523         10  WS-ABEND-KEY-1                PIC X(100).
019523     05  WS-ABEND-KEY-LINE2.
019523         10  FILLER                        PIC X(24)  VALUE SPACE.
019523         10  WS-ABEND-KEY-2                PIC X(100).
019523     05  WS-ABEND-KEY-LINE3.
019523         10  FILLER                        PIC X(24)  VALUE SPACE.
019523         10  WS-ABEND-KEY-3                PIC X(100).
019523
019523 01  WS-ABEND-KEY-TABLE                    REDEFINES
019523     WS-ABEND-KEY-TABLE-FILLER.
019523     05  WS-AK-LINE                        OCCURS 3  PIC X(124).
      /
       01  WS-CICS-WORK-AREA.
           05  WS-NUM-X.
               10  WS-NUM                   PIC 9(02).

026070*    05  WS-ABEND-CODE                PIC X(04)  VALUE SPACES.
           05  WS-SQL-IO-DESC-TEXT          PIC X(50).

           05  WS-SQL-IMPRV-TEXT            PIC X(70).
           05  WS-SQL-ERROR-TEXT            PIC X(70).
           05  WS-HOLD-CRNT-PGM-ID          PIC X(08).
           05  WS-HOLD-PREV-PGM-ID          PIC X(08).


       COPY XCWTEMSG.
021930*COPY XCWTFCMD.
      /
021930*COPY XCWWWKDT.
021930*
       COPY XCWL0035.
       COPY XCWL0040.
       COPY XCWL0270.
       COPY XCWL1610.
      /
       COPY XCFWERLG.
       COPY XCFRERLG.
       COPY XCFHERLG.
       COPY XCFWERLH.
      /
      *****************
       LINKAGE SECTION.
      *****************

AMQCNV*COPY XCWWDFH.
       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.

AMQCNV*PROCEDURE DIVISION USING DFHEIBLK
AMQCNV*                         DFHCOMMAREA
AMQCNV*                         WGLOB-GLOBAL-AREA.
AMQCNV PROCEDURE DIVISION USING WGLOB-GLOBAL-AREA.

      *---------------------------
       0000-MAINLINE.
      *---------------------------
023514
023514     PERFORM  9990-INIT-WORKING-STORAGE
023514         THRU 9990-INIT-WORKING-STORAGE-X.

021890*    IF  WGLOB-ENVRMNT-BATCH
021890*        PERFORM  1000-BATCH-ABEND
021890*            THRU 1000-BATCH-ABEND-X
021890*    ELSE
021890*        PERFORM  2000-CICS-ABEND
021890*            THRU 2000-CICS-ABEND-X
021890*    END-IF.
021890*
021890     IF  WGLOB-ENVRMNT-ONLINE
021890         PERFORM  2000-CICS-ABEND
021890             THRU 2000-CICS-ABEND-X
021890     ELSE
021890         PERFORM  1000-BATCH-ABEND
021890             THRU 1000-BATCH-ABEND-X
021890     END-IF.
021890
       0000-MAINLINE-X.
           EXIT.
      /
      *---------------------------
       1000-BATCH-ABEND.
      *---------------------------

           IF  WGLOB-OPTM-SQL-IMPRV
               CONTINUE
           ELSE
               PERFORM  0035-2000-ROLLBACK
                   THRU 0035-2000-ROLLBACK-X
           END-IF.

           PERFORM  1610-1000-GET-DATE-TIME
               THRU 1610-1000-GET-DATE-TIME-X.
           MOVE L1610-SYSTEM-DATE-INT    TO WERLG-ERROR-DT.
           MOVE L1610-SYSTEM-TIME-INT-HH TO WS-FORMAT-HOUR.
           MOVE L1610-SYSTEM-TIME-INT-MM TO WS-FORMAT-MIN.
           MOVE L1610-SYSTEM-TIME-INT-SS TO WS-FORMAT-SEC.

           MOVE WS-FORMAT-TIME           TO WERLG-ERROR-TIME.
           MOVE WERLG-KEY                TO RERLG-KEY.


           MOVE 'BATCH'                  TO RERLG-USER-ID.
           MOVE WGLOB-BUS-FCN-ID         TO RERLG-BUS-FCN-ID.
           MOVE WGLOB-TABLE-NAME         TO RERLG-ERROR-TBL-NM.
           MOVE WGLOB-CRNT-PGM-ID        TO RERLG-ERROR-CRNT-PGM-ID.
           MOVE WGLOB-PREV-PGM-ID        TO RERLG-ERROR-PREV-PGM-ID.
           SET  WS-OPTM-SQL-MSG-NOT-FOUND  TO  TRUE.
      *
      *    INITIALIZE THE DESCRIPTION FIELDS
      *
           MOVE SPACES                   TO RERLG-ERROR-RQST-TXT.
           MOVE SPACES                   TO RERLG-ERROR-DESC-TXT.

           EVALUATE TRUE

               WHEN WGLOB-SQL-ERROR
                  PERFORM 1100-B-SQL-ERROR
                     THRU 1100-B-SQL-ERROR-X

               WHEN WGLOB-QSAM-ERROR
                  PERFORM 1200-B-QSAM-ERROR
                     THRU 1200-B-QSAM-ERROR-X

              WHEN WGLOB-CTL-CARD-ERROR
                  PERFORM 1300-B-CTL-CARD-ERROR
                     THRU 1300-B-CTL-CARD-ERROR-X

              WHEN WGLOB-LOGIC-ERROR
                  PERFORM 1400-B-LOGIC-ERROR
                     THRU 1400-B-LOGIC-ERROR-X

019632        WHEN WGLOB-COMUN-ERROR
021620            PERFORM 1450-B-COMUN-ERROR
021620               THRU 1450-B-COMUN-ERROR-X
021620*           PERFORM 1500-B-COMUN-ERROR
021620*              THRU 1500-B-COMUN-ERROR-X

           END-EVALUATE.

           IF  WS-OPTM-SQL-MSG-NOT-FOUND
                PERFORM  ERLG-1000-WRITE
                    THRU ERLG-1000-WRITE-X
           END-IF.

           IF  WGLOB-OPTM-SQL-IMPRV
               GOBACK
           ELSE
               PERFORM  0035-1000-COMMIT
                   THRU 0035-1000-COMMIT-X
           END-IF.

           PERFORM 1500-B-OUTPUT-ABEND-DESCR
              THRU 1500-B-OUTPUT-ABEND-DESCR-X.

026070*    PERFORM  ABND-7000-STOP-RUN
026070*        THRU ABND-7000-STOP-RUN-X.
AMQCNV*    PERFORM  ERR-3000-STOP-RUN
AMQCNV*        THRU ERR-3000-STOP-RUN-X.
AMQCNV     MOVE +99                        TO RETURN-CODE.
AMQCNV     DISPLAY '** ERROR: PROGRAM ENDING ON USER ABEND 99'.
AMQCNV     STOP RUN.


       1000-BATCH-ABEND-X.
           EXIT.

      *---------------------------
       1100-B-SQL-ERROR.
      *---------------------------
      *  THIS PARAGRAPH HAS BEEN RESTRUCTURED TO NOT GO TO THE TEXT
      *  TABLE FOR DESCRIPTIONS.  ALL CODE MAKING REFERENCES
      *  TO 2490 LOOKUPS AND ALL COMMENTED OUT CODE HAS BEEN REMOVED.

           EVALUATE TRUE

               WHEN WGLOB-OPTM-SQL-IMPRV
      *MSG: Warning, required optimization level @1 not found,
      *     @2 was executed
                    MOVE 'SQLW'                TO RERLG-ERROR-TYP-CD
                    MOVE SPACES                TO RERLG-ERROR-CD
                    MOVE TEMSG-GENERROR-RECORD (02)  TO L0270-MSG-IN
                    MOVE WGLOB-OPTM-SQL-REQIR  TO L0270-MSG-PARM (1)
                    MOVE WGLOB-OPTM-SQL-EXEC   TO L0270-MSG-PARM (2)
                    PERFORM  0270-1000-TOKEN-REPLACEMENT
                        THRU 0270-1000-TOKEN-REPLACEMENT-X
                    MOVE L0270-MSG-OUT         TO RERLG-ERROR-DESC-TXT
      * CHECK IF THIS MESSAGE ALREADY EXISTS IN THE ERROR LOG
                    MOVE RERLG-REC-INFO        TO  HERLG-REC-INFO
                    MOVE RERLG-ERROR-CRNT-PGM-ID
                                            TO  WERLH-ERROR-CRNT-PGM-ID
                    MOVE RERLG-ERROR-DESC-TXT  TO  WERLH-ERROR-DESC-TXT
                    MOVE WERLH-KEY             TO  WERLH-ENDBR-KEY

                    PERFORM  ERLH-4000-BROWSE-INDEX
                        THRU ERLH-4000-BROWSE-INDEX-X

                    PERFORM  ERLH-5000-READ-NEXT-INDEX
                        THRU ERLH-5000-READ-NEXT-INDEX-X

                    IF  WERLH-IO-OK
                        SET  WS-OPTM-SQL-MSG-FOUND TO  TRUE
                    END-IF

                    PERFORM  ERLH-6000-END-BROWSE-INDEX
                        THRU ERLH-6000-END-BROWSE-INDEX-X

                    MOVE HERLG-REC-INFO    TO  RERLG-REC-INFO


               WHEN WGLOB-OPTM-SQL-ERROR
      *MSG: Required optimization level @1 not found in SQL I/O program
                    MOVE 'SQLE'                TO RERLG-ERROR-TYP-CD
                    MOVE SPACES                TO RERLG-ERROR-CD
                    MOVE TEMSG-GENERROR-RECORD (01)  TO L0270-MSG-IN
                    MOVE WGLOB-OPTM-SQL-REQIR  TO L0270-MSG-PARM (1)
                    PERFORM  0270-1000-TOKEN-REPLACEMENT
                        THRU 0270-1000-TOKEN-REPLACEMENT-X
                    MOVE L0270-MSG-OUT         TO RERLG-ERROR-DESC-TXT

               WHEN OTHER
                    MOVE 'SQL'                 TO RERLG-ERROR-TYP-CD
                    MOVE WGLOB-SQLCODE         TO WS-SQLCODE
                    MOVE WS-SQLCODE            TO RERLG-ERROR-CD
                    MOVE WGLOB-ERROR-DESC-TXT  TO RERLG-ERROR-DESC-TXT

           END-EVALUATE.

019523     MOVE WGLOB-ERROR-IO-KEY-INFO  TO RERLG-ERROR-IO-KEY-INFO.

           IF  WGLOB-IO-COMMAND NOT NUMERIC
               MOVE TEMSG-GENERROR-RECORD (6)
                 TO RERLG-ERROR-RQST-TXT
           ELSE
               MOVE WGLOB-IO-COMMAND           TO WS-SUB-N
               MOVE TEMSG-SQLIOERR-RECORD (WS-SUB-N)
                 TO RERLG-ERROR-RQST-TXT
           END-IF.

       1100-B-SQL-ERROR-X.
           EXIT.

      *---------------------------
       1200-B-QSAM-ERROR.
      *---------------------------
      *  THIS PARAGRAPH HAS BEEN RESTRUCTURED TO NOT GO TO THE TEXT
      *  TABLE FOR DESCRIPTIONS.  ALL CODE MAKING REFERENCES
      *  TO 2490 LOOKUPS AND ALL COMMENTED OUT CODE HAS BEEN REMOVED.

           MOVE 'QSAM'                    TO RERLG-ERROR-TYP-CD.
           MOVE WGLOB-SEQ-FILE-STATUS     TO RERLG-ERROR-CD.
           MOVE TEMSG-GENERROR-RECORD (5) TO RERLG-ERROR-DESC-TXT.

           IF  WGLOB-IO-COMMAND NOT NUMERIC
               MOVE TEMSG-GENERROR-RECORD (6) TO RERLG-ERROR-RQST-TXT
           ELSE
               MOVE WGLOB-IO-COMMAND           TO WS-SUB-N
               MOVE TEMSG-QSAMERR-RECORD (WS-SUB-N)
                 TO RERLG-ERROR-RQST-TXT
           END-IF.

       1200-B-QSAM-ERROR-X.
           EXIT.

      *---------------------------
       1300-B-CTL-CARD-ERROR.
      *---------------------------
      *  THIS PARAGRAPH HAS BEEN RESTRUCTURED TO NOT GO TO THE TEXT
      *  TABLE FOR DESCRIPTIONS.  ALL CODE MAKING REFERENCES
      *  TO 2490 LOOKUPS AND ALL COMMENTED OUT CODE HAS BEEN REMOVED.

           MOVE 'CARD'                    TO RERLG-ERROR-TYP-CD.
           MOVE WGLOB-SEQ-FILE-STATUS     TO RERLG-ERROR-CD.
           MOVE TEMSG-GENERROR-RECORD (3) TO RERLG-ERROR-RQST-TXT.

       1300-B-CTL-CARD-ERROR-X.
           EXIT.

      *---------------------------
       1400-B-LOGIC-ERROR.
      *---------------------------
      *  THIS PARAGRAPH HAS BEEN RESTRUCTURED TO NOT GO TO THE TEXT
      *  TABLE FOR DESCRIPTIONS.  ALL CODE MAKING REFERENCES
      *  TO 2490 LOOKUPS AND ALL COMMENTED OUT CODE HAS BEEN REMOVED.

           MOVE 'LGIC'                    TO RERLG-ERROR-TYP-CD.
           MOVE WGLOB-SEQ-FILE-STATUS     TO RERLG-ERROR-CD.
           MOVE TEMSG-GENERROR-RECORD (4) TO RERLG-ERROR-RQST-TXT.

       1400-B-LOGIC-ERROR-X.
           EXIT.

019632******************
021620 1450-B-COMUN-ERROR.
021620*1500-B-COMUN-ERROR.
019632******************
019632
019632     MOVE 'COMU'                    TO RERLG-ERROR-TYP-CD.
019632     MOVE 'COMU'                    TO RERLG-ERROR-CD.
019632     MOVE WGLOB-ERROR-DESC-TXT      TO RERLG-ERROR-DESC-TXT.
019632     MOVE SPACES                    TO RERLG-ERROR-RQST-TXT.
019632
021620*1500-B-COMUN-ERROR-X.
021620 1450-B-COMUN-ERROR-X.
019632     EXIT.

      *---------------------------
       1500-B-OUTPUT-ABEND-DESCR.
      *---------------------------

           PERFORM  1510-B-RETRIEVE-ABEND-DESC
               THRU 1510-B-RETRIEVE-ABEND-DESC-X
            VARYING WS-SUB-N FROM 1 BY 1
              UNTIL WS-SUB-N > 10.

           PERFORM  1520-B-OUTPUT-ABND-DESC-LINE
               THRU 1520-B-OUTPUT-ABND-DESC-LINE-X
            VARYING WS-SUB-N FROM +1 BY +1
              UNTIL WS-SUB-N > +20.

019523     MOVE TEMSG-ABENDERR-RECORD (12)  TO WS-ABEND-KEY-LINE1-DESC.
019523     MOVE RERLG-ERROR-IO-KEY-INFO-TXT (1:100)
019523                                      TO WS-ABEND-KEY-1.
019523     MOVE RERLG-ERROR-IO-KEY-INFO-TXT (101:100)
019523                                      TO WS-ABEND-KEY-2.
019523     MOVE RERLG-ERROR-IO-KEY-INFO-TXT (201:100)
019523                                      TO WS-ABEND-KEY-3.
019523
019523     PERFORM  1530-B-OUTPUT-ABND-KEY-LINE
019523         THRU 1530-B-OUTPUT-ABND-KEY-LINE-X
019523         VARYING WS-SUB-N FROM 1 BY 1
019523         UNTIL   WS-SUB-N > 3.
019523
       1500-B-OUTPUT-ABEND-DESCR-X.
           EXIT.

      *---------------------------
       1510-B-RETRIEVE-ABEND-DESC.
      *---------------------------

           MOVE TEMSG-ABENDERR-RECORD (WS-SUB-N)  TO L0270-MSG-IN.

           EVALUATE TRUE

               WHEN WS-SUB-N = 6
                    MOVE RERLG-KEY    TO L0270-MSG-PARM (1)

               WHEN WS-SUB-N = 7
                    MOVE RERLG-ERROR-CD
                                      TO L0270-MSG-PARM (1)

               WHEN WS-SUB-N = 8
                    MOVE RERLG-ERROR-TBL-NM
                                      TO L0270-MSG-PARM (1)

               WHEN WS-SUB-N = 9
                    MOVE RERLG-ERROR-DESC-TXT
                                      TO L0270-MSG-PARM (1)

               WHEN WS-SUB-N = 10
                    PERFORM  1511-B-MOVE-ERROR-RQST-PARM
                        THRU 1511-B-MOVE-ERROR-RQST-PARM-X

           END-EVALUATE.

           PERFORM  0270-1000-TOKEN-REPLACEMENT
               THRU 0270-1000-TOKEN-REPLACEMENT-X.

           EVALUATE TRUE

               WHEN WS-SUB-N = 1
                    MOVE L0270-MSG-OUT     TO WS-ABEND-DESC-LINE1

               WHEN WS-SUB-N = 2
                    MOVE L0270-MSG-OUT     TO WS-ABEND-DESC-LINE2

               WHEN WS-SUB-N = 3
                    MOVE L0270-MSG-OUT     TO WS-ABEND-DESC-LINE3

               WHEN WS-SUB-N = 4
                    MOVE L0270-MSG-OUT     TO WS-ABEND-DESC-LINE4

               WHEN WS-SUB-N = 5
                    MOVE L0270-MSG-OUT     TO WS-ABEND-DESC-LINE5

               WHEN WS-SUB-N = 6
                    MOVE L0270-MSG-OUT     TO WS-ABEND-DESC-LINE6

               WHEN WS-SUB-N = 7
                    MOVE L0270-MSG-OUT     TO WS-ABEND-DESC-LINE7

               WHEN WS-SUB-N = 8
                    MOVE L0270-MSG-OUT     TO WS-ABEND-DESC-LINE8

               WHEN WS-SUB-N = 9
                    MOVE L0270-MSG-OUT     TO WS-ABEND-DESC-LINE9

               WHEN WS-SUB-N = 10
                    MOVE L0270-MSG-OUT     TO WS-ABEND-DESC-LINE10

           END-EVALUATE.


       1510-B-RETRIEVE-ABEND-DESC-X.
           EXIT.

      *---------------------------
       1511-B-MOVE-ERROR-RQST-PARM.
      *---------------------------

           IF  RERLG-ERROR-RQST-TXT > SPACES
               MOVE RERLG-ERROR-RQST-TXT  TO L0270-MSG-PARM (1)
           ELSE
               MOVE 'N/A'                 TO L0270-MSG-PARM (1)
           END-IF.

       1511-B-MOVE-ERROR-RQST-PARM-X.
           EXIT.
      /
      *---------------------------
       1520-B-OUTPUT-ABND-DESC-LINE.
      *---------------------------

           IF WGLOB-TABLE-NAME = 'OCF '
              DISPLAY WS-AD-LINE (WS-SUB-N)
           ELSE
              MOVE WS-AD-LINE (WS-SUB-N) TO L0040-INPUT-LINE
              PERFORM 0040-3000-WRITE-OTHER
                 THRU 0040-3000-WRITE-OTHER-X
           END-IF.

       1520-B-OUTPUT-ABND-DESC-LINE-X.
           EXIT.
      /
019523*----------------------------
019523 1530-B-OUTPUT-ABND-KEY-LINE.
019523*----------------------------
019523
019523     IF  (WGLOB-ERROR-IO-KEY-INFO-LEN > ((WS-SUB-N - 1) * 100))
019523         IF  WGLOB-TABLE-NAME = 'OCF '
019523             DISPLAY WS-AK-LINE (WS-SUB-N)
019523         ELSE
019523             MOVE WS-AK-LINE (WS-SUB-N) TO L0040-INPUT-LINE
019523             PERFORM  0040-3000-WRITE-OTHER
019523                 THRU 0040-3000-WRITE-OTHER-X
019523         END-IF
019523     END-IF.
019523
019523 1530-B-OUTPUT-ABND-KEY-LINE-X.
019523     EXIT.
019523/
      *---------------------------
       2000-CICS-ABEND.
      *---------------------------

025489*     PERFORM  ABND-4000-ASSIGN-ABCODE
025489*         THRU ABND-4000-ASSIGN-ABCODE-X.

           MOVE WGLOB-CRNT-PGM-ID          TO WS-HOLD-CRNT-PGM-ID.
           MOVE WGLOB-PREV-PGM-ID          TO WS-HOLD-PREV-PGM-ID.

           IF  WGLOB-OPTM-SQL-IMPRV
               PERFORM  2100-C-PROCESS-WARNING
                   THRU 2100-C-PROCESS-WARNING-X
           ELSE
026070*        PERFORM  ABND-5000-ABEND-GOBACK
026070*            THRU ABND-5000-ABEND-GOBACK-X
026070*
               PERFORM  2200-C-PROCESS-ROLLBACK
                   THRU 2200-C-PROCESS-ROLLBACK-X
           END-IF.

           GOBACK.

       2000-CICS-ABEND-X.
           EXIT.

      *---------------------------
       2100-C-PROCESS-WARNING.
      *---------------------------

           PERFORM  2210-C-BUILD-ERROR-LOG
               THRU 2210-C-BUILD-ERROR-LOG-X.

      * CHECK IF THIS MESSAGE ALREADY EXISTS IN THE ERROR LOG
           MOVE RERLG-REC-INFO             TO  HERLG-REC-INFO.
           MOVE RERLG-ERROR-CRNT-PGM-ID    TO  WERLH-ERROR-CRNT-PGM-ID.
           MOVE RERLG-ERROR-DESC-TXT       TO  WERLH-ERROR-DESC-TXT.
           MOVE WERLH-KEY                  TO  WERLH-ENDBR-KEY.

           PERFORM  ERLH-4000-BROWSE-INDEX
               THRU ERLH-4000-BROWSE-INDEX-X.

           MOVE WS-HOLD-CRNT-PGM-ID        TO WGLOB-CRNT-PGM-ID.
           MOVE WS-HOLD-PREV-PGM-ID        TO WGLOB-PREV-PGM-ID.

           PERFORM  ERLH-5000-READ-NEXT-INDEX
               THRU ERLH-5000-READ-NEXT-INDEX-X.

           MOVE WS-HOLD-CRNT-PGM-ID        TO WGLOB-CRNT-PGM-ID.
           MOVE WS-HOLD-PREV-PGM-ID        TO WGLOB-PREV-PGM-ID.

           IF  WERLH-IO-EOF
               MOVE HERLG-REC-INFO         TO  RERLG-REC-INFO
               PERFORM  ERLG-1000-WRITE
                   THRU ERLG-1000-WRITE-X
               MOVE WS-HOLD-CRNT-PGM-ID    TO WGLOB-CRNT-PGM-ID
               MOVE WS-HOLD-PREV-PGM-ID    TO WGLOB-PREV-PGM-ID
           END-IF.

           PERFORM  ERLH-6000-END-BROWSE-INDEX
               THRU ERLH-6000-END-BROWSE-INDEX-X.

           MOVE WS-HOLD-CRNT-PGM-ID        TO WGLOB-CRNT-PGM-ID.
           MOVE WS-HOLD-PREV-PGM-ID        TO WGLOB-PREV-PGM-ID.

       2100-C-PROCESS-WARNING-X.
           EXIT.

      *---------------------------
       2200-C-PROCESS-ROLLBACK.
      *---------------------------

021351*    PERFORM  ABND-6000-SYNCPOINT
021351*        THRU ABND-6000-SYNCPOINT-X.

026070*    PERFORM  ABND-6000-ROLLBACK
026070*        THRU ABND-6000-ROLLBACK-X.
AMQCNV*    PERFORM  ERR-2000-ROLLBACK
AMQCNV*        THRU ERR-2000-ROLLBACK-X.
AMQCNV
AMQCNV     PERFORM  0035-2000-ROLLBACK
AMQCNV         THRU 0035-2000-ROLLBACK-X.

           MOVE WS-HOLD-CRNT-PGM-ID        TO WGLOB-CRNT-PGM-ID.
           MOVE WS-HOLD-PREV-PGM-ID        TO WGLOB-PREV-PGM-ID.

      *
      *  WRITE A RECORD ON THE ERROR LOG WHEN CICS ATTACH IS UP
      *
           PERFORM  2210-C-BUILD-ERROR-LOG
               THRU 2210-C-BUILD-ERROR-LOG-X.

026070*    IF  WGLOB-ABEND-CD = 'AEY9'
026070*        CONTINUE
026070*    ELSE
026070*        PERFORM  ERLG-1000-WRITE
026070*            THRU ERLG-1000-WRITE-X
026070*        MOVE WS-HOLD-CRNT-PGM-ID    TO WGLOB-CRNT-PGM-ID
026070*        MOVE WS-HOLD-PREV-PGM-ID    TO WGLOB-PREV-PGM-ID
026070*    END-IF.
026070
026070     PERFORM  ERLG-1000-WRITE
026070         THRU ERLG-1000-WRITE-X.
026070     MOVE WS-HOLD-CRNT-PGM-ID    TO WGLOB-CRNT-PGM-ID.
026070     MOVE WS-HOLD-PREV-PGM-ID    TO WGLOB-PREV-PGM-ID.
      *
      *  WRITE AN ENTRY TO THE MSIN TABLE FOR BACKGROUND TASKS
      *
           EVALUATE TRUE

               WHEN WGLOB-ENVRMNT-BACKGROUND
                    PERFORM  2220-C-WRITE-MSIN
                        THRU 2220-C-WRITE-MSIN-X

           END-EVALUATE.

AMQCNV     PERFORM  0035-1000-COMMIT
AMQCNV         THRU 0035-1000-COMMIT-X.

       2200-C-PROCESS-ROLLBACK-X.
           EXIT.

      *---------------------
       2210-C-BUILD-ERROR-LOG.
      *---------------------

           MOVE WGLOB-SYSTEM-DATE-INT      TO  WERLG-ERROR-DT.
           MOVE WGLOB-SYSTEM-TIME-INT      TO  WERLG-ERROR-TIME.
           MOVE WERLG-KEY                  TO  RERLG-KEY.
           MOVE WGLOB-USER-ID              TO  RERLG-USER-ID.
           MOVE WGLOB-BUS-FCN-ID           TO  RERLG-BUS-FCN-ID.
           MOVE WGLOB-CRNT-PGM-ID          TO  RERLG-ERROR-CRNT-PGM-ID.
           MOVE WGLOB-PREV-PGM-ID          TO  RERLG-ERROR-PREV-PGM-ID.

           EVALUATE TRUE

                WHEN WGLOB-SQL-ERROR
                     IF WGLOB-OPTM-SQL-IMPRV
                         PERFORM  2211-C-GET-SQL-IMPRV-TEXT
                             THRU 2211-C-GET-SQL-IMPRV-TEXT-X
                     END-IF

                     IF WGLOB-OPTM-SQL-ERROR
                         PERFORM  2212-C-GET-SQL-ERROR-TEXT
                             THRU 2212-C-GET-SQL-ERROR-TEXT-X
                     END-IF

                     PERFORM  2213-C-GET-SQL-IODES-TEXT
                         THRU 2213-C-GET-SQL-IODES-TEXT-X

                     PERFORM  2214-C-MOVE-SQL-INFO
                         THRU 2214-C-MOVE-SQL-INFO-X

                WHEN WGLOB-CICS-ERROR
                     PERFORM  2215-C-MOVE-CICS-INFO
                         THRU 2215-C-MOVE-CICS-INFO-X

                WHEN WGLOB-LOGIC-ERROR
                     PERFORM  2215-C-MOVE-CICS-INFO
                         THRU 2215-C-MOVE-CICS-INFO-X

019632          WHEN WGLOB-COMUN-ERROR
019632               PERFORM  2216-C-MOVE-COMUN-INFO
019632                   THRU 2216-C-MOVE-COMUN-INFO-X

           END-EVALUATE.

       2210-C-BUILD-ERROR-LOG-X.
           EXIT.

      *-----------------------------
       2211-C-GET-SQL-IMPRV-TEXT.
      *-----------------------------

           MOVE TEMSG-GENERROR-RECORD (2)      TO L0270-MSG-IN.

           MOVE WGLOB-OPTM-SQL-REQIR           TO L0270-MSG-PARM (1).
           MOVE WGLOB-OPTM-SQL-EXEC            TO L0270-MSG-PARM (2).

           PERFORM  0270-1000-TOKEN-REPLACEMENT
               THRU 0270-1000-TOKEN-REPLACEMENT-X.
           MOVE WS-HOLD-CRNT-PGM-ID            TO WGLOB-CRNT-PGM-ID.
           MOVE WS-HOLD-PREV-PGM-ID            TO WGLOB-PREV-PGM-ID.

           IF  L0270-RETRN-OK
               MOVE L0270-MSG-OUT              TO WS-SQL-IMPRV-TEXT
           END-IF.

       2211-C-GET-SQL-IMPRV-TEXT-X.
           EXIT.

      *-----------------------------
       2212-C-GET-SQL-ERROR-TEXT.
      *-----------------------------

           MOVE TEMSG-GENERROR-RECORD (01)     TO L0270-MSG-IN.

           MOVE WGLOB-OPTM-SQL-REQIR           TO L0270-MSG-PARM (1).

           PERFORM  0270-1000-TOKEN-REPLACEMENT
               THRU 0270-1000-TOKEN-REPLACEMENT-X.
           MOVE WS-HOLD-CRNT-PGM-ID            TO WGLOB-CRNT-PGM-ID.
           MOVE WS-HOLD-PREV-PGM-ID            TO WGLOB-PREV-PGM-ID.

           IF  L0270-RETRN-OK
               MOVE L0270-MSG-OUT              TO WS-SQL-ERROR-TEXT
           END-IF.

       2212-C-GET-SQL-ERROR-TEXT-X.
           EXIT.

      *-----------------------------
       2213-C-GET-SQL-IODES-TEXT.
      *-----------------------------

           MOVE WGLOB-IO-COMMAND               TO WS-NUM-X.
           MOVE TEMSG-SQLIOERR-RECORD (WS-NUM) TO WS-SQL-IO-DESC-TEXT.

       2213-C-GET-SQL-IODES-TEXT-X.
           EXIT.

      *-------------------
       2214-C-MOVE-SQL-INFO.
      *-------------------

           MOVE WGLOB-TABLE-NAME               TO RERLG-ERROR-TBL-NM.

           EVALUATE TRUE

               WHEN WGLOB-OPTM-SQL-IMPRV
                    MOVE 'SQLW'                TO RERLG-ERROR-TYP-CD
                    MOVE SPACES                TO RERLG-ERROR-CD
                    MOVE WS-SQL-IMPRV-TEXT     TO RERLG-ERROR-DESC-TXT

               WHEN WGLOB-OPTM-SQL-ERROR
                    MOVE 'SQLE'                TO RERLG-ERROR-TYP-CD
                    MOVE SPACES                TO RERLG-ERROR-CD
                    MOVE WS-SQL-ERROR-TEXT     TO RERLG-ERROR-DESC-TXT

               WHEN OTHER
                    MOVE 'SQL'                 TO RERLG-ERROR-TYP-CD
                    MOVE WGLOB-SQLCODE         TO WS-SQLCODE
                    MOVE WS-SQLCODE            TO RERLG-ERROR-CD
                    MOVE WGLOB-ERROR-DESC-TXT  TO RERLG-ERROR-DESC-TXT

           END-EVALUATE.

019523     MOVE WGLOB-ERROR-IO-KEY-INFO  TO RERLG-ERROR-IO-KEY-INFO.

           MOVE WS-SQL-IO-DESC-TEXT            TO  RERLG-ERROR-RQST-TXT.

       2214-C-MOVE-SQL-INFO-X.
           EXIT.

      *--------------------
       2215-C-MOVE-CICS-INFO.
      *--------------------

           IF  WGLOB-LOGIC-ERROR
               MOVE 'LGIC'                     TO  RERLG-ERROR-TYP-CD
           ELSE
               MOVE 'CICS'                     TO  RERLG-ERROR-TYP-CD
           END-IF.
           MOVE SPACES                         TO  RERLG-ERROR-TBL-NM.
           MOVE WGLOB-ABEND-CD                 TO  RERLG-ERROR-CD.
           MOVE SPACES                         TO  RERLG-ERROR-RQST-TXT.
           MOVE WGLOB-ABEND-CD                 TO  RERLG-ERROR-DESC-TXT.

       2215-C-MOVE-CICS-INFO-X.
           EXIT.

019632*---------------------
019632 2216-C-MOVE-COMUN-INFO.
019632*---------------------
019632
019632     MOVE 'COMU'                         TO  RERLG-ERROR-TYP-CD.
019632     MOVE SPACES                         TO  RERLG-ERROR-TBL-NM.
019632     MOVE WGLOB-ABEND-CD                 TO  RERLG-ERROR-CD.
019632     MOVE WGLOB-ERROR-DESC-TXT           TO  RERLG-ERROR-DESC-TXT.
019632     MOVE SPACES                         TO  RERLG-ERROR-RQST-TXT.
019632
019632 2216-C-MOVE-COMUN-INFO-X.
019632     EXIT.
      /
      *---------------------------
       2220-C-WRITE-MSIN.
      *---------------------------
      *
      *  GENERATE MESSAGE, WHICH CAUSES MSIN RECORD TO BE WRITTEN
      *
           MOVE  'XS00300001'              TO  WGLOB-MSG-REF-INFO.
           IF  WGLOB-ABEND-CD  =  SPACES
           OR  WGLOB-ABEND-CD  =  'SQLC'
               MOVE  WGLOB-SQLCODE         TO  WS-SQLCODE
               MOVE  WS-SQLCODE            TO  WGLOB-MSG-PARM (1)
           ELSE
               MOVE  WGLOB-ABEND-CD        TO  WGLOB-MSG-PARM (1)
           END-IF.

           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
           MOVE WS-HOLD-CRNT-PGM-ID        TO WGLOB-CRNT-PGM-ID.
           MOVE WS-HOLD-PREV-PGM-ID        TO WGLOB-PREV-PGM-ID.

       2220-C-WRITE-MSIN-X.
           EXIT.
      /
      *---------------------------
       0030-1000-SQL-ERROR.
      *---------------------------

           IF  WGLOB-ENVRMNT-BATCH
               MOVE TEMSG-ABENDERR-RECORD (11) TO L0270-MSG-IN
               MOVE SQLCODE                 TO WS-SQLCODE
               MOVE WS-SQLCODE              TO L0270-MSG-PARM (1)
               PERFORM  0270-1000-TOKEN-REPLACEMENT
                   THRU 0270-1000-TOKEN-REPLACEMENT-X
               MOVE L0270-MSG-OUT           TO WS-AD-ERLG-MSG
           END-IF.

       0030-1000-SQL-ERROR-X.
           EXIT.
      /
      *----------------------
       0030-5000-LOGIC-ERROR.
      *----------------------

           IF  WGLOB-ENVRMNT-BATCH
               MOVE L0270-MSG-IN           TO L0270-MSG-OUT
           END-IF.

       0030-5000-LOGIC-ERROR-X.
           EXIT.
023514
023514*----------------------------
023514 9990-INIT-WORKING-STORAGE.
023514*----------------------------
023514
025970     PERFORM  0040-0000-INIT-PARM-INFO
025970         THRU 0040-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  0270-0000-INIT-PARM-INFO
025970         THRU 0270-0000-INIT-PARM-INFO-X.
025970
025970     PERFORM  1610-0000-INIT-PARM-INFO
025970         THRU 1610-0000-INIT-PARM-INFO-X.
025970
023514     CONTINUE.
023514
023514 9990-INIT-WORKING-STORAGE-X.
023514     EXIT.

      *****************************************************************
      *  LINKAGE PROCESSING COPYBOOKS                                 *
      *****************************************************************
       COPY XCPL0035.
025970 COPY XCPS0040.
       COPY XCPL0040.
025970 COPY XCPS1610.
       COPY XCPL1610.
025970 COPY XCPS0270.
       COPY XCPL0270.
       COPY XCPL0260.
      /
      *****************************************************************
      *  CICS PROCESSING COPYBOOKS                                    *
      *****************************************************************
026070*COPY XCCPABND.
AMQCNV*COPY XCCPERR.
      /
      *****************************************************************
      *  FILE I/O PROCESS MODULE                                      *
      *****************************************************************
       COPY XCPAERLG.
       COPY XCPBERLH.
      /
      *****************************************************************
      **                 END OF PROGRAM XSDU0030                     **
      *****************************************************************
