      *************************
       IDENTIFICATION DIVISION.
      *************************
      *
       PROGRAM-ID.  CSBM9355.
      *
AMQCNV*COPY XCWWCRHT.
      *****************************************************************
      **  MEMBER :  CSBM9355                                         **
      **  REMARKS:  TOTAL NUMBER OF POLICIES UNDER (SS534)           **
      **                                                             **
      **            THIS MODULE EXTRACTS FROM THE SALARY SAVINGS     **
      **            TOTAL NUMBER OF POLICIES CCSR9350 AND            **
      **            TOTAL NUMBER OF POLICIES REPORT                  **
      **                                                             **      
      **                                                             **
      **  DOMAIN :  AC                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
5013IP**  27OCT2005 GMIR   [P3A] AGENTS' SALARY SAVINGS (SS534)      **
5013IP**            BILLING TYPE                                     **
T01580**  18MAY2020 PHONGP  FIXING INITIAL                           **
AMQCNV**  15JAN2024 NHANTT CICS REPLACEMENT                          **
      *****************************************************************

      /
      **********************
       ENVIRONMENT DIVISION.
      **********************
       CONFIGURATION SECTION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.


      /
      ***************
       DATA DIVISION.
      ***************
       FILE SECTION.


      /
       WORKING-STORAGE SECTION.

       COPY XCWWPGWS REPLACING '$VAR1' BY 'CSBM9355'.

       COPY XCWWDFH.

       COPY SQLCA.

       COPY CCWWCCC.

       COPY XCSWPRT  REPLACING ==:ID:==  BY PRT1
                               ==':ID:'==  BY =='PRT1'==.
       
       COPY XCSWPRT  REPLACING ==:ID:==  BY PRT2
                               ==':ID:'==  BY =='PRT2'==.                               


       COPY CCFWEDIT.
       COPY CCFREDIT.
       
       COPY CCFWPOL.
       COPY CCFRPOL.
       
       COPY CCFRMAST.
       COPY CCFWMAST.

       COPY CCFWPSYS.
       COPY CCFRPSYS.
      
       COPY NCFWTTAB.
       COPY NCFRTTAB.

       COPY CCSRPRT1.
       COPY CCSRPRT2.
      
       01  WS-SAVE-AREA.              
           05  WS-SAVE-R9350-SERV-BR-ID     PIC X(05) VALUE SPACES.
           05  WS-SAVE-R9350-SERV-AGT-ID    PIC X(06) VALUE SPACES.           
           
           05  WS-SAVE-R9350-POL-ISS-EFF-DT.
               10  WS-SAVE-R9350-POL-ISS-EFF-YYYY PIC X(04)
                                                      VALUE SPACES.
               10  FILLER                         PIC X VALUE '-'.
               10  WS-SAVE-R9350-POL-ISS-EFF-MM   PIC X(02)
                                                      VALUE SPACES.
               10  FILLER                         PIC X VALUE '-'.                                                      
               10  WS-SAVE-R9350-POL-ISS-EFF-DD   PIC X(02)
                                                      VALUE SPACES.
           05  WS-SAVE-R9350-POL-PD-TO-DT.
               10  WS-SAVE-R9350-POL-PTD-YYYY     PIC X(04)
                                                      VALUE SPACES.
               10  FILLER                         PIC X VALUE '-'.                                                      
               10  WS-SAVE-R9350-POL-PTD-MM       PIC X(02)
                                                      VALUE SPACES.
               10  FILLER                         PIC X VALUE '-'.                                                      
               10  WS-SAVE-R9350-POL-PTD-DD       PIC X(02)
                                                      VALUE SPACES.
           05  WS-TITLE-DATE.
               10  WS-TITLE-DATE-DD         PIC X(02) VALUE SPACES.
               10  WS-TITLE-DATE-MMM        PIC X(03) VALUE SPACES.
               10  WS-TITLE-DATE-YYYY       PIC X(04) VALUE SPACES.
               10  WS-TITLE-DATE-XS         PIC X VALUE SPACES.

           05  WS-TITLE-DATE2.
               10  FILLER                   PIC X(53) VALUE SPACES.
               10  WS-AS-OF-DATE-LIT        PIC X(06) VALUE 'AS OF '.
               10  WS-AS-OF-DDMMMYYYY.               
                   15  WS-AS-OF-DATE-DD     PIC X(02) VALUE SPACES.
                   15  WS-AS-OF-DATE-MMM    PIC X(03) VALUE SPACES.
                   15  WS-AS-OF-DATE-YYYY   PIC X(04) VALUE SPACES.
               10  FILLER                   PIC X(63) VALUE SPACES.
           
           05  WS-SUB-HDG.
               10  FILLER                   PIC X(27) VALUE SPACES.   
               10  FILLER                   PIC X(10)
AMQCNV                                            VALUE 'ISSUE DAY'. 
               10  WS-SUB-HDG-ISS-DAY       PIC 9(02) VALUE ZEROES. 
               10  FILLER                   PIC X(93)  VALUE SPACES. 
               
           05  WS-DATE-EDIT.
               10 WS-DATE-YR                PIC X(04).
               10 WS-DATE-YR-NUM REDEFINES
                  WS-DATE-YR                PIC 9(04).               
               10 FILLER                    PIC X(01).
               10 WS-DATE-MM                PIC X(02).
               10 WS-DATE-MM-NUM REDEFINES
                  WS-DATE-MM                PIC 9(02). 
               10 FILLER                    PIC X(01).
               10 WS-DATE-DD                PIC X(02).
               10 WS-DATE-DD-NUM REDEFINES
                  WS-DATE-DD                PIC 9(02).                              
           
  
           
           05  WS-HDG-LINE-1                PIC X(132).
           05  WS-RPRT1-SEQ-REC-INFO        PIC X(132).  
           05  WS-RPRT2-SEQ-REC-INFO        PIC X(132).  
           05  WS-RPRT3-SEQ-REC-INFO        PIC X(132) VALUE SPACES.  
           05  WS-RPRT4-SEQ-REC-INFO        PIC X(132).  
           05  WS-REPORT-TITLE              PIC X(50).  
           
           05  WS-HDG-LINE-B                PIC X(132).
           05  WS-RPRT1-SEQ-REC-INFO-2      PIC X(132).  
           05  WS-RPRT2-SEQ-REC-INFO-2      PIC X(132).  
           05  WS-RPRT3-SEQ-REC-INFO-2      PIC X(132) VALUE SPACES.  
           05  WS-RPRT4-SEQ-REC-INFO-2      PIC X(132).  
          





           05  WS-PLAN-TOTAL                PIC 9(06) VALUE ZEROES.
           05  WS-MTH-TOTAL                 PIC 9(05) VALUE ZEROES.
           05  WS-ALL-PLAN-TOTAL            PIC 9(06) VALUE ZEROES.
 
           05  WS-RPT-TYP-CD                PIC X(01).
           05  WS-POL-INS-TYP-CD            PIC X(01).
           05  WS-PLAN-ID                   PIC X(06).
          
           05  WS-CONTROL-DATE              PIC X(10).          
           05  WS-MTH-END-DT                PIC X(10). 
           05  WS-PROC-YR                   PIC X(04).               

       01  WS-COUNTERS.
           05  WS-LINE-COUNT                PIC 9(02) VALUE 56.
           05  WS-PAGE-COUNT                PIC 9(05) VALUE 0.
           05  WS-REC-COUNT                 PIC 9(09) VALUE 0.

       
           05  WS-BR-IDX                    PIC 9(09) VALUE 0.  
           05  WS-MTH-IDX                   PIC 9(09) VALUE 0. 

       01  WS-COUNTERS-2.
           05  WS-LINE-COUNT-2              PIC 9(02) VALUE 59.
           05  WS-PAGE-COUNT-2              PIC 9(05) VALUE 0.
           05  WS-REC-COUNT-2               PIC 9(09) VALUE 0.
              
   
       01  WS-FLAGS-AND-SWITCHES.
           05  WS-FIRST-HEADER              PIC X(01) VALUE 'Y'.
           
           05  WS-ERROR-SW                  PIC X(01) VALUE 'N'.
               88  WS-ERRORS-FOUND          VALUE 'Y'.
           05  WS-INI1-SW                   PIC 9 VALUE 0.
               88  WS-INI1-YES              VALUE 0.
               88  WS-INI1-NO               VALUE 1.      
           05  WS-PLAN-SW                   PIC 9 VALUE 0.
               88  WS-PLAN-OFF              VALUE 0.
               88  WS-PLAN-ON               VALUE 1. 
  
    
       01  WS-SAVE-GRAND-TOTAL.
T01580*    05 WS-SAVE-R9350-POL-REC-CTR     PIC 9(09).
T01580*    05 WS-SAVE-R9350-POL-MPREM-AMT   PIC 9(13)V9(02). 
T01580*    05 WS-SAVE-ISS-DAY               PIC 9(02).
T01580     05 WS-SAVE-R9350-POL-REC-CTR     PIC 9(09) VALUE ZEROES.
T01580     05 WS-SAVE-R9350-POL-MPREM-AMT   PIC 9(13)V9(02)         
T01580                                                VALUE ZEROES.
T01580     05 WS-SAVE-ISS-DAY               PIC 9(02) VALUE ZEROES.
       
       
       01  WS-GRAND-TOTAL.
           05  FILLER                       PIC X(45) VALUE SPACES.                    
           05  FILLER                       PIC X(07) VALUE 'TOTALS:'.
           05  FILLER                       PIC X(07) VALUE SPACES.
           05  WS-TOT-R9350-POL-REC-CTR     PIC 9(05) VALUE ZEROES. 
           05  FILLER                       PIC X(15) VALUE SPACES.
           05  WS-TOT-R9350-POL-MPREM-AMT   PIC ZZZ,ZZZ,ZZ9.99. 
           05  FILLER                       PIC X(45) VALUE SPACES. 




       01  PRINT-DTL-LINE.
           05  FILLER                       PIC X(45) VALUE SPACES. 
           05  WS-DTL-R9350-POL-ISS-DAY     PIC 9(02) VALUE ZEROS.
           05  FILLER                       PIC X(12) VALUE SPACES. 
           05  WS-DTL-R9350-POL-REC-CTR     PIC 9(05) VALUE ZEROS.
           05  FILLER                       PIC X(15) VALUE SPACES. 
           05  WS-DTL-R9350-POL-MPREM-AMT   PIC ZZZ,ZZZ,ZZ9.99.
           05  FILLER                       PIC X(45)  VALUE SPACES.

       01  PRINT-DTL-LINE-1.
           05  FILLER                       PIC X(28) VALUE SPACES. 
           05  WS-DTL-R9350-SERV-BR-ID      PIC X(06) VALUE SPACES.
           05  FILLER                       PIC X(09) VALUE SPACES. 
           05  WS-DTL-R9350-SERV-AGT-ID     PIC X(06) VALUE SPACES.
           05  FILLER                       PIC X(08) VALUE SPACES. 
           05  WS-DTL-R9350-POL-PD-TO-DT.
               10  WS-DTL-R9350-POL-PTD-YYYY PIC X(04) VALUE SPACES.
               10  FILLER                   PIC X VALUE '-'.
               10  WS-DTL-R9350-POL-PTD-MM  PIC X(02) VALUE SPACES.
               10  FILLER                   PIC X VALUE '-'.
               10  WS-DTL-R9350-POL-PTD-DD  PIC X(02) VALUE SPACES.
           05  FILLER                       PIC X(06) VALUE SPACES. 
           05  WS-DTL-R9350-POL-ID          PIC X(10) VALUE SPACES.
           05  FILLER                       PIC X(07) VALUE SPACES. 
           05  WS-DTL-R9350-POL-MPREM-AMT2  PIC ZZZ,ZZZ,ZZ9.99.
           05  FILLER                       PIC X(28) VALUE SPACES.       
    
       COPY CCSR9350.
       COPY XCSWSEQ  REPLACING ==:ID:==  BY 9350
                               ==':ID:'==  BY =='9350'==.

       COPY XCWL0017.
       COPY XCWL0035.

       COPY XCWL0010.
       COPY CCWL0950.
       COPY XCWL0040.
      /
       COPY XCWL0290.
      /

       COPY XCSWPRT  REPLACING ==:ID:==  BY OCF
                               ==':ID:'==  BY =='OCF'==.
       COPY XCSROCF.
       COPY XCSWSEQ  REPLACING ==:ID:==  BY BCF
                               ==':ID:'==  BY =='BCF'==.
       COPY XCSRBCF.
       
       COPY CCWL0460.

       COPY XCWWHDG.
       COPY XCWWPARM.

      /

       01  WGLOB-GLOBAL-AREA.
       COPY XCWWGLOB.
       COPY XCWTFCMD.
      /
       COPY XCWL1640.
       COPY XCWL2490.
       COPY XCWLDTLK.
      ********************
       PROCEDURE DIVISION.
      ********************

      *--------------
       0000-MAINLINE.
      *--------------

           PERFORM  0100-OPEN-FILES
               THRU 0100-OPEN-FILES-X.

           PERFORM  1000-INITIALIZATION
               THRU 1000-INITIALIZATION-X.
                              
           
           PERFORM  2000-PROCESS-9355-CCSR9350
               THRU 2000-PROCESS-9355-CCSR9350-X
             UNTIL W9350-SEQ-IO-EOF.
           PERFORM 2550-TOTAL-RTN
               THRU 2550-TOTAL-RTN-X.
       
           PERFORM  9999-CLOSE-FILES
               THRU 9999-CLOSE-FILES-X.

           PERFORM  0017-2000-BATCH-PGM-ENDS
               THRU 0017-2000-BATCH-PGM-ENDS-X.

           STOP RUN.


       0000-MAINLINE-X.
           EXIT.
      /
      *----------------
       0100-OPEN-FILES.
      *----------------

           PERFORM  OCF-3000-OPEN-OUTPUT
               THRU OCF-3000-OPEN-OUTPUT-X.

           PERFORM  BCF-1000-OPEN-INPUT
               THRU BCF-1000-OPEN-INPUT-X.

           PERFORM  9350-1000-OPEN-INPUT
               THRU 9350-1000-OPEN-INPUT-X.

           PERFORM  PRT1-3000-OPEN-OUTPUT
               THRU PRT1-3000-OPEN-OUTPUT-X.
               
           PERFORM  PRT2-3000-OPEN-OUTPUT
               THRU PRT2-3000-OPEN-OUTPUT-X.    
   
       0100-OPEN-FILES-X.
           EXIT.

      /
      *--------------------
       1000-INITIALIZATION.
      *--------------------

           PERFORM  CCC-1000-PRCES-CO-CTL-CARDS
               THRU CCC-1000-PRCES-CO-CTL-CARDS-X.
               
           PERFORM  0017-0000-INIT-PARM-INFO
               THRU 0017-0000-INIT-PARM-INFO-X.

           PERFORM  0017-1000-BATCH-PGM-STARTS
               THRU 0017-1000-BATCH-PGM-STARTS-X.

           IF WS-ERRORS-FOUND
              PERFORM  0030-4000-CTL-CARD-ERROR
                  THRU 0030-4000-CTL-CARD-ERROR-X
           END-IF.

           MOVE WPGWS-CRNT-PGM-ID      TO L2490-TXT-SRC-ID.
           PERFORM  0950-0000-INIT-PARM-INFO
               THRU 0950-0000-INIT-PARM-INFO-X.

           PERFORM  0950-1000-GET-COMPANY-NAME
               THRU 0950-1000-GET-COMPANY-NAME-X.

           MOVE SPACES                 TO WHDG-LINE-1.
           MOVE SPACES                 TO WHDG-LINE-2.
           MOVE SPACES                 TO WHDG-LINE-3.

           PERFORM  HDG-1000-INIT-CONSTANTS
               THRU HDG-1000-INIT-CONSTANTS-X.

           MOVE L0950-COMPANY-NAME     TO WHDG-COMPANY-NAME.
           MOVE L0950-COMPANY-DATE     TO WHDG-DATE.          
           MOVE L0950-COMPANY-TIME     TO WHDG-TIME.
           MOVE WPGWS-CRNT-PGM-ID      TO WHDG-PROGRAM-ID.
           MOVE SPACES                 TO WHDG-REPORT-TITLE.
           
      *MSG: INGENIUM  6.6
           MOVE 'XS00000145'           TO WGLOB-MSG-REF-INFO.
           PERFORM  0260-2000-GET-MESSAGE
               THRU 0260-2000-GET-MESSAGE-X.
           MOVE WGLOB-MSG-TXT          TO L0040-SYSTEM-ID.
           MOVE WGLOB-MSG-TXT          TO WHDG-SYSTEM-ID.

           MOVE L0950-COMPANY-NAME     TO L0040-COMPANY-NAME.
           MOVE ZERO                   TO L0040-ERROR-CNT.
           MOVE SPACES                 TO L0040-PROGRAM-DESC.

           PERFORM  0040-1000-INIT-TITLE
               THRU 0040-1000-INIT-TITLE-X.
               
           PERFORM 0460-0000-INIT-PARM-INFO
              THRU 0460-0000-INIT-PARM-INFO-X.
           PERFORM 0460-1000-READ-MAST-ONLY
              THRU 0460-1000-READ-MAST-ONLY-X.
   
           IF  NOT L0460-RETRN-OK
                PERFORM  0030-5000-LOGIC-ERROR
                   THRU 0030-5000-LOGIC-ERROR-X
           END-IF.        
               
           MOVE RMAST-BTCH-PRCES-DT    TO WS-DATE-EDIT.
           MOVE WS-DATE-YR-NUM         TO WGLOB-PROCESS-DATE-YR.
           MOVE WS-DATE-MM-NUM         TO WGLOB-PROCESS-DATE-MO.
           MOVE WS-DATE-DD-NUM         TO WGLOB-PROCESS-DATE-DY.
           
           MOVE WGLOB-PROCESS-DATE    TO L1640-INTERNAL-DATE.
           PERFORM 1640-2000-INTERNAL-TO-EXT
              THRU 1640-2000-INTERNAL-TO-EXT-X.
           MOVE L1640-EXTERNAL-DATE   TO WS-AS-OF-DDMMMYYYY.                      
               

      *
      * FIRST READ OF INPUT FILE
      *
           PERFORM  1200-READ-FILE
               THRU 1200-READ-FILE-X.

           IF W9350-SEQ-IO-EOF
      *MSG:   'INPUT FILE EMPTY - NO DATA TO PROCESS'
              MOVE 'CS93550001'        TO WGLOB-MSG-REF-INFO
              PERFORM  0260-1000-GENERATE-MESSAGE
                  THRU 0260-1000-GENERATE-MESSAGE-X
              GO TO 1000-INITIALIZATION-X
           END-IF.

           MOVE ZEROES                 TO WS-PAGE-COUNT.
           MOVE ZEROES                 TO WS-PAGE-COUNT-2.
       1000-INITIALIZATION-X.
           EXIT.

      *----------------------------
       1110-DUPL-CTL-CARD.
      *----------------------------

      *MSG: DUPLICATE @1 CONTROL CARD
           MOVE 'XS00000366'           TO WGLOB-MSG-REF-INFO.
           MOVE WPARM-DESCRIPTION      TO WGLOB-MSG-PARM (1).
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
           PERFORM  0030-4000-CTL-CARD-ERROR
               THRU 0030-4000-CTL-CARD-ERROR-X.
                                                                                                                                            
       1110-DUPL-CTL-CARD-X.
           EXIT.
      /
      *----------------------------
       1120-CTL-CARD-TRUNCATED.
      *----------------------------

      *MSG: @1 CONTROL CARD DATA TRUNCATED
           MOVE 'XS00000368'           TO WGLOB-MSG-REF-INFO.
           MOVE WPARM-DESCRIPTION      TO WGLOB-MSG-PARM (1).
           PERFORM  0260-1000-GENERATE-MESSAGE
               THRU 0260-1000-GENERATE-MESSAGE-X.
           PERFORM  0030-4000-CTL-CARD-ERROR
               THRU 0030-4000-CTL-CARD-ERROR-X.

       1120-CTL-CARD-TRUNCATED-X.
           EXIT.

      *--------------------
       1130-EDIT-RUN-DATE.
      *--------------------

           MOVE WS-CONTROL-DATE        TO L1640-EXTERNAL-DATE.

           PERFORM  1640-6000-CTL-CARD-TO-INT
               THRU 1640-6000-CTL-CARD-TO-INT-X.

           MOVE L1640-INTERNAL-DATE    TO WGLOB-PROCESS-DATE.

           IF L1640-NOT-VALID
      *MSG: INVALID PROCESS DATE
               MOVE 'XS00000159'       TO WGLOB-MSG-REF-INFO
               PERFORM  0260-1000-GENERATE-MESSAGE
                   THRU 0260-1000-GENERATE-MESSAGE-X
               PERFORM  0030-4000-CTL-CARD-ERROR
                   THRU 0030-4000-CTL-CARD-ERROR-X
           END-IF.

       1130-EDIT-RUN-DATE-X.
           EXIT.
      /
      *---------------------------
       1200-READ-FILE.
      *---------------------------

           PERFORM  9350-1000-READ
               THRU 9350-1000-READ-X.
               
           IF R9350-SEQ-REC-INFO = SPACES
              PERFORM 9350-1000-READ
                 THRU 9350-1000-READ-X
           END-IF.

           IF W9350-SEQ-IO-EOF
           OR R9350-SEQ-REC-INFO = HIGH-VALUES
              SET  W9350-SEQ-IO-EOF    TO TRUE
           END-IF.

           IF W9350-SEQ-IO-OK
           AND NOT W9350-SEQ-IO-EOF
              ADD 1 TO WS-REC-COUNT
           END-IF.

       1200-READ-FILE-X.
           EXIT.

      /
      *---------------------------
       2000-PROCESS-9355-CCSR9350.          
      *---------------------------          
           IF R9350-REC-SUMMARY
                  
              MOVE R9350-POL-ISS-DAY 
                                    TO    WS-DTL-R9350-POL-ISS-DAY
              MOVE R9350-POL-REC-CTR          
                                    TO    WS-DTL-R9350-POL-REC-CTR
              MOVE R9350-POL-MPREM-AMT    
                                    TO    WS-DTL-R9350-POL-MPREM-AMT       
              
              COMPUTE WS-SAVE-R9350-POL-REC-CTR =
               (WS-SAVE-R9350-POL-REC-CTR + R9350-POL-REC-CTR)                                              
              
              COMPUTE WS-SAVE-R9350-POL-MPREM-AMT =
               (WS-SAVE-R9350-POL-MPREM-AMT + R9350-POL-MPREM-AMT)  
                                         
              MOVE WS-SAVE-R9350-POL-REC-CTR 
                                    TO    WS-TOT-R9350-POL-REC-CTR   
              MOVE WS-SAVE-R9350-POL-MPREM-AMT 
                                    TO    WS-TOT-R9350-POL-MPREM-AMT
              
              
              PERFORM  2500-PRNT-DTL-RPT           
                  THRU 2500-PRNT-DTL-RPT-X          
           
              PERFORM 1200-READ-FILE
                  THRU 1200-READ-FILE-X
           
           END-IF.
           
    
           IF R9350-REC-DETAIL 
              MOVE R9350-POL-ISS-DAY TO WS-SAVE-ISS-DAY

      
              PERFORM UNTIL R9350-POL-ISS-DAY NOT = WS-SAVE-ISS-DAY
                    OR W9350-SEQ-IO-EOF
                  
                  MOVE  R9350-SERV-BR-ID      
                                       TO WS-DTL-R9350-SERV-BR-ID
                  MOVE  R9350-SERV-AGT-ID
                                       TO WS-DTL-R9350-SERV-AGT-ID
                  MOVE  R9350-POL-PD-TO-DT
                                       TO WS-DTL-R9350-POL-PD-TO-DT
                  MOVE  R9350-POL-ID
                                       TO WS-DTL-R9350-POL-ID
                  MOVE  R9350-POL-MPREM-AMT
                                       TO WS-DTL-R9350-POL-MPREM-AMT2
                  PERFORM 2500-PRNT-DTL-RPT2    
                      THRU 2500-PRNT-DTL-RPT2-X   
                          
                  PERFORM 1200-READ-FILE
                      THRU 1200-READ-FILE-X
              END-PERFORM       
              IF   R9350-POL-ISS-DAY NOT = WS-SAVE-ISS-DAY
                   PERFORM 2600-PRNT-SUB-HDG-RTN
                      THRU 2600-PRNT-SUB-HDG-RTN-X
              END-IF            
           END-IF.
       
      
       2000-PROCESS-9355-CCSR9350-X.
           EXIT.
      
      
    
      *-------------------------
       2300-HEADINGS-RPRT1.
      *-------------------------

           PERFORM  2490-1000-BUILD-PARM-INFO
               THRU 2490-1000-BUILD-PARM-INFO-X.
           
           MOVE WPGWS-CRNT-PGM-ID      TO L2490-TXT-SRC-ID.
           
           MOVE '90001'                TO L2490-TXT-SRC-REF-ID.
           PERFORM  2490-1000-RETRIEVE-TEXT
               THRU 2490-1000-RETRIEVE-TEXT-X.
           MOVE L2490-TXT-STR-TXT      TO WS-HDG-LINE-1.

           MOVE '90002'                TO L2490-TXT-SRC-REF-ID.
           PERFORM  2490-1000-RETRIEVE-TEXT
               THRU 2490-1000-RETRIEVE-TEXT-X.
           MOVE L2490-TXT-STR-TXT      TO WS-RPRT1-SEQ-REC-INFO.

           MOVE '90003'                TO L2490-TXT-SRC-REF-ID.
           PERFORM  2490-1000-RETRIEVE-TEXT
               THRU 2490-1000-RETRIEVE-TEXT-X.
           MOVE L2490-TXT-STR-TXT      TO WS-RPRT2-SEQ-REC-INFO.
           
           
           MOVE 12                 TO WS-LINE-COUNT.                       
          
           PERFORM  2400-PRINT-NEW-PAGE-RPRT1
               THRU 2400-PRINT-NEW-PAGE-RPRT1-X.
         
       2300-HEADINGS-RPRT1-X.
           EXIT.
      
    
    
 
      *-------------------------
       2300-HEADINGS-RPRT2.
      *-------------------------
 
            PERFORM  2490-1000-BUILD-PARM-INFO
                THRU 2490-1000-BUILD-PARM-INFO-X.
            
            MOVE WPGWS-CRNT-PGM-ID      TO L2490-TXT-SRC-ID.
            
            MOVE '90004'                TO L2490-TXT-SRC-REF-ID.
            PERFORM  2490-1000-RETRIEVE-TEXT
                THRU 2490-1000-RETRIEVE-TEXT-X.
            MOVE L2490-TXT-STR-TXT      TO WS-HDG-LINE-B.
 
            MOVE '90005'                TO L2490-TXT-SRC-REF-ID.
            PERFORM  2490-1000-RETRIEVE-TEXT
                THRU 2490-1000-RETRIEVE-TEXT-X.
            MOVE L2490-TXT-STR-TXT      TO WS-RPRT1-SEQ-REC-INFO-2.
 
            MOVE '90006'                TO L2490-TXT-SRC-REF-ID.
            PERFORM  2490-1000-RETRIEVE-TEXT
                THRU 2490-1000-RETRIEVE-TEXT-X.
            MOVE L2490-TXT-STR-TXT      TO WS-RPRT2-SEQ-REC-INFO-2.
            
          
            MOVE 10                     TO WS-LINE-COUNT-2.                       
           
            PERFORM  2400-PRINT-NEW-PAGE-RPRT2
                THRU 2400-PRINT-NEW-PAGE-RPRT2-X.
          
        2300-HEADINGS-RPRT2-X.
            EXIT.
       

      *--------------------------
       2400-PRINT-NEW-PAGE-RPRT1.
      *--------------------------

           ADD 1                       TO WS-PAGE-COUNT.
           MOVE WS-PAGE-COUNT          TO WHDG-PAGE.
           MOVE SPACES                 TO RPRT1-SEQ-REC-INFO.
           PERFORM  PRT1-2000-WRITE
               THRU PRT1-2000-WRITE-X.
           MOVE +2                     TO WPRT1-NUMBER-LINES.
           
           MOVE WHDG-LINE-1            TO RPRT1-SEQ-REC-INFO.
           PERFORM  PRT1-1000-WRITE
               THRU PRT1-1000-WRITE-X.
           MOVE +1                     TO WPRT1-NUMBER-LINES.
           
           MOVE WHDG-LINE-2            TO RPRT1-SEQ-REC-INFO.
           PERFORM  PRT1-1000-WRITE
               THRU PRT1-1000-WRITE-X.
           MOVE +1                     TO WPRT1-NUMBER-LINES.
           
           MOVE WS-HDG-LINE-1          TO RPRT1-SEQ-REC-INFO.
           PERFORM  PRT1-1000-WRITE
               THRU PRT1-1000-WRITE-X.
           MOVE +1                     TO WPRT1-NUMBER-LINES.

           MOVE WS-TITLE-DATE2         TO RPRT1-SEQ-REC-INFO.
           PERFORM  PRT1-1000-WRITE
               THRU PRT1-1000-WRITE-X.
           MOVE +2                     TO WPRT1-NUMBER-LINES.
           
                    
           MOVE WS-RPRT1-SEQ-REC-INFO  TO RPRT1-SEQ-REC-INFO.
           PERFORM  PRT1-1000-WRITE
               THRU PRT1-1000-WRITE-X.
           MOVE +1                     TO WPRT1-NUMBER-LINES.
           
           MOVE WS-RPRT2-SEQ-REC-INFO  TO RPRT1-SEQ-REC-INFO.
           PERFORM  PRT1-1000-WRITE
               THRU PRT1-1000-WRITE-X.
           MOVE +1                     TO WPRT1-NUMBER-LINES.

   
               
       2400-PRINT-NEW-PAGE-RPRT1-X.
           EXIT.
      /
     
      
      *--------------------------
       2400-PRINT-NEW-PAGE-RPRT2.
      *--------------------------

           ADD 1                       TO WS-PAGE-COUNT-2.
           MOVE WS-PAGE-COUNT-2        TO WHDG-PAGE.
           MOVE SPACES                 TO RPRT2-SEQ-REC-INFO.
           PERFORM  PRT2-2000-WRITE
               THRU PRT2-2000-WRITE-X.
           MOVE +2                     TO WPRT2-NUMBER-LINES.
           
           MOVE WHDG-LINE-1            TO RPRT2-SEQ-REC-INFO.
           PERFORM  PRT2-1000-WRITE
               THRU PRT2-1000-WRITE-X.
           MOVE +1                     TO WPRT2-NUMBER-LINES.
           
           MOVE WHDG-LINE-2            TO RPRT2-SEQ-REC-INFO.
           PERFORM  PRT2-1000-WRITE
               THRU PRT2-1000-WRITE-X.
           MOVE +1                     TO WPRT2-NUMBER-LINES.
           
           MOVE WS-HDG-LINE-B          TO RPRT2-SEQ-REC-INFO.
           PERFORM  PRT2-1000-WRITE
               THRU PRT2-1000-WRITE-X.
           MOVE +1                     TO WPRT2-NUMBER-LINES.
            
           PERFORM 2600-PRNT-SUB-HDG-RTN
                      THRU 2600-PRNT-SUB-HDG-RTN-X.
                      
      
  
               
       2400-PRINT-NEW-PAGE-RPRT2-X.
           EXIT.
      /
     
      
      *--------------------------
       2500-PRNT-DTL-RPT.
      *--------------------------
             
           IF WS-LINE-COUNT > 55
               PERFORM  2300-HEADINGS-RPRT1
                   THRU 2300-HEADINGS-RPRT1-X
               MOVE 13                 TO WS-LINE-COUNT                  
           END-IF.
      
           MOVE PRINT-DTL-LINE         TO RPRT1-SEQ-REC-INFO.

           PERFORM  PRT1-1000-WRITE
               THRU PRT1-1000-WRITE-X.    
           MOVE +1                     TO WPRT1-NUMBER-LINES.               

           ADD 1                       TO WS-LINE-COUNT.
           
           
       2500-PRNT-DTL-RPT-X.
           EXIT.    
      /  
      
            
      *--------------------------
       2500-PRNT-DTL-RPT2.
      *--------------------------
             
           IF WS-LINE-COUNT-2 > 58
               PERFORM  2300-HEADINGS-RPRT2
                   THRU 2300-HEADINGS-RPRT2-X
               MOVE 13                 TO WS-LINE-COUNT-2               
           END-IF.
           
           MOVE PRINT-DTL-LINE-1       TO RPRT2-SEQ-REC-INFO.

           PERFORM  PRT2-1000-WRITE
               THRU PRT2-1000-WRITE-X.    
           MOVE +1                     TO WPRT2-NUMBER-LINES.               

           ADD 1                       TO WS-LINE-COUNT-2.
           
          
       2500-PRNT-DTL-RPT2-X.
           EXIT.          
      
      *-------------------------
       2550-TOTAL-RTN.
      *-------------------------
           MOVE WS-GRAND-TOTAL      TO RPRT1-SEQ-REC-INFO
           PERFORM  PRT1-1000-WRITE
               THRU PRT1-1000-WRITE-X.    
       2550-TOTAL-RTN-X.
           EXIT.
      
      *--------------------------
       2600-PRNT-SUB-HDG-RTN.
      *-------------------------- 
           
           MOVE  SPACES                  TO  RPRT2-SEQ-REC-INFO.
           PERFORM  PRT2-1000-WRITE
               THRU PRT2-1000-WRITE-X.           
           MOVE +1                       TO  WPRT2-NUMBER-LINES.
             
           ADD  1                        TO  WS-LINE-COUNT-2.
           
           MOVE  R9350-POL-ISS-DAY       TO  WS-SUB-HDG-ISS-DAY.
           
           
           
           MOVE  WS-SUB-HDG              TO  RPRT2-SEQ-REC-INFO.
           PERFORM  PRT2-1000-WRITE
               THRU PRT2-1000-WRITE-X.           
           ADD 1                         TO WS-LINE-COUNT-2.  
           MOVE +1                       TO WPRT2-NUMBER-LINES.
           
           

           MOVE WS-RPRT1-SEQ-REC-INFO-2  TO RPRT2-SEQ-REC-INFO.
           PERFORM  PRT2-1000-WRITE
               THRU PRT2-1000-WRITE-X.
           MOVE +1                       TO WPRT2-NUMBER-LINES.
           ADD 1                         TO WS-LINE-COUNT-2.
           
           MOVE WS-RPRT2-SEQ-REC-INFO-2  TO RPRT2-SEQ-REC-INFO.
           PERFORM  PRT2-1000-WRITE
               THRU PRT2-1000-WRITE-X.
           MOVE +1                       TO WPRT2-NUMBER-LINES.
           ADD 1                         TO WS-LINE-COUNT-2.
         
       
       
       
       2600-PRNT-SUB-HDG-RTN-X.
           EXIT.
      *-----------------
       9999-CLOSE-FILES.
      *-----------------

           PERFORM  OCF-4000-CLOSE
               THRU OCF-4000-CLOSE-X.

           PERFORM  BCF-4000-CLOSE
               THRU BCF-4000-CLOSE-X.

           PERFORM  9350-4000-CLOSE
               THRU 9350-4000-CLOSE-X.

           PERFORM  PRT1-4000-CLOSE
               THRU PRT1-4000-CLOSE-X.

           PERFORM  PRT2-4000-CLOSE
               THRU PRT2-4000-CLOSE-X.               

       9999-CLOSE-FILES-X.
           EXIT.

       COPY XCPPCCC.
      
       COPY XCSLFILE REPLACING ==:ID:== BY PRT1
                         ==':PGM:'== BY =='CSRQPRT1'==.
       COPY XCSAPRT  REPLACING ==:ID:==  BY PRT1.
       COPY XCSOFILE REPLACING ==:ID:==  BY PRT1.

       COPY XCSLFILE REPLACING ==:ID:== BY PRT2
                         ==':PGM:'== BY =='CSRQPRT2'==.
       COPY XCSAPRT  REPLACING ==:ID:==  BY PRT2.
       COPY XCSOFILE REPLACING ==:ID:==  BY PRT2.


       COPY XCPL0035.

       COPY CCPNPSYS.
       COPY CCPNEDIT.
       COPY NCPNTTAB.
       COPY CCPESGFD.

       COPY XCPL0010.

       COPY CCPS0460.
       COPY CCPL0460.

       COPY XCSLFILE REPLACING ==:ID:==  BY 9350
                               ==':PGM:'== BY =='CSRQ9350'==.
       COPY CCPL0950.
       COPY XCPS0010.
       COPY CCPS0950.
       COPY XCPL0040.
       COPY XCPL0260.
       COPY XCCP0030.
       COPY XCSLFILE REPLACING ==:ID:==  BY OCF
                               ==':PGM:'== BY =='XSRQOCF'==.
       COPY XCSLFILE REPLACING ==:ID:==  BY BCF
                               ==':PGM:'== BY =='XSRQBCF'==.

       COPY XCSOFILE REPLACING ==:ID:==  BY 9350.
       COPY XCSNSEQ  REPLACING ==:ID:==  BY 9350.
       COPY XCSOFILE REPLACING ==:ID:==  BY OCF.
       COPY XCSOFILE REPLACING ==:ID:==  BY BCF.
       COPY XCSNSEQ  REPLACING ==:ID:==  BY BCF.

       COPY XCPL1640.
       COPY XCPS2490.
       COPY XCPL2490.
       COPY XCPS0017.
       COPY XCPL0017.
      /
       COPY XCPS0290.
       COPY XCPL0290.
      /
       COPY XCPPHDG.

      *
      *****************************************************************
      **                 END OF PROGRAM CSBM9355                     **
      *****************************************************************
