      *****************************************************************
      **  MEMBER :  MQOBJ                                         **
      **  REMARKS:  PROGRAM WORKING STORAGE AREA                     **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
      *****************************************************************
 
           05  WS-STMO-:ID:.
               10  STMF-:ID:                       PIC S9(09) COMP-5.
                   88  STMF-:ID:-CONN              VALUE 0.
                   88  STMF-:ID:-DISC              VALUE 1.
                   88  STMF-:ID:-OPEN              VALUE 2.
                   88  STMF-:ID:-CLOSE             VALUE 3.
                   88  STMF-:ID:-PUT               VALUE 4.
                   88  STMF-:ID:-GET               VALUE 5.

               10  WS-STMO-:ID:-DEST               PIC X(80).
               10  WS-STMO-:ID:-SOCK               PIC S9(09) COMP-5.
               10  WS-STMO-:ID:-VERS               PIC X(80).

               10  STMR-:ID:                       PIC S9(08) COMP-5.
                   88  STMR-:ID:-OK                VALUE 0.
                   88  STMR-:ID:-ERR-SOCKET        VALUE 1.
                   88  STMR-:ID:-ERR-CONNECT       VALUE 11.
                   88  STMR-:ID:-ERR-DISCONNECT    VALUE 12.
                   88  STMR-:ID:-ERR-OPEN          VALUE 13.
                   88  STMR-:ID:-ERR-CLOSE         VALUE 14.
                   88  STMR-:ID:-ERR-PUT           VALUE 15.
                   88  STMR-:ID:-ERR-GET           VALUE 16.
                   88  STMR-:ID:-ERR-TIMEOUT       VALUE 55.
                   88  STMR-:ID:-ERR-EXCEPTION     VALUE 97.
                   88  STMR-:ID:-ERR-LINK          VALUE 98.
                   88  STMR-:ID:-INVALD-RQST       VALUE 99.

               10  STME-:ID:                       PIC S9(08) COMP-5.

               10  STMOD-:ID:.
                   15  STMOD-:ID:-TYPE             PIC S9(09) COMP-5.
                       88  STMOD-:ID:-TYPE-QUEUE   VALUE 1.
                       88  STMOD-:ID:-TYPE-TOPIC   VALUE 2.
                   15  STMOD-:ID:-NAME             PIC X(80).

               10  STMGO-:ID:.
                   15  STMGO-:ID:-WAIT-TIME        PIC S9(09) COMP-5.
                       88  STMGO-:ID:-WAIT-NONE    VALUE 0.
                       88  STMGO-:ID:-WAIT-UNLIMITED    VALUE -1.
                   15  STMGO-:ID:-CLI-ACK          PIC S9(09) COMP-5.

               10  STMMD-:ID:.
                   15  STMMD-:ID:-CORE-ID          PIC X(256).
                   15  STMMD-:ID:-MSG-ID           PIC X(256).
                   15  STMMD-:ID:-VERS             PIC X(80).
                   15  STMMD-:ID:-DEST             PIC X(80).

      *****************************************************************
      **                 END OF COPYBOOK MQOBJ                    **
      *****************************************************************
