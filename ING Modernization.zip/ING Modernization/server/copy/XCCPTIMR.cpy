      *****************************************************************
      **  MEMBER :  XCCPTIMR                                         **
      **  REMARKS:                                                   **
      **                                                             **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
026766**  6.6       PERFORMANCE MONITORING                           **
AMQCNV**  15JAN2024 NHANTT CICS REPLACEMENT                          **
      *****************************************************************

      *----------------------------
       TIMR-0000-GET-TIME.
      *----------------------------

AMQCNV*    CALL WTIMR-TIMER-PROGRAM USING DFHEIBLK
AMQCNV*                                   DFHCOMMAREA
AMQCNV*                                   LTIMR-PARM-INFO.
AMQCNV     CALL WTIMR-TIMER-PROGRAM USING LTIMR-PARM-INFO.

       TIMR-0000-GET-TIME-X.
           EXIT.

      *----------------------------
       TIMR-1000-ENTRY-TIME.
      *----------------------------

           IF  NOT WGLOB-GENERATE-STATS-ALL
               GO TO TIMR-1000-ENTRY-TIME-X
           END-IF.

           SET WTIMR-REC-ENTRY           TO TRUE.

           PERFORM  TIMR-0000-GET-TIME
               THRU TIMR-0000-GET-TIME-X.
           MOVE LTIMR-NS9                TO WTIMR-TIME.

           ADD +1                        TO WGLOB-STAT-LEVEL.
           MOVE WGLOB-STAT-LEVEL         TO WTIMR-STAT-LEVEL.

           PERFORM  TIMR-5000-LOG-TIME
               THRU TIMR-5000-LOG-TIME-X.

       TIMR-1000-ENTRY-TIME-X.
           EXIT.

      *----------------------------
       TIMR-2000-START-PX-TIME.
      *----------------------------

           IF  NOT WGLOB-GENERATE-STATS-ALL
               GO TO TIMR-2000-START-PX-TIME-X
           END-IF.

           SET WTIMR-REC-START-PX        TO TRUE.
           ADD +1                        TO WGLOB-STAT-LEVEL.
           MOVE WGLOB-STAT-LEVEL         TO WTIMR-STAT-LEVEL.

           PERFORM  TIMR-0000-GET-TIME
               THRU TIMR-0000-GET-TIME-X.
           MOVE LTIMR-NS9                TO WTIMR-TIME.

           PERFORM  TIMR-5000-LOG-TIME
               THRU TIMR-5000-LOG-TIME-X.

       TIMR-2000-START-PX-TIME-X.
           EXIT.

      *----------------------------
       TIMR-3000-PX-RETURN-TIME.
      *----------------------------

           IF  NOT WGLOB-GENERATE-STATS-ALL
               GO TO TIMR-3000-PX-RETURN-TIME-X
           END-IF.

           SET WTIMR-REC-END-PX          TO TRUE.

           PERFORM  TIMR-0000-GET-TIME
               THRU TIMR-0000-GET-TIME-X.
           MOVE LTIMR-NS9                TO WTIMR-TIME.

           PERFORM  TIMR-5000-LOG-TIME
               THRU TIMR-5000-LOG-TIME-X.

           SUBTRACT +1                   FROM WGLOB-STAT-LEVEL.
           MOVE WGLOB-STAT-LEVEL         TO WTIMR-STAT-LEVEL.

       TIMR-3000-PX-RETURN-TIME-X.
           EXIT.

      *----------------------------
       TIMR-4000-EXIT-TIME.
      *----------------------------

           IF  NOT WGLOB-GENERATE-STATS-ALL
               GO TO TIMR-4000-EXIT-TIME-X
           END-IF.

           SET WTIMR-REC-EXIT            TO TRUE.

           PERFORM  TIMR-0000-GET-TIME
               THRU TIMR-0000-GET-TIME-X.
           MOVE LTIMR-NS9                TO WTIMR-TIME.

           PERFORM  TIMR-5000-LOG-TIME
               THRU TIMR-5000-LOG-TIME-X.

           SUBTRACT +1                   FROM WGLOB-STAT-LEVEL.
           MOVE WGLOB-STAT-LEVEL         TO WTIMR-STAT-LEVEL.

       TIMR-4000-EXIT-TIME-X.
           EXIT.

      *----------------------------
       TIMR-5000-LOG-TIME.
      *----------------------------

           DISPLAY WTIMR-TIME-INFO.

       TIMR-5000-LOG-TIME-X.
           EXIT.

      *----------------------------
       TIMR-6000-MAIN-ENTRY-TIME.
      *----------------------------

           IF  WGLOB-GENERATE-STATS-NONE
               GO TO TIMR-6000-MAIN-ENTRY-TIME-X
           END-IF.

           SET WTIMR-REC-ENTRY           TO TRUE.

           PERFORM  TIMR-0000-GET-TIME
               THRU TIMR-0000-GET-TIME-X.
           MOVE LTIMR-NS9                TO WTIMR-TIME.

           ADD +1                        TO WGLOB-STAT-LEVEL.
           MOVE WGLOB-STAT-LEVEL         TO WTIMR-STAT-LEVEL.

           PERFORM  TIMR-5000-LOG-TIME
               THRU TIMR-5000-LOG-TIME-X.

       TIMR-6000-MAIN-ENTRY-TIME-X.
           EXIT.

      *----------------------------
       TIMR-7000-MAIN-EXIT-TIME.
      *----------------------------

           IF  WGLOB-GENERATE-STATS-NONE
               GO TO TIMR-7000-MAIN-EXIT-TIME-X
           END-IF.

           SET WTIMR-REC-EXIT            TO TRUE.

           PERFORM  TIMR-0000-GET-TIME
               THRU TIMR-0000-GET-TIME-X.
           MOVE LTIMR-NS9                TO WTIMR-TIME.

           PERFORM  TIMR-5000-LOG-TIME
               THRU TIMR-5000-LOG-TIME-X.

           SUBTRACT +1                   FROM WGLOB-STAT-LEVEL.
           MOVE WGLOB-STAT-LEVEL         TO WTIMR-STAT-LEVEL.

       TIMR-7000-MAIN-EXIT-TIME-X.
           EXIT.

      *****************************************************************
      **                 END OF COPYBOOK XCCPTIMR                    **
      *****************************************************************
