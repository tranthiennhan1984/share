      *****************************************************************
      **  MEMBER :  XCPPSOKT                                         **
      **  REMARKS:  WINDOWS SOCKETS API ROUTINES.                    **
      **            THIS IMPLEMENTATION OF THE SOCKET API USES       **
      **            THE WINDOWS SOCKETS INTERFACE.                   **
      **                                                             **
      **  DOMAIN :  SY                                               **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
019632**  6.3.1     PRODUCT XPRESS CONNECTOR 1.0                     **
023222**  6.4       PERFORMANCE ENHANCEMENTS                         **
023217**  6.5       PRODUCT XPRESS 2.1                               **
AMQCNV**  15JAN2024 NHANTT CICS REPLACEMENT                          **
      *****************************************************************

      *---------------------
       SOKT-0000-INITIALIZE.
      *---------------------

           INITIALIZE                        L0004-RETRN-CD.
           SET  WSOKT-MSG-ERROR-NO           TO TRUE.
           SET  WSOKT-INITAPI-NOT-DONE       TO TRUE.
           SET  WSOKT-RETRN-OK               TO TRUE.
           SET  WSOKT-TRACE-OFF              TO TRUE.

       SOKT-0000-INITIALIZE-X.
           EXIT.
      /
      *-------------------
       SOKT-1000-INIT-API.
      *-------------------

      *------------------------------------------------------------
      * INITIALIZE SOCKET API NOT REQUIRED FOR WINDOWS
      *------------------------------------------------------------

           SET  WSOKT-RETRN-OK                 TO TRUE.

       SOKT-1000-INIT-API-X.
           EXIT.

      *-----------------------
       SOKT-2000-CREAT-SOCKET.
      *-----------------------

      *-------------------------------------------------------------
      * THE CREATION OF A SOCKET IS IMPLEMENTED WITH THE CONNECT API
      *--------------------------------------------------------------

           SET  WSOKT-RETRN-OK                 TO TRUE.

       SOKT-2000-CREAT-SOCKET-X.
           EXIT.

      *----------------------
       SOKT-3000-CONN-SOCKET.
      *----------------------

      *------------------------------------------------------------
      * TRY TO CONNECT TO ITERATIVE SERVER ON RETURNED IP ADDRESS
      *------------------------------------------------------------

           MOVE WSOKT-PX-SRVR-IP-ADDR-ID     TO L0004-CREATE-IP-ADDR-ID.
           MOVE WSOKT-PX-SRVR-PORT-NUM       TO L0004-CREATE-PORT-NUM.

           PERFORM  0004-2000-CREATE
               THRU 0004-2000-CREATE-X.

           IF  NOT L0004-RETRN-OK
               SET  WSOKT-RETRN-ERR-CONNECT    TO TRUE
               SET  WSOKT-MSG-E-CONN-ERR       TO TRUE
               SET  WSOKT-TRACE-ON             TO TRUE
               MOVE ZERO                       TO WSOKT-ERR-SOCKET-ID
               MOVE L0004-RETRN-CD             TO WSOKT-ERR-RETRN-CD
               MOVE WSOKT-MSG-E-INFO           TO WSOKT-ERR-MSG-TXT
               MOVE WSOKT-ERR-INFO             TO WSOKT-TRACE-MSG-INFO
               PERFORM  SOKT-9000-CSMT-TRACE
                   THRU SOKT-9000-CSMT-TRACE-X
               GO TO SOKT-3000-CONN-SOCKET-X
           ELSE
               SET  WSOKT-RETRN-OK             TO TRUE
               SET  WSOKT-MSG-E-CONN-SUCCESS   TO TRUE
               MOVE WSOKT-MSG-E-INFO           TO WSOKT-TRACE-MSG-TITL
               MOVE WSOKT-PX-SRVR-IP-ADDR-ID   TO WSOKT-IP-ADDR-BIN
               PERFORM  SOKT-8200-IP-BIN-TO-CHAR
                   THRU SOKT-8200-IP-BIN-TO-CHAR-X
               MOVE WSOKT-IP-ADDR-CHAR         TO WSOKT-TRACE-MSG-TXT
               PERFORM  SOKT-9000-CSMT-TRACE
                   THRU SOKT-9000-CSMT-TRACE-X
           END-IF.

           MOVE L0004-CREATE-SOCKET-ID         TO WGLOB-PX-COMUN-ID-R.

       SOKT-3000-CONN-SOCKET-X.
           EXIT.

      *--------------------
023217*SOKT-4000-SEND-RECV.
023217 SOKT-4000-SEND.
      *--------------------

           SET  WSOKT-RETRN-OK           TO TRUE.
           MOVE WGLOB-PX-COMUN-ID-R      TO L0004-SEND-RECV-SOCKET-ID.
023222*    MOVE WSOKT-PX-COMUN-LEN       TO L0004-SEND-RECV-TXT-LEN.
023217*    MOVE WSOKT-PX-SEND-COMUN-LEN  TO L0004-SEND-TXT-LEN.
023217     MOVE LBUFR-BUFFER-LEN         TO L0004-SEND-TXT-LEN.
023217     MOVE WSOKT-TRANSMIT-CD        TO L0004-SEND-RECV-SEND-IND.
023217*    MOVE WSOKT-PX-RECV-COMUN-LEN  TO L0004-RECV-TXT-LEN.
023217*    MOVE WSOKT-SEND-IND           TO L0004-SEND-RECV-SEND-IND.

AMQCNV*    CALL WSOKT-ADDR-SET-PGM     USING DFHEIBLK
AMQCNV*                                      DFHCOMMAREA
023217*                                      WSOKT-PX-COMUN-TXT
AMQCNV*                                      LBUFR-BUFFER-TXT
AMQCNV     CALL WSOKT-ADDR-SET-PGM     USING LBUFR-BUFFER-TXT
                                             L0004-SEND-TXT-ADDR-PTR.

           PERFORM  0004-3000-SEND
               THRU 0004-3000-SEND-X.

           IF  L0004-RETRN-ERR-WRITE
               SET  WSOKT-RETRN-ERR-WRITE      TO TRUE
               SET  WSOKT-MSG-E-WRITE-ERR      TO TRUE
               PERFORM  SOKT-9100-RETRN-ERR
                   THRU SOKT-9100-RETRN-ERR-X
           END-IF.

           IF  L0004-RETRN-ERR-READ
               SET  WSOKT-RETRN-ERR-READ       TO TRUE
               SET  WSOKT-MSG-E-READ-ERR       TO TRUE
               PERFORM  SOKT-9100-RETRN-ERR
                   THRU SOKT-9100-RETRN-ERR-X
           END-IF.

           IF  NOT L0004-RETRN-OK
           AND     WSOKT-RETRN-OK
               SET  WSOKT-RETRN-ERR-WRITE      TO TRUE
               SET  WSOKT-MSG-E-WRITE-ERR      TO TRUE
               PERFORM  SOKT-9100-RETRN-ERR
                   THRU SOKT-9100-RETRN-ERR-X
           END-IF.

           IF  WSOKT-RETRN-OK
               SET  WSOKT-MSG-E-WRITE-SUCCESS  TO TRUE
               MOVE WSOKT-MSG-E-INFO           TO WSOKT-TRACE-MSG-INFO
               PERFORM  SOKT-9000-CSMT-TRACE
                   THRU SOKT-9000-CSMT-TRACE-X
               SET  WSOKT-MSG-E-READ-SUCCESS   TO TRUE
               MOVE WSOKT-MSG-E-INFO           TO WSOKT-TRACE-MSG-INFO
               PERFORM  SOKT-9000-CSMT-TRACE
                   THRU SOKT-9000-CSMT-TRACE-X
           END-IF.

023217 SOKT-4000-SEND-X.
023217*SOKT-4000-SEND-RECV-X.
           EXIT.

023217*--------------------
023217 SOKT-4200-PING.
023217*--------------------
023217
023217     CONTINUE.
023217
023217 SOKT-4200-PING-X.
023217     EXIT.
023217
023217*--------------------
023217 SOKT-4500-RECV.
023217*--------------------
023217
023217******************************************************************
023217*  THREE POINTERS MUST BE PASSED INTO THE XSCU0004 MODULE:
023217*  1.  POINTER TO BUFFER AREA
023217*  2.  POINTER TO LENGTH PARAMETER OUTPUT FIELD
023217*  3.  POINTER TO TERMINATION PATTERN WHICH DEFINES THE END OF
023217*      THE XML DOCUMENT
023217******************************************************************
023217*
023217     SET  WSOKT-RETRN-OK             TO TRUE.
023217     MOVE WGLOB-PX-COMUN-ID-R        TO L0004-RECV-SOCKET-ID.
023217     MOVE LENGTH OF LBUFR-BUFFER-TXT TO L0004-RECV-MAX-BUFFER-LEN.
023217     MOVE ZERO                       TO L0004-RECV-CURRENT-POS.
023217
023217*  SET ADDRESS OF BUFFER AREA
023217     CALL WSOKT-ADDR-SET-PGM     USING DFHEIBLK
023217                                       DFHCOMMAREA
023217                                       LBUFR-BUFFER-TXT
023217                                       L0004-RECV-TXT-ADDR-PTR.
023217
023217*  SET ADDRESS OF LENGTH FIELD
023217     CALL WSOKT-ADDR-SET-PGM    USING DFHEIBLK
023217                                      DFHCOMMAREA
023217                                      L0004-TCP-RECV-BUFFER-LEN
023217                                      L0004-RECV-TXT-LEN-ADDR-PTR.
023217
023217*  SET ADDRESS OF TERMINATION PATTERN FIELD
023217     CALL WSOKT-ADDR-SET-PGM    USING DFHEIBLK
023217                                      DFHCOMMAREA
023217                                      L0003-TERM-PATTERN-TXT
023217                                      L0004-RECV-TERM-PATTERN-PTR.
023217
023217     PERFORM  0004-3500-RECV
023217         THRU 0004-3500-RECV-X.
023217
023217     IF  L0004-RETRN-ERR-READ
023217         SET  WSOKT-RETRN-ERR-READ       TO TRUE
023217         SET  WSOKT-MSG-E-READ-ERR       TO TRUE
023217         PERFORM  SOKT-9100-RETRN-ERR
023217             THRU SOKT-9100-RETRN-ERR-X
023217     END-IF.
023217
023217     IF  NOT L0004-RETRN-OK
023217     AND     WSOKT-RETRN-OK
023217         SET  WSOKT-RETRN-ERR-WRITE      TO TRUE
023217         SET  WSOKT-MSG-E-WRITE-ERR      TO TRUE
023217         PERFORM  SOKT-9100-RETRN-ERR
023217             THRU SOKT-9100-RETRN-ERR-X
023217      END-IF.
023217
023217     IF  L0004-RETRN-COMPLETE
023217         SET WSOKT-RETRN-COMPLETE        TO TRUE
023217     END-IF.
023217
023217     IF  WSOKT-RETRN-OK
023217         MOVE L0004-TCP-RECV-BUFFER-LEN  TO LBUFR-BUFFER-LEN
023217         SET  WSOKT-MSG-E-WRITE-SUCCESS  TO TRUE
023217         MOVE WSOKT-MSG-E-INFO           TO WSOKT-TRACE-MSG-INFO
023217         PERFORM  SOKT-9000-CSMT-TRACE
023217             THRU SOKT-9000-CSMT-TRACE-X
023217         SET  WSOKT-MSG-E-READ-SUCCESS   TO TRUE
023217         MOVE WSOKT-MSG-E-INFO           TO WSOKT-TRACE-MSG-INFO
023217         PERFORM  SOKT-9000-CSMT-TRACE
023217             THRU SOKT-9000-CSMT-TRACE-X
023217     END-IF.
023217
023217 SOKT-4500-RECV-X.
023217     EXIT.
      *-----------------------
       SOKT-5000-CLOSE-SOCKET.
      *-----------------------

      *---------------------------------------------------------------*
      *                                                               *
      *   CLOSE 'ACCEPT DESCRIPTOR'                                   *
      *                                                               *
      *---------------------------------------------------------------*

           MOVE WGLOB-PX-COMUN-ID-R            TO L0004-CLOSE-SOCKET-ID.

           PERFORM  0004-4000-CLOSE
               THRU 0004-4000-CLOSE-X.

           IF  NOT L0004-RETRN-OK
               SET  WSOKT-RETRN-ERR-CLOSE      TO TRUE
               SET  WSOKT-MSG-E-CLOS-ERR       TO TRUE
               PERFORM  SOKT-9100-RETRN-ERR
                   THRU SOKT-9100-RETRN-ERR-X
           ELSE
               SET  WSOKT-RETRN-OK             TO TRUE
               SET  WSOKT-MSG-E-CLOS-SUCCESS   TO TRUE
               MOVE WSOKT-MSG-E-INFO           TO WSOKT-TRACE-MSG-INFO
               PERFORM  SOKT-9000-CSMT-TRACE
                   THRU SOKT-9000-CSMT-TRACE-X
           END-IF.

       SOKT-5000-CLOSE-SOCKET-X.
           EXIT.

      *------------------------
       SOKT-6000-PRCES-HOST-NM.
      *------------------------

      *------------------------------------------------------------
      * GET HOST IP ADDRESS BASED ON HOST NAME
      *------------------------------------------------------------

           MOVE WSOKT-HOST-NAME-LEN      TO L0004-LOOKUP-NM-LEN.


           CALL WSOKT-ADDR-SET-PGM  USING DFHEIBLK
                                          DFHCOMMAREA
                                          WSOKT-HOST-NAME
                                          L0004-LOOKUP-NM-ADDR-PTR.

           PERFORM  0004-1000-LOOKUP
               THRU 0004-1000-LOOKUP-X.

           IF  NOT L0004-RETRN-OK
               SET  WSOKT-RETRN-ERR-GETHOST    TO TRUE
               SET  WSOKT-MSG-E-HOSTBYNAME-ERR TO TRUE
               PERFORM  SOKT-9100-RETRN-ERR
                   THRU SOKT-9100-RETRN-ERR-X
           ELSE
               SET  WSOKT-RETRN-OK             TO TRUE
           END-IF.

       SOKT-6000-PRCES-HOST-NM-X.
           EXIT.

      *------------------------
       SOKT-6100-PRCES-HOST-IP.
      *------------------------

           MOVE L0004-LOOKUP-IP-ADDR-ID
             TO WSOKT-PX-SRVR-IP-ADDR-ID.

       SOKT-6100-PRCES-HOST-IP-X.
           EXIT.

      *------------------------
       SOKT-6200-SET-CONN-NEXT.
      *------------------------

           SET  WSOKT-RETRN-ERR-CONNECT        TO TRUE.

       SOKT-6200-SET-CONN-NEXT-X.
           EXIT.

      *-------------------
       SOKT-7000-TERM-API.
      *-------------------

      *------------------------------------------------------------
      * TERMINATE SOCKET API NOT REQUIRED BY WINDOWS SOCKETS
      *------------------------------------------------------------

           SET  WSOKT-RETRN-OK           TO TRUE.

       SOKT-7000-TERM-API-X.
           EXIT.

      *-------------------------
       SOKT-8200-IP-BIN-TO-CHAR.
      *-------------------------

           MOVE LOW-VALUES                     TO WSOKT-IP-ADDR-LOW.

           MOVE WSOKT-IP-ADDR-BIN-1            TO WSOKT-IP-ADDR-HIGH.
           MOVE WSOKT-IP-ADDR                  TO WSOKT-IP-ADDR-CHAR-1.

           MOVE WSOKT-IP-ADDR-BIN-2            TO WSOKT-IP-ADDR-HIGH.
           MOVE WSOKT-IP-ADDR                  TO WSOKT-IP-ADDR-CHAR-2.

           MOVE WSOKT-IP-ADDR-BIN-3            TO WSOKT-IP-ADDR-HIGH.
           MOVE WSOKT-IP-ADDR                  TO WSOKT-IP-ADDR-CHAR-3.

           MOVE WSOKT-IP-ADDR-BIN-4            TO WSOKT-IP-ADDR-HIGH.
           MOVE WSOKT-IP-ADDR                  TO WSOKT-IP-ADDR-CHAR-4.

       SOKT-8200-IP-BIN-TO-CHAR-X.
           EXIT.

      *---------------------
       SOKT-9000-CSMT-TRACE.
      *---------------------

           IF  WSOKT-TRACE-ON
               MOVE WGLOB-TASK-ID-N            TO WSOKT-TRACE-TASK-NUM
               MOVE WSOKT-TRACE-INFO           TO WCSMT-MSG-TXT
               MOVE LENGTH OF WSOKT-TRACE-INFO TO WCSMT-MSG-LEN
               PERFORM  CSMT-1000-WRITE-MSG
                   THRU CSMT-1000-WRITE-MSG-X
           END-IF.

           MOVE SPACES                         TO WSOKT-TRACE-MSG-INFO.

       SOKT-9000-CSMT-TRACE-X.
           EXIT.

      *--------------------
       SOKT-9100-RETRN-ERR.
      *--------------------

           SET  WSOKT-TRACE-ON                 TO TRUE.
           MOVE WGLOB-PX-COMUN-ID              TO WSOKT-ERR-SOCKET-ID.
           MOVE L0004-RETRN-CD                 TO WSOKT-ERR-RETRN-CD.
           MOVE WSOKT-MSG-E-INFO               TO WSOKT-ERR-MSG-TXT.
           MOVE WSOKT-ERR-INFO                 TO WSOKT-TRACE-MSG-INFO.
           PERFORM  SOKT-9000-CSMT-TRACE
               THRU SOKT-9000-CSMT-TRACE-X.

       SOKT-9100-RETRN-ERR-X.
           EXIT.

      *****************************************************************
      **                 END OF COPYBOOK XCPPSOKT                    **
      *****************************************************************
