      *****************************************************************
      **  MEMBER :  XCCP0030                                         **
      **  REMARKS:  COPYBOOK USED TO CALL ERROR ROLLBACK & LOG       **
      **            (BATCH)                                          **
      *****************************************************************
      **  RELEASE   DESCRIPTION                                      **
      **                                                             **
014590**  6.0       ELIMINATION OF L0030 AREA FROM LINKAGE           **
018764**  6.3       LINKAGE AREA MODIFICATIONS                       **
019632**  6.3.1     PRODUCT XPRESS CONNECTOR 1.0                     **
026070**  6.6       ERROR HANDLER                                    **
      *****************************************************************

      *----------------------------
       0030-0000-CALL-ROLLBACK-LOG.
      *----------------------------

           MOVE WGLOB-PREV-PGM-ID       TO WPGWS-PREV-PGM-ID.
           MOVE WPGWS-CRNT-PGM-ID       TO WGLOB-PREV-PGM-ID.

018764*    MOVE 'XSRU0030'              TO WPGWS-CALL-PGM-ID.
018764     MOVE 'XSDU0030'              TO WPGWS-CALL-PGM-ID.
           MOVE WPGWS-CALL-PGM-ID       TO WGLOB-CRNT-PGM-ID.

018764*    CALL WPGWS-CALL-PGM-ID   USING WGLOB-GLOBAL-AREA.
ZOS   *    CALL WPGWS-CALL-PGM-ID USING DFHEIBLK
ZOS   *                                 DFHCOMMAREA
ZOS   *                                 WGLOB-GLOBAL-AREA
NONZOS     CALL WPGWS-CALL-PGM-ID       USING WGLOB-GLOBAL-AREA.

           MOVE WPGWS-CRNT-PGM-ID       TO WGLOB-CRNT-PGM-ID.
           MOVE WPGWS-PREV-PGM-ID       TO WGLOB-PREV-PGM-ID.

       0030-0000-CALL-ROLLBACK-LOG-X.
           EXIT.

      *--------------------
       0030-1000-SQL-ERROR.
      *--------------------

           SET  WGLOB-SQL-ERROR       TO TRUE.
           MOVE ZERO                  TO WGLOB-SEQ-FILE-STATUS.
           IF  WGLOB-OPTM-SQL-ERROR
           OR  WGLOB-OPTM-SQL-IMPRV
               MOVE ZERO              TO WGLOB-SQLCODE
               MOVE SPACES            TO WGLOB-ERROR-DESC-TXT
           ELSE
               MOVE SQLCODE           TO WGLOB-SQLCODE
               MOVE SQLERRMC          TO WGLOB-ERROR-DESC-TXT
           END-IF.
049241     IF  WGLOB-OPTM-SQL-IMPRV
059629     AND WGLOB-SQLCODE >= ZERO 
049241         PERFORM 0030-0000-CALL-ROLLBACK-LOG
049241            THRU 0030-0000-CALL-ROLLBACK-LOG-X
049241     ELSE
049241         IF  WGLOB-ENVRMNT-ONLINE
049241             MOVE 'SQLC'       TO WGLOB-ABEND-CD
049241             SET WGLOB-RETURN-ABEND TO TRUE
049241             GOBACK
049241         ELSE
049241             PERFORM 0030-0000-CALL-ROLLBACK-LOG
049241                THRU 0030-0000-CALL-ROLLBACK-LOG-X
049241         END-IF
049241     END-IF.

       0030-1000-SQL-ERROR-X.
           EXIT.


      *---------------------
       0030-3000-QSAM-ERROR.
      *---------------------

           SET  WGLOB-QSAM-ERROR      TO TRUE.
           MOVE ZERO                  TO WGLOB-SQLCODE.
           MOVE SPACES                TO WGLOB-ERROR-DESC-TXT.
           MOVE SPACES                TO WGLOB-OPTM-SQL-STAT-CD.
           MOVE SPACES                TO WGLOB-OPTM-SQL-REQIR.
           MOVE SPACES                TO WGLOB-OPTM-SQL-EXEC.
026070     MOVE 1                     TO WGLOB-ERROR-IO-KEY-INFO-LEN.
026070     MOVE SPACES                TO WGLOB-ERROR-IO-KEY-INFO-TXT.

           PERFORM 0030-0000-CALL-ROLLBACK-LOG
              THRU 0030-0000-CALL-ROLLBACK-LOG-X.

       0030-3000-QSAM-ERROR-X.
           EXIT.

      *-------------------------
       0030-4000-CTL-CARD-ERROR.
      *-------------------------

           SET  WGLOB-CTL-CARD-ERROR  TO TRUE.
           MOVE SPACES                TO WGLOB-TABLE-NAME.
           MOVE SPACES                TO WGLOB-IO-COMMAND.
           MOVE ZERO                  TO WGLOB-SEQ-FILE-STATUS.
           MOVE ZERO                  TO WGLOB-SQLCODE.
           MOVE SPACES                TO WGLOB-ERROR-DESC-TXT.
           MOVE SPACES                TO WGLOB-OPTM-SQL-STAT-CD.
           MOVE SPACES                TO WGLOB-OPTM-SQL-REQIR.
           MOVE SPACES                TO WGLOB-OPTM-SQL-EXEC.
026070     MOVE 1                     TO WGLOB-ERROR-IO-KEY-INFO-LEN.
026070     MOVE SPACES                TO WGLOB-ERROR-IO-KEY-INFO-TXT.

           PERFORM 0030-0000-CALL-ROLLBACK-LOG
              THRU 0030-0000-CALL-ROLLBACK-LOG-X.

       0030-4000-CTL-CARD-ERROR-X.
           EXIT.

      *----------------------
       0030-5000-LOGIC-ERROR.
      *----------------------

           SET  WGLOB-LOGIC-ERROR     TO TRUE.
026070*    MOVE 'L'                   TO WGLOB-ERROR-CD.
           MOVE SPACES                TO WGLOB-TABLE-NAME.
           MOVE SPACES                TO WGLOB-IO-COMMAND.
           MOVE ZERO                  TO WGLOB-SEQ-FILE-STATUS.
           MOVE ZERO                  TO WGLOB-SQLCODE.
035753*    MOVE SPACES                TO WGLOB-ERROR-DESC-TXT.
035753     MOVE WGLOB-MSG-TXT         TO WGLOB-ERROR-DESC-TXT.
           MOVE SPACES                TO WGLOB-OPTM-SQL-STAT-CD.
           MOVE SPACES                TO WGLOB-OPTM-SQL-REQIR.
           MOVE SPACES                TO WGLOB-OPTM-SQL-EXEC.
026070     MOVE 1                     TO WGLOB-ERROR-IO-KEY-INFO-LEN.
026070     MOVE SPACES                TO WGLOB-ERROR-IO-KEY-INFO-TXT.

049241     IF  WGLOB-ENVRMNT-ONLINE
049241         MOVE 'LGIC'            TO WGLOB-ABEND-CD
049241         SET WGLOB-RETURN-ABEND TO TRUE
049241         GOBACK
049241     ELSE
049241         PERFORM 0030-0000-CALL-ROLLBACK-LOG
049241            THRU 0030-0000-CALL-ROLLBACK-LOG-X
049241     END-IF.

       0030-5000-LOGIC-ERROR-X.
           EXIT.

      *----------------------
       0030-6000-COMUN-ERROR.
      *----------------------

026070     SET  WGLOB-COMUN-ERROR     TO TRUE.
026070*    SET  WGLOB-LOGIC-ERROR     TO TRUE.
026070*    MOVE 'C'                   TO WGLOB-ERROR-CD.
           MOVE SPACES                TO WGLOB-TABLE-NAME.
           MOVE SPACES                TO WGLOB-IO-COMMAND.
           MOVE ZERO                  TO WGLOB-SEQ-FILE-STATUS.
           MOVE ZERO                  TO WGLOB-SQLCODE.
026070*    MOVE SPACES                TO WGLOB-ERROR-DESC-TXT.
           MOVE SPACES                TO WGLOB-OPTM-SQL-STAT-CD.
           MOVE SPACES                TO WGLOB-OPTM-SQL-REQIR.
           MOVE SPACES                TO WGLOB-OPTM-SQL-EXEC.
026070     MOVE 1                     TO WGLOB-ERROR-IO-KEY-INFO-LEN.
026070     MOVE SPACES                TO WGLOB-ERROR-IO-KEY-INFO-TXT.

049241     IF  WGLOB-ENVRMNT-ONLINE
049241         MOVE 'COMU'            TO WGLOB-ABEND-CD
049241         SET WGLOB-RETURN-ABEND TO TRUE
049241         GOBACK
049241     ELSE
049241         PERFORM 0030-0000-CALL-ROLLBACK-LOG
049241            THRU 0030-0000-CALL-ROLLBACK-LOG-X
049241     END-IF.

       0030-6000-COMUN-ERROR-X.
           EXIT.

      *****************************************************************
      **                 END OF COPYBOOK XCCP0030                    **
      *****************************************************************
