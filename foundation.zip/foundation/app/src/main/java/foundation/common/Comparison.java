package foundation.common;

@FunctionalInterface
public interface Comparison<V> {
    int apply(V v);
}
