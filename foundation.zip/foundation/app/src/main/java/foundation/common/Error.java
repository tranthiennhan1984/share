package foundation.common;

public class Error extends Exception {
    public Error(String errorMessage) {
        super(errorMessage);
    }
}
