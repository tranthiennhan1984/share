package foundation.common;

@FunctionalInterface
public interface ItemGetter<E, V> {
    V get(E e, int index);
}
