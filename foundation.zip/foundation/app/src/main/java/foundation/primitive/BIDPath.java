package foundation.primitive;

import java.util.List;
import foundation.Util;
import java.util.ArrayList;

public final class BIDPath {
    public static final char MEMBER_SEPARATOR = '.';
    private final List<BID> items = new ArrayList<>();

    public BIDPath(BID item) {
        add(item);
    }

    public BID get(int index) {
        return items.get(index);
    }

    public int size() {
        return items.size();
    }

    public BIDPath add(BID item) {
        if (!Util.isNullOrNothing(item)) {
            items.add(item);
        }
        return this;
    }

    public BIDPath remove(int index) {
        items.remove(index);
        return this;
    }

    public BIDPath append(BIDPath path) {
        if (Util.isNullOrEmpty(path)) {
            return this;
        }
        var length = path.size();
        for (int i = 0; i < length; i++) {
            var item = path.get(i);
            if (!Util.isNullOrNothing(item)) {
                items.add(path.get(i));
            }
        }
        return this;
    }
}
