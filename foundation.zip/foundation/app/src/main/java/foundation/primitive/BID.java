package foundation.primitive;

import foundation.Util;

public final class BID implements Comparable<BID> {
    private static final long ANNOTATION_MASK = 0x8000000000000000L;
    public static final String EMPTY = "";
    public static final BID NOTHING = new BID();

    private final long[] content;

    private BID() {
        this(0L);
    }

    public BID(long[] content) {
        this.content = content;
    }

    public BID(long code) {
        this(new long[] {code});
    }

    public final int getLength() {
        return content.length;
    }

    public final String toName() {
        return toName(content);
    }

    public final String toCode() {
        return toCode0(content);
    }

    public final boolean isNothing() {
        return content[0] == 0;
    }

    @Override
    public final int hashCode() {
        return (int) (this.content[0] ^ this.content.length);
    }

    @Override
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof BID)) {
            return false;
        }
        return compareTo0(content, ((BID) obj).content) == 0;
    }

    @Override
    public final int compareTo(BID o) {
        if (o == this) {
            return 0;
        }
        if (o == null) {
            return 1;
        }
        return compareTo0(content, o.content);
    }

    private static final int compareTo0(long[] content, long[] others) {
        var cLen = Integer.compare(content.length, others.length);
        var len = cLen < 0 ? content.length : others.length;

        for (int i = 0; i < len; i++) {
            var r = Long.compare(content[i], others[i]);
            if (r != 0)
                return r;
        }

        return cLen;
    }

    public static final boolean isAnnotation(BID bid) {
        return bid.content[0] < 0;
    }

    public static final BID fromName(String txt) {
        if (Util.isNullOrEmpty(txt)) {
            return NOTHING;
        }
        return fromName(txt, false);
    }

    public static final BID fromHiddenName(String txt) {
        if (Util.isNullOrEmpty(txt)) {
            return NOTHING;
        }
        return fromName(txt, true);
    }

    private static final BID fromName(String txt, boolean annotation) {
        var txtEnd = txt.length();

        var end = txtEnd / 9;
        if (end * 9 < txtEnd) {
            end++;
        }
        var content = new long[end];
        long code;
        int txtInd = 0;
        int index = 0;
        while ((end = txtEnd - txtInd) > 0) {
            long unit = 0;
            end = end > 8 ? 0 : (9 - end) * 7;
            for (int bitOff = 56; bitOff >= end; bitOff -= 7) {
                if ((code = (long) txt.charAt(txtInd++) & 127) == 0) {
                    txtInd = txtEnd;
                    break;
                }
                unit |= code << bitOff;
            }
            content[index++] = unit;
        }

        assert content[0] > 0;

        if (annotation) {
            content[0] |= ANNOTATION_MASK;
        }

        return new BID(content);
    }

    private static String toName(long[] content) {
        if (content[0] == 0) {
            return BID.EMPTY;
        }

        var unitLen = content.length;
        var buffer = new char[unitLen * 9];
        var count = 0;
        char chr;
        var index = 0;
        for (; index < unitLen; index++) {
            var unit = content[index];
            if (unit == 0) {
                break;
            }
            for (int bitOff = 56; bitOff >= 0; bitOff -= 7) {
                chr = (char) ((unit >> bitOff) & 127);
                if (chr == 0) {
                    index = unitLen;
                    break;
                }
                buffer[count++] = chr;
            }

        }
        return new String(buffer, 0, count);
    }

    private static final char[] _codeIdEncodingMap =
            buildEncodingMap("_0123456789AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz-");
    private static final byte[] _codeIdDecodingMap = buildDecodingMap(_codeIdEncodingMap);

    private static final char[] buildEncodingMap(String encodingText) {
        var length = encodingText.length();
        var retVal = new char[length];
        for (var i = 0; i < length; i++) {
            retVal[i] = encodingText.charAt(i);
        }
        return retVal;
    }

    private static final byte[] buildDecodingMap(char[] encodingMap) {
        var retVal = new byte[127];
        var length = retVal.length;
        for (int i = 0; i < length; i++) {
            retVal[i] = -1;
        }
        length = encodingMap.length;
        int code;
        for (byte i = 0; i < length; i++) {
            code = encodingMap[i];
            retVal[code] = i;
        }
        return retVal;
    }

    public static final BID fromCode(String txt) {
        if (Util.isNullOrEmpty(txt)) {
            return NOTHING;
        }
        return fromCode0(txt);
    }

    private static final BID fromCode0(String txt) throws IllegalArgumentException {
        var txtEnd = txt.length();
        var count = txtEnd / 11;
        if (count * 11 < txtEnd) {
            count++;
            txt = "__________".substring(0, count * 11 - txtEnd) + txt;
        }
        var content = new long[count];

        var index = 0;
        var offset = 0;
        while (index < count) {
            long unit = 0;
            var code = _codeIdDecodingMap[txt.charAt(offset++)];
            if (code < 0) {
                throw new IllegalArgumentException(
                        "Invalid character: '" + txt.charAt((offset)) + "'");
            }
            assert (code >= 0);
            unit |= (long) code << 60;

            for (int bitOff = 54; bitOff >= 0; bitOff -= 6) {
                code = _codeIdDecodingMap[(byte) txt.charAt(offset++)];
                if (code < 0) {
                    throw new IllegalArgumentException(
                            "Invalid character: '" + txt.charAt((offset)) + "'");
                }
                unit |= (long) code << bitOff;
            }

            content[index++] = unit;
        }
        return new BID(content);
    }

    private static final String toCode0(long[] content) {
        if (content[0] == 0) {
            return BID.EMPTY;
        }
        var length = content.length;
        var buffer = new char[length * 11];
        var offset = 0;
        for (int index = 0; index < length; index++) {
            long unit = content[index];
            buffer[offset++] = _codeIdEncodingMap[(int) (unit >> 60)];
            for (int bitOff = 54; bitOff >= 0; bitOff -= 6) {
                buffer[offset++] = _codeIdEncodingMap[(int) ((unit >> bitOff) & 63)];
            }
        }
        return new String(buffer);
    }

}
