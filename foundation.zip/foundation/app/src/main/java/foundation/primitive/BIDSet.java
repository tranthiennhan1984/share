package foundation.primitive;

import java.util.List;
import foundation.Util;
import foundation.common.Comparison;
import java.util.ArrayList;

public final class BIDSet implements BIDCollection {
    private final BIDFinder finder;

    private final List<BID> items = new ArrayList<>();
    private final boolean sorted;
    private boolean readonly;

    public BIDSet(boolean sorted) {
        this.sorted = sorted;
        finder = this.sorted ? this::binarySearch : this::itemSearch;
    }

    @Override
    public boolean sorted() {
        return sorted;
    }

    @Override
    public boolean isUnique() {
        return true;
    }

    @Override
    public boolean readonly() {
        return readonly;
    }

    @Override
    public void setReadonly(boolean readonly) {
        this.readonly = readonly;
    }

    @Override
    public int size() {
        return items.size();
    }

    @Override
    public BID get(int index) {
        return items.get(index);
    }


    @Override
    public int find(BID item) {
        return Util.isNullOrNothing(item) ? -1 : finder.find(item);
    }

    @Override
    public int add(BID item) {
        if (this.readonly || Util.isNullOrNothing(item)) {
            return -1;
        }

        var index = finder.find(item);
        if (index > -1) {
            return index;
        }

        index = ~index;
        items.add(index, item);
        return index;
    }

    @Override
    public int add(int index, BID item) {
        return add(item);
    }

    @Override
    public BID remove(int index) {
        return readonly ? BID.NOTHING : items.remove(index);
    }

    @Override
    public void clear() {
        if (!readonly) {
            items.clear();
        }
    }

    private int binarySearch(BID item) {
        return Util.binarySearch(items, items.size(), List::get,
                (Comparison<BID>) (v -> v.compareTo(item)));
    }

    private int itemSearch(BID item) {
        return Util.itemSearch(items, items.size(), List::get,
                (Comparison<BID>) (v -> v.compareTo(item)));
    }

    private interface BIDFinder {
        int find(BID item);
    }
}
