package foundation.primitive;

public interface BIDCollection extends BIDReadonlyCollection {
    boolean readonly();

    void setReadonly(boolean readonly);

    int add(BID item);

    int add(int index, BID item);

    BID remove(int index);

    void clear();
}
