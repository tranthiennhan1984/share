package foundation.primitive;

public interface BIDReadonlyCollection {
    boolean sorted();

    boolean isUnique();

    int size();

    BID get(int index);

    int find(BID item);

}
