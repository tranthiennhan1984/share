package foundation.primitive;

import java.util.List;
import foundation.Util;
import foundation.common.Comparison;
import java.util.ArrayList;

public final class BIDList implements BIDCollection {
    private final List<BID> items = new ArrayList<>();
    private final boolean unique;
    private boolean readonly;

    public BIDList(boolean isUnique) {
        this.unique = isUnique;
    }

    @Override
    public boolean sorted() {
        return false;
    }

    @Override
    public boolean isUnique() {
        return this.unique;
    }

    @Override
    public int size() {
        return items.size();
    }

    @Override
    public BID get(int index) {
        return items.get(index);
    }

    @Override
    public boolean readonly() {
        return readonly;
    }

    @Override
    public void setReadonly(boolean readonly) {
        this.readonly = readonly;
    }


    @Override
    public int find(BID item) {
        return Util.isNullOrNothing(item) ? -1 : inFind(item);
    }

    @Override
    public int add(BID item) {
        return (add(items.size(), item));
    }

    @Override
    public int add(int index, BID item) {
        if (readonly || Util.isNullOrNothing(item)) {
            return -1;
        }

        if (unique) {
            var curIndex = inFind(item);
            if (curIndex > -1) {
                return curIndex;
            }
        }

        items.add(index, item);
        return index;
    }

    @Override
    public BID remove(int index) {
        return readonly ? BID.NOTHING : items.remove(index);
    }

    @Override
    public void clear() {
        if (!readonly) {
            items.clear();
        }
    }

    private final int inFind(BID item) {
        return Util.itemSearch(items, items.size(), List::get,
                (Comparison<BID>) (v -> v.compareTo(item)));
    }
}
