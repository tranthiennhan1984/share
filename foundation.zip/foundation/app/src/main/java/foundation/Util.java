package foundation;

import foundation.common.Comparison;
import foundation.common.ItemGetter;
import foundation.primitive.BID;
import foundation.primitive.BIDPath;
import foundation.primitive.BIDReadonlyCollection;

public final class Util {

    private Util() {}

    public static final boolean isNullOrEmpty(String txt) {
        return txt == null || txt.length() == 0;
    }

    public static final boolean isNullOrNothing(BID bid) {
        return bid == null || bid.isNothing();
    }

    public static final boolean isNullOrEmpty(BIDReadonlyCollection collection) {
        return collection == null || collection.size() == 0;
    }

    public static final boolean isNullOrEmpty(BIDPath path) {
        return path == null || path.size() == 0;
    }

    public static <E, V> int binarySearch(E set, int length, ItemGetter<E, V> getter,
            Comparison<V> comparison) {

        if (length == 0) {
            return ~0;
        }

        var low = 0;
        var hi = length - 1;
        var comp = hi < 0 ? 1 : comparison.apply(getter.get(set, hi));
        if (comp == 0) {
            return hi;
        } else if (comp < 0) {
            return ~(hi + 1);
        }
        hi--;

        comp = comparison.apply(getter.get(set, low));
        if (comp == 0) {
            return low;
        } else if (comp > 0) {
            return ~low;
        }
        low++;

        while (low <= hi) {
            var mid = low + ((hi - low) >> 1);
            comp = comparison.apply(getter.get(set, mid));
            if (comp == 0) {
                return mid;
            }

            if (comp > 0) {
                hi = mid - 1;
            } else {
                low = mid + 1;
            }
        }
        return ~low;
    }

    public static <E, V> int itemSearch(E set, int length, ItemGetter<E, V> getter,
            Comparison<V> comparison) {

        if (length == 0) {
            return ~0;
        }

        for (int i = 0; i < length; i++) {
            if (comparison.apply(getter.get(set, i)) == 0) {
                return i;
            }
        }

        return ~length;
    }
}
