﻿using Binean.Private;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;

namespace Binean.Foundation {
    public static partial class Extension {

        #region :: Converter Helpers ::
        //public const string DateTimeFormat = "yyyy-MM-dd HH.mm.ss";
        //public const string DateFormat = "yyyy-MM-dd";
        //private static readonly Dictionary<Type, string> _builtInTypeNames
        //    = new() {
        //        { typeof(bool), "bool" },
        //        { typeof(byte), "byte" },
        //        { typeof(char), "char" },
        //        { typeof(decimal), "decimal" },
        //        { typeof(double), "double" },
        //        { typeof(float), "float" },
        //        { typeof(int), "int" },
        //        { typeof(long), "long" },
        //        { typeof(object), "object" },
        //        { typeof(sbyte), "sbyte" },
        //        { typeof(short), "short" },
        //        { typeof(string), "string" },
        //        { typeof(uint), "uint" },
        //        { typeof(ulong), "ulong" },
        //        { typeof(ushort), "ushort" }
        //    };

        //public static string? GetTypeDisplayName(this Type type) {
        //    string? fullName;
        //    if (type.IsGenericType) {
        //        if ((fullName = type.GetGenericTypeDefinition().FullName) is null) return null;

        //        var parts = fullName.Split('+');

        //        for (var i = 0; i < parts.Length; i++) {
        //            var partName = parts[i];

        //            var backTickIndex = partName.IndexOf('`');
        //            if (backTickIndex >= 0) {
        //                partName = partName[..backTickIndex];
        //            }

        //            parts[i] = partName;
        //        }

        //        return string.Join(".", parts);
        //    }

        //    if (_builtInTypeNames.TryGetValue(type, out string? value)) return value;

        //    if ((fullName = type.FullName) is null) return null;

        //    if (!type.IsNested) return fullName;
        //    return fullName.Replace('+', '.');
        //}


        //private static bool ConvertToDateTime(this string text, out object? target) {
        //    if (string.IsNullOrWhiteSpace(text)) { target = null; return false; }

        //    if (DateTime.TryParseExact(text, text.Length == 10 ? DateFormat : DateTimeFormat,
        //        CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime dt)) {
        //        target = dt; return true;
        //    }

        //    target = null;
        //    return false;
        //}

        //public static bool IsNullable(this Type type) {
        //    if (type.IsInterface) return true;
        //    var underlyingType = Nullable.GetUnderlyingType(type);
        //    return underlyingType != null || type == typeof(object);
        //}

        //public static bool TryConvert1(this object? value, Type targetType, out object? target) {
        //    if (targetType is null) { target = null; return false; }
        //    var underlyingType = Nullable.GetUnderlyingType(targetType);

        //    var canBeNull = targetType.IsInterface || targetType == typeof(string) || underlyingType != null || targetType == typeof(object);

        //    if (value is DBNull) { target = null; return canBeNull; }

        //    if (targetType == typeof(object)) { target = value; return true; }

        //    if (value is null) { target = null; return canBeNull; }

        //    if (targetType == typeof(Type)) { target = value.ToType(); return target != null; }

        //    var valueType = value.GetType();
        //    if (valueType == targetType || targetType.IsAssignableFrom(valueType)) {
        //        target = value; return true;
        //    }

        //    if (targetType.IsEnum) return Helper.ConvertToEnum(value, targetType, out target);
        //    if (underlyingType != null && underlyingType.IsEnum) {
        //        return Helper.ConvertToEnum(value, underlyingType, out target);
        //    }

        //    if (value is IConvertible && targetType.IsPrimitive) {
        //        try {
        //            target = System.Convert.ChangeType(value, targetType, CultureInfo.CurrentCulture);
        //            return true;
        //        } catch {
        //            target = null; return false;
        //        }
        //    }

        //    if (targetType == typeof(string)) {
        //        target = value is Type t ? t.GetTypeName()
        //            : value is BID bid ? (string)bid
        //            : value is DateTime dt ? dt.ToTimeString()
        //            : value is byte[] blob ? System.Convert.ToBase64String(blob)
        //            : value.ToString();
        //        return true;
        //    }

        //    if (targetType == typeof(BID)) {
        //        if (value is string txt) {
        //            target = (BID)txt;
        //            return true;
        //        }

        //        target = BID.Nothing;
        //        return false;
        //    }

        //    target = null;

        //    if (targetType == typeof(byte[])) {
        //        if (value is string txt) {
        //            if (txt.StartsWith('[')) {
        //                target = txt[1..^1].HexToBlob();
        //                return true;
        //            }
        //            if (txt.StartsWith('{') && TryParseBase64(txt[1..^1], out byte[]? blob)) {
        //                target = blob;
        //                return true;
        //            }
        //            if (TryParseBase64(txt[1..^1], out byte[]? bl)) {
        //                target = bl;
        //                return true;
        //            }
        //        }
        //        return false;
        //    }
        //    if (targetType == typeof(Guid) || underlyingType == typeof(Guid)) {
        //        if (value is string txt && Guid.TryParse(txt, out Guid retVal)) {
        //            target = retVal; return true;
        //        }
        //        if (value is byte[] blob) {
        //            target = new Guid(blob);
        //            return true;
        //        }
        //        return false;
        //    }
        //    if (targetType == typeof(Uri)) {
        //        if (value is string txt) {
        //            target = new Uri(txt, UriKind.RelativeOrAbsolute);
        //            return true;
        //        }
        //    }
        //    if (targetType == typeof(DateTime) || underlyingType == typeof(DateTime)) {
        //        return value is string txt && ConvertToDateTime(txt, out target);
        //    }
        //    if (TypeDescriptor.GetConverter(targetType) is TypeConverter tconv && tconv.CanConvertFrom(valueType)) {
        //        target = tconv.ConvertFrom(value);
        //        return true;
        //    }
        //    if (TypeDescriptor.GetConverter(valueType) is TypeConverter vconv && vconv.CanConvertTo(targetType)) {
        //        target = vconv.ConvertTo(value, targetType);
        //        return true;
        //    }

        //    //          var conversionOperator = typeof(T1).GetMethods(BindingFlags.Static | BindingFlags.Public)
        //    //.Where(m => m.Name == "op_Explicit" || m.Name == "op_Implicit")
        //    //.Where(m => m.ReturnType == typeof(T2))
        //    //.Where(m => m.GetParameters().Length == 1 && m.GetParameters()[0].ParameterType == typeof(T1))
        //    //.FirstOrDefault();

        //    //          if (conversionOperator != null)
        //    //              return (T2)conversionOperator.Invoke(null, new object[] { obj });

        //    //          throw new Exception("No conversion operator found");
        //    return false;
        //}


        //public static object? ConvertAsDbValue(this object? value, Type targetType, Func<object?>? failback = null) {
        //    if (value is null) return Nullable.GetUnderlyingType(targetType) is null ? null : DBNull.Value;
        //    var retVal = Convert(value, targetType, failback);
        //    if (retVal != null) return retVal;
        //    return Nullable.GetUnderlyingType(targetType) is null ? null : DBNull.Value;
        //}
        #endregion

        #region :: Object Helpers ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        [return: NotNull]
        public static T NotNull<T>(this object? value) {
            var retVal = (T?)value;
            Debug.Assert(retVal != null);
            return retVal;
        }

        [DebuggerStepThrough]
        [Conditional("DEBUG")]
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void AssertNotNull<T>([NotNull] this T? value) {
            Debug.Assert(value != null);
        }

        //public static bool IsEquals(this object? srce, object? dest) {
        //    if (srce is null && dest is null) return true;
        //    if (srce is null || dest is null) return false;

        //    if (dest.TryConvert(srce.GetType(), out object? dest2)) {
        //        if (srce is IComparable srcComparable) return srcComparable.CompareTo(dest2) == 0;
        //        if (srce is IEqualityComparer seq) return seq.Equals(dest2);
        //    }

        //    if (srce.TryConvert(dest.GetType(), out object? srce2)) {
        //        if (dest is IComparable destComparable) return destComparable.CompareTo(srce2) == 0;
        //        if (dest is IEqualityComparer deq) return deq.Equals(srce2);
        //    }

        //    return srce.Equals(dest);
        //}

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsNullOrEmpty([NotNullWhen(false)] this Guid? guid)
            => guid is null || guid == Guid.Empty;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsEmpty(this Guid guid)
            => guid == Guid.Empty;

        public static bool IsWorkDay(this DateTime date) {
            var dow = date.DayOfWeek;
            return dow >= DayOfWeek.Monday && dow <= DayOfWeek.Friday;
        }
        public static DateTime GetNextWorkDay(this DateTime date) {
            while (!date.IsWorkDay()) date = date.AddDays(1);
            return date;
        }
        public static DateTime GetPreviousWorkDay(this DateTime date) {
            while (!date.IsWorkDay()) date = date.AddDays(-1);
            return date;
        }
        public static int DayDiff(this DateTime to, DateTime from, bool workingDayOnly = false) {
            int invert = from > to ? -1 : 1;
            if (invert < 0) {
                (to, from) = (from, to);
            }
            if (!workingDayOnly) return invert * (int)((to - from).TotalDays + 1);
            from = GetNextWorkDay(from);
            to = GetPreviousWorkDay(to);
            var days = (to - from).TotalDays;
            if (days < 0) return 0;
            var weeks = (int)(days / 7);

            var retVal = to.DayOfWeek - from.DayOfWeek;
            if (retVal < 0) retVal += 5;
            return invert * (retVal + 5 * weeks) + 1;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string Repeat(this string text, int count) {
            if (string.IsNullOrEmpty(text)) return string.Empty;
            var sb = new StringBuilder();
            for (var i = 0; i < count; i++) {
                sb.Append(text);
            }
            return sb.ToString();
        }
        #endregion

        //public static string RemoveVnToneMarks(this string text) {
        //    const string letters = "aeouiyd";
        //    const int count = 7;
        //    string[] arrays = new string[] {
        //        "áàảãạăắằẳẵặâấầẩẫậÁÀẢÃẠĂẮẰẲẴẶÂẤẦẨẪẬ",
        //        "éèẻẽẹêếềểễệÉÈẺẼẸÊẾỀỂỄỆ",
        //        "óòỏõọôốồổỗộơớờởỡợÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢ",
        //        "úùủũụưứừửữựÚÙỦŨỤƯỨỪỬỮỰ",
        //        "íìỉĩịÍÌỈĨỊ",
        //        "ýỳỷỹỵÝỲỶỸỴ",
        //        "đĐ"
        //    };

        //    //var a = arrays[1].UnicodeEscaps();
        //    //a = arrays[2].UnicodeEscaps();
        //    //a = arrays[3].UnicodeEscaps();
        //    //a = arrays[4].UnicodeEscaps();
        //    //a = arrays[5].UnicodeEscaps();
        //    //a = arrays[6].UnicodeEscaps();
        //    //a = arrays[7].UnicodeEscaps();

        //    if (string.IsNullOrWhiteSpace(text)) return text;
        //    var retVal = new StringBuilder();
        //    var length = text.Length;
        //    for (int i = 0; i < length; i++) {
        //        var chr = char.ToLower(text[i]);
        //        if (chr > 'z') {
        //            for (var index = 0; index < count; index++) {
        //                if (arrays[index].Contains(chr)) {
        //                    chr = letters[index];
        //                    index = count;
        //                    continue;
        //                }
        //            }
        //        }
        //        retVal.Append(chr);
        //    }
        //    return retVal.ToString();
        //}

        //public static string UnicodeEscaps(this string text) {
        //    var retVal = new StringBuilder();
        //    var length = text.Length;
        //    for (int i = 0; i < length; i++) {
        //        var chr = text[i];
        //        retVal.Append("\\u").Append(((int)chr).ToString("X4"));
        //    }
        //    return retVal.ToString();
        //}

        #region :: Blob Helper ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsNullOrEmpty([NotNullWhen(false)] this byte[]? buffer)
            => buffer is null || buffer.Length == 0;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsEmpty(this byte[] buffer)
            => buffer.Length == 0;
        public static bool Compare(this byte[]? buf, byte[]? oth) {
            if (buf is null && oth is null) return true;
            if (buf is null || oth is null || buf.Length != oth.Length) return false;
            if (ReferenceEquals(buf, oth)) return true;
            unsafe {
                fixed (byte* p1 = buf, p2 = oth) {
                    byte* x1 = p1, x2 = p2;
                    int l = buf.Length / 8;

                    for (int i = 0; i < l; i++, x1 += 8, x2 += 8)
                        if (*(long*)x1 != *(long*)x2) return false;

                    l = buf.Length;
                    if ((l & 4) != 0) { if (*(int*)x1 != *(int*)x2) return false; x1 += 4; x2 += 4; }
                    if ((l & 2) != 0) { if (*(short*)x1 != *(short*)x2) return false; x1 += 2; x2 += 2; }
                    if ((l & 1) != 0) if (*x1 != *x2) return false;
                    return true;
                }
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string ToBase64(this byte[] arr)
            => Convert.ToBase64String(arr);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static byte[]? Base64ToBlob(this string base64)
            => TryParseBase64(base64, out byte[]? retVal) ? retVal : null;
        public static bool TryParseBase64(this string base64, [NotNullWhen(true)] out byte[]? blob) {
            const int bitsEncodedPerChar = 6;
            int bytesExpected = (base64.Length * bitsEncodedPerChar) >> 3; // divide by 8 bits in a byte
            Span<byte> bytesBuffer = stackalloc byte[bytesExpected];
            if (!Convert.TryFromBase64String(base64, bytesBuffer, out int bytesWritten)) {
                blob = null;
                return false;
            }
            blob = bytesBuffer[..bytesWritten].ToArray();
            return true;
        }

        public static string ToHex(this byte[] arr) {
            if (arr.IsEmpty()) return string.Empty;
            var sb = new StringBuilder();
            var length = arr.Length;
            for (int i = 0; i < length; i++) {
                sb.Append(arr[i].ToString("X2"));
            }
            return sb.ToString();
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static byte[]? HexToBlob(this string hex)
            => TryParseHex(hex, out byte[]? retVal) ? retVal : null;
        public static bool TryParseHex(this string txt, [NotNullWhen(true)] out byte[]? blob) {
            if (string.IsNullOrEmpty(txt)) {
                blob = [];
                return false;
            }
            try {
                var retVal = new byte[txt.Length / 2];
                var length = retVal.Length;
                for (int i = 0; i < length; i++) {
                    retVal[i] = Convert.ToByte(txt.Substring(i * 2, 2), 16);
                }
                blob = retVal;
                return true;
            } catch {
                blob = null;
                return false;
            }
        }
        #endregion

        #region :: SecureString Helpers ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string? ToString(this SecureString password)
            => Helper.ToString(password);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static SecureString ToSecureString(this string text)
            => Helper.ToSecureString(text);
        #endregion
    }
}
