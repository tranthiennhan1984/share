﻿using Binean.Private;
using Microsoft.VisualBasic;
using System;
using System.ComponentModel;
using System.Globalization;
using System.Runtime.CompilerServices;

namespace Binean.Foundation {
    public class Converter {
        private readonly List<Conversion> _conversions = [];
        public Converter() {
            _conversions.Add(Helper.InToEntityConvert);
            _conversions.Add(Helper.InFromEntityConvert);
            _conversions.Add(Helper.InInheritConvert);
            _conversions.Add(Helper.InEnumConvert);
            _conversions.Add(Helper.InConvertibleConvert);
            _conversions.Add(Helper.InBIDConvert);
            _conversions.Add(Helper.InTypeNameConvert);
            _conversions.Add(Helper.InBPathConvert);
            _conversions.Add(Helper.InBlobConvert);
            _conversions.Add(Helper.InGuidConvert);
            _conversions.Add(Helper.InDateTimeConvert);
            _conversions.Add(Helper.InSysTypeConvert);
            //_conversions.Add(Helper.InSysCastConvert);
        }

        public void Register(Conversion conversion) {
            _conversions.Add(conversion);
        }

        public bool TryConvert(object? value, Type destinationType, out object? result, ConverterArguments args) {
            if (destinationType is null) {
                result = null;
                return true;
            }

            if (value == null || value is DBNull) {
                result = destinationType.Default();
                return true;
            }

            if (destinationType == typeof(object)) { result = value; return true; }

            var targetType = Nullable.GetUnderlyingType(destinationType) ?? destinationType;
            var length = _conversions.Count;
            for (int i = 0; i < length; i++) {
                var conversion = _conversions[i];
                var retVal = conversion(value, targetType, out result, args);
                if (retVal != null) return retVal.Value;
            }

            if (destinationType == typeof(string)) {
                result = value.ToString();
                return true;
            }

            result = null;
            return false;
        }
    }

    public delegate bool? Conversion(object value, Type destinationType, out object? result, ConverterArguments args);

    [Avatar]
    public class ConverterArguments {
        [AvatarProperty]
        public BIDType BIDType { get; set; } = BIDType.Name;

        [AvatarProperty]
        public bool BPathAssert { get; set; } = false;
        [AvatarProperty]
        public char BPathMemberSeparator { get; set; } = BPath.MemberSeparator;

        [AvatarProperty]
        public BlobType BlobType { get; set; } = BlobType.Base64;

        [AvatarProperty]
        public string? StringFormat { get; set; }
        [AvatarProperty]
        public List<string> StringFormats { get; } = [];

        [AvatarProperty]
        public bool BoxAllowed { get; set; } = true;
        [AvatarProperty]
        public bool BoxAvataOnly { get; set; } = false;

        [AvatarProperty]
        public bool UnboxAllowed { get; set; } = true;
        [AvatarProperty]
        public bool UnboxGuarantee { get; set; } = false;
    }

    public enum BlobType {
        Hex,
        Base64
    }
}
