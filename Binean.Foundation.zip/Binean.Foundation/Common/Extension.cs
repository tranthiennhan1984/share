﻿using System.Reflection;

namespace Binean.Foundation {
    public static partial class Extension {
        #region :: Bexception ::
        public static Exception Correct(this Exception ex)
            => Correct(ex, out bool _);
        public static Exception Correct(this Exception ex, out bool isCancelled) {
            isCancelled = false;
            var retVal = ex;
            AggregateException? ae;
            if ((ae = ex as AggregateException) is null) return retVal;
            if (ae.InnerException is TaskCanceledException) {
                isCancelled = true;
            }
            while (ae != null && ae.InnerExceptions.Count == 1) {
                retVal = ae.InnerExceptions[0];
                ae = retVal as AggregateException;
            }
            return retVal;
        }
        #endregion

        #region :: Helpers ::
        public static IDisposable AssertDisposable(this IDisposable? disposable)
            => disposable ?? Dummy.Disposable;
        public static string? GetFirstManifestResourcePath(this Assembly asm, string name) {
            if (string.IsNullOrWhiteSpace(name)) return null;
            name = '.' + name.TrimStart('.');
            foreach (var n in asm.GetManifestResourceNames()) {
                if (n.EndsWith(name)) return n;
            }
            return null;
        }
        public static string AssertPath(this string? folderPath, string? dir = null) {
            if (!string.IsNullOrWhiteSpace(folderPath) && Path.IsPathRooted(folderPath)) return folderPath;

            if (string.IsNullOrWhiteSpace(dir)) {
                var type = new System.Diagnostics.StackTrace().GetFrame(1)?.GetMethod()?.DeclaringType ?? typeof(Extension);
                if (Path.GetDirectoryName(type.Assembly.Location) is not string location || string.IsNullOrWhiteSpace(location)) return folderPath ?? string.Empty;
                dir = location;
            }
            return string.IsNullOrWhiteSpace(folderPath) ? dir : Path.Combine(dir, folderPath);
        }
        #endregion
    }
}
