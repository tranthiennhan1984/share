﻿namespace Binean.Foundation {
    [AttributeUsage(AttributeTargets.Assembly, AllowMultiple = false, Inherited = false)]
    public sealed class BAssemblyAttribute : Attribute {
    }
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    public sealed class BLogAttribute : Attribute {
    }
}

