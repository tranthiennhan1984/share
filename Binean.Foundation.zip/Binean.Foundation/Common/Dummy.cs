﻿using Binean.Private;
using System.Collections;

namespace Binean.Foundation {
    public partial class Dummy {
        public static readonly IDisposable Disposable = new Disposable(null);
        public static readonly IEntity Entity = new DummyEntity();
        public static readonly IGetter Getter = Entity;
        public static readonly IEnumerable List = Array.Empty<object?>();
        public static readonly IBSet NameList = new DummyNameList();

        public static readonly Func<IGetter> ReturnGetter = () => Getter;
        public static readonly Func<IGetter> ReturnEntity = () => Entity;

        public static readonly IScript Script = new DummyScript();

        public static readonly ICell Cell = new DummyCell();
        public static readonly ILogger ErrLog = new ExceptionLogger();
        public static readonly ILogger Logger = new NullLogger();

        public static readonly Proc ErrorProc = r => r.InternalServerError();
        public static readonly Proc ReturnProc = r => r.NoContent();
        public static readonly Proc KillProc = r => r.Kill();

        public static readonly ValidationDelegate ValidationDelegate = (logger) => true;

        public static ILogger CreateLogger() => new DummyLogger();
        public static IEntity CreateEntity() => new DummyEntity();

        private sealed class DummyEntity : IEntity {
            bool IGetter.IsEmpty => true;
            public IReadonlyBSet Names => NameList;
            bool IGettable.TryGetValue(BID bid, out object? obj)
                => (obj = null) != null;
            bool ISettable.TrySetValue(BID bid, object? value) => false;
            bool ISetter.Clear() => true;
            bool ISetter.TryRemoveValue(BID bid) => false;
        }


        private sealed class ExceptionLogger : ILogger {
            public LogLevel MinimumLevel {
                get => LogLevel.Error;
                set { }
            }

            public IGetter? ErrorMessage { get; private set; }
            public LogLevel MaxLogLevel => LogLevel.Verbose;

            public void Log(IGetter message) {
                var level = message.Get(Properties.LogLevel, LogLevel.Information);
                if (level < LogLevel.Error) return;
                ErrorMessage = message;
                throw message.CreateError();
            }
        }
        private sealed class DummyLogger : ILogger {
            public LogLevel MinimumLevel { get; set; } = LogLevel.Verbose;
            public IGetter? ErrorMessage { get; private set; }
            public LogLevel MaxLogLevel { get; private set; }
            public void Log(IGetter message) {
                var level = message.Get(Properties.LogLevel, LogLevel.Verbose);
                if (level > MinimumLevel) MinimumLevel = level;
                if (level < MaxLogLevel) MaxLogLevel = level;
                if (level >= LogLevel.Error) ErrorMessage = message;
            }
        }
        private sealed class NullLogger : ILogger {
            public LogLevel MinimumLevel { get; set; } = LogLevel.Verbose;
            public IGetter? ErrorMessage { get; private set; }
            public LogLevel MaxLogLevel { get; private set; } = LogLevel.Verbose;
            public void Log(IGetter message) {
                var level = message.Get(Properties.LogLevel, LogLevel.Verbose);
            }
        }

        private sealed class DummyNameList : IBSet {
            public bool IsSorted => false;
            public bool IsUnique => true;
            public BID this[int index] => BID.Nothing;
            public int Count => 0;

            public bool IsReadOnly {
                get => false;
                set { }
            }

            public int Add(BID item) => -1;
            public int Insert(int index, BID item) => -1;
            public void Clear() { }

            public bool Find(BID name, out int index) => (index = -1) > -1;

            private static IEnumerable<BID> GetItems() => [];
            public IEnumerator<BID> GetEnumerator() => GetItems().GetEnumerator();

            public void RemoveAt(int index) { }
            IEnumerator IEnumerable.GetEnumerator() => GetItems().GetEnumerator();
        }

        private sealed class DummyMessage : IMessage {
            public IMessage? Parent => null;
            public ILogger Logger => Dummy.Logger;
            public object? Response => throw new NotImplementedException();

            public BStatusCode StatusCode => throw new NotImplementedException();

            public BStatus BStatus => throw new NotImplementedException();

            public IEntity Potential => throw new NotImplementedException();

            public void ChangeStatus(BStatus status) {
                throw new NotImplementedException();
            }

            public bool Error(BStatusCode code, IGetter? message) {
                throw new NotImplementedException();
            }

            public bool Kill() {
                throw new NotImplementedException();
            }

            public bool Return(object? response, BStatusCode code = BStatusCode.Ok) {
                throw new NotImplementedException();
            }
        }

        private sealed class DummyScript : IScript {
            public BID Name => Name;
            public IEntity Functions => Entity;
        }

        private sealed class DummyCell : ICell {
            public bool AllowPathProcess => false;
            public ICell? Owner => null;
            public IReadonlyBSet Names => NameList;
            public bool IsEmpty => true;
            public bool Process(IMessage message) => message.Forbidden();
            public bool TryGetValue(BID name, out object? value) => (value = null) != null;
        }
    }
}
