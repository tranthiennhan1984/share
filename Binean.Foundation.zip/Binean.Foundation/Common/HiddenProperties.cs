﻿namespace Binean.Foundation {
    public static class HiddenProperties {
        /// <summary>
        /// System Type used in serializer
        /// </summary>
        public static readonly BID SysType = nameof(SysType).ToHiddenNameId();
        /// <summary>
        /// AvatarType used in serializer
        /// </summary>
        public static readonly BID AvatarType = nameof(AvatarType).ToHiddenNameId();
        /// <summary>
        /// Ordered Data used in serializer
        /// </summary>
        public static readonly BID Ordered = nameof(Ordered).ToHiddenNameId();
        /// <summary>
        /// Is Context value used in serializer
        /// </summary>
        public static readonly BID Context = nameof(Context).ToHiddenNameId();
        /// <summary>
        /// Is Appended data used in serializer
        /// </summary>
        public static readonly BID Append = nameof(Append).ToHiddenNameId();
        /// <summary>
        /// Next Item used in serializer
        /// </summary>
        public static readonly BID Next = nameof(Next).ToHiddenNameId();
        /// <summary>
        /// Class names
        /// </summary>
        public static readonly BID ClassNames = nameof(ClassNames).ToHiddenNameId();
        /// <summary>
        /// Class name
        /// </summary>
        public static readonly BID ClassName = nameof(ClassName).ToHiddenNameId();

        public static readonly BID Properties = nameof(Properties).ToHiddenNameId();
        public static readonly BID Owner = nameof(Owner).ToHiddenNameId();

        public static readonly BID Callback = nameof(Callback).ToHiddenNameId();

    }
}

