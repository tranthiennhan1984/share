﻿namespace Binean.Foundation {
    public static class Properties {
        public static readonly BID Id = nameof(Id);
        public static readonly BID Name = nameof(Name);
        public static readonly BID Type = nameof(Type);
        public static readonly BID Value = nameof(Value);
        public static readonly BID Content = nameof(Content);
        public static readonly BID Key = nameof(Key);
        public static readonly BID Text = nameof(Text);

        public static readonly BID ChildContent = nameof(ChildContent);
        public static readonly BID Tag = nameof(Tag);
        public static readonly BID Callback = nameof(Callback);

        public static readonly BID Icon = nameof(Icon);
        public static readonly BID Description = nameof(Description);

        public static readonly BID LogLevel = nameof(LogLevel);
        public static readonly BID LogTime = nameof(LogTime);
        public static readonly BID Exception = nameof(Exception);
        public static readonly BID Message = nameof(Message);
        public static readonly BID Trace = nameof(Trace);

        public static readonly BID Request = nameof(Request);
        public static readonly BID Scope = nameof(Scope);

        public static readonly BID Api = nameof(Api);
        public static readonly BID Path = nameof(Path);
        public static readonly BID Args = nameof(Args);
        public static readonly BID InfoType = nameof(InfoType);

        public static readonly BID Location = nameof(Location);
        public static readonly BID Position = nameof(Position);
        public static readonly BID Format = nameof(Format);
        public static readonly BID Extension = nameof(Extension);
        public static readonly BID IsReadonly = nameof(IsReadonly);

        public static readonly BID IsSelected = nameof(IsSelected);

        public static readonly BID Cell = nameof(Cell);
        public static readonly BID Batch = nameof(Batch);

        public static readonly BID Command = nameof(Command);
        public static readonly BID Link = nameof(Link);
        public static readonly BID Run = nameof(Run);

        public static readonly BID Formats = nameof(Formats);
        public static readonly BID Items = nameof(Items);
        public static readonly BID Service = nameof(Service);

        public static readonly BID Visible = nameof(Visible);
        public static readonly BID CanSearch = nameof(CanSearch);
        public static readonly BID Search = nameof(Search);

        public static readonly BID Loaded = nameof(Loaded);
    }
    public static class PathProperties {
        public static readonly BID Root = "~";
        public static readonly BID Current = ".";
        public static readonly BID Parent = "..";
    }
}

