﻿namespace Binean.Foundation.Protect {
    [BLog]
    internal static class Logs {
        public const string BFND40101E = "'EndArray punctuator' expected.";
        public const string BFND40102E = "'{0} punctuator' expected.";
        public const string BFND40103E = "Invalid argument types.";
    }
}