﻿namespace Binean.Private {
    internal sealed class FlowReader : MenReader {
        private readonly IContext _context;
        public FlowReader(object obj, IContext context, IEntity templatedArgs, Action? disposedAction = null) : base(obj, disposedAction) {
            _context = context;
            TemplateArgs = templatedArgs;
        }

        protected override Token OnTokenResolve(TokenResolve resolve, ref Serialize serialize, Token block, Token token) {
            var value = token.Value;
            //if (value is ICell cell) return new Token(NodeType.Value, GetCellValue(cell, _context), token.Name);
            if (value is IAction action) return new Token(NodeType.Value, action.Process(_context), token.Name);

            return base.OnTokenResolve(resolve, ref serialize, block, token);
        }
        //private static object? GetCellValue(ICell cell, IContext context) {
        //    var msg = context.CreateRequest(false);
        //    return cell.Process(msg) ? msg.Response : null;
        //}
    }
}