﻿using System.Collections;

namespace Binean.Private {
    internal sealed class DictionaryEntity(IDictionary dict) : IEntity, IEnumerable<Unit> {
        private readonly IDictionary _dict = dict;

        public bool IsEmpty => _dict.Count == 0;
        IReadonlyBSet IGetter.Names {
            get {
                var retVal = Prior.CreateSortedBSet();
                foreach (var key in _dict.Keys) {
                    if (key is not string name) continue;
                    retVal.Add(name);
                }
                return retVal;
            }
        }
        public bool TryGetValue(BID bid, out object? value) {
            if (!bid.IsNothing && _dict.Count > 0 && _dict.Contains(bid)) {
                value = _dict[bid];
                if (value is not DBNull) return true;
            }
            value = null;
            return false;
        }
        public bool TrySetValue(BID bid, object? value) {
            if (bid.IsNothing) return false;

            if (_dict.Contains(bid)) {
                if (value is DBNull) {
                    _dict.Remove(bid);
                    return false;
                }
                _dict[bid] = value;
                return true;
            }

            if (value is DBNull) return true;

            _dict[bid] = value;
            return true;
        }
        public bool Clear() {
            _dict.Clear();
            return true;
        }
        public bool TryRemoveValue(BID bid) {
            if (!_dict.Contains(bid)) return false;
            _dict.Remove(bid);
            return true;
        }

        private List<Unit> GetUnits() {
            var retVal = new List<Unit>(_dict.Count);
            foreach (var name in _dict.Keys) {
                if (name?.ToString() is not string txt) continue;
                retVal.Add(new Unit(txt, _dict[name]));
            }
            return retVal;
        }

        IEnumerator<Unit> IEnumerable<Unit>.GetEnumerator() => GetUnits().GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetUnits().GetEnumerator();

    }
    internal sealed class ListEntity(IList list) : IEntity, IEnumerable<Unit> {
        private readonly IList _list = list;

        bool IGetter.IsEmpty => _list.Count == 0;
        IReadonlyBSet IGetter.Names => Dummy.NameList;
        public bool TryGetValue(BID name, out object? value) {
            if (!int.TryParse((string)name, out int index)) return (value = null) != null;
            if (index < 0 || index >= _list.Count) return (value = null) != null;
            return (value = _list[index]) is not DBNull || (value = null) != null;
        }
        public bool TrySetValue(BID name, object? value) => false;
        public bool Clear() => false;
        public bool TryRemoveValue(BID name) => false;
        public IEnumerable<Unit> GetUnits() {
            var length = _list.Count;
            for (int i = 0; i < length; i++) {
                yield return new Unit(BID.Nothing, _list[i]);
            }
        }
        public IEnumerable GetValues() => _list;
        IEnumerator<Unit> IEnumerable<Unit>.GetEnumerator() => GetUnits().GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => _list.GetEnumerator();
    }

    internal sealed class ValidationEntity(IEntity entity, ValidationDelegate? validationDelegate = null) : IEntity, IValidator {
        private readonly IEntity _entity = entity;
        private readonly ValidationDelegate _validationDelegate = validationDelegate ?? Dummy.ValidationDelegate;

        public bool IsEmpty => _entity.IsEmpty;
        public IReadonlyBSet Names => _entity.Names;

        public bool TryGetValue(BID bid, out object? value) => _entity.TryGetValue(bid, out value);
        public bool TrySetValue(BID bid, object? value) => _entity.TrySetValue(bid, value);
        public bool TryRemoveValue(BID bid) => _entity.TryRemoveValue(bid);
        public bool Clear() => _entity.Clear();
        public bool Validate(ILogger logger) {
            if (!_validationDelegate(logger)) return false;
            if (_entity is IValidator eval) return eval.Validate(logger);
            return true;
        }
    }

    internal sealed class ProspectEntity(IEntity avatar, IEntity potential, Func<BID, bool>? skipRead = null) : IEntity, IValidator, IEnumerable<Unit> {
        private readonly BSet _deleted = Prior.CreateSortedBSet();
        private readonly Func<BID, bool> _skipRead = skipRead ?? new Func<BID, bool>((b) => false);

        public bool IsEmpty => Avatar.IsEmpty && Potential.IsEmpty;

        public IEntity Avatar { get; private set; } = avatar;
        public IEntity Potential { get; private set; } = potential;

        public IReadonlyBSet Names => InGetNames();

        public bool TryGetValue(BID bid, out object? value) {
            if (bid.IsNothing || _deleted.Contains(bid) || _skipRead(bid)) return (value = null) != null;

            if (Avatar.TryGetValue(bid, out value)) return true;

            return Potential.TryGetValue(bid, out value);
        }
        public bool TrySetValue(BID bid, object? value) {
            if (bid.IsNothing) return false;

            if (value is DBNull) _deleted.Add(bid);
            else _deleted.Remove(bid);

            if (Avatar.TrySetValue(bid, value)) return true;
            return Potential.TrySetValue(bid, value);
        }
        public bool Clear() {
            Avatar.Clear();
            Potential.Clear();
            _deleted.Clear();
            return true;
        }
        public bool TryRemoveValue(BID name) {
            if (name.IsNothing) return false;
            _deleted.Add(name);
            if (Avatar.TryRemoveValue(name)) return true;
            return Potential.TryRemoveValue(name);
        }

        private BSet InGetNames() {
            var retVal = Prior.CreateSortedBSet();
            retVal.AddRange(Avatar.Names);
            if (!Potential.IsEmpty) retVal.AddRange(Potential.Names);
            retVal.RemoveRange(_deleted);
            return retVal;
        }
        private IEnumerable<Unit> InGetUnits() {
            var visited = Prior.CreateSortedBSet().AddRange(_deleted);

            foreach (var unit in Avatar.GetUnits()) {
                var name = unit.Name;
                if (_deleted.Find(name, out _)) continue;
                visited.Add(name);
                yield return unit;
            }

            foreach (var unit in Potential.GetUnits()) {
                var name = unit.Name;
                if (visited.Find(name, out _)) continue;
                yield return unit;
            }
        }

        public bool Validate(ILogger logger) => (Avatar as IValidator)?.Validate(logger) ?? false;
        public IEnumerator<Unit> GetEnumerator() => InGetUnits().GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => InGetUnits().GetEnumerator();

    }

    internal sealed class HiddenEntity(IEntity entity) : IEntity {
        private readonly IEntity _entity = entity;

        public IReadonlyBSet Names {
            get {
                var retVal = Prior.CreateBList();
                foreach (var name in _entity.Names) {
                    if (name.IsHiddenName) retVal.Add(name.Unhide());
                }
                return retVal;
            }
        }

        public bool IsEmpty => _entity.IsEmpty;
        public bool Clear() {
            bool retVal = true;
            foreach (var name in Names) {
                retVal &= _entity.TryRemoveValue(name);
            }
            return retVal;
        }

        public bool TryGetValue(BID name, out object? value) {
            name = name.Hide();
            if (name.IsNothing) return (value = null) != null;
            return _entity.TryGetValue(name, out value);
        }
        public bool TryRemoveValue(BID name) {
            name = name.Hide();
            if (name.IsNothing) return false;
            return _entity.TryRemoveValue(name);
        }
        public bool TrySetValue(BID name, object? value) {
            name = name.Hide();
            if (name.IsNothing) return false;
            return _entity.TrySetValue(name, value);
        }
    }

    internal sealed class LockedEntity(IGetter getter) : IGetter {
        public IGetter Source { get; } = getter;

        public IReadonlyBSet Names => Source.Names;
        public bool IsEmpty => Source.IsEmpty;
        public bool TryGetValue(BID name, out object? value) {
            if (!Source.TryGetValue(name, out value)) return false;
            if (value is IEntity ent) value = new LockedEntity(ent);
            return true;
        }
    }
}