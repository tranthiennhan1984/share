﻿using Binean.Foundation.Protect;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;
using Logs = Binean.Foundation.Protect.Logs;

namespace Binean.Private {
    internal static partial class Helper {

        #region :: Message Helpers ::
        internal static void LoadLogs(IEntity logs, Type type) {
            var fields = type.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);

            var length = fields.Length;
            for (int i = 0; i < length; i++) {
                if (fields[i] is not FieldInfo field) continue;
                if (field.GetValue(null) is not string msg) continue;
                BID bid = field.Name;
                if (logs.Contains(bid)) throw new InvalidDataException($"Log id '{bid}' in type '{type}' existed.");
                logs.Set(bid, GenerateLog(bid, msg));
            }
        }
        internal static Entity GenerateLog(string mid, string message) {
            InParseMessageId(mid, out LogLevel logLevel);
            return Prior.CreateEntity()
               .Set(Properties.Id, mid)
               .Set(Properties.LogLevel, logLevel)
               .Set(Properties.Message, message);

        }
        private static void InParseMessageId(string msgId, out LogLevel logLevel) {
            var length = msgId.Length;

            var chr = msgId[length - 1];
            var lv = "VDIWEF".IndexOf(char.ToUpper(chr));
            if (lv > -1) {
                logLevel = (LogLevel)lv;
            } else logLevel = LogLevel.Verbose;
        }

        internal static Entity GenerateLog(IEntity logs, string id, params object?[] args) {
            var getter = logs.Get(id).As<IGetter>();
            var retVal = Prior.CreateEntity().Set(Properties.Message, InBuildLog(getter?.Get(Properties.Message).As<string>(), id, args));
            if (!getter.IsNullOrEmpty()) retVal.MAssign(getter, false);
            return retVal;
        }
        private static string InBuildLog(string? msg, string id, params object?[] args) {
            if (string.IsNullOrWhiteSpace(msg)) {
                var sb = new StringBuilder(id);
                var length = args.Length;
                for (int i = 0; i < length; i++) {
                    sb.Append($" {{{i}}}");
                }
                msg = sb.ToString();
            }

            string retVal = (args.Length > 0 ? string.Format(CultureInfo.CurrentCulture, msg, args) : msg) ?? string.Empty;

            char first;
            return retVal.Length > 0 && char.IsLower(first = retVal[0]) ? $"{char.ToUpper(first)}{retVal[1..]}" : retVal;
        }
        #endregion

        #region :: IO Helpers ::

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal static char ToChar(this int value) => value <= 0 ? Prior.EofCharacter : (char)value;

        #endregion

        #region :: Reflection Helpers ::
        internal static AvatarGetDelegate BuildGetAccessor(this PropertyInfo propertyInfo) {
            var ownerType = propertyInfo.DeclaringType!;
            var propType = propertyInfo.PropertyType;

            DynamicMethod dynamicMethod = new("GetProperty", typeof(object), [typeof(object)], ownerType);

            ILGenerator il = dynamicMethod.GetILGenerator();

            il.Emit(OpCodes.Ldarg_0);
            il.Emit(OpCodes.Castclass, ownerType);
            il.EmitCall(OpCodes.Callvirt, propertyInfo.GetGetMethod()!, null);
            if (propType.IsValueType) il.Emit(OpCodes.Box, propType);

            il.Emit(OpCodes.Ret);

            var func = (Func<object, object?>)dynamicMethod.CreateDelegate(typeof(Func<object, object?>));
            return delegate (object instance, out object? value) {
                value = func(instance);
                return true;
            };
        }
        internal static AvatarSetDelegate? BuildSetAccessor(this PropertyInfo propertyInfo) {
            if (propertyInfo.GetSetMethod() is not MethodInfo methodInfo) return null;

            var ownerType = propertyInfo.DeclaringType!;
            var propType = propertyInfo.PropertyType;

            var dynamicMethod = new DynamicMethod("SetProperty", null, [typeof(object), typeof(object)], ownerType);

            var il = dynamicMethod.GetILGenerator();

            il.Emit(OpCodes.Ldarg_0);
            il.Emit(OpCodes.Castclass, ownerType);
            il.Emit(OpCodes.Ldarg_1);
            if (propType.IsValueType) il.Emit(OpCodes.Unbox_Any, propType);
            il.EmitCall(OpCodes.Callvirt, methodInfo, null);
            il.Emit(OpCodes.Ret);

            var action = (Action<object, object?>)dynamicMethod.CreateDelegate(typeof(Action<object, object?>));

            return new AvatarSetDelegate((i, o) => {
                if (!o.TryConvert(propType, out object? value)) return false;
                action(i, value);
                return true;
            });
        }
        internal static AvatarGetDelegate BuildGetProcAccessor(this MethodInfo methodInfo, out Type? reqType, out bool nullable) {
            var args = methodInfo.GetParameters();
            if (args.Length < 1 || args.Length > 2 || args[0].ParameterType != typeof(IMessage))
                throw LogStorage.CreateError(nameof(Logs.BFND40103E));

            nullable = true;
            reqType = null;
            var isSync = methodInfo.ReturnType == typeof(bool);
            if (args.Length == 1) return isSync ? methodInfo.BuildGetProcAccessor() : methodInfo.BuildGetProcAsyncAccessor();

            nullable = args[1].GetCustomAttribute<NullableAttribute>() != null;
            reqType = args[1].ParameterType;
            return isSync ? methodInfo.BuildGetProcAccessor(reqType, nullable) : methodInfo.BuildGetProcAsyncAccessor(reqType, nullable);
        }
        private static AvatarGetDelegate BuildGetProcAccessor(this MethodInfo methodInfo) {
            var ownerType = methodInfo.DeclaringType!;
            var dynamicMethod = new DynamicMethod("CallMethod", typeof(bool), [typeof(object), typeof(IMessage)], ownerType);

            ILGenerator il = dynamicMethod.GetILGenerator();

            il.Emit(OpCodes.Ldarg_0);
            il.Emit(OpCodes.Castclass, ownerType);
            il.Emit(OpCodes.Ldarg_1);
            il.EmitCall(OpCodes.Callvirt, methodInfo, null);
            il.Emit(OpCodes.Ret);

            var func = (Func<object, IMessage, bool>)dynamicMethod.CreateDelegate(typeof(Func<object, IMessage, bool>));

            return delegate (object instance, out object? value) {
                value = new Proc(m => func(instance, m));
                return true;
            };
        }
        private static AvatarGetDelegate BuildGetProcAccessor(this MethodInfo methodInfo, Type reqType, bool nullable) {
            var ownerType = methodInfo.DeclaringType!;
            var dynamicMethod = new DynamicMethod("CallMethod", typeof(bool), [typeof(object), typeof(IMessage), typeof(object)], ownerType);

            ILGenerator il = dynamicMethod.GetILGenerator();

            il.Emit(OpCodes.Ldarg_0);
            il.Emit(OpCodes.Castclass, ownerType);
            il.Emit(OpCodes.Ldarg_1);
            il.Emit(OpCodes.Ldarg_2);
            il.Emit(OpCodes.Castclass, reqType);
            il.EmitCall(OpCodes.Callvirt, methodInfo, null);
            il.Emit(OpCodes.Ret);

            var func = (Func<object, IMessage, object?, bool>)dynamicMethod.CreateDelegate(typeof(Func<object, IMessage, object?, bool>));

            return delegate (object instance, out object? value) {
                value = new Proc(m => {
                    if (!m.Potential.Get(Properties.Request).TryConvert(reqType, out object? args) && !nullable) {
                        m.Logger.Log(nameof(Foundation.Core.Logs.BFND10103E), reqType);
                        return m.BadRequest();
                    }
                    return func(instance, m, args);
                });
                return true;
            };
        }
        private static AvatarGetDelegate BuildGetProcAsyncAccessor(this MethodInfo methodInfo) {
            var ownerType = methodInfo.DeclaringType!;
            var dynamicMethod = new DynamicMethod("CallMethod", typeof(ValueTask<bool>), [typeof(object), typeof(IMessage)], ownerType);

            ILGenerator il = dynamicMethod.GetILGenerator();

            il.Emit(OpCodes.Ldarg_0);
            il.Emit(OpCodes.Castclass, ownerType);
            il.Emit(OpCodes.Ldarg_1);
            il.EmitCall(OpCodes.Callvirt, methodInfo, null);
            il.Emit(OpCodes.Ret);

            var func = (Func<object, IMessage, ValueTask<bool>>)dynamicMethod.CreateDelegate(typeof(Func<object, IMessage, ValueTask<bool>>));

            return delegate (object instance, out object? value) {
                value = new ProcAsync(m => func(instance, m));
                return true;
            };
        }
        internal static AvatarGetDelegate BuildGetProcAsyncAccessor(this MethodInfo methodInfo, Type reqType, bool nullable) {
            var ownerType = methodInfo.DeclaringType!;
            var dynamicMethod = new DynamicMethod("CallMethod", typeof(ValueTask<bool>), [typeof(object), typeof(IMessage), typeof(object)], ownerType);

            ILGenerator il = dynamicMethod.GetILGenerator();

            il.Emit(OpCodes.Ldarg_0);
            il.Emit(OpCodes.Castclass, ownerType);
            il.Emit(OpCodes.Ldarg_1);
            il.Emit(OpCodes.Ldarg_2);
            il.Emit(OpCodes.Castclass, reqType);
            il.EmitCall(OpCodes.Callvirt, methodInfo, null);
            il.Emit(OpCodes.Ret);

            var func = (Func<object, IMessage, object?, ValueTask<bool>>)dynamicMethod.CreateDelegate(typeof(Func<object, IMessage, object?, ValueTask<bool>>));

            return delegate (object instance, out object? value) {
                value = new ProcAsync(m => {
                    if (!m.Potential.Get(Properties.Request).TryConvert(reqType, out object? args) && !nullable) {
                        m.Logger.Log(nameof(Foundation.Core.Logs.BFND10103E), reqType);
                        return ValueTask.FromResult(m.BadRequest());
                    }
                    return func(instance, m, args);
                });
                return true;
            };
        }

        #endregion

        #region :: SecureString Helpers ::
        internal static string? ToString(this SecureString password) {
            IntPtr unmanagedString = IntPtr.Zero;
            try {
                unmanagedString = System.Runtime.InteropServices.Marshal.SecureStringToGlobalAllocUnicode(password);
                return System.Runtime.InteropServices.Marshal.PtrToStringUni(unmanagedString);
            } finally {
                System.Runtime.InteropServices.Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }
        internal static SecureString ToSecureString(this string text) {
            var retVal = new SecureString();
            if (string.IsNullOrWhiteSpace(text)) return retVal;
            var length = text.Length;
            for (int i = 0; i < length; i++) {
                retVal.AppendChar(text[i]);
            }
            retVal.MakeReadOnly();
            return retVal;
        }
        #endregion
    }
}