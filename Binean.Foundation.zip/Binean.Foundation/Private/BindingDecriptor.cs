﻿namespace Binean.Private {
    internal sealed class BindingDecriptor {
        private BindingDecriptor(Type bindingType, BindingLifetime lifetime) {
            Lifetime = lifetime;
            BindingType = bindingType;
        }
        public BindingDecriptor(Type bindingType, object instance) : this(bindingType, BindingLifetime.Singleton) {
            ImplementationInstance = instance;
        }
        public BindingDecriptor(Type bindingType, Type implementationType, BindingLifetime lifetime) : this(bindingType, lifetime) {
            ImplementationType = implementationType;
            if (lifetime != BindingLifetime.Transient) ImplementationInstance = Activator.CreateInstance(ImplementationType!);
        }
        public BindingDecriptor(Type bindingType, Func<object>? implementationFactory, BindingLifetime lifetime) : this(bindingType, lifetime) {
            ImplementationFactory = implementationFactory;
            if (lifetime != BindingLifetime.Transient) ImplementationInstance = ImplementationFactory!.Invoke();
        }
        public BindingLifetime Lifetime { get; internal set; }
        public Type BindingType { get; }
        public Type? ImplementationType { get; }
        public object? ImplementationInstance { get; private set; }
        public Func<object>? ImplementationFactory { get; }

        public object GetInstance() {
            if (Lifetime != BindingLifetime.Transient) return ImplementationInstance!;
            return CreateInstance();
        }
        private object CreateInstance() {
            return ImplementationFactory != null ? ImplementationFactory() : Activator.CreateInstance(ImplementationType!)!;
        }
    }
}
