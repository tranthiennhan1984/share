﻿namespace Binean.Private {
    sealed class WeakAvatarInfo : AvatarInfo {
        private WeakReference _dataRef;
        private int _genCount = 0;
        public WeakAvatarInfo(Type sysType, AvatarAttribute avaAtt) : base(sysType, avaAtt) {
            _dataRef = new WeakReference(GenerateData(), true);
        }
        protected override Entity OnGetData() {
            if (_dataRef.IsAlive && _dataRef.Target is Entity ent) return ent;
            ent = GenerateData();
            if (_dataRef.IsAlive) _dataRef.Target = ent;
            else _dataRef = new WeakReference(ent, true);
            if (++_genCount >= 5) {
                Task.Factory.StartNew(() => Prior.ConvertToPersistencyAvatar(SysType, AvatarAttribute)).ConfigureAwait(false);
            }
            return ent;
        }
    }
    sealed class PersistentAvatarInfo : AvatarInfo {
        private readonly Entity _data;
        public PersistentAvatarInfo(Type sysType, AvatarAttribute avaAtt) : base(sysType, avaAtt) {
            _data = GenerateData();
        }
        protected override Entity OnGetData() => _data;
    }
}