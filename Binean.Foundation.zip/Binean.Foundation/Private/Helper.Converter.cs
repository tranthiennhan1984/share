﻿using Binean.Foundation.Protect;
using Microsoft.VisualBasic;
using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace Binean.Private {
    internal static partial class Helper {
        public const string DateTimeFormat = "yyyy-MM-dd HH.mm.ss";
        public const string DateFormat = "yyyy-MM-dd";

        internal static bool? InToEntityConvert(object value, Type destinationType, out object? result, ConverterArguments args) {
            if (destinationType == typeof(IEntity)) {
                return (result = args.BoxAllowed ? value.Box(args.BoxAvataOnly) : value as IEntity) != null;
            }
            if (destinationType == typeof(IGetter)) {
                return (result = value is IGetter getter ? getter : args.BoxAllowed ? value.Box(args.BoxAvataOnly) : null) != null;
            }
            if (destinationType == typeof(ISetter)) {
                return (result = value is ISetter setter ? setter : args.BoxAllowed ? value.Box(args.BoxAvataOnly) : null) != null;
            }
            if (destinationType == typeof(IGettable)) {
                return (result = value is IGettable gettable ? gettable
                    : value is GetDelegate deleg ? new DelegateGettable(deleg)
                    : args.BoxAllowed ? value.Box(args.BoxAvataOnly) : null) != null;
            }
            if (destinationType == typeof(ISettable)) {
                return (result = value is ISettable settable ? settable
                    : value is SetDelegate deleg ? new DelegateSettable(deleg)
                    : args.BoxAllowed ? value.Box(args.BoxAvataOnly) : null) != null;
            }
            result = null;
            return null;
        }
        internal static bool? InFromEntityConvert(object value, Type destinationType, out object? result, ConverterArguments args) {
            if (value is IGettable gettable) {
                if (gettable.Get(HiddenProperties.SysType)?.As<Type>() is Type t && destinationType.IsAssignableFrom(t)) destinationType = t;
                if (destinationType.IsAssignableFrom(value.GetType())) return (result = value) != null;

                if (!args.UnboxAllowed || gettable is not IEntity ent) return (result = null) != null;
                return (result = ent.Unbox(destinationType, args.UnboxGuarantee)) != null;
            }
            result = null;
            return null;
        }
        internal static bool? InInheritConvert(object value, Type destinationType, out object? result, ConverterArguments args) {
            var valueType = value.GetType();
            if (valueType == destinationType || destinationType.IsAssignableFrom(valueType)) {
                result = value;
                return true;
            }
            result = null;
            return null;
        }
        internal static bool? InEnumConvert(object value, Type destinationType, out object? result, ConverterArguments args) {
            if (destinationType.IsEnum) return TryEnum(value, destinationType, out result);
            result = null;
            return null;
        }
        internal static bool? InConvertibleConvert(object value, Type destinationType, out object? result, ConverterArguments args) {
            if (value is not IConvertible || !destinationType.IsPrimitive) {
                result = null;
                return null;
            }
            try {
                result = Convert.ChangeType(value, destinationType, CultureInfo.CurrentCulture);
                return true;
            } catch {
                result = null;
                return false;
            }
        }
        internal static bool? InBIDConvert(object value, Type destinationType, out object? result, ConverterArguments args) {
            if (destinationType == typeof(BID)) {
                if (value is string text) {
                    result = args.BIDType switch {
                        BIDType.Name => (BID)text,
                        BIDType.Code => text.ToCodeId(),
                        _ => new StringReader(text).CreateTextReader().ReadBID()
                    };
                    return true;
                }
                if (value is ulong code) {
                    result = (BID)code;
                    return true;
                }
                if (value is Guid guid) {
                    result = (BID)guid;
                    return true;
                }
                if (value is Type type) {
                    result = (BID)type;
                    return true;
                }
                if (value is IntPtr intPtr) {
                    result = (BID)intPtr;
                    return true;
                }
                result = null;
                return false;
            }

            if (value is BID bid) {
                if (destinationType == typeof(string)) {
                    result = args.BIDType switch {
                        BIDType.Name => (string)bid,
                        BIDType.Code => bid.ToString(),
                        _ => bid.ToText()
                    };
                    return true;
                }
                if (destinationType == typeof(ulong)) {
                    result = (ulong)bid;
                    return true;
                }
                if (destinationType == typeof(Guid)) {
                    result = (Guid)bid;
                    return true;
                }
                if (destinationType == typeof(Type)) {
                    result = bid.ToType();
                    return true;
                }
                result = null;
                return false;
            }

            result = null;
            return null;
        }
        internal static bool? InTypeNameConvert(object value, Type destinationType, out object? result, ConverterArguments args) {
            if (destinationType == typeof(Type)) {
                if (value is string typeName) {
                    try {
                        result = Type.GetType(typeName);
                        return true;
                    } catch (Exception ex) {
                        var _ = ex;
                        result = null;
                        return false;
                    }
                }
            }
            if (value is Type type && destinationType == typeof(string)) {
                result = type.InGetTypeName();
                return true;
            }
            result = null;
            return null;
        }
        internal static bool? InBPathConvert(object value, Type destinationType, out object? result, ConverterArguments args) {
            if (destinationType == typeof(BPath)) {
                result = value.ToBPath(args.BPathMemberSeparator, args.BPathAssert);
                return result != null;
            }

            if (value is BPath path) {
                if (destinationType == typeof(string)) {
                    result = path.ToString(args.BPathMemberSeparator);
                    return true;
                }
                if (path.Count == 1) {
                    if (destinationType == typeof(BID)) {
                        result = path[0];
                        return true;
                    }
                    if (destinationType == typeof(ulong)) {
                        result = (ulong)path[0];
                        return true;
                    }
                    if (destinationType == typeof(Guid)) {
                        result = (Guid)path[0];
                        return true;
                    }
                    if (destinationType == typeof(Type)) {
                        result = path[0].ToType();
                        return true;
                    }
                }
                result = null;
                return false;
            }

            result = null;
            return null;
        }
        internal static bool? InBlobConvert(object value, Type destinationType, out object? result, ConverterArguments args) {
            var blobType = args.BlobType;
            if (destinationType == typeof(byte[])) {
                if (value is not string txt) {
                    result = null;
                    return false;
                }
                if (txt.StartsWith('[')) {
                    blobType = BlobType.Hex;
                    txt = txt[1..^1];
                } else if (txt.StartsWith('{')) {
                    blobType = BlobType.Base64;
                    txt = txt[1..^1];
                }

                if (blobType == BlobType.Hex) {
                    result = txt.HexToBlob();
                    return result != null;
                }
                result = txt.Base64ToBlob();
                return result != null;
            }

            if (value is byte[] data && destinationType == typeof(string)) {
                result = args.BlobType switch {
                    BlobType.Hex => data.ToHex(),
                    _ => data.ToBase64()
                };
                return true;
            }

            result = null;
            return null;
        }
        internal static bool? InGuidConvert(object value, Type destinationType, out object? result, ConverterArguments args) {
            if (destinationType == typeof(Guid)) {
                if (value is string txt && Guid.TryParse(txt, out Guid retVal)) {
                    result = retVal;
                    return true;
                }
                if (value is byte[] blob) {
                    result = new Guid(blob);
                    return true;
                }
                result = null;
                return false;
            }
            if (value is Guid guid) {
                if (destinationType == typeof(string)) {
                    result = guid.ToString();
                    return true;
                }
                result = null;
                return false;
            }

            result = null;
            return null;
        }
        internal static bool? InDateTimeConvert(object value, Type destinationType, out object? result, ConverterArguments args) {
            if (destinationType == typeof(DateTime)) {
                if (value is string text) {
                    if (text.Length < 10) {
                        result = null;
                        return false;
                    }

                    if (args.StringFormats is List<string> formats) {
                        var length = formats.Count;
                        for (int i = 0; i < length; i++) {
                            if (DateTime.TryParseExact(text, formats[i], CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime dt)) {
                                result = dt;
                                return true;
                            }
                        }
                    }
                    if (args.StringFormat is not string format || string.IsNullOrEmpty(format)) format = text.Length == 10 ? DateFormat : DateTimeFormat;

                    if (DateTime.TryParseExact(text, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime dt2)) {
                        result = dt2;
                        return true;
                    }
                }
                result = null;
                return false;
            }

            if (value is DateTime dateTime) {
                if (destinationType == typeof(string)) {
                    if (args.StringFormat is not string format) format = DateTimeFormat;
                    result = dateTime.ToString(format, CultureInfo.CurrentCulture);
                    return true;
                }
                result = null;
                return false;
            }

            result = null;
            return null;
        }
        internal static bool? InSysTypeConvert(object value, Type destinationType, out object? result, ConverterArguments args) {
            if (TypeDescriptor.GetConverter(destinationType) is TypeConverter typeConverter && typeConverter.CanConvertFrom(destinationType)) {
                result = typeConverter.ConvertFrom(value);
                return true;
            }
            if (TypeDescriptor.GetConverter(destinationType) is TypeConverter valueConverter && valueConverter.CanConvertTo(destinationType)) {
                result = valueConverter.ConvertTo(value, destinationType);
                return true;
            }

            result = null;
            return null;
        }


        internal static BPath? ToBPath(this object value, char? memberSeparator = null, bool pathAssert = false) {
            if (value is BPath p) return p;
            if (value is string text) {
                if (BPath.TryParse(text, out BPath? p2, memberSeparator)) return p2;
                if (pathAssert) throw LogStorage.CreateError(nameof(Foundation.Primitive.Logs.BFND20202E), text);
                return null;
            }
            if (value is BID bid) return new BPath(bid);
            if (value is ulong code) return new BPath((BID)code);
            if (value is Guid guid) return new BPath((BID)guid);
            if (value is Type type) return new BPath((BID)type);
            if (value is IntPtr intPtr) return new BPath((BID)intPtr);

            return null;
        }
        private static string? InGetTypeName(this Type type) {
            var name = type.AssemblyQualifiedName;
            if (name is null) return null;
            var index = name.IndexOf(',', 0);
            index = name.IndexOf(',', index + 1);
            return name[..index].Replace(", ", ",");
        }

        internal static string ToTimeString(this DateTime time) => time.ToString(DateTimeFormat, CultureInfo.CurrentCulture);
        public static T ToEnum<T>(this int value, T faultValue) {
            var type = typeof(T);
            if (!type.IsEnum) return faultValue;
            try {
                return (T)Enum.ToObject(type, value) ?? faultValue;
            } catch {
                return faultValue;
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T ToEnum<T>(this object? value, T faultValue) {
            var enumType = typeof(T);
            if (!enumType.IsEnum || value == null) return faultValue;
            return !TryEnum(value, enumType, out object? result) || result is not T t ? faultValue : t;
        }

        private static bool TryEnum(object value, Type enumType, out object? result) {
            try {
                result = value is string text
                    ? Enum.Parse(enumType, text, true)
                    : Enum.ToObject(enumType, value);
                return true;
            } catch {
                result = null;
                return false;
            }
        }
    }
}