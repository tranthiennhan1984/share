﻿namespace Binean.Private {
    internal sealed class DummWriter : Writer {
        internal DummWriter(Action? disposedAction = null) {
            Initialize(new Node(NodeType.Array), WriteItem, disposedAction);
        }
        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            var tokenType = token.Type;
            if (tokenType.IsEndBlock()) return block.EndNode();
            return block.AddItem(new Node(tokenType, DBNull.Value, block.AssertTokenName(token.Name)));
        }
    }
}

