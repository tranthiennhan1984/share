﻿using System.Diagnostics;

namespace Binean.Private {
    internal sealed class DummyNode : DesNode {
        public DummyNode(ref Deserialize deserialize, NodeType tokenType, BID name)
            : base(deserialize, tokenType, DBNull.Value, name) {
            deserialize = WriteItem;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            if (token.Type.IsEndBlock()) {
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }
            if (block.Type.IsObject()) Debug.Assert(!token.Name.IsNothing);
            return block.AddItem(token.Skip(ref deserialize));
        }
    }
}
