﻿namespace Binean.Private {
    internal sealed class VirtualToken : BlockToken {
        private Serialize _next;
        public VirtualToken(ref Serialize serialize, NodeType tokenType, BID name, Serialize? next = null)
            : base(serialize, tokenType, null, name) {
            _next = next ?? serialize;
            serialize = ReadItem;
        }
        private Token ReadItem(TokenResolve resolve, ref Serialize serialize, Token block) {
            var token = _next(resolve, ref _next, block);
            if (block != this) return token;

            if (token.Type.IsEndBlock()) serialize = ReadEndBlock;
            else if (token.IsDummy) return ReadEndBlock(resolve, ref serialize, block);
            return token;
        }
    }
}
