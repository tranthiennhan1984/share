﻿
namespace Binean.Private {
    internal sealed class BlockReader : Stream {
        private readonly Stream _stream;
        private readonly int _capacity = 1024;
        private readonly byte[] _buffer;
        private int _index;
        private int _count;
        private bool _isEnd;

        private Action? _disposedAction;
        internal BlockReader(Stream stream, bool leaveOpen = false, int capacity = 1024) {
            _stream = stream;
            _disposedAction = leaveOpen ? null : stream.Dispose;
            _capacity = capacity;
            _buffer = new byte[_capacity + 1];
        }
        protected override void Dispose(bool disposing) {
            base.Dispose(disposing);
            if (_disposedAction != null) {
                _disposedAction();
                _disposedAction = null;
            }
        }
        public override bool CanRead => true;
        public override bool CanSeek => false;
        public override bool CanWrite => false;
        public override long Length => throw new NotSupportedException();
        public override long Position {
            get { return _stream.Position - (_count <= 0 ? 0 : _count - _index); }
            set { throw new NotSupportedException(); }
        }

        public override void Flush() => _stream.Flush();

        private bool ReadBuffer(byte[] buffer, ref int offset, ref int count, ref int total) {
            var exist = _count - _index;
            if (exist <= 0) return false;
            var min = Math.Min(exist, count);
            Array.Copy(_buffer, _index, buffer, offset, min);
            total += min;
            _index += min;
            offset += min;
            count -= min;
            return count == 0;
        }
        public override int Read(byte[] buffer, int offset, int count) {
            int retVal = 0;
            if (_index < _count && ReadBuffer(buffer, ref offset, ref count, ref retVal)) return retVal;
            while (!_isEnd) {
                _index = 0;
                _count = _stream.Read(_buffer, 0, _capacity);
                if (_isEnd = _count <= 0) break;
                if (ReadBuffer(buffer, ref offset, ref count, ref retVal)) break;
            }
            if (retVal > 0) return retVal;
            return _count;
        }

        public override long Seek(long offset, SeekOrigin origin)
            => throw new NotSupportedException();

        public override void SetLength(long value)
            => throw new NotSupportedException();

        public override void Write(byte[] buffer, int offset, int count)
            => throw new NotSupportedException();
    }
}
