﻿using System.Diagnostics;

namespace Binean.Private {
    internal sealed class BenSnode : DesNode {
        private readonly BenWriter _writer;
        private readonly BenDataTypes _itemType;

        internal BenSnode(BenWriter writer, ref Deserialize deserialize, BenDataTypes itemType, string? name = null)
            : base(deserialize, NodeType.Array, name) {
            Debug.Assert(itemType != BenDataTypes.None);
            _writer = writer;
            _writer.Write(BenPunctuator.BeginArray)
                .Write(BenPunctuator.ItemType)
                .Write(_itemType = itemType);
            deserialize = WriteItem;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            if (token.Type.IsEndBlock()) {
                _writer.Write(BenPunctuator.EndArray);
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }
            return _writer.WriteSameTypeItem(block, token, _itemType);
        }
    }
}
