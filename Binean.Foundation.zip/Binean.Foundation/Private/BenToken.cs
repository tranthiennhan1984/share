﻿using System.Diagnostics;
using Logs = Binean.Foundation.Protect.Logs;

namespace Binean.Private {
    internal sealed class BenToken : BlockToken {
        private static readonly Token _token = new(NodeType.None, null);
        private readonly BenReader _reader;
        private readonly BenPunctuator _endPunctuator;
        private readonly BenPunctuator _unexpPunctuator;

        public BenToken(BenReader reader, ref Serialize serialize, bool isObject, BID name)
            : base(serialize, isObject ? NodeType.Object : NodeType.Array, null, name) {
            _reader = reader;
            _endPunctuator = isObject ? BenPunctuator.EndObject : BenPunctuator.EndArray;
            _unexpPunctuator = isObject ? BenPunctuator.EndArray : BenPunctuator.EndObject;
            serialize = ReadItem;
        }

        private Token ReadItem(TokenResolve resolve, ref Serialize serialize, Token block) {
            Debug.Assert(this == block);
            var punc = _reader.PeekPunctuator();
            if (punc == _unexpPunctuator) throw _reader.CreateException(nameof(Logs.BFND40102E), _endPunctuator);
            if (punc == _endPunctuator) {
                _reader.MoveNext();
                return ReadEndBlock(resolve, ref serialize, block);
            }
            return block.AddItem(resolve(resolve, ref serialize, block, _token));
        }
    }
}
