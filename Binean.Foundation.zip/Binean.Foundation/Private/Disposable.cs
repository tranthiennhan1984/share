﻿namespace Binean.Private {
    internal sealed class Disposable(Action? disposedAction) : IDisposable {
        private Action? _disposedAction = disposedAction;

        public void Dispose() {
            _disposedAction?.Invoke();
            _disposedAction = null;
        }
    }
}