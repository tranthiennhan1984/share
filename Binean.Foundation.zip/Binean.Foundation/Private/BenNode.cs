﻿using System.Diagnostics;

namespace Binean.Private {
    internal sealed class BenNode : DesNode {
        private readonly BenWriter _writer;
        private readonly BenPunctuator _endNode;
        private readonly bool _assertName;

        public BenNode(BenWriter writer, ref Deserialize deserialize, bool isObject, string? name = null)
            : base(deserialize, isObject ? NodeType.Object : NodeType.Array, name) {
            _writer = writer;
            _writer.Write(isObject ? BenPunctuator.BeginObject : BenPunctuator.BeginArray);
            _endNode = isObject ? BenPunctuator.EndObject : BenPunctuator.EndArray;
            _assertName = isObject;
            deserialize = WriteItem;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            if (token.Type.IsEndBlock()) {
                _writer.Write(_endNode);
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }
            if (_assertName) Debug.Assert(!token.Name.IsNothing);
            return _writer.WriteItem(block, token, ref deserialize);
        }
    }
}
