﻿namespace Binean.Private {
    internal sealed class DelegateGettable(GetDelegate getDelegate) : IGettable {
        private readonly GetDelegate _getDelegate = getDelegate;
        public bool TryGetValue(BID bid, out object? value)
            => _getDelegate(bid, out value);
    }
    internal sealed class DelegateSettable(SetDelegate setDelegate) : ISettable {
        private readonly SetDelegate _setDelegate = setDelegate;
        public bool TrySetValue(BID name, object? value)
            => _setDelegate(name, value);
    }
}