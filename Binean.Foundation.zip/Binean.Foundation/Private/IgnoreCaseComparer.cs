﻿
namespace Binean.Private {
    internal sealed class IgnoreCaseComparer : StringComparer {
        public override int Compare(string? x, string? y) {
            if (x is null && y is null) return 0;
            if (x is null) return -1;
            if (y is null) return 1;

            return string.Compare(x, y, true);
        }
        public override bool Equals(string? x, string? y)
            => Compare(x, y) == 0;
        public override int GetHashCode(string obj) => obj.ToLower().GetHashCode();
    }
}

