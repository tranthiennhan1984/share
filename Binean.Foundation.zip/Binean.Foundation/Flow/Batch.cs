﻿using Binean.Private;
using System;
using System.Collections;
using System.Diagnostics.CodeAnalysis;

namespace Binean.Foundation.Flow {
    [Avatar]
    public class Batch : Cell {
        public const string ScriptExtension = ".bs";
        public static readonly BID bs = nameof(bs);

        public static Batch Current => _current ??= Generator.Create<Batch>();
        private static Batch? _current;

        protected readonly FileCell _fileCell;

        public Batch() {
            _fileCell = new FileCell {
                Location = nameof(Batch),
                Owner = this
            };
            ImmutableSetDelegate.Set(Resources.file, _fileCell);
            OnConfiguration();
        }

        public static void Test() {
            //var domain = Generator.Create<BDomain>();
            //if (domain.ToGettable().QGet((Bsid)"batch") is Batch batch) {
            //    if (batch.List() is IList scripts) {
            //        batch.Run(new BatchRunArgs {
            //            Path = scripts[0].Convert<string>()
            //        });
            //    }
            //}
        }

        [AvatarProperty]
        public string Location {
            get => _fileCell.Location;
            set => _fileCell.Location = value;
        }

        [AvatarMethod]
        public virtual bool List(IMessage message) {
            var retVal = _fileCell.Execute(BMethods.List, null, message);
            return message.Complete(retVal);
        }
        [AvatarMethod]
        public virtual bool Run(IMessage message, BatchRunArgs args) {
            var script = args.Script;
            if (script is null && !string.IsNullOrWhiteSpace(args.Path)) {
                if ((script = OnLoadScript(args.Path)) == null) message.BadRequest(nameof(Logs.BFND30112E), args.Path);
            }
            if (script is null && !string.IsNullOrWhiteSpace(args.Command)) {
                if ((script = OnLoadCommand(args.Command)) == null) message.BadRequest(nameof(Logs.BFND30111E), args.Path);
            }

            if (script is null) return message.BadRequest();

            if (!script.Functions.TryGetNotNull(Properties.main, out IFunc? func)) return message.BadRequest(nameof(Logs.BFND30101E));

            var context = CreateContext(func, null, message.Logger);
            if (!args.Arguments.IsNullOrEmpty()) context.Variables.Assign(args.Arguments);
            //if (func.Parameters is IGetter pars) ApplyArguments(context, pars, Prior.CreateEntity().QSet(Properties.Arguments, args.Arguments));

            try {
                OnLoadContext(context);
                Execute(func.Body, context);
                return message.Complete(context);
            } catch (Exception ex) {
                return message.Faulted(ex.Correct());
            } finally {
                OnSaveContext(context);
            }
        }

        protected virtual void OnConfiguration() { }
        protected virtual void OnSaveContext(IContext context) { }
        protected virtual void OnLoadContext(IContext context) { }

        protected virtual IScript? OnLoadScript(string path) {
            var retVal = _fileCell.Process(BMethods.Read, new FileRdArgs {
                Format = Formats.bs,
                Type = ContentType.Object,
                Path = path,
            });

            return retVal.As<IScript>() ?? retVal as IScript;
        }
        protected virtual IScript? OnLoadCommand(string commandText) {
            if (string.IsNullOrWhiteSpace(commandText)) return null;

            if (this.GetFormat(bs) is not IFormat format) return null;
            if (!(commandText = commandText.Trim()).EndsWith(';')) commandText += ';';
            commandText = $"func main() {{ {commandText} }}";

            using (var reader = format.Serialize(commandText).Assert()) {
                using (var writer = new MenWriter()) {
                    writer.Write(reader);
                    return writer.GetContent() as IScript;
                }
            }
        }
        public virtual IContext CreateContext(IContext? parent = null, ILogger? logger = null) {
            return new Context(this, parent?.Script ?? Dummy.Script, parent, logger);
        }
        public virtual IContext CreateContext(IFunc func, Context? parent = null, ILogger? logger = null) {
            var retVal = new Context(this, func.Script, parent, logger);
            retVal.Potential.Set(Properties.Function, func);
            return retVal;
        }

        public virtual void ApplyArguments(IContext context, IGetter pars, IGetter args)
            => context.ApplyArguments(pars, args);

        public virtual void Execute(IList actions, IContext context) {
            context.ChangeStatus(BStatus.Processing);
            var length = actions.Count;
            if (length == 0) return;
            for (int i = 0; i < length; i++) {
                if (context.IsCompleted()) return;
                if (actions[i] is not IAction act) {
                    context.BadRequest(nameof(Logs.BFND30102E), actions[i]);
                    return;
                }
                act.Process(context);
                //if (context.IsSuccess() ) {
                //    context.BadRequest(nameof(Logs.BFND30104E), actions[i]);
                //    return;
                //}
            }
            if (!context.IsCompleted()) context.NoContent();
        }

        public virtual object? ReadExpression(IContext context, object expression)
            => context.ReadExpression(expression);

        public virtual Reader Serialize(object expression, IContext context)
            => new FlowReader(expression, context, context.Variables);
    }

    [Avatar]
    public class BatchRunArgs : Avatar {
        [AvatarProperty]
        public string? Path { get; set; }
        [AvatarProperty]
        public string? Command { get; set; }
        [AvatarProperty]
        public IScript? Script { get; set; }
        [AvatarProperty]
        public IEntity? Arguments { get; set; }
    }

    file static class Resources {
        public static readonly BID file = nameof(file);
    }
    file static class Properties {
        public static readonly BID Arguments = nameof(Arguments);
        public static readonly BID Cells = nameof(Cells);

        public static readonly BID Response = nameof(Response);
        public static readonly BID StatusCode = nameof(StatusCode);

        public static readonly BID Function = nameof(Function);

        public static readonly BID main = nameof(main);
    }
    file static class Methods {
        public static readonly BID run = nameof(run);
    }
    file static class Formats {
        public static readonly BID bs = nameof(bs);
    }
}
