﻿namespace Binean.Foundation.Flow {
    [BLog]
    internal static class Logs {
        public const string BFND30101E = "Missing main function.";
        public const string BFND30102E = "Cannot convert '{0}' to IAction.";
        public const string BFND30103E = "Context is completed at action '{0}'.";

        public const string BFND30111E = "Cannot load command from: '{0}'.";
        public const string BFND30112E = "Cannot load script from path: '{0}'.";
    }
}
