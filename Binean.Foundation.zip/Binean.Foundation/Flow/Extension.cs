﻿using System.Runtime.CompilerServices;

namespace Binean.Foundation.Flow {
    public static class Extension {
        #region :: Common Helpers ::
        #endregion

        #region :: Context Helpers ::

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void ApplyArguments(this IContext context, IGetter pars, IGetter args) {
            var vars = context.Variables;
            var index = 0;
            foreach (var unit in pars.GetUnits()) {
                var name = unit.Name;
                if (name.IsNothing) continue;
                if (!args.TryGetValue(name, out object? v)) {
                    if (index < 0) v = unit.Value;
                    else if (!args.TryGetValue((BID)$"%{++index}", out v)) index = -2;
                } else index = -2;
                vars.Set(name, v);
            }
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? ReadExpression(this IContext context, object? expresion) {
            if (expresion is null) return null;
            if (expresion is IAction func) return func.Process(context);
            if (Generator.IsPrimitiveType(expresion.GetType())) return expresion;
            using (var reader = context.Batch.Serialize(expresion, context))
                return Men.ToObject(reader);
        }

        //public Reader Serialize(object obj, BRequest req, Action? disposedAction = null)
        //    => Serialize(obj, req, this, disposedAction);
        //private Reader Serialize(object obj, BRequest req, IContext source, Action? disposedAction = null)
        //    => new FuncReader(obj, req, source, _variables, disposedAction);
        #endregion
    }
}

