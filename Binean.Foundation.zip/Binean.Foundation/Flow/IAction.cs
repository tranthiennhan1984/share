﻿using System.Collections;

namespace Binean.Foundation.Flow {
    public interface IAction {
        object? Process(IContext context);
    }
    public interface IContext : IMessage {
        IScript Script { get; }
        Batch Batch { get; }
        BSet ReadonlyVariables { get; }
        IEntity Variables { get; }
    }
    public interface IScript {
        BID Name { get; }
        IEntity Functions { get; }
    }
    public interface IFunc {
        IScript Script { get; }
        BID Name { get; }
        IEntity Parameters { get; }
        IList Body { get; }
    }
}
