﻿using System.Collections;

namespace Binean.Foundation.Flow {
    public class Context : BMessage, IContext {
        internal readonly IEntity _variables = Prior.CreateEntity();

        public Context(Batch batch, IScript script, IMessage? parent = null, ILogger? logger = null) : base(parent, logger) {
            Batch = batch;
            Script = script;
            Variables = new VarEnt(this);
        }
        public BSet ReadonlyVariables { get; } = Prior.CreateSortedBSet();
        public IEntity Variables { get; }

        public Batch Batch { get; }
        public IScript Script { get; }

        protected bool OnTryGetVariable(BID name, out object? value)
            => _variables.TryGetValue(name, out value);
        protected bool OnTrySetVariable(BID name, object? value) {
            if (ReadonlyVariables.Find(name, out _)) return false;
            if (_variables.TrySetValue(name, value)) return true;
            if (Parent is IContext pContext) return pContext.Variables.TrySetValue(name, value);
            return false;
        }
        sealed class VarEnt : IEntity, IEnumerable<Unit> {
            private readonly Context _context;
            private readonly IEntity _variable;

            public VarEnt(Context context) {
                _context = context;
                _variable = _context._variables;
            }

            public bool IsEmpty => _variable.IsEmpty;
            public IReadonlyBSet Names => _variable.Names;

            public bool TryGetValue(BID bid, out object? value)
                => _context.OnTryGetVariable(bid, out value);
            public bool TrySetValue(BID bid, object? value)
                => _context.OnTrySetVariable(bid, value);
            public bool TryRemoveValue(BID bid) => _variable.TryRemoveValue(bid);
            public bool Clear() => _variable.Clear();

            IEnumerator<Unit> IEnumerable<Unit>.GetEnumerator() => _variable.GetUnits().GetEnumerator();
            IEnumerator IEnumerable.GetEnumerator() => _variable.GetUnits().GetEnumerator();
        }
    }
}
