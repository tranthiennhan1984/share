﻿namespace Binean.Foundation.Storage {
    [Avatar]
    public sealed class TenReader : Reader {
        public readonly TenLexer _lexer;

        public TenReader(ICharacterInput reader, Action? disposedAction = null) {
            var rootToken = new Token(NodeType.Array);
            _lexer = new TenLexer(reader);
            Ordered = false;
            _lexer.MoveNext();
            Initialize(rootToken, _lexer.IsEnd ? ReadEof : ReadItem, disposedAction);
        }

        [AvatarProperty]
        public string? Location {
            get { return _lexer.Location; }
            set { _lexer.Location = value; }
        }

        [AvatarProperty]
        public object Position => _lexer.Position;

        private Token ReadItem(TokenResolve resolve, ref Serialize serialize, Token block) {
            var blockType = block.Type;
            BID propName = BID.Nothing;
            var cls = Dummy.NameList;
            while (true) {
                var symbol = _lexer.Current;
                var type = symbol.Type;

                if (type == CenSymbol.Name) {
                    _lexer.MoveNext();
                    propName = (BID)symbol.Tag!;
                    continue;
                }

                if (type == TenSymbol.String || type == TenSymbol.Identifier) {
                    var text = symbol.Text;
                    _lexer.MoveNext();
                    if (propName.IsNothing && blockType.IsObject()) return block.NewToken(NodeType.Value, null, (BID)text);
                    return block.NewToken(NodeType.Value, text, propName).AddClass(cls);
                }

                if (type == TenSymbol.LBRACE) {
                    _lexer.MoveNext();
                    return block.NewToken(NodeType.Object, null, propName).AddClass(cls);
                }

                if (type == TenSymbol.RBRACE) {
                    if (blockType.IsArray()) throw _lexer.ExpectedCharacter(']');
                    _lexer.MoveNext();
                    return block.EndToken();
                }

                if (type == TenSymbol.LSQBRACKET) {
                    _lexer.MoveNext();
                    return block.NewToken(NodeType.Array, null, propName).AddClass(cls);
                }

                if (type == TenSymbol.RSQBRACKET) {
                    if (blockType.IsObject()) throw _lexer.ExpectedCharacter('}');
                    _lexer.MoveNext();
                    return block.EndToken();
                }

                if (type == TenSymbol.COMMA) {
                    _lexer.MoveNext();
                    if (propName.IsNothing) continue;
                    return block.NewToken(NodeType.Value, null, propName).AddClass(cls);
                }

                if (type == TenSymbol.Number
                    || type == TenSymbol.Null
                    || type == TenSymbol.Boolean
                    || type == TenSymbol.Blob
                    ) {
                    _lexer.MoveNext();
                    return block.NewToken(NodeType.Value, symbol.Tag, propName);
                }

                if (type == TenSymbol.Class) {
                    _lexer.MoveNext();
                    cls = Prior.CreateUniqueBList().ReadBids(symbol.Text);
                    continue;
                }

                if (type == TenSymbol.Context) {
                    _lexer.MoveNext();
                    return block.AddItem(new Token(NodeType.Value, Prior.CreateSortedEntity().Set(TokenProperties.SysType, symbol.Tag?.As<Type>() ?? symbol.Tag), symbol.Text).PSet(TokenProperties.Context, true));
                }
                if (type == TenSymbol.AContext) {
                    _lexer.MoveNext();
                    return block.AddItem(new Token(NodeType.Value, Prior.CreateSortedEntity().Set(TokenProperties.SysType, symbol.Tag?.As<Type>() ?? symbol.Tag), symbol.Text).PSet(TokenProperties.Context, true).PSet(TokenProperties.Append, true));
                }
                if (type == TenSymbol.BContext) {
                    _lexer.MoveNext();
                    return block.AddItem(new Token(NodeType.Object, null, symbol.Text).PSet(TokenProperties.Context, true));
                }
                if (type == TenSymbol.BAContext) {
                    _lexer.MoveNext();
                    return block.AddItem(new Token(NodeType.Object, null, symbol.Text).PSet(TokenProperties.Context, true).PSet(TokenProperties.Append, true));
                }

                if (type == TenSymbol.Template) {
                    _lexer.MoveNext();
                    return block.AddItem(CreateTemplateToken(ref serialize, (symbol.Tag as Template)!, propName)).AddClass(cls);
                }

                if (type == TenSymbol.Comment) {
                    _lexer.MoveNext();
                    continue;
                }

                if (type == TenSymbol.Ordered) {
                    _lexer.MoveNext();
                    if (symbol.Tag is bool ordered) {
                        return block.AddItem(new Token(NodeType.Value, ordered, TokenProperties.Ordered).PSet(TokenProperties.Context, true));
                    }
                    continue;
                }

                if (symbol == Symbol.Eof) return ReadEof(resolve, ref serialize, block);

                throw _lexer.InvalidSymbol(_lexer.Current);
            }
        }
        private Token CreateTemplateToken(ref Serialize serialize, Template template, BID name) {
            var value = template.Read(TemplateArgs);
            if (value is null) return new Token(NodeType.Value, value, name);
            if (Men.Serialize(value, true) is not Reader reader) return new Token(NodeType.Value, value, name);
            return new ReaderToken(ref serialize, reader, name, false);
        }
    }
}
