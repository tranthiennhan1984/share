﻿using System.Runtime.CompilerServices;


namespace Binean.Foundation.Storage {
    public sealed class Cen(BID name) : ICharacterFormat, IStreamFormat {
        public BID Name { get; private set; } = name;

        Reader? IFormat.Serialize(object? data, IGetter? config)
            => Serialize(data).TryConfigure(config);
        Writer? IFormat.Deserialize(object? data, IGetter? config)
            => Deserialize(data).TryConfigure(config);

        Reader? ICharacterFormat.Serialize(ICharacterInput input, IGetter? config)
            => Serialize(input, true).TryConfigure(config);
        Writer? ICharacterFormat.Deserialize(BTextWriter output, IGetter? config)
            => Deserialize(output, true).TryConfigure(config);

        Reader? IStreamFormat.Serialize(Stream stream, IGetter? config)
            => Serialize(stream.CreateTextReader(true)).TryConfigure(config);
        Writer? IStreamFormat.Deserialize(Stream stream, IGetter? config)
            => Deserialize(stream.CreateTextWriter(true)).TryConfigure(config);


        public static CenReader? Serialize(object? data) {
            if (data is ICharacterInput input) return Serialize(input, true);
            if (data is null || data.CreateTextReader() is not ICharacterInput ci) return null;
            return Serialize(ci);
        }
        public static CenWriter? Deserialize(object? data = null) {
            if (data is null) {
                var st = new StringWriter();
                return new CenWriter(st.CreateTextWriter(true), st.Dispose, w => {
                    st.Flush();
                    w.SetContent(st.GetStringBuilder().ToString());
                    st.Dispose();
                });
            }

            if (data is BTextWriter w) return Deserialize(w, true);
            if (data.CreateTextWriter() is not BTextWriter tw) return null;
            return Deserialize(tw).SetContent(data);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static CenReader Serialize(ICharacterInput reader, bool leaveOpen = false)
            => new(reader, leaveOpen ? null : reader.Dispose);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static CenWriter Deserialize(BTextWriter writer, bool leaveOpen = false)
            => new(writer, leaveOpen ? null : writer.Dispose);

        public static string ToString(Reader reader, IGetter? config = null) {
            using (var writer = Deserialize()!.TryConfigure(config)) {
                writer.Write(reader);
                return (string)writer.GetContent()!;
            }
        }
    }
}