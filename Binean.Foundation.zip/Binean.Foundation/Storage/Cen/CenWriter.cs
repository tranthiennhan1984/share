﻿using Binean.Foundation.Primitive;
using System.Xml.Linq;

namespace Binean.Foundation.Storage {
    [Avatar]
    public sealed class CenWriter : Writer {
        private readonly BTextWriter _writer;
        private Action<CenWriter>? _close;
        private readonly BSet _defined = Prior.CreateSortedBSet();

        public CenWriter(BTextWriter writer, Action? disposedAction = null, Action<CenWriter>? close = null) {
            _content = writer;
            _close = close;
            var rootNode = new Node(NodeType.Array);
            _writer = writer;
            var deserialize = new Deserialize(WriteItem);
            if (_close != null) {
                if (disposedAction is null) disposedAction = Close;
                else {
                    var cur = disposedAction;
                    disposedAction = () => {
                        Close();
                        cur();
                    };
                }
            }
            Initialize(rootNode, deserialize, disposedAction);
        }

        [AvatarProperty]
        public string? Location {
            get => _writer.Location;
            set => _writer.Location = value;
        }

        [AvatarProperty]
        public bool Decorate {
            get => _writer.Decorate;
            set => _writer.Decorate = value;
        }

        [AvatarProperty]
        public int IndentOffset {
            get => _writer.IndentOffset;
            set => _writer.IndentOffset = value;
        }

        [AvatarProperty]
        public CenClassType ClassType { get; set; } = CenClassType.AllClassWithNameDefine;

        [AvatarProperty]
        public Entity Defines { get; } = Prior.CreateSortedEntity();

        public override void PrepareContext(Reader reader, IGetter? source = null) {
            base.PrepareContext(reader, source);
            Context.MAssign(Defines);
        }
        protected override void OnWriteContext(Token token) {
            var ordered = Ordered;
            base.OnWriteContext(token);
            if (ordered == Ordered) return;
            WriteOrdered(Ordered, token.Level);
        }
        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            if (block.Level < 0 && token.Type.IsEndBlock()) {
                deserialize = WriteException;
                return block.EndNode();
            }
            if (token.Name == HiddenProperties.ClassNames) return block.AddItem(token.Skip(ref deserialize));

            return WriteItem(_writer, block, token, token.Name);
        }
        public Node WriteItem(BTextWriter _writer, Node block, Token token, BID name, int indentationOffset = 0) {
            var blockType = block.Type;
            if (token.Type.IsEndBlock()) {
                _writer.AssertNewLine(block.Level + indentationOffset, true).Write(blockType.IsArray() ? "]" : "}").EndLine();
                return block.EndNode();
            }

            var indentationLevel = block.Level + indentationOffset + 1;
            if (token.ClassSet() is IReadonlyBSet set && set.Count > 0) {
                if (BuildClass(set, Context, ClassType) is BList list) {
                    WriteClass(_writer, Context, indentationLevel, list, _defined);
                }
            }

            var tokenType = token.Type;
            if (tokenType.IsValue()) {
                _writer.AssertNewLine(indentationLevel);
                if (blockType.IsObject()) {
                    _writer.WriteBID(name).Write(":");
                    if (_writer.Decorate) _writer.Write(" ");
                }

                var value = token.Value;
                if (value is BID bid) _writer.WriteBID(bid).EndLine(',');
                else if (value is byte[] blob) _writer.WriteBlob(blob).EndLine(',');
                else _writer.WriteValue(value).EndLine(',');
                return block.AddItem(new Node(tokenType, value, token.Name));
            }

            _writer.AssertNewLine(indentationLevel, true);
            if (blockType.IsObject()) {
                _writer.WriteBID(name);
                if (_writer.Decorate) _writer.Write(" ");
            }
            _writer.Write(token.Type.IsObject() ? "{" : "[").EndLine();
            return block.AddItem(new Node(tokenType, DBNull.Value, token.Name));
        }

        private void WriteOrdered(bool ordered, int indentationLevel) {
            _writer.AssertNewLine(indentationLevel);
            _writer.Write(ordered ? "#!-o" : "#!+o").EndLine();
        }

        private static BList? BuildClass(IReadonlyBSet set, IEntity context, CenClassType classType) {
            if (classType == CenClassType.None) return null;

            static BID? ClassInContext(BID name, IEntity context) {
                if (context.Get(name) is not IGetter info) return null;
                return info.Get(HiddenProperties.ClassName) is BID clsName ? clsName : name;
            }
            static BID? AllClassWithoutDefine(BID name, IEntity context) {
                if (context.Get(name) is IGetter info && info.Get(HiddenProperties.ClassName) is BID clsName) return clsName;
                return name;
            }
            static BID? AllClassWithTypeDefine(BID name, IEntity context) {
                if (context.Get(name) is IGetter info) {
                    if (info.Get(HiddenProperties.ClassName) is BID clsName) return clsName;
                    return name;
                }

                if (name.ToType() is not Type type) return null;
                context.DefineSysType(type);
                return name;
            }
            static BID? AllClassWithNameDefine(BID name, IEntity context) {
                if (context.Get(name) is IGetter info) {
                    if (info.Get(HiddenProperties.ClassName) is BID clsName) return clsName;
                    return name;
                }

                if (name.ToType() is not Type type) return null;
                context.DefineSysType(type, name = type.Name);
                return name;
            }
            var getter = classType switch {
                CenClassType.AllClassWithTypeDefine => new Func<BID, IEntity, BID?>(AllClassWithTypeDefine),
                CenClassType.AllClassWithNameDefine => new Func<BID, IEntity, BID?>(AllClassWithNameDefine),
                CenClassType.AllClassWithoutDefine => AllClassWithoutDefine,
                _ => ClassInContext,
            };

            var retVal = Prior.CreateUniqueBList();
            foreach (var name in set) {
                if (getter(name, context) is not BID item) return null;
                retVal.Add(item);
            }
            return retVal;
        }
        private static void WriteClass(BTextWriter writer, IEntity context, int indentationLevel, IReadonlyBSet set, BSet defined) {
            static void WriteDefine(BTextWriter writer, IEntity context, BID item) {
                if (!context.TryGetNotNull(item, out IGetter? info)) throw new InvalidOperationException();
                if (info.Get(HiddenProperties.SysType) is not Type type) return;
                writer.Write($"#${item.ToText()}:{type.To<string>()}").EndLine();
            }
            foreach (var name in set) {
                if (defined.Find(name, out _)) continue;
                writer.AssertNewLine(indentationLevel);
                WriteDefine(writer, context, name);
                defined.Add(name);
            }

            writer.AssertNewLine(indentationLevel);
            writer.Write("#@").Write(new StringWriter().WriteBids(set).ToString()!).EndLine();
        }

        protected override void Close() {
            if (_close is null) return;
            _close(this);
            CanContinue = false;
            _close = null;
        }
    }
    public enum CenClassType {
        None = 0,
        ClassInContext,
        AllClassWithoutDefine,
        AllClassWithTypeDefine,
        AllClassWithNameDefine,
    }
}
