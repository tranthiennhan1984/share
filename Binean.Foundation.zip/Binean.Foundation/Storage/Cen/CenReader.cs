﻿namespace Binean.Foundation.Storage {
    [Avatar]
    public class CenReader : Reader {
        public readonly CenLexer _lexer;

        public CenReader(ICharacterInput reader, Action? disposedAction = null, NodeType beginType = NodeType.Array) {
            var rootToken = new Token(beginType);
            _lexer = new CenLexer(reader);
            Ordered = false;
            _lexer.MoveNext();
            Initialize(rootToken, _lexer.IsEnd ? ReadEof : ReadItem, disposedAction);
        }

        [AvatarProperty]
        public string? Location {
            get { return _lexer.Location; }
            set { _lexer.Location = value; }
        }

        [AvatarProperty]
        public object Position => _lexer.Position;

        private Token ReadItem(TokenResolve resolve, ref Serialize serialize, Token block) {
            var blockType = block.Type;
            BID propName = BID.Nothing;
            var cls = Dummy.NameList;
            while (true) {
                var symbol = _lexer.Current;
                var type = symbol.Type;

                if (type == CenSymbol.Name) {
                    _lexer.MoveNext();
                    propName = (BID)symbol.Tag!;
                    continue;
                }

                if (type == CenSymbol.String || type == CenSymbol.Identifier) {
                    var text = symbol.Text;
                    _lexer.MoveNext();
                    if (propName.IsNothing && blockType.IsObject()) return block.NewToken(NodeType.Value, null, (BID)text);
                    return block.NewToken(NodeType.Value, text, propName).AddClass(cls);
                }

                if (type == CenSymbol.LBRACE) {
                    _lexer.MoveNext();
                    return block.NewToken(NodeType.Object, null, propName).AddClass(cls);
                }

                if (type == CenSymbol.RBRACE) {
                    if (blockType.IsArray()) throw _lexer.ExpectedCharacter(']');
                    _lexer.MoveNext();
                    return block.EndToken();
                }

                if (type == CenSymbol.LSQBRACKET) {
                    _lexer.MoveNext();
                    return block.NewToken(NodeType.Array, null, propName).AddClass(cls);
                }

                if (type == CenSymbol.RSQBRACKET) {
                    if (blockType.IsObject()) throw _lexer.ExpectedCharacter('}');
                    _lexer.MoveNext();
                    return block.EndToken();
                }

                if (type == CenSymbol.COMMA) {
                    _lexer.MoveNext();
                    if (propName.IsNothing) continue;
                    return block.NewToken(NodeType.Value, null, propName);
                }

                if (type == CenSymbol.Number
                    || type == CenSymbol.Null
                    || type == CenSymbol.Boolean
                    || type == CenSymbol.Blob) {
                    _lexer.MoveNext();
                    return block.NewToken(NodeType.Value, symbol.Tag, propName);
                }

                if (type == CenSymbol.Class) {
                    _lexer.MoveNext();
                    cls = Prior.CreateUniqueBList().ReadBids(symbol.Text);
                    continue;
                }

                if (type == CenSymbol.Context) {
                    _lexer.MoveNext();
                    return block.AddItem(new Token(NodeType.Value, Prior.CreateSortedEntity().Set(TokenProperties.SysType, symbol.Tag?.As<Type>() ?? symbol.Tag), symbol.Text).PSet(TokenProperties.Context, true));
                }
                if (type == CenSymbol.AContext) throw _lexer.InvalidSymbol(_lexer.Current);
                if (type == CenSymbol.BContext) throw _lexer.InvalidSymbol(_lexer.Current);
                if (type == CenSymbol.BAContext) throw _lexer.InvalidSymbol(_lexer.Current);

                if (type == CenSymbol.Comment) {
                    _lexer.MoveNext();
                    continue;
                }

                if (type == CenSymbol.Ordered) {
                    _lexer.MoveNext();
                    if (symbol.Tag is bool ordered) {
                        Ordered = ordered;
                        return block.AddItem(new Token(NodeType.Value, Ordered, TokenProperties.Ordered).PSet(TokenProperties.Context, true));
                    }
                    continue;
                }

                if (symbol == Symbol.Eof) return ReadEof(resolve, ref serialize, block);

                throw _lexer.InvalidSymbol(_lexer.Current);
            }
        }
    }
}
