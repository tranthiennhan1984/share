﻿namespace Binean.Foundation.Storage {
    [Avatar]
    public sealed class CenLexer : IInput<Symbol> {

        private readonly ICharacterInput _reader;
        public CenLexer(ICharacterInput reader) {
            _reader = reader;
            _reader.IsWhitespace = Json.IsWhitespace;
        }

        [AvatarProperty]
        public string? Location {
            get { return _reader.Location; }
            set { _reader.Location = value; }
        }

        [AvatarProperty]
        public object Position => _reader.Position;

        public Symbol Current { get; private set; } = Symbol.None;
        public bool IsEnd => Current == Symbol.Eof;
        public void MoveNext() {
            if (Current == Symbol.Eof) return;
            Current = Read();
        }
        public Symbol Read() {
            while (true) {
                var chr = _reader.SkipWhitespaces();

                switch (chr) {
                    case '{':
                        _reader.MoveNext();
                        return new Symbol(CenSymbol.LBRACE, chr.ToString());
                    case '}':
                        _reader.MoveNext();
                        return new Symbol(CenSymbol.RBRACE, chr.ToString());
                    case '[':
                        _reader.MoveNext();
                        return new Symbol(CenSymbol.LSQBRACKET, chr.ToString());
                    case ']':
                        _reader.MoveNext();
                        return new Symbol(CenSymbol.RSQBRACKET, chr.ToString());

                    case ',':
                        _reader.MoveNext();
                        return new Symbol(CenSymbol.COMMA, chr.ToString());

                    case ':':
                        throw _reader.InvalidCharacter(chr);

                    case '\'':
                    case '"':
                        return _reader.ReadStringSymbol().CheckIfCenName(_reader);

                    case '(':
                        var bid = _reader.ReadBID();
                        if (_reader.SkipWhitespaces() == ':') _reader.MoveNext();
                        return new Symbol(CenSymbol.Name, bid.ToString()) { Tag = bid };

                    case '-':
                        return _reader.ReadNumberSymbol();

                    case '@':
                        _reader.MoveNext();
                        if ("[{".Contains(chr = _reader.Current)) return _reader.ReadBlobSymbol();
                        if (Prior.IsIdentifierCharacter(chr)) return _reader.ReadIdentifierSymbol().CheckIfCenName(_reader).ToCodeID();
                        throw _reader.InvalidCharacter(chr);

                    case '#':
                        _reader.MoveNext();
                        if (_reader.Current == '!') return _reader.ReadOrderedSymbol();
                        if (_reader.Current == '@') return _reader.ReadClassSymbol();
                        if (_reader.Current == '$') return _reader.ReadContextSymbol();
                        return new Symbol(CenSymbol.Comment, _reader.ReadUntil(endCond: "\r\n\0".Contains));

                    case Prior.EofCharacter: return Symbol.Eof;
                }

                if (char.IsDigit(chr)) return _reader.ReadNumberSymbol();
                if (Prior.IsIdentifierCharacter(chr)) return _reader.ReadIdentifierSymbol().CheckIfCenName(_reader);
                throw _reader.InvalidCharacter(chr);
            }
        }
    }
    internal static class CenSymbol {
        public static readonly BID COMMA = nameof(COMMA);
        public static readonly BID LSQBRACKET = nameof(LSQBRACKET);
        public static readonly BID RSQBRACKET = nameof(RSQBRACKET);
        public static readonly BID LBRACE = nameof(LBRACE);
        public static readonly BID RBRACE = nameof(RBRACE);

        public static readonly BID Identifier = nameof(Identifier);
        public static readonly BID String = nameof(String);
        public static readonly BID Number = nameof(Number);
        public static readonly BID Boolean = nameof(Boolean);
        public static readonly BID Null = nameof(Null);
        public static readonly BID Blob = nameof(Blob);

        public static readonly BID Name = nameof(Name);
        public static readonly BID Comment = nameof(Comment);
        public static readonly BID Class = nameof(Class);

        public static readonly BID Context = nameof(Context);
        public static readonly BID AContext = nameof(AContext);
        public static readonly BID BContext = nameof(BContext);
        public static readonly BID BAContext = nameof(BAContext);

        public static readonly BID Ordered = nameof(Ordered);
    }
}
