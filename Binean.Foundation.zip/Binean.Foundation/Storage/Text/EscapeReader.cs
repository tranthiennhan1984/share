﻿using System.Globalization;
using System.Text;

namespace Binean.Foundation.Storage {
    [Avatar]
    public sealed class EscapeReader : ICharacterInput {

        private bool _isDiposed = false;
        private readonly ICharacterInput _reader;
        private readonly EscapeContext _escape;

        char _escapeCharacter = Prior.EofCharacter;
        public EscapeReader(ICharacterInput reader, EscapeContext context) {
            if (reader is EscapeReader) throw new NotSupportedException();
            _reader = reader;
            _escape = context;
        }
        void IDisposable.Dispose() {
            if (_isDiposed) throw new InvalidOperationException();
            _isDiposed = true;
            if (HasEscape) {
                _reader.PeekChar = _escape.StartChar;
            }
        }

        public bool HasEscape { get; private set; }

        [AvatarProperty(WriteSkip = true)]
        public object Position => _reader.Position;
        [AvatarProperty]
        public string? Location {
            get => _reader.Location;
            set => _reader.Location = value;
        }
        public Func<char, bool> IsWhitespace {
            get => _reader.IsWhitespace;
            set => _reader.IsWhitespace = value;
        }
        public char Current {
            get {
                if (HasEscape) return _escapeCharacter;
                return (HasEscape = OnPeekChar(out char value)) ? (_escapeCharacter = value) : value;
            }
        }
        public bool IsEnd => _reader.IsEnd;

        char ICharacterInput.PeekChar {
            get => _reader.PeekChar;
            set => _reader.PeekChar = value;
        }

        public void MoveNext() {
            if (HasEscape) HasEscape = false;
            else _reader.MoveNext();
        }
        private bool OnPeekChar(out char value) {
            value = _reader.Current;
            if (value != _escape.StartChar) return false;

            _reader.MoveNext();
            value = _reader.Current;
            var index = _escape.EndChars.IndexOf(value);
            if (index >= 0) {
                _reader.MoveNext();
                value = _escape.ReplaceChars[index];
                return true;
            }

            if (!_escape.EscapeUnicode) {
                if (_escape.Guarantee) throw this.InvalidCharacter(value);
                value = _escape.StartChar;
                return false;
            }
            if (value != 'u' && value != 'U') throw this.InvalidCharacter(value);

            _reader.MoveNext();
            var u = new StringBuilder();
            if (char.IsDigit(value = _reader.Current) || "abcdef".IndexOf(char.ToLower(value, CultureInfo.CurrentCulture)) > -1) u.Append(value);
            else throw this.InvalidCharacter(value);

            _reader.MoveNext();
            if (char.IsDigit(value = _reader.Current) || "abcdef".IndexOf(char.ToLower(value, CultureInfo.CurrentCulture)) > -1) u.Append(value);
            else throw this.InvalidCharacter(value);

            _reader.MoveNext();
            if (char.IsDigit(value = _reader.Current) || "abcdef".IndexOf(char.ToLower(value, CultureInfo.CurrentCulture)) > -1) u.Append(value);
            else throw this.InvalidCharacter(value);

            _reader.MoveNext();
            if (char.IsDigit(value = _reader.Current) || "abcdef".IndexOf(char.ToLower(value, CultureInfo.CurrentCulture)) > -1) u.Append(value);
            else throw this.InvalidCharacter(value);

            _reader.MoveNext();
            value = (char)short.Parse(u.ToString(), NumberStyles.HexNumber, CultureInfo.CurrentCulture);
            return true;
        }
    }
}
