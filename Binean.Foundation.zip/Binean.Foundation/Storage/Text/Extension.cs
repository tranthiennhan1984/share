﻿using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text;

namespace Binean.Foundation.Storage {
    public static partial class Extension {

        #region :: Text Reader Writer Helper ::

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T SetContent<T>(this T writer, object? content) where T : Writer {
            writer._content = content;
            return writer;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ICharacterInput CreateTextReader(this string text)
            => CreateTextReader(new StringReader(text));

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ICharacterInput CreateTextReader(this Stream stream, bool leaveOpen = false)
            => CreateTextReader(stream, leaveOpen, Encoding.UTF8);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ICharacterInput CreateTextReader(this Stream stream, bool leaveOpen, Encoding encoding) {
            var str = new StreamReader(stream, encoding, true, 1024, leaveOpen);
            return new BTextReader(str, str.Dispose);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ICharacterInput CreateTextReader(this TextReader textReader, bool leaveOpen = false)
            => new BTextReader(textReader, leaveOpen ? null : textReader.Dispose);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BTextWriter CreateTextWriter(this Stream stream, bool leaveOpen = false)
            => CreateTextWriter(stream, leaveOpen, Encoding.UTF8);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BTextWriter CreateTextWriter(this Stream stream, bool leaveOpen, Encoding encoding) {
            var stw = new StreamWriter(stream, encoding, 1024, leaveOpen);
            return new BTextWriter(stw, stw.Dispose);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BTextWriter CreateTextWriter(this TextWriter textWriter, bool leaveOpen = false)
            => new(textWriter, leaveOpen);

        public static string ReadAll(this ICharacterInput reader) {
            var sb = new StringBuilder();
            while (!reader.IsEnd) {
                sb.Append(reader.Current);
                reader.MoveNext();
            }
            return sb.ToString();
        }
        public static byte[] ReadBlob(this ICharacterInput reader, char begin = '[', char end = ']') {
            if (reader.IsEnd) return [];

            var chr = reader.Current;
            if (begin != Prior.EofCharacter) {
                if (chr != begin) throw reader.InvalidCharacter(chr);
                else reader.MoveNext();
            }//else skip begin

            int value = 0;
            var step = 0;
            using (var stream = new MemoryStream()) {
                while (!reader.IsEnd) {
                    chr = reader.Current;
                    if (chr == end) {
                        reader.MoveNext();
                        stream.Flush();
                        return stream.ToArray();
                    }

                    int i = 0;

                    if (char.IsDigit(chr)) i = chr - 48;
                    else if ((chr = char.ToUpper(chr)) >= 'A' && chr <= 'F') i = chr - 55;
                    else throw reader.InvalidCharacter(chr);

                    if (++step == 1) {
                        value = (byte)(i * 16);
                    } else {
                        value += i;
                        stream.WriteByte((byte)value);
                        step = 0;
                    }
                    reader.MoveNext();
                }
            }
            if (step == 1) throw reader.InvalidCharacter(chr);
            throw reader.ExpectedCharacter(end);
        }
        public static string ReadUntil(this ICharacterInput reader, Func<char, bool>? endCond = null, Func<char, bool>? skipCond = null, Func<char, bool>? errCond = null, char? expected = null) {
            if (endCond is null && skipCond is null && errCond is null && expected is null) throw reader.CreateException(nameof(Logs.BFND5040AE));
            var sb = new StringBuilder();
            while (!reader.IsEnd) {
                var chr = reader.Current;
                if (!reader.HasEscape) {
                    if (endCond != null && endCond(chr)) return sb.ToString();
                    if (expected != null && expected == chr) {
                        reader.MoveNext();
                        return sb.ToString();
                    }

                    if (skipCond != null && skipCond(chr)) {
                        reader.MoveNext();
                        return sb.ToString();
                    }
                    if (errCond != null && errCond(chr)) {
                        if (expected != null) throw reader.ExpectedCharacter(expected.Value);
                        else throw reader.InvalidCharacter(chr);
                    }
                }
                sb.Append(chr);
                reader.MoveNext();
            }
            if (endCond != null && endCond(Prior.EofCharacter)) return sb.ToString();
            if (expected != null) throw reader.ExpectedCharacter(expected.Value);
            else throw reader.InvalidCharacter(Prior.EofCharacter);
        }
        public static string ReadWhile(this ICharacterInput reader, Func<char, bool> condition) {
            var sb = new StringBuilder();
            while (!reader.IsEnd) {
                char chr = reader.Current;
                if (!reader.HasEscape && !condition(chr)) break;
                sb.Append(chr);
                reader.MoveNext();
            }
            return sb.ToString();
        }
        public static string ReadWhile(this ICharacterInput reader, Func<char, bool>? lastCond = null, Func<char, bool>? endCond = null, Func<char, bool>? errCond = null) {
            if (lastCond is null && endCond is null && errCond is null) throw reader.CreateException(nameof(Logs.BFND50409E));
            var sb = new StringBuilder();
            while (!reader.IsEnd) {
                char chr = reader.Current;
                if (!reader.HasEscape) {
                    if (lastCond != null && lastCond(chr)) { _ = sb.Append(chr); break; }
                    if (endCond != null && endCond(chr)) break;
                    if (errCond != null && errCond(chr)) throw reader.InvalidCharacter(chr);
                }
                sb.Append(chr);
                reader.MoveNext();
            }
            return sb.ToString();
        }
        public static char SkipWhitespaces(this ICharacterInput reader) {
            var isWhitespace = reader.IsWhitespace;
            char chr;
            while (isWhitespace(chr = reader.Current)) {
                if (reader.HasEscape) break;
                reader.MoveNext();
            }
            return chr;
        }
        public static char SkipNewLine(this ICharacterInput reader) {
            char chr;
            while ("\r\n".Contains(chr = reader.Current)) {
                if (reader.HasEscape) break;
                reader.MoveNext();
            }
            return chr;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string? ReadString(this ICharacterInput reader) {
            var chr = reader.Current;
            if (!"\"'".Contains(chr)) return null;
            reader.MoveNext();
            using (var er = new EscapeReader(reader, EscapeContext.StringEscape))
                return er.ReadUntil(expected: chr, errCond: "\r\n".Contains);
        }
        public static Symbol ReadStringSymbol(this ICharacterInput reader) {
            var chr = reader.Current;
            return new Symbol(JsonSymbol.String, reader.ReadString()!) { Tag = chr };
        }

        public static Symbol ReadNumberSymbol(this ICharacterInput reader) {
            var sb = new StringBuilder();
            if (reader.Current == '-') {
                sb.Append('-');
                reader.MoveNext();
            }
            sb.Append(reader.ReadWhile(char.IsDigit));
            if (reader.Current == '.') {
                sb.Append('.');
                reader.MoveNext();
                sb.Append(reader.ReadWhile(char.IsDigit));
                var text = sb.ToString();
                if (text.EndsWith('.')) throw reader.InvalidCharacter(reader.Current);
                return new Symbol(Bebol.Number, text) { Tag = double.Parse(text) };
            } else {
                var text = sb.ToString();
                return new Symbol(Bebol.Number, text) { Tag = int.Parse(text) };
            }
        }
        public static Symbol ReadBlobSymbol(this ICharacterInput reader) {
            var chr = reader.Current;
            if (chr == '[') return new Symbol(Bebol.Blob) { Tag = reader.ReadBlob() };
            if (chr == '{') {
                reader.MoveNext();
                var text = reader.ReadUntil(expected: '}', errCond: "\r\n".Contains);
                return new Symbol(Bebol.Blob) { Tag = text.Base64ToBlob() };
            }
            throw reader.InvalidCharacter(chr);
        }


        public static Symbol CheckIfCenName(this Symbol symbol, ICharacterInput reader) {
            if (reader.SkipWhitespaces() == ':') {
                reader.MoveNext();
                symbol.Type = Bebol.Name;
                symbol.Tag = (BID)symbol.Text;
            }
            if ("{[".Contains(reader.Current)) {
                symbol.Type = Bebol.Name;
                symbol.Tag = (BID)symbol.Text;
            }
            return symbol;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Symbol ToCodeID(this Symbol symbol) {
            symbol.Tag = symbol.Text.ToCodeId();
            return symbol;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string ReadIdentifier(this ICharacterInput reader, Func<char, bool>? isIdentifierCharacter = null)
            => reader.ReadWhile(isIdentifierCharacter ?? Prior.IsIdentifierCharacter);
        public static Symbol ReadIdentifierSymbol(this ICharacterInput reader, bool keywordOnly = false, Func<char, bool>? isIdentifierCharacter = null) {
            var text = reader.ReadIdentifier(isIdentifierCharacter);

            if (string.Compare(text, "true", true) == 0) return new Symbol(Bebol.Boolean, text) { Tag = true };
            if (string.Compare(text, "false", true) == 0) return new Symbol(Bebol.Boolean, text) { Tag = false };
            if (string.Compare(text, "null", true) == 0) return new Symbol(Bebol.Null, text) { Tag = null };

            if (keywordOnly) throw reader.CreateException(nameof(Logs.BFND50405E), text);
            return new Symbol(Bebol.Identifier, text);
        }
        public static Symbol ReadClassSymbol(this ICharacterInput reader) {
            if (reader.Current != '@') throw reader.InvalidCharacter(reader.Current);
            reader.MoveNext();
            return new Symbol(Bebol.Class, reader.ReadUntil(endCond: "\r\n\0".Contains));
        }
        public static Symbol ReadContextSymbol(this ICharacterInput reader) {
            if (reader.Current != '$') throw reader.InvalidCharacter(reader.Current);
            reader.MoveNext();
            var tKey = reader.ReadUntil(endCond: ":{|\r\n\0".Contains);
            bool isAppend = false;
            if (reader.Current == '|') {
                reader.MoveNext();
                isAppend = true;
            }
            if (reader.Current == ':') {
                reader.MoveNext();
                return new Symbol(isAppend ? Bebol.AContext : Bebol.Context, tKey.TrimEnd()) { Tag = reader.ReadUntil(endCond: "\r\n\0".Contains) };
            }
            if (reader.Current == '{') {
                reader.MoveNext();
                return new Symbol(isAppend ? Bebol.BAContext : Bebol.BContext, tKey.TrimEnd());
            }
            return new Symbol(Bebol.Class, tKey);
        }
        public static Symbol ReadTemplateSymbol(this ICharacterInput _reader) {
            var chr = _reader.Current;
            if ("'\"".Contains(chr)) {
                var text = _reader.ReadString()!;
                return new Symbol(Bebol.Template, text) { Tag = new Template(text) };
            }
            if (chr == '{') {
                var text = _reader.ReadWhile(lastCond: c => c == '}')!;
                return new Symbol(Bebol.Template, text) { Tag = new Template(text) };
            }
            throw _reader.InvalidCharacter(chr);
        }
        public static Symbol ReadOrderedSymbol(this ICharacterInput reader) {
            if (reader.Current != '!') throw reader.InvalidCharacter(reader.Current);
            reader.MoveNext();
            var ordered = reader.ReadOrdered(out string text, new Func<char, bool>(chr => throw reader.InvalidCharacter(chr)));
            return new Symbol(Bebol.Ordered, text) { Tag = ordered };
        }
        public static bool ReadOrdered(this ICharacterInput reader, out string text, Func<char, bool> failback) {
            var chr = reader.Current;
            if (!"+-o".Contains(chr)) {
                text = string.Empty;
                return failback(chr);
            }

            var sb = new StringBuilder();
            bool? retVal = null;
            var isOn = false;
            while (true) {
                if (chr == '-') isOn = true;
                else if (chr == '+') isOn = false;
                else if (chr == 'o') {
                    if (isOn) retVal = true;
                    else retVal = false;
                } else break;
                sb.Append(chr);
                reader.MoveNext();
                chr = reader.Current;
            }
            if (retVal == null) {
                text = string.Empty;
                return failback(chr);
            }
            text = sb.ToString();
            return retVal.Value;
        }

        public static TextWriter WriteEscape(this TextWriter writer, string text, EscapeContext escape) {
            var len = text.Length;
            for (var i = 0; i < len; i++) {
                var chr = text[i];
                if ((escape.ReplaceChars.IndexOf(chr) is int index) && index > -1) {
                    writer.Write("\\");
                    writer.Write(escape.EndChars[index]);
                } else {
                    int value = chr;
                    if (escape.AnsiSupport && (value < 32 || value >= 127)) throw LogStorage.CreateError(Logs.BFND50402E, chr);
                    if ((value >= 32 && value <= 256)
                        || (value >= 0x0100 && value <= 0x024F)
                        || (value >= 0x0300 && value <= 0x036F)
                        || (value >= 0x1E00 && value <= 0x1EFF))
                        writer.Write(chr);
                    else {
                        writer.Write("\\u");
                        writer.Write(value.ToString("X", CultureInfo.CurrentCulture).PadLeft(4, '0'));
                    }
                }
            }
            return writer;
        }
        public static TextWriter WriteBID(this TextWriter writer, BID bid) {
            if (bid.IsNothing) return writer;

            if (bid.BIDType == BIDType.Code) {
                writer.Write('@');
                writer.Write(bid.ToString());
                return writer;
            }

            var txt = (string)bid;
            if (bid.IsHiddenName) {
                writer.Write('(');
                writer.WriteEscape(txt, EscapeContext.BidNameEscape);
                writer.Write(')');
                return writer;
            }

            if (IsIdentifier(txt)) {
                writer.Write(txt);
                return writer;
            }

            writer.Write('"');
            writer.WriteEscape(txt, EscapeContext.StringEscape);
            writer.Write('"');
            return writer;
        }
        private static bool IsIdentifier(string name) {
            var length = name.Length;
            for (int i = 0; i < length; i++) {
                var chr = name[i];
                if (Prior.IsIdentifierCharacter(chr)) continue;
                return false;
            }
            return true;
        }

        public static BID ReadBID(this ICharacterInput reader) {
            var chr = reader.Current;
            if ("'\"".Contains(chr)) {
                reader.MoveNext();
                using (var er = new EscapeReader(reader, EscapeContext.StringEscape)) {
                    return (BID)er.ReadUntil(expected: chr, errCond: "\r\n".Contains);
                }
            }

            if (chr == '(') {
                reader.MoveNext();
                using (var er = new EscapeReader(reader, EscapeContext.BidNameEscape))
                    return er.ReadUntil(expected: ')', errCond: "\r\n".Contains).ToHiddenNameId();
            }

            if (chr == '{') {
                reader.MoveNext();
                return reader.ReadUntil(expected: '}', errCond: "\r\n".Contains).ToGuidId();
            }

            if (chr == '@') {
                reader.MoveNext();
                return reader.ReadWhile(Prior.IsIdentifierCharacter).ToCodeId();
            }

            var txt = reader.ReadWhile(Prior.IsIdentifierCharacter);
            if (txt.Length == 0) return BID.Nothing;
            return (BID)txt;
        }
        #endregion
    }
    file static class Bebol {
        public static readonly BID Name = nameof(Name);
        public static readonly BID Identifier = nameof(Identifier);
        public static readonly BID Number = nameof(Number);
        public static readonly BID Boolean = nameof(Boolean);
        public static readonly BID Null = nameof(Null);

        public static readonly BID String = nameof(String);

        public static readonly BID Blob = nameof(Blob);
        public static readonly BID Comment = nameof(Comment);
        public static readonly BID Class = nameof(Class);

        public static readonly BID Context = nameof(Context);
        public static readonly BID AContext = nameof(AContext);
        public static readonly BID BContext = nameof(BContext);
        public static readonly BID BAContext = nameof(BAContext);

        public static readonly BID Template = nameof(Template);
        public static readonly BID Ordered = nameof(Ordered);
    }
}
