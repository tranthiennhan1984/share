﻿using System.Text;

namespace Binean.Foundation.Storage {
    public class Symbol(BID type, string value) {
        public static readonly BID KW_NONE = (BID)"_NONE_";
        public static readonly BID KW_EOF = (BID)"_EOF_";
        public static readonly BID KW_SKIP = (BID)"_SKIP_";

        public static readonly Symbol None = new(KW_NONE);
        public static readonly Symbol Eof = new(KW_EOF);
        public Symbol(BID type) : this(type, string.Empty) { }

        public override string ToString() {
            var sb = new StringBuilder((string)Type);
            if (!string.IsNullOrWhiteSpace(Text)) {
                sb.Append('[').Append(Text);
                if (Tag != null) sb.Append('|').Append(Tag);
                sb.Append(']');
            } else if (Tag != null) sb.Append('[').Append(Tag).Append(']');
            return sb.ToString();
        }
        public BID Type { get; set; } = type;
        public string Text { get; set; } = value;
        public object? Tag { get; set; }
    }
}
