﻿
namespace Binean.Foundation.Storage {
    public struct BTextLocation(int row, int column) : IEquatable<BTextLocation> {
        public static readonly BTextLocation Empty = new(0, 0);

        public override readonly string ToString()
            => $"[{Row + 1}, {Column + 1}]";

        public int Row { get; set; } = row;
        public int Column { get; set; } = column;

        public bool IsEmpty {
            readonly get { return Row == 0 && Column == 0; }
            set {
                if (!value) return;
                Row = 0;
                Column = 0;
            }
        }

        public override readonly int GetHashCode() => Row ^ Column;

        public override readonly bool Equals(object? obj)
            => obj is BTextLocation other && Equals(other);

        public readonly bool Equals(BTextLocation other)
            => Row == other.Row && Column == other.Column;

        public static bool operator ==(BTextLocation left, BTextLocation right) => left.Equals(right);
        public static bool operator !=(BTextLocation left, BTextLocation right) => !left.Equals(right);

    }
}
