﻿namespace Binean.Foundation.Storage {
    public interface ICharacterInput : IInput<char>, IDisposable {
        string? Location { get; set; }
        bool HasEscape { get; }
        Func<char, bool> IsWhitespace { get; set; }
        char PeekChar { get; set; }
    }
}
