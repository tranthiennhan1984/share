﻿namespace Binean.Foundation.Storage {
    public class EscapeContext {
        public static readonly EscapeContext DummyContext = new() {
            StartChar = Prior.EofCharacter,
            EndChars = string.Empty,
            ReplaceChars = string.Empty,
            EscapeUnicode = false
        };
        public static readonly EscapeContext StringEscape = new() {
            StartChar = '\\',
            EndChars = "\"\\bfnrt",
            ReplaceChars = "\"\\\b\f\n\r\t",
            EscapeUnicode = true
        };
        public static readonly EscapeContext BidNameEscape = new() {
            StartChar = '\\',
            EndChars = "\"\\bfnrt()",
            ReplaceChars = "\"\\\b\f\n\r\t()",
            EscapeUnicode = true,
            AnsiSupport = true
        };

        public char StartChar { get; set; }
        public string EndChars { get; set; } = string.Empty;
        public string ReplaceChars { get; set; } = string.Empty;
        public bool EscapeUnicode { get; set; }
        public bool AnsiSupport { get; set; } = false;
        public bool Guarantee { get; set; } = true;

        public EscapeContext Copy(string exEscapeEndChars = "", string exReplaceChars = "", bool? escapeUnicode = null)
            => new() {
                StartChar = StartChar,
                EndChars = EndChars + exEscapeEndChars,
                ReplaceChars = ReplaceChars + exReplaceChars,
                EscapeUnicode = escapeUnicode is null ? EscapeUnicode : escapeUnicode.Value
            };
    }
}
