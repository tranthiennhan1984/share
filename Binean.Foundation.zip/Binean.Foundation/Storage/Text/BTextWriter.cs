﻿using Binean.Foundation.Primitive;

namespace Binean.Foundation.Storage {
    [Avatar]
    public sealed class BTextWriter(TextWriter writer, Action? disposedAction = null, EscapeContext? stringEscape = null, int tabSize = 2) : IDisposable {
        private readonly EscapeContext _stringEscape = stringEscape ?? EscapeContext.StringEscape;
        private readonly string _indentedText = tabSize < 0 ? new string('\t', -tabSize) : tabSize > 0 ? new string(' ', tabSize) : string.Empty;
        private Action? _disposedAction = disposedAction;
        private readonly string _newLine = "\n";
        private bool _isNewLine = true;
        internal TextWriter _textWriter = writer;

        public BTextWriter(TextWriter writer, bool leaveOpen = false, EscapeContext? stringEscape = null, int tabSize = 2)
            : this(writer, leaveOpen ? null : writer.Dispose, stringEscape, tabSize) { }

        public void Dispose() {
            if (_disposedAction != null) {
                _disposedAction();
                _disposedAction = null;
            }
        }

        [AvatarProperty]
        public string? Location { get; set; }

        [AvatarProperty]
        public bool Decorate { get; set; } = true;

        [AvatarProperty]
        public int IndentOffset { get; set; }

        public BTextWriter Write(string text) {
            _textWriter.Write(text);
            _isNewLine = false;
            return this;
        }

        public BTextWriter AssertNewLine(bool force = false) {
            if (_isNewLine || !force) return this;
            if (Decorate) _textWriter.Write(_newLine);
            _isNewLine = true;
            return this;
        }
        public BTextWriter AssertNewLine(int indent, bool force = false) {
            if (!_isNewLine && !force) return this;
            if (!_isNewLine) EndLine();
            if (Decorate) {
                _textWriter.Write(_indentedText.Repeat(indent + IndentOffset));
                _isNewLine = false;
            }
            return this;
        }
        public BTextWriter EndLine(char? undecoratedText = null, char? alwayText = null) {
            if (alwayText != null) _textWriter.Write(alwayText);
            if (Decorate) _textWriter.Write(_newLine);
            else if (undecoratedText != null) _textWriter.Write(undecoratedText);
            _isNewLine = true;
            return this;
        }
        public BTextWriter WriteBlob(byte[] blob, string start = "@{", string end = "}") {
            _isNewLine = false;
            if (blob is null) {
                _textWriter.Write("null");
                return this;
            }
            if (!string.IsNullOrWhiteSpace(start)) _textWriter.Write(start);
            _textWriter.Write(blob.ToBase64());
            if (!string.IsNullOrWhiteSpace(end)) _textWriter.Write(end);
            return this;
        }
        public BTextWriter WriteBID(BID bid) {
            _textWriter.WriteBID(bid);
            return this;
        }
        public BTextWriter WriteValue(object? value) {
            if (value is null) return Write("null");
            if (value is string strValue) return WriteString(strValue);
            if (value is Type tValue) return WriteString(tValue.To<string>());
            if (value is decimal dec) return Write(dec.ToString());
            if (value is double dValue) return Write(dValue.ToString());
            if (value is float fValue) return Write(fValue.ToString());
            if (value is int iValue) return Write(iValue.ToString());
            if (value is long lValue) return Write(lValue.ToString());
            if (value is short sValue) return Write(sValue.ToString());
            if (value is byte bValue) return Write(bValue.ToString());
            if (value is bool blValue) return Write(blValue ? "true" : "false");
            return WriteString(value.ToString());
        }
        public BTextWriter WriteString(string? text, bool inQuote = true, EscapeContext? escapeContext = null) {
            if (text is null) {
                _textWriter.Write("null");
                return this;
            }
            if (inQuote) _textWriter.Write("\"");

            _textWriter.WriteEscape(text, escapeContext ?? _stringEscape);

            if (inQuote) _textWriter.Write("\"");
            _isNewLine = false;
            return this;
        }

        public BTextWriter WriterName(string name) {
            //if (name.IsHiddenName) { }
            if (IsIdentifier(name)) return Write(name);
            return WriteString(name);
        }
        //static bool WriteHidenName(string name) {
        //}
        static bool IsIdentifier(string name) {
            var length = name.Length;
            for (int i = 0; i < length; i++) {
                var chr = name[i];
                if (Prior.IsIdentifierCharacter(chr)) continue;
                return false;
            }
            return true;
        }
    }
}
