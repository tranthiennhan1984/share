﻿using Binean.Private;
using SystemTextReader = System.IO.TextReader;

namespace Binean.Foundation.Storage {
    [Avatar]
    public sealed class BTextReader(SystemTextReader reader, Action? disposedAction = null) : ICharacterInput {

        private Action? _disposedAction = disposedAction;
        private BTextLocation _currentLocation;
        private readonly SystemTextReader _textReader = reader;

        ~BTextReader() {
            Dispose(false);
        }
        public void Dispose() {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        private void Dispose(bool disposing) {
            if (disposing) {
                if (_disposedAction != null) {
                    _disposedAction.Invoke();
                    _disposedAction = null;
                }
            }
        }

        [AvatarProperty(WriteSkip = true)]
        public string? Location { get; set; }
        public bool HasEscape => false;
        [AvatarProperty]
        public bool OverEof { get; set; }

        object IInput<char>.Position => _currentLocation;
        public Func<char, bool> IsWhitespace { get; set; } = char.IsWhiteSpace;
        public char PeekChar { get; set; } = Prior.EofCharacter;
        public char Current {
            get {
                if (!OverEof && IsEnd) return Prior.EofCharacter;
                if (PeekChar != Prior.EofCharacter) return PeekChar;
                var chr = _textReader.Peek();
                if (chr <= 0) {
                    IsEnd = true;
                    return Prior.EofCharacter;
                }
                return Helper.ToChar(chr);
            }
        }
        public bool IsEnd { get; private set; }
        public void MoveNext() {
            if (!OverEof && IsEnd) return;
            var _prevChar = Current;
            if (PeekChar != Prior.EofCharacter) {
                PeekChar = Prior.EofCharacter;
            } else _textReader.Read();

            var chr = Current;
            IsEnd = false;
            if (chr == Prior.EofCharacter) {
                IsEnd = true;
            } else if (chr == '\r') {
                _currentLocation.Row++;
                _currentLocation.Column = 0;
            } else if (chr == '\n' && _prevChar != '\r') {
                _currentLocation.Row++;
                _currentLocation.Column = 0;
            } else {
                _currentLocation.Column++;
            }
        }
    }
}
