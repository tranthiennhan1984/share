﻿namespace Binean.Foundation.Storage {
    public class WriterNode : DesNode {
        private readonly Writer _writer;
        private readonly DesNode _rootNode;
        private int _startLevel;
        private readonly Action? _disposedAction;

        public WriterNode(ref Deserialize deserialize, Writer writer, object? value, NodeType type, BID? name = null, bool leaveOpen = false, DesNode? rootNode = null)
            : base(deserialize, type, name) {
            _writer = writer;
            _disposedAction = leaveOpen ? null : _writer.Dispose;
            _rootNode = rootNode ?? this;

            writer.Write(new Token(type, value, name));
            deserialize = WriteBegin;
        }

        protected virtual Node WriteBegin(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            _startLevel = token.Level;
            deserialize = WriteItem;
            return WriteItem(resolve, ref deserialize, block, token);
        }

        protected virtual Node WriteEnd(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            _disposedAction?.Invoke();
            return _rootNode.WriteEndBlock(resolve, ref deserialize, block, token);
        }
        protected virtual Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            var tokenType = token.Type;
            if (tokenType.IsEndBlock() && block == _rootNode) {
                return WriteEnd(resolve, ref deserialize, block, token);
            }
            var newToken = new Token(tokenType, token.Value, token.Name)
                .UpdateLevelIndex(token.Level - _startLevel, token.Index);
            _writer.Write(newToken);
            return block.AddItem(new Node(newToken.Potential));
        }
    }
}
