﻿using Binean.Private;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text;

namespace Binean.Foundation.Storage {
    [Avatar]
    public sealed class BenReader : Reader {

        private readonly Stream _reader;
        private int _current = -1;
        private readonly Dictionary<int, BID> _properties = [];

        public BenReader(Stream reader, Action? disposedAction = null) {
            var rootToken = new Token(NodeType.Array);
            _reader = reader;
            Initialize(rootToken, !_reader.CanRead ? ReadEof : ReadContainer, disposedAction);
        }

        [AvatarProperty]
        public string? Location { get; set; }

        [AvatarProperty]
        public int Position { get; private set; }
        public bool IsEnd { get; private set; }

        internal int MoveNext() {
            if (IsEnd) return -1;
            Position++;
            _current = -1;
            return Peek();
        }
        private int Peek() {
            if (_current != -1) return _current;
            if (IsEnd) return _current = -1;

            _current = _reader.ReadByte();
            IsEnd = _current == -1;
            return _current;
        }

        private byte[] Read(int length) {
            var retVal = new byte[length];
            var offset = _current == -1 ? 0 : 1;
            var count = length - offset;
            if (count > 0 && _reader.Read(retVal, offset, count) != count) {
                throw this.CreateException(nameof(Logs.BFND50101E));
            }
            if (_current != -1) {
                retVal[0] = (byte)_current;
                _current = -1;
            }
            Position += length;
            return retVal;
        }

        internal object? ReadValue(BenDataTypes dataType) {
            return dataType switch {
                BenDataTypes.Text => Encoding.UTF8.GetString(Read(Read(1)[0])),
                BenDataTypes.String => Encoding.UTF8.GetString(Read(BitConverter.ToInt16(Read(2), 0))),
                BenDataTypes.Utf8 => Encoding.UTF8.GetString(Read(BitConverter.ToInt32(Read(4), 0))),
                BenDataTypes.Int32 => BitConverter.ToInt32(Read(4), 0),
                BenDataTypes.Float64 => BitConverter.ToDouble(Read(8), 0),
                BenDataTypes.Float32 => BitConverter.ToSingle(Read(4), 0),
                BenDataTypes.Int64 => BitConverter.ToInt64(Read(8), 0),
                BenDataTypes.True => true,
                BenDataTypes.False => false,
                BenDataTypes.Null => null,
                BenDataTypes.ASCII => BitConverter.ToChar(Read(1), 0),
                BenDataTypes.Int8 => ToSByte(Read(1)[0]),
                BenDataTypes.Uint8 => Convert.ToByte(Read(1)[0]),
                BenDataTypes.Int16 => BitConverter.ToInt16(Read(2), 0),
                BenDataTypes.Blob => Read(ReadInteger()),
                _ => throw this.CreateException(nameof(Logs.BFND50104E), dataType),
            };
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static sbyte ToSByte(byte value)
            => (sbyte)(value - sbyte.MinValue);

        private object? ReadValue() {
            var dataType = PeekDataType();
            MoveNext();
            return ReadValue(dataType);
        }

        private int ReadInteger() {
            var dataType = PeekDataType();
            MoveNext();
            return ReadInteger(dataType);
        }
        private int ReadInteger(BenDataTypes dataType) {
            return dataType switch {
                BenDataTypes.Int8 => ToSByte(Read(1)[0]),
                BenDataTypes.Uint8 => Convert.ToByte(Read(1)[0]),
                BenDataTypes.Int16 => BitConverter.ToInt16(Read(2), 0),
                BenDataTypes.Int32 => BitConverter.ToInt32(Read(4), 0),
                _ => throw this.CreateException(nameof(Logs.BFND50102E))
            };
        }

        private string ReadString() {
            var dataType = PeekDataType();
            MoveNext();
            return dataType switch {
                BenDataTypes.ASCII => BitConverter.ToChar(Read(1), 0).ToString(CultureInfo.CurrentCulture),
                BenDataTypes.Text => Encoding.UTF8.GetString(Read(Read(1)[0])),
                BenDataTypes.String => Encoding.UTF8.GetString(Read(BitConverter.ToInt16(Read(2), 0))),
                BenDataTypes.Utf8 => Encoding.UTF8.GetString(Read(BitConverter.ToInt16(Read(4), 0))),
                _ => throw this.CreateException(nameof(Logs.BFND50103E)),
            };
        }

        private BenDataTypes PeekDataType() => Peek().ToEnum(BenDataTypes.None);
        internal BenPunctuator PeekPunctuator() => Peek().ToEnum(BenPunctuator.None);

        private Token ReadContainer(TokenResolve resolve, ref Serialize serialize, Token block) {
            var punctuator = PeekPunctuator();
            if (punctuator == BenPunctuator.EOF) {
                MoveNext();
                return ReadEof(resolve, ref serialize, block);
            }
            serialize = ReadEof;
            return ReadItem(resolve, ref serialize, block);
        }
        private Token ReadItem(TokenResolve resolve, ref Serialize serialize, Token block) {
            Debug.Assert(resolve != null);
            return InReadItem(ref serialize, block);
        }
        private Token InReadItem(ref Serialize serialize, Token block) {
            BID cls = BID.Nothing;
            BID propName = BID.Nothing;
            int propertyId;
            //string? text;
            BenDataTypes itemType = BenDataTypes.None;
            while (true) {
                var punctuator = PeekPunctuator();
                switch (punctuator) {
                    case BenPunctuator.BeginObject:
                        MoveNext();
                        return block.AddItem(new BenToken(this, ref serialize, true, propName)).AddClass(cls);

                    case BenPunctuator.BeginArray:
                        MoveNext();
                        punctuator = PeekPunctuator();
                        if (punctuator == BenPunctuator.ItemType) {
                            MoveNext();
                            itemType = PeekDataType();
                            MoveNext();
                            return block.AddItem(new BenStoken(this, ref serialize, itemType, propName));
                        }
                        return block.AddItem(new BenToken(this, ref serialize, false, propName)).AddClass(cls);

                    case BenPunctuator.Class:
                        MoveNext();
                        cls = (BID)ReadString();
                        continue;

                    case BenPunctuator.PropertyName:
                        MoveNext();
                        propertyId = ReadInteger(BenDataTypes.Int8);
                        propName = (BID)ReadString();
                        _properties[propertyId] = propName;
                        continue;
                    case BenPunctuator.PropertyName_16:
                        MoveNext();
                        propertyId = ReadInteger(BenDataTypes.Int16);
                        propName = (BID)ReadString();
                        _properties[propertyId] = propName;
                        continue;
                    case BenPunctuator.PropertyName_32:
                        MoveNext();
                        propertyId = ReadInteger(BenDataTypes.Int32);
                        propName = (BID)ReadString();
                        _properties[propertyId] = propName;
                        continue;

                    case BenPunctuator.PropertyId:
                        MoveNext();
                        propertyId = ReadInteger(BenDataTypes.Int8);
                        propName = _properties[propertyId];
                        continue;
                    case BenPunctuator.PropertyId_16:
                        MoveNext();
                        propertyId = ReadInteger(BenDataTypes.Int16);
                        propName = _properties[propertyId];
                        continue;
                    case BenPunctuator.PropertyId_32:
                        MoveNext();
                        propertyId = ReadInteger(BenDataTypes.Int32);
                        propName = _properties[propertyId];
                        continue;
                    case BenPunctuator.Ordered:
                        MoveNext();
                        Ordered = PeekDataType() == BenDataTypes.True;
                        MoveNext();
                        continue;

                    case BenPunctuator.EOF:
                    case BenPunctuator.EndObject:
                    case BenPunctuator.EndArray:
                    case BenPunctuator.ItemType:
                        throw this.CreateException(nameof(Logs.BFND50105E), punctuator);
                }

                return block.NewToken(NodeType.Value, ReadValue(), propName).AddClass(cls);
            }
        }
        protected override Token OnTokenResolve(TokenResolve resolve, ref Serialize serialize, Token block, Token unit)
            => InReadItem(ref serialize, block);
    }
}
