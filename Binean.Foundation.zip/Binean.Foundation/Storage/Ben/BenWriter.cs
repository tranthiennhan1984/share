﻿using Binean.Private;
using System.Runtime.CompilerServices;
using System.Text;

namespace Binean.Foundation.Storage {
    [Avatar]
    public sealed class BenWriter : Writer {
        private readonly Dictionary<string, int> _map = [];
        private readonly Stream _stream;
        private Action<BenWriter>? _close;

        public BenWriter(Stream stream, Action? disposedAction = null, Action<BenWriter>? close = null) {
            _content = _stream = stream;
            _close = close;
            var rootNode = new Node(NodeType.Array);

            if (_close != null) {
                if (disposedAction is null) disposedAction = Close;
                else {
                    var act = disposedAction;
                    disposedAction = () => {
                        Close();
                        act();
                    };
                }
            }

            Initialize(rootNode, WriteContainer, disposedAction);
        }

        [AvatarProperty]
        public string? Location { get; set; }

        [AvatarProperty]
        public int Position { get; private set; }

        private Node WriteContainer(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            if (token.IsDummy) return WriteEof(resolve, ref deserialize, block, token);
            deserialize = WriteEof;
            return WriteItem(block, token, ref deserialize);
        }
        internal Node WriteItem(Node block, Token token, ref Deserialize deserialize) {
            var value = token.Value;

            //if (token.ClassNames.Convert<string>() is string clatypeName) {
            //    Write(BenPunctuator.Class).WriteString(clatypeName);
            //}

            var name = (string)token.Name;
            if (!string.IsNullOrWhiteSpace(name)) {
                if (!_map.TryGetValue(name, out int id)) {
                    id = _map.Count;
                    _map[name] = id;
                    WritePropertyName(id, name);
                } else WritePropertyId(id);
            }
            var tokenType = token.Type;
            if (tokenType.IsValue()) {
                WriteValue(value);
                return block.AddItem(new Node(tokenType, value, token.Name));
            }

            if (token.Type.IsObject()) return block.AddItem(new BenNode(this, ref deserialize, true, name));

            token.AssertTokenType(NodeType.Array);
            //if (GetSameType(token.ClassNames?.ToType()) is BenDataTypes sType) {

            //}
            return block.AddItem(new BenNode(this, ref deserialize, false, name));
        }

        internal BenWriter Write(BenDataTypes type) => Write([(byte)type]);
        private BenWriter Write(byte value) => Write([value]);
        private BenWriter Write(byte[] buffer) {
            _stream.Write(buffer, 0, buffer.Length);
            Position += buffer.Length;
            return this;
        }

        private BenWriter WriteValue(object? value) {
            if (value is null) return Write(BenDataTypes.Null);
            if (value is string text) return WriteNotNullString(text);
            if (value is int int32) return Write(BenDataTypes.Int32).Write(BitConverter.GetBytes(int32).ToArray(0, 4));
            if (value is double float64) return Write(BenDataTypes.Float64).Write(BitConverter.GetBytes(float64).ToArray(0, 8));
            if (value is float float32) return Write(BenDataTypes.Float32).Write(BitConverter.GetBytes(float32).ToArray(0, 4));
            if (value is long int64) return Write(BenDataTypes.Int64).Write(BitConverter.GetBytes(int64).ToArray(0, 8));
            if (value is bool bit) return bit ? Write(BenDataTypes.True) : Write(BenDataTypes.False);
            if (value is null || value is DBNull) return Write(BenDataTypes.Null);
            if (value is char ascii) return Write(BenDataTypes.ASCII).Write(BitConverter.GetBytes(ascii));
            if (value is byte uint8) return Write(BenDataTypes.Uint8).Write(uint8);
            if (value is sbyte int8) return Write(BenDataTypes.Int8).Write(ToByte(int8));
            if (value is short int16) return Write(BenDataTypes.Int16).Write(BitConverter.GetBytes(int16).ToArray(0, 2));
            if (value is byte[] buffer) return Write(BenDataTypes.Blob).WriteInteger(buffer.Length).Write(buffer);
            if (value is DateTime dateTime) return WriteNotNullString(dateTime.ToTimeString());
            return WriteString(value.ToString());
        }

        private BenWriter WriteInteger(int value) {
            if (value < 0) throw new NotSupportedException();
            if (value <= byte.MaxValue) return Write(BenDataTypes.Uint8).Write((byte)value);
            if (value <= short.MaxValue) return Write(BenDataTypes.Int16).Write(BitConverter.GetBytes((short)value).ToArray(0, 2));
            return Write(BenDataTypes.Int32).Write(BitConverter.GetBytes(value).ToArray(0, 4));
        }
        private BenWriter WritePropertyId(int id) {
            if (id < 0) throw new NotSupportedException();
            if (id <= byte.MaxValue) return Write(BenPunctuator.PropertyId).Write((byte)id);
            if (id <= short.MaxValue) return Write(BenPunctuator.PropertyId_16).Write(BitConverter.GetBytes((short)id).ToArray(0, 2));
            return Write(BenPunctuator.PropertyId_32).Write(BitConverter.GetBytes(id).ToArray(0, 4));
        }
        private BenWriter WritePropertyName(int id, string name) {
            if (id < 0) throw new NotSupportedException();
            if (id <= byte.MaxValue) Write(BenPunctuator.PropertyName).Write((byte)id);
            else if (id <= short.MaxValue) Write(BenPunctuator.PropertyName_16).Write(BitConverter.GetBytes((short)id).ToArray(0, 2));
            else Write(BenPunctuator.PropertyName_32).Write(BitConverter.GetBytes(id).ToArray(0, 4));
            return WriteString(name);
        }

        private BenWriter WriteString(string? text) {
            if (text is null) return Write(BenDataTypes.Null);
            return WriteNotNullString(text);
        }

        private BenWriter WriteNotNullString(string text) {
            var buffer = Encoding.UTF8.GetBytes(text);
            var length = buffer.Length;
            if (length <= byte.MaxValue) Write(BenDataTypes.Text).Write((byte)length);
            else if (length <= short.MaxValue) Write(BenDataTypes.String).Write(BitConverter.GetBytes((short)length).ToArray(0, 2));
            else Write(BenDataTypes.Utf8).Write(BitConverter.GetBytes(length).ToArray(0, 4));
            return Write(buffer);
        }

        internal BenWriter Write(BenPunctuator punctuator) => Write([(byte)punctuator]);

        private static BenDataTypes? GetSameType(Type? itemType) {
            if (itemType is null) return null;
            else if (itemType == typeof(int)) return BenDataTypes.Int32;
            else if (itemType == typeof(double)) return BenDataTypes.Float64;
            else if (itemType == typeof(float)) return BenDataTypes.Float32;
            else if (itemType == typeof(long)) return BenDataTypes.Int64;
            else if (itemType == typeof(char)) return BenDataTypes.ASCII;
            else if (itemType == typeof(byte)) return BenDataTypes.Uint8;
            else if (itemType == typeof(sbyte)) return BenDataTypes.Int8;
            else if (itemType == typeof(short)) return BenDataTypes.Int16;
            else return null;
        }
        private BenWriter WriteValue(BenDataTypes type, object value) {
            return type switch {
                BenDataTypes.Int32 => Write(BitConverter.GetBytes((int)value).ToArray(0, 4)),
                BenDataTypes.Float64 => Write(BitConverter.GetBytes((double)value).ToArray(0, 8)),
                BenDataTypes.Float32 => Write(BitConverter.GetBytes((float)value).ToArray(0, 4)),
                BenDataTypes.Int64 => Write(BitConverter.GetBytes((long)value).ToArray(0, 8)),
                BenDataTypes.ASCII => Write((byte)(char)value),
                BenDataTypes.Uint8 => Write((byte)value),
                BenDataTypes.Int8 => Write(ToByte((sbyte)value)),
                BenDataTypes.Int16 => Write(BitConverter.GetBytes((short)value).ToArray(0, 2)),
                _ => throw new NotSupportedException(),
            };
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static byte ToByte(sbyte value)
            => (byte)(value + sbyte.MinValue);
        internal Node WriteSameTypeItem(Node block, Token token, BenDataTypes itemType) {
            var value = token.Value;
            var tokenType = token.Type;
            if (!tokenType.IsValue()) throw new NotSupportedException();
            WriteValue(itemType, value!);
            return block.AddItem(new Node(tokenType, value, token.Name));
        }

        protected override void Close() {
            if (_close is null) return;
            _close(this);
            CanContinue = false;
            _close = null;
        }

        protected override void OnWriteContext(Token token) {
            var ordered = Ordered;
            base.OnWriteContext(token);
            if (ordered == Ordered) return;
            Write(BenPunctuator.Ordered).Write(Ordered ? BenDataTypes.True : BenDataTypes.False);
        }
    }
}
