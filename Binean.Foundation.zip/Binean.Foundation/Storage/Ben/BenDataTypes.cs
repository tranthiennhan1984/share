﻿
namespace Binean.Foundation.Storage {
    public enum BenDataTypes {
        None = -1,
        /// <summary>
        /// 2^32 character
        /// </summary>
        Utf8 = 83,//S
        /// <summary>
        /// 256 character
        /// </summary>
        Text = 116,//t
        /// <summary>
        /// 2^16 character
        /// </summary>
        String = 115,//s
        Int8 = 105,//i
        Int16 = 73,//I
        Int32 = 108,//l
        Int64 = 76,//L
        Float32 = 100,//d
        Float64 = 68,//D
        True = 84,//T
        False = 70,//F
        Null = 90,//Z,
        ASCII = 67,//C
        Uint8 = 85,//U
        Blob = 65,//A

        //Int32_8 = 131,
        //Int32_16 = 132,
        //Int64_8 = 133,
        //Int64_16 = 134,
        //Int64_32 = 135,
    }
}
