﻿
namespace Binean.Foundation.Storage {
    public enum BenPunctuator {
        EOF = -1,
        None = 0,
        BeginArray = 91,//[
        EndArray = 93,//]
        BeginObject = 123,//{
        EndObject = 125,//}
        ItemType = 35,//#
        Class = 64,//@
        Ordered = 41,//!
        //StringTemplate = 36,//$
        //Template = 37,//%
        PropertyName = 48,
        PropertyName_16 = 49,
        PropertyName_32 = 50,
        PropertyId = 51,
        PropertyId_16 = 52,
        PropertyId_32 = 53,
    }
}
