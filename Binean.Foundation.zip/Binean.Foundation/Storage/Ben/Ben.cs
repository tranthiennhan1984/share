﻿
using System.Runtime.CompilerServices;


namespace Binean.Foundation.Storage {
    public sealed class Ben(BID name) : IFormat, IStreamFormat {
        public BID Name { get; set; } = name;

        Reader? IFormat.Serialize(object? data, IGetter? config)
            => Serialize(data).TryConfigure(config);
        Writer? IFormat.Deserialize(object? data, IGetter? config)
            => Deserialize(data)?.TryConfigure(config);

        Reader? IStreamFormat.Serialize(Stream stream, IGetter? config)
            => Serialize(stream, true).TryConfigure(config);
        Writer? IStreamFormat.Deserialize(Stream stream, IGetter? config)
            => Deserialize(stream, true).SetContent(stream).TryConfigure(config);

        public static Reader? Serialize(object? data = null) {
            if (data is null) return null;
            if (data is Stream st) return Serialize(st, true);
            if (data.CreateStream() is not Stream ds) return null;
            return Serialize(ds);
        }
        public static Writer? Deserialize(object? data = null) {
            if (data is null) {
                var stream = new MemoryStream();
                return new BenWriter(stream, stream.Dispose, w => {
                    stream.Flush();
                    w.SetContent(stream.ToArray());
                });
            }
            if (data is not Stream st) return null;
            return Deserialize(st, true).SetContent(data);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BenReader Serialize(Stream stream, bool leaveOpen = false)
            => new(stream, leaveOpen ? null : stream.Dispose);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BenWriter Deserialize(Stream stream, bool leaveOpen = false)
            => new(stream, leaveOpen ? null : stream.Dispose);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BenReader Serialize(byte[] blob)
            => Serialize(new MemoryStream(blob));

        public static byte[] ToBlob(Reader reader, IGetter? config = null) {
            using (var writer = Deserialize()!.TryConfigure(config)) {
                writer.Write(reader);
                return (byte[])writer.GetContent()!;
            }
        }
    }
}