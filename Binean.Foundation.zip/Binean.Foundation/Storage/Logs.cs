﻿namespace Binean.Foundation.Storage {
    [BLog]
    internal static class Logs {
        public const string BFND50101E = "Buffer has less data then expected.";
        public const string BFND50102E = "'Integer data type' expected.";
        public const string BFND50103E = "'String data type' expected.";
        public const string BFND50104E = "Invalid data type '{0}'.";
        public const string BFND50105E = "Invalid punctuator '{0}'.";

        public const string BFND50401E = "'{0}' is expected.";
        public const string BFND50402E = "Invalid character '{0}'.";
        public const string BFND50403E = "Invalid token '{0}'.";
        public const string BFND50404E = "Invalid symbol '{0}'.";
        public const string BFND50405E = "Invalid keyword '{0}'.";
        public const string BFND50406E = "Token's name is expected.";
        public const string BFND50407E = "Token's name is unexpected.";
        public const string BFND50408E = "Token's tag is too long: '{0}'.";
        public const string BFND50409E = "At least one condition is expected'.";
        public const string BFND5040AE = "At least one configure is expected'.";
    }
}
