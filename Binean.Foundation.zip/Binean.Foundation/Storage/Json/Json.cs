﻿using System.Runtime.CompilerServices;


namespace Binean.Foundation.Storage {
    public sealed class Json(BID name) : ICharacterFormat, IStreamFormat {
        public BID Name { get; private set; } = name;

        Reader? IFormat.Serialize(object? data, IGetter? config)
            => Serialize(data).TryConfigure(config);
        Writer? IFormat.Deserialize(object? data, IGetter? config)
            => Deserialize(data).TryConfigure(config);

        Reader? ICharacterFormat.Serialize(ICharacterInput input, IGetter? config)
            => Serialize(input, true).TryConfigure(config);
        Writer? ICharacterFormat.Deserialize(BTextWriter output, IGetter? config)
            => Deserialize(output, true).TryConfigure(config);

        Reader? IStreamFormat.Serialize(Stream stream, IGetter? config)
            => Serialize(stream.CreateTextReader(true)).TryConfigure(config);
        Writer? IStreamFormat.Deserialize(Stream stream, IGetter? config)
            => Deserialize(stream.CreateTextWriter(true)).TryConfigure(config);

        public static JsonReader? Serialize(object? data) {
            if (data is ICharacterInput input) return Serialize(input, true);
            if (data is null || data.CreateTextReader() is not ICharacterInput ci) return null;
            return Serialize(ci);
        }
        public static JsonWriter? Deserialize(object? data = null) {
            if (data is null) {
                var st = new StringWriter();
                return new JsonWriter(st.CreateTextWriter(true), st.Dispose, w => {
                    st.Flush();
                    w.SetContent(st.GetStringBuilder().ToString());
                    st.Dispose();
                });
            }

            if (data is BTextWriter w) return Deserialize(w, true);
            if (data.CreateTextWriter() is not BTextWriter tw) return null;
            return Deserialize(tw).SetContent(data);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static JsonReader Serialize(ICharacterInput reader, bool leaveOpen = false)
            => new(reader, leaveOpen ? null : reader.Dispose);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static JsonWriter Deserialize(BTextWriter writer, bool leaveOpen = false)
            => new(writer, leaveOpen ? null : writer.Dispose);

        public static string ToString(Reader reader, IGetter? config = null) {
            using (var writer = Deserialize()!.TryConfigure(config)) {
                writer.Write(reader);
                return (string)writer.GetContent()!;
            }
        }
        public static IEntity? Box(object? data, NameCase idCase = NameCase.NotSet) {
            if (Serialize(data) is not JsonReader reader) return null;
            var config = idCase == NameCase.NotSet ? null : Prior.CreateSortedEntity().Set(Properties.IdCase, NameCase.PascalCase);
            using (reader) {
                return Men.ToObject(reader, config) as IEntity;
            }
        }
        public static bool IsWhitespace(char chr) => " \t\r\n\f".Contains(chr);
    }
    file static class Properties {
        public static readonly BID IdCase = nameof(IdCase);
    }
}