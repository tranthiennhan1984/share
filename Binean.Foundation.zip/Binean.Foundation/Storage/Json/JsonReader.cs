﻿namespace Binean.Foundation.Storage {
    [Avatar]
    public class JsonReader : Reader {
        private readonly JsonLexer _lexer;

        public JsonReader(ICharacterInput reader, Action? disposedAction = null, NodeType beginType = NodeType.Array) {
            var rootToken = new Token(beginType);
            _lexer = new JsonLexer(reader);
            _lexer.MoveNext();
            Ordered = true;
            Initialize(rootToken, _lexer.IsEnd ? ReadEof : ReadItem, disposedAction);
        }

        [AvatarProperty]
        public string? Location {
            get { return _lexer.Location; }
            set { _lexer.Location = value; }
        }

        [AvatarProperty]
        public object Position => _lexer.Position;

        private Token ReadItem(TokenResolve resolve, ref Serialize serialize, Token block) {
            var blockType = block.Type;
            BID propName = BID.Nothing;
            while (true) {
                string? text;
                var symbol = _lexer.Current;

                if (symbol.IsType(JsonSymbol.String)) {
                    text = symbol.Text;
                    _lexer.MoveNext();
                    if (_lexer.Current.IsType(JsonSymbol.COLON)) {
                        _lexer.MoveNext();
                        propName = (BID)text;
                        continue;
                    }
                    if (propName.IsNothing && blockType.IsObject()) return block.NewToken(NodeType.Value, null, (BID)text);
                    return block.NewToken(NodeType.Value, text, propName);
                }

                if (symbol.IsType(JsonSymbol.LBRACE)) {
                    _lexer.MoveNext();
                    return block.NewToken(NodeType.Object, null, propName);
                }

                if (symbol.IsType(JsonSymbol.RBRACE)) {
                    if (blockType.IsArray()) throw _lexer.ExpectedCharacter(']');
                    _lexer.MoveNext();
                    return block.EndToken();
                }

                if (symbol.IsType(JsonSymbol.LSQBRACKET)) {
                    _lexer.MoveNext();
                    return block.NewToken(NodeType.Array, null, propName);
                }

                if (symbol.IsType(JsonSymbol.RSQBRACKET)) {
                    if (blockType.IsObject()) throw _lexer.ExpectedCharacter('}');
                    _lexer.MoveNext();
                    return block.EndToken();
                }

                if (symbol.IsType(JsonSymbol.COMMA)) {
                    _lexer.MoveNext();
                    if (propName.IsNothing) continue;
                    return block.NewToken(NodeType.Value, null, propName);
                }

                if (symbol.IsType(JsonSymbol.Number)
                    || symbol.IsType(JsonSymbol.Null)
                    || symbol.IsType(JsonSymbol.Boolean)
                    ) {
                    _lexer.MoveNext();
                    return block.NewToken(NodeType.Value, symbol.Tag, propName);
                }

                if (symbol == Symbol.Eof) return ReadEof(resolve, ref serialize, block);

                throw _lexer.InvalidSymbol(_lexer.Current);
            }
        }
    }
}
