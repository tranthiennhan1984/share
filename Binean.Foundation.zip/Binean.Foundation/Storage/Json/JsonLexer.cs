﻿namespace Binean.Foundation.Storage {
    [Avatar]
    sealed class JsonLexer : IInput<Symbol> {
        private readonly ICharacterInput _reader;
        public JsonLexer(ICharacterInput reader) {
            _reader = reader;
            _reader.IsWhitespace = Json.IsWhitespace;
        }

        [AvatarProperty]
        public string? Location {
            get { return _reader.Location; }
            set { _reader.Location = value; }
        }

        [AvatarProperty]
        public object Position => _reader.Position;
        public Symbol Current { get; private set; } = Symbol.None;
        public bool IsEnd => Current == Symbol.Eof;
        public void MoveNext() {
            if (Current == Symbol.Eof) return;
            Current = Read();
        }

        public Symbol Read() {
            while (true) {
                var chr = _reader.SkipWhitespaces();

                switch (chr) {
                    case '{':
                        _reader.MoveNext();
                        return new Symbol(JsonSymbol.LBRACE, chr.ToString());
                    case '}':
                        _reader.MoveNext();
                        return new Symbol(JsonSymbol.RBRACE, chr.ToString());
                    case '[':
                        _reader.MoveNext();
                        return new Symbol(JsonSymbol.LSQBRACKET, chr.ToString());
                    case ']':
                        _reader.MoveNext();
                        return new Symbol(JsonSymbol.RSQBRACKET, chr.ToString());
                    case ':':
                        _reader.MoveNext();
                        return new Symbol(JsonSymbol.COLON, chr.ToString());
                    case ',':
                        _reader.MoveNext();
                        return new Symbol(JsonSymbol.COMMA, chr.ToString());
                    case '"':
                        return _reader.ReadStringSymbol();
                    case '-':
                        return _reader.ReadNumberSymbol();

                    case Prior.EofCharacter: return Symbol.Eof;
                }
                if (char.IsDigit(chr)) return _reader.ReadNumberSymbol();
                if (char.IsLetter(chr)) return _reader.ReadIdentifierSymbol(true);

                throw _reader.InvalidCharacter(chr);
            }
        }
    }
    static class JsonSymbol {
        public static readonly BID COMMA = nameof(COMMA);
        public static readonly BID LSQBRACKET = nameof(LSQBRACKET);
        public static readonly BID RSQBRACKET = nameof(RSQBRACKET);
        public static readonly BID LBRACE = nameof(LBRACE);
        public static readonly BID RBRACE = nameof(RBRACE);
        public static readonly BID COLON = nameof(COLON);

        public static readonly BID String = nameof(String);
        public static readonly BID Number = nameof(Number);
        public static readonly BID Boolean = nameof(Boolean);
        public static readonly BID Null = nameof(Null);
    }
}
