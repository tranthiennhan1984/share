﻿namespace Binean.Foundation.Storage {
    [Avatar]
    public sealed class JsonWriter : Writer {
        private readonly BTextWriter _writer;
        private Action<JsonWriter>? _close;

        public JsonWriter(BTextWriter writer, Action? disposedAction = null, Action<JsonWriter>? close = null) {
            _content = writer;
            _close = close;
            var rootNode = new Node(NodeType.Array);
            _writer = writer;
            var deserialize = new Deserialize(WriteItem);
            if (_close != null) {
                if (disposedAction is null) disposedAction = Close;
                else {
                    var cur = disposedAction;
                    disposedAction = () => {
                        Close();
                        cur();
                    };
                }
            }

            Initialize(rootNode, deserialize, disposedAction);
        }

        [AvatarProperty]
        public string? Location {
            get => _writer.Location;
            set => _writer.Location = value;
        }

        [AvatarProperty]
        public bool Decorate {
            get => _writer.Decorate;
            set => _writer.Decorate = value;
        }

        [AvatarProperty]
        public int IndentOffset {
            get => _writer.IndentOffset;
            set => _writer.IndentOffset = value;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            if (block.Level < 0 && token.Type.IsEndBlock()) {
                deserialize = WriteException;
                return block.EndNode();
            }
            return WriteItem(_writer, block, token, token.Name);
        }


        public static void WriteObject(BTextWriter writer, int indentationLevel, BID name, bool isObject) {
            writer.AssertNewLine(indentationLevel, true);
            if (!name.IsNothing) {
                writer.WriteString((string)name).Write(":");
                if (writer.Decorate) writer.Write(" ");
            }
            writer.Write(isObject ? "{" : "[").EndLine();
        }
        public static void WriteEndObject(BTextWriter writer, int indentationLevel, bool blockIsObject) {
            writer.AssertNewLine(indentationLevel, true).Write(blockIsObject ? "}" : "]");
        }
        public static void WriteEndLine(BTextWriter writer, int itemIndex) {
            if (itemIndex >= 0) writer.EndLine(null, ',');
        }
        public static void WriteValue(BTextWriter writer, int indentationLevel, BID name, object? value) {
            writer.AssertNewLine(indentationLevel);
            if (!name.IsNothing) {
                writer.WriteString((string)name).Write(":");
                if (writer.Decorate) writer.Write(" ");
            }
            if (value is byte[] blob) writer.WriteBlob(blob, "\"", "\"");
            else writer.WriteValue(value);
        }
        public static Node WriteItem(BTextWriter writer, Node block, Token token, BID name, int indentationOffset = 0) {
            var blockType = block.Type;
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                WriteEndObject(writer, block.Level + indentationOffset, blockType.IsObject());
                return block.EndNode();
            }
            if (block.ItemIndex >= 0) writer.EndLine(null, ',');
            var indentationLevel = block.Level + indentationOffset + 1;

            if (tokenType.IsValue()) {
                WriteValue(writer, indentationLevel, blockType.IsObject() ? name : BID.Nothing, token.Value);
                return block.AddItem(new Node(token.Potential));
            }

            WriteObject(writer, indentationLevel, blockType.IsObject() ? name : BID.Nothing, tokenType.IsObject());
            return block.AddItem(new Node(token.Potential));
        }
        protected override void Close() {
            if (_close is null) return;
            _close(this);
            CanContinue = false;
            _close = null;
        }
    }
}
