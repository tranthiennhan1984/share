﻿namespace Binean.Foundation.Storage {
    /// <summary>
    /// Stream format
    /// </summary>
    public interface IStreamFormat : IFormat {
        Reader? Serialize(Stream stream, IGetter? config = null);
        Writer? Deserialize(Stream stream, IGetter? config = null);
    }
    /// <summary>
    /// Character format
    /// </summary>
    public interface ICharacterFormat : IFormat {
        Reader? Serialize(ICharacterInput input, IGetter? config = null);
        Writer? Deserialize(BTextWriter output, IGetter? config = null);
    }
}