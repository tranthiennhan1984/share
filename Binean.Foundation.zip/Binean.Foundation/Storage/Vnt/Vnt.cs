﻿using System.Runtime.CompilerServices;


namespace Binean.Foundation.Storage {
    public sealed class Vnt(BID name) : ICharacterFormat, IStreamFormat {
        public BID Name { get; private set; } = name;

        Reader? IFormat.Serialize(object? data, IGetter? config)
            => Serialize(data).TryConfigure(config);
        Writer? IFormat.Deserialize(object? data, IGetter? config)
            => throw new NotSupportedException();

        Reader? ICharacterFormat.Serialize(ICharacterInput input, IGetter? config)
            => Serialize(input, true).TryConfigure(config);
        Writer? ICharacterFormat.Deserialize(BTextWriter output, IGetter? config)
            => throw new NotSupportedException();

        Reader? IStreamFormat.Serialize(Stream stream, IGetter? config)
            => Serialize(stream.CreateTextReader(true)).TryConfigure(config);
        Writer? IStreamFormat.Deserialize(Stream stream, IGetter? config)
            => throw new NotSupportedException();

        public static TenReader? Serialize(object? data) {
            if (data is ICharacterInput input) return Serialize(input, true);
            if (data is null || data.CreateTextReader() is not ICharacterInput ci) return null;
            return Serialize(ci);
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static TenReader Serialize(ICharacterInput reader, bool leaveOpen = false)
            => new(reader, leaveOpen ? null : reader.Dispose);
    }
}