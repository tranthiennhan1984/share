﻿using Binean.Foundation.Core;
using System.Collections;
using System.Diagnostics;

namespace Binean.Foundation.Storage {
    public sealed class MenNode : DesNode {
        private readonly IEntity _ent;
        private readonly bool _guarantee;

        public MenNode(IEntity entity, ref Deserialize deserialize, Token token, bool guarantee)
            : base(deserialize, token.Type, entity, token.Name) {
            _ent = entity;

            _ent.AddClass(token);

            _guarantee = guarantee;
            deserialize = WriteItem;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                _ent.Validate();
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }
            if (!tokenType.IsValue()) token.ChangeValue(null);

            var node = resolve(resolve, ref deserialize, block, token);
            if (node.IsDummy) return block.AddItem(token.Skip(ref deserialize));

            if (node.Name.IsNothing) {

            }
            _ent.Set(node.Name, node.Value, _guarantee);
            return block.AddItem(node);
        }
    }
    public sealed class BNode : DesNode {
        private readonly IBoxable _boxable;
        private readonly IEntity _ent;
        private readonly bool _guarantee;

        public BNode(IBoxable boxable, IEntity ent, ref Deserialize deserialize, NodeType kind, BID name, bool guarantee)
            : base(deserialize, kind, boxable, name) {
            _boxable = boxable;
            _ent = ent;
            _guarantee = guarantee;
            deserialize = WriteItem;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                _boxable.Unbox(_ent);
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }
            if (!tokenType.IsValue()) token.ChangeValue(null);

            var node = resolve(resolve, ref deserialize, block, token);
            if (node.IsDummy) return block.AddItem(token.Skip(ref deserialize));

            _ent.Set(node.Name, node.Value, _guarantee);
            return block.AddItem(node);
        }
    }
    public sealed class CNode : DesNode {
        private readonly IAvatarType _cType;
        private readonly object _instance;
        private readonly bool _guarantee;

        public CNode(object instance, IAvatarType cType, ref Deserialize deserialize, Token token, bool guarantee)
            : base(deserialize, token.Type, instance, token.Name) {
            _cType = cType;
            _instance = instance;
            _guarantee = guarantee;
            deserialize = WriteItem;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);

            var tokenType = token.Type;
            if (tokenType.IsEndBlock()) {
                _instance.Validate();
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }
            if (!tokenType.IsValue()) token.ChangeValue(null);

            var node = _cType.NodeResolve(_instance, resolve, ref deserialize, block, token, _guarantee);
            if (node == DummyNode || node.Value is DBNull) return block.AddItem(token.Skip(ref deserialize));
            return block.AddItem(node);
        }
    }
    public sealed class ENode : DesNode {
        private readonly IAvatarType _cType;
        private readonly IReadonlyBSet _settableNames;
        private readonly object _instance;
        private readonly IEntity _ent;
        private readonly bool _guarantee;

        public ENode(object instance, IEntity ent, IAvatarType cType, ref Deserialize deserialize, Node token, bool guarantee)
            : base(deserialize, token.Type, instance, token.Name) {
            _cType = cType;
            _settableNames = _cType.SettableNames;
            _instance = instance;
            _ent = ent;

            _ent.AddClass(token);

            _guarantee = guarantee;
            deserialize = WriteItem;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                _instance.Validate();
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }
            if (!tokenType.IsValue()) token.ChangeValue(null);

            var name = token.Name;
            if (_settableNames.Find(name, out _)) {
                var node = _cType.NodeResolve(_instance, resolve, ref deserialize, block, token, _guarantee);
                if (node == DummyNode || node.Value is DBNull) return block.AddItem(token.Skip(ref deserialize));
                return block.AddItem(node);
            } else {
                var node = resolve(resolve, ref deserialize, block, token);
                if (node == DummyNode) return block.AddItem(token.Skip(ref deserialize));
                _ent.Set(node.Name, node.Value, _guarantee);
                return block.AddItem(node);
            }
        }
    }
    public sealed class AvatarNode : DesNode {
        private readonly Avatar _avatar;
        private readonly bool _guarantee;

        public AvatarNode(Avatar avatar, ref Deserialize deserialize, Node token, bool guarantee)
            : base(deserialize, token.Type, avatar, token.Name) {
            _avatar = avatar;
            _guarantee = guarantee;
            deserialize = WriteItem;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                _avatar.Validate();
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }
            if (!tokenType.IsValue()) token.ChangeValue(null);

            var node = AvatarNodeResolve(_avatar, resolve, ref deserialize, block, token, _guarantee);
            if (node == DummyNode || node.Value is DBNull) return block.AddItem(token.Skip(ref deserialize));
            return block.AddItem(node);
        }

        private Node AvatarNodeResolve(Avatar avatar, NodeResolve resolve, ref Deserialize deserialize, Node block, Token token, bool guarantee) {
            if (!avatar.AvatarProperties.TryGetNotNull(token.Name, out AvatarProperty? property)) {
                var node = resolve(resolve, ref deserialize, block, token);
                if (node.IsDummy) return node;
                _avatar.Set(node.Name, node.Value, _guarantee);
                return node;
            }

            if (property.Attribute.WriteSkip) return DummyNode;

            if ((!token.Type.IsValue() || token.Value is null) && GetValue(property, avatar, token) is object v) token.ChangeValue(v);

            var retVal = resolve(resolve, ref deserialize, block, token);
            if (retVal.IsDummy) return retVal;

            var name = retVal.Name;
            try {
                if (property.TrySetValue(avatar, retVal.Value) && guarantee) return retVal;
                if (guarantee) throw LogStorage.CreateError(nameof(Primitive.Logs.BFND20206E), name, avatar);
                return DummyNode;
            } catch {
                if (guarantee) throw LogStorage.CreateError(nameof(Primitive.Logs.BFND20206E), name, avatar);
                return DummyNode;
            }
        }
        private static object? GetValue(AvatarProperty property, object instance, Token token) {
            if (property.IsReadOnly) {
                property.TryGetOver(instance, out var value);
                return value;
            }
            token.Potential.MSet(HiddenProperties.SysType, () => property.PropertyType);
            return null;
        }
    }

    public sealed class ListNode : DesNode {
        private readonly IList _list;
        private readonly Type? _itemType;

        public ListNode(IList list, ref Deserialize deserialize, Node node)
            : base(deserialize, node.Type, list, node.Name) {
            _list = list;
            _itemType = _list.GetType().GetGenericArguments().Single();
            deserialize = WriteItem;
        }
        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                _list.Validate();
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }

            if (!tokenType.IsValue()) token.ChangeValue(null);
            var node = InResolve(resolve, ref deserialize, block, token);
            if (node == DummyNode) return block.AddItem(token.Skip(ref deserialize));
            _list.Add(node.Value);
            return block.AddItem(node);
        }
        private Node InResolve(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            if (token.Value is null && _itemType != null) token.ChangeValue(Generator.CreateInstance(_itemType));
            return resolve(resolve, ref deserialize, block, token);
        }
    }
    public sealed class NameListNode : DesNode {
        private readonly IBSet _list;

        public NameListNode(IBSet list, ref Deserialize deserialize, Node node)
            : base(deserialize, node.Type, list, node.Name) {
            _list = list;
            deserialize = WriteItem;
        }
        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                _list.Validate();
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }

            if (!tokenType.IsValue()) token.ChangeValue(null);
            var node = resolve(resolve, ref deserialize, block, token);
            if (node == DummyNode) return block.AddItem(token.Skip(ref deserialize));
            if (node.Value.As<string>() is string txt && !string.IsNullOrWhiteSpace(txt)) _list.Add((BID)txt);
            return block.AddItem(node);
        }
    }
    public sealed class DictNode : DesNode {
        private readonly IDictionary _dict;
        private readonly Type? _itemType;

        public DictNode(IDictionary dict, ref Deserialize deserialize, Node node)
            : base(deserialize, node.Type, dict, node.Name) {
            _dict = dict;
            var args = _dict.GetType().GetGenericArguments();
            if (args.Length > 1) _itemType = args[1];
            deserialize = WriteItem;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                _dict.Validate();
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }

            var name = token.Name;
            Debug.Assert(!name.IsNothing);

            if (!tokenType.IsValue()) token.ChangeValue(null);
            var node = InResolve(resolve, ref deserialize, block, token);
            if (node == DummyNode) return block.AddItem(token.Skip(ref deserialize));

            _dict[name] = node.Value;
            return block.AddItem(node);
        }
        private Node InResolve(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            if (token.Value is null && _itemType != null) token.ChangeValue(Generator.CreateInstance(_itemType));
            return resolve(resolve, ref deserialize, block, token);
        }
    }
    public sealed class SetNode : DesNode {
        private readonly ISetter _setter;
        private readonly bool _guarantee;

        public SetNode(ISetter setter, ref Deserialize deserialize, NodeType kind, BID name, bool guarantee)
            : base(deserialize, kind, setter, name) {
            _setter = setter;
            _guarantee = guarantee;
            deserialize = WriteItem;
        }

        private Node WriteItem(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(this == block);
            var tokenType = token.Type;

            if (tokenType.IsEndBlock()) {
                _setter.Validate();
                return WriteEndBlock(resolve, ref deserialize, block, token);
            }

            if (!tokenType.IsValue()) token.ChangeValue(null);
            var node = resolve(resolve, ref deserialize, block, token);
            if (node == DummyNode) return block.AddItem(token.Skip(ref deserialize));

            _setter.Set(token.Name, token.Value, _guarantee);
            return block.AddItem(node);
        }
    }
}
