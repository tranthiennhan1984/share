﻿using System.Collections;


namespace Binean.Foundation.Storage {
    public class MenToken : BlockToken {
        private readonly IEnumerator<Token> _enumerator;

        public MenToken(ref Serialize serialize, IEnumerator<Token> enumerator, Token token, NodeType kind)
            : base(serialize, token.To<IEntity>()) {
            _enumerator = enumerator;
            ChangeType(kind);
            serialize = ReadItem;
        }

        private Token ReadItem(TokenResolve resolve, ref Serialize serialize, Token block) {
            if (!_enumerator.MoveNext()) return ReadEndBlock(resolve, ref serialize, block);
            var retVal = _enumerator.Current;
            if (retVal != Eof) retVal = resolve(resolve, ref serialize, block, retVal);
            return retVal == Eof ? ReadEndBlock(resolve, ref serialize, block)
                : block.AddItem(retVal);
        }

    }
}