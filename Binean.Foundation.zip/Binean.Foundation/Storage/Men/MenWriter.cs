﻿using System.Collections;
using System.Diagnostics;
namespace Binean.Foundation.Storage {
    [Avatar]
    public class MenWriter : Writer {
        public MenWriter(object? content = null, Action? disposedAction = null) {
            _content = content;
            Initialize(new Node(NodeType.Array), WriteContainer, disposedAction);
        }

        [AvatarProperty]
        public bool WriteGuarantee { get; set; } = true;

        private Node WriteContainer(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            if (token.IsDummy) return WriteEof(resolve, ref deserialize, block, token);
            deserialize = WriteEof;

            var tokenType = token.Type;
            if (!tokenType.IsValue()) token.ChangeValue(null);

            if (_content != null) {
                if (token.Potential.Get(TokenProperties.SysType)?.As<Type>() is Type sysType && !_content.GetType().IsAssignableFrom(sysType)) throw this.InvalidToken(token);
                token.ChangeValue(_content);
            }

            var node = resolve(resolve, ref deserialize, block, token);
            if (node.IsDummy) return block.AddItem(token.Skip(ref deserialize));

            _content = node.Value;
            return block.AddItem(node);
        }

        protected override Node OnNodeResolve(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            var value = token.Value;

            var vType = token.Potential.Get(TokenProperties.SysType);

            if (value is null && vType?.As<Type>() is Type valueType) {
                if (!valueType.IsEnum && Generator.IsObjectType(valueType) && valueType != typeof(object)) {
                    token.ChangeValue(value = valueType.CreateInstance());
                    if (value is IGetter cls) cls.AddClass(token);
                }
            }

            var tokenType = token.Type;
            if (tokenType.IsValue()) return new Node(token.To<IEntity>());

            if (tokenType.IsObject()) {
                if (value is null) {
                    var vent = Prior.CreateEntity(!token.Potential.Get(TokenProperties.Ordered, false)).AddClass(token);
                    if (vType is string) vent.Set(TokenProperties.SysType, vType);
                    return new MenNode(vent, ref deserialize, token, WriteGuarantee);
                }
                if (value is Avatar avatar) return new AvatarNode(avatar, ref deserialize, token, WriteGuarantee);

                if (value is IBoxable boxable) return new BNode(boxable, Prior.CreateEntity(!token.Potential.Get(TokenProperties.Ordered, false)).AddClass(token), ref deserialize, NodeType.Object, token.Name, WriteGuarantee);

                if (value.GetType().GetAvatarInfo()?.GetAvatarType() is IAvatarType avatarType) {
                    if (value is IProspect evolvable) return new ENode(value, evolvable.Potential, avatarType, ref deserialize, token, WriteGuarantee);
                    return new CNode(value, avatarType, ref deserialize, token, WriteGuarantee);
                }
                if (value is Prospect prospect) return new MenNode(prospect.Potential, ref deserialize, token, WriteGuarantee);
                if (value is IDictionary dict) return new DictNode(dict, ref deserialize, token);
                if (value.As<IEntity>() is IEntity ent) return new MenNode(ent, ref deserialize, token, WriteGuarantee);
                if (value is ISetter setter) return new SetNode(setter, ref deserialize, token.Type, token.Name, WriteGuarantee);
                return token.Skip(ref deserialize);
            }

            Debug.Assert(tokenType.IsArray());
            {
                if (token.Name == HiddenProperties.ClassNames) return token.Skip(ref deserialize);
                if (value is null) return new ListNode(Prior.CreateList(), ref deserialize, token);
                if (value is IList list) return new ListNode(list, ref deserialize, token);
                if (value is IBSet nameList) return new NameListNode(nameList, ref deserialize, token);
                return token.Skip(ref deserialize);
            }
        }
    }
}
