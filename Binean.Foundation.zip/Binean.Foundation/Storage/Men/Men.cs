﻿using System.Collections;

namespace Binean.Foundation.Storage {
    public sealed class Men(BID name) : IFormat {
        public BID Name { get; private set; } = name;

        Reader? IFormat.Serialize(object? data, IGetter? config)
            => Serialize(data).TryConfigure(config);
        Writer? IFormat.Deserialize(object? data, IGetter? config)
            => Deserialize(data).TryConfigure(config);

        public static MenReader? Serialize(object? obj, bool requireBlock = false) {
            if (obj is null || obj is DBNull) return null;
            if (ToBlock(obj) is object block) return new MenReader(block);
            if (!requireBlock) return new MenReader(obj);
            return null;
        }
        public static MenWriter Deserialize(object? obj)
            => new(obj);
        public static object? ToObject(Reader? reader, IGetter? proConfig = null) {
            if (reader is null) return null;
            using (var writer = new MenWriter().TryConfigure(proConfig)) {
                writer.Write(reader);
                return writer.GetContent();
            }
        }
        public static object? Clone(object? obj, IGetter? proConfig = null) {
            if (obj is null) return null;
            if (obj is byte[] blob) {
                var retVal = new byte[blob.Length];
                blob.CopyTo(retVal, 0);
                return retVal;
            }
            if (ToBlock(obj) is not object block) return obj;
            using (var reader = new MenReader(block))
                return ToObject(reader, proConfig);
        }

        private static object? ToBlock(object? obj) {
            if (obj is null) return null;
            if (obj.As<IGetter>() is IGetter getter) return getter;
            return obj as IList;
        }
    }
}