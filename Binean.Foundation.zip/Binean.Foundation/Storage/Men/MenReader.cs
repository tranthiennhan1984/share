﻿using Binean.Foundation.Primitive;
using System.Collections;


namespace Binean.Foundation.Storage {
    [Avatar]
    public class MenReader : Reader {
        private Token? _nextToken;

        public MenReader(object obj, Action? disposedAction = null) {
            Content = obj;
            Serialize serialize = Content is null ? ReadEof : ReadContainer;

            _nextToken = Defines.CreateContextToken();

            var rootToken = new Token(NodeType.Array);
            Initialize(rootToken, serialize, disposedAction);
        }

        public event TokenResolve? TokenResolve;

        [AvatarProperty]
        public TagMode TagMode { get; set; }

        public IEntity Defines { get; } = Prior.CreateSortedEntity();

        public object? Content { get; }

        private Token ReadContainer(TokenResolve resolve, ref Serialize serialize, Token block) {
            serialize = ReadEof;

            var token = resolve(resolve, ref serialize, block, new Token(NodeType.None, Content));
            if (token.IsDummy) {
                serialize = ReadException;
                return ReadEof(resolve, ref serialize, block);
            }
            return block.AddItem(token);
        }

        protected override Token OnSerialize(TokenResolve resolve, ref Serialize serialize, Token block) {
            Token token = _nextToken != null ? block.AddItem(_nextToken) : serialize(resolve, ref serialize, block);
            _nextToken = token.Potential.Get(TokenProperties.Next).As<Token>();
            return token;
        }

        protected override Token OnTokenResolve(TokenResolve resolve, ref Serialize serialize, Token block, Token token) {
            var value = token.Value;
            if (value is null) {
                token.ChangeType(NodeType.Value);
                return token;
            }

            var valueType = value.GetType();
            if (Generator.IsPrimitiveType(valueType)) {
                token.ChangeType(NodeType.Value);
                return token;
            }

            if (value.As<IGetter>() is IGetter getter) return new MenToken(ref serialize, GetTokens(getter).GetEnumerator(), token, NodeType.Object).AddClass(getter);
            if (value is IList list) return new MenToken(ref serialize, ValuesToTokens(list).GetEnumerator(), token, NodeType.Array).AddClass(list);
            if (value is IEnumerable enm) return new MenToken(ref serialize, ValuesToTokens(enm).GetEnumerator(), token, NodeType.Array).AddClass(enm);

            var retVal = TokenResolve?.Invoke(resolve, ref serialize, block, token) ?? Token.Eof;
            if (!retVal.IsDummy) return retVal;

            token.ChangeType(NodeType.Value);
            return token;
        }
        protected static List<Token> GetTokens(IGetter getter) {
            var names = getter.Names;
            if (names.IsSorted) return UnitsToSortedTokens(getter.GetUnits());
            return names.IsUnique ? UnitsToUniqueTokens(getter.GetUnits()) : UnitsToTokens(getter.GetUnits());
        }
        private static List<Token> UnitsToTokens(IEnumerable<Unit> units) {
            var retVal = new List<Token>();
            foreach (var unit in units) {
                retVal.Add(new Token(NodeType.None, unit.Value, unit.Name).AddClass(unit.Value));
            }
            return retVal;
        }
        private static List<Token> UnitsToUniqueTokens(IEnumerable<Unit> units) {
            var visited = Prior.CreateBSet();
            var retVal = new List<Token>();
            foreach (var unit in units) {
                var name = unit.Name;
                if (visited.Find(name, out _)) continue;
                visited.Add(name);
                retVal.Add(new Token(NodeType.None, unit.Value, name).AddClass(unit.Value));
            }
            return retVal;
        }
        private static List<Token> UnitsToSortedTokens(IEnumerable<Unit> units) {
            var names = Prior.CreateBSet();
            var retVal = new List<Token>();
            foreach (var unit in units) {
                var name = unit.Name;
                if (names.Find(name, out _)) continue;
                int index = names.Add(name);
                retVal.Insert(index, new Token(NodeType.None, unit.Value, name).AddClass(unit.Value));
            }
            return retVal;
        }
        protected static List<Token> ValuesToTokens(IEnumerable values) {
            var retVal = new List<Token>();
            foreach (var value in values) {
                retVal.Add(new Token(NodeType.None, value).AddClass(value));
            }
            return retVal;
        }
    }
}
