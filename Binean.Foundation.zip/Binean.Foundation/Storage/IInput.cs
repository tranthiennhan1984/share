﻿namespace Binean.Foundation.Storage {
    public interface IInput<T> {
        object Position { get; }
        bool IsEnd { get; }
        T Current { get; }
        void MoveNext();
    }

    //public interface IOutput<T> {
    //    object Position { get; }
    //    bool IsEnd { get; }
    //    bool Write(T value);
    //}
}
