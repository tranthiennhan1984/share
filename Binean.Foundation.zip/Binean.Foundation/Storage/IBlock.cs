﻿namespace Binean.Foundation.Storage {
    public delegate Token TokenResolve(TokenResolve resolve, ref Serialize serialize, Token block, Token unit);
    public delegate Token Serialize(TokenResolve resolve, ref Serialize serialize, Token block);

    public delegate Node NodeResolve(NodeResolve resolve, ref Deserialize deserialize, Node block, Token unit);
    public delegate Node Deserialize(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token);

    public delegate bool NameStrategy(Node block, Node unit, out string? name);
    public enum TagMode {
        None,
        Tag,
        Type,
        TypeName,
        TagOrType,
    }
}