﻿using System.Runtime.CompilerServices;
using System.Text;

namespace Binean.Foundation.Storage {
    public static partial class Extension {
        #region :: Stream Helper ::
        //public static Stream ToBlockReader(this Stream stream, bool asyncRead = false, bool leaveOpen = false, int capacity = 1024)
        //    => new BlockReader(stream, asyncRead, leaveOpen, capacity);
        public static byte[] ReadExactly(this Stream stream, int count) {
            if (count <= 0) return [];
            byte[] blob = new byte[count];
            stream.ReadExactly(blob, 0, count);
            return blob;
        }
        public static void WriteASCII(this Stream stream, string txt) {
            var blob = Encoding.ASCII.GetBytes(txt);
            stream.Write([(byte)blob.Length]);
            stream.Write(blob);
        }
        public static string ReadASCII(this Stream stream)
            => Encoding.ASCII.GetString(stream.ReadExactly(stream.ReadByte()));

        //public static void Write(this Stream stream, Reader reader, ISformat format, IEntity? config = null) {
        //    stream.WriteASCII(format.Name);
        //    using (var writer = format.Deserialize(stream).TryConfigure(config).Assert())
        //        writer.Write(reader);
        //}
        //public static Reader? Serialize(this Stream stream, out ISformat format, IEntity? config = null) {
        //    var name = Encoding.ASCII.GetString(stream.ReadExactly(stream.ReadByte()));
        //    format = Eformat.Get(name).NotNull<ISformat>();
        //    return format.Serialize(stream).TryConfigure(config);
        //}

        #endregion

        #region :: Exception Helpers ::

        public static BError CreateException(this object sender, string messageId, params object?[] args) {
            var retVal = LogStorage.CreateError(messageId, args);
            if (sender.As<IGettable>() is IGettable source && retVal.Content.To<ISettable>() is ISettable settable) {
                settable.Set(Properties.Location, source.Get(Properties.Location), false)
                    .Set(Properties.Position, source.Get(Properties.Position), false);
            }
            return retVal;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BError ExpectedCharacter(this object reader, char chr)
            => reader.CreateException(nameof(Logs.BFND50401E), chr);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BError InvalidCharacter(this object reader, char chr)
            => reader.CreateException(nameof(Logs.BFND50402E), chr);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BError InvalidToken(this object reader, Token token)
            => reader.CreateException(nameof(Logs.BFND50403E), token);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BError InvalidSymbol(this object reader, Symbol symbol)
            => reader.CreateException(nameof(Logs.BFND50404E), symbol);

        #endregion

        #region :: Reader Writer Helper ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsNullOrEmpty(this Reader reader)
            => reader is null || reader.IsEmpty || !reader.CanRead;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Reader Assert(this Reader? reader)
            => reader ?? Reader.CreateDummy();

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Writer Assert(this Writer? writer)
            => writer ?? Writer.CreateDummy();

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string ToCen(this object? getter, IGetter? config = null) {
            if (getter == null) return string.Empty;
            using (var reader = Men.Serialize(getter)!) {
                return Cen.ToString(reader, config);
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string ToJson(this object? obj, IGetter? config = null) {
            if (obj is null) return string.Empty;
            using (var reader = Men.Serialize(obj).Assert()) {
                return Json.ToString(reader, config);
            }
        }
        public static Stream? CreateStream(this object data) {
            var buffer = data.As<byte[]>();
            if (buffer != null && buffer.Length > 0) {
                return new MemoryStream(buffer);
            }
            return null;
        }
        public static ICharacterInput? CreateTextReader(this object data) {
            if (data is ICharacterInput) throw new NotSupportedException();
            if (data is string text && !string.IsNullOrWhiteSpace(text)) return text.CreateTextReader();
            if (data is TextReader txtReader) return txtReader.CreateTextReader(true);
            if (data is Stream stream) return stream.CreateTextReader(true);
            if (data is byte[] buffer) return Encoding.UTF8.GetString(buffer, 0, buffer.Length).CreateTextReader();
            return null;
        }
        public static BTextWriter? CreateTextWriter(this object data) {
            if (data is BTextWriter) throw new NotSupportedException();
            if (data is TextWriter sw) return sw.CreateTextWriter(true);
            if (data is StringBuilder sb) return new StringWriter(sb).CreateTextWriter();
            if (data is Stream stream) return stream.CreateTextWriter(true);
            if (data is byte[] buffer) return new MemoryStream(buffer).CreateTextWriter();
            return null;
        }
        #endregion

        #region :: Data format ::
        //public static byte[] Serialize(this IStreamSerializer reader, Reader reader) {
        //    using (var stream = new MemoryStream()) {
        //        reader.Serialize(reader, stream);
        //        stream.Flush();
        //        return stream.ToArray();
        //    }
        //}
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static bool TryCreateReader(this string? txt, [NotNullWhen(true)] out Reader? reader) {
        //    if (!string.IsNullOrWhiteSpace(txt) && txt.Length > 6 && txt[0] == '_' && txt[4] == '_'
        //        && txt.Substring(1, 3).Get() is IEntityNotation format) {
        //        reader = format.CreateReader(txt[5..]);
        //        return true;
        //    }
        //    reader = null;
        //    return false;
        //}
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static string? GetFormatName(this IEntity entity, string? faultValue = null) {
        //    if (!entity.TryGet(Properties.Format, out object? obj)) return faultValue;
        //    if (obj is string type) return type;
        //    if (obj is IEntityNotation format) return format.Name;
        //    return faultValue;
        //}
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static IEntityNotation? GetDataFormat(this IEntity entity, IEntityNotation? faultValue = null, bool keep = false) {
        //    if (!entity.TryGet(Properties.Format, out object? obj)) return faultValue;
        //    if (obj is IEntityNotation format) return format;
        //    if (obj is not string type) return faultValue;

        //    if (type?.Get() is not IEntityNotation fm) return faultValue;
        //    format = fm;
        //    if (keep) entity.Set(Properties.Format, format);
        //    return format;
        //}
        #endregion

        #region :: Symbol Helpers ::

        public static bool IsType(this Symbol symbol, BID type)
            => symbol.Type == type;

        public static bool IsType(this Symbol symbol, BID type, string text)
            => symbol.Type == type && string.Compare(symbol.Text, text) == 0;

        #endregion

    }

    file static class Properties {
        public static readonly BID Location = nameof(Location);
        public static readonly BID Position = nameof(Position);

        public static readonly BID Logs = nameof(Logs);
        public static readonly BID Body = nameof(Body);
        public static readonly BID Template = nameof(Template);
    }
}
