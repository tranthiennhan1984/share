﻿namespace Binean.Foundation.Storage {
    public sealed class ReaderToken : BlockToken {
        private readonly BlockToken _rootToken;
        private readonly Reader _reader;
        private readonly Action? _disposedAction;

        public ReaderToken(ref Serialize serialize, Reader reader, BID? name = null, bool leaveOpen = false, BlockToken? rootToken = null)
            : this(ref serialize, reader, name, leaveOpen ? null : reader.Dispose, rootToken) { }
        public ReaderToken(ref Serialize serialize, Reader reader, BID? name = null, Action? disposedAction = null, BlockToken? rootToken = null)
            : base(serialize, NodeType.Array, null, name) {
            _reader = reader;
            _disposedAction = disposedAction;
            _rootToken = rootToken ?? this;

            var token = _reader.Read();

            if (Value is null && token.Value != null) ChangeValue(token.Value);
            if (!Name.IsNothing) ChangeName(token.Name);
            this.AddClass(token);

            if (!token.Type.IsData()) {
                _disposedAction?.Invoke();
                ChangeType(NodeType.Value);
                return;
            }

            ChangeType(token.Type);
            if (token.Type.IsBlock()) {
                serialize = FirstRead;
            } else {
                _disposedAction?.Invoke();
            }
        }
        private Token FirstRead(TokenResolve resolve, ref Serialize serialize, Token block) {
            serialize = ReadItem;
            return ReadItem(resolve, ref serialize, block);
        }
        private Token EndRead(TokenResolve resolve, ref Serialize serialize, Token block) {
            _disposedAction?.Invoke();
            return _rootToken.ReadEndBlock(resolve, ref serialize, block);
        }
        private Token ReadItem(TokenResolve resolve, ref Serialize serialize, Token block) {
            var retVal = _reader.Read();
            if ((retVal.Type.IsEndBlock() || retVal.IsDummy) && (block == _rootToken)) {
                return EndRead(resolve, ref serialize, block);
            }
            return block.AddItem(new Token(retVal.Potential));
        }
    }
}
