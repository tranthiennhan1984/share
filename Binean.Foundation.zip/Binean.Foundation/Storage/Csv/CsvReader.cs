﻿using System.Globalization;

namespace Binean.Foundation.Storage {
    [Avatar]
    public sealed class CsvReader : Reader {
        public readonly CsvLexer _lexer;
        private int _columnIndex;
        private Func<BID, bool> _isSelected = s => true;

        public CsvReader(ICharacterInput reader, Action? disposedAction = null, NodeType beginType = NodeType.Array) {
            Headers = [];
            var rootToken = new Token(beginType);
            _lexer = new CsvLexer(reader);
            _lexer.MoveNext();
            Initialize(rootToken, _lexer.IsEnd ? ReadEof : ReadBeginTable, disposedAction);
        }

        [AvatarProperty]
        public string? Location {
            get { return _lexer.Location; }
            set { _lexer.Location = value; }
        }

        [AvatarProperty]
        public object Position => _lexer.Position;

        [AvatarProperty]
        public bool HasHeaders { get; set; }

        [AvatarProperty]
        public string HeaderTemplate { get; set; } = "Column{0}";

        [AvatarProperty]
        public char DecimalSeparator { get; set; } = CultureInfo.CurrentCulture.NumberFormat.CurrencyDecimalSeparator[0];
        public List<BID> Headers { get; }

        [AvatarProperty]
        public BSet Select { get; } = Prior.CreateSortedBSet();

        private Token ReadBeginTable(TokenResolve resolve, ref Serialize serialize, Token block) {
            serialize = ReadEof;
            var symbol = _lexer.Current;
            if (symbol == Symbol.Eof) return ReadEof(resolve, ref serialize, block);
            if (HasHeaders) ReadHeader();

            if (_lexer.Current == Symbol.Eof) return ReadEof(resolve, ref serialize, block);
            if (Select.Count > 0) _isSelected = Select.Contains;

            serialize = ReadBeginRow;
            return block.NewToken(NodeType.Array);
        }
        private Token ReadBeginRow(TokenResolve resolve, ref Serialize serialize, Token block) {
            var symbol = _lexer.Current;
            if (symbol == Symbol.Eof) {
                serialize = ReadEof;
                return block.EndToken();
            }
            _columnIndex = 0;
            serialize = ReadCell;
            return block.NewToken(NodeType.Object);
        }
        private Token ReadCell(TokenResolve resolve, ref Serialize serialize, Token block) {
            Symbol symbol;
            while ((symbol = _lexer.Current) != Symbol.Eof) {
                _lexer.MoveNext();
                if (symbol == CsvLexer.NewLineSymbol) {
                    serialize = ReadBeginRow;
                    return block.EndToken();
                }
                var header = ReadHeader(_columnIndex);
                var isSelected = _isSelected(header);

                if (symbol == CsvLexer.CommaSymbol) {
                    _columnIndex++;
                    if (!isSelected) return ReadCell(resolve, ref serialize, block);
                    return block.NewToken(NodeType.Value, null, header);
                }
                if (_lexer.Current.IsType(CsvSymbol.Comma)) {
                    _columnIndex++;
                    _lexer.MoveNext();
                }

                if (!isSelected) return ReadCell(resolve, ref serialize, block);

                if (symbol.Type == CsvSymbol.Text) return block.NewToken(NodeType.Value, symbol.Text, header);
                return block.NewToken(NodeType.Value, ToValue(symbol.Text), header);
            }
            serialize = ReadBeginRow;
            return block.EndToken();
        }
        public object ToValue(string text) {
            if (string.IsNullOrWhiteSpace(text)) return text;
            if (!char.IsDigit(text[0]) || text.Length > 30) return text;
            if (text.Contains(DecimalSeparator) && double.TryParse(text, out double db)) return db;
            if (int.TryParse(text, out int n)) return n;
            return text;
        }
        private BID ReadHeader(int columnIndex) {
            BID header;
            if (columnIndex < Headers.Count) header = Headers[columnIndex];
            else {
                while (Headers.Count <= columnIndex) {
                    Headers.Add((BID)string.Format(HeaderTemplate, Headers.Count));
                }
                header = Headers[columnIndex];
            }
            return header;
        }
        private void ReadHeader() {
            Symbol symbol;
            while ((symbol = _lexer.Current) != Symbol.Eof) {
                _lexer.MoveNext();
                if (symbol.IsType(CsvSymbol.NewLine)) break;
                if (symbol.IsType(CsvSymbol.Comma)) continue;
                var text = symbol.Text;
                if (string.IsNullOrWhiteSpace(text)) text = string.Format(HeaderTemplate, Headers.Count);
                Headers.Add((BID)text);
            }

        }
    }
}
