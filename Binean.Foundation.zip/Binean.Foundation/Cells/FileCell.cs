﻿using Binean.Foundation.Primitive;
using System.Net.NetworkInformation;

namespace Binean.Foundation.Cells {
    [Avatar]
    public sealed partial class FileCell(string? location) : Cell, IValidator {
        public FileCell() : this(null) { }

        [AvatarProperty]
        public string Location {
            get => _location;
            set => _location = value.AssertPath();
        }
        private string _location = (location ?? string.Empty).AssertPath();

        public BID Format {
            get => PotentialGetDelegate.Get(Properties.Format, FormatNames.cen);
            set => PotentialSetDelegate.Set(Properties.Format, value);
        }

        public bool IsReadOnly {
            get => PotentialGetDelegate.Get(Properties.IsReadonly, false);
            set => PotentialSetDelegate.Set(Properties.IsReadonly, value);
        }

        [AvatarMethod]
        public bool Mount(IMessage message) {
            if (!this.Get(Properties.Mountable, false)) return message.Forbidden();

            if (!message.TryUnboxRequest(out FileCnArgs? args)) {
                return message.Return(CloneInfo());
            }

            if (args.Folder is not string location || string.IsNullOrWhiteSpace(location)) {
                if (args.Path is not string path || string.IsNullOrWhiteSpace(path))
                    return message.BadRequest(nameof(Logs.BFND70101E));
                if (Path.GetDirectoryName(path.AssertPath(Location)) is not string fd || string.IsNullOrWhiteSpace(fd))
                    return message.BadRequest(nameof(Logs.BFND70101E));
                location = fd;
            } else location = location.AssertPath(Location);

            if (!Directory.Exists(location)) {
                Directory.CreateDirectory(location);
            }

            Location = location;
            return message.Return(CloneInfo());
        }
        [AvatarMethod]
        public bool Connect(IMessage message, FileCnArgs args) {
            if (args.Folder is not string location || string.IsNullOrWhiteSpace(location)) {
                if (args.Path is not string path || string.IsNullOrWhiteSpace(path))
                    return message.BadRequest(nameof(Logs.BFND70101E));
                if (Path.GetDirectoryName(path.AssertPath(Location)) is not string fd || string.IsNullOrWhiteSpace(fd))
                    return message.BadRequest(nameof(Logs.BFND70101E));
                location = fd;
            } else location = location.AssertPath(Location);

            var isReadOnly = this.Get(Properties.IsReadonly, false);
            if (!Directory.Exists(location)) {
                if (isReadOnly || !args.CreateIfNotExist) return message.NoContent();
                Directory.CreateDirectory(location);
            }
            return message.Return(new FileCell(location).Set(Properties.IsReadonly, isReadOnly).Set(Properties.Format, Format));
        }
        [AvatarMethod]
        public bool Info(IMessage message, FileHdArgs args) {
            if (args.Path is not string filePath || string.IsNullOrWhiteSpace(filePath))
                return message.BadRequest(nameof(Logs.BFND70101E));

            var ext = Path.GetExtension(filePath);
            if (string.IsNullOrWhiteSpace(ext)) {
                ext = Format;
                filePath = Path.ChangeExtension(filePath, $".{ext}");
            }
            var fileInfo = new FileInfo(filePath);
            if (!fileInfo.Exists) return message.NotFound();

            return args.NameOnly ? message.Return(fileInfo.FullName)
                : message.Return(ToFileInfo(fileInfo));
        }

        [AvatarMethod]
        public bool List(IMessage message, FileLsArgs? args) {
            args ??= new FileLsArgs();
            if (args.Path is not string path) path = Location;
            else path = path.AssertPath(Location);

            if (File.Exists(path)) path = Path.GetDirectoryName(path).AssertPath(Location);
            if (!Directory.Exists(path)) return message.NoContent();

            var nameOnly = args.NameOnly;
            var retVal = Prior.CreateList();
            if (args.ListType == FileListType.Folder) {
                var list = Directory.GetDirectories(path, args.Filter ?? "*.*", args.FindAll ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);
                foreach (var item in list) {
                    var dirInfo = new DirectoryInfo(item);
                    if (!dirInfo.Exists) continue;
                    if (nameOnly) retVal.Add(Path.GetFileNameWithoutExtension(item));
                    else retVal.Add(ToDirInfo(dirInfo));
                }
            } else {
                var list = Directory.GetFiles(path, args.Filter ?? "*.*", args.FindAll ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);
                foreach (var item in list) {
                    var fileInfo = new FileInfo(item);
                    if (!fileInfo.Exists) continue;
                    if (nameOnly) retVal.Add(Path.GetFileNameWithoutExtension(item));
                    else retVal.Add(ToFileInfo(fileInfo));
                }
            }
            return message.Return(retVal);
        }
        [AvatarMethod]
        public bool Read(IMessage message, FileRdArgs args) {
            if (args.Path is not string filePath || string.IsNullOrWhiteSpace(filePath))
                return message.BadRequest(nameof(Logs.BFND70101E));

            filePath = filePath.AssertPath(Location);

            var fmt = args.Format;
            var ext = Path.GetExtension(filePath).TrimStart('.');
            if (fmt.IsNothing) fmt = string.IsNullOrWhiteSpace(ext) ? Format : (BID)ext;
            if (string.IsNullOrWhiteSpace(ext)) filePath = Path.ChangeExtension(filePath, $".{(string)fmt}");

            if (!File.Exists(filePath)) return message.Conflict(nameof(Logs.BFND70103E), filePath);

            var contentType = args.Type;
            if (contentType == ContentType.Text || string.Compare(fmt, "txt", true) == 0) {
                return message.Return(File.ReadAllText(filePath));
            }
            if (contentType == ContentType.Blob) {
                return message.Return(File.ReadAllBytes(filePath));
            }
            if (contentType == ContentType.Stream) {
                return message.Return(File.OpenRead(filePath));
            }

            if (this.GetFormat(fmt) is not IFormat format) return message.BadRequest(nameof(Logs.BFND70102E), fmt);

            if (contentType == ContentType.Reader) {
                return message.Return(format.Serialize(File.OpenRead(filePath).CreateTextReader(), args.Configs).Assert());
            }

            using (var stream = File.OpenRead(filePath)) {
                using (var reader = format.Serialize(stream, args.Configs).Assert()) {
                    reader.As<ISettable>()?.Set(Properties.Location, filePath, false);
                    if (args.TmplArgs is IGetter tmplArgs) reader.TemplateArgs = tmplArgs;
                    return message.Return(Men.ToObject(reader));
                }
            }
        }
        [AvatarMethod]
        public bool Create(IMessage message, FileUdArgs args) => InUpdate(message, args, create: true);
        [AvatarMethod]
        public bool Update(IMessage message, FileUdArgs args) => InUpdate(message, args);
        [AvatarMethod]
        public bool Replace(IMessage message, FileUdArgs args) => InUpdate(message, args, replace: true);

        [AvatarMethod]
        public bool Delete(IMessage message, FileArgs args) {
            if (args.Path is not string filePath || string.IsNullOrWhiteSpace(filePath))
                return message.BadRequest(nameof(Logs.BFND70101E));

            filePath = filePath.AssertPath(Location);

            var ext = Path.GetExtension(filePath);
            if (string.IsNullOrWhiteSpace(ext)) filePath = Path.ChangeExtension(filePath, $".{Format}");

            if (!File.Exists(filePath)) return message.Conflict(nameof(Logs.BFND70103E), filePath);

            File.Delete(filePath);
            return message.Return(filePath);
        }

        private bool InUpdate(IMessage message, FileUdArgs args, bool replace = false, bool create = false) {
            if (this.Get(Properties.IsReadonly, false)) return message.NotFound();
            if (!Directory.Exists(Location)) Directory.CreateDirectory(Location);

            if (args.Path is not string filePath || string.IsNullOrWhiteSpace(filePath))
                return message.BadRequest(nameof(Logs.BFND70101E));

            filePath = filePath.AssertPath(Location);

            if (create && Directory.Exists(filePath)) return message.NotFound();

            var fmt = args.Format;
            var ext = Path.GetExtension(filePath).TrimStart('.');
            if (fmt.IsNothing) fmt = string.IsNullOrWhiteSpace(ext) ? Format : (BID)ext;
            if (string.IsNullOrWhiteSpace(ext)) filePath = Path.ChangeExtension(filePath, $".{ext = (string)fmt}");

            if (create && File.Exists(filePath)) return message.NotFound();
            if (create) replace = true;
            if (!replace && !File.Exists(filePath)) return message.Conflict(nameof(Logs.BFND70103E), filePath);

            var contentType = args.Type;
            if (contentType == ContentType.Text || string.Compare(fmt, "txt", true) == 0) {
                File.WriteAllText(filePath, args.Content.As(() => string.Empty));
                return message.Return(filePath);
            }
            if (contentType == ContentType.Blob) {
                if (args.Content is byte[] content) File.WriteAllBytes(filePath, content);
                else File.WriteAllText(filePath, string.Empty);
                return message.Return(filePath);
            }
            if (contentType == ContentType.Stream) {
                if (args.Content is Stream stream) {
                    stream.Seek(0, SeekOrigin.Begin);
                    using (var ws = File.Create(filePath)) {
                        stream.CopyTo(ws);
                    }
                } else File.WriteAllText(filePath, string.Empty);
                return message.Return(filePath);
            }

            if (this.GetFormat(fmt) is not IFormat format) return message.BadRequest(nameof(Logs.BFND70102E), fmt);

            Reader? reader = null;
            if (contentType == ContentType.Reader) reader = args.Content.As<Reader>();
            reader ??= Men.Serialize(args.Content).Assert();

            var configs = args.Configs;
            using (var stream = File.Create(filePath)) {
                using (var writer = format.Deserialize(stream, configs).Assert()) {
                    writer.As<ISettable>()?.Set(Properties.Location, filePath, false);
                    writer.Write(reader);
                }
            }
            return message.Return(filePath);
        }

        private Entity CloneInfo() {
            var retVal = Prior.CreateSortedEntity();
            using (var writer = Men.Deserialize(retVal)) {
                using (var reader = Men.Serialize(this).Assert()) {
                    writer.Write(reader);
                }
            }
            return retVal;
        }
        private static Entity ToFileInfo(FileInfo fileInfo)
            => Prior.CreateSortedEntity()
                .Set(nameof(fileInfo.Name), fileInfo.Name)
                .Set(nameof(fileInfo.FullName), fileInfo.FullName)
                .Set(nameof(fileInfo.Length), fileInfo.Length)
                .Set(nameof(fileInfo.IsReadOnly), fileInfo.IsReadOnly)
                .Set(nameof(fileInfo.CreationTime), fileInfo.CreationTime)
                .Set(nameof(fileInfo.LastWriteTime), fileInfo.LastWriteTime)
                .Set(nameof(fileInfo.LastAccessTime), fileInfo.LastAccessTime);
        private static Entity ToDirInfo(DirectoryInfo dirInfo)
            => Prior.CreateSortedEntity()
                .Set(nameof(dirInfo.Name), dirInfo.Name)
                .Set(nameof(dirInfo.FullName), dirInfo.FullName)
                .Set(nameof(dirInfo.CreationTime), dirInfo.CreationTime)
                .Set(nameof(dirInfo.LastWriteTime), dirInfo.LastWriteTime)
                .Set(nameof(dirInfo.LastAccessTime), dirInfo.LastAccessTime);

        public bool Validate(ILogger logger) {
            Location = Location.AssertPath();
            return true;
        }
    }
    file static class Properties {
        public static readonly BID Location = Foundation.Properties.Location;
        public static readonly BID Formats = nameof(Formats);

        public static readonly BID Mountable = nameof(Mountable);
        public static readonly BID IsReadonly = nameof(IsReadonly);
        public static readonly BID Format = nameof(Format);

        public static readonly BID Folder = nameof(Folder);
        public static readonly BID CreateIfNotExist = nameof(CreateIfNotExist);
    }
    public enum ContentType {
        Object,
        Text,
        Blob,
        Stream,
        Reader,
    }

    [Avatar]
    public class FileArgs : Avatar {
        [AvatarProperty]
        public string? Path { get; set; }
    }
    [Avatar]
    public sealed class FileCnArgs : FileArgs {
        [AvatarProperty]
        public string? Folder { get; set; }
        [AvatarProperty]
        public bool CreateIfNotExist { get; set; }
    }
    [Avatar]
    public abstract class FileCmArgs : FileArgs {
        [AvatarProperty]
        public BID Format { get; set; } = BID.Nothing;
        [AvatarProperty]
        public ContentType? Type { get; set; }
        [AvatarProperty]
        public IGetter? Configs { get; set; }
    }
    [Avatar]
    public sealed class FileRdArgs : FileCmArgs {
        [AvatarProperty]
        public IGetter? TmplArgs { get; set; }
    }
    [Avatar]
    public sealed class FileUdArgs : FileCmArgs {
        [AvatarProperty]
        public object? Content { get; set; }
    }
    [Avatar]
    public class FileHdArgs : FileArgs {
        [AvatarProperty]
        public bool NameOnly { get; set; } = true;
    }
    [Avatar]
    public sealed class FileLsArgs : FileHdArgs {
        [AvatarProperty]
        public FileListType? ListType { get; set; }
        [AvatarProperty]
        public string? Filter { get; set; }
        [AvatarProperty]
        public bool FindAll { get; set; }
    }
    public enum FileListType {
        File,
        Folder
    }
}
