﻿namespace Binean.Foundation.Cells {
    [BLog]
    internal static class Logs {
        public const string BFND70101E = "Missing file path.";
        public const string BFND70102E = "Format '{0}' does not exist in current context.";
        public const string BFND70103E = "File '{0}' does not exist.";

        public const string BFND70110E = "Missing method name.";
    }
}

