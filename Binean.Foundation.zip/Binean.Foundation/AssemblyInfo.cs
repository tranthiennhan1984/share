﻿global using Binean.Foundation;
global using Binean.Foundation.Cells;
global using Binean.Foundation.Collections;
global using Binean.Foundation.Core;
global using Binean.Foundation.Flow;
global using Binean.Foundation.Logging;
global using Binean.Foundation.Primitive;
global using Binean.Foundation.Storage;

[assembly: BAssembly]