﻿namespace Binean.Foundation.Core {
    public enum ListType {
        Id,
        Name,
        Summary,
        Details
    }

    [Avatar]
    public sealed class ListArgs : Avatar {
        [AvatarProperty]
        public ListType ListType { get; set; } = ListType.Id;
    }
}

