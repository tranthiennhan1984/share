﻿namespace Binean.Foundation.Core {
    public class BError(IGetter content, Exception? innerException = null) : Exception(content.Get(Properties.Message).As<string>(), innerException) {
        public IGetter Content { get; } = content;
    }
}
