﻿namespace Binean.Foundation.Core {
    public interface ILink {
        BPath? Path { get; }
        object? Args { get; }
    }
    [Avatar]
    public class Link : Avatar, ILink {
        [AvatarProperty]
        public BPath? Path { get; set; }

        [AvatarProperty]
        public object? Args { get; set; }
    }
}
