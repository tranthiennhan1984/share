﻿namespace Binean.Foundation.Core {
    /// <summary>
    /// Request status code
    /// </summary>
    public enum BStatusCode {
        /// <summary>
        /// Shows success.
        /// </summary>
        Ok = 200,
        /// <summary>
        /// When a resource is successfully created using POST or PUT request.Returns link to the newly created resource using the location header.
        /// </summary>
        Created = 201,
        /// <summary>
        /// When response body is empty.For example, a DELETE request.
        /// </summary>
        NoContent = 204,

        /// <summary>
        /// Used to reduce network bandwidth usage in case of conditional GET requests. Response body should be empty.Headers should have date, location, etc.
        /// </summary>
        NotModified = 304,

        /// <summary>
        /// States that an invalid input is provided. For example, validation error, missing data.
        /// </summary>
        BadRequest = 400,
        /// <summary>
        /// States that user is using invalid or wrong authentication token.
        /// </summary>
        Unauthorized = 401,
        /// <summary>
        /// States that the user is not having access to the method being used. For example, Delete access without admin rights.
        /// </summary>
        Forbidden = 403,
        /// <summary>
        /// States that the method is not available.
        /// </summary>
        NotFound = 404,
        /// <summary>
        /// States conflict situation while executing the method. For example, adding duplicate entry.
        /// </summary>
        Conflict = 409,
        /// <summary>
        /// States that the server has thrown some exception while executing the method.
        /// </summary>
        InternalServerError = 500,
    }
}

