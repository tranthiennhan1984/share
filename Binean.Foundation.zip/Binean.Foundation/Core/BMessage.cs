﻿namespace Binean.Foundation.Core {
    public class BMessage : Prospect, IMessage {
        public BMessage() : this(null) { }
        public BMessage(IMessage? parent, ILogger? logger = null) : base(Prior.CreateSortedEntity()) {
            Parent = parent;
            Logger = logger ?? new MemoryLogger();

            if (parent != null) {
                (parent as BMessage)?.CompletedAction.AddFirst(InParentCompleted);
                var pL = parent.Potential;
                Potential.Set(Spaces.Public, Men.Clone(pL.Get(Spaces.Public)))
                    .Set(Spaces.Share, pL.Get(Spaces.Share));
            }
        }
        public IMessage? Parent { get; }
        public ActionList<IMessage> CompletedAction { get; } = new();

        public ILogger Logger { get; protected set; }
        public object? Response => Potential.Get(Properties.Response);
        public BStatusCode StatusCode => Potential.Get(Properties.StatusCode).As<BStatusCode>();
        public BStatus BStatus { get; protected set; }

        public void ChangeStatus(BStatus status) {
            BStatus = status switch {
                BStatus.Waiting or BStatus.Sending or BStatus.Processing => status,
                _ => throw new InvalidOperationException(),
            };
        }
        public bool Return(object? response, BStatusCode code = BStatusCode.Ok) {
            this.AssertNotCompleted();
            if (!code.IsSuccess()) throw LogStorage.CreateError(nameof(Logs.BFND10201E), nameof(Return), code);
            OnReturn(response, code);
            return true;
        }
        public bool Kill() {
            if (this.IsCompleted()) return false;
            Potential.Set(Properties.StatusCode, BStatusCode.InternalServerError);
            OnCompleted(BStatus.Terminated);
            return false;
        }
        public bool Error(BStatusCode code, IGetter? message) {
            message = message.AssertErrorMessage();
            //if (code.IsSuccess()) throw MessageStorage.CreateException(nameof(Logs.BFND10204E), nameof(Error), code);
            if (this.IsCompleted()) {
                if (!message.IsNullOrEmpty()) Logger.Log(message);
                Potential.MSet(Properties.StatusCode,()=> code);
                return false;
            }
            OnError(code, message);
            return false;
        }
        protected void OnReturn(object? response, BStatusCode code) {
            Potential.Set(Properties.Response, response);
            Potential.Set(Properties.StatusCode, code);
            OnCompleted(BStatus.Success);
        }
        protected void OnError(BStatusCode code, IGetter message) {
            Potential.Set(Properties.StatusCode, code);
            if (!message.IsNullOrEmpty()) Logger.Log(message);
            OnCompleted(BStatus.Faulted);
        }

        protected virtual void OnCompleted(BStatus status) {
            BStatus = status;
            (Parent as BMessage)?.CompletedAction.Remove(InParentCompleted);
            CompletedAction.Invoke(this);
        }
        private void InParentCompleted(IMessage parent) {
            if (!this.IsCompleted()) OnError(BStatusCode.InternalServerError, this.AssertErrorMessage());
        }
    }

    public interface IMessage : IProspect {
        IMessage? Parent { get; }
        ILogger Logger { get; }
        object? Response { get; }
        BStatusCode StatusCode { get; }
        BStatus BStatus { get; }
        void ChangeStatus(BStatus status);
        bool Return(object? response, BStatusCode code = BStatusCode.Ok);
        bool Kill();
        bool Error(BStatusCode code, IGetter? message);
    }

    file static class Properties {
        public static readonly BID Response = nameof(Response);
        public static readonly BID StatusCode = nameof(StatusCode);
    }

    public enum BStatus {
        None = 0,
        Waiting,
        Sending,
        Processing,
        Success,
        Faulted,
        Terminated
    }

    file static class Spaces {
        public static readonly BID Public = nameof(Public);
        public static readonly BID Share = nameof(Share);
    }
}