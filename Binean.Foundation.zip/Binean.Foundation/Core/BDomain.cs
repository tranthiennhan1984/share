﻿using System.Runtime.InteropServices.JavaScript;

namespace Binean.Foundation.Core {
    [Avatar]
    public class BDomain : Avatar {
        internal static readonly ConcurrentEntity _formats = new(Prior.CreateSortedEntity()
            .Set(FormatNames.ben, new Ben(FormatNames.ben))
            .Set(FormatNames.cen, new Cen(FormatNames.cen))
            .Set(FormatNames.json, new Json(FormatNames.json))
            .Set(FormatNames.ten, new Ten(FormatNames.ten))
            .Set(FormatNames.men, new Men(FormatNames.men))
            .Set(FormatNames.csv, new Csv(FormatNames.csv)));

        public BDomain() {
            Cell = new Cell();
            Cell.Set(Properties.Formats, _formats);
        }

        [AvatarProperty]
        public Cell Cell { get; }

        [AvatarProperty]
        public IGettable Formats => _formats;

        public virtual void RaiseFatalError(Exception ex) => throw ex;
    }
}
