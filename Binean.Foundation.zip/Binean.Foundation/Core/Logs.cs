﻿namespace Binean.Foundation.Core {
    [BLog]
    internal static class Logs {
        public const string BFND10101E = "Missing request path.";
        public const string BFND10102E = "Missing request method.";
        public const string BFND10103E = "Cannot convert request information to '{0}'.";
        public const string BFND10104E = "Missing context.";
        public const string BFND10105E = "Forbidden - you don't have permission to access/on this server.";
        public const string BFND10106E = "Not found.";
        public const string BFND10107E = "The request has been completed.";

        public const string BFND10111E = "Scope initialized.";

        public const string BFND10201E = "In the {0} function, status code '{1}' is not allowed.";

        public const string BFND10211E = "Missing method {0} in {1}.";
    }
}