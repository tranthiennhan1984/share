﻿namespace Binean.Foundation.Core {
    /// <summary>
    /// Base methods
    /// </summary>
    public static class BMethods {
        public static readonly BID List = nameof(List);
        public static readonly BID Read = nameof(Read);
        public static readonly BID Create = nameof(Create);
        public static readonly BID Replace = nameof(Replace);
        public static readonly BID Update = nameof(Update);
        public static readonly BID Delete = nameof(Delete);
        public static readonly BID Option = nameof(Option);
        public static readonly BID Trace = nameof(Trace);
        public static readonly BID Connect = nameof(Connect);
        public static readonly BID Mount = nameof(Mount);
        public static readonly BID Run = nameof(Run);

        public static readonly BID Load = nameof(Load);
        public static readonly BID Show = nameof(Show);
        public static readonly BID Hide = nameof(Hide);
        public static readonly BID Navigate = nameof(Navigate);
    }
}

