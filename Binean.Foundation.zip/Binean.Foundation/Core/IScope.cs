﻿namespace Binean.Foundation.Core {
    //public interface ICell : IGetter, ICell {
    //    ICell? Scope { get; }
    //    IFormat? GetFormat(BID name);
    //}
    public sealed class BScope(Cell cell, Func<BID, IFormat?> formatGetter) : ICell {
        private readonly Cell _cell = cell;
        private readonly Func<BID, IFormat?> _formatGetter = formatGetter;

        public ICell? Scope => null;
        public IReadonlyBSet Names => _cell.Names;
        public bool IsEmpty => _cell.IsEmpty;
        public IFormat? GetFormat(BID name) => _formatGetter(name);
        public bool Process(IMessage message) => _cell.Process(message);
        public bool TryGetValue(BID name, out object? value) => _cell.TryGetValue(name, out value);
    }
}
