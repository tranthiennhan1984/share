﻿using System.Collections;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;


namespace Binean.Foundation.Core {
    public static partial class Extension {

        #region :: Message Helpers ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsSuccess(this BStatusCode code)
            => code > 0 && code <= BStatusCode.NotModified;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsSuccess(this IMessage message)
            => message.StatusCode.IsSuccess();

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsCompleted(this BStatus status)
            => status == BStatus.Success || status == BStatus.Faulted || status == BStatus.Terminated;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsCompleted(this IMessage message)
            => message.BStatus.IsCompleted();


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IMessage CreateRequest(this IMessage message, bool useParentLogger = true)
            => new BMessage(message, useParentLogger ? message.Logger : null);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Faulted(this IMessage message, Exception ex) {
            Debug.WriteLine(ex);
            return message.Error(BStatusCode.InternalServerError, ex.ToMessage());
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? Response(this IMessage message, Func<object>? failback = null, bool assert = false)
            => message.IsSuccess() ? message.Response.As(failback) : assert ? throw message.AssertErrorMessage().CreateError() : failback is null ? default : failback();
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Response<T>(this IMessage message, Func<T>? failback = null, bool assert = false)
            => message.IsSuccess() ? message.Response.As(failback) : assert ? throw message.AssertErrorMessage().CreateError() : failback is null ? default : failback();


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool NoContent(this IMessage message)
            => message.Return(DBNull.Value, BStatusCode.NoContent);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Faulted(this IMessage message, BStatusCode code, BID logId, params object?[] args)
            => message.Error(code, LogStorage.GenerateLog(logId, args));

        /// <summary>
        /// Faulted because of an invalid input is provided. For example, validation error, missing data.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool BadRequest(this IMessage message, BID logId, params object?[] args)
            => message.Faulted(BStatusCode.BadRequest, logId, args);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool BadRequest(this IMessage message)
            => message.Error(BStatusCode.BadRequest, Dummy.Getter);
        /// <summary>
        /// Faulted because of conflict situation while executing the method. For example, adding duplicate entry
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Conflict(this IMessage message, BID logId, params object?[] args)
            => message.Faulted(BStatusCode.Conflict, logId, args);

        /// <summary>
        /// Faulted because the user is not having access to the method being used. For example, Delete access without admin rights.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Forbidden(this IMessage message)
            => message.Faulted(BStatusCode.Forbidden, nameof(Logs.BFND10105E));

        /// <summary>
        /// Faulted because the method is not available.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool NotFound(this IMessage message)
            => message.Faulted(BStatusCode.NotFound, nameof(Logs.BFND10106E));

        /// <summary>
        /// Faulted because the server has thrown some exception while executing the method.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool InternalServerError(this IMessage message)
            => message.Error(BStatusCode.InternalServerError, null);

        public static bool AssertError(this IMessage message) => message.IsCompleted() ? message.IsSuccess() : message.InternalServerError();
        public static IGetter AssertErrorMessage(this IGetter? msg) => msg ?? LogStorage.SomethingWrongMessage();
        public static IGetter AssertErrorMessage(this IMessage message) => message.Logger.ErrorMessage.AssertErrorMessage();

        public static bool Complete(this IMessage message, IMessage value) {
            if (value == message) return message.StatusCode.IsSuccess();
            message.AssertNotCompleted();
            switch (value.BStatus) {
                case BStatus.Success:
                    message.Return(value.Response, value.StatusCode);
                    break;
                case BStatus.Faulted:
                    message.Error(value.StatusCode, value.Logger == message.Logger ? Dummy.Getter : value.AssertErrorMessage());
                    break;
                case BStatus.Terminated:
                    message.Kill();
                    break;
            }
            return message.StatusCode.IsSuccess();
        }
        public static void AssertNotCompleted(this IMessage message) {
            if (message.IsCompleted()) throw LogStorage.CreateError(nameof(Logs.BFND10107E));
        }

        public static bool TryUnboxRequest<T>(this IMessage message, [NotNullWhen(true)] out T? args, bool allowLog = true) {
            if (message.Potential.TryGetValue(Properties.Request, out object? obj)) {
                if ((args = obj.As<T>()) != null) return true;
            }
            if (allowLog) message.Logger.Log(nameof(Logs.BFND10103E), typeof(T));
            args = default;
            return false;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? GetRequest(this IMessage message) => message.Potential.Get(Properties.Request);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IMessage Request(this IMessage message, object? args = null) {
            if (args != null) message.Potential.Set(Properties.Request, args);
            return message;
        }
        #endregion

        #region :: Process Helpers ::
        public static IMessage Execute(this object obj, BPath? path, object? args = null, IMessage? message = null, bool assertFatalError = true) {
            var msg = message is null ? Generator.Create<IMessage>() : message.CreateRequest();
            try {
                if (path.IsNullOrEmpty()) obj.Process(msg);
                else obj.Process(path, msg.Request(args), true);
                return msg;
            } finally {
                if (assertFatalError) msg.Logger.AssertFatalError();
            }
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? Process(this object obj, BPath? path, object? args = null, IMessage? message = null, Func<object?>? failback = null, bool assert = false)
            => (message = obj.Execute(path, args, message)).IsSuccess() ? message.Response.As(failback) : assert ? throw message.AssertErrorMessage().CreateError() : failback is null ? default : failback();

        public static async ValueTask<IMessage> ExecuteAsync(this object obj, BPath? path, object? args = null, IMessage? message = null, bool assertFatalError = true) {
            var msg = message is null ? Generator.Create<IMessage>() : message.CreateRequest();
            try {
                if (path.IsNullOrEmpty()) await obj.ProcessAsync(msg);
                else await obj.ProcessAsync(path, msg.Request(args), true);
                return msg;
            } finally {
                if (assertFatalError) msg.Logger.AssertFatalError();
            }
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<object?> ProcessAsync(this object obj, BPath? path, object? args = null, IMessage? message = null, Func<object?>? failback = null, bool assert = false)
            => (message = await obj.ExecuteAsync(path, args, message)).IsSuccess() ? message.Response.As(failback) : assert ? throw message.AssertErrorMessage().CreateError() : failback is null ? default : failback();
        #endregion

        #region :: Link Helpers ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IMessage Execute(this object obj, ILink link, IMessage? message = null, bool assertFatalError = true)
            => obj.Execute(link.Path, link.Args, message, assertFatalError);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? Process(this object obj, ILink link, IMessage? message = null, Func<object?>? failback = null, bool assert = false)
            => (message = obj.Execute(link.Path, link.Args, message)).IsSuccess() ? message.Response.As(failback) : assert ? throw message.AssertErrorMessage().CreateError() : failback is null ? default : failback();

        public static async ValueTask<IMessage> ExecuteAsync(this object obj, ILink link, IMessage? message = null, bool assertFatalError = true)
            => await obj.ExecuteAsync(link.Path, link.Args, message, assertFatalError);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<object?> ProcessAsync(this object obj, ILink link, IMessage? message = null, Func<object?>? failback = null, bool assert = false)
            => (message = await obj.ExecuteAsync(link.Path, link.Args, message)).IsSuccess() ? message.Response.As(failback) : assert ? throw message.AssertErrorMessage().CreateError() : failback is null ? default : failback();
        #endregion
    }
}
