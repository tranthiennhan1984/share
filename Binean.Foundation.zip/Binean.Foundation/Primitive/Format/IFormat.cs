﻿namespace Binean.Foundation.Primitive {
    public interface IFormat {
        BID Name { get; }
        Reader? Serialize(object? data, IGetter? config = null);
        Writer? Deserialize(object? data = null, IGetter? config = null);
    }
}