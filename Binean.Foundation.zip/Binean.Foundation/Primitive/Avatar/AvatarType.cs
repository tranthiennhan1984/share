﻿using Binean.Private;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using System.Xml.Linq;

namespace Binean.Foundation.Primitive {
    public delegate bool AvatarSetDelegate(object instance, object? value);
    public delegate bool AvatarGetDelegate(object instance, out object? value);
    public sealed class AvatarType : IAvatarType {
        private readonly AvatarAttribute _cea;

        public AvatarType(Type type) {
            var skipNames = Prior.CreateSortedBSet();
            _cea = LoadMembers(SysType = type, Props, skipNames, SettableNames);
            Ordered = _cea.Ordered;

            Props.Names.Lock();
            if (!skipNames.IsNullOrEmpty()) (SkipNames = skipNames).Lock();
        }

        public Type SysType { get; }
        public bool Ordered { get; }
        public IEntity Props { get; } = Prior.CreateSortedEntity();
        public IBSet? SkipNames { get; }
        public IBSet SettableNames { get; } = Prior.CreateSortedBSet();

        public IEntity? CreateEntity(object instance) => new AvatarEntity(this, instance);

        public static AvatarAttribute LoadMembers(Type type, IEntity properties, IBSet skipNames, IBSet settableNames) {
            if (type.GetCustomAttribute<AvatarAttribute>(true) is not AvatarAttribute avatarAttribute) throw new InvalidOperationException();

            var avatarMemberSet = Prior.CreateEntity();
            foreach (var mt in type.GetCustomAttributes<AvatarMemberAttribute>()) {
                avatarMemberSet.Set(mt.MemberName, mt);
            }

            foreach (var prop in type.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)) {
                BID propName = prop.Name;
                if (prop.GetCustomAttribute<AvatarPropertyAttribute>() is not AvatarPropertyAttribute att) {
                    if (!avatarMemberSet.TryGetNotNull(propName, out AvatarMemberAttribute? mt)) continue;
                    att = mt;
                }

                var avatarProperty = new AvatarProperty(att, prop);
                propName = avatarProperty.Name;
                if (att.ReadSkip) skipNames.Add(propName);
                if (!att.WriteHidden) settableNames.Add(propName);
                properties.Set(propName, new AvatarProperty(att, prop));
            }

            avatarMemberSet.Clear();
            foreach (var mt in type.GetCustomAttributes<AvatarDefineAttribute>()) {
                avatarMemberSet.Set(mt.MemberName, mt);
            }
            foreach (var prop in type.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)) {
                BID propName = prop.Name;
                if (prop.GetCustomAttribute<AvatarMethodAttribute>(true) is not AvatarMethodAttribute att) {
                    if (!avatarMemberSet.TryGetNotNull(propName, out AvatarDefineAttribute? mt)) continue;
                    att = mt;
                }

                var avatarMethod = new AvatarMethod(att, prop);
                propName = avatarMethod.Name;
                skipNames.Add(propName);
                properties.Set(propName, new AvatarMethod(att, prop));
            }

            return avatarAttribute;
        }
        public Node NodeResolve(object instance, NodeResolve resolve, ref Deserialize deserialize, Node block, Token token, bool guarantee) {
            if (!Props.TryGetNotNull(token.Name, out AvatarProperty? property)) return Node.DummyNode;
            if ((!token.Type.IsValue() || token.Value is null) && GetValue(property, instance, token) is object v) token.ChangeValue(v);

            var retVal = resolve(resolve, ref deserialize, block, token);
            if (retVal.IsDummy) return retVal;

            var name = retVal.Name;
            try {
                if (property.TrySetValue(instance, retVal.Value)) return retVal;
                if (guarantee) throw LogStorage.CreateError(nameof(Logs.BFND20206E), name, instance);
                return Node.DummyNode;
            } catch {
                if (guarantee) throw LogStorage.CreateError(nameof(Logs.BFND20206E), name, instance);
                return Node.DummyNode;
            }
        }
        private static object? GetValue(AvatarProperty property, object instance, Token token) {
            if (property.IsReadOnly) {
                property.TryGetOver(instance, out var value);
                return value;
            }
            token.Potential.MSet(HiddenProperties.SysType, () => property.PropertyType);
            return null;
        }
    }
    public interface IAvatarMember {
        BID Name { get; }
        bool TryGetValue(object instance, out object? value);
        bool TrySetValue(object instance, object? value);
        bool TryRemoveValue(object instance);
    }
    public sealed class AvatarProperty : IAvatarMember {
        private readonly object? _defaultValue;

        private readonly AvatarGetDelegate _getOver;
        private readonly AvatarGetDelegate _getter;
        private readonly AvatarSetDelegate _setter;
        private readonly AvatarRemoveDelegate _remove;

        public AvatarProperty(AvatarPropertyAttribute att, PropertyInfo prop) {
            if (prop.GetCustomAttribute<DefaultValueAttribute>() is DefaultValueAttribute defaultValue) {
                _defaultValue = defaultValue.Value;
            } else _defaultValue = prop.PropertyType.Default();
            PropertyType = prop.PropertyType;
            Attribute = att;
            if (att.ItemType != null) ItemType = att.ItemType;
            else ItemType = GetItemType(PropertyType);

            if (!string.IsNullOrWhiteSpace(att.Name)) Name = InToBID(att.Name, att.HiddenName);
            else if (att.NameCase != NameCase.NotSet) Name = InToBID(prop.Name.ToCase(att.NameCase), att.HiddenName);
            else Name = InToBID(prop.Name, att.HiddenName);

            _getter = att.ReadHidden || !prop.CanRead ? ReadFaulted : prop.BuildGetAccessor();
            if (IsReadOnly = !prop.CanWrite && prop.CanRead) {
                _getOver = prop.BuildGetAccessor();
                _setter = WriteOver;
                _remove = RemoveOver;
            } else {
                _getOver = ReadFaulted;
                _setter = att.WriteSkip ? WriteSuccess
                    : att.WriteHidden || !prop.CanWrite ? WriteFaulted
                    : prop.BuildSetAccessor() ?? WriteFaulted;
                _remove = RemoveBySetDefault;
            }
        }
        public BID Name { get; }

        public AvatarPropertyAttribute Attribute { get; }
        public Type? ItemType { get; }

        public Type PropertyType { get; }
        public bool IsReadOnly { get; }
        public bool TryGetValue(object instance, out object? value)
            => _getter.Invoke(instance, out value);
        public bool TrySetValue(object instance, object? value)
            => _setter(instance, value);
        public bool TryRemoveValue(object instance)
            => _remove(instance);

        public bool TryGetOver(object instance, out object? value)
            => _getOver.Invoke(instance, out value);
        private bool WriteOver(object instance, object? value) {
            if (!_getOver(instance, out object? v)) return false;
            if (v == value) return true;

            if (v is not ISetter s || value is not IGetter g) return false;

            s.Assign(g, false).Validate();
            return true;
        }
        private bool RemoveOver(object instance) {
            if (!_getOver(instance, out object? v)) return false;
            if (v.As<ISetter>() is ISetter s) return s.Clear();
            return false;
        }

        private bool RemoveBySetDefault(object instance)
            => _setter(instance, _defaultValue);

        private static bool ReadFaulted(object instance, out object? value) => (value = null) != null;
        private static bool WriteSuccess(object instance, object? value) => true;
        private static bool WriteFaulted(object instance, object? value) => false;

        public delegate bool AvatarRemoveDelegate(object instance);
        private static BID InToBID(string name, bool isHidden) => isHidden ? name.ToHiddenNameId() : name;
        private static Type? GetItemType(Type propertyType) {
            if (!propertyType.IsAssignableTo(typeof(IList))) return null;
            if (!propertyType.IsGenericType) return typeof(object);
            return propertyType.GetGenericArguments().Single();
        }
    }
    public sealed class AvatarMethod : IAvatarMember {
        private readonly AvatarGetDelegate _getter;
        public AvatarMethod(AvatarMethodAttribute att, MethodInfo method) {
            _getter = method.BuildGetProcAccessor(out Type? reqType, out bool nullable);
            RequestType = reqType;
            RequestNullable = nullable;
            if (!string.IsNullOrWhiteSpace(att.Name)) Name = InToBID(att.Name, att.HiddenName);
            else if (att.NameCase != NameCase.NotSet) Name = InToBID(method.Name.ToCase(att.NameCase), att.HiddenName);
            else Name = InToBID(method.Name, att.HiddenName);
        }
        public BID Name { get; }
        public Type? RequestType { get; }
        public bool RequestNullable { get; }
        public bool TryGetValue(object instance, out object? value) => _getter(instance, out value);
        public bool TrySetValue(object instance, object? value) => false;
        public bool TryRemoveValue(object instance) => false;

        private static BID InToBID(string name, bool isHidden) => isHidden ? name.ToHiddenNameId() : name;
    }
}