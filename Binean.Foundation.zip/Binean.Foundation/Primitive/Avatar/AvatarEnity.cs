﻿using System.Collections;

namespace Binean.Foundation.Primitive {
    public sealed class AvatarEntity : IEntity, IValidator, IEnumerable<Unit> {
        private readonly AvatarType _avatarType;
        private readonly object _instance;

        public AvatarEntity(AvatarType avatarType, object instance) {
            _avatarType = avatarType;
            _instance = instance;
            ClassList.AddClass(avatarType.SysType);
        }

        public Type SysType => _avatarType.SysType;
        public bool IsEmpty => false;
        public IReadonlyBSet Names => _avatarType.Props.Names;

        public BList ClassList { get; } = Prior.CreateUniqueBList();

        public bool TryGetValue(BID bid, out object? value) {
            if (bid.IsNothing || !_avatarType.Props.TryGetNotNull(bid, out IAvatarMember? property)) return (value = null) != null;
            return property.TryGetValue(_instance, out value);
        }
        public bool TrySetValue(BID bid, object? value) {
            if (bid.IsNothing || !_avatarType.Props.TryGetNotNull(bid, out IAvatarMember? property)) return false;
            if (value is DBNull) return property.TryRemoveValue(_instance);
            return property.TrySetValue(_instance, value);
        }
        public bool Clear() {
            foreach (var unit in _avatarType.Props.GetUnits()) {
                if (unit.Value is not IAvatarMember property) continue;
                property.TryRemoveValue(_instance);
            }
            return true;
        }
        public bool TryRemoveValue(BID name) {
            if (!_avatarType.Props.TryGetNotNull(name, out IAvatarMember? property)) return false;
            return property.TryRemoveValue(_instance);
        }

        public bool Validate(ILogger logger) => (_instance as IValidator)?.Validate(logger) ?? true;

        public List<Unit> GetUnits() {
            var retVal = new List<Unit>();
            foreach (var unit in _avatarType.Props.GetUnits()) {
                if (unit.Value is not AvatarProperty prop) continue;
                var att = prop.Attribute;
                if (att.ReadHidden) continue;
                if (att.ReadSkip) continue;
                else retVal.Add(new Unit(unit.Name, prop.TryGetValue(_instance, out object? v) ? v : null));
            }
            return retVal;
        }
        public IEnumerator<Unit> GetEnumerator() => ((IEnumerable<Unit>)GetUnits()).GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetUnits().GetEnumerator();
    }
}