﻿namespace Binean.Foundation.Primitive {
    public abstract class AvatarInfo(Type sysType, AvatarAttribute avaAtt) : IBoxable {
        public AvatarAttribute AvatarAttribute { get; } = avaAtt;
        public Type SysType { get; } = sysType;
        public DateTime LastGetTime { get; protected set; } = DateTime.Now;

        public Entity GetData() {
            LastGetTime = DateTime.Now;
            return OnGetData();
        }
        protected abstract Entity OnGetData();
        protected Entity GenerateData() {
            var retVal = Prior.CreateSortedEntity();
            retVal.Set(HiddenProperties.SysType, SysType);
            if (AvatarAttribute.AvatarType?.As<Type>() is Type t && Generator.CreateInstance(t) is IAvatarType avatarType) {
                retVal.Set(HiddenProperties.AvatarType, avatarType);
            } else retVal.Set(HiddenProperties.AvatarType, new AvatarType(SysType));

            return retVal;
        }

        public IAvatarType? GetAvatarType()
            => GetData().TryGetNotNull(HiddenProperties.AvatarType, out IAvatarType? avatarType) ? avatarType : null;

        public IEntity Box() => GetData();
        public void Unbox(IEntity data) => throw new NotSupportedException();
    }

}