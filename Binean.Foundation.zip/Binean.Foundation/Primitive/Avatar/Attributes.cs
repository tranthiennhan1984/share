﻿namespace Binean.Foundation.Primitive {
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = true)]
    public class AvatarAttribute : Attribute {
        public Type? AvatarType { get; set; }
        public bool Persistent { get; set; }
        public bool Ordered { get; set; }
    }

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class AvatarPropertyAttribute : Attribute {
        public bool ReadHidden { get; set; }
        public bool ReadSkip { get; set; }
        public bool WriteHidden { get; set; }
        public bool WriteSkip { get; set; }
        public string? Description { get; set; }

        public string? Name { get; set; }
        public bool HiddenName { get; set; }
        public NameCase NameCase { get; set; }

        public Type? ItemType { get; set; }
    }

    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true, Inherited = true)]
    public class AvatarMemberAttribute : AvatarPropertyAttribute {
        public string MemberName { get; set; } = default!;
    }

    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public class AvatarMethodAttribute : Attribute {
        public string? Name { get; set; }
        public bool HiddenName { get; set; }
        public NameCase NameCase { get; set; }
    }

    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public class AvatarDefineAttribute : AvatarMethodAttribute {
        public string MemberName { get; set; } = default!;
    }
}
