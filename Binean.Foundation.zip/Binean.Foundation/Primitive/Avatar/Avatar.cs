﻿using System;
using System.Collections;
using System.Xml.Linq;

namespace Binean.Foundation.Primitive {
    public class Avatar : IEntity, IEnumerable<Unit> {
        private readonly BSet _names = new(true);
        private readonly List<object?> _values = Prior.CreateList();

        public Avatar(ClassType classType = ClassType.Type) : this(classType, true) { }
        public Avatar(ClassType classType, bool configuration) {
            this.ClassList().AddClass(GetType(), classType);
            if (configuration) OnConfiguration(true, true);
        }

        public bool IsEmpty => _values.Count == 0;
        public IReadonlyBSet Names => _names;

        public Entity AvatarProperties { get; } = Prior.CreateSortedEntity();

        protected BSet ImmutableNames { get; } = new(true);

        public virtual bool TryGetValue(BID name, out object? value) {
            if (AvatarProperties.Get(name) is AvatarProperty avatarProperty) {
                var att = avatarProperty.Attribute;
                if (!att.ReadHidden) return avatarProperty.TryGetValue(this, out value);
            }
            return TryGetPotentialValue(name, out value);
        }
        public virtual bool TrySetValue(BID name, object? value) {
            if (ImmutableNames.Find(name, out _)) return false;
            if (AvatarProperties.Get(name) is AvatarProperty avatarProperty) {
                if (avatarProperty.IsReadOnly) return false;
                var att = avatarProperty.Attribute;
                if (!att.WriteHidden) return avatarProperty.TrySetValue(this, value);
            }
            return TrySetPotentialValue(name, value);
        }

        public bool Clear() {
            if (_names.IsReadOnly) return false;

            var length = _names.Count;
            for (int i = 0; i <= length; i++) {
                var name = _names[i];
                if (ImmutableNames.Count > 0 && ImmutableNames.Find(name, out _)) continue;
                _names.RemoveAt(i);
                _values.RemoveAt(i);
                i--;
                length--;
            }

            foreach (var item in AvatarProperties.GetValues()) {
                if (item is not AvatarProperty avatarProperty) continue;
                avatarProperty.TryRemoveValue(this);
            }
            return true;
        }
        public virtual bool TryRemoveValue(BID name) {
            if (_names.IsReadOnly || ImmutableNames.Find(name, out _)) return false;
            if (AvatarProperties.Get(name) is AvatarProperty avatarProperty) avatarProperty.TryRemoveValue(this);
            if (!_names.Find(name, out int index)) return false;
            _names.RemoveAt(index);
            _values.RemoveAt(index);
            return true;
        }

        public GetDelegate PotentialGetDelegate => TryGetPotentialValue;
        public SetDelegate PotentialSetDelegate => TrySetPotentialValue;
        public SetDelegate ImmutableSetDelegate => ImmutableSetValue;

        protected bool TrySetPotentialValue(BID name, object? value) {
            if (_names.IsReadOnly || name.IsNothing) return false;

            if (_names.Find(name, out int index)) {
                if (value is DBNull) {
                    _names.RemoveAt(index);
                    _values.RemoveAt(index);
                } else {
                    _values[index] = value;
                }
                return true;
            }

            if (value is DBNull) return true;

            _values.Insert(_names.Add(name), value);
            return true;
        }
        protected bool TryGetPotentialValue(BID name, out object? value)
            => (!name.IsNothing && _names.Count > 0
                && _names.Find(name, out int index)
                && (value = _values[index]) is not DBNull) || (value = null) != null;

        protected bool ImmutableSetValue(BID name, object? value) {
            if (ImmutableNames.Find(name, out _)) return false;
            if (AvatarProperties.Names.Find(name, out _)) return false;
            if (!TrySetPotentialValue(name, value)) return false;
            ImmutableNames.Add(name);
            return true;
        }

        protected virtual void OnConfiguration(bool configProperties, bool configMethod) {
            if (GetType().GetAvatarInfo() is not AvatarInfo info || info.GetAvatarType() is not IAvatarType avatarType) return;
            foreach (var unit in avatarType.Props.GetUnits()) {
                if (configProperties && unit.Value is AvatarProperty avatarProperty) AvatarProperties.Set(unit.Name, avatarProperty);
                else if (configMethod && unit.Value is AvatarMethod avatarMethod && avatarMethod.TryGetValue(this, out object? value)) {
                    if (value is Proc proc) ImmutableSetValue(avatarMethod.Name, proc);
                    if (value is ProcAsync procAsync) ImmutableSetValue(avatarMethod.Name, procAsync);
                }
            }
            AvatarProperties.Names.Lock();
        }

        public List<Unit> GetUnits() {
            var visited = Prior.CreateSortedBSet();
            var retVal = new List<Unit>();
            foreach (var unit in AvatarProperties) {
                if (unit.Value is not AvatarProperty prop) continue;
                var att = prop.Attribute;
                if (att.ReadHidden) continue;
                if (att.ReadSkip) visited.Add(unit.Name);
                else retVal.Add(new Unit(unit.Name, prop.TryGetValue(this, out object? v) ? v : null));
            }
            var length = _values.Count;
            for (int i = 0; i < length; i++) {
                var name = _names[i];
                if (visited.Contains(name)) continue;
                retVal.Add(new Unit(_names[i], _values[i]));
            }
            return retVal;
        }
        public IEnumerable GetValues() => _values;

        public IEnumerator<Unit> GetEnumerator() => ((IEnumerable<Unit>)GetUnits()).GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetUnits().GetEnumerator();
    }
}