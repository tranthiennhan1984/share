﻿
namespace Binean.Foundation.Primitive {
    public interface IAvatarType {
        IBSet? SkipNames { get; }
        IBSet SettableNames { get; }

        bool Ordered { get; }
        IEntity Props { get; }

        IEntity? CreateEntity(object instance);
        Node NodeResolve(object instance, NodeResolve resolve, ref Deserialize deserialize, Node block, Token token, bool guarantee);
    }
}