﻿using Binean.Foundation.Storage;
using Binean.Private;
using System.Diagnostics;

namespace Binean.Foundation.Primitive {
    [Avatar]
    public abstract class Writer : IDisposable {
        private readonly List<Node> _stack = [];
        private readonly NodeResolve _resolve;

        private Action? _disposedAction;
        protected Node? _rootNode;
        private Deserialize _deserialize;
        private Node? _blockNode;

        internal protected object? _content;

        protected Writer() {
            _resolve = OnNodeResolve;
            _deserialize = WriteException;
            Ordered = false;
        }

        ~Writer() {
            Dispose(false);
        }
        public void Dispose() {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing) {
            if (disposing) {
                if (_disposedAction != null) {
                    _disposedAction.Invoke();
                    _disposedAction = null;
                }
            }
        }

        public bool CanContinue { get; protected set; }

        [AvatarProperty]
        public bool Ordered { get; set; }

        public IEntity Context { get; private set; } = Dummy.Entity;

        private bool InWrite(Token token) {
            var isContext = token.Potential.Get(TokenProperties.Context, false);
            if (isContext && token.Type.IsValue()) {
                OnWriteContext(token);
                return true;
            }

            if (!CanContinue) {
                _deserialize = WriteException;
                return false;
            }

            if (_blockNode is null || token is null || token.IsDummy) return Clear();

            var node = isContext ? OnWriteBeginContext(_resolve, ref _deserialize, _blockNode, token)
                : OnDeserialize(_resolve, ref _deserialize, _blockNode, token);
            var nodeType = node.Type;
            if (nodeType.IsBlock()) {
                Debug.Assert(_blockNode != null);
                _stack.Add(_blockNode);
                (_blockNode = node).Potential.Names.Lock();
                return true;
            }
            if (nodeType.IsEndBlock()) {
                Debug.Assert(_blockNode != null);
                if (_blockNode.Level == -1) return Clear();
                var index = _stack.Count - 1;
                var cNode = _stack[index];
                _stack.RemoveAt(index);
                (_blockNode = cNode).Potential.Names.Lock();
                return true;
            }
            if (node.IsDummy) return Clear();
            return true;
        }

        private bool Clear() {
            _stack.Clear();
            _blockNode = null;
            _deserialize = WriteException;
            CanContinue = false;
            return true;
        }

        protected void Initialize(Node rootNode, Deserialize deserialize, Action? disposedAction) {
            if (_rootNode != null || _disposedAction != null) throw LogStorage.CreateError(nameof(Logs.BFND20223E));

            _disposedAction = disposedAction;
            _deserialize = deserialize;

            _stack.Clear();
            (_rootNode = rootNode).Potential.Names.Lock();
            _blockNode = _rootNode;
            CanContinue = _blockNode != null;
        }

        public bool Write(Token token) {
            using (token.ContextScope(Context)) {
                return InWrite(token);
            }
        }
        public virtual void PrepareContext(Reader reader, IGetter? source = null) {
            Context = source == null ? Prior.CreateSortedEntity() : new DependencyEntity(source, Prior.CreateSortedEntity());
            if (reader.Ordered != Ordered) OnWriteContext(new Token(NodeType.Value, reader.Ordered, TokenProperties.Ordered).PSet(TokenProperties.Context, true));
            else Context.Set(TokenProperties.Ordered, Ordered);
        }
        public virtual void Write(Reader reader) {
            if (reader.IsNullOrEmpty() || !CanContinue) return;
            var token = reader.Read();
            if (token.IsDummy) return;

            token.AssertLevel(0);

            PrepareContext(reader);
            if (!Write(token)) return;

            while (reader.CanRead && CanContinue) {
                token = reader.Read();
                if (!Write(token) || token.IsDummy) break;
            }
        }

        protected virtual void OnWriteContext(Token token) {
            var name = token.Name;
            if (name.IsNothing) return;

            if (token.Potential.Get(TokenProperties.Append, false)) {
                if (!Context.TryGetNotNull(token.Name, out IEntity? ent)) {
                    ent = Prior.CreateSortedEntity();
                    Context.Set(token.Name, ent);
                }
                if (token.Value is IGetter gt) ent.Assign(gt);
            } else Context.Set(token.Name, token.Value);
            return;
        }
        protected virtual Node OnWriteBeginContext(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            token.AssertTokenType(NodeType.Object);
            var name = token.Name;
            if (name.IsNothing) return block.AddItem(token.Skip(ref deserialize));

            IEntity? ent;
            if (token.Potential.Get(TokenProperties.Append, false)) {
                if (!Context.TryGetNotNull(name, out ent)) {
                    Context.Set(name, ent = Prior.CreateSortedEntity());
                } else if (Context is DependencyEntity dpe && !dpe.Entity.Contains(name)) {
                    Context.Set(name, ent = new DependencyEntity(ent));
                }
            } else Context.Set(name, ent = Prior.CreateSortedEntity());

            return block.AddItem(new ContextNode(ent, ref deserialize, token));
        }

        protected virtual void Close() { }
        protected virtual Node OnDeserialize(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token)
            => deserialize(resolve, ref deserialize, block, token);

        protected virtual Node OnNodeResolve(NodeResolve resolve, ref Deserialize deserialize, Node block, Token node) => Node.DummyNode;

        public object? GetContent() {
            Close();
            return _content;
        }
        public Node WriteEof(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            Debug.Assert(resolve != null);
            Debug.Assert(block != null);
            Debug.Assert(token != null);
            deserialize = WriteException;
            return Node.DummyNode;
        }
        public Node WriteException(NodeResolve resolve, ref Deserialize deserialize, Node block, Token token) {
            deserialize = WriteException;
            throw this.CreateException(nameof(Logs.BFND20401E));
        }
        public static Writer CreateDummy(Action? disposedAction = null)
            => new DummWriter(disposedAction);
    }
}
