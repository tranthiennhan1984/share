﻿namespace Binean.Foundation.Primitive {
    public interface IBoxable {
        IEntity Box();
        void Unbox(IEntity data);
    }
    public interface IValidator {
        bool Validate(ILogger logger);
    }
    public interface ISerializable {
        Node Write(ref Deserialize deserialize, Node block, string name);
        Token Read(ref Serialize serialize, Token block, string name);
    }

    public delegate bool ValidationDelegate(ILogger logger);
}