﻿namespace Binean.Foundation.Primitive {
    public static class TokenProperties {
        public static readonly BID SysType = HiddenProperties.SysType;
        public static readonly BID ClassName = HiddenProperties.ClassName;

        public static readonly BID Next = HiddenProperties.Next;

        public static readonly BID Ordered = HiddenProperties.Ordered;
        public static readonly BID Context = HiddenProperties.Context;
        public static readonly BID Append = HiddenProperties.Append;
    }
}
