﻿using Binean.Private;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace Binean.Foundation.Primitive {
    static partial class Extension {
        #region :: NodeType Helpers ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsBlock(this NodeType nodeType) => nodeType == NodeType.Object || nodeType == NodeType.Array;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsEndBlock(this NodeType nodeType) => nodeType == NodeType.End;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsArray(this NodeType nodeType) => nodeType == NodeType.Array;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsObject(this NodeType nodeType) => nodeType == NodeType.Object;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsValue(this NodeType nodeType) => nodeType == NodeType.Value;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsData(this NodeType nodeType) => nodeType == NodeType.Value || nodeType == NodeType.Object || nodeType == NodeType.Array;
        #endregion

        #region :: Token Helper ::

        [DebuggerStepThrough]
        [Conditional("DEBUG")]
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void AssertLevel(this Token token, int expected)
            => Debug.Assert(token.Level == expected);

        [DebuggerStepThrough]
        [Conditional("DEBUG")]
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void AssertTokenType(this Token token, NodeType expected)
            => Debug.Assert(token.Type == expected);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BID AssertTokenName(this Node block, BID name) {
            var tokenType = block.Type;
            if (tokenType.IsObject() && name.IsNothing) throw LogStorage.CreateError(nameof(Logs.BFND20204E));
            if (tokenType.IsArray() && !name.IsNothing) throw LogStorage.CreateError(nameof(Logs.BFND20205E));
            return name;
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Node Skip(this Token token, ref Deserialize deserialize) {
            var tokenType = token.Type;
            if (tokenType.IsValue()) return new Node(token.To<IEntity>());
            if (tokenType.IsBlock()) return new DummyNode(ref deserialize, token.Type, token.Name);
            throw LogStorage.CreateError(nameof(Logs.BFND20203E), token);
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Token AddVirtualToken(this Token block, ref Serialize serialize, NodeType tokenType, BID? name = null, Serialize? next = null)
            => block.AddItem(new VirtualToken(ref serialize, tokenType, name ?? BID.Nothing, next));

        #endregion

        #region :: Reader Writer Helpers ::

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T DefineSysType<T>(this T defines, Type type) where T : IEntity
            => DefineSysType(defines, type, type);

        public static T DefineSysType<T>(this T defines, Type type, BID name) where T : IEntity {
            if (defines.IsDummy()) return defines;
            if (defines.Get(type) is not IEntity ent) defines.Get(type, ent = Prior.CreateSortedEntity());
            ent.Set(TokenProperties.SysType, type);
            if (name != type) {
                if (!defines.TryGetValue(name, out _)) defines.Set(name, ent);
                ent.Set(TokenProperties.ClassName, name);
            }
            return defines;
        }
        public static Token? CreateContextToken(this IEntity defines) {
            if (defines.IsNullOrEmpty()) return null;

            Token? retVal = null;
            Token? cur = null;
            foreach (var unit in defines.GetUnits()) {
                var token = new Token(NodeType.Value, unit.Value, unit.Name).PSet(TokenProperties.Context, true);
                if (cur == null) cur = retVal = token;
                else {
                    cur.PSet(TokenProperties.Next, token);
                    cur = token;
                }
            }
            return retVal;
        }
        #endregion
    }
}
