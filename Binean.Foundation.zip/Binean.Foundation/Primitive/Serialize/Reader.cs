﻿using Binean.Foundation.Storage;

namespace Binean.Foundation.Primitive {
    [Avatar]
    public abstract class Reader : IDisposable {
        private readonly List<Token> _stack = [];
        private readonly TokenResolve _resolve;
        private Serialize _serialize;
        private Token? _rootToken;
        private Token _token = Token.Eof;
        private Token? _blockToken;
        private Action? _disposedAction;

        protected Reader() {
            _serialize = ReadException;
            _resolve = OnTokenResolve;
        }

        ~Reader() {
            Dispose(false);
        }
        public void Dispose() {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing) {
            if (_disposedAction != null) {
                _disposedAction.Invoke();
                _disposedAction = null;
            }
        }

        [AvatarProperty]
        public IGetter TemplateArgs { get; set; } = Dummy.Getter;

        [AvatarProperty]
        public virtual bool Ordered { get; set; }

        public bool IsEmpty {
            get {
                if (_isEmpty) return true;
                if (_rootToken is null) return true;
                return false;
            }
            protected set { _isEmpty = value; }
        }
        private bool _isEmpty;

        public bool CanRead { get; protected set; }
        public int EofLevel { get; set; } = -1;

        public virtual Token Read() {
            if (_token.Type.IsBlock()) {
                if (_blockToken != null) _stack.Add(_blockToken);
                (_blockToken = _token).Potential.Names.Lock();
            } else if (_token.Type.IsEndBlock()) {
                if (_stack.Count == 0) _blockToken = null;
                else {
                    var index = _stack.Count - 1;
                    var bToken = _stack[index];
                    _stack.RemoveAt(index);
                    _blockToken = bToken;
                }
            }

            if (!CanRead) {
                _serialize = ReadException;
                return _token = Token.Eof;
            }

            if (_blockToken is null) {
                _stack.Clear();
                CanRead = false;
                _serialize = ReadException;
                return _token = Token.Eof;
            }

            _token = OnSerialize(_resolve, ref _serialize, _blockToken);

            if (_token.IsDummy) {
                if (_blockToken.Level != EofLevel) {
                    throw LogStorage.CreateError(nameof(Logs.BFND20301E), NodeType.End);
                }
                _stack.Clear();
                _blockToken = null;
                _serialize = ReadException;
                CanRead = false;
            }

            return _token;
        }

        protected void Initialize(Token rootToken, Serialize serialize, Action? disposedAction) {
            if (_token != Token.Eof || _disposedAction != null) throw LogStorage.CreateError(nameof(Logs.BFND20223E));

            _serialize = serialize;
            _disposedAction = disposedAction;
            _stack.Clear();
            _blockToken = null;
            _token = _rootToken = rootToken;
            CanRead = _token != null;
        }

        protected virtual Token OnTokenResolve(TokenResolve resolve, ref Serialize serialize, Token block, Token unit) => Token.Eof;
        protected virtual Token OnSerialize(TokenResolve resolve, ref Serialize serialize, Token block)
            => serialize(resolve, ref serialize, block);

        public Token ReadEof(TokenResolve resolve, ref Serialize serialize, Token block) {
            serialize = ReadEof;
            return Token.Eof;
        }
        public Token ReadException(TokenResolve resolve, ref Serialize serialize, Token block) {
            serialize = ReadException;
            throw LogStorage.CreateError(nameof(Logs.BFND20302E));
        }

        public static Reader CreateDummy(Action? disposedAction = null)
            => new DummyReader(disposedAction) { _isEmpty = true };
        private class DummyReader : Reader {
            public DummyReader(Action? disposedAction) {
                var rootToken = new Token(NodeType.Array);
                Serialize serialize = ReadEof;
                Initialize(rootToken, serialize, disposedAction);
            }
        }
    }
}
