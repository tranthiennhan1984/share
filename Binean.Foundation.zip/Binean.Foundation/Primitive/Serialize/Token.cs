﻿using System.Diagnostics;

namespace Binean.Foundation.Primitive {
    public class Token : Node {
        public static readonly Token Eof = new(Dummy.Entity);

        private bool _hasContext;

        public Token(NodeType type, object? value = null, BID? name = null) : base(type, value, name) { }
        public Token(IEntity ent) : base(ent) { }

        public void ChangeType(NodeType type) => Potential.Set(Properties.Type, type);
        public void ChangeName(BID name) => Potential.Set(Properties.Name, name);
        public void ChangeValue(object? value) => Potential.Set(Properties.Value, value);

        public Token NewToken(NodeType tokenType, object? value = null, BID? name = null)
            => AddItem(new Token(tokenType, value, name));
        public Token EndToken() => AddItem(new Token(_endEntity));

        public IDisposable ContextScope(IGetter context) {
            if (IsDummy || IsEnd || _hasContext || this.ClassSet() is not IReadonlyBSet set || set.Count == 0) return Dummy.Disposable;

            var oldValue = _potential;
            _hasContext = true;
            _potential = new DependencyEntity(new ValueMap().Map(context, set), oldValue);
            return Generator.CreateDisposable(() => {
                _potential = oldValue;
                _hasContext = false;
            });
        }

        public Token UpdateLevelIndex(int level, int index) {
            Level = level;
            Index = index;
            return this;
        }
    }
    public abstract class BlockToken : Token {
        private readonly Serialize _serialize;
        public BlockToken(Serialize serialize, NodeType type, object? value = null, BID? name = null)
            : base(type, value, name) {
            _serialize = serialize;
        }
        public BlockToken(Serialize serialize, IEntity ent) : base(ent) {
            _serialize = serialize;
        }

        public virtual Token ReadEndBlock(TokenResolve resolve, ref Serialize serialize, Token block) {
            Debug.Assert(block == this);
            serialize = _serialize;
            return block.EndToken();
        }
        public virtual Token ReadEof(TokenResolve resolve, ref Serialize serialize, Token block) {
            Debug.Assert(block == this);
            serialize = _serialize;
            return Eof;
        }

        protected void MoveBack(ref Serialize serialize) => serialize = _serialize;
        protected Token ReadBack(TokenResolve resolve, ref Serialize serialize, Token block)
            => _serialize(resolve, ref serialize, block);
    }
}
