﻿using Binean.Foundation.Storage;
using Binean.Private;
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;

namespace Binean.Foundation.Primitive {
    public static class Prior {
        public const char EofCharacter = '\0';
        public static readonly Func<char, bool> IsIdentifierCharacter = new(c => char.IsLetterOrDigit(c) || "_-".Contains(c));

        #region :: Constant Helpers ::
        private static readonly Func<string, string> _constCreator = BuildConstantCreator();
        private static Func<string, string> BuildConstantCreator() {
            ParameterExpression param = Expression.Parameter(typeof(string), "para");
            return Expression.Lambda<Func<string, string>>(param, param).Compile();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string ToConstant(this string name)
            => _constCreator.Invoke(name);
        #endregion

        #region :: BSet Helpers ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BSet CreateBSet(bool sorted = false) => new(sorted);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BSet CreateSortedBSet() => new(true);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BList CreateBList(bool isUnique = false) => new(isUnique);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BList CreateUniqueBList() => new(true);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Lock<T>(this T set) where T : IReadonlyBSet {
            if (set is IBSet bset) bset.IsReadOnly = true;
            return set;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Unlock<T>(this T set) where T : IReadonlyBSet {
            if (set is IBSet bset) bset.IsReadOnly = false;
            return set;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IDisposable UnlockScope(this IReadonlyBSet set)
            => set is IBSet bset ? InLockScope(bset, false) : Dummy.Disposable;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IDisposable LockScope(this IReadonlyBSet set)
            => set is IBSet bset ? InLockScope(bset, true) : Dummy.Disposable;
        private static IDisposable InLockScope(IBSet set, bool locked = false) {
            var cur = set.IsReadOnly;
            if (cur == locked) return Dummy.Disposable;
            set.IsReadOnly = locked;
            return Generator.CreateDisposable(() => set.IsReadOnly = cur);
        }
        #endregion

        #region :: Entity Helpers ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Entity CreateEntity(bool sorted = false) => new(sorted);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Entity CreateSortedEntity() => new(true);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IEntity ToHidden(this IEntity entity) => new HiddenEntity(entity);


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static List<object?> CreateList() => [];

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IGetter Lock(this IEntity entity) => new LockedEntity(entity);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IEntity? Unlock(this IGettable gettable)
            => (gettable is LockedEntity le) ? le.Source.As<IEntity>() : gettable.As<IEntity>();

        private static IGettable? InGetParent(IGettable? getter, BPath? path, out BID bid) {
            if (getter is null || path is null) {
                bid = BID.Nothing;
                return default;
            }
            if (path.Count == 0) {
                bid = BID.Nothing;
                return getter;
            }
            if (path.Count == 1) {
                bid = path[0];
                return getter;
            }
            var ent = getter;

            static IGettable? TryGettable(object? obj) => obj == null ? null : obj.As<IGettable>() ?? (obj is IList list ? new ListEntity(list) : null);

            var length = path.Count - 1;
            for (var i = 0; i < length; i++) {
                var n = path[i];
                if (TryGettable(ent.Get(n)) is not IGettable v) {
                    bid = BID.Nothing;
                    return null;
                }
                ent = v;
            }
            bid = ent is null ? BID.Nothing : path[^1];
            return ent;
        }
        public static bool TryRead(this IGettable? getter, BPath? path, out object? value) {
            var p = InGetParent(getter, path, out BID bid);
            if (p is null || bid.IsNothing) return (value = null) != null;
            return p.TryGetValue(bid, out value);
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? Read(this IGettable? getter, BPath? path)
        => TryRead(getter, path, out object? value) ? value : null;
        public static bool Delete(this IEntity? entity, BPath? path, bool guarantee = true) {
            if (InGetParent(entity, path, out BID bid).As<ISetter>() is not ISetter p) return false;
            if (bid.IsNothing) p.Clear();
            p.Remove(bid, guarantee);
            return true;
        }
        private static IEntity? InAssertParent(this IEntity? ent, BPath? path, out BID bid) {
            if (ent is null || path is null) {
                bid = BID.Nothing;
                return default;
            }
            if (path.Count == 0) {
                bid = BID.Nothing;
                return ent;
            }
            if (path.Count == 1) {
                bid = path[0];
                return ent;
            }

            static IEntity? TryEntity(object? obj) => obj == null ? null : obj.Box() ?? (obj is IList list ? new ListEntity(list) : null);

            var length = path.Count - 1;
            for (var i = 0; i < length; i++) {
                var n = path[i];
                if (TryEntity(ent.Get(n)) is not IEntity v) {
                    v = CreateEntity();
                    ent.Set(n, v);
                }
                ent = v;
            }
            bid = ent is null ? BID.Nothing : path[^1];
            return ent;
        }
        public static bool Update(this IEntity? entity, BPath? path, object? value, bool guarantee = true, bool assert = true) {
            var p = assert ? entity.InAssertParent(path, out BID bid) : InGetParent(entity, path, out bid).As<ISettable>();
            if (p is null || bid.IsNothing) return false;
            p.Set(bid, value, guarantee);
            return true;
        }

        #endregion

        #region :: Converter Helpers ::
        private static readonly Converter _converter = new();
        private static readonly object _converterLock = new();

        public static ConverterArguments ConverterArguments { get; } = new ConverterArguments();

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T To<T>(this object? value, Func<T>? failBack = null, ConverterArguments? args = null)
            => TryConvert(value, typeof(T), out object? result, args ?? ConverterArguments) && result is T t ? t
            : failBack != null ? failBack() : throw LogStorage.CreateError(nameof(Logs.BFND20102E), value?.ToString(), typeof(T));

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? As<T>(this object? value, ConverterArguments? args = null)
            => TryConvert(value, typeof(T), out object? result, args ?? ConverterArguments) && result is T t ? t : default;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? As<T>(this object? value, Func<T?>? failback, ConverterArguments? args = null)
            => TryConvert(value, typeof(T), out object? retVal, args ?? ConverterArguments) ? (T?)retVal
            : failback != null ? failback() : default;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool TryConvert(this object? value, Type destinationType, out object? result, ConverterArguments? args = null) {
            lock (_converterLock) {
                return _converter.TryConvert(value, destinationType, out result, args ?? ConverterArguments);
            }
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Register(this Conversion conversion) {
            lock (_converterLock) {
                _converter.Register(conversion);
            }
        }
        #endregion

        #region :: Avatar Helpers ::
        private static readonly ConcurrentEntity _avatars = new(CreateSortedEntity());
        private static bool _avatarRemoving;
        internal static async ValueTask ConvertToPersistencyAvatar(Type sysType, AvatarAttribute avaAtt) {
            _avatars.Set(sysType, new PersistentAvatarInfo(sysType, avaAtt));
            if (!_avatarRemoving) await CleanUpAvatars();
        }
        private static ValueTask CleanUpAvatars() {
            _avatarRemoving = true;
            var removeTime = DateTime.Now.Subtract(new TimeSpan(0, 3, 0));

            var removeList = CreateUniqueBList();
            foreach (var unit in _avatars.GetUnits()) {
                if (unit.Value is not AvatarInfo info) continue;
                if (info.LastGetTime < removeTime) removeList.Add(unit.Name);
            }

            var length = removeList.Count;
            for (int i = 0; i < length; i++) {
                _avatars.Remove(removeList[i]);
            }

            _avatarRemoving = false;
            return ValueTask.CompletedTask;
        }
        public static AvatarInfo? GetAvatarInfo(this Type type) {
            var bid = (BID)type;
            if (_avatars.TryGetNotNull(bid, out AvatarInfo? info)) return info;
            if (type.GetCustomAttribute<AvatarAttribute>() is not AvatarAttribute avaAtt) return null;
            _avatars.Set(bid, info = avaAtt.Persistent ? new PersistentAvatarInfo(type, avaAtt) : new WeakAvatarInfo(type, avaAtt));
            return info;
        }
        private static IEntity? InAvatar(object obj, IAvatarType avatarType, bool avataOnly = false) {
            var ent = avatarType.CreateEntity(obj);
            if (ent == null) return null;

            if (avataOnly) return ent;

            if (obj is Avatar avatar) {
                var skips = avatarType.SkipNames;
                return new ProspectEntity(ent, avatar, skips.IsNullOrEmpty() ? null : skips.Contains);
            } else if (obj is IProspect prospect) {
                var skips = avatarType.SkipNames;
                return new ProspectEntity(ent, prospect.Potential, skips.IsNullOrEmpty() ? null : skips.Contains);
            }

            return ent;
        }
        private static IEntity? InAvatar(object obj) {
            if (obj is IProspect prospect) return prospect is IValidator validator ? prospect.Potential.ToValidationEntity(validator.Validate) : prospect.Potential;
            return obj is IDictionary dict ? new DictionaryEntity(dict) : null;
        }
        #endregion

        #region :: Box Unbox::

        [ThreadStatic]
        private static IEntity? _potential;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IEntity GetPotentialData() => _potential ?? CreateEntity();

        internal static IEntity? Box(this object obj, bool avataOnly = false) {
            if (obj.GetType().GetCustomAttribute<AvatarAttribute>() is IAvatarType avatarType) return InAvatar(obj, avatarType, avataOnly);
            if (obj is IEntity entity) return entity;
            if (obj is IBoxable boxable) return boxable.Box();
            return InAvatar(obj);
        }
        internal static object? Unbox(this IEntity entity, Type type, bool guarantee) {
            try {
                object? obj;
                var old = _potential;
                try {
                    _potential = entity;
                    if ((obj = Generator.CreateInstance(type)) is null) return false;
                } finally {
                    _potential = old;
                }

                if (obj is IBoxable boxable) boxable.Unbox(entity);
                else obj.As<ISetter>()?.Assign(entity, guarantee)?.Validate();

                return obj;
            } catch (Exception ex) {
                Debug.WriteLine(ex.Correct().ToString());
                throw;
            }
        }
        #endregion

        #region :: Format Helpers ::
        public static bool RegisterFormat(this ISettable formats, IFormat format, BID name) {
            format.As<ISettable>()?.Set(Properties.Name, name, false);
            formats.Set(name, format);
            return true;
        }
        #endregion

        #region :: Cell Helpers ::
        private static ICell? _cell;
        public static ICell Cell => (_cell ?? Generator.CreateInstance<BDomain>(false)?.Cell) ?? Dummy.Cell;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Process(this object? obj, BPath path, IMessage message, bool tryCurCell = true)
            => Process(obj, path, message, tryCurCell, m => m.Forbidden());
        public static bool Process(this object? obj, BPath path, IMessage message, bool tryCurCell, Proc failback) {
            if (obj is null) return failback(message);

            if (path.IsNullOrEmpty()) return obj.Process(message, failback);

            if (obj is IGettable gettable && gettable.TryGetValue(path[0], out object? value)) {
                if (path.Remove(0).Count == 0) return value.Process(message, failback);
                return value.Process(path, message, true, failback);
            }

            if (!tryCurCell || obj is not ICell cell || !cell.AllowPathProcess) return failback(message);
            try {
                message.Potential.Set(Properties.Path, path);
                return cell.Process(message);
            } finally {
                message.Potential.Remove(Properties.Path);
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Process(this object? obj, IMessage message)
            => Process(obj, message, m => m.Forbidden());
        public static bool Process(this object? obj, IMessage message, Proc failback) {
            if (obj is null) return failback(message);
            if (obj is ICell cell) return cell.Process(message);
            if (obj is Proc proc) return proc(message);
            if (obj is ProcAsync procAsync) return Task.Factory.StartNew(async () => await procAsync(message)).Unwrap().GetAwaiter().GetResult();
            return failback(message);
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<bool> ProcessAsync(this object? obj, BPath path, IMessage message, bool tryCurCell = true)
            => await ProcessAsync(obj, path, message, tryCurCell, m => m.Forbidden());
        public static async ValueTask<bool> ProcessAsync(this object? obj, BPath path, IMessage message, bool tryCurCell, Proc failback) {
            if (obj is null) return failback(message);
            if (path.IsNullOrEmpty()) return await obj.ProcessAsync(message, failback);

            if (obj is IGettable gettable && gettable.TryGetValue(path[0], out object? value)) {
                if (path.Remove(0).Count == 0) return await value.ProcessAsync(message, failback);
                return await value.ProcessAsync(path, message, true, failback);
            }

            if (!tryCurCell || obj is not ICell cell || !cell.AllowPathProcess) return failback(message);
            try {
                message.Potential.Set(Properties.Path, path);
                return await cell.ProcessAsync(message);
            } finally {
                message.Potential.Remove(Properties.Path);
            }
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<bool> ProcessAsync(this object? obj, IMessage message)
            => await ProcessAsync(obj, message, m => m.Forbidden());
        public static async ValueTask<bool> ProcessAsync(this object? obj, IMessage message, Proc failback) {
            if (obj is null) return failback(message);
            if (obj is IAsyncCell acell) return await acell.ProcessAsync(message);
            if (obj is ICell cell) return cell.Process(message);
            if (obj is ProcAsync procAsync) return await procAsync(message);
            if (obj is Proc proc) return proc(message);
            return failback(message);
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static async ValueTask<bool> ProcessAsync(this ICell cell, IMessage message)
            => cell is IAsyncCell asyncCell ? await asyncCell.ProcessAsync(message) : cell.Process(message);

        public static void UseCell(ICell cell) {
            _cell = cell;
        }
        #endregion
    }

    public static class FormatNames {
        public static readonly BID ben = nameof(ben);
        public static readonly BID cen = nameof(cen);
        public static readonly BID json = nameof(json);
        public static readonly BID ten = nameof(ten);
        public static readonly BID men = nameof(men);
        public static readonly BID csv = nameof(csv);
    }
}
