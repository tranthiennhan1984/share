﻿namespace Binean.Foundation.Primitive {
    public sealed class ValueMap : IGetter {
        public List<IGetter> Items { get; } = [];
        public IReadonlyBSet Names {
            get {
                var retVal = Prior.CreateSortedBSet();
                var length = Items.Count;
                for (int i = 0; i < length; i++) {
                    retVal.AddRange(Items[i].Names);
                }
                return retVal;
            }
        }
        bool IGetter.IsEmpty => false;
        public bool TryGetValue(BID name, out object? value) {
            var length = Items.Count;
            if (name.IsNothing || length == 0) return (value = null) != null;
            for (int i = 0; i < length; i++) {
                if (Items[i].TryGetValue(name, out value)) return true;
            }
            return (value = null) != null;
        }
    }
}