﻿using Binean.Private;
using System.Collections;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.CompilerServices;

namespace Binean.Foundation.Primitive {
    public static partial class Extension {
        #region :: Potential Helpers ::

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T PSet<T>(this T prospect, BID name, object? value, bool guarantee = true) where T : IProspect {
            if (!prospect.Potential.TrySetValue(name, value) && guarantee) throw LogStorage.CreateError(nameof(Logs.BFND20206E), name, prospect);
            return prospect;
        }

        #endregion

        #region :: IGetter Helpers ::
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsDummy(this IGetter? getter)
            => getter is not null && ReferenceEquals(getter, Dummy.Getter);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsNullOrEmpty([NotNullWhen(false)] this IGetter? getter)
            => getter is null || getter.IsEmpty;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Contains(this IGetter getter, BID name) {
            if (getter.Names is BSet nameList) return nameList.Find(name, out _);
            return getter.TryGetValue(name, out _);
        }
        public static IEnumerable GetValues(this IGetter getter) {
            static IEnumerable InGetValues(IGetter? getter) {
                if (getter is null) yield break;
                foreach (var unit in getter.GetUnits()) {
                    yield return unit.Value;
                }
            }

            if (getter is Entity ent) return ent.GetValues();
            if (getter is Avatar avatar) return avatar.GetValues();
            if (getter is ListEntity lstEnt) return lstEnt.GetValues();

            return InGetValues(getter);
        }

        public static IEnumerable<Unit> GetUnits(this IGetter? getter) {
            static IEnumerable<Unit> InGetUnits(IGetter? getter) {
                if (getter is null) yield break;
                foreach (var name in getter.Names) {
                    if (!getter.TryGetValue(name, out object? value)) continue;
                    yield return new Unit(name, value);
                }
            }

            if (getter is IEnumerable<Unit> unitList) return unitList;
            return InGetUnits(getter);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? Get(this GetDelegate getDelegate, BID name)
            => getDelegate(name, out object? obj) ? obj : null;
        [return: NotNullIfNotNull(nameof(faultValue))]
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Get<T>(this GetDelegate getDelegate, BID name, T? faultValue)
            => getDelegate(name, out object? obj) ? obj.As(() => faultValue) : faultValue;


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static SetDelegate Set(this SetDelegate setter, BID name, object? value, bool guarantee = true) {
            if (!setter(name, value) && guarantee) throw LogStorage.CreateError(nameof(Logs.BFND20206E), name, setter);
            return setter;
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static object? Get(this IGettable gettable, BID name)
            => gettable.TryGetValue(name, out object? obj) ? obj : null;
        [return: NotNullIfNotNull(nameof(faultValue))]
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Get<T>(this IGettable getter, BID name, T? faultValue)
            => getter.TryGetValue(name, out object? obj) ? obj.As(() => faultValue) : faultValue;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? Get<T>(this IGettable gettable, BID name, Func<T?> faultValue)
            => gettable.TryGetValue(name, out object? obj) ? obj.As(faultValue) : faultValue();

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? GetAs<T>(this IGettable gettable, BID name, T? faultValue, bool guarantee = true, bool allowCellPath = false)
            => gettable.GetAs(name, () => faultValue, guarantee, allowCellPath);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T GetTo<T>(this IGettable gettable, BID name, T faultValue, bool guarantee = true, bool allowCellPath = false)
            => GetTo(gettable, name, () => faultValue, guarantee, allowCellPath);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? GetAs<T>(this IGettable gettable, BID name, Func<T?>? faultBack = null, bool guarantee = true, bool allowCellPath = false) {
            if (!gettable.TryGetValue(name, out object? obj)) return faultBack != null ? faultBack() : default;

            if (allowCellPath && typeof(T) != typeof(BPath) && obj?.ToBPath() is BPath path) {
                if (Prior.Cell.Read(path) is object o) obj = o;
            }

            var value = obj.As(faultBack);
            if (value != null) (gettable as ISettable)?.Set(name, value, guarantee);
            return value;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T GetTo<T>(this IGettable gettable, BID name, Func<T>? faultBack = null, bool guarantee = true, bool allowCellPath = false) {
            if (!gettable.TryGetValue(name, out object? obj)) return faultBack != null ? faultBack() : throw LogStorage.CreateError(nameof(Logs.BFND20102E), obj?.ToString(), typeof(T));

            if (allowCellPath && typeof(T) != typeof(BPath) && obj?.ToBPath() is BPath path) {
                if (Prior.Cell.Read(path) is object o) obj = o;
            }

            var value = obj.To(faultBack);
            (gettable as ISettable)?.Set(name, value, guarantee);
            return value;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Set<T>(this T setter, BID name, object? value, bool guarantee = true) where T : ISettable {
            if (!setter.TrySetValue(name, value) && guarantee) throw LogStorage.CreateError(nameof(Logs.BFND20206E), name, setter);
            return setter;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Remove<T>(this T setter, BID name) where T : ISetter {
            setter.TryRemoveValue(name);
            return setter;
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T MSet<T>(this T ent, BID name, Func<object?> valueGetter, bool guarantee = true) where T : IEntity {
            if (ent.TryGetValue(name, out _)) return ent;
            if (!ent.TrySetValue(name, valueGetter()) && guarantee) throw LogStorage.CreateError(nameof(Logs.BFND20206E), name, ent);
            return ent;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Remove<T>(this T setter, BID name, bool guarantee = false) where T : ISetter {
            if (!setter.TryRemoveValue(name) && guarantee) throw LogStorage.CreateError(nameof(Logs.BFND20207E), name, setter);
            return setter;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Clear<T>(this T setter) where T : ISetter {
            setter.Clear();
            return setter;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool TryGetNotNull<T>(this IGettable? getter, BID name, [NotNullWhen(true)] out T? value)
            => (getter == null ? null : (GetDelegate)getter.TryGetValue).TryGetNotNull(name, out value);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool TryGetText(this IGettable? getter, BID name, [NotNullWhen(true)] out string? value)
            => (getter == null ? null : (GetDelegate?)getter.TryGetValue).TryGetText(name, out value);

        public static bool TryGetNotNull<T>(this GetDelegate? getter, BID name, [NotNullWhen(true)] out T? value) {
            if (getter != null && getter(name, out object? obj)) {
                if (obj.TryConvert(typeof(T), out object? v)) {
                    value = (T?)v;
                    return v != null;
                }
            }
            value = default;
            return false;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool TryGetText(this GetDelegate? getter, BID name, [NotNullWhen(true)] out string? value)
            => TryGetNotNull(getter, name, out value) && !string.IsNullOrWhiteSpace(value);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T TryConfigure<T>(this T obj, IGettable? value) {
            if (value is null) return obj;
            obj.TryConfigure(value, false);
            return obj;
        }
        public static T TryConfigure<T>(this T setter, IGettable? value, bool guarantee = false) {
            if (value is null) return setter;
            using (var reader = Men.Serialize(value)!) {
                using (var writer = Men.Deserialize(setter)) {
                    writer.WriteGuarantee = guarantee;
                    writer.Write(reader);
                }
            }
            return setter;
        }
        public static T Assign<T>(this T setter, IGetter? getter, bool guarantee = false) where T : ISettable {
            if (getter.IsNullOrEmpty() || ReferenceEquals(setter, getter)) return setter;

            if (setter is not IEquatable<IGetter> equ || !equ.Equals(getter)) {
                foreach (var unit in getter.GetUnits()) {
                    setter.Set(unit.Name, unit.Value, guarantee);
                }
            }
            return setter;
        }
        public static T Update<T>(this T setter, IGetter? getter, bool guarantee = false) where T : IEntity {
            if (getter.IsNullOrEmpty() || ReferenceEquals(setter, getter)) return setter;

            if (setter is not IEquatable<IGetter> equ || !equ.Equals(getter)) {
                foreach (var name in setter.Names) {
                    if (!getter.TryGetValue(name, out object? value)) continue;
                    setter.Set(name, value, guarantee);
                }
            }
            return setter;
        }
        public static T MAssign<T>(this T setter, IGetter? getter, bool guarantee = false) where T : IEntity {
            if (getter.IsNullOrEmpty()) return setter;

            foreach (var unit in getter.GetUnits()) {
                setter.MSet(unit.Name, () => unit.Value, guarantee);
            }

            return setter;
        }


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ValueMap Map(this ValueMap map, IGetter context, IEnumerable<BID> names) {
            map.Items.Map(context, names);
            return map;
        }
        public static void Map(this List<IGetter> map, IGetter context, IEnumerable<BID> names) {
            foreach (var name in names) {
                if (context.Get(name)?.As<IGetter>() is not IGetter gt) continue;
                map.Add(gt);
            }
        }
        #endregion

        #region :: Class Helpers ::

        public static IReadonlyBSet? ClassSet(this object? obj) {
            if (obj is AvatarEntity avatarEntity) return avatarEntity.ClassList;
            var gettable = obj is Node node ? node.Potential : obj.As<IGettable>();
            return gettable?.Get(HiddenProperties.ClassNames).As<IReadonlyBSet>();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IBSet ClassList(this IEntity entity) => ClassList(entity, Prior.CreateUniqueBList);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IBSet ClassList(this IEntity entity, Func<IBSet> creator) {
            if (entity.Get(HiddenProperties.ClassNames) is IBSet retVal) return retVal;
            entity.Set(HiddenProperties.ClassNames, retVal = creator().Lock());
            return retVal;
        }
        public static IBSet AddClass(this IBSet set, Type type, ClassType classType = ClassType.Type) {
            if (classType == ClassType.None) return set;

            using (set.UnlockScope()) {
                switch (classType) {
                    case ClassType.Type: set.Add(type); break;
                    case ClassType.Name: set.Add(type.Name); break;
                    case ClassType.FullName: set.Add(type.FullName ?? type.Name); break;
                }
            }
            return set;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T AddClass<T>(this T cls, object? other) {
            if (other.ClassSet() is IBSet names && names.Count > 0) {
                if (cls.As<IEntity>()?.ClassList() is IBSet bset) {
                    using (bset.UnlockScope()) {
                        bset.AddRange(names);
                    }
                }
            }
            return cls;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T AddClass<T>(this T cls, IEnumerable<BID>? value) {
            if (value == null) return cls;
            if (cls.As<IEntity>()?.ClassList() is IBSet bset) {
                using (bset.UnlockScope()) {
                    bset.AddRange(value);
                }
            }
            return cls;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T AddClass<T>(this T cls, BID className) {
            if (cls.As<IEntity>()?.ClassList() is IBSet bset) {
                using (bset.UnlockScope()) {
                    bset.Add(className);
                }
            }
            return cls;
        }



        #endregion

        #region :: Validator ::

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IEntity ToValidationEntity(this IEntity entity, ValidationDelegate? validationDelegate = null)
            => new ValidationEntity(entity, validationDelegate);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        [return: NotNullIfNotNull(nameof(obj))]
        public static T? Validate<T>(this T? obj, bool assert = true) {
            (obj as IValidator)?.Validate(assert ? Dummy.ErrLog : Dummy.CreateLogger());
            return obj;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool TryValidate(this IValidator validator) {
            var logger = Dummy.CreateLogger();
            return validator.Validate(logger) && logger.MinimumLevel < LogLevel.Error;
        }

        #endregion
    }
    public enum ClassType {
        None = 0,
        Type,
        Name,
        FullName,
    }
}
