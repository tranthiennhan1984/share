﻿using System.Collections;

namespace Binean.Foundation.Primitive {
    public sealed class Entity(bool sorted) : IEntity, IEnumerable<Unit> {
        private readonly BSet _names = new(sorted);
        private readonly List<object?> _values = Prior.CreateList();

        public bool IsEmpty => _values.Count == 0;
        public IReadonlyBSet Names => _names;

        public bool IsReadOnly {
            get => _names.IsReadOnly;
            set => _names.IsReadOnly = value;
        }

        public bool TryGetValue(BID name, out object? value)
            => (!name.IsNothing && _names.Count > 0
                && _names.Find(name, out int index)
                && (value = _values[index]) is not DBNull) || (value = null) != null;

        public bool TrySetValue(BID name, object? value) {
            if (_names.IsReadOnly || name.IsNothing) return false;

            if (_names.Find(name, out int index)) {
                if (value is DBNull) {
                    _names.RemoveAt(index);
                    _values.RemoveAt(index);
                } else {
                    _values[index] = value;
                }
                return true;
            }

            if (value is DBNull) return true;

            _values.Insert(_names.Add(name), value);
            return true;
        }

        public bool Clear() {
            if (_names.IsReadOnly) return false;
            _names.Clear();
            _values.Clear();
            return true;
        }
        public bool TryRemoveValue(BID name) {
            if (_names.IsReadOnly) return false;

            if (!_names.Find(name, out int index)) return false;

            _names.RemoveAt(index);
            _values.RemoveAt(index);
            return true;
        }

        public Unit[] GetUnits() {
            var length = _values.Count;
            var retVal = new Unit[length];
            for (int i = 0; i < length; i++) {
                retVal[i] = new Unit(_names[i], _values[i]);
            }
            return retVal;
        }
        public IEnumerable GetValues() => _values;

        public IEnumerator<Unit> GetEnumerator() => ((IEnumerable<Unit>)GetUnits()).GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetUnits().GetEnumerator();
    }
}