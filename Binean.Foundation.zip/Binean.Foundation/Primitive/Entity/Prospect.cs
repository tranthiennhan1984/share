﻿namespace Binean.Foundation.Primitive {
    public interface IProspect {
        IEntity Potential { get; }
    }
    public abstract class Prospect : IProspect {
        protected IEntity _potential;

        protected Prospect() : this(Prior.GetPotentialData()) { }
        protected Prospect(IEntity potential, bool addClass = true) {
            _potential = potential;
            if (addClass) Potential.ClassList().Add(GetType());
        }

        public IEntity Potential => _potential;
        public bool IsDummy => Potential == Dummy.Getter;
    }
}