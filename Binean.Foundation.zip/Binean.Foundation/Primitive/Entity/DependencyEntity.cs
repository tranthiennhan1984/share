﻿using System.Collections;

namespace Binean.Foundation.Primitive {
    public sealed class DependencyEntity(IGetter? source, IEntity entity) : IEntity, IValidator, IEnumerable<Unit> {
        private readonly BSet _deleted = Prior.CreateSortedBSet();

        public DependencyEntity(IGetter? source) : this(source, Prior.CreateEntity(source?.Names.IsSorted ?? false)) { }

        public bool IsEmpty => Entity.IsEmpty && Source.IsEmpty;

        public IReadonlyBSet Names => InGetNames();

        public IEntity Entity { get; } = entity;
        public IGetter Source { get; private set; } = source ?? Dummy.Getter;


        public void ChangeSource(IGetter source) {
            Source = source;
        }

        public bool TryGetValue(BID bid, out object? value) {
            if (_deleted.Find(bid, out _) || bid.IsNothing) {
                value = null;
                return false;
            }
            if (Entity.TryGetValue(bid, out value)) return true;
            return Source.TryGetValue(bid, out value);
        }
        public bool TrySetValue(BID bid, object? value) {
            if (bid.IsNothing) return false;

            if (value is DBNull) {
                Entity.TryRemoveValue(bid);
                _deleted.Add(bid);
                return true;
            }

            _deleted.Remove(bid);
            Entity.TrySetValue(bid, value);
            return true;
        }
        public bool Clear() {
            _deleted.Clear();
            return Entity.Clear();
        }
        public bool TryRemoveValue(BID bid) {
            Entity.TryRemoveValue(bid);
            _deleted.Add(bid);
            return true;
        }
        private BSet InGetNames() {
            var retVal = Prior.CreateBSet();
            if (Source != Dummy.Getter) retVal.AddRange(Source.Names);
            retVal.AddRange(Entity.Names);
            retVal.RemoveRange(_deleted);
            return retVal;
        }
        private IEnumerable<Unit> InGetUnits() {
            var visited = Prior.CreateSortedBSet().AddRange(_deleted);

            foreach (var unit in Source.GetUnits()) {
                var name = unit.Name;
                if (visited.Find(name, out _)) continue;
                visited.Add(name);
                if (Entity.TryGetValue(name, out object? value)) yield return new Unit(name, value);
                else yield return unit;
            }

            foreach (var unit in Entity.GetUnits()) {
                var name = unit.Name;
                if (visited.Find(name, out _)) continue;
                yield return unit;
            }
        }

        public IEnumerator<Unit> GetEnumerator() => InGetUnits().GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => InGetUnits().GetEnumerator();

        public bool Validate(ILogger logger) => (Entity as IValidator)?.Validate(logger) ?? false;
    }
}