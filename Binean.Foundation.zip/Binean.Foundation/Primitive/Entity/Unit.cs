﻿namespace Binean.Foundation.Primitive {
    public readonly struct Unit(BID name, object? value) {
        public static readonly Unit Empty = new(BID.Nothing, DBNull.Value);

        private readonly BID _name = name;
        private readonly object? _value = value;

        public BID Name => _name;
        public object? Value => _value;
    }
}
