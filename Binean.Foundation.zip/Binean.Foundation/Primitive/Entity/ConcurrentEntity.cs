﻿using System.Collections;

namespace Binean.Foundation.Primitive {
    public sealed class ConcurrentEntity(IEntity entity) : IEntity, IEnumerable<Unit> {
        private readonly object _lock = new();

        public IEntity Entity { get; } = entity;
        public object Lock => _lock;

        public IReadonlyBSet Names => Entity.Names;
        public bool IsEmpty => Entity.IsEmpty;

        public bool Clear() {
            lock (_lock) return Entity.Clear();
        }
        public bool TryGetValue(BID name, out object? value) {
            lock (_lock) return Entity.TryGetValue(name, out value);
        }
        public bool TrySetValue(BID name, object? value) {
            lock (_lock) return Entity.TrySetValue(name, value);
        }
        public bool TryRemoveValue(BID name) {
            lock (_lock) return Entity.TryRemoveValue(name);
        }

        public List<Unit> GetUnits() {
            var retVal = new List<Unit>();
            lock (_lock) {
                foreach (var unit in Entity.GetUnits()) {
                    retVal.Add(unit);
                }
            }
            return retVal;
        }
        public IEnumerator<Unit> GetEnumerator() => GetUnits().GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetUnits().GetEnumerator();
    }
}