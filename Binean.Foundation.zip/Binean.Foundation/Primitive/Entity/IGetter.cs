﻿namespace Binean.Foundation.Primitive {
    public interface IGettable {
        bool TryGetValue(BID name, out object? value);
    }
    public interface ISettable {
        bool TrySetValue(BID name, object? value);
    }

    public interface IGetter : IGettable {
        IReadonlyBSet Names { get; }
        bool IsEmpty { get; }
    }

    public interface ISetter : ISettable {
        bool TryRemoveValue(BID name);
        bool Clear();
    }

    public interface IEntity : IGetter, ISetter {
    }

    public delegate bool GetDelegate(BID name, out object? value);
    public delegate bool SetDelegate(BID name, object? value);

    public delegate bool Proc(IMessage message);
    public delegate ValueTask<bool> ProcAsync(IMessage message);
}