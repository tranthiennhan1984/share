﻿using System.Collections;

namespace Binean.Foundation.Primitive {
    public sealed class BList(bool isUnique) : IBSet {
        private readonly List<BID> _items = [];

        public bool IsSorted => false;
        public bool IsUnique { get; } = isUnique;

        public BID this[int index] => _items[index];
        public int Count => _items.Count;

        public bool IsReadOnly { get; set; }

        public int Add(BID item) {
            if (IsUnique && Find(item, out int index)) return index;
            _items.Add(item);
            return _items.Count - 1;
        }
        public int Insert(int index, BID item) {
            if (IsUnique && Find(item, out int curIndex)) return curIndex;
            _items.Insert(index, item);
            return index;
        }

        public void Clear() => _items.Clear();

        public bool Find(BID item, out int index) {
            var length = _items.Count;
            if (length == 0) return (index = ~length) > -1;
            for (int i = 0; i < length; i++) {
                if (_items[i].CompareTo(item) == 0) return (index = i) > -1;
            }
            return (index = ~length) > -1;
        }
        public void RemoveAt(int index) => _items.RemoveAt(index);

        public IEnumerator<BID> GetEnumerator() => _items.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => ((IEnumerable)_items).GetEnumerator();
    }
}
