﻿using System.Collections;

namespace Binean.Foundation.Primitive {
    public sealed class BSet : IBSet {
        private readonly Finder _finder;
        private readonly List<BID> _items = [];

        public BSet(bool sorted) {
            _finder = (IsSorted = sorted) ? InBinaryFinder : InFinder;
        }
        public bool IsSorted { get; }
        public bool IsUnique => true;

        public bool IsReadOnly { get; set; }
        public int Count => _items.Count;
        public BID this[int index] => _items[index];

        public int Add(BID item) {
            if (IsReadOnly || item.IsNothing) return -1;
            if (_finder(item, out int index)) return index;
            index = ~index;
            _items.Insert(index, item);
            return index;
        }
        public int Insert(int index, BID item) => Add(item);
        public bool Find(BID item, out int index)
        => item.IsNothing ? (index = -1) > 0 : _finder(item, out index);
        public void RemoveAt(int index) {
            if (!IsReadOnly) _items.RemoveAt(index);
        }
        public void Clear() {
            if (!IsReadOnly) _items.Clear();
        }

        public IEnumerator<BID> GetEnumerator() => _items.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => ((IEnumerable)_items).GetEnumerator();

        private delegate bool Finder(BID item, out int index);
        private bool InBinaryFinder(BID item, out int index) {
            var length = _items.Count;
            if (length == 0) return (index = ~length) > -1;
            return _items.BinarySearch(length, (set, index) => set[index], n => n.CompareTo(item), out index);
        }
        private bool InFinder(BID item, out int index) {
            var length = _items.Count;
            if (length == 0) return (index = ~length) > -1;
            for (int i = 0; i < length; i++) {
                if (_items[i].CompareTo(item) == 0) return (index = i) > -1;
            }
            return (index = ~length) > -1;
        }
    }
}
