﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.InteropServices;
using System.Text;

namespace Binean.Foundation.Primitive {
    public sealed class BPath {
        public const char MemberSeparator = '.';
        private readonly List<BID> _bids = [];
        private BPath() { }
        public BPath(BID bid) {
            AddItem(bid);
        }
        public BID this[int index] => _bids[index];
        public int Count => _bids.Count;
        public BPath Add(BPath prop) {
            if (prop.IsEmpty()) return this;
            var length = prop.Count;
            for (int i = 0; i < length; i++) {
                _bids.Add(prop[i]);
            }
            return this;
        }
        public BPath AddItem(BID bid) {
            if (bid.IsNothing) return this;
            _bids.Add(bid);
            return this;
        }
        public BPath Remove(int index) {
            _bids.RemoveAt(index);
            return this;
        }

        public override string ToString() => ToString(MemberSeparator);
        public BID Peek() => _bids.Count == 0 ? BID.Nothing : _bids[0];
        public BID Pop() {
            if (_bids.Count == 0) return BID.Nothing;
            var retVal = _bids[0];
            _bids.RemoveAt(0);
            return retVal;
        }
        public BPath Clone(int index = 0, int length = -1) {
            if (length > 0) length = index + length;
            if (length < 0 || length > _bids.Count) length = _bids.Count;
            var retVal = new BPath();
            var props = retVal._bids;
            for (int i = index; i < length; i++) {
                props.Add(_bids[i]);
            }
            return retVal;
        }
        public BPath? GetParentPath(out BID name) {
            if (Count == 0) {
                name = BID.Nothing;
                return null;
            }
            if (Count == 1) {
                name = _bids[0];
                return null;
            }

            var length = Count - 1;
            name = _bids[length];
            var retVal = new BPath();
            for (int i = 0; i < length; i++) {
                retVal.Add(new(_bids[i]));
            }
            return retVal;
        }
        public void Scan(Func<BID, bool> action, int from = 0, int to = -1) {
            if (to < 0 || to >= _bids.Count) to = _bids.Count - 1;
            for (var i = from; i <= to; i++) {
                if (!action(_bids[i])) break;
            }
        }

        public static implicit operator BPath(BID bid) => new(bid);
        public static BPath CreateEmpty() => new();
        public static bool TryParse(string? text, [NotNullWhen(true)] out BPath? path, char? memberSeparator = null) {
            if (string.IsNullOrWhiteSpace(text = text?.Trim())) return (path = null) != null;
            path = new BPath();

            memberSeparator ??= MemberSeparator;

            var ends = $"{memberSeparator}\0";
            using (var reader = text.CreateTextReader()) {
                while (true) {
                    var chr = reader.Current;
                    if (chr == memberSeparator) {
                        reader.MoveNext();
                        continue;
                    }
                    if (chr == Prior.EofCharacter) break;
                    var name = reader.ReadUntil(endCond: ends.Contains, errCond: "\r\n".Contains, expected: memberSeparator);
                    if (string.IsNullOrWhiteSpace(name)) return (path = null) != null;
                    path.Add(new BPath((BID)name));
                }
            }
            return path.Count > 0;
        }
        public string ToString(char? memberSeparator) {
            var sb = new StringBuilder();
            var length = _bids.Count;
            for (int i = 0; i < length; i++) {
                sb.Append(memberSeparator).Append(_bids[i]);
            }
            if (sb.Length > 0) sb.Remove(0, 1);
            return sb.ToString();
        }
    }
}

