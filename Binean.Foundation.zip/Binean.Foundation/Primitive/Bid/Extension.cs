﻿using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;

namespace Binean.Foundation.Primitive {
    public static partial class Extension {
        #region :: Bid Helpers ::

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BID ToHiddenNameId(this string name) => string.IsNullOrEmpty(name) ? BID.Nothing : BID.Helper.ToNameId(name, true);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BID ToCodeId(this string name) => string.IsNullOrEmpty(name) ? BID.Nothing : BID.Helper.ToCodeId(name);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BID ToGuidId(this string txt) => !Guid.TryParse(txt, out Guid guid) || guid.IsEmpty() ? BID.Nothing : (BID)guid;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BID ToTypeId(this Type? type) => type == null ? BID.Nothing : (BID)(ulong)type.TypeHandle.Value;

        public static Type? ToType(this BID bid) => bid.BIDType != BIDType.Code ? null : Type.GetTypeFromHandle(RuntimeTypeHandle.FromIntPtr((nint)(ulong)bid));
        public static BID Hide(this BID bid, bool keep = false) {
            if (!bid.IsName) return keep ? bid : BID.Nothing;
            if (bid.IsHiddenName) return bid;

            var codes = bid.GetContent();
            codes[0] |= BID.HiddenMark;
            return new BID(codes, BIDType.Name);
        }
        public static BID Unhide(this BID bid) {
            if (!bid.IsHiddenName) return bid;
            var codes = bid.GetContent();
            codes[0] &= ~BID.HiddenMark;
            return new BID(codes, BIDType.Name);
        }

        #endregion

        #region :: BidSet Helpers ::

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool Contains(this IReadonlyBSet? set, BID bid)
            => set != null && set.Find(bid, out int _);
        public static bool Contains(this IReadonlyBSet set, [NotNullWhen(true)] ref BID bid) {
            if (!set.Find(bid, out int index)) return false;
            return (bid = set[index]) is not null;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsNullOrEmpty([NotNullWhen(false)] this IReadonlyBSet? set)
            => set is null || set.Count == 0;


        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T AddRange<T>(this T list, IEnumerable<BID> items) where T : IBSet {
            foreach (var name in items) {
                if (name.IsNothing) continue;
                list.Add(name);
            }
            return list;
        }

        public static bool Remove(this IBSet list, BID bid) {
            if (bid.IsNothing || !list.Find(bid, out int index)) return false;
            list.RemoveAt(index);
            return true;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T RemoveRange<T>(this T list, IEnumerable<BID> bids) where T : IBSet {
            foreach (var bid in bids) {
                if (!bid.IsNothing) list.Remove(bid);
            }
            return list;
        }

        private static string ReadText(this TextReader reader) {
            StringBuilder builder = new();
            char chr;
            while ((chr = reader.ReadChar()) != Prior.EofCharacter) {
                if (chr == ' ') {
                    if (builder.Length > 0) return builder.ToString();
                    continue;
                }
                builder.Append(chr);
            }
            return builder.Length == 0 ? string.Empty : builder.ToString();
        }
        private static char ReadChar(this TextReader reader) {
            var retVal = reader.Read();
            return retVal < 0 ? Prior.EofCharacter : (char)retVal;
        }

        public static T ReadCssClasses<T>(this T list, string? cls) where T : IBSet {
            if (string.IsNullOrWhiteSpace(cls)) return list;
            using (var txtReader = new StringReader(cls)) {
                string txt;
                while ((txt = txtReader.ReadText()).Length > 0) {
                    list.Add(txt);
                }
            }
            return list;
        }
        public static string WriteCssClasses(this IBSet list) {
            var builder = new StringBuilder();
            var length = list.Count;
            for (int i = 0; i < length; i++) {
                var name = list[i];
                if (builder.Length > 0) builder.Append(' ');
                builder.Append(name);
            }
            return builder.ToString();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T AddName<T>(this T list, BID name) where T : IBSet {
            if (!string.IsNullOrWhiteSpace(name)) list.Add(name);
            return list;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T AddName<T>(this T list, bool condition, Func<BID> nameFunc) where T : IBSet
            => !condition ? list : list.AddName(nameFunc());

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T AddFirstName<T>(this T list, params T[] values) where T : IBSet {
            foreach (var value in values) {
                if (value is not BID name) {
                    if (value is not string txt || txt.Length == 0) continue;
                    name = txt;
                }
                list.Add(name);
                break;
            }
            return list;
        }
        public static void AddNames(this IBSet list, Type namesType) {
            if (list is null) return;
            if (namesType.IsEnum) {
                foreach (var name in Enum.GetNames(namesType)) {
                    list.Add(name);
                }
            } else InAddFields(list, namesType);
        }
        private static void InAddFields(IBSet list, Type propType) {
            var st = typeof(string);
            foreach (var field in propType.GetFields(BindingFlags.Public | BindingFlags.Static | BindingFlags.FlattenHierarchy)) {
                if (!field.IsLiteral || field.IsInitOnly || field.FieldType != st) continue;
                if (field.GetRawConstantValue() is not string value || string.IsNullOrWhiteSpace(value)) continue;
                list.Add(value);
            }
        }

        public static T ReadBids<T>(this T list, string? text) where T : IBSet {
            if (string.IsNullOrWhiteSpace(text)) return list;
            using (var reader = new StringReader(text).CreateTextReader()) {
                BID bid;
                while (!(bid = reader.ReadBID()).IsNothing) {
                    list.Add(bid);
                }
            }
            return list;
        }
        public static TextWriter WriteBids<T>(this TextWriter writer, T list) where T : IReadonlyBSet {
            var length = list.Count;
            for (int i = 0; i < length; i++) {
                if (i > 0) writer.Write(' ');
                writer.WriteBID(list[i]);
            }
            return writer;
        }
        #endregion

        #region :: PropPath Helpers ::

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsEmpty([NotNullWhen(false)] this BPath path) => path.Count == 0;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsNullOrEmpty([NotNullWhen(false)] this BPath? path)
            => path is null || path.Count == 0 || path[0].IsNothing;

        #endregion

        #region :: Case Helper ::
        public static List<string> GetWords(this string text, bool ignorePunctuator = true) {
            var retVal = new List<string>();
            var builder = new StringBuilder();

            static char GetText(string text, int index) => index >= text.Length ? Prior.EofCharacter : text[index];

            static void ReadWord(string text, ref int index, List<string> list, StringBuilder builder) {
                static bool func(char c) => char.IsLetterOrDigit(c) && !char.IsUpper(c);
                char chr;
                while (((chr = GetText(text, index)) != Prior.EofCharacter) && func(chr)) {
                    builder.Append(chr);
                    index++;
                }
                if (builder.Length > 0) {
                    list.Add(builder.ToString());
                    builder.Clear();
                }
            }
            static void ReadUpper(string text, ref int index, List<string> list, StringBuilder builder) {
                static bool func(char c) => char.IsDigit(c) || char.IsUpper(c);
                char chr;
                while (((chr = GetText(text, index)) != Prior.EofCharacter) && func(chr)) {
                    _ = builder.Append(char.ToLower(chr));
                    index++;
                }
                if (builder.Length <= 0) return;

                var len = chr == Prior.EofCharacter ? builder.Length : builder.Length - 1;
                if (len == 0) return;
                list.Add(builder.ToString(0, len));
                builder.Remove(0, len);
            }
            static void ReadPunctuator(string text, ref int index, List<string> list, StringBuilder builder, bool ignorePunctuator) {
                static bool func(char c) => !char.IsLetterOrDigit(c);

                System.Diagnostics.Debug.Assert(builder.Length == 0);
                char chr;
                while (((chr = GetText(text, index)) != Prior.EofCharacter) && func(chr)) {
                    builder.Append(chr);
                    index++;
                }
                if (builder.Length > 0) {
                    if (!ignorePunctuator) list.Add(builder.ToString());
                    builder.Clear();
                }
            }

            var index = 0;
            char chr;
            while ((chr = GetText(text, index)) != Prior.EofCharacter) {
                if (!char.IsLetterOrDigit(chr)) ReadPunctuator(text, ref index, retVal, builder, ignorePunctuator);
                else if (char.IsUpper(chr)) ReadUpper(text, ref index, retVal, builder);
                else ReadWord(text, ref index, retVal, builder);
            }
            return retVal;
        }
        public static string ToName(this List<string> words, NameCase nameCase = NameCase.PascalCase) {
            if (words.Count == 0) return string.Empty;

            if (nameCase == NameCase.NotSet) nameCase = NameCase.PascalCase;

            var first = nameCase switch {
                NameCase.PascalCase or NameCase.SNAKE_CASE or NameCase.KEBAB_CASE => new Func<char, string>(chr => char.ToString(char.ToUpper(chr))),
                _ => new Func<char, string>(chr => chr.ToString())
            };

            var body = nameCase switch {
                NameCase.KEBAB_CASE or NameCase.SNAKE_CASE => new Func<string, string>(s => s.ToUpper()),
                _ => new Func<string, string>(s => s),
            };

            var builder = new StringBuilder();
            var length = words.Count;
            var name = words[0];
            builder.Append(first(name[0])).Append(body(name[1..]));
            if (length == 1) return builder.ToString();

            first = nameCase switch {
                NameCase.PascalCase => new Func<char, string>(chr => char.ToString(char.ToUpper(chr))),
                NameCase.SNAKE_CASE => new Func<char, string>(chr => $"_{char.ToUpper(chr)}"),
                NameCase.KEBAB_CASE => new Func<char, string>(chr => $"-{char.ToUpper(chr)}"),
                NameCase.camelCase => new Func<char, string>(chr => char.ToString(char.ToLower(chr))),
                NameCase.snake_case => new Func<char, string>(chr => $"_{char.ToLower(chr)}"),
                NameCase.kebab_case => new Func<char, string>(chr => $"-{char.ToLower(chr)}"),
                _ => throw new InvalidOperationException(),
            };

            for (int i = 1; i < length; i++) {
                name = words[i];
                builder.Append(first(name[0])).Append(body(name[1..]));
            }

            return builder.ToString();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string ToCase(this string name, NameCase to) => name.GetWords().ToName(to);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BID ToCase(this BID bid, NameCase to) => ((string)bid).GetWords().ToName(to);
        #endregion

        //#region :: Lock Helper ::
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static T Lock<T>(this T obj) {
        //    if (obj is ILockable lck) lck.IsReadOnly = true;
        //    return obj;
        //}
        //private static IDisposable InLockScope(ILockable lck, bool locked = false) {
        //    var cur = lck.IsReadOnly;
        //    if (cur == locked) return Dummy.Disposable;
        //    lck.IsReadOnly = locked;
        //    return Generator.CreateDisposable(() => lck.IsReadOnly = cur);
        //}
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static IDisposable UnlockScope(this object obj)
        //    => obj is not ILockable lck ? Dummy.Disposable : InLockScope(lck, false);
        //[MethodImpl(MethodImplOptions.AggressiveInlining)]
        //public static IDisposable LockScope(this object obj)
        //    => obj is not ILockable lck ? Dummy.Disposable : InLockScope(lck, true);
        //#endregion

    }
}