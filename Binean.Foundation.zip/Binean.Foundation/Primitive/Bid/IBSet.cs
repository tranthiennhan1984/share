﻿namespace Binean.Foundation.Primitive {
    public interface IReadonlyBSet : IEnumerable<BID> {
        bool IsSorted { get; }
        bool IsUnique { get; }
        int Count { get; }
        BID this[int index] { get; }
        bool Find(BID name, out int index);
    }

    public interface IBSet : IReadonlyBSet {
        bool IsReadOnly { get; set; }
        int Insert(int index, BID item);
        int Add(BID item);
        void RemoveAt(int index);
        void Clear();
    }

}