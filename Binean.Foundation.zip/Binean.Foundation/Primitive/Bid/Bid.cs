﻿using System.Runtime.InteropServices;

namespace Binean.Foundation.Primitive {
    ///<summary>
    /// Binean identifier
    /// </summary>
    public sealed class BID : IComparable<BID>, IEquatable<BID> {
        public const ulong HiddenMark = 0x8000000000000000UL;

        public static readonly BID Nothing = new();

        private readonly ulong[] _units;
        private BID() {
            BIDType = BIDType.Nothing;
            _units = [0UL];
        }
        public BID(ulong[] units, BIDType bidType) {
            if (units.Length == 0 || (bidType == BIDType.Name && units[0] == 0)) {
                _units = [0L];
                BIDType = BIDType.Nothing;
            } else {
                _units = units;
                BIDType = bidType;
            }
        }

        public override string ToString() => BIDType switch {
            BIDType.Code => Helper.ToCodeText(_units),
            BIDType.Name => Helper.ToNameText(_units),
            _ => string.Empty,
        };

        public string ToText() => new StringWriter().WriteBID(this).ToString()!;

        public BIDType BIDType { get; }

        public int Length => _units.Length;
        public bool IsNothing => _units[0] == 0;
        public bool IsName => BIDType == BIDType.Name;
        public bool IsHiddenName => IsName && ((_units[0] & HiddenMark) == HiddenMark);

        public override int GetHashCode() => _units[0].GetHashCode();
        public override bool Equals(object? obj) {
            if (ReferenceEquals(this, obj)) return true;
            if (obj is null) return false;
            if (obj is not BID other) throw this.CreateException(nameof(Logs.BFND20212E), obj);
            return InCompareTo(other._units) == 0;
        }
        public int CompareTo(BID? other) {
            if (ReferenceEquals(this, other)) return 0;
            if (other is null) return 1;
            return InCompareTo(other._units);
        }
        public bool Equals(BID? other) {
            if (ReferenceEquals(this, other)) return true;
            if (other is null) return false;
            return InCompareTo(other._units) == 0;
        }
        private int InCompareTo(ulong[] others) {
            var contents = _units;
            var rLen = contents.Length.CompareTo(others.Length);
            var len = rLen < 0 ? contents.Length : others.Length;

            for (int r, i = 0; i < len; i++) {
                if ((r = contents[i].CompareTo(others[i])) != 0) return r;
            }

            return rLen;
        }

        public ReadOnlySpan<ulong> AsSpan => new(_units);
        public void Increase(int offset = 1) {
            if (IsNothing || _units.Length != 1) return;
            if (offset < 0) _units[0] -= (uint)(-offset);
            else _units[0] += (uint)offset;
        }
        public ulong[] GetContent() => Helper.CreateBidContent(_units);

        public static bool operator ==(BID? left, BID? right)
            => left is null ? right is null : left.CompareTo(right) == 0;
        public static bool operator !=(BID? left, BID? right) => !(left == right);
        public static bool operator <(BID? left, BID? right)
            => left is null ? right is not null : left.CompareTo(right) < 0;
        public static bool operator <=(BID? left, BID? right)
            => left is null || left.CompareTo(right) <= 0;
        public static bool operator >(BID? left, BID? right)
            => left is not null && left.CompareTo(right) > 0;
        public static bool operator >=(BID left, BID right)
            => left is null ? right is null : left.CompareTo(right) >= 0;

        public static implicit operator string(BID bid) => bid.IsNothing ? string.Empty : Helper.ToNameText(bid._units);
        public static implicit operator BID(string text) => string.IsNullOrEmpty(text) ? Nothing : Helper.ToNameId(text);
        public static implicit operator BID(Guid guid) => guid == Guid.Empty ? Nothing : new(Helper.CreateBidContent(guid.ToByteArray()), BIDType.Code);
        public static implicit operator BID(ulong value) => value == 0 ? Nothing : new BID([value], BIDType.Code);
        public static implicit operator BID(Type? type) => type is null ? Nothing : new BID([(ulong)type.TypeHandle.Value], BIDType.Code);
        public static implicit operator BID(IntPtr? type) => type is null ? Nothing : new BID([(ulong)type.Value], BIDType.Code);

        public static explicit operator Guid(BID bid) => bid.IsNothing ? Guid.Empty : new(MemoryMarshal.Cast<ulong, byte>(bid._units));
        public static explicit operator ulong(BID bid) => bid.IsNothing || bid._units.Length != 1 ? 0 : bid._units[0];

        internal static class Helper {

            #region :: Bid Helpers ::
            public static ulong[] CreateBidContent(ReadOnlySpan<byte> data) {
                var len = data.Length / 8;
                if (len * 8 < data.Length) len++;
                var contents = new ulong[len];
                data.CopyTo(MemoryMarshal.Cast<ulong, byte>(contents));
                return contents;
            }
            public static ulong[] CreateBidContent(ulong[] data) {
                var len = data.Length;
                var contents = new ulong[len];
                Array.Copy(data, contents, len);
                return contents;
            }
            #endregion

            #region :: NameId Helpers ::
            public static string ToNameText(ulong[] units) {
                if (units[0] == 0) return string.Empty;

                var unitLen = units.Length;
                var buffer = new char[unitLen * 9];
                var offset = 0;
                unsafe {
                    char chr;
                    for (var index = 0; index < unitLen; index++) {
                        fixed (ulong* content = &units[index]) {
                            if (*content == 0) break;
                            for (int bitOff = 56; bitOff >= 0; bitOff -= 7) {
                                chr = (char)((*content >> bitOff) & 127);
                                if (chr == 0) {
                                    index = unitLen;
                                    break;
                                }
                                buffer[offset++] = chr;
                            }
                        }
                    }
                }
                return new string(buffer, 0, offset);
            }
            public static BID ToNameId(string txt, bool hidden = false) {
                var txtEnd = txt.Length;

                var end = txtEnd / 9;
                if (end * 9 < txtEnd) end++;
                var units = new ulong[end];

                unsafe {
                    ulong code;
                    for (int txtInd = 0, index = 0; (end = txtEnd - txtInd) > 0;) {
                        fixed (ulong* unit = &units[index++]) {
                            end = end > 8 ? 0 : (9 - end) * 7;
                            for (int bitOff = 56; bitOff >= end; bitOff -= 7) {
                                if ((code = (ulong)txt[txtInd++] & 127) == 0) {
                                    txtInd = txtEnd;
                                    break;
                                }
                                *unit |= code << bitOff;
                            }
                        }
                    }
                }

                if (hidden) units[0] |= HiddenMark;
                return new BID(units, BIDType.Name);
            }
            #endregion

            #region :: CodeId Helpers ::
            internal static char[] _codeIdEncodingMap = [.. "_0123456789AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz-"];
            internal static sbyte[] _codeIdDecodingMap = BuildBidDecodingMap(_codeIdEncodingMap);
            private static sbyte[] BuildBidDecodingMap(char[] encodingMap) {
                var retVal = new sbyte[sbyte.MaxValue];
                var length = retVal.Length;
                for (int i = 0; i < length; i++) {
                    retVal[i] = -1;
                }
                length = encodingMap.Length;
                int code;
                for (sbyte i = 0; i < length; i++) {
                    code = encodingMap[i];
                    retVal[code] = i;
                }
                return retVal;
            }

            public static string ToCodeText(ulong[] units) {
                if (units[0] == 0) return string.Empty;

                var length = units.Length;
                var buffer = new char[length * 11];
                unsafe {
                    for (int index = 0, offset = 0; index < length; index++) {
                        fixed (ulong* content = &units[index]) {
                            buffer[offset++] = _codeIdEncodingMap[(*content >> 60)];
                            for (int bitOff = 54; bitOff >= 0; bitOff -= 6) {
                                buffer[offset++] = _codeIdEncodingMap[(*content >> bitOff) & 63];
                            }
                        }
                    }
                }
                return new string(buffer);
            }
            public static BID ToCodeId(string txt) {
                var txtEnd = txt.Length;
                var end = txtEnd / 11;
                if (end * 11 < txtEnd) {
                    end++;
                    txt = txt.PadLeft(end * 11, '_');
                }
                var units = new ulong[end];

                unsafe {
                    sbyte code;
                    for (int offset = 0, index = 0; index < end;) {
                        fixed (ulong* unit = &units[index++]) {
                            if ((code = _codeIdDecodingMap[txt[offset++]]) < 0) throw LogStorage.CreateError(nameof(Logs.BFND20211E), "CodeId", txt[offset]);
                            *unit |= (ulong)code << 60;
                            for (int bitOff = 54; bitOff >= 0; bitOff -= 6) {
                                if ((code = _codeIdDecodingMap[txt[offset++]]) < 0) throw LogStorage.CreateError(nameof(Logs.BFND20211E), "CodeId", txt[offset]);
                                *unit |= (ulong)code << bitOff;
                            }
                        }
                    }
                }

                return new BID(units, BIDType.Code);
            }
            #endregion

        }
    }

    public enum BIDType {
        Nothing,
        Name,
        Code
    }
}