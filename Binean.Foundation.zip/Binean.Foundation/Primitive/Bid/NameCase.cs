﻿namespace Binean.Foundation.Primitive {
    public enum NameCase {
        NotSet,
        PascalCase,
        camelCase,
        snake_case,
        kebab_case,
        KEBAB_CASE,
        SNAKE_CASE,
    }
}