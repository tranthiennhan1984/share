﻿
namespace Binean.Foundation.Primitive {
    public enum SimpleType {
        Array,
        Blob,
        Boolean,
        Float,
        Integer,
        Null,
        Object,
        String,
    }
    [Avatar]
    public sealed class BType: Avatar {
        [AvatarProperty]
        public BID Name { get; set; } = default!;
        [AvatarProperty]
        public SimpleType Type { get; set; } = SimpleType.Object;
        [AvatarProperty]
        public string? Description { get; set; } = default!;
    }
}
