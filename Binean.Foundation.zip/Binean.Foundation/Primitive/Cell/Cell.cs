﻿using System.Xml.Linq;

namespace Binean.Foundation.Primitive {
    [Avatar]
    public class Cell(ClassType classType = ClassType.Type, bool configuration = true) : Avatar(classType, configuration), ICell {

        [AvatarProperty(HiddenName = true, ReadSkip = true, WriteSkip = true)]
        public ICell? Owner { get; set; }
        public SetDelegate CellSetDelegate => InTrySetCell;

        public bool AllowPathProcess => true;

        public override bool TryGetValue(BID name, out object? value) {
            var retVal = OnGetSpecialValue(name, out value);
            if (retVal != null) return retVal.Value;
            return base.TryGetValue(name, out value);
        }
        public override bool TrySetValue(BID name, object? value) {
            if (!base.TrySetValue(name, value)) return false;
            if (name != HiddenProperties.Owner && value is ICell cell) {
                OnAddItem(name, cell);
            }
            return true;
        }
        public override bool TryRemoveValue(BID name) {
            if (this.Get(name) is ICell cell && cell.As<IEntity>() is IEntity ent) {
                if (ent.Get(HiddenProperties.Owner) == this) ent.Remove(HiddenProperties.Owner);
            }
            return base.TryRemoveValue(name);
        }

        public virtual bool Process(IMessage message) {
            var potential = message.Potential;
            if (potential.GetAs<BPath>(Properties.Path) is not BPath path || path.Count == 0) return OnProcess(message);
            else if (!AllowPathProcess) return message.Forbidden();

            while (path.Count > 1 && path[0] == PathProperties.Current) path.Remove(0);
            if (path.Count == 0) return OnProcess(message);

            try {
                potential.Remove(Properties.Path);
                return OnProcess(path.Clone(), message);
            } finally {
                potential.Set(Properties.Path, path);
            }
        }

        private bool InTrySetCell(BID name, object? value) {
            if (!ImmutableSetDelegate(name, value)) return false;
            if (value is ICell cell) OnAddItem(name, cell);
            return true;
        }
        protected void OnAddItem(BID name, ICell cell) {
            if (cell.As<ISettable>() is ISettable settable) {
                settable.Set(Properties.Name, name);
                if (this.Get(Properties.Path).As<BPath>() is BPath path) {
                    settable.Set(Properties.Path, path.Clone().AddItem(name));
                } else {
                    settable.Set(Properties.Path, new BPath(name));
                }
                settable.Set(HiddenProperties.Owner, this);
            }
        }

        protected bool? OnGetSpecialValue(BID name, out object? value) {
            if (name == PathProperties.Current) {
                value = this;
                return true;
            }
            if (name == PathProperties.Parent) {
                value = Owner;
                return true;
            }
            if (name == PathProperties.Root) {
                value = (Generator.TryCreateInstance(typeof(BDomain), out object? v) && v is BDomain domain) ? domain.Cell : null;
                return true;
            }
            value = null;
            return null;
        }

        protected virtual bool OnProcess(IMessage message) => message.Forbidden();
        protected virtual bool OnProcess(BPath path, IMessage message) => this.Process(path, message, false);
    }
}
