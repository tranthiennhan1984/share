﻿namespace Binean.Foundation.Primitive {
    public interface ICell : IGetter {
        bool AllowPathProcess { get; }
        ICell? Owner { get; }
        bool Process(IMessage message);
    }

    public interface IAsyncCell : ICell {
        ValueTask<bool> ProcessAsync(IMessage message);
    }
}
