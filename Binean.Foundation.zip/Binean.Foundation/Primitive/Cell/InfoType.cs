﻿namespace Binean.Foundation.Primitive {
    public enum InfoType {
        Normal,
        Details,
    }
}
