﻿namespace Binean.Foundation.Primitive {
    [Avatar]
    public class ExtensionCell(ClassType classType = ClassType.None, bool configuration = true) : Cell(classType, configuration) {

        //[AvatarMethod]
        //public override bool Info(IMessage message) {
        //    if (message.GetRequest()?.As<IGettable>()?.Get(Properties.InfoType).As<InfoType>() is not InfoType infoType) infoType = InfoType.Normal;
        //    return infoType == InfoType.Normal? OnNormalInfo(message): OnDetailsInfo(message);
        //}

        [AvatarMethod]
        public virtual bool Read(IMessage message) {
            if (this.Get(Properties.Extension) is not IGetter ex) return message.NotFound();
            return message.Return(new DependencyEntity(ex).Set(Properties.Path, this.Get(Properties.Path)));
        }
        protected virtual bool OnNormalInfo(IMessage message) {
            return message.Return(Prior.CreateSortedEntity()
                .Set(Properties.Name, this.Get(Properties.Name))
                .Set(Properties.Path, this.Get(Properties.Path)));
        }
        protected virtual bool OnDetailsInfo(IMessage message) => OnNormalInfo(message);
    }
}
