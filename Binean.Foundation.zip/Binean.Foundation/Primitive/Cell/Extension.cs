﻿using System.Reflection;

namespace Binean.Foundation.Primitive {
    public static partial class Extension {
        public static IFormat? GetFormat(this ICell cell, BID name) {
            if (cell is not IGettable gettable) return null;
            if (gettable.TryGetNotNull(Properties.Formats, out IGettable? format) && format.Get(name).As<IFormat>() is IFormat retVal) return retVal;
            return cell.Owner == null ? BDomain._formats.Get(name).As<IFormat>() : cell.Owner.GetFormat(name);
        }
    }
}
