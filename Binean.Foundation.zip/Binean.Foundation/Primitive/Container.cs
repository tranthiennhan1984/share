﻿namespace Binean.Foundation.Primitive {
    public sealed class Container(SetDelegate? beginSetDelegate, SetDelegate? removeDelegate = null) : Avatar {
        private readonly SetDelegate? _beginSetDelegate = beginSetDelegate;
        private readonly SetDelegate? _removeDelegate = removeDelegate;

        public override bool TrySetValue(BID name, object? value) {
            if (_beginSetDelegate != null && !_beginSetDelegate(name, value)) return false;
            return base.TrySetValue(name, value);
        }
        public override bool TryRemoveValue(BID name) {
            if (!TryGetValue(name, out var value)) value = null;
            if (_removeDelegate != null && !_removeDelegate(name, value)) return false;
            return base.TryRemoveValue(name);
        }
    }
}