﻿namespace Binean.Foundation.Primitive {
    public interface ILockable {
        bool IsReadOnly { get; set; }
    }
}
