﻿namespace Binean.Foundation.Primitive {
    [BLog]
    internal static class Logs {
        public const string BFND20101E = "Cannot unbox '{0}' to '{1}'.";
        public const string BFND20102E = "Cannot convert '{0}' to type '{1}'.";

        public const string BFND20202E = "Cannot convert '{0}' to path.";
        public const string BFND20203E = "Invalid token '{0}'.";
        public const string BFND20204E = "Token's name is expected.";
        public const string BFND20205E = "Token's name is unexpected.";

        public const string BFND20206E = "Cannot set property: '{0}' to {1}.";
        public const string BFND20207E = "Cannot remove property: '{0}' from {1}.";
        public const string BFND20208E = "Cannot get property '{0}' as type '{1}'.";

        public const string BFND20211E = "Invalid {0} character: '{1}'.";
        public const string BFND20212E = "Argument must be a {0} instance: '{1}'.";

        public const string BFND20223E = "Initialize fault; reader is already initialized.";

        public const string BFND20301E = "Token '{0}' is expected.";
        public const string BFND20302E = "Read fault; reader is closed.";

        public const string BFND20401E = "Invalid token.";
    }
}