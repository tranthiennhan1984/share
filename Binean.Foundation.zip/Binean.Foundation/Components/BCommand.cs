﻿
namespace Binean.Foundation.Components {
    [Avatar]
    public class BCommand : BField {
        [AvatarProperty]
        public IGetter? Command { get; set; }
    }
}
