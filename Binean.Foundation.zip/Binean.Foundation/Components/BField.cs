﻿
namespace Binean.Foundation.Components {
    [Avatar]
    public class BField : Avatar {
        [AvatarProperty]
        public bool Visible { get; set; } = true;

        [AvatarProperty]
        public string? Text { get; set; }

        [AvatarProperty]
        public object? Icon { get; set; }

    }
}
