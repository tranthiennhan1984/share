﻿
using Binean.Private;
using System.Runtime.CompilerServices;

namespace Binean.Foundation.Logging {
    public static class LogStorage {
        private static readonly Entity _logs = Prior.CreateSortedEntity();
        public static void Load(Type type)
            => Helper.LoadLogs(_logs, type);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static IEntity SomethingWrongMessage()
            => Helper.GenerateLog(_logs, nameof(Logs.BFND90201E));
        public static IEntity GenerateLog(string logId, params object?[] args)
            => Helper.GenerateLog(_logs, logId, args);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BError CreateError(string logId, params object?[] args)
            => CreateError(null, logId, args);

        public static BError CreateError(Exception? innerException, string logId, params object?[] args) {
            var msg = GenerateLog(logId, args);
            if (innerException != null) msg.Set(Properties.Exception, innerException);
            return new(msg, innerException);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static BError CreateError(this IGetter logMessage, Exception? innerException = null)
            => new(logMessage, innerException);
    }
}
