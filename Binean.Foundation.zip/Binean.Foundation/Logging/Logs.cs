﻿namespace Binean.Foundation.Logging {
    [BLog]
    internal static class Logs {
        public const string BFND90101E = "This field is required.";
        public const string BFND90201E = "Oops, Something went wrong.";
    }
}
