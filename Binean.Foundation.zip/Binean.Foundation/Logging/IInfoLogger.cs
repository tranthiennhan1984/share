﻿namespace Binean.Foundation.Logging {
    public interface IInfoLogger : ILogger {
        bool SkipSuccess { get; set; }
        void Log(IMessage message);
    }
}
