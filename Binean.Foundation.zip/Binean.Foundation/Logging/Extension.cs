﻿using System.Collections;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace Binean.Foundation.Logging {
    public static partial class Extension {
        #region :: Logger ::
        public static BError CreateException(this ILogger logger, string logId, params object?[] args) {
            var msg = InGenerateLog(logger, out LogLevel _, logId, args);
            if (msg != null) logger.Log(msg.Trace());
            return LogStorage.CreateError(logId, args);
        }
        public static void Log(this ILogger logger, IList? logs) {
            if (logs is null || logs.Count == 0) return;
            var length = logs.Count;
            for (int i = 0; i < length; i++) {
                if (logs[i] is IEntity msg) logger.Log(msg);
            }
        }
        public static IEntity ToMessage(this Exception ex) {
            IEntity msg;
            if (ex is BError bex) msg = (Men.Clone(bex.Content) as IEntity) ?? Prior.CreateEntity();
            else {
                msg = LogStorage.SomethingWrongMessage().Set(Properties.LogTime, DateTime.Now);
                var txt = ex.Message;
                if (!string.IsNullOrWhiteSpace(txt)) msg.Set(Properties.Message, $"{msg.Get(Properties.Message)} {txt}");
                msg.Trace();
            }
            return msg.Set(Properties.Exception, ex);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T? AssertSupport<T>(this T? logger, LogLevel level) where T : ILogger {
            return logger != null && logger.MinimumLevel <= level ? logger : default;
        }

        private static IEntity? InGenerateLog<T>(T? logger, out LogLevel logLevel, BID logId, params object?[] args) where T : ILogger {
            var retVal = LogStorage.GenerateLog(logId, args);
            logLevel = retVal.Get(Properties.LogLevel, LogLevel.Verbose);
            if (logger.AssertSupport(logLevel) is null) return null;
            return retVal.Set(Properties.LogTime, DateTime.Now);
        }

        public static bool Log(this ILogger logger, BID logId, params object?[] args) {
            var msg = InGenerateLog(logger, out LogLevel level, logId, args) ?? throw new InvalidOperationException();
            logger.Log(msg.Trace());
            return level < LogLevel.Error;
        }
        public static T Trace<T>(this T entity, int index = 2) where T : IEntity {
            if (new StackTrace(1).GetFrame(index) is StackFrame stackFrame)
                entity.Set(Properties.Trace, stackFrame);
            return entity;
        }

        public static void WriteLogs(this ISerlogger logger, ILogger newLogger) {
            using (var reader = logger.Serialize()) {
                if (Men.ToObject(reader) is IList logs) {
                    foreach (var item in logs) {
                        if (item is not IGetter log) continue;
                        newLogger.Log(log);
                    }
                }
            }
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void WriteDebug(this ISerlogger logger)
            => logger.WriteLogs(new DebugLogger());

        #endregion
    }
}
