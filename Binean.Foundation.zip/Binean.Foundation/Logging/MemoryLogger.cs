﻿using System.Collections;


namespace Binean.Foundation.Logging {
    public class MemoryLogger(IList items) : ISerlogger {
        private readonly object _lock = new();
        protected readonly IList _items = items ?? new List<IEntity>();

        public MemoryLogger() : this(new List<IEntity>()) { }

        public object Lock => _lock;
        public LogLevel MinimumLevel {
            get { return _minimumLevel; }
            set {
                if (value > LogLevel.Warning) return;
                _minimumLevel = value;
            }
        }
        private LogLevel _minimumLevel = LogLevel.Verbose;

        public LogLevel MaxLogLevel { get; protected set; }
        public IGetter? ErrorMessage { get; protected set; }

        public virtual void Log(IGetter message) {
            var level = message.Get(Properties.LogLevel, LogLevel.Verbose);
            if (level < MinimumLevel) return;
            if (level >= LogLevel.Error) ErrorMessage = message;
            lock (_lock) {
                _items.Add(message);
                if (level > MaxLogLevel) MaxLogLevel = level;
            }
        }
        public Reader Serialize() => Men.Serialize(_items)!;
        public void Clear() {
            lock (_lock) {
                _items.Clear();
            }
        }
    }
    file static class Properties {
        public static readonly BID Id = nameof(Id);
        public static readonly BID LogLevel = nameof(LogLevel);
        public static readonly BID ErrorCode = nameof(ErrorCode);
        public static readonly BID Exception = nameof(Exception);
        public static readonly BID Message = nameof(Message);
    }
}
