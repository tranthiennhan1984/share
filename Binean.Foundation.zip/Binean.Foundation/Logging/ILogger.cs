﻿

namespace Binean.Foundation.Logging {
    public interface ILogger {
        IGetter? ErrorMessage { get; }
        LogLevel MinimumLevel { get; set; }
        LogLevel MaxLogLevel { get; }
        void Log(IGetter message);
    }

    public enum LogLevel {
        Verbose = 0,
        Debug = 1,
        Information = 2,
        Warning = 3,
        Error = 4,
        Fatal = 5
    }
}