﻿namespace Binean.Foundation.Logging {
    public static class Properties {
    }
}
