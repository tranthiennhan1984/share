﻿

namespace Binean.Foundation.Logging {
    public sealed class MixLogger : ISerlogger {
        private readonly ISerlogger _logger;
        public MixLogger(ISerlogger src) {
            _logger = src;
            Items.Add(_logger);
        }
        public List<ISerlogger> Items { get; } = [];
        public LogLevel MinimumLevel {
            get { return _logger.MinimumLevel; }
            set { _logger.MinimumLevel = value; }
        }
        public LogLevel MaxLogLevel => _logger.MaxLogLevel;
        public IGetter? ErrorMessage => _logger.ErrorMessage;

        public void Clear() {
            var length = Items.Count;
            for (int i = 0; i < length; i++) {
                Items[i].Clear();
            }
        }

        public Reader Serialize() => _logger.Serialize();
        public void Log(IGetter message) {
            var length = Items.Count;
            if (length > 0) Items[0].Log(message);
            for (int i = 1; i < length; i++) {
                Items[i].Log(Men.Clone(message).To<IGetter>()!);
            }
        }
    }
}
