﻿namespace Binean.Foundation.Logging {
    public interface ISerlogger : ILogger {
        Reader Serialize();
        void Clear();
    }
}
