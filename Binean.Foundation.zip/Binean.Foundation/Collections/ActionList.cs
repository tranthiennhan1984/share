﻿namespace Binean.Foundation.Collections {
    public class ActionList {
        private readonly List<Action> _actions = [];
        public ActionList() { }
        public void Invoke() {
            var length = _actions.Count;
            for (int i = 0; i < length; i++) {
                _actions[i].Invoke();
            }
        }
        public ActionList AddFirst(Action? action) {
            if (action != null) _actions.Insert(0, action);
            return this;
        }
        public ActionList AddLast(Action? action) {
            if (action != null) _actions.Add(action);
            return this;
        }
        public ActionList Remove(Action? action) {
            if (action != null) _actions.Remove(action);
            return this;
        }
    }

    public class ActionList<T> {
        private readonly List<Action<T>> _actions = [];

        public ActionList() { }
        public void Invoke(T args) {
            var length = _actions.Count;
            for (int i = 0; i < length; i++) {
                _actions[i].Invoke(args);
            }
        }

        public ActionList<T> AddFirst(Action<T>? action) {
            if (action != null) _actions.Insert(0, action);
            return this;
        }
        public ActionList<T> AddLast(Action<T>? action) {
            if (action != null) _actions.Add(action);
            return this;
        }
        public ActionList<T> Remove(Action<T>? action) {
            if (action != null) _actions.Remove(action);
            return this;
        }
    }
}
