﻿using System.Runtime.CompilerServices;

namespace Binean.Foundation.Collections {
    public static partial class Extension {
        public static T[] ToArray<T>(this IList<T> list) {
            T[] retVal = new T[list.Count];
            list.CopyTo(retVal, 0);
            return retVal;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T[] ToArray<T>(this T[] source, int offset, int count) {
            if (offset == 0 && count == source.Length) return source;
            var retVal = new T[count];
            Array.Copy(source, offset, retVal, 0, count);
            return retVal;
        }

        public static bool BinarySearch<T, V>(this T set, int length, Func<T, int, V> getter, Func<V, int> comparison, out int index) {
            if (length == 0) {
                index = ~0;
                return false;
            }
            var low = 0;
            var hi = length - 1;

            var comp = hi < 0 ? 1 : comparison(getter(set, hi));
            if (comp == 0) return (index = hi) > -1;
            else if (comp < 0) return (index = ~(hi + 1)) > -1;
            hi--;

            comp = comparison(getter(set, low));
            if (comp == 0) return (index = low) > -1;
            else if (comp > 0) return (index = ~low) > -1;
            low++;

            while (low <= hi) {
                var mid = low + ((hi - low) >> 1);
                comp = comparison(getter(set, mid));
                if (comp == 0) return (index = mid) > -1;

                if (comp > 0) hi = mid - 1;
                else low = mid + 1;
            }
            index = ~low;
            return false;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static TC Diff<TC, TI>(this TC dList, IEnumerable<TI>? source, IEnumerable<TI>? target, IComparer<TI> comparer, Differ<TC, TI> differ, Func<TI?, bool> isNull)
            => Diff(dList, source, target, comparer.Compare, differ, isNull);
        public static TC Diff<TC, TI>(this TC dList, IEnumerable<TI>? source, IEnumerable<TI>? target, Comparison<TI> comparer, Differ<TC, TI> differ, Func<TI?, bool> isNull) {
            var sList = new List<TI>();
            var tList = new List<TI>();

            if (source != null) sList.AddRange(source);
            sList.Sort(comparer);

            if (target != null) tList.AddRange(target);
            tList.Sort(comparer);

            var sLen = sList.Count;
            var tLen = tList.Count;
            int sInd = 0;
            int tInd = 0;
            while (true) {
                var sItm = sInd < sLen ? sList[sInd] : default;
                var tItm = tInd < tLen ? tList[tInd] : default;

                var sNull = isNull(sItm);
                var tNull = isNull(tItm);
                if (sNull && tNull) {
                    if (sInd < sLen) sInd++;
                    if (tInd < tLen) tInd++;
                    if (sInd >= sLen && tInd >= tLen) break;
                    continue;
                }

                int comp = sNull ? 1 : tNull ? -1 : comparer(sItm!, tItm!);

                differ(dList, comp, sItm, tItm);

                sInd += comp <= 0 ? 1 : 0;
                tInd += comp >= 0 ? 1 : 0;
                continue;
            }
            return dList;
        }
    }

    public delegate void Differ<TC, TI>(TC container, int comp, TI? source, TI? target);
}
